# GENT — Node 22 Premium Founder Edition · Bundle d'installation

Runtime souverain Node 22 LTS cloné + transformé + durci. IDE local **+ mode
Build Vision** (voir son site se construire en direct). Identité unique
d'instance. Service systemd autostart :4310. Raccourci bureau.
**Zone sacrée `~/Aether` : jamais lue, jamais écrite (garde-fou codé).**

## Contenu du bundle

| Fichier | Rôle |
|---|---|
| `gent-install.sh` | Installeur complet (clone Node 22, transformation PFE, identité, IDE + Build Vision, systemd, bureau, scaffold Git) |
| `gent-upgrade-vision.sh` | Upgrade **Build Vision 1.0** sur une installation existante (sauvegarde + rollback auto, identité conservée) |
| `gent-set-port.sh` | Déménagement instantané de port (unité systemd + identité + CLI + raccourcis, `--auto` = 1er port libre) |
| `gent-build.sh`   | Script de build Premium (intégrité, warmup compile-cache V8, manifeste SHA256, tarball dist) |
| `gent-git-push.sh`| Publication vers l'organisation GitHub (+ cheatsheet des commandes Git) |
| `gent-verify.sh`  | Protocole senior : 9 contrôles PASS/FAIL/SKIP |
| `app/gent-server.js` | Le serveur souverain Build Vision (référence ; embarqué aussi dans l'installeur) |

## BUILD VISION — le site se construit sous tes yeux

Trois panneaux : **Éditeur** (gutter numéroté, marques d'erreur) | **Terminal
de build** (les 5 étapes datées) | **Live Preview** (iframe rechargée par
hot-reload SSE). Statut permanent : `● Prêt` → `⚡ Compilation…` →
`✅ Succès · ms` / `❌ Erreur`. Raccourcis : **Ctrl+S** = enregistrer +
analyser, **Ctrl+Entrée** = Build & Run.

```mermaid
graph TD
    A[Utilisateur tape le code] -->|éditeur + auto-validation| B{"Analyse AST V8\n+ lint stdlib"}
    B -->|erreur| C[Bloquer · surligner ligne + colonne]
    B -->|propre| D[Compilation sèche node --check]
    D -->|échec| C
    D -->|OK| E[Exécution sandbox\npermission model]
    E --> F[Publication + Hot Reload SSE\nLive Preview iframe]
    style A fill:#00d4ff,color:#000
    style F fill:#00ff9d,color:#000
    style C fill:#ff2d55,color:#fff
```

Le **protocole zéro erreur** ne touche jamais à `node` avant d'avoir prouvé le
code. Étage 1 : parse **AST réel par le moteur V8** (`vm.Script`) — erreur
grepée avec ligne exacte (`demo.js:2`). Étage 2 : lint stdlib maison —
`debugger`/`eval`/`with` = bloquants ; `==`, `var`, `new Function`, TODO,
lignes > 120 col = avertissements. Étage 3 : **`node --check`** (byte-compile
sans exécuter). Puis exécution sandboxée (`--permission`) et publication.
Pour un `.html` : vérification des **références** (`src=`/`href=` locaux) —
une brique manquante bloque le build et est nommée.

Endpoints nouveaux : `POST /api/validate` (étages 1+2, jamais d'exécution),
`POST /api/build` (pipeline complet + publication), `GET /api/events?t=…`
(SSE hot reload), `GET /preview/<fichier>?t=…` (servage workspace au
navigateur, types filtrés, fichiers cachés interdits). Une démo est seedée
automatiquement : `workspace/demo-vision/` — les blocs se posent comme une
maison qui s'élève.

```bash
bash gent-upgrade-vision.sh     # sur une install existante (identité conservée)
# puis ouvrir :  http://127.0.0.1:<PORT>/vision
```

## Installation (2 commandes)

```bash
bash gent-install.sh              # port dédié 4310 par défaut
gent verify                       # protocole senior immédiat
```

Options : `--port NNNN` · `--version v22.x.y` · `--home /chemin/isole` ·
`--no-service` · `--selftest` (test hors-ligne sans réseau).

## Build Premium

```bash
gent build
```

## Publication GitHub (organisation officielle)

```bash
bash ~/gent/scripts/gent-git-push.sh MON-ORG gent-node22-pfe

# ou manuellement :
cd ~/gent/repo
git remote add origin git@github.com:MON-ORG/gent-node22-pfe.git
git push -u origin main
git push origin --tags
```

`identity/` (jeton), `runtime/`, `logs/`, `cache/`, `workspace/` sont
exclus par `.gitignore` + garde anti-fuite dans le script.

## Sécurité embarquée (prouvée en test sur Node v22.23.4)

- SHA256 strict contre `SHASUMS256.txt` officiel nodejs.org ;
- API de l'IDE protégée par jeton d'instance (401 sans jeton) ;
- exécution code via **modèle de permission Node 22** (`ERR_ACCESS_DENIED`
  sur toute lecture/écriture hors workspace) ;
- refus des traversées de chemin (400) ;
- bind 127.0.0.1 uniquement, sandbox systemd (`NoNewPrivileges`,
  `PrivateTmp`, `ProtectSystem=full`, UMask 0077) ;
- identité `GENT-xxxx-xxxx-xxxx-xxxx` + registre de builds append-only.

## Accès

- IDE classique : `http://127.0.0.1:4310/` (ou `gent open`, ou raccourci bureau)
- **Build Vision : `http://127.0.0.1:4310/vision`** (3 panneaux + hot reload)
- Identité : `gent id`
- Santé : `gent status`
