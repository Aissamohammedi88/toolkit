// ════════════════════════════════════════════════════════════════════════════
// NEXUS-DOCTOR — Module booster.rs (Mode Ferrari)
// Boost la performance du PC comme une Ferrari
// ════════════════════════════════════════════════════════════════════════════
use std::fs;
use std::process::Command;
use std::time::Instant;

pub struct Action {
    pub title: String,
    pub detail: String,
    pub needs_root: bool,
    pub cmd: String,
    pub args: Vec<String>,
}

pub struct ActionResult {
    pub title: String,
    pub success: bool,
    pub duration_ms: u128,
    pub error: String,
}

pub fn plan_actions() -> Vec<Action> {
    let mut actions = Vec::new();

    // CPU governor → performance
    actions.push(Action {
        title: "CPU governor → performance".into(),
        detail: "Tous les cœurs en fréquence max".into(),
        needs_root: true,
        cmd: "bash".into(),
        args: vec![
            "-c".into(),
            "for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo performance | sudo tee $f >/dev/null; done".into(),
        ],
    });

    // vm.swappiness = 10
    actions.push(Action {
        title: "vm.swappiness = 10".into(),
        detail: "Réduit l'usage du swap (desktop optimal)".into(),
        needs_root: true,
        cmd: "sudo".into(),
        args: vec!["sysctl".into(), "vm.swappiness=10".into()],
    });

    // vfs_cache_pressure = 50
    actions.push(Action {
        title: "vfs_cache_pressure = 50".into(),
        detail: "Garde plus de dentries/inodes en cache".into(),
        needs_root: true,
        cmd: "sudo".into(),
        args: vec!["sysctl".into(), "vm.vfs_cache_pressure=50".into()],
    });

    // IO scheduler → none (pour SSD NVMe)
    actions.push(Action {
        title: "IO scheduler → none (SSD)".into(),
        detail: "Désactive le scheduler pour SSD NVMe".into(),
        needs_root: true,
        cmd: "bash".into(),
        args: vec![
            "-c".into(),
            "for d in /sys/block/nvme*n*/queue/scheduler /sys/block/sd*/queue/scheduler; do [ -f \"$d\" ] && echo none | sudo tee $d >/dev/null 2>&1; done".into(),
        ],
    });

    // TCP BBR congestion control
    actions.push(Action {
        title: "TCP congestion = bbr".into(),
        detail: "Meilleur débit réseau (vs cubic)".into(),
        needs_root: true,
        cmd: "bash".into(),
        args: vec![
            "-c".into(),
            "echo net.ipv4.tcp_congestion_control=bbr | sudo tee -a /etc/sysctl.d/99-nexus.conf >/dev/null && sudo sysctl -p /etc/sysctl.d/99-nexus.conf >/dev/null 2>&1".into(),
        ],
    });

    // tcp_fastopen = 3
    actions.push(Action {
        title: "tcp_fastopen = 3".into(),
        detail: "Active TCP Fast Open (client+server)".into(),
        needs_root: true,
        cmd: "sudo".into(),
        args: vec!["sysctl".into(), "net.ipv4.tcp_fastopen=3".into()],
    });

    // Drop caches (page + dentry + inode)
    actions.push(Action {
        title: "Drop page cache (echo 3)".into(),
        detail: "Vide caches kernel — utile après grosse charge".into(),
        needs_root: true,
        cmd: "bash".into(),
        args: vec!["-c".into(), "sync && echo 3 | sudo tee /proc/sys/vm/drop_caches >/dev/null".into()],
    });

    // Memory compaction
    actions.push(Action {
        title: "compact_memory (réduit fragmentation)".into(),
        detail: "Défragmente la mémoire physique".into(),
        needs_root: true,
        cmd: "bash".into(),
        args: vec!["-c".into(), "echo 1 | sudo tee /proc/sys/vm/compact_memory >/dev/null 2>&1".into()],
    });

    // TRIM sur SSD
    actions.push(Action {
        title: "fstrim (TRIM SSD)".into(),
        detail: "Indique au SSD les blocs libres".into(),
        needs_root: true,
        cmd: "sudo".into(),
        args: vec!["fstrim".into(), "-av".into()],
    });

    // Priorité process courant
    actions.push(Action {
        title: "nice -n -10 (process courant)".into(),
        detail: "Donne priorité élevée au shell actuel".into(),
        needs_root: false,
        cmd: "bash".into(),
        args: vec!["-c".into(), "renice -n -10 -p $$ 2>/dev/null".into()],
    });

    // Disable kernel debugging (perf gain)
    actions.push(Action {
        title: "kernel.kptr_restrict = 1".into(),
        detail: "Cache les pointeurs kernel (perf + sécurité)".into(),
        needs_root: true,
        cmd: "sudo".into(),
        args: vec!["sysctl".into(), "kernel.kptr_restrict=1".into()],
    });

    // Augmenter max FD
    actions.push(Action {
        title: "fs.file-max = 2097152".into(),
        detail: "Augmente limite fichiers ouverts système".into(),
        needs_root: true,
        cmd: "sudo".into(),
        args: vec!["sysctl".into(), "fs.file-max=2097152".into()],
    });

    actions
}

pub fn execute(actions: &[Action]) -> Vec<ActionResult> {
    let mut results = Vec::new();
    for a in actions {
        let start = Instant::now();
        let status = Command::new(&a.cmd)
            .args(&a.args)
            .output();
        let dur = start.elapsed().as_millis();
        match status {
            Ok(o) if o.status.success() => results.push(ActionResult {
                title: a.title.clone(),
                success: true,
                duration_ms: dur,
                error: "".into(),
            }),
            Ok(o) => {
                let err = String::from_utf8_lossy(&o.stderr).to_string();
                let err_short: String = err.chars().take(80).collect();
                results.push(ActionResult {
                    title: a.title.clone(),
                    success: false,
                    duration_ms: dur,
                    error: if err_short.is_empty() { "exit code non-zero".into() } else { err_short },
                });
            }
            Err(e) => results.push(ActionResult {
                title: a.title.clone(),
                success: false,
                duration_ms: dur,
                error: e.to_string(),
            }),
        }
    }
    results
}

// Snapshots before/after pour comparaison
pub fn snapshot() -> String {
    let mut s = String::new();
    if let Ok(gov) = fs::read_to_string("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor") {
        s.push_str(&format!("governor={}\n", gov.trim()));
    }
    if let Ok(swap) = fs::read_to_string("/proc/sys/vm/swappiness") {
        s.push_str(&format!("swappiness={}\n", swap.trim()));
    }
    if let Ok(mem) = fs::read_to_string("/proc/meminfo") {
        for line in mem.lines() {
            if line.starts_with("MemAvailable") || line.starts_with("SwapFree") {
                s.push_str(line);
                s.push('\n');
            }
        }
    }
    s
}
