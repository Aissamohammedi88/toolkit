// ════════════════════════════════════════════════════════════════════════════
// NEXUS-DOCTOR — ui_dashboard.ts (TypeScript, 3% of project)
// Génère un dashboard HTML live avec les vitales du PC
// Lancé par : node ui_dashboard.ts <output.html>
// ════════════════════════════════════════════════════════════════════════════

import * as fs from 'fs';
import * as os from 'os';
import { execSync } from 'child_process';

interface Vitals {
  hostname: string;
  arch: string;
  kernel: string;
  uptime: string;
  loadAvg: number[];
  cpus: { model: string; speed: number }[];
  mem: { total: number; free: number; usedPercent: number };
  diskUsage: { fs: string; mount: string; percent: number }[];
  topProcesses: { pid: number; cpu: number; mem: number; cmd: string }[];
  networkInterfaces: string[];
  ferrariScore?: number;
}

function sh(cmd: string): string {
  try {
    return execSync(cmd, { encoding: 'utf8', timeout: 5000 }).trim();
  } catch {
    return '';
  }
}

function collectVitals(): Vitals {
  const hostname = os.hostname();
  const arch = os.arch();
  const kernel = os.release();
  const uptime = os.uptime();
  const days = Math.floor(uptime / 86400);
  const hours = Math.floor((uptime % 86400) / 3600);
  const mins = Math.floor((uptime % 3600) / 60);
  const uptimeStr = `${days}j ${hours}h ${mins}m`;

  const loadAvg = os.loadavg();
  const cpus = os.cpus().map(c => ({
    model: c.model,
    speed: c.speed,
  }));

  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedPercent = Math.round(((totalMem - freeMem) / totalMem) * 100);

  // Disk usage via df
  const df = sh('df -h --output=source,target,pcent --type=ext4 --type=btrfs --type=xfs 2>/dev/null');
  const diskUsage = df.split('\n').slice(1).map(line => {
    const parts = line.trim().split(/\s+/);
    return {
      fs: parts[0] || '',
      mount: parts[1] || '',
      percent: parseInt(parts[2]?.replace('%', '') || '0', 10),
    };
  }).filter(d => d.mount);

  // Top processes
  const ps = sh('ps aux --sort=-%cpu | head -10');
  const topProcesses = ps.split('\n').slice(1).map(line => {
    const parts = line.trim().split(/\s+/);
    return {
      pid: parseInt(parts[1], 10),
      cpu: parseFloat(parts[2]),
      mem: parseFloat(parts[3]),
      cmd: parts.slice(10).join(' '),
    };
  });

  const networkInterfaces = Object.keys(os.networkInterfaces())
    .filter(name => !name.startsWith('lo'));

  return {
    hostname, arch, kernel,
    uptime: uptimeStr, loadAvg, cpus, mem: { total: totalMem, free: freeMem, usedPercent },
    diskUsage, topProcesses, networkInterfaces,
  };
}

function generateHTML(v: Vitals): string {
  const memGB = (b: number) => (b / 1024 / 1024 / 1024).toFixed(2);
  const memColor = v.mem.usedPercent > 85 ? '#dc3545' : v.mem.usedPercent > 70 ? '#ffc107' : '#28a745';
  const loadColor = v.loadAvg[0] > v.cpus.length ? '#dc3545' : '#28a745';

  const cpuBars = v.cpus.slice(0, 8).map((c, i) => `
    <div class="cpu-bar">
      <span class="cpu-label">CPU${i}</span>
      <div class="bar"><div class="bar-fill" style="width:${(c.speed / 4000) * 100}%;background:linear-gradient(90deg,#58a6ff,#bc8cff)"></div></div>
      <span class="cpu-speed">${(c.speed / 1000).toFixed(2)} GHz</span>
    </div>`).join('');

  const diskRows = v.diskUsage.map(d => `
    <tr>
      <td><code>${d.fs}</code></td>
      <td>${d.mount}</td>
      <td><div class="bar"><div class="bar-fill" style="width:${d.percent}%;background:${d.percent > 85 ? '#dc3545' : d.percent > 70 ? '#ffc107' : '#28a745'}"></div></div></td>
      <td><strong>${d.percent}%</strong></td>
    </tr>`).join('');

  const procRows = v.topProcesses.slice(0, 8).map(p => `
    <tr>
      <td>${p.pid}</td>
      <td>${p.cmd.slice(0, 50)}</td>
      <td><span style="color:${p.cpu > 50 ? '#dc3545' : p.cpu > 20 ? '#ffc107' : '#28a745'}">${p.cpu.toFixed(1)}%</span></td>
      <td>${p.mem.toFixed(1)}%</td>
    </tr>`).join('');

  return `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>NEXUS-DOCTOR Dashboard — ${v.hostname}</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: -apple-system, 'Segoe UI', system-ui, sans-serif;
  background: linear-gradient(135deg, #0d1117 0%, #161b22 100%);
  color: #c9d1d9;
  min-height: 100vh;
  padding: 24px;
}
.container { max-width: 1400px; margin: 0 auto; }
header {
  display: flex; justify-content: space-between; align-items: center;
  padding: 24px; background: rgba(88, 166, 255, 0.1);
  border-radius: 12px; border: 1px solid rgba(88, 166, 255, 0.2);
  margin-bottom: 24px;
}
h1 {
  font-size: 28px; font-weight: 800;
  background: linear-gradient(135deg, #58a6ff, #bc8cff);
  -webkit-background-clip: text; background-clip: text; color: transparent;
}
.subtitle { color: #8b949e; font-size: 13px; margin-top: 4px; }
.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 16px; margin-bottom: 24px; }
.card {
  background: rgba(22, 27, 34, 0.8);
  border: 1px solid rgba(88, 166, 255, 0.2);
  border-radius: 12px; padding: 20px;
  backdrop-filter: blur(10px);
}
.card h2 {
  font-size: 14px; color: #8b949e;
  text-transform: uppercase; letter-spacing: 0.1em;
  margin-bottom: 16px; font-weight: 600;
}
.big-num { font-size: 36px; font-weight: 800; }
.unit { font-size: 14px; color: #8b949e; margin-left: 4px; }
.bar {
  height: 8px; background: rgba(255,255,255,0.1); border-radius: 4px;
  overflow: hidden; flex: 1; margin: 0 8px;
}
.bar-fill { height: 100%; transition: width 0.5s ease; }
.cpu-bar { display: flex; align-items: center; gap: 8px; margin: 6px 0; font-size: 12px; }
.cpu-label { width: 50px; color: #8b949e; }
.cpu-speed { width: 80px; text-align: right; color: #c9d1d9; }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
th { text-align: left; color: #8b949e; padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,0.1); font-weight: 600; }
td { padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,0.05); }
code { background: rgba(255,255,255,0.08); padding: 2px 6px; border-radius: 4px; font-family: 'SF Mono', monospace; font-size: 11px; color: #58a6ff; }
.ferrari {
  text-align: center; padding: 32px;
  background: linear-gradient(135deg, rgba(188, 140, 255, 0.2), rgba(88, 166, 255, 0.2));
  border-radius: 16px; margin-bottom: 24px;
}
.ferrari-score { font-size: 64px; font-weight: 900; color: #bc8cff; }
.ferrari-label { color: #8b949e; font-size: 14px; text-transform: uppercase; letter-spacing: 0.2em; }
footer { text-align: center; color: #8b949e; font-size: 12px; padding: 24px 0; }
.live-dot {
  display: inline-block; width: 8px; height: 8px;
  background: #28a745; border-radius: 50%; margin-right: 6px;
  animation: pulse 1.5s infinite;
}
@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
</style>
</head>
<body>
<div class="container">
  <header>
    <div>
      <h1>NEXUS-DOCTOR</h1>
      <div class="subtitle">Dashboard live · ${v.hostname} · ${new Date().toLocaleString('fr-FR')}</div>
    </div>
    <div><span class="live-dot"></span>Live</div>
  </header>

  <div class="ferrari">
    <div class="ferrari-label">Vitals PC</div>
    <div class="ferrari-score">${v.mem.usedPercent}%</div>
    <div class="subtitle">Utilisation RAM</div>
  </div>

  <div class="grid">
    <div class="card">
      <h2>Système</h2>
      <p><strong>Hostname:</strong> ${v.hostname}</p>
      <p><strong>Kernel:</strong> ${v.kernel}</p>
      <p><strong>Arch:</strong> ${v.arch}</p>
      <p><strong>Uptime:</strong> ${v.uptime}</p>
      <p><strong>Load:</strong> <span style="color:${loadColor}">${v.loadAvg.map(l => l.toFixed(2)).join(' / ')}</span></p>
    </div>
    <div class="card">
      <h2>Mémoire</h2>
      <div class="big-num" style="color:${memColor}">${v.mem.usedPercent}<span class="unit">%</span></div>
      <p style="margin-top:8px"><strong>${memGB(v.mem.total - v.mem.free)}</strong> / ${memGB(v.mem.total)} GB utilisés</p>
      <p style="margin-top:8px">${memGB(v.mem.free)} GB libres</p>
    </div>
    <div class="card">
      <h2>CPU — ${v.cpus[0]?.model || '?'}</h2>
      <p style="font-size:12px;margin-bottom:8px;color:#8b949e">${v.cpus.length} cœurs logiques</p>
      ${cpuBars}
    </div>
  </div>

  <div class="card" style="margin-bottom:24px">
    <h2>Disques</h2>
    <table>
      <thead><tr><th>Device</th><th>Mount</th><th>Usage</th><th>%</th></tr></thead>
      <tbody>${diskRows}</tbody>
    </table>
  </div>

  <div class="card">
    <h2>Top processus</h2>
    <table>
      <thead><tr><th>PID</th><th>Command</th><th>CPU</th><th>MEM</th></tr></thead>
      <tbody>${procRows}</tbody>
    </table>
  </div>

  <footer>
    NEXUS-DOCTOR v1.0 · Aissa Mohammedi (DGK) — Nexus Quantum<br>
    Generated by TypeScript via <code>node ui_dashboard.ts</code> · ${new Date().toISOString()}
  </footer>
</div>
</body>
</html>`;
}

// Main
const args = process.argv.slice(2);
const outputPath = args[0] || process.env.HOME + '/nexus-doctor-dashboard.html';

const vitals = collectVitals();
const html = generateHTML(vitals);
fs.writeFileSync(outputPath, html, 'utf8');
console.log(`[NEXUS-DOCTOR] Dashboard généré : ${outputPath}`);
console.log(`[NEXUS-DOCTOR] RAM: ${vitals.mem.usedPercent}% · Load: ${vitals.loadAvg[0].toFixed(2)} · CPU cores: ${vitals.cpus.length}`);
