       *> ═════════════════════════════════════════════════════════════════════
       *> NEXUS-DOCTOR — legacy_log.cob (Cobol, 2% of project)
       *> "Le carnet du docteur" — écrit une entrée de log formatée COBOL
       *> Lancé par : ./legacy_log <findings.json> <output.log>
       *> ═════════════════════════════════════════════════════════════════════

       IDENTIFICATION DIVISION.
       PROGRAM-ID. NEXUS-DOCTOR-LOG.

       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT INPUT-FILE ASSIGN TO DYNAMIC WS-INPUT-NAME
               ORGANIZATION IS LINE SEQUENTIAL
               FILE STATUS IS WS-INPUT-STATUS.
           SELECT OUTPUT-FILE ASSIGN TO DYNAMIC WS-OUTPUT-NAME
               ORGANIZATION IS LINE SEQUENTIAL
               FILE STATUS IS WS-OUTPUT-STATUS.

       DATA DIVISION.
       FILE SECTION.
       FD INPUT-FILE.
       01 INPUT-RECORD PIC X(4096).
       FD OUTPUT-FILE.
       01 OUTPUT-RECORD PIC X(132).

       WORKING-STORAGE SECTION.
       01 WS-INPUT-NAME    PIC X(256).
       01 WS-OUTPUT-NAME   PIC X(256).
       01 WS-INPUT-STATUS  PIC XX.
       01 WS-OUTPUT-STATUS PIC XX.
       01 WS-EOF           PIC X VALUE 'N'.
       01 WS-LINE-COUNT    PIC 9(5) VALUE 0.
       01 WS-FINDING-COUNT PIC 9(5) VALUE 0.
       01 WS-CRITICAL      PIC 9(5) VALUE 0.
       01 WS-HIGH          PIC 9(5) VALUE 0.
       01 WS-MEDIUM        PIC 9(5) VALUE 0.
       01 WS-LOW           PIC 9(5) VALUE 0.
       01 WS-INFO          PIC 9(5) VALUE 0.
       01 WS-DATE.
          05 WS-YEAR       PIC 9(4).
          05 WS-MONTH      PIC 9(2).
          05 WS-DAY        PIC 9(2).
       01 WS-TIME.
          05 WS-HOUR       PIC 9(2).
          05 WS-MIN        PIC 9(2).
          05 WS-SEC        PIC 9(2).
       01 WS-HOSTNAME      PIC X(64).
       01 WS-I             PIC 9(5).
       01 WS-BUFFER        PIC X(4096).

       01 HEADER-LINE.
          05 FILLER        PIC X(2) VALUE SPACES.
          05 HDR-DATE      PIC X(10).
          05 FILLER        PIC X(2) VALUE SPACES.
          05 HDR-TIME      PIC X(8).
          05 FILLER        PIC X(4) VALUE SPACES.
          05 HDR-TEXT      PIC X(80)
             VALUE "NEXUS-DOCTOR LEGACY LOG  ---  LE CARNET DU DOCTEUR".

       01 SEPARATOR-LINE    PIC X(70)
          VALUE ALL "=".

       01 PATIENT-LINE.
          05 FILLER        PIC X(4) VALUE "  P".
          05 PT-LABEL      PIC X(20) VALUE "ATIENT (HOSTNAME) : ".
          05 PT-NAME       PIC X(64).

       01 STATS-LINE.
          05 FILLER        PIC X(4) VALUE "  S".
          05 ST-LABEL      PIC X(20) VALUE "TATISTIQUES EXAMEN ".
          05 ST-COUNT      PIC 9(5).
          05 FILLER        PIC X(5) VALUE " (C:".
          05 ST-C          PIC 9(5).
          05 FILLER        PIC X(5) VALUE " H:".
          05 ST-H          PIC 9(5).
          05 FILLER        PIC X(5) VALUE " M:".
          05 ST-M          PIC 9(5).
          05 FILLER        PIC X(5) VALUE " L:".
          05 ST-L          PIC 9(5).
          05 FILLER        PIC X(5) VALUE " I:".
          05 ST-I          PIC 9(5).
          05 FILLER        PIC X(2) VALUE ")".

       01 SIGNATURE-LINE.
          05 FILLER        PIC X(40) VALUE SPACES.
          05 SIG-TEXT      PIC X(50)
             VALUE "Dr. NEXUS  ---  signature electronique".

       PROCEDURE DIVISION.

       MAIN-PARA.
           ACCEPT WS-INPUT-NAME FROM ARGUMENT-VALUE
           ACCEPT WS-OUTPUT-NAME FROM ARGUMENT-VALUE
           IF WS-INPUT-NAME = SPACES OR WS-OUTPUT-NAME = SPACES
               DISPLAY "Usage: legacy_log <in.json> <out.log>"
               STOP RUN
           END-IF

           ACCEPT WS-DATE FROM DATE YYYYMMDD
           ACCEPT WS-TIME FROM TIME

           DISPLAY "NEXUS-DOCTOR COBOL LOG WRITER"
           DISPLAY "INPUT  : " WS-INPUT-NAME
           DISPLAY "OUTPUT : " WS-OUTPUT-NAME

           OPEN INPUT INPUT-FILE
           IF WS-INPUT-STATUS NOT = "00"
               DISPLAY "ERREUR OUVERTURE INPUT, status=" WS-INPUT-STATUS
               STOP RUN
           END-IF

           OPEN OUTPUT OUTPUT-FILE
           IF WS-OUTPUT-STATUS NOT = "00"
               DISPLAY "ERREUR OUVERTURE OUTPUT"
               STOP RUN
           END-IF

           PERFORM COUNT-FINDINGS
           PERFORM GET-HOSTNAME
           PERFORM WRITE-HEADER
           PERFORM WRITE-PATIENT
           PERFORM WRITE-STATS
           PERFORM WRITE-FINDINGS
           PERFORM WRITE-SIGNATURE

           CLOSE INPUT-FILE
           CLOSE OUTPUT-FILE

           DISPLAY "LOG LEGACY ECRIT : " WS-OUTPUT-NAME
           DISPLAY "FINDINGS TRAITES : " WS-FINDING-COUNT
           STOP RUN.

       COUNT-FINDINGS.
           MOVE 0 TO WS-FINDING-COUNT WS-CRITICAL WS-HIGH
                    WS-MEDIUM WS-LOW WS-INFO
           PERFORM UNTIL WS-EOF = 'Y'
               READ INPUT-FILE
                   AT END
                       MOVE 'Y' TO WS-EOF
                   NOT AT END
                       ADD 1 TO WS-FINDING-COUNT
                       INSPECT INPUT-RECORD
                         TALLYING WS-CRITICAL FOR ALL '"critical"'
                       INSPECT INPUT-RECORD
                         TALLYING WS-HIGH FOR ALL '"high"'
                       INSPECT INPUT-RECORD
                         TALLYING WS-MEDIUM FOR ALL '"medium"'
                       INSPECT INPUT-RECORD
                         TALLYING WS-LOW FOR ALL '"low"'
                       INSPECT INPUT-RECORD
                         TALLYING WS-INFO FOR ALL '"info"'
           END-PERFORM
           CLOSE INPUT-FILE
           OPEN INPUT INPUT-FILE
           MOVE 'N' TO WS-EOF.

       GET-HOSTNAME.
           MOVE "nexus-doctor-host" TO WS-HOSTNAME.

       WRITE-HEADER.
           STRING WS-YEAR "-" WS-MONTH "-" WS-DAY INTO HDR-DATE
           STRING WS-HOUR ":" WS-MIN ":" WS-SEC INTO HDR-TIME
           WRITE OUTPUT-RECORD FROM SEPARATOR-LINE
           WRITE OUTPUT-RECORD FROM HEADER-LINE
           WRITE OUTPUT-RECORD FROM SEPARATOR-LINE.

       WRITE-PATIENT.
           MOVE WS-HOSTNAME TO PT-NAME
           WRITE OUTPUT-RECORD FROM PATIENT-LINE.

       WRITE-STATS.
           MOVE WS-FINDING-COUNT TO ST-COUNT
           MOVE WS-CRITICAL      TO ST-C
           MOVE WS-HIGH          TO ST-H
           MOVE WS-MEDIUM        TO ST-M
           MOVE WS-LOW           TO ST-L
           MOVE WS-INFO          TO ST-I
           WRITE OUTPUT-RECORD FROM STATS-LINE
           WRITE OUTPUT-RECORD FROM SEPARATOR-LINE.

       WRITE-FINDINGS.
           MOVE 0 TO WS-LINE-COUNT
           PERFORM UNTIL WS-EOF = 'Y'
               READ INPUT-FILE
                   AT END
                       MOVE 'Y' TO WS-EOF
                   NOT AT END
                       ADD 1 TO WS-LINE-COUNT
                       IF INPUT-RECORD(1:20) = '                    '
                           CONTINUE
                       ELSE
                           MOVE SPACES TO OUTPUT-RECORD
                           STRING "  " DELIMITED BY SIZE
                                  FUNCTION TRIM(INPUT-RECORD)
                                  DELIMITED BY SIZE
                                  INTO OUTPUT-RECORD
                           WRITE OUTPUT-RECORD
                       END-IF
           END-PERFORM
           WRITE OUTPUT-RECORD FROM SEPARATOR-LINE.

       WRITE-SIGNATURE.
           WRITE OUTPUT-RECORD FROM SIGNATURE-LINE
           WRITE OUTPUT-RECORD FROM SEPARATOR-LINE.
