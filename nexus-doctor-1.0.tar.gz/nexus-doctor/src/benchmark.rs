// ════════════════════════════════════════════════════════════════════════════
// NEXUS-DOCTOR — Module benchmark.rs
// Benchmark CPU/Mem/Disk/Net + Ferrari Score
// ════════════════════════════════════════════════════════════════════════════
use std::fs;
use std::process::Command;
use std::time::{Duration, Instant};

pub struct BenchmarkOptions {
    pub cpu: bool,
    pub memory: bool,
    pub disk: bool,
    pub network: bool,
    pub iterations: u32,
    pub save_results: bool,
}

pub struct BenchmarkResults {
    pub cpu_gflops: f64,
    pub cpu_ms_per_op: f64,
    pub mem_gbps: f64,
    pub mem_ms: f64,
    pub disk_seq_mbps: f64,
    pub disk_rand_mbps: f64,
    pub net_ping_ms: f64,
    pub ferrari_score_val: u32,
}

impl BenchmarkResults {
    pub fn ferrari_score(&self) -> u32 {
        // Composite score /10000
        // CPU (40%) + Mem (25%) + Disk (25%) + Net (10%)
        let cpu_part = (self.cpu_gflops * 200.0).min(4000.0);
        let mem_part = (self.mem_gbps * 150.0).min(2500.0);
        let disk_part = ((self.disk_seq_mbps * 5.0) + (self.disk_rand_mbps * 10.0)).min(2500.0);
        let net_part = (1000.0 / (self.net_ping_ms + 1.0) * 100.0).min(1000.0);
        let total = cpu_part + mem_part + disk_part + net_part;
        total as u32
    }
}

fn bench_cpu(iters: u32) -> (f64, f64) {
    // Compute sum of square roots — proxy for FLOPS
    let mut total_ms = 0.0;
    let mut total_ops = 0u64;
    let mut result: f64 = 0.0;
    for _ in 0..iters {
        let start = Instant::now();
        let n = 5_000_000u64;
        let mut acc = 0.0f64;
        for i in 1..=n {
            acc += (i as f64).sqrt();
        }
        result = acc;
        let dur = start.elapsed().as_secs_f64() * 1000.0;
        total_ms += dur;
        total_ops += n;
    }
    let avg_ms = total_ms / iters as f64;
    // GFLOPS ≈ ops / time(s) / 1e9 (sqrt ~ 1 op)
    let gflops = (total_ops as f64 / (total_ms / 1000.0)) / 1e9;
    // Avoid unused warning
    let _ = result;
    (gflops, avg_ms)
}

fn bench_memory(iters: u32) -> (f64, f64) {
    let size = 64 * 1024 * 1024; // 64 MB
    let mut buf = vec![0u8; size];
    let mut total_ms = 0.0;
    let mut total_bytes = 0u64;
    for _ in 0..iters {
        let start = Instant::now();
        // Sequential write + read
        for chunk in buf.chunks_mut(4096) {
            for b in chunk.iter_mut() { *b = 0xAA; }
        }
        let mut acc = 0u8;
        for chunk in buf.chunks(4096) {
            for b in chunk { acc = acc.wrapping_add(*b); }
        }
        let dur = start.elapsed().as_secs_f64() * 1000.0;
        total_ms += dur;
        total_bytes += (size * 2) as u64; // write + read
        let _ = acc;
    }
    let avg_ms = total_ms / iters as f64;
    let gbps = (total_bytes as f64 / (total_ms / 1000.0)) / (1024.0 * 1024.0 * 1024.0);
    (gbps, avg_ms)
}

fn bench_disk(iters: u32) -> (f64, f64) {
    let path = "/tmp/nexus-bench.tmp";
    let size: u64 = 100 * 1024 * 1024; // 100 MB
    let mut seq_total: f64 = 0.0;
    let mut rand_total: f64 = 0.0;
    for _ in 0..iters {
        // Sequential write
        let start = Instant::now();
        if let Ok(mut f) = fs::File::create(path) {
            use std::io::Write;
            let chunk = vec![0xCD; 1024 * 1024];
            for _ in 0..(size / chunk.len() as u64) {
                let _ = f.write_all(&chunk);
            }
            let _ = f.sync_all();
            let dur = start.elapsed().as_secs_f64();
            seq_total += (size as f64 / dur) / (1024.0 * 1024.0); // MB/s
        }
        // Random read
        let start = Instant::now();
        if let Ok(f) = fs::File::open(path) {
            use std::io::{Read, Seek, SeekFrom};
            let mut buf = [0u8; 4096];
            let mut rng_state: u64 = 12345;
            let iterations = 1000;
            for _ in 0..iterations {
                rng_state ^= rng_state << 13;
                rng_state ^= rng_state >> 7;
                rng_state ^= rng_state << 17;
                let offset = (rng_state % (size - 4096)) as i64;
                let mut f2 = f.try_clone().unwrap();
                let _ = f2.seek(SeekFrom::Start(offset as u64));
                let _ = f2.read(&mut buf);
            }
            let _ = buf;
            let dur = start.elapsed().as_secs_f64();
            rand_total += ((iterations as f64 * 4096.0) / dur) / (1024.0 * 1024.0);
        }
        let _ = fs::remove_file(path);
    }
    let seq_avg = seq_total / iters as f64;
    let rand_avg = rand_total / iters as f64;
    (seq_avg, rand_avg)
}

fn bench_network() -> f64 {
    // Ping 1.1.1.1 — 5 pings, take avg
    let out = Command::new("ping")
        .args(["-c", "5", "-W", "2", "1.1.1.1"])
        .output()
        .map(|o| String::from_utf8_lossy(&o.stdout).to_string())
        .unwrap_or_default();
    // Parse "min/avg/max = X/Y/Z ms"
    if let Some(idx) = out.find("= ") {
        let after = &out[idx + 2..];
        if let Some(end) = after.find(" ms") {
            let parts: Vec<&str> = after[..end].split('/').collect();
            if parts.len() >= 2 {
                return parts[1].parse::<f64>().unwrap_or(999.0);
            }
        }
    }
    999.0
}

pub fn run_all(opts: &BenchmarkOptions) -> BenchmarkResults {
    let mut cpu_gflops = 0.0;
    let mut cpu_ms = 0.0;
    let mut mem_gbps = 0.0;
    let mut mem_ms = 0.0;
    let mut disk_seq = 0.0;
    let mut disk_rand = 0.0;
    let mut net_ping = 0.0;

    if opts.cpu {
        let (g, m) = bench_cpu(opts.iterations);
        cpu_gflops = g;
        cpu_ms = m;
    }
    if opts.memory {
        let (g, m) = bench_memory(opts.iterations);
        mem_gbps = g;
        mem_ms = m;
    }
    if opts.disk {
        let (s, r) = bench_disk(opts.iterations);
        disk_seq = s;
        disk_rand = r;
    }
    if opts.network {
        net_ping = bench_network();
    }

    let mut results = BenchmarkResults {
        cpu_gflops,
        cpu_ms_per_op: cpu_ms,
        mem_gbps,
        mem_ms,
        disk_seq_mbps: disk_seq,
        disk_rand_mbps: disk_rand,
        net_ping_ms: net_ping,
        ferrari_score_val: 0,
    };
    results.ferrari_score_val = results.ferrari_score();

    if opts.save_results {
        let home = std::env::var("HOME").unwrap_or_else(|_| "/tmp".to_string());
        let dir = format!("{}/nexus-doctor", home);
        let _ = fs::create_dir_all(&dir);
        let path = format!("{}/benchmarks.json", dir);
        let json = format!(
            r#"{{"cpu_gflops":{:.3},"cpu_ms":{:.2},"mem_gbps":{:.3},"mem_ms":{:.2},"disk_seq_mbps":{:.2},"disk_rand_mbps":{:.2},"net_ping_ms":{:.1},"ferrari_score":{}}}"#,
            cpu_gflops, cpu_ms, mem_gbps, mem_ms, disk_seq, disk_rand, net_ping, results.ferrari_score_val
        );
        let _ = fs::write(&path, json);
    }

    results
}

// Avoid unused warnings for Duration
#[allow(dead_code)]
fn _unused() -> Duration { Duration::from_secs(0) }
