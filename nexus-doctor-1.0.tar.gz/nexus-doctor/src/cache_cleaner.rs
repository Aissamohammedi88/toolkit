// ════════════════════════════════════════════════════════════════════════════
// NEXUS-DOCTOR — Module cache_cleaner.rs
// Vide 40% du cache intelligemment (pas tout, garde le système stable)
// ════════════════════════════════════════════════════════════════════════════
use std::fs;
use std::os::unix::fs::MetadataExt;
use std::path::Path;
use std::process::Command;
use std::time::Instant;

pub struct ClearedItem {
    pub path: String,
    pub size_mb: u64,
}

pub struct CleanReport {
    pub cache_before_mb: u64,
    pub target_to_clear_mb: u64,
    pub cache_after_mb: u64,
    pub total_cleared_mb: u64,
    pub percent_cleared: f64,
    pub cleared_items: Vec<ClearedItem>,
}

fn dir_size_mb(path: &Path) -> u64 {
    if !path.exists() {
        return 0;
    }
    let mut total: u64 = 0;
    let walker = walkdir_simple(path, 5);
    for p in walker {
        if let Ok(meta) = fs::metadata(&p) {
            if meta.is_file() {
                total += meta.size();
            }
        }
    }
    total / (1024 * 1024)
}

fn walkdir_simple(root: &Path, max_depth: usize) -> Vec<String> {
    let mut out = Vec::new();
    let mut current = vec![root.to_string_lossy().to_string()];
    for _ in 0..max_depth {
        let mut next = Vec::new();
        for d in &current {
            if let Ok(entries) = fs::read_dir(d) {
                for entry in entries.flatten() {
                    let p = entry.path();
                    let s = p.to_string_lossy().to_string();
                    if let Ok(meta) = entry.metadata() {
                        if meta.is_file() {
                            out.push(s);
                        } else if meta.is_dir() {
                            next.push(s);
                        }
                    }
                }
            }
        }
        current = next;
    }
    out
}

fn get_cache_size_mb() -> u64 {
    // Cache kernel (page cache) — approx via MemTotal - MemFree - MemAvailable
    let meminfo = fs::read_to_string("/proc/meminfo").unwrap_or_default();
    let mut total: u64 = 0;
    let mut avail: u64 = 0;
    let mut free: u64 = 0;
    let mut buffers: u64 = 0;
    let mut cached: u64 = 0;
    let mut sreclaimable: u64 = 0;
    for line in meminfo.lines() {
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() < 2 { continue; }
        let key = parts[0].trim_end_matches(':');
        let val = parts[1].parse::<u64>().unwrap_or(0);
        match key {
            "MemTotal" => total = val,
            "MemAvailable" => avail = val,
            "MemFree" => free = val,
            "Buffers" => buffers = val,
            "Cached" => cached = val,
            "SReclaimable" => sreclaimable = val,
            _ => {}
        }
    }
    // Page cache = Buffers + Cached + SReclaimable (en kB)
    (buffers + cached + sreclaimable) / 1024
}

fn get_user_cache_dirs() -> Vec<(String, u64)> {
    let home = std::env::var("HOME").unwrap_or_else(|_| "/tmp".to_string());
    let candidates = vec![
        format!("{}/.cache", home),
        format!("{}/.local/share/Trash/files", home),
        format!("{}/.local/share/Trash/expunged", home),
        "/tmp".to_string(),
        "/var/tmp".to_string(),
    ];
    let mut dirs = Vec::new();
    for c in candidates {
        let p = Path::new(&c);
        if p.exists() {
            let size = dir_size_mb(p);
            if size > 0 {
                dirs.push((c, size));
            }
        }
    }
    dirs.sort_by(|a, b| b.1.cmp(&a.1));
    dirs
}

pub fn clean_40_percent() -> CleanReport {
    let start = Instant::now();
    let cache_before = get_cache_size_mb();
    let target = cache_before * 40 / 100;
    let mut cleared_items: Vec<ClearedItem> = Vec::new();
    let mut total_cleared: u64 = 0;

    // 1. User cache dirs (clear eligible subdirs proportionally)
    let user_dirs = get_user_cache_dirs();
    for (dir, size) in &user_dirs {
        if total_cleared >= target { break; }
        let remaining = target.saturating_sub(total_cleared);
        let to_clear = (*size).min(remaining);
        let cleared = clear_dir_proportionally(dir, to_clear);
        if cleared > 0 {
            cleared_items.push(ClearedItem {
                path: dir.clone(),
                size_mb: cleared,
            });
            total_cleared += cleared;
        }
    }

    // 2. Try kernel drop_caches (page cache 1 = pages only — safest)
    // User-space only here. The "full" drop_caches needs sudo — left to booster.rs
    // For 40% kernel cache: not directly possible (drop_caches is all-or-nothing).
    // We do a sync instead.
    let _ = Command::new("sync").spawn();

    let cache_after = get_cache_size_mb();
    let percent = if cache_before > 0 {
        (total_cleared as f64 / cache_before as f64) * 100.0
    } else { 0.0 };

    CleanReport {
        cache_before_mb: cache_before,
        target_to_clear_mb: target,
        cache_after_mb: cache_after,
        total_cleared_mb: total_cleared,
        percent_cleared: percent,
        cleared_items,
    }
}

fn clear_dir_proportionally(dir: &str, target_mb: u64) -> u64 {
    if target_mb == 0 { return 0; }
    let p = Path::new(dir);
    // Strategy: list subdirs/entries by size, clear the biggest ones until target reached
    let mut entries: Vec<(String, u64)> = Vec::new();
    if let Ok(rd) = fs::read_dir(p) {
        for entry in rd.flatten() {
            let path = entry.path();
            let s = path.to_string_lossy().to_string();
            let size = if let Ok(m) = entry.metadata() {
                if m.is_dir() {
                    dir_size_mb(&path)
                } else {
                    m.size() / (1024 * 1024)
                }
            } else { 0 };
            if size > 0 {
                entries.push((s, size));
            }
        }
    }
    entries.sort_by(|a, b| b.1.cmp(&a.1));

    let mut cleared: u64 = 0;
    for (path, size) in entries {
        if cleared >= target_mb { break; }
        let _ = fs::remove_dir_all(&path).or_else(|_| fs::remove_file(&path));
        cleared += size;
    }
    cleared
}
