#!/usr/bin/env ruby
# ════════════════════════════════════════════════════════════════════════════
# NEXUS-DOCTOR — report_generator.rb (Ruby, 3% of project)
# Génère un "rapport médical" HTML depuis les findings JSON
# Lancé par : ruby report_generator.rb <findings.json> <output.html>
# Sans dépendance externe : parseur JSON pur Ruby intégré
# ════════════════════════════════════════════════════════════════════════════

# Time est built-in core Ruby — pas besoin de require 'time'

# ─── Mini parseur JSON pur Ruby (pas de require 'json') ─────────────────────
module MiniJSON
  class Parser
    def initialize(str)
      @str = str
      @pos = 0
    end

    def parse
      skip_ws
      v = parse_value
      skip_ws
      v
    end

    private

    def skip_ws
      while @pos < @str.length && " \t\n\r".include?(@str[@pos])
        @pos += 1
      end
    end

    def parse_value
      skip_ws
      c = @str[@pos]
      case c
      when '{' then parse_object
      when '[' then parse_array
      when '"' then parse_string
      when 't' then consume('true'); true
      when 'f' then consume('false'); false
      when 'n' then consume('null'); nil
      else parse_number
      end
    end

    def parse_object
      @pos += 1 # skip {
      obj = {}
      skip_ws
      if @str[@pos] == '}'
        @pos += 1
        return obj
      end
      loop do
        skip_ws
        key = parse_string
        skip_ws
        @pos += 1 if @str[@pos] == ':' # skip :
        val = parse_value
        obj[key] = val
        skip_ws
        if @str[@pos] == ','
          @pos += 1
        elsif @str[@pos] == '}'
          @pos += 1
          break
        end
      end
      obj
    end

    def parse_array
      @pos += 1 # skip [
      arr = []
      skip_ws
      if @str[@pos] == ']'
        @pos += 1
        return arr
      end
      loop do
        arr << parse_value
        skip_ws
        if @str[@pos] == ','
          @pos += 1
        elsif @str[@pos] == ']'
          @pos += 1
          break
        end
      end
      arr
    end

    def parse_string
      @pos += 1 # skip opening "
      result = ''
      while @pos < @str.length
        c = @str[@pos]
        if c == '\\'
          @pos += 1
          e = @str[@pos]
          result << case e
                    when '"' then '"'
                    when '\\' then '\\'
                    when '/' then '/'
                    when 'b' then "\b"
                    when 'f' then "\f"
                    when 'n' then "\n"
                    when 'r' then "\r"
                    when 't' then "\t"
                    when 'u'
                      hex = @str[(@pos + 1)..(@pos + 4)]
                      @pos += 4
                      [hex.hex].pack('U')
                    else e
                    end
          @pos += 1
        elsif c == '"'
          @pos += 1
          break
        else
          result << c
          @pos += 1
        end
      end
      result
    end

    def parse_number
      start = @pos
      @pos += 1 while @pos < @str.length && /[0-9eE+\-.]/.match?(@str[@pos])
      s = @str[start...@pos]
      s.include?('.') || s.downcase.include?('e') ? s.to_f : s.to_i
    end

    def consume(word)
      @pos += word.length
    end
  end

  def self.parse(str)
    Parser.new(str).parse
  end
end

# ─── Helpers ────────────────────────────────────────────────────────────────
def read_json(path)
  return { 'findings' => [] } unless File.exist?(path)
  data = MiniJSON.parse(File.read(path))
  data.is_a?(Hash) ? data : { 'findings' => [] }
rescue => e
  warn "[NEXUS-DOCTOR Ruby] JSON parse error: #{e.message}"
  { 'findings' => [] }
end

def html_escape(s)
  s.to_s.gsub('&', '&amp;').gsub('<', '&lt;').gsub('>', '&gt;')
        .gsub('"', '&quot;').gsub("'", '&#39;')
end

def severity_icon(sev)
  case sev
  when 'critical' then { icon: '🔴', color: '#dc3545', bg: '#f8d7da' }
  when 'high'     then { icon: '🟠', color: '#fd7e14', bg: '#fff3cd' }
  when 'medium'   then { icon: '🟡', color: '#ffc107', bg: '#fff9e6' }
  when 'low'      then { icon: '🔵', color: '#17a2b8', bg: '#e0f7fa' }
  else                 { icon: '🟢', color: '#28a745', bg: '#d4edda' }
  end
end

def count_by_severity(findings)
  counts = { 'critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0, 'info' => 0 }
  findings.each { |f| counts[f['severity']] = counts[f['severity']].to_i + 1 if counts.key?(f['severity']) }
  counts
end

def patient_info
  hostname = `hostname`.strip
  kernel = `uname -r`.strip
  arch = `uname -m`.strip
  distro = File.exist?('/etc/os-release') ? File.read('/etc/os-release').scan(/PRETTY_NAME="([^"]+)"/).flatten.first : 'Linux'
  uptime = `uptime -p 2>/dev/null || uptime`.strip.gsub(/^up\s+/, '')
  {
    hostname: hostname, kernel: kernel, arch: arch,
    distro: distro, uptime: uptime,
    date: Time.now.strftime('%Y-%m-%d %H:%M:%S'),
  }
end

def html_template(patient, findings, counts)
  total = findings.length
  findings_html = findings.map do |f|
    s = severity_icon(f['severity'])
    tech_html = f['technical'] && !f['technical'].empty? ?
      "<div class=\"tech\"><strong>Analyse technique :</strong> #{f['technical']}</div>" : ''
    simple_html = f['simple'] && !f['simple'].empty? ?
      "<div class=\"simple\"><strong>Explication simple :</strong> #{f['simple']}</div>" : ''
    rec_html = f['recommendation'] && !f['recommendation'].empty? ?
      "<div class=\"rec\"><strong>Prescription :</strong> #{f['recommendation']}</div>" : ''
    <<-HTML
    <div class="finding" style="border-left:4px solid #{s[:color]}; background:#{s[:bg]};">
      <div class="head">
        <span class="icon">#{s[:icon]}</span>
        <span class="cat">[#{f['category']}]</span>
        <strong>#{f['title']}</strong>
      </div>
      #{tech_html}
      #{simple_html}
      #{rec_html}
    </div>
    HTML
  end.join("\n")

  verdict = if counts['critical'] > 0
    "<strong style='color:#dc3545'>PATIENT EN DANGER IMMÉDIAT</strong> — intervention requise"
  elsif counts['high'] > 0
    "<strong style='color:#fd7e14'>PATIENT SOUS SURVEILLANCE</strong> — anomalies détectées"
  elsif counts['medium'] > 0
    "<strong style='color:#ffc107'>PATIENT STABLE AVEC ANOMALIES MINEURES</strong>"
  else
    "<strong style='color:#28a745'>PATIENT EN BONNE SANTÉ</strong> — système nominal"
  end

  <<-HTML
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Rapport médical NEXUS-DOCTOR — #{patient[:hostname]}</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: -apple-system, 'Segoe UI', system-ui, sans-serif;
  background: #f5f5f7; color: #1d1d1f; padding: 32px;
  background-image: radial-gradient(circle at 10% 10%, rgba(88,166,255,0.05) 0%, transparent 50%),
                    radial-gradient(circle at 90% 90%, rgba(188,140,255,0.05) 0%, transparent 50%);
  min-height: 100vh;
}
.container { max-width: 900px; margin: 0 auto; background: white; padding: 48px; border-radius: 16px; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
header { border-bottom: 2px solid #0066cc; padding-bottom: 24px; margin-bottom: 32px; }
h1 { color: #0066cc; font-size: 32px; font-weight: 800; }
.subtitle { color: #6e7681; font-size: 14px; margin-top: 8px; }
.patient-info { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 32px; background: #f0f4ff; padding: 24px; border-radius: 12px; }
.patient-info > div { font-size: 14px; }
.patient-info strong { color: #0066cc; display: inline-block; min-width: 100px; }
.summary { display: flex; gap: 12px; margin-bottom: 32px; flex-wrap: wrap; }
.summary-card { flex: 1; min-width: 100px; padding: 16px; border-radius: 8px; text-align: center; color: white; }
.summary-card .num { font-size: 28px; font-weight: 800; }
.summary-card .lbl { font-size: 11px; opacity: 0.9; text-transform: uppercase; letter-spacing: 0.1em; }
.verdict { background: linear-gradient(135deg, #fff9e6, #f0f4ff); padding: 24px; border-radius: 12px; margin-bottom: 32px; text-align: center; font-size: 18px; }
h2 { color: #0066cc; font-size: 20px; margin: 32px 0 16px; padding-bottom: 8px; border-bottom: 1px solid #e1e4e8; }
.finding { border-left: 4px solid; padding: 16px 20px; margin: 12px 0; border-radius: 4px; }
.finding .head { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; font-size: 15px; }
.finding .head .icon { font-size: 18px; }
.finding .head .cat { color: #6e7681; font-family: 'SF Mono', monospace; font-size: 12px; }
.finding .tech, .finding .simple, .finding .rec { font-size: 13px; margin: 6px 0; color: #444; line-height: 1.6; }
.finding .tech { background: rgba(0,0,0,0.03); padding: 8px 12px; border-radius: 4px; font-family: 'SF Mono', monospace; }
.finding .rec { background: rgba(0,102,204,0.05); padding: 8px 12px; border-radius: 4px; border-left: 2px solid #0066cc; }
footer { margin-top: 48px; padding-top: 24px; border-top: 1px solid #e1e4e8; text-align: center; color: #6e7681; font-size: 12px; }
.doctor-sig { font-family: cursive, 'Brush Script MT'; font-size: 24px; color: #0066cc; margin-top: 16px; }
</style>
</head>
<body>
<div class="container">
  <header>
    <h1>🔬 Rapport médical NEXUS-DOCTOR</h1>
    <div class="subtitle">Examen complet du système · #{patient[:date]}</div>
  </header>

  <div class="patient-info">
    <div><strong>Patient :</strong> #{patient[:hostname]}</div>
    <div><strong>Distro :</strong> #{patient[:distro]}</div>
    <div><strong>Kernel :</strong> #{patient[:kernel]}</div>
    <div><strong>Arch :</strong> #{patient[:arch]}</div>
    <div><strong>Uptime :</strong> #{patient[:uptime]}</div>
    <div><strong>Date exam :</strong> #{patient[:date]}</div>
  </div>

  <div class="summary">
    <div class="summary-card" style="background:#dc3545;"><div class="num">#{counts['critical']}</div><div class="lbl">Critical</div></div>
    <div class="summary-card" style="background:#fd7e14;"><div class="num">#{counts['high']}</div><div class="lbl">High</div></div>
    <div class="summary-card" style="background:#ffc107;color:#000;"><div class="num">#{counts['medium']}</div><div class="lbl">Medium</div></div>
    <div class="summary-card" style="background:#17a2b8;"><div class="num">#{counts['low']}</div><div class="lbl">Low</div></div>
    <div class="summary-card" style="background:#28a745;"><div class="num">#{counts['info']}</div><div class="lbl">Info</div></div>
    <div class="summary-card" style="background:#6e7681;"><div class="num">#{total}</div><div class="lbl">Total</div></div>
  </div>

  <div class="verdict">VERDICT : #{verdict}</div>

  <h2>📊 Diagnostics détaillés</h2>
  #{findings_html}

  <footer>
    Rapport généré par NEXUS-DOCTOR v1.0 — report_generator.rb<br>
    Aissa Mohammedi (DGK) — Nexus Quantum<br>
    <div class="doctor-sig">Dr. NEXUS</div>
  </footer>
</div>
</body>
</html>
  HTML
end

# ─── Main ───────────────────────────────────────────────────────────────────
if ARGV.length < 2
  warn "Usage: ruby report_generator.rb <findings.json> <output.html>"
  exit 1
end

json_path = ARGV[0]
output_path = ARGV[1]

data = read_json(json_path)
findings = data['findings'] || []
counts = count_by_severity(findings)
patient = patient_info

html = html_template(patient, findings, counts)
File.write(output_path, html)
puts "[NEXUS-DOCTOR Ruby] Rapport généré : #{output_path}"
puts "[NEXUS-DOCTOR Ruby] #{findings.length} findings traités"
puts "[NEXUS-DOCTOR Ruby] Patient : #{patient[:hostname]} — #{counts['critical']} critical, #{counts['high']} high"
