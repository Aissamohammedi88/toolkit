// ════════════════════════════════════════════════════════════════════════════
// NEXUS-DOCTOR — Module doctor.rs (diagnostics techniques)
// Le docteur explique en mode technique ce que le PC avait
// ════════════════════════════════════════════════════════════════════════════
use std::collections::HashMap;
use std::fs;
use std::process::Command;

pub struct Finding {
    pub category: String,
    pub severity: String, // critical / high / medium / low / info
    pub title: String,
    pub technical: String,    // explication technique détaillée
    pub simple: String,       // explication simple
    pub recommendation: String,
}

impl Finding {
    pub fn print(&self, technical_mode: bool) {
        let icon = match self.severity.as_str() {
            "critical" => "🔴",
            "high"     => "🟠",
            "medium"   => "🟡",
            "low"      => "🔵",
            _          => "🟢",
        };
        let color = match self.severity.as_str() {
            "critical" => "\x1b[31m",
            "high"     => "\x1b[31m",
            "medium"   => "\x1b[33m",
            "low"      => "\x1b[36m",
            _          => "\x1b[32m",
        };
        println!("  {} [{}] {}\x1b[0m \x1b[1m{}\x1b[0m",
                 icon, self.category, color, self.title);
        if technical_mode {
            println!("       \x1b[2mtechnique:\x1b[0m {}", self.technical);
        } else {
            println!("       \x1b[2mexplication:\x1b[0m {}", self.simple);
        }
        if !self.recommendation.is_empty() {
            println!("       \x1b[36mrecommandation:\x1b[0m {}", self.recommendation);
        }
    }
}

pub fn findings_to_json(findings: &[Finding]) -> String {
    let mut s = String::from("{\"findings\":[");
    for (i, f) in findings.iter().enumerate() {
        if i > 0 { s.push(','); }
        s.push_str(&format!(
            "{{\"category\":\"{}\",\"severity\":\"{}\",\"title\":\"{}\",\"technical\":\"{}\",\"simple\":\"{}\",\"recommendation\":\"{}\"}}",
            esc(&f.category), esc(&f.severity), esc(&f.title),
            esc(&f.technical), esc(&f.simple), esc(&f.recommendation)
        ));
    }
    s.push_str("]}");
    s
}

fn esc(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"")
}

fn read_file(path: &str) -> String {
    fs::read_to_string(path).unwrap_or_default()
}

fn run_cmd(args: &[&str]) -> String {
    Command::new(args[0])
        .args(&args[1..])
        .output()
        .map(|o| String::from_utf8_lossy(&o.stdout).to_string())
        .unwrap_or_default()
}

// ─── 1. CPU ──────────────────────────────────────────────────────────────
pub fn check_cpu() -> Vec<Finding> {
    let mut out = Vec::new();
    let model = read_file("/proc/cpuinfo")
        .lines()
        .find(|l| l.starts_with("model name"))
        .and_then(|l| l.split(':').nth(1))
        .map(|s| s.trim().to_string())
        .unwrap_or_else(|| "inconnu".to_string());
    let cores = read_file("/proc/cpuinfo").matches("processor").count();

    out.push(Finding {
        category: "CPU".into(),
        severity: "info".into(),
        title: format!("{} ({} cœurs)", model, cores),
        technical: format!("Architecture x86_64, {} cœurs logiques détectés via /proc/cpuinfo.", cores),
        simple: format!("Votre processeur a {} cœurs.", cores),
        recommendation: "".into(),
    });

    // Governor
    let gov_path = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor";
    let gov = read_file(gov_path).trim().to_string();
    if !gov.is_empty() {
        let (sev, rec) = match gov.as_str() {
            "performance" => ("info", "Gouvernor déjà en performance — optimal."),
            "powersave" | "schedutil" => ("medium", "Passer en performance pour max FPS : echo performance | sudo tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor"),
            _ => ("low", "Vérifier le governor."),
        };
        out.push(Finding {
            category: "CPU".into(),
            severity: sev.into(),
            title: format!("Governor : {}", gov),
            technical: format!("cpufreq scaling_governor = {} — détermine la politique de fréquence. performance = toujours max, powersave = min, schedutil = adaptatif.", gov),
            simple: format!("Le mode de gestion d'énergie du CPU est '{}'.", gov),
            recommendation: rec.into(),
        });
    }

    // Thermal
    let temp_paths = [
        "/sys/class/thermal/thermal_zone0/temp",
        "/sys/class/hwmon/hwmon0/temp1_input",
    ];
    for tp in temp_paths {
        if let Ok(t) = fs::read_to_string(tp) {
            if let Ok(milli) = t.trim().parse::<i32>() {
                let c = milli / 1000;
                let (sev, rec) = match c {
                    t if t > 90 => ("critical", "ARRÊT IMMINENT — vérifier refroidissement (ventilo, pâte thermique)."),
                    t if t > 80 => ("high", "Température élevée — nettoyer ventilateurs, surveiller charge."),
                    t if t > 70 => ("medium", "Légèrement chaud — normal en charge."),
                    _ => ("info", "Température nominale."),
                };
                out.push(Finding {
                    category: "CPU".into(),
                    severity: sev.into(),
                    title: format!("Température CPU : {}°C", c),
                    technical: format!("Lecture {} — valeur en millidegrés Celsius. Le kernel expose thermal_zone pour monitoring.", tp),
                    simple: format!("Le CPU est à {}°C.", c),
                    recommendation: rec.into(),
                });
                break;
            }
        }
    }
    out
}

// ─── 2. Mémoire ──────────────────────────────────────────────────────────
pub fn check_memory() -> Vec<Finding> {
    let mut out = Vec::new();
    let meminfo = read_file("/proc/meminfo");
    let mut map: HashMap<String, u64> = HashMap::new();
    for line in meminfo.lines() {
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() >= 2 {
            let key = parts[0].trim_end_matches(':').to_string();
            if let Ok(v) = parts[1].parse::<u64>() {
                map.insert(key, v);
            }
        }
    }
    let total = *map.get("MemTotal").unwrap_or(&0);
    let avail = *map.get("MemAvailable").unwrap_or(&0);
    let used = total.saturating_sub(avail);
    let pct = if total > 0 { (used * 100 / total) as u8 } else { 0 };
    let total_gb = total as f64 / 1024.0 / 1024.0;
    let used_gb = used as f64 / 1024.0 / 1024.0;
    out.push(Finding {
        category: "MEM".into(),
        severity: if pct > 90 { "high" } else if pct > 75 { "medium" } else { "info" }.into(),
        title: format!("RAM : {:.1}/{:.1} GB ({}%)", used_gb, total_gb, pct),
        technical: format!("/proc/meminfo MemTotal={} kB, MemAvailable={} kB. Utilisation réelle = Total - Available (inclut cache reclaimable).", total, avail),
        simple: format!("Vous utilisez {}% de votre mémoire.", pct),
        recommendation: if pct > 85 { "Fermer les apps gourmandes ou ajouter de la RAM." } else { "" }.into(),
    });

    // Swap
    let swap_total = *map.get("SwapTotal").unwrap_or(&0);
    let swap_free = *map.get("SwapFree").unwrap_or(&0);
    if swap_total > 0 {
        let swap_used = swap_total - swap_free;
        let pct = (swap_used * 100 / swap_total) as u8;
        out.push(Finding {
            category: "MEM".into(),
            severity: if pct > 50 { "medium" } else { "low" }.into(),
            title: format!("Swap : {} MB utilisés ({}%)", swap_used / 1024, pct),
            technical: format!("vm.swappiness contrôle l'usage. Valeur par défaut 60 — recommandé 10 pour desktop avec RAM suffisante."),
            simple: format!("{}% du swap est utilisé.", pct),
            recommendation: if pct > 30 { "sudo sysctl vm.swappiness=10" } else { "" }.into(),
        });
    }

    // swappiness actuel
    let swappiness = read_file("/proc/sys/vm/swappiness").trim().to_string();
    if !swappiness.is_empty() {
        let sev = match swappiness.as_str() {
            "10" | "20" => "info",
            "60" => "low",
            _ if swappiness.parse::<u8>().unwrap_or(60) > 60 => "medium",
            _ => "info",
        };
        out.push(Finding {
            category: "MEM".into(),
            severity: sev.into(),
            title: format!("vm.swappiness = {}", swappiness),
            technical: "Plus la valeur est haute, plus le kernel swap tôt. Desktop = 10-20 idéal, serveur = 60.".into(),
            simple: "Contrôle quand le système utilise le swap.".into(),
            recommendation: "sudo sysctl vm.swappiness=10".into(),
        });
    }
    out
}

// ─── 3. Disque ──────────────────────────────────────────────────────────
pub fn check_disk() -> Vec<Finding> {
    let mut out = Vec::new();
    // df
    let df = run_cmd(&["df", "-h", "--type=ext4", "--type=btrfs", "--type=xfs", "--type=f2fs", "--type=ntfs"]);
    for line in df.lines().skip(1) {
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() >= 6 {
            let dev = parts[0];
            let size = parts[1];
            let used = parts[2];
            let avail = parts[3];
            let pct = parts[4].trim_end_matches('%');
            let mount = parts[5];
            let sev = match pct.parse::<u8>().unwrap_or(0) {
                p if p > 95 => "critical",
                p if p > 85 => "high",
                p if p > 70 => "medium",
                _ => "info",
            };
            out.push(Finding {
                category: "DISK".into(),
                severity: sev.into(),
                title: format!("{} {} ({}/{}, {}%)", mount, size, used, avail, pct),
                technical: format!("{} mounted on {} — block device utilization.", dev, mount),
                simple: format!("Partition {} : {}% utilisée.", mount, pct),
                recommendation: if sev != "info" { "Nettoyer gros fichiers ou vider corbeille." } else { "" }.into(),
            });
        }
    }

    // IO scheduler
    let sched_path = "/sys/block/sda/queue/scheduler";
    if let Ok(s) = fs::read_to_string(sched_path) {
        let active = s.trim();
        out.push(Finding {
            category: "DISK".into(),
            severity: "low".into(),
            title: format!("IO scheduler : {}", active),
            technical: "none/mq-deadline/kyber/bfq — none optimal pour SSD NVMe, bfq pour HDD/interactif.".into(),
            simple: "L'algorithme d'ordonnancement des accès disque.".into(),
            recommendation: "Pour SSD NVMe : echo none | sudo tee /sys/block/sdX/queue/scheduler".into(),
        });
    }
    out
}

// ─── 4. Filesystem ────────────────────────────────────────────────────────
pub fn check_filesystem() -> Vec<Finding> {
    let mut out = Vec::new();
    let mounts = read_file("/proc/mounts");
    let mut ext_count = 0;
    let mut ro_count = 0;
    for line in mounts.lines() {
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() < 4 { continue; }
        let dev = parts[0];
        let mount = parts[1];
        let fstype = parts[2];
        let opts = parts[3];
        if fstype.starts_with("ext") || fstype == "btrfs" || fstype == "xfs" {
            ext_count += 1;
            if opts.contains("ro") {
                ro_count += 1;
                out.push(Finding {
                    category: "FS".into(),
                    severity: "high".into(),
                    title: format!("{} monté en READ-ONLY", mount),
                    technical: format!("Options de mount : {} — ro indique probablement une erreur FS, le kernel a basculé en read-only pour protection.", opts),
                    simple: format!("La partition {} est en lecture seule — souvent signe d'erreur disque.", mount),
                    recommendation: "fsck /dev/... puis remount rw".into(),
                });
            }
        }
        let _ = dev;
    }
    out.push(Finding {
        category: "FS".into(),
        severity: "info".into(),
        title: format!("{} partitions montées ({} en read-only)", ext_count, ro_count),
        technical: "/proc/mounts liste tous les mount points — surveiller les ro qui indiquent corruption.".into(),
        simple: format!("{} partitions accessibles.", ext_count),
        recommendation: "".into(),
    });
    out
}

// ─── 5. Réseau ──────────────────────────────────────────────────────────
pub fn check_network() -> Vec<Finding> {
    let mut out = Vec::new();
    // DNS resolution test
    let dns_ok = Command::new("getent")
        .args(["hosts", "google.com"])
        .output()
        .map(|o| o.status.success())
        .unwrap_or(false);
    out.push(Finding {
        category: "NET".into(),
        severity: if dns_ok { "info" } else { "high" }.into(),
        title: format!("DNS : {}", if dns_ok { "OK (résolution google.com)" } else { "ÉCHEC résolution DNS" }),
        technical: "getent hosts utilise nsswitch — teste la résolution via /etc/resolv.conf et systemd-resolved.".into(),
        simple: if dns_ok { "Internet fonctionne." } else { "Problème DNS — pas d'internet." }.into(),
        recommendation: if !dns_ok { "Vérifier /etc/resolv.conf — nameserver 1.1.1.1" } else { "" }.into(),
    });

    // Interfaces
    let ip_addr = run_cmd(&["ip", "-br", "addr"]);
    for line in ip_addr.lines() {
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() >= 3 && parts[2] != "DOWN" {
            out.push(Finding {
                category: "NET".into(),
                severity: "info".into(),
                title: format!("{} UP — {}", parts[0], parts[2]),
                technical: format!("ip -br addr — interface {} state UP with address {}.", parts[0], parts[2]),
                simple: format!("Interface {} active.", parts[0]),
                recommendation: "".into(),
            });
        }
    }
    out
}

// ─── 6. Processus ────────────────────────────────────────────────────────
pub fn check_processes() -> Vec<Finding> {
    let mut out = Vec::new();
    let ps = run_cmd(&["ps", "aux", "--sort=-%cpu"]);
    let mut top: Vec<&str> = ps.lines().skip(1).take(5).collect();
    for line in &top {
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() < 11 { continue; }
        let cpu: f32 = parts[2].parse().unwrap_or(0.0);
        let mem: f32 = parts[3].parse().unwrap_or(0.0);
        let cmd = parts[10..].join(" ");
        if cpu > 50.0 {
            out.push(Finding {
                category: "PROC".into(),
                severity: if cpu > 90.0 { "high" } else { "medium" }.into(),
                title: format!("{} — CPU {:.0}% MEM {:.0}%", cmd, cpu, mem),
                technical: format!("PID {} — consommation CPU anormale. ps(1) stats depuis /proc/[pid]/stat.", parts[1]),
                simple: format!("Le processus {} consomme beaucoup de CPU.", cmd),
                recommendation: format!("Si légitime, ignorer. Sinon : kill {} ou pkill -f {}", parts[1], parts[10]),
            });
        }
    }
    // Zombies
    let zombies = run_cmd(&["ps", "aux"]).lines()
        .filter(|l| l.contains(" Z ") || l.contains("<defunct>"))
        .count();
    if zombies > 0 {
        out.push(Finding {
            category: "PROC".into(),
            severity: "low".into(),
            title: format!("{} processus zombie(s)", zombies),
            technical: "Zombie = processus terminé dont le parent n'a pas appelé wait(). Pas consommateur de RAM, mais occupe un PID.".into(),
            simple: format!("{} processus zombie(s) — pas dangereux mais à nettoyer.", zombies),
            recommendation: "kill -9 PPID du zombie".into(),
        });
    }
    let _ = &mut top;
    out
}

// ─── 7. Logs kernel ──────────────────────────────────────────────────────
pub fn check_logs() -> Vec<Finding> {
    let mut out = Vec::new();
    // dmesg (avec sudo en général, mais readable pour user parfois)
    let dmesg = Command::new("dmesg")
        .output()
        .map(|o| String::from_utf8_lossy(&o.stdout).to_string())
        .unwrap_or_default();
    let mut err_count = 0;
    let mut last_err = String::new();
    for line in dmesg.lines() {
        let ll = line.to_lowercase();
        if ll.contains("error") || ll.contains("fail") || ll.contains("critical") || ll.contains("panic") {
            err_count += 1;
            if last_err.is_empty() {
                last_err = line.to_string();
            }
        }
    }
    if err_count > 0 {
        out.push(Finding {
            category: "LOG".into(),
            severity: if err_count > 10 { "high" } else { "medium" }.into(),
            title: format!("{} entrées kernel error/panic dans dmesg", err_count),
            technical: format!("dmesg lit le ring buffer kernel. Erreurs récentes : '{}'", last_err.chars().take(120).collect::<String>()),
            simple: format!("{} erreurs kernel récentes.", err_count),
            recommendation: "sudo dmesg -T pour timestamps, identifier la cause.".into(),
        });
    } else {
        out.push(Finding {
            category: "LOG".into(),
            severity: "info".into(),
            title: "Aucune erreur kernel dans dmesg".into(),
            technical: "dmesg ring buffer clean.".into(),
            simple: "Pas d'erreur kernel.".into(),
            recommendation: "".into(),
        });
    }
    out
}

// ─── 8. Sécurité ─────────────────────────────────────────────────────────
pub fn check_security() -> Vec<Finding> {
    let mut out = Vec::new();
    // sudoers
    let sudoers = read_file("/etc/sudoers");
    let nopasswd = sudoers.matches("NOPASSWD").count();
    if nopasswd > 0 {
        out.push(Finding {
            category: "SEC".into(),
            severity: "high".into(),
            title: format!("{} entrée(s) NOPASSWD dans /etc/sudoers", nopasswd),
            technical: "NOPASSWD permet sudo sans mot de passe — risque si compte compromis.".into(),
            simple: "Certains programmes peuvent agir en root sans mot de passe.".into(),
            recommendation: "Vérifier /etc/sudoers.d/ et restreindre NOPASSWD".into(),
        });
    }
    // Ports ouverts
    let ss = run_cmd(&["ss", "-tlnp"]);
    let open_ports: Vec<&str> = ss.lines().skip(1)
        .filter(|l| l.contains("LISTEN"))
        .collect();
    let port_count = open_ports.len();
    out.push(Finding {
        category: "SEC".into(),
        severity: if port_count > 10 { "medium" } else { "low" }.into(),
        title: format!("{} ports TCP en écoute", port_count),
        technical: format!("ss -tlnp — ports exposés localement. Vérifier les services inattendus."),
        simple: format!("{} services écoutent sur des ports.", port_count),
        recommendation: if port_count > 10 { "Fermer les services non utilisés." } else { "" }.into(),
    });
    out
}
