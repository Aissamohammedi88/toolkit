// ════════════════════════════════════════════════════════════════════════════
// NEXUS-DOCTOR v1.0 — Main entry point (Rust, 90% of the project)
// Linux desktop app : debug + boost + clean + auto-repair + benchmark
// Auteur : Aissa Mohammedi (DGK) — Nexus Quantum
// ════════════════════════════════════════════════════════════════════════════
mod doctor;
mod booster;
mod cache_cleaner;
mod auto_repair;
mod benchmark;

use std::env;
use std::io::{self, Write};
use std::process::Command;
use std::thread;
use std::time::Duration;

// ANSI colors
const RESET: &str = "\x1b[0m";
const BOLD: &str = "\x1b[1m";
const RED: &str = "\x1b[31m";
const GREEN: &str = "\x1b[32m";
const YELLOW: &str = "\x1b[33m";
const BLUE: &str = "\x1b[34m";
const MAGENTA: &str = "\x1b[35m";
const CYAN: &str = "\x1b[36m";

fn banner() {
    print!("{CLEAR}{CYAN}{BOLD}", CLEAR = "\x1b[2J\x1b[H");
    println!("╔════════════════════════════════════════════════════════════╗");
    println!("║   ███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗  ██████╗    ║");
    println!("║   ████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝ ██╔═══██╗   ║");
    println!("║   ██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗ ██║   ██║   ║");
    println!("║   ██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║ ██║   ██║   ║");
    println!("║   ██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████╗╚██████╔╝   ║");
    println!("║   ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝ ╚═════╝    ║");
    println!("║                                                            ║");
    println!("║   Linux Doctor · Booster Ferrari · Cache 40% · Auto-repair ║");
    println!("╚════════════════════════════════════════════════════════════╝");
    println!("{RESET}Auteur : Aissa Mohammedi (DGK) — Nexus Quantum{RESET}\n",
             RESET = RESET);
}

fn menu() {
    println!("{CYAN}{BOLD}═══ MENU PRINCIPAL ═══{RESET}");
    println!("  {BOLD}1){RESET} Diagnostic complet   {MAGENTA}(le docteur t'explique tout){RESET}");
    println!("  {BOLD}2){RESET} Mode technique       {CYAN}(détails techniques complets){RESET}");
    println!("  {BOLD}3){RESET} Booster Ferrari      {YELLOW}(max perf — demande sudo){RESET}");
    println!("  {BOLD}4){RESET} Vider 40% cache      {GREEN}(smart clear){RESET}");
    println!("  {BOLD}5){RESET} Auto-réparation      {RED}(avec notifs pour dangers){RESET}");
    println!("  {BOLD}6){RESET} Benchmark            {CYAN}(CPU/Mem/Disk/Net + score){RESET}");
    println!("  {BOLD}7){RESET} Rapport complet      {BLUE}(génère HTML via Ruby){RESET}");
    println!("  {BOLD}8){RESET} Dashboard UI         {BLUE}(HTML via TypeScript){RESET}");
    println!("  {BOLD}9){RESET} Log legacy COBOL     {MAGENTA}(le carnet du docteur){RESET}");
    println!("  {BOLD}0){RESET} Full session         {BOLD}(1→2→3→4→5→6→7→8→9){RESET}");
    println!("  {BOLD}q){RESET} Quitter\n");
}

fn read_input() -> String {
    let mut buf = String::new();
    io::stdout().flush().ok();
    io::stdin().read_line(&mut buf).ok();
    buf.trim().to_string()
}

fn notify(title: &str, body: &str, urgency: &str) {
    // notify-send (libnotify) — best effort, ignore errors
    let _ = Command::new("notify-send")
        .args(["-u", urgency, title, body])
        .spawn();
}

fn header(s: &str) {
    println!("\n{BLUE}{BOLD}════════ {} ════════{RESET}", s, BLUE = BLUE, BOLD = BOLD, RESET = RESET);
}

fn run_doctor(technical: bool) -> Vec<doctor::Finding> {
    header("DIAGNOSTIC MÉDICAL DU PC");
    println!("{CYAN}Le docteur NEXUS examine votre système...{RESET}\n");

    let mut all_findings: Vec<doctor::Finding> = Vec::new();

    println!("{BOLD}[1/8] CPU — governor, thermals, throttling{RESET}");
    let cpu = doctor::check_cpu();
    for f in &cpu {
        f.print(technical);
    }
    all_findings.extend(cpu);

    println!("\n{BOLD}[2/8] Mémoire — RAM, swap, OOM{RESET}");
    let mem = doctor::check_memory();
    for f in &mem { f.print(technical); }
    all_findings.extend(mem);

    println!("\n{BOLD}[3/8] Disque — SMART, IO errors{RESET}");
    let disk = doctor::check_disk();
    for f in &disk { f.print(technical); }
    all_findings.extend(disk);

    println!("\n{BOLD}[4/8] Filesystem — mount, errors{RESET}");
    let fs = doctor::check_filesystem();
    for f in &fs { f.print(technical); }
    all_findings.extend(fs);

    println!("\n{BOLD}[5/8] Réseau — DNS, latency, interfaces{RESET}");
    let net = doctor::check_network();
    for f in &net { f.print(technical); }
    all_findings.extend(net);

    println!("\n{BOLD}[6/8] Processus — zombies, high CPU{RESET}");
    let procs = doctor::check_processes();
    for f in &procs { f.print(technical); }
    all_findings.extend(procs);

    println!("\n{BOLD}[7/8] Logs kernel — dmesg récents{RESET}");
    let logs = doctor::check_logs();
    for f in &logs { f.print(technical); }
    all_findings.extend(logs);

    println!("\n{BOLD}[8/8] Sécurité — sudoers, ports ouverts{RESET}");
    let sec = doctor::check_security();
    for f in &sec { f.print(technical); }
    all_findings.extend(sec);

    println!("\n{CYAN}{BOLD}Bilan : {} finding(s) au total{RESET}", all_findings.len());
    let crit = all_findings.iter().filter(|f| f.severity == "critical").count();
    let high = all_findings.iter().filter(|f| f.severity == "high").count();
    let med = all_findings.iter().filter(|f| f.severity == "medium").count();
    let low = all_findings.iter().filter(|f| f.severity == "low").count();
    println!("  {RED}Critical : {}{RESET}  {YELLOW}High : {}{RESET}  {YELLOW}Medium : {}{RESET}  {CYAN}Low : {}{RESET}",
             crit, high, med, low);

    all_findings
}

fn run_booster() {
    header("BOOSTER FERRARI");
    println!("{YELLOW}⚠ Cette opération modifie la config système (governor, swappiness, IO scheduler).{RESET}");
    println!("{YELLOW}Certaines actions nécessitent sudo. Le docteur demande confirmation.{RESET}\n");
    let actions = booster::plan_actions();
    for a in &actions {
        println!("  [{BOLD}{}{RESET}] {} — {}",
                 if a.needs_root { "{RED}sudo{RESET}" } else { "{GREEN}user{RESET}" },
                 a.title, a.detail);
    }
    print!("\n{BOLD}Lancer le boost? [y/N] : {RESET}");
    io::stdout().flush().ok();
    let confirm = read_input();
    if confirm != "y" && confirm != "Y" {
        println!("{YELLOW}Boost annulé.{RESET}");
        return;
    }
    let results = booster::execute(&actions);
    let mut ok = 0;
    let mut fail = 0;
    for r in &results {
        if r.success {
            println!("  {GREEN}✓{RESET} {} — {}ms", r.title, r.duration_ms);
            ok += 1;
        } else {
            println!("  {RED}✗{RESET} {} — {}", r.title, r.error);
            fail += 1;
        }
    }
    println!("\n{GREEN}{BOLD}Boost terminé : {} OK, {} échec(s){RESET}", ok, fail);
    if fail > 0 {
        notify("NEXUS-DOCTOR — Boost",
               &format!("{} actions OK, {} échouées (sudo probablement requis)", ok, fail),
               "normal");
    } else {
        notify("NEXUS-DOCTOR — Boost", "PC boosté mode Ferrari!", "low");
    }
}

fn run_cache_clean() {
    header("VIDER 40% DU CACHE");
    let report = cache_cleaner::clean_40_percent();
    println!("{CYAN}Cache avant : {} MB{RESET}", report.cache_before_mb);
    println!("{CYAN}Cible 40%   : {} MB{RESET}", report.target_to_clear_mb);
    println!("{CYAN}Cache après : {} MB{RESET}", report.cache_after_mb);
    println!();
    println!("{BOLD}Éléments nettoyés :{RESET}");
    for item in &report.cleared_items {
        println!("  {GREEN}✓{RESET} {} — {} MB", item.path, item.size_mb);
    }
    println!("\n{GREEN}{BOLD}Libéré : {} MB ({:.1}% du cache initial){RESET}",
             report.total_cleared_mb,
             report.percent_cleared);
    notify("NEXUS-DOCTOR — Cache",
           &format!("{} MB libérés ({:.1}%)", report.total_cleared_mb, report.percent_cleared),
           "low");
}

fn run_auto_repair(findings: &[doctor::Finding]) {
    header("AUTO-RÉPARATION AVEC NOTIFS");
    println!("{RED}⚠ L'auto-réparation peut être dangereuse pour le système.{RESET}");
    println!("{RED}  Le docteur notifie pour chaque action risquée.{RESET}\n");

    let plan = auto_repair::plan_repairs(findings);
    let mut safe_count = 0;
    let mut danger_count = 0;
    let mut critical_count = 0;

    println!("{BOLD}Plan de réparation :{RESET}");
    for action in &plan {
        let icon = match action.danger_level {
            auto_repair::DangerLevel::Safe => "{GREEN}SAFE{RESET}",
            auto_repair::DangerLevel::Dangerous => "{YELLOW}DANGER{RESET}",
            auto_repair::DangerLevel::Critical => "{RED}CRITICAL{RESET}",
        };
        println!("  [{BOLD}{}{RESET}] {} — {}", icon, action.title, action.description);
        match action.danger_level {
            auto_repair::DangerLevel::Safe => safe_count += 1,
            auto_repair::DangerLevel::Dangerous => danger_count += 1,
            auto_repair::DangerLevel::Critical => critical_count += 1,
        }
    }

    println!("\n{BOLD}Résumé :{RESET} {GREEN}{} safe{RESET}, {YELLOW}{} dangereux{RESET}, {RED}{} critiques{RESET}",
             safe_count, danger_count, critical_count);

    print!("\n{BOLD}Exécuter les réparations SAFE automatiquement? [y/N] : {RESET}");
    io::stdout().flush().ok();
    let safe_confirm = read_input();

    print!("{BOLD}Exécuter aussi les DANGEREUX (avec notif individuelle)? [y/N] : {RESET}");
    io::stdout().flush().ok();
    let danger_confirm = read_input();

    let mut applied = 0;
    let mut notif_sent = 0;
    for action in &plan {
        let do_it = match action.danger_level {
            auto_repair::DangerLevel::Safe => safe_confirm == "y" || safe_confirm == "Y",
            auto_repair::DangerLevel::Dangerous => danger_confirm == "y" || danger_confirm == "Y",
            auto_repair::DangerLevel::Critical => false,
        };
        if do_it {
            // Notif pour les dangereux (avant exécution)
            if action.danger_level == auto_repair::DangerLevel::Dangerous {
                notify("NEXUS-DOCTOR — Action dangereuse auto",
                       &format!("{} — {}", action.title, action.description),
                       "critical");
                notif_sent += 1;
                thread::sleep(Duration::from_millis(500));
            }
            let result = auto_repair::execute(action);
            if result.success {
                println!("  {GREEN}✓{RESET} {} — {}", action.title, result.detail);
                applied += 1;
            } else {
                println!("  {RED}✗{RESET} {} — {}", action.title, result.error);
            }
        } else {
            println!("  {YELLOW}⊘{RESET} {} — skip", action.title);
        }
    }
    println!("\n{GREEN}{BOLD}Réparations appliquées : {}{RESET}", applied);
    if notif_sent > 0 {
        println!("{YELLOW}{BOLD}Notifications envoyées : {} (actions dangereuses){RESET}", notif_sent);
    }
    if critical_count > 0 {
        notify("NEXUS-DOCTOR — Action critique détectée",
               &format!("{} action(s) critique(s) nécessitent intervention manuelle", critical_count),
               "critical");
    }
}

fn run_benchmark() {
    header("BENCHMARK — SCORE FERRARI");
    let opts = benchmark::BenchmarkOptions {
        cpu: true,
        memory: true,
        disk: true,
        network: true,
        iterations: 3,
        save_results: true,
    };
    println!("{CYAN}Lancement benchmark (CPU+Mem+Disk+Net, 3 itérations)...{RESET}\n");
    let results = benchmark::run_all(&opts);
    println!("{BOLD}CPU{RESET}     : {:.2} GFLOPS  ({:.0} ms/op)", results.cpu_gflops, results.cpu_ms_per_op);
    println!("{BOLD}Memory{RESET}  : {:.2} GB/s    ({:.0} ms)", results.mem_gbps, results.mem_ms);
    println!("{BOLD}Disk{RESET}    : {:.2} MB/s seq, {:.2} MB/s rand", results.disk_seq_mbps, results.disk_rand_mbps);
    println!("{BOLD}Network{RESET} : {:.0} ms ping avg", results.net_ping_ms);
    println!();
    let score = results.ferrari_score();
    let rating = match score {
        s if s >= 8000 => "FERRARI SF90 🏎️",
        s if s >= 5000 => "FERRARI 488 🏎️",
        s if s >= 3000 => "FERRARI California",
        s if s >= 1500 => "Golf GTI",
        s if s >= 500  => "Clio 4",
        _ => "Twingo",
    };
    println!("{MAGENTA}{BOLD}═══ FERRARI SCORE : {} / 10000 ═══{RESET}", score);
    println!("{MAGENTA}{BOLD}═══ NIVEAU : {} ═══{RESET}", rating);
    notify("NEXUS-DOCTOR — Benchmark",
           &format!("Score Ferrari : {} — {}", score, rating),
           "normal");
}

fn run_report(findings: &[doctor::Finding]) {
    header("RAPPORT HTML (RUBY)");
    let json = doctor::findings_to_json(findings);
    let json_file = "/tmp/nexus-doctor-findings.json";
    std::fs::write(json_file, &json).ok();
    let report_rb = env::var("NEXUS_DOCTOR_SRC").unwrap_or_else(|_| ".".to_string());
    let rb_path = format!("{}/report_generator.rb", report_rb);
    let out_html = format!("{}/nexus-doctor-report-{}.html",
        env::var("HOME").unwrap_or_else(|_| "/tmp".to_string()),
        chrono_timestamp());
    let status = Command::new("ruby")
        .args([&rb_path, json_file, &out_html])
        .status();
    match status {
        Ok(s) if s.success() => {
            println!("{GREEN}Rapport généré : {}{RESET}", out_html);
            notify("NEXUS-DOCTOR — Rapport", &format!("Rapport HTML : {}", out_html), "low");
        }
        _ => println!("{RED}Échec génération rapport. Ruby installé?{RESET}"),
    }
}

fn run_dashboard() {
    header("DASHBOARD UI (TYPESCRIPT)");
    let ts_path = format!("{}/ui_dashboard.ts",
        env::var("NEXUS_DOCTOR_SRC").unwrap_or_else(|_| ".".to_string()));
    let out_html = format!("{}/nexus-doctor-dashboard-{}.html",
        env::var("HOME").unwrap_or_else(|_| "/tmp".to_string()),
        chrono_timestamp());
    // Node 22+ strip TS types natively
    let status = Command::new("node")
        .args([&ts_path, &out_html])
        .status();
    match status {
        Ok(s) if s.success() => {
            println!("{GREEN}Dashboard généré : {}{RESET}", out_html);
            // Try to open in browser
            if let Ok(_) = Command::new("xdg-open").arg(&out_html).spawn() {
                println!("{CYAN}Ouverture navigateur...{RESET}");
            }
        }
        _ => println!("{RED}Échec dashboard. Node installé?{RESET}"),
    }
}

fn run_legacy_log(findings: &[doctor::Finding]) {
    header("LOG LEGACY (COBOL — le carnet du docteur)");
    let json_file = "/tmp/nexus-doctor-findings.json";
    let json = doctor::findings_to_json(findings);
    std::fs::write(json_file, &json).ok();
    let src = env::var("NEXUS_DOCTOR_SRC").unwrap_or_else(|_| ".".to_string());
    let cob_path = format!("{}/legacy_log.cob", src);
    let log_out = format!("{}/nexus-doctor/legacy-doctor.log",
        env::var("HOME").unwrap_or_else(|_| "/tmp".to_string()));
    let status = Command::new("cobc")
        .args(["-x", &cob_path, "-o", "/tmp/nexus_legacy_log"])
        .status();
    match status {
        Ok(s) if s.success() => {
            let run_status = Command::new("/tmp/nexus_legacy_log")
                .args([&json_file[..], &log_out[..]])
                .status();
            match run_status {
                Ok(rs) if rs.success() => {
                    println!("{GREEN}Log legacy écrit : {}{RESET}", log_out);
                    if let Ok(content) = std::fs::read_to_string(&log_out) {
                        println!("\n{MAGENTA}── extrait ──{RESET}");
                        for line in content.lines().take(10) {
                            println!("  {}", line);
                        }
                    }
                }
                _ => println!("{RED}Échec exécution COBOL{RESET}"),
            }
        }
        _ => println!("{RED}Échec compilation COBOL. gnucobol installé?{RESET}"),
    }
}

fn chrono_timestamp() -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    let secs = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs();
    format!("{}", secs)
}

fn full_session() {
    println!("{MAGENTA}{BOLD}═══ FULL SESSION — le docteur fait tout ═══{RESET}\n");
    let findings = run_doctor(true);
    println!("\n{CYAN}Appuyez sur Entrée pour continuer vers le boost...{RESET}");
    let _ = read_input();
    run_booster();
    println!("\n{CYAN}Appuyez sur Entrée pour vider le cache...{RESET}");
    let _ = read_input();
    run_cache_clean();
    println!("\n{CYAN}Appuyez sur Entrée pour auto-réparer...{RESET}");
    let _ = read_input();
    run_auto_repair(&findings);
    println!("\n{CYAN}Appuyez sur Entrée pour le benchmark...{RESET}");
    let _ = read_input();
    run_benchmark();
    println!("\n{CYAN}Appuyez sur Entrée pour générer les rapports...{RESET}");
    let _ = read_input();
    run_report(&findings);
    run_dashboard();
    run_legacy_log(&findings);
    println!("\n{GREEN}{BOLD}═══ Session complète terminée ═══{RESET}");
}

fn main() {
    let args: Vec<String> = env::args().collect();
    // CLI dispatch (pour le launcher bash)
    if args.len() > 1 {
        match args[1].as_str() {
            "--doctor" => { let _ = run_doctor(false); return; }
            "--technical" => { let _ = run_doctor(true); return; }
            "--boost" => { run_booster(); return; }
            "--cache" => { run_cache_clean(); return; }
            "--repair" => {
                let f = run_doctor(false);
                run_auto_repair(&f);
                return;
            }
            "--bench" => { run_benchmark(); return; }
            "--report" => {
                let f = run_doctor(false);
                run_report(&f);
                return;
            }
            "--dashboard" => { run_dashboard(); return; }
            "--legacy" => {
                let f = run_doctor(false);
                run_legacy_log(&f);
                return;
            }
            "--full" => { full_session(); return; }
            "--help" | "-h" => {
                println!("NEXUS-DOCTOR v1.0\n");
                println!("Usage: nexus-doctor [option]");
                println!("  (no arg)  Menu interactif");
                println!("  --doctor    Diagnostic simple");
                println!("  --technical Diagnostic technique complet");
                println!("  --boost     Booster Ferrari");
                println!("  --cache     Vider 40% cache");
                println!("  --repair    Auto-réparation (avec notifs)");
                println!("  --bench     Benchmark + score Ferrari");
                println!("  --report    Rapport HTML (Ruby)");
                println!("  --dashboard Dashboard HTML (TypeScript)");
                println!("  --legacy    Log COBOL");
                println!("  --full      Session complète");
                return;
            }
            _ => {}
        }
    }

    // Interactive TUI
    loop {
        banner();
        menu();
        print!("{BOLD}Choix > {RESET}");
        io::stdout().flush().ok();
        let choice = read_input();
        match choice.as_str() {
            "1" => { let _ = run_doctor(false); pause(); }
            "2" => { let _ = run_doctor(true); pause(); }
            "3" => { run_booster(); pause(); }
            "4" => { run_cache_clean(); pause(); }
            "5" => {
                let f = run_doctor(false);
                run_auto_repair(&f);
                pause();
            }
            "6" => { run_benchmark(); pause(); }
            "7" => {
                let f = run_doctor(false);
                run_report(&f);
                pause();
            }
            "8" => { run_dashboard(); pause(); }
            "9" => {
                let f = run_doctor(false);
                run_legacy_log(&f);
                pause();
            }
            "0" => { full_session(); pause(); }
            "q" | "Q" | "quit" | "exit" => {
                println!("{CYAN}NEXUS-DOCTOR : au revoir, docteur.{RESET}");
                break;
            }
            _ => println!("{RED}Choix invalide{RESET}"),
        }
    }
}

fn pause() {
    print!("\n{BOLD}Appuyez sur Entrée pour continuer...{RESET}");
    io::stdout().flush().ok();
    let _ = read_input();
}
