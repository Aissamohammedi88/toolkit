// ════════════════════════════════════════════════════════════════════════════
// NEXUS-DOCTOR — Module auto_repair.rs
// Auto-réparation avec évaluation de danger + notifications
// ════════════════════════════════════════════════════════════════════════════
use crate::doctor::Finding;
use std::process::Command;

#[derive(PartialEq, Debug)]
pub enum DangerLevel {
    Safe,         // auto-réparable sans risque
    Dangerous,    // risqué — notifier AVANT d'exécuter
    Critical,     // ne pas auto-réparer — intervention manuelle requise
}

pub struct RepairAction {
    pub title: String,
    pub description: String,
    pub danger_level: DangerLevel,
    pub cmd: String,
    pub args: Vec<String>,
    pub technical_reason: String,  // pourquoi ce niveau de danger
}

pub struct RepairResult {
    pub success: bool,
    pub detail: String,
    pub error: String,
}

pub fn plan_repairs(findings: &[Finding]) -> Vec<RepairAction> {
    let mut plan = Vec::new();
    for f in findings {
        // Mapper findings → actions
        if f.title.contains("zombie") {
            plan.push(RepairAction {
                title: "Reaper zombies".into(),
                description: "Tuer les parents des zombies".into(),
                danger_level: DangerLevel::Dangerous, // tuer un parent peut casser un service
                cmd: "bash".into(),
                args: vec![
                    "-c".into(),
                    "ps -A -ostat,ppid | awk '/[zZ]/{print $2}' | sort -u | xargs -r kill -9".into(),
                ],
                technical_reason: "kill -9 sur PPID d'un zombie — risque de casser le service parent".into(),
            });
        }
        if f.title.contains("READ-ONLY") {
            plan.push(RepairAction {
                title: "fsck + remount rw".into(),
                description: "Vérifier et remonter la partition en read-write".into(),
                danger_level: DangerLevel::Critical, // fsck sur une partition montée = perte de données
                cmd: "echo".into(),
                args: vec!["INTERVENTION MANUELLE REQUISE — fsck à froid uniquement".into()],
                technical_reason: "fsck sur FS monté = corruption garantie. Doit être fait depuis un live USB ou en single-user mode.".into(),
            });
        }
        if f.title.starts_with("Governor") && f.title.contains("powersave") {
            plan.push(RepairAction {
                title: "CPU governor → performance".into(),
                description: "Max performance CPU".into(),
                danger_level: DangerLevel::Dangerous, // chauffe + conso
                cmd: "bash".into(),
                args: vec![
                    "-c".into(),
                    "for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo performance | sudo tee $f >/dev/null; done".into(),
                ],
                technical_reason: "Performance = toujours max freq → chauffe + conso élevée. Pas dangereux mais impact thermique.".into(),
            });
        }
        if f.title.starts_with("Température") && f.severity == "high" {
            plan.push(RepairAction {
                title: "Cool-down emergency".into(),
                description: "Forcer governor powersave temporairement".into(),
                danger_level: DangerLevel::Dangerous,
                cmd: "bash".into(),
                args: vec![
                    "-c".into(),
                    "for f in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo powersave | sudo tee $f >/dev/null; done".into(),
                ],
                technical_reason: "Réduction urgent de charge CPU — impact performance immédiat".into(),
            });
        }
        if f.title.contains("CPU") && f.title.contains("%") {
            // Extraire le PID si présent
            if let Some(pid_start) = f.technical.find("PID ") {
                let rest = &f.technical[pid_start..];
                if let Some(end) = rest.find(' ') {
                    if rest.len() > 4 {
                        let pid_str = &rest[4..end];
                        if pid_str.chars().all(|c| c.is_numeric()) {
                            plan.push(RepairAction {
                                title: format!("SIGTERM PID {}", pid_str),
                                description: "Terminer le process gourmand".into(),
                                danger_level: DangerLevel::Dangerous,
                                cmd: "kill".into(),
                                args: vec!["-TERM".into(), pid_str.to_string()],
                                technical_reason: "kill -TERM peut interrompre un travail en cours — perte de données possible si le process n'est pas signal-safe".into(),
                            });
                        }
                    }
                }
            }
        }
        if f.title.contains("NOPASSWD") {
            plan.push(RepairAction {
                title: "Restreindre NOPASSWD".into(),
                description: "Vérifier /etc/sudoers.d/".into(),
                danger_level: DangerLevel::Critical,
                cmd: "echo".into(),
                args: vec!["INTERVENTION MANUELLE — visudo".into()],
                technical_reason: "Modifier sudoers incorrectement = bloquer tout accès root. Toujours via visudo.".into(),
            });
        }
        if f.title.contains("Ports") && f.severity == "medium" {
            plan.push(RepairAction {
                title: "Audit ports ouverts".into(),
                description: "Lister services en écoute".into(),
                danger_level: DangerLevel::Safe,
                cmd: "ss".into(),
                args: vec!["-tlnp".into()],
                technical_reason: "Lecture seule — pas d'impact".into(),
            });
        }
    }
    // Toujours ajouter : sync (safe) + clear tmp orphelins (safe)
    plan.push(RepairAction {
        title: "sync (flush buffers)".into(),
        description: "Écrit les buffers disque en attente".into(),
        danger_level: DangerLevel::Safe,
        cmd: "sync".into(),
        args: vec![],
        technical_reason: "sync(1) — syscall sync(), sans risque".into(),
    });
    plan.push(RepairAction {
        title: "Nettoyer /tmp orphelins (>7j)".into(),
        description: "Supprime fichiers /tmp anciens".into(),
        danger_level: DangerLevel::Safe,
        cmd: "find".into(),
        args: vec!["/tmp".into(), "-type".into(), "f".into(), "-mtime".into(), "+7".into(),
                   "-delete".into()],
        technical_reason: "Fichiers >7 jours dans /tmp rarement utilisés — suppression safe".into(),
    });
    plan.push(RepairAction {
        title: "Nettoyer journaux anciens".into(),
        description: "Journalctl vacuum >100MB".into(),
        danger_level: DangerLevel::Safe,
        cmd: "journalctl".into(),
        args: vec!["--vacuum-size=100M".into()],
        technical_reason: "journalctl vacuum — limite la taille des logs systemd".into(),
    });
    plan
}

pub fn execute(action: &RepairAction) -> RepairResult {
    let status = Command::new(&action.cmd)
        .args(&action.args)
        .output();
    match status {
        Ok(o) if o.status.success() => RepairResult {
            success: true,
            detail: String::from_utf8_lossy(&o.stdout).chars().take(120).collect(),
            error: "".into(),
        },
        Ok(o) => {
            let err = String::from_utf8_lossy(&o.stderr);
            let detail: String = if err.is_empty() {
                String::from_utf8_lossy(&o.stdout).chars().take(120).collect()
            } else {
                err.chars().take(120).collect()
            };
            RepairResult {
                success: false,
                detail: detail.clone(),
                error: if err.is_empty() { "exit non-zero".into() } else { detail },
            }
        }
        Err(e) => RepairResult {
            success: false,
            detail: "".into(),
            error: e.to_string(),
        },
    }
}
