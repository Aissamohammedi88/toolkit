#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════════════════
# NEXUS-DOCTOR v1.0 — Launcher bash
# Compile les 9 fichiers (Rust + TypeScript + Ruby + Cobol) et lance l'app
# Auteur : Aissa Mohammedi (DGK) — Nexus Quantum
# ════════════════════════════════════════════════════════════════════════════
set -uo pipefail

# ─── Couleurs ────────────────────────────────────────────────────────────────
G='\033[0;32m'; Y='\033[0;33m'; R='\033[0;31m'
B='\033[0;34m'; C='\033[0;36m'; M='\033[0;35m'; BD='\033[1m'; NC='\033[0m'
info()    { echo -e "${G}[OK]${NC} $*"; }
warn()    { echo -e "${Y}[WARN]${NC} $*"; }
fail()    { echo -e "${R}[ERR]${NC} $*"; }
section() { echo -e "\n${B}===== $* =====${NC}"; }

# ─── Paths ───────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="${SCRIPT_DIR}/src"
BUILD_DIR="${SCRIPT_DIR}/build"
LOG_DIR="${SCRIPT_DIR}/logs"
HOME_NEXUS="${HOME}/.nexus-doctor"

mkdir -p "$BUILD_DIR" "$LOG_DIR" "$HOME_NEXUS"

export NEXUS_DOCTOR_SRC="$SRC_DIR"

# ─── Vérif outils ────────────────────────────────────────────────────────────
check_tools() {
    section "VÉRIFICATION OUTILS"
    local miss=()
    for t in rustc node ruby cobc; do
        if command -v "$t" &>/dev/null; then
            info "$t : $(command -v "$t")"
        else
            warn "$t : MANQUANT"
            miss+=("$t")
        fi
    done
    if (( ${#miss[@]} > 0 )); then
        warn "Outils manquants : ${miss[*]}"
        warn "  rustc : curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh"
        warn "  node  : https://nodejs.org/ (v22+ pour TS stripping natif)"
        warn "  ruby  : apt install ruby / pacman -S ruby / dnf install ruby"
        warn "  cobc  : apt install gnucobol / pacman -S gnucobol"
        return 1
    fi
    info "Tous les outils présents"
}

# ─── Build Rust ──────────────────────────────────────────────────────────────
build_rust() {
    section "BUILD RUST (main.rs + doctor + booster + cache_cleaner + auto_repair + benchmark)"
    if [[ -x "${BUILD_DIR}/nexus-doctor" ]] && \
       [[ "${SRC_DIR}/main.rs" -ot "${BUILD_DIR}/nexus-doctor" ]] && \
       [[ "${SRC_DIR}/doctor.rs" -ot "${BUILD_DIR}/nexus-doctor" ]]; then
        info "Binaire déjà compilé (récent)"
        return 0
    fi
    info "Compilation des 6 modules Rust..."
    cd "$SRC_DIR"
    if rustc -O -o "${BUILD_DIR}/nexus-doctor" main.rs 2>&1 | tee "${LOG_DIR}/rust-compile.log"; then
        if [[ -x "${BUILD_DIR}/nexus-doctor" ]]; then
            info "Binaire Rust : ${BUILD_DIR}/nexus-doctor ($(du -h "${BUILD_DIR}/nexus-doctor" | cut -f1))"
        else
            fail "Compilation Rust échouée — voir ${LOG_DIR}/rust-compile.log"
            return 1
        fi
    else
        fail "rustc a retourné une erreur"
        return 1
    fi
}

# ─── Build Cobol ─────────────────────────────────────────────────────────────
build_cobol() {
    section "BUILD COBOL (legacy_log.cob)"
    if [[ -x "${BUILD_DIR}/nexus_legacy_log" ]] && \
       [[ "${SRC_DIR}/legacy_log.cob" -ot "${BUILD_DIR}/nexus_legacy_log" ]]; then
        info "Binaire COBOL déjà compilé"
        return 0
    fi
    info "Compilation legacy_log.cob..."
    if cobc -x -o "${BUILD_DIR}/nexus_legacy_log" "${SRC_DIR}/legacy_log.cob" 2>&1 | tee "${LOG_DIR}/cobol-compile.log"; then
        [[ -x "${BUILD_DIR}/nexus_legacy_log" ]] \
            && info "Binaire COBOL : ${BUILD_DIR}/nexus_legacy_log" \
            || { fail "COBOL compile échoué"; return 1; }
    else
        fail "cobc a retourné une erreur"
        return 1
    fi
}

# ─── Test TypeScript (validation syntaxique via node) ────────────────────────
test_typescript() {
    section "VALIDATION TYPESCRIPT"
    info "Test ui_dashboard.ts via node (strip types natif)..."
    if node "${SRC_DIR}/ui_dashboard.ts" /tmp/nexus-ts-test.html 2>&1 | head -3; then
        info "TypeScript exécutable OK"
        [[ -f /tmp/nexus-ts-test.html ]] && info "HTML généré : $(du -h /tmp/nexus-ts-test.html | cut -f1)"
        rm -f /tmp/nexus-ts-test.html
    else
        warn "TypeScript a des erreurs — le rapport UI ne marchera pas"
    fi
}

# ─── Test Ruby ───────────────────────────────────────────────────────────────
test_ruby() {
    section "VALIDATION RUBY"
    info "Test report_generator.rb..."
    echo '{"findings":[]}' > /tmp/nexus-ruby-test.json
    if ruby "${SRC_DIR}/report_generator.rb" /tmp/nexus-ruby-test.json /tmp/nexus-ruby-test.html 2>&1 | head -3; then
        info "Ruby exécutable OK"
        [[ -f /tmp/nexus-ruby-test.html ]] && info "HTML généré : $(du -h /tmp/nexus-ruby-test.html | cut -f1)"
        rm -f /tmp/nexus-ruby-test.json /tmp/nexus-ruby-test.html
    else
        warn "Ruby a des erreurs — le rapport médical ne marchera pas"
    fi
}

# ─── Build all ───────────────────────────────────────────────────────────────
build_all() {
    check_tools || return 1
    build_rust
    build_cobol
    test_typescript
    test_ruby
    section "BUILD COMPLET TERMINÉ"
    info "Binaire principal : ${BUILD_DIR}/nexus-doctor"
    info "Binaire legacy    : ${BUILD_DIR}/nexus_legacy_log"
    info "TypeScript        : ${SRC_DIR}/ui_dashboard.ts (run via node)"
    info "Ruby              : ${SRC_DIR}/report_generator.rb (run via ruby)"
}

# ─── Run app ─────────────────────────────────────────────────────────────────
run() {
    if [[ ! -x "${BUILD_DIR}/nexus-doctor" ]]; then
        warn "Binaire manquant — build d'abord"
        build_all || return 1
    fi
    exec "${BUILD_DIR}/nexus-doctor" "$@"
}

# ─── Install desktop entry ───────────────────────────────────────────────────
install_desktop() {
    section "INSTALLATION .desktop"
    local desktop_dir="${HOME}/.local/share/applications"
    local icons_dir="${HOME}/.local/share/icons/hicolor/256x256/apps"
    mkdir -p "$desktop_dir" "$icons_dir"

    # Génère une icône SVG (croix médicale + engrenage)
    local icon_svg="${icons_dir}/nexus-doctor.svg"
    cat > "$icon_svg" << 'EOF'
<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 256 256">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#0d1117"/>
      <stop offset="100%" stop-color="#161b22"/>
    </linearGradient>
    <linearGradient id="accent" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#58a6ff"/>
      <stop offset="100%" stop-color="#bc8cff"/>
    </linearGradient>
  </defs>
  <rect width="256" height="256" rx="48" fill="url(#bg)"/>
  <circle cx="128" cy="128" r="80" fill="none" stroke="url(#accent)" stroke-width="6"/>
  <rect x="108" y="80" width="40" height="96" rx="4" fill="url(#accent)"/>
  <rect x="80" y="108" width="96" height="40" rx="4" fill="url(#accent)"/>
</svg>
EOF

    # .desktop file
    local desktop_file="${desktop_dir}/nexus-doctor.desktop"
    cat > "$desktop_file" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=NEXUS-DOCTOR
Comment=Linux Doctor · Booster Ferrari · Auto-repair · Benchmark
Exec=${SCRIPT_DIR}/nexus-doctor.sh --tui
Icon=nexus-doctor
Terminal=true
Categories=System;Utility;Monitor;
Keywords=doctor;system;boost;repair;cache;benchmark;
StartupNotify=true
EOF
    info "Desktop entry : ${desktop_file}"
    info "Icône SVG     : ${icon_svg}"
    info "Trouvé dans le menu applications > System > NEXUS-DOCTOR"
    # Update desktop database si possible
    update-desktop-database "$desktop_dir" 2>/dev/null || true
}

# ─── Status ──────────────────────────────────────────────────────────────────
status_report() {
    section "STATUT NEXUS-DOCTOR v1.0"
    echo -e "  ${BD}Source${NC}    : ${C}${SRC_DIR}${NC}"
    echo -e "  ${BD}Build${NC}     : ${C}${BUILD_DIR}${NC}"
    echo -e "  ${BD}Logs${NC}      : ${C}${LOG_DIR}${NC}"
    echo -e "  ${BD}Data${NC}      : ${C}${HOME_NEXUS}${NC}"
    echo ""
    echo "Fichiers source (9) :"
    for f in main.rs doctor.rs booster.rs cache_cleaner.rs auto_repair.rs benchmark.rs \
             ui_dashboard.ts report_generator.rb legacy_log.cob; do
        [[ -f "${SRC_DIR}/${f}" ]] \
            && echo -e "  ${G}OK${NC}  $(wc -l < ${SRC_DIR}/${f}) lignes  ${f}" \
            || echo -e "  ${R}--${NC}  manquant     ${f}"
    done
    echo ""
    echo "Binaires buildés :"
    [[ -x "${BUILD_DIR}/nexus-doctor" ]] \
        && echo -e "  ${G}OK${NC}  $(du -h ${BUILD_DIR}/nexus-doctor | cut -f1)  nexus-doctor (Rust)" \
        || echo -e "  ${Y}--${NC}  non buildé  nexus-doctor"
    [[ -x "${BUILD_DIR}/nexus_legacy_log" ]] \
        && echo -e "  ${G}OK${NC}  $(du -h ${BUILD_DIR}/nexus_legacy_log | cut -f1)  nexus_legacy_log (Cobol)" \
        || echo -e "  ${Y}--${NC}  non buildé  nexus_legacy_log"
    echo ""
    echo "Outils :"
    for t in rustc ruby cobc node; do
        command -v "$t" &>/dev/null \
            && echo -e "  ${G}OK${NC}  $t" \
            || echo -e "  ${R}--${NC}  $t absent"
    done
}

# ─── Aide ────────────────────────────────────────────────────────────────────
usage() {
    cat << EOF
NEXUS-DOCTOR v1.0 — Aissa Mohammedi (DGK) — Nexus Quantum

Linux desktop app : debug + boost + clean + auto-repair + benchmark
9 fichiers : 6 Rust (90%) + 1 TypeScript (3%) + 1 Ruby (3%) + 1 Cobol (2%)

Usage :
  nexus-doctor.sh [commande]

Commandes :
  --build        Compile les 9 fichiers (Rust + Cobol + test TS + test Ruby)
  --tui          Lance l'app TUI interactive (défaut)
  --doctor       Diagnostic simple
  --technical    Diagnostic technique complet
  --boost        Mode Ferrari
  --cache        Vider 40% du cache
  --repair       Auto-réparation (avec notifs pour dangers)
  --bench        Benchmark + Ferrari score
  --report       Rapport HTML (Ruby)
  --dashboard    Dashboard HTML (TypeScript)
  --legacy       Log COBOL (le carnet du docteur)
  --full         Session complète
  --install-desktop  Installe le .desktop + icône
  --status       Statut (fichiers, binaires, outils)
  --tar          Crée l'archive tar.gz du projet
  --help         Cette aide

Prérequis (sans sudo) :
  rustc  : curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
  ruby   : apt install ruby / conda install ruby
  cobc   : apt install gnucobol / open-cobol
  node   : v22+ requis (strip TypeScript natif)

EOF
}

# ─── Tar archive ─────────────────────────────────────────────────────────────
make_tar() {
    section "ARCHIVE TAR"
    local out="${SCRIPT_DIR}/../nexus-doctor-1.0.tar.gz"
    info "Création archive : ${out}"
    cd "${SCRIPT_DIR}/.."
    tar czf "nexus-doctor-1.0.tar.gz" \
        --exclude='nexus-doctor/build' \
        --exclude='nexus-doctor/logs' \
        --exclude='nexus-doctor/*.tar.gz' \
        nexus-doctor/ 2>&1 | tail -3
    [[ -f "../nexus-doctor-1.0.tar.gz" ]] \
        && info "Archive : $(du -h ../nexus-doctor-1.0.tar.gz | cut -f1) — $(pwd)/../nexus-doctor-1.0.tar.gz" \
        || fail "Archive échouée"
}

# ─── Main ────────────────────────────────────────────────────────────────────
case "${1:-}" in
    --build)           build_all ;;
    --tui|"")          run ;;
    --doctor|--technical|--boost|--cache|--repair|--bench|--report|--dashboard|--legacy|--full)
                       run "$@" ;;
    --install-desktop) install_desktop ;;
    --status)          status_report ;;
    --tar)             make_tar ;;
    --help|-h)         usage ;;
    *)                 warn "Commande inconnue : $1"; usage; exit 1 ;;
esac
