import json
import sqlite3
from pathlib import Path

import pytest

from nexus_senior.judges.anchor import AnchorJudge, split_passages, tokenize
from nexus_senior.judges.coherence import CoherenceJudge
from nexus_senior.judges.facts import FactJudge, SandboxJudge, init_db
from nexus_senior.seed import DEFAULT_KNOWLEDGE, seed
from nexus_senior.types import Claim, ClaimType, Generation


@pytest.fixture()
def kb(tmp_path: Path) -> str:
    db = tmp_path / "kb.db"
    n = seed(db, DEFAULT_KNOWLEDGE)
    assert n > 0
    return str(db)


# ---------------- Juge 1 : Ancrage (WTO) ----------------

class TestAnchorJudge:
    def test_tokenize_filters_stopwords(self):
        toks = tokenize("Le serveur dispose de 8 CPU très rapides")
        assert "serveur" in toks and "cpu" in toks
        assert "le" not in toks and "de" not in toks

    def test_anchored_claim_passes(self):
        ctx = ("Documentation serveur A. Le serveur A est équipé de 8 CPU et 32 GB RAM. "
               "Le stockage total atteint 512 Go NVMe.")
        gen = Generation(answer="x", claims=[
            Claim(text="Le serveur A est équipé de 8 CPU et 32 GB RAM", claim_type=ClaimType.FACT),
        ])
        res = AnchorJudge(threshold=0.35).judge(gen, ctx)
        assert res[0].passed and res[0].evidence.startswith("contexte[")

    def test_hallucinated_claim_fails_anchor(self):
        ctx = "Documentation serveur A. Le serveur A est équipé de 8 CPU et 32 GB RAM."
        gen = Generation(answer="x", claims=[
            Claim(text="Les tortues ninja pilotent des drones quantiques à Kyoto",
                  claim_type=ClaimType.FACT),
        ])
        res = AnchorJudge(threshold=0.35).judge(gen, ctx)
        assert not res[0].passed and "Ancrage insuffisant" in res[0].reason

    def test_opinion_is_not_anchorable(self):
        gen = Generation(answer="x", claims=[
            Claim(text="Python est le meilleur langage", claim_type=ClaimType.OPINION),
        ])
        res = AnchorJudge().judge(gen, "Python est un langage de programmation.")
        assert not res[0].passed

    def test_split_passages_deterministic(self):
        src = "Pom. Qok.\n\nZoum bar."
        p1 = split_passages(src)
        p2 = split_passages(src)
        # Déterministe : même entrée -> même découpage, et le contenu est couvert.
        assert p1 == p2 and len(p1) >= 1
        joined = " ".join(p1).lower()
        for word in ("pom", "qok", "zoum", "bar"):
            assert word in joined

    def test_split_passages_respects_paragraph_breaks(self):
        # Un paragraphe long (> max_len) force au moins deux passages.
        long_ctx = ("Alpha beta gamma. " * 30) + "\n\n" + ("Delta epsilon zeta. " * 30)
        passages = split_passages(long_ctx, max_len=100)
        assert len(passages) >= 2


# ---------------- Juge 2 : Faits (SQLite) ----------------

class TestFactJudge:
    def test_true_fact_verified_with_evidence(self, kb):
        gen = Generation(answer="x", claims=[
            Claim(text="serveur_a a 8 cpu", claim_type=ClaimType.FACT,
                  subject="serveur_a", predicate="cpu", value="8"),
        ])
        res = FactJudge(kb).judge(gen)
        assert res[0].passed and "docs/infra.md" in res[0].evidence

    def test_false_value_rejected(self, kb):
        gen = Generation(answer="x", claims=[
            Claim(text="serveur_a a 16 cpu", claim_type=ClaimType.FACT,
                  subject="serveur_a", predicate="cpu", value="16"),
        ])
        res = FactJudge(kb).judge(gen)
        assert not res[0].passed and "contredite" in res[0].reason

    def test_unknown_fact_refused_not_invented(self, kb):
        gen = Generation(answer="x", claims=[
            Claim(text="le cache DNS expire après 30 s", claim_type=ClaimType.FACT,
                  subject="cache_dns", predicate="ttl", value="30"),
        ])
        res = FactJudge(kb).judge(gen)
        assert not res[0].passed and "introuvable" in res[0].reason

    def test_missing_subject_rejected(self, kb):
        gen = Generation(answer="x", claims=[
            Claim(text="il fait beau", claim_type=ClaimType.FACT),
        ])
        res = FactJudge(kb).judge(gen)
        assert not res[0].passed


# ---------------- Juge 2b : Sandbox de code ----------------

class TestSandboxJudge:
    TESTS = "assert add(2, 3) == 5\nassert add(-1, 1) == 0\n"

    def test_correct_code_passes(self):
        gen = Generation(answer="x", claims=[
            Claim(text="implémentation de add", claim_type=ClaimType.CODE,
                  code="def add(a, b):\n    return a + b\n"),
        ])
        res = SandboxJudge().judge(gen, self.TESTS)
        assert res[0].passed and "ALL_TESTS_PASSED" in res[0].evidence or res[0].passed

    def test_broken_code_rejected_with_exact_error(self):
        gen = Generation(answer="x", claims=[
            Claim(text="mauvaise implémentation", claim_type=ClaimType.CODE,
                  code="def add(a, b):\n    return a - b\n"),
        ])
        res = SandboxJudge().judge(gen, self.TESTS)
        assert not res[0].passed and "AssertionError" in res[0].reason

    def test_syntax_error_rejected(self):
        gen = Generation(answer="x", claims=[
            Claim(text="code invalide", claim_type=ClaimType.CODE, code="def add(a b:\n"),
        ])
        res = SandboxJudge().judge(gen, self.TESTS)
        assert not res[0].passed and "SyntaxError" in res[0].reason

    def test_infinite_loop_times_out(self):
        gen = Generation(answer="x", claims=[
            Claim(text="boucle infinie", claim_type=ClaimType.CODE, code="while True:\n    pass\n"),
        ])
        res = SandboxJudge(timeout_s=2).judge(gen, self.TESTS)
        assert not res[0].passed and "timeout" in res[0].reason

    def test_code_without_tests_is_refused(self):
        gen = Generation(answer="x", claims=[
            Claim(text="du code", claim_type=ClaimType.CODE, code="print(1)\n"),
        ])
        res = SandboxJudge().judge(gen, None)
        assert not res[0].passed


# ---------------- Juge 3 : Cohérence (symbolique + Z3) ----------------

class TestCoherenceJudge:
    def test_contradiction_detected(self):
        c1 = Claim(text="Le serveur A a 8 CPU", claim_type=ClaimType.FACT)
        c2 = Claim(text="Le serveur A possède 4 CPU", claim_type=ClaimType.FACT)
        gen = Generation(answer="Le serveur A a 8 CPU.", claims=[c1, c2])
        res = CoherenceJudge().judge(gen)
        assert any(not r.passed and "contradictoire" in r.reason.lower() for r in res)

    def test_consistent_answer_passes(self):
        c1 = Claim(text="Le serveur A a 8 CPU", claim_type=ClaimType.FACT)
        gen = Generation(answer="Le serveur A a 8 CPU.", claims=[c1])
        res = CoherenceJudge().judge(gen)
        assert all(r.passed for r in res)

    def test_z3_detects_impossible_numeric(self):
        # Une durée négative encodée comme contrainte numérique -> UNSAT via >= 0.
        c = Claim(text="latence de -45 ms", claim_type=ClaimType.NUMERIC, value="-45")
        gen = Generation(answer="latence de -45 ms", claims=[c])
        res = CoherenceJudge().judge(gen)
        assert any(not r.passed for r in res)

    def test_z3_sat_model_reported(self):
        c = Claim(text="latence mesurée", claim_type=ClaimType.NUMERIC, value="45")
        gen = Generation(answer="ok", claims=[c])
        res = CoherenceJudge().judge(gen)
        z3res = [r for r in res if "Z3" in (r.evidence + r.reason)]
        assert z3res and z3res[0].passed and "SAT" in z3res[0].evidence


# ---------------- Couche 3 : boucle CoVe complète ----------------

class TestSolverLoop:
    def _loop(self, scripts, kb):
        from nexus_senior.generator import ScriptedGenerator
        from nexus_senior.solver_loop import SolverLoop
        return SolverLoop(ScriptedGenerator(scripts), db_path=kb, max_attempts=3)

    CTX = ("Documentation serveur A. Le serveur A est équipé de 8 CPU et 32 GB RAM. "
           "Le stockage total atteint 512 Go.")

    def test_hallucination_then_self_correction(self, kb):
        bad = json.dumps({"answer": "Le serveur A dispose de 16 CPU", "claims": [
            {"text": "Le serveur A dispose de 8 CPU", "type": "fact",
             "subject": "serveur_a", "predicate": "cpu", "value": "16"}]})
        good = json.dumps({"answer": "Le serveur A dispose de 8 CPU", "claims": [
            {"text": "Le serveur A dispose de 8 CPU", "type": "fact",
             "subject": "serveur_a", "predicate": "cpu", "value": "8"}]})
        report = self._loop([bad, good], kb).run("CPU du serveur A ?", self.CTX)
        from nexus_senior.types import Verdict
        assert report.verdict == Verdict.VERIFIED
        assert report.attempts == 2
        assert report.proofs and "docs/infra.md" in report.proofs[0]
        # Le feedback exact du solveur a bien été transmis au générateur.
        assert "contredite" in report.feedback_history[0]

    def test_persistent_hallucination_is_refused(self, kb):
        bad = json.dumps({"answer": "Les licornes volent", "claims": [
            {"text": "Les licornes volent à 80 km/h", "type": "fact",
             "subject": "licorne", "predicate": "vitesse", "value": "80"}]})
        report = self._loop([bad, bad, bad], kb).run("Licornes ?", self.CTX)
        from nexus_senior.types import Verdict
        assert report.verdict == Verdict.REFUSED
        assert "REFUS" in report.answer

    def test_unstructured_answer_rejected(self, kb):
        raw = "Je pense que tout va bien mon frère"  # pas de JSON -> pas de claims
        report = self._loop([raw, raw, raw], kb).run("Ça va ?", self.CTX)
        from nexus_senior.types import Verdict
        assert report.verdict == Verdict.REFUSED

    def test_latency_under_target_for_simple_verified_case(self, kb):
        good = json.dumps({"answer": "Le serveur A dispose de 8 CPU", "claims": [
            {"text": "Le serveur A dispose de 8 CPU", "type": "fact",
             "subject": "serveur_a", "predicate": "cpu", "value": "8"}]})
        report = self._loop([good], kb).run("CPU ?", self.CTX)
        # Référence MORPHEUS : ~45ms pour la vérification déterministe.
        assert report.latency_ms < 2000  # marge large CI ; mesuré en pratique < 50ms hors sandbox.
