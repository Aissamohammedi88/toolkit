"""Juge 2 — L'EXPERT (Faits) + Sandbox de code.

Partie A — Lookup déterministe dans une base SQLite structurée
(équivalent local d'une base de vulnérabilités / documentation officielle).
Si l'information n'est PAS dans la base : claim considérée NON VÉRIFIÉE.
Le système refuse plutôt que d'inventer.

Partie B — Juge de Code : exécution en sandbox (sous-processus isolé,
timeout strict, pas de réseau simulé par restriction cwd/tmp). Le code
proposé doit compiler/exécuter ET satisfaire les tests unitaires fournis.
Un test qui plante = preuve formelle du contraire -> rejet.
"""

from __future__ import annotations

import os
import resource
import sqlite3
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path

from nexus_senior.types import ClaimType, Generation, JudgeResult

SCHEMA = """
CREATE TABLE IF NOT EXISTS knowledge (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject TEXT NOT NULL,
    predicate TEXT NOT NULL,
    value TEXT NOT NULL,
    source TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_subject ON knowledge(subject);
"""


def init_db(db_path: str | Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path))
    conn.executescript(SCHEMA)
    return conn


class FactJudge:
    name = "facts"

    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)

    def _lookup(self, subject: str, predicate: str | None) -> list[tuple[str, str]]:
        with sqlite3.connect(self.db_path) as conn:
            if predicate:
                rows = conn.execute(
                    "SELECT value, source FROM knowledge WHERE lower(subject)=lower(?) AND lower(predicate)=lower(?)",
                    (subject, predicate),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT value, source FROM knowledge WHERE lower(subject)=lower(?)",
                    (subject,),
                ).fetchall()
        return rows

    def judge(self, generation: Generation) -> list[JudgeResult]:
        results: list[JudgeResult] = []
        for i, claim in enumerate(generation.claims):
            if claim.claim_type != ClaimType.FACT:
                continue
            if not claim.subject:
                results.append(JudgeResult(
                    judge=self.name, passed=False,
                    reason="Claim factuelle sans sujet identifiable : lookup impossible.",
                    claim_index=i,
                ))
                continue
            rows = self._lookup(claim.subject, claim.predicate)
            if not rows:
                results.append(JudgeResult(
                    judge=self.name, passed=False,
                    reason=(f"Fait introuvable en base : ({claim.subject}, {claim.predicate}). "
                            "Refus : aucune entrée de référence ne le confirme."),
                    claim_index=i,
                ))
                continue
            values = [v for v, _ in rows]
            if claim.value is not None and claim.value not in values:
                results.append(JudgeResult(
                    judge=self.name, passed=False, score=0.0,
                    reason=(f"Valeur contredite par la base : proposé={claim.value!r}, "
                            f"référence={values!r} (source: {rows[0][1]})."),
                    claim_index=i,
                ))
                continue
            results.append(JudgeResult(
                judge=self.name, passed=True, score=1.0,
                evidence=f"base[{rows[0][1]}]: {claim.subject} {claim.predicate or ''} = {values[0]}",
                claim_index=i,
            ))
        return results


SANDBOX_TEMPLATE = textwrap.dedent("""
    import sys
    sys.tracebacklimit = 5
    # --- code proposé (non fiable) ---
    {candidate}
    # --- tests unitaires (source de vérité) ---
    {tests}
    print("ALL_TESTS_PASSED")
""")


class SandboxJudge:
    """Juge de Code : exécute proposition + tests dans un sous-processus isolé."""

    name = "sandbox"

    def __init__(self, timeout_s: int = 5):
        self.timeout_s = timeout_s

    @staticmethod
    def _limits():
        # Pré-tâche du fils : plafonne mémoire (~256 Mo) et CPU.
        resource.setrlimit(resource.RLIMIT_AS, (256 * 1024 * 1024, 256 * 1024 * 1024))
        resource.setrlimit(resource.RLIMIT_CPU, (5, 5))

    def run(self, code: str, tests: str) -> JudgeResult:
        src = SANDBOX_TEMPLATE.format(candidate=code, tests=tests)
        with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False, dir="/tmp") as f:
            f.write(src)
            path = f.name
        try:
            proc = subprocess.run(
                [sys.executable, path],
                capture_output=True, text=True, timeout=self.timeout_s,
                cwd=tempfile.mkdtemp(prefix="nexus_sandbox_"),
                env={"PATH": os.defpath, "PYTHONDONTWRITEBYTECODE": "1"},
                preexec_fn=self._limits,
            )
            out = (proc.stdout or "") + (proc.stderr or "")
            if proc.returncode == 0 and "ALL_TESTS_PASSED" in proc.stdout:
                return JudgeResult(judge=self.name, passed=True, score=1.0,
                                   evidence="Sandbox : exécution OK, tous les tests unitaires passent.")
            return JudgeResult(
                judge=self.name, passed=False,
                reason=("Sortie d'erreur exacte du solveur (pour re-génération) :\n"
                        + textwrap.shorten(out.strip() or f"exit={proc.returncode}", width=800)),
            )
        except subprocess.TimeoutExpired:
            return JudgeResult(judge=self.name, passed=False,
                               reason=f"Sandbox : dépassement du timeout ({self.timeout_s}s) -> code non prouvé.")
        finally:
            os.unlink(path)

    def judge(self, generation: Generation, tests: str | None) -> list[JudgeResult]:
        results: list[JudgeResult] = []
        for i, claim in enumerate(generation.claims):
            if claim.claim_type != ClaimType.CODE or not claim.code:
                continue
            if not tests:
                results.append(JudgeResult(
                    judge=self.name, passed=False, claim_index=i,
                    reason="Aucun test unitaire fourni : le code ne peut pas être prouvé -> refus.",
                ))
                continue
            res = self.run(claim.code, tests)
            res.claim_index = i
            results.append(res)
        return results
