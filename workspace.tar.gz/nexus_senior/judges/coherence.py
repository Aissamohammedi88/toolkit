"""Juge 3 — LE LOGICIEN (Cohérence interne).

Détecte les contradictions via analyse sémantique SYMBOLIQUE + solveur
formel Z3 (principe Toroid : "le LLM propose, le Solveur dispose").

1. Extraction déterministe des paires (sujet, attribut, valeur numérique)
   depuis toutes les claims ET la réponse globale.
2. Deux mentions du même (sujet, attribut) avec des valeurs différentes
   -> contradiction immédiate (preuve à l'appui).
3. Les contraintes numériques sont injectées dans Z3 ; si le système
   d'équations/inéquations est UNSAT, la réponse est logiquement impossible.
4. Garde-fous temporels simples : une date de sortie future > maintenant
   pour un événement déjà passé, durées négatives, etc.
"""

from __future__ import annotations

import re
from collections import defaultdict

import z3

from nexus_senior.types import Generation, JudgeResult

# Motifs FR/EN pour l'extraction symbolique (déterministes).
ATTR_VALUE_RE = re.compile(
    r"\b(\d+(?:[.,]\d+)?)\s*(cpu|cœurs?|cores?|gb|go|mb|tpm|ports?|utilisateurs?|users?|"
    r"vitesse|speed|ms|secondes?|s\b|min|euros?|€|\$)",
    re.IGNORECASE,
)
SUBJECT_NEAR_RE = re.compile(
    r"\b([a-zà-ÿ][a-zà-ÿ0-9_-]{2,})[^.;\n]{0,40}?\b(\d+(?:[.,]\d+)?)\s*"
    r"(cpu|cœurs?|cores?|gb|go|ram|ports?|utilisateurs?|users?)",
    re.IGNORECASE,
)
NEGATIVE_RE = re.compile(r"-\s*\d+(?:[.,]\d+)?\s*(gb|go|ms|secondes?|cpu|cores?|utilisateurs?|users?)", re.I)


def _norm_num(s: str) -> float:
    return float(s.replace(",", "."))


def _norm_unit(u: str) -> str:
    u = u.lower().strip()
    return {"go": "gb", "cœurs": "cpu", "coeurs": "cpu", "core": "cpu", "cores": "cpu",
            "s": "secondes", "sec": "secondes", "eur": "euros"}.get(u, u)


class CoherenceJudge:
    name = "coherence"

    def judge(self, generation: Generation) -> list[JudgeResult]:
        results: list[JudgeResult] = []
        texts = [generation.answer] + [c.text for c in generation.claims]

        # --- 1. Contradictions directes sujet+attribut -> deux valeurs ---
        seen: dict[tuple[str, str], list[tuple[float, int]]] = defaultdict(list)
        for ti, text in enumerate(texts):
            claim_idx = None if ti == 0 else ti - 1
            for subj, num, unit in SUBJECT_NEAR_RE.findall(text):
                seen[(subj.lower(), _norm_unit(unit))].append((_norm_num(num), claim_idx))
            for num, unit in ATTR_VALUE_RE.findall(text):
                seen[("global", _norm_unit(unit))].append((_norm_num(num), claim_idx))

        conflicts = []
        for (subj, unit), vals in seen.items():
            uniq = sorted({v for v, _ in vals})
            if len(uniq) > 1 and subj != "global":
                conflicts.append(f"{subj}.{unit}: valeurs contradictoires {uniq}")
            elif len(uniq) > 1 and subj == "global":
                # Sur les grandeurs globales, on ne signale que si les deux
                # mentions proviennent de claims différentes.
                owners = {ci for _, ci in vals}
                if len(owners) > 1:
                    conflicts.append(f"{unit}: valeurs contradictoires {uniq} entre claims {sorted(o for o in owners if o is not None)}")

        if conflicts:
            results.append(JudgeResult(
                judge=self.name, passed=False,
                reason="Contradiction(s) interne(s) détectée(s) : " + "; ".join(conflicts),
            ))
        else:
            results.append(JudgeResult(judge=self.name, passed=True, score=1.0,
                                       evidence="Aucune contradiction surface détectée."))

        # --- 2. Valeurs negatives impossibles ---
        negs = [m.group(0) for t in texts for m in NEGATIVE_RE.finditer(t)]
        if negs:
            results.append(JudgeResult(
                judge=self.name, passed=False,
                reason=f"Valeurs physiques impossibles (négatives) : {negs}",
            ))

        # --- 3. Solveur formel Z3 sur les contraintes numériques ---
        solver_result = self._z3_check(generation)
        if solver_result is not None:
            results.append(solver_result)

        return results

    @staticmethod
    def _z3_check(generation: Generation) -> JudgeResult | None:
        """Encode les affirmations numériques structurées (claim.value) en
        contraintes Z3 et vérifie la satisfaisabilité."""
        constraints = []
        labels = []
        for i, claim in enumerate(generation.claims):
            if claim.claim_type.value != "numeric" or claim.value is None:
                continue
            try:
                v = _norm_num(claim.value)
            except ValueError:
                continue
            var = z3.Real(f"c{i}")
            constraints.append(var == v)
            labels.append(f"claim[{i}]={v}")
            if v < 0:
                constraints.append(var >= 0)
                labels.append(f"claim[{i}] doit être >= 0")
        if not constraints:
            return None

        s = z3.Solver()
        s.add(*constraints)
        if s.check() == z3.unsat:
            core = [labels[j] for j, c in enumerate(constraints)
                    if any(id(c) == id(d) for d in s.unsat_core())]
            return JudgeResult(
                judge="coherence", passed=False,
                reason=f"Solveur Z3 : système INSATISFAISABLE. Cœur de conflit : {core}",
            )
        model = s.model()
        shown = ", ".join(str(x) for x in model) or "contraintes consistantes"
        return JudgeResult(judge="coherence", passed=True, score=1.0,
                           evidence=f"Solveur Z3 : SAT. Modèle : {shown}")
