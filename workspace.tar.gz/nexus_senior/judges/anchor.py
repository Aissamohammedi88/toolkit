"""Juge 1 — LE DÉTECTIVE (Ancrage).

Vérifie que chaque affirmation est ANCRÉE dans le contexte fourni
(documentation, code source). Algorithme : Weighted Token Overlap (WTO),
déterministe et sans LLM.

Principe MORPHEUS v2.0 : on ne demande jamais à un LLM "est-ce que c'est
vrai ?" — on calcule un recouvrement de tokens pondérés par IDF entre la
claim et les passages candidats du contexte. En dessous du seuil, la claim
est considérée comme potentiellement inventée -> rejet.
"""

from __future__ import annotations

import math
import re
from collections import Counter

from nexus_senior.types import Generation, JudgeResult

TOKEN_RE = re.compile(r"[a-zà-ÿ0-9]+")

# Petits mots creux : ignorés dans le calcul d'ancrage (bruit statistique).
STOPWORDS = frozenset(
    "le la les un une des du de au aux et ou a à dans sur pour par avec sans "
    "que qui dont est sont être avoir ce cela cette cet il elle ils elles on "
    "ne pas plus moins très bien fait faire peut peux selon donc car mais or "
    "the is are of and or to in for with that this it has have was were".split()
)


def tokenize(text: str) -> list[str]:
    return [t for t in TOKEN_RE.findall(text.lower()) if len(t) > 1 and t not in STOPWORDS]


def split_passages(context: str, max_len: int = 400) -> list[str]:
    """Découpe déterministe du contexte en passages vérifiables."""
    raw_parts = re.split(r"\n\s*\n|(?<=[.;])\s+", context.strip())
    passages: list[str] = []
    buf = ""
    for part in raw_parts:
        part = part.strip()
        if not part:
            continue
        if buf and len(buf) + len(part) > max_len:
            passages.append(buf)
            buf = part
        else:
            buf = f"{buf} {part}".strip()
    if buf:
        passages.append(buf)
    return passages


class AnchorJudge:
    name = "anchor"

    def __init__(self, threshold: float = 0.35):
        self.threshold = threshold

    def _idf(self, passages_tokens: list[list[str]]) -> dict[str, float]:
        n = max(1, len(passages_tokens))
        df: Counter[str] = Counter()
        for toks in passages_tokens:
            df.update(set(toks))
        return {tok: math.log((n + 1) / (c + 1)) + 1.0 for tok, c in df.items()}

    @staticmethod
    def _weighted_vector(tokens: list[str], idf: dict[str, float]) -> dict[str, float]:
        vec: dict[str, float] = {}
        for tok, cnt in Counter(tokens).items():
            w = idf.get(tok, math.log(len(idf) + 1) + 1.0)  # token hors-corpus = poids maximal
            vec[tok] = vec.get(tok, 0.0) + cnt * w
        return vec

    @staticmethod
    def _wto_score(v1: dict[str, float], v2: dict[str, float]) -> float:
        """Weighted Token Overlap normalisé (cosine-like, déterministe)."""
        common = set(v1) & set(v2)
        overlap = sum(min(v1[t], v2[t]) for t in common)
        total = sum(v1.values())
        if total <= 0:
            return 0.0
        return overlap / total

    def judge(self, generation: Generation, context: str) -> list[JudgeResult]:
        passages = split_passages(context)
        p_tokens = [tokenize(p) for p in passages]
        idf = self._idf(p_tokens)
        p_vecs = [self._weighted_vector(t, idf) for t in p_tokens]

        results: list[JudgeResult] = []
        for i, claim in enumerate(generation.claims):
            if claim.claim_type.value == "opinion":
                results.append(JudgeResult(
                    judge=self.name, passed=False, score=0.0,
                    reason="Affirmation marquée 'opinion' : non ancrable dans une source.",
                    claim_index=i,
                ))
                continue
            c_vec = self._weighted_vector(tokenize(claim.text), idf)
            best_idx, best_score = -1, 0.0
            for j, pv in enumerate(p_vecs):
                s = self._wto_score(c_vec, pv)
                if s > best_score:
                    best_idx, best_score = j, s
            passed = best_score >= self.threshold
            results.append(JudgeResult(
                judge=self.name,
                passed=passed,
                score=best_score,
                evidence=(f"contexte[{best_idx}]: {passages[best_idx][:200]}" if passed else ""),
                reason=("" if passed else
                        f"Ancrage insuffisant : WTO={best_score:.2f} < seuil {self.threshold:.2f}. "
                        "La claim n'est pas étayée par le contexte fourni."),
                claim_index=i,
            ))
        return results
