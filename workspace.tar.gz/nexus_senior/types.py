"""Types partagés du protocole NEXUS-SENIOR (contrats de données stricts)."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Verdict(str, Enum):
    """Verdict final — le système ne connaît que ces états."""

    VERIFIED = "VERIFIED"          # Toutes les affirmations ont une preuve.
    PARTIAL = "PARTIAL"            # Certaines preuves manquent (jamais renvoyé tel quel à l'utilisateur final par défaut).
    REFUSED = "REFUSED"            # Impossible de prouver -> refus (règle d'or : on ne ment pas).
    ERROR = "ERROR"                # Panne interne du pipeline.


class ClaimType(str, Enum):
    FACT = "fact"                  # Affirmation vérifiable dans la base de connaissances.
    CODE = "code"                  # Bloc de code exécutable en sandbox.
    NUMERIC = "numeric"            # Valeur numérique auto-cohérente.
    OPINION = "opinion"            # Non vérifiable -> doit être marquée comme telle ou rejetée.


@dataclass(frozen=True)
class Claim:
    """Une affirmation atomique extraite de la réponse du générateur."""

    text: str
    claim_type: ClaimType
    # Pour les faits : sujet/valeur extraits pour lookup déterministe.
    subject: str | None = None
    predicate: str | None = None
    value: str | None = None
    # Pour le code : le langage et le corps.
    language: str = "python"
    code: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "text": self.text,
            "claim_type": self.claim_type.value,
            "subject": self.subject,
            "predicate": self.predicate,
            "value": self.value,
            "language": self.language,
            "code": self.code,
        }


@dataclass
class JudgeResult:
    """Résultat d'un juge déterministe sur une claim (ou sur la réponse entière)."""

    judge: str                     # "anchor" | "facts" | "coherence" | "sandbox"
    passed: bool
    score: float = 0.0             # 0..1 (ex: Weighted Token Overlap)
    evidence: str = ""             # Preuve trouvée (citation source, sortie test, modèle Z3)...
    reason: str = ""               # Explication déterministe du rejet, sinon "".
    claim_index: int | None = None # Claim concernée (None = niveau global).

    def to_dict(self) -> dict[str, Any]:
        return {
            "judge": self.judge,
            "passed": self.passed,
            "score": round(self.score, 4),
            "evidence": self.evidence,
            "reason": self.reason,
            "claim_index": self.claim_index,
        }


@dataclass
class Generation:
    """Sortie brute du Couche 1 (le LLM propose)."""

    answer: str
    claims: list[Claim] = field(default_factory=list)
    attempt: int = 0
    feedback: str | None = None    # Retour du solveur lors d'une re-génération.


# Regex utilitaires partagées par les juges (déterministes, compilées une fois).
NUM_RE = re.compile(r"(?<![\w.])(\d+(?:[.,]\d+)?)\s*(%|x|fois)?")
CODE_BLOCK_RE = re.compile(r"```(\w+)?\n(.*?)```", re.DOTALL)
