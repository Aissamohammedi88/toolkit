"""API FastAPI — NEXUS-SENIOR.

Endpoints :
  GET  /health          — état du pipeline + latence de référence.
  POST /verify          — vérifie une réponse déjà générée (les 3 juges).
  POST /ask             — pipeline complet CoVe : question -> verdict prouvé ou refus.
  GET  /report/{id}     — rapport JSON d'une vérification passée (audit trail).

Lancement : uvicorn nexus_senior.api:app --port 8077
"""

from __future__ import annotations

import json
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from nexus_senior.generator import BaseGenerator, OpenAIGenerator, ScriptedGenerator
from nexus_senior.judges.anchor import AnchorJudge
from nexus_senior.judges.coherence import CoherenceJudge
from nexus_senior.judges.facts import FactJudge, SandboxJudge, init_db
from nexus_senior.seed import DEFAULT_KNOWLEDGE, seed
from nexus_senior.solver_loop import SolverLoop, VerificationReport
from nexus_senior.types import Claim, ClaimType, Generation, Verdict

DATA_DIR = Path(__file__).parent / "data"
DB_PATH = DATA_DIR / "knowledge.db"
REPORTS_DB = DATA_DIR / "reports.db"

app = FastAPI(title="NEXUS-SENIOR", version="1.0.0",
              description="Détecteur/Correcteur d'hallucinations — 'Le LLM propose, le Solveur dispose.'")


def _reports_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(str(REPORTS_DB))
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS reports (
            id TEXT PRIMARY KEY, created_at REAL, verdict TEXT, payload TEXT
        );
    """)
    return conn


@app.on_event("startup")
def startup() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not DB_PATH.exists():
        seed(DB_PATH, DEFAULT_KNOWLEDGE)
    _reports_conn().close()


def get_generator() -> BaseGenerator:
    """Choisit le générateur selon l'environnement.

    Si NEXUS_LLM_API_KEY est absente -> mock scripté (démo hors-ligne),
    jamais un appel réseau implicite.
    """
    import os
    if os.environ.get("NEXUS_LLM_API_KEY"):
        return OpenAIGenerator()
    # Démo hors-ligne : première réponse hallucinée (CPU faux + fait inventé),
    # puis correction guidée par le feedback du solveur.
    bad = json.dumps({
        "answer": "Le serveur A dispose de 16 CPU et le cache DNS expire après 30 secondes.",
        "claims": [
            {"text": "Le serveur A dispose de 16 CPU", "type": "fact",
             "subject": "serveur_a", "predicate": "cpu", "value": "16"},
            {"text": "Le cache DNS expire après 30 secondes", "type": "fact",
             "subject": "cache_dns", "predicate": "ttl", "value": "30"},
        ],
    }, ensure_ascii=False)
    good = json.dumps({
        "answer": "Le serveur A dispose de 8 CPU (docs/infra.md#L12).",
        "claims": [
            {"text": "Le serveur A dispose de 8 CPU", "type": "fact",
             "subject": "serveur_a", "predicate": "cpu", "value": "8"},
        ],
    }, ensure_ascii=False)
    return ScriptedGenerator([bad, good])


class AskRequest(BaseModel):
    question: str = Field(min_length=3)
    context: str = ""
    unit_tests: str | None = None
    max_attempts: int = Field(default=3, ge=1, le=6)


class VerifyClaimIn(BaseModel):
    text: str
    type: ClaimType = ClaimType.FACT
    subject: str | None = None
    predicate: str | None = None
    value: str | None = None
    code: str | None = None


class VerifyRequest(BaseModel):
    answer: str
    claims: list[VerifyClaimIn]
    context: str = ""
    unit_tests: str | None = None


def store_report(report: VerificationReport) -> str:
    rid = uuid.uuid4().hex[:12]
    conn = _reports_conn()
    with conn:
        conn.execute("INSERT INTO reports VALUES (?,?,?,?)",
                     (rid, time.time(), report.verdict.value,
                      json.dumps(report.to_dict(), ensure_ascii=False)))
    conn.close()
    return rid


@app.get("/health")
def health() -> dict[str, Any]:
    with sqlite3.connect(str(DB_PATH)) as conn:
        n = conn.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0]
    return {"status": "ok", "protocol": "NEXUS-SENIOR", "judges": ["anchor", "facts", "coherence", "sandbox"],
            "knowledge_entries": n, "generator": type(get_generator()).__name__}


@app.post("/verify")
def verify(req: VerifyRequest) -> dict[str, Any]:
    """Couche 2 seule : applique les 3 juges à une réponse déjà générée."""
    gen = Generation(
        answer=req.answer,
        claims=[Claim(text=c.text, claim_type=c.type, subject=c.subject,
                      predicate=c.predicate, value=c.value, code=c.code) for c in req.claims],
    )
    anchor = AnchorJudge()
    facts = FactJudge(str(DB_PATH)).judge(gen)
    sandbox_results = SandboxJudge().judge(gen, req.unit_tests)
    sandbox_passed = {r.claim_index for r in sandbox_results if r.passed}
    # Règle "Le LLM propose, le Solveur dispose" : la preuve d'exécution
    # (tests qui passent en sandbox) tient lieu de preuve formelle pour le
    # code ; l'ancrage texte ne s'applique qu'aux claims textuelles.
    anchor_results = []
    for r in anchor.judge(
        Generation(answer=req.answer,
                   claims=[c for c in gen.claims if c.claim_type != ClaimType.CODE]),
        req.context or req.answer,
    ):
        anchor_results.append(r)
    # Ré-indexe les résultats ancre vers les indices réels des claims.
    real_idx = [i for i, c in enumerate(gen.claims) if c.claim_type != ClaimType.CODE]
    for pos, r in enumerate(anchor_results):
        if r.claim_index is not None:
            r.claim_index = real_idx[pos]
    results = anchor_results + facts + sandbox_results + CoherenceJudge().judge(gen)

    per_claim: dict[int, list] = {}
    for r in results:
        if r.claim_index is not None:
            per_claim.setdefault(r.claim_index, []).append(r)
    proven = [i for i, rs in per_claim.items() if rs and all(x.passed for x in rs)]
    failed = [i for i, rs in per_claim.items() if rs and not all(x.passed for x in rs)]
    verdict = Verdict.VERIFIED if proven and not failed else (Verdict.PARTIAL if proven else Verdict.REFUSED)
    report = VerificationReport(verdict=verdict, answer=req.answer, attempts=0,
                                latency_ms=0.0, results=results)
    rid = store_report(report)
    return {"report_id": rid, **report.to_dict()}


@app.post("/ask")
def ask(req: AskRequest) -> dict[str, Any]:
    """Pipeline complet CoVe : Génération -> Juges -> Vérification -> Synthèse."""
    loop = SolverLoop(generator=get_generator(), db_path=str(DB_PATH),
                      max_attempts=req.max_attempts)
    report = loop.run(req.question, req.context, req.unit_tests)
    rid = store_report(report)
    return {"report_id": rid, **report.to_dict()}


@app.get("/report/{report_id}")
def report(report_id: str) -> dict[str, Any]:
    conn = _reports_conn()
    row = conn.execute("SELECT payload FROM reports WHERE id=?", (report_id,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(404, "Rapport introuvable.")
    return json.loads(row[0])
