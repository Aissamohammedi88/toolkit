"""Démo CLI du protocole NEXUS-SENIOR (hors-ligne, déterministe).

Usage : python -m nexus_senior.demo
Montre les 3 scénarios clés :
  1. Réponse véridique et ancrée   -> VERIFIED + preuves.
  2. Hallucination auto-corrigée   -> re-génération guidée par l'erreur exacte du solveur.
  3. Hallucination persistante     -> REFUS (règle d'or : pas de preuve => pas de réponse).
"""

from __future__ import annotations

import json
from pathlib import Path

from nexus_senior.generator import ScriptedGenerator
from nexus_senior.seed import DEFAULT_KNOWLEDGE, seed
from nexus_senior.solver_loop import SolverLoop

CTX = ("Documentation serveur A. Le serveur A est équipé de 8 CPU et 32 GB RAM. "
       "Le stockage total atteint 512 Go NVMe.")


def show(title: str, report) -> None:
    print(f"\n{'=' * 70}\n{title}\n{'=' * 70}")
    print(f"Verdict   : {report.verdict.value}")
    print(f"Tentatives: {report.attempts} | Latence: {report.latency_ms:.1f} ms")
    print(f"Réponse   : {report.answer}")
    for p in report.proofs:
        print(f"  PREUVE  : {p}")
    for r in report.rejected_claims:
        print(f"  REJETÉ  : {r}")
    for fb in report.feedback_history:
        print(f"  FEEDBACK SOLVEUR -> LLM :\n    {fb.replace(chr(10), chr(10) + '    ')}")


def main() -> None:
    db = Path("/tmp/nexus_demo.db")
    seed(db, DEFAULT_KNOWLEDGE)

    def claim(text, subj, pred, val):
        return {"text": text, "type": "fact", "subject": subj, "predicate": pred, "value": val}

    # 1. Véridique et ancrée.
    good = json.dumps({"answer": "Le serveur A est équipé de 8 CPU.",
                       "claims": [claim("Le serveur A est équipé de 8 CPU", "serveur_a", "cpu", "8")]},
                      ensure_ascii=False)
    show("SCÉNARIO 1 — Réponse ancrée dans la documentation",
         SolverLoop(ScriptedGenerator([good]), str(db)).run("CPU du serveur A ?", CTX))

    # 2. Hallucination corrigée après feedback du solveur.
    bad = json.dumps({"answer": "Le serveur A dispose de 16 CPU.",
                      "claims": [claim("Le serveur A dispose de 16 CPU", "serveur_a", "cpu", "16")]},
                     ensure_ascii=False)
    show("SCÉNARIO 2 — Hallucination détectée puis auto-corrigée (CoVe)",
         SolverLoop(ScriptedGenerator([bad, good]), str(db)).run("CPU du serveur A ?", CTX))

    # 3. Hallucination persistante -> refus.
    lie = json.dumps({"answer": "Le cache DNS expire après 30 secondes.",
                      "claims": [claim("Le cache DNS expire après 30 secondes", "cache_dns", "ttl", "30")]},
                     ensure_ascii=False)
    show("SCÉNARIO 3 — Fait invérifiable : le système REFUSE de répondre",
         SolverLoop(ScriptedGenerator([lie] * 3), str(db)).run("TTL du cache DNS ?", CTX))


if __name__ == "__main__":
    main()
