"""
NEXUS-SENIOR — Protocole de Détecteur/Correcteur d'hallucinations.

Principe fondamental : "Le LLM propose, le Solveur dispose."
Aucune réponse ne sort sans preuve formelle (test qui passe, ancrage dans
une source, ou validation par un solveur déterministe).

Architecture (3 couches) :
  Couche 1 : Generateur  — le LLM (ou un mock déterministe pour les tests).
  Couche 2 : Les 3 Juges — Déterministes, AUCUN LLM dans la vérification.
      - Juge 1 (Détective / Ancrage) : Weighted Token Overlap vs contexte.
      - Juge 2 (Expert / Faits)       : lookup dans la base SQLite + sandbox.
      - Juge 3 (Logicien / Cohérence) : extraction symbolique + solver Z3.
  Couche 3 : SolverLoop  — boucle CoVe en 4 étapes avec re-génération
      guidée par l'erreur exacte des juges.

Règle d'or : verdict == VERIFIED seulement si TOUTES les affirmations
ont une preuve. Sinon : REFUSED (le système refuse plutôt que d'inventer).
"""

__version__ = "1.0.0"
