"""Couche 3 : SolverLoop — la boucle Chain-of-Verification (CoVe) en 4 étapes.

  1. GÉNÉRATION          : le LLM produit une réponse (Couche 1).
  2. QUESTIONNEMENT      : les juges produisent des checks ciblés par claim.
  3. VÉRIFICATION INDÉP. : chaque check est résolu par un outil déterministe
     (SQLite, sandbox Python, Z3, WTO) — jamais par le LLM -> pas de
     contamination par l'hallucination initiale.
  4. SYNTHÈSE CORRIGÉE   : seules les claims PREUVÉES sont conservées.
     Si toutes échouent ou si le budget d'itérations est épuisé : REFUS.

Règle d'or appliquée ici : verdict VERIFIED uniquement si CHAQUE claim
de la réponse finale possède au moins une preuve (evidence non vide)
validée par un juge. Sinon, re-génération guidée par l'erreur EXACTE du
solveur, puis refus à la fin du budget.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from nexus_senior.generator import BaseGenerator
from nexus_senior.judges.anchor import AnchorJudge
from nexus_senior.judges.coherence import CoherenceJudge
from nexus_senior.judges.facts import FactJudge, SandboxJudge
from nexus_senior.types import ClaimType, Generation, JudgeResult, Verdict


@dataclass
class VerificationReport:
    verdict: Verdict
    answer: str
    attempts: int
    latency_ms: float
    results: list[JudgeResult] = field(default_factory=list)
    proofs: list[str] = field(default_factory=list)
    rejected_claims: list[str] = field(default_factory=list)
    feedback_history: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "verdict": self.verdict.value,
            "answer": self.answer,
            "attempts": self.attempts,
            "latency_ms": round(self.latency_ms, 1),
            "results": [r.to_dict() for r in self.results],
            "proofs": self.proofs,
            "rejected_claims": self.rejected_claims,
            "feedback_history": self.feedback_history,
        }


class SolverLoop:
    def __init__(
        self,
        generator: BaseGenerator,
        db_path: str,
        max_attempts: int = 3,
        anchor_threshold: float = 0.35,
    ):
        self.generator = generator
        self.anchor = AnchorJudge(threshold=anchor_threshold)
        self.facts = FactJudge(db_path)
        self.sandbox = SandboxJudge()
        self.coherence = CoherenceJudge()
        self.max_attempts = max_attempts

    # ---- Étape 2+3 : vérification indépendante (aucun LLM ici) ----
    def _verify(self, gen: Generation, context: str, tests: str | None) -> list[JudgeResult]:
        results: list[JudgeResult] = []
        if not gen.claims and gen.answer.strip():
            results.append(JudgeResult(
                judge="pipeline", passed=False,
                reason="Réponse sans affirmations structurées : aucune preuve possible -> rejet.",
            ))
            return results
        # Le Juge d'Ancrage ne s'applique qu'aux claims textuelles ancrables
        # (faits/numériques). Le code est jugé par le solveur exécutable
        # (sandbox), pas par le recouvrement de tokens.
        anchor_gen = Generation(
            answer=gen.answer,
            claims=[c for c in gen.claims if c.claim_type != ClaimType.CODE],
        )
        anchor_results = self.anchor.judge(anchor_gen, context)
        sandbox_passed = {r.claim_index for r in self.sandbox.judge(gen, tests) if r.passed}
        # Preuve formelle équivalente : un bloc de code qui PASSE ses tests en
        # sandbox est une preuve au même titre que l'ancrage documentaire.
        for r in anchor_results:
            if (not r.passed and r.claim_index is not None
                    and gen.claims[r.claim_index].claim_type == ClaimType.CODE
                    and r.claim_index in sandbox_passed):
                r.passed = True
                r.score = 1.0
                r.evidence = "preuve-exécution : sandbox OK (remplace l'ancrage texte)"
                r.reason = ""
        results += anchor_results
        results += self.facts.judge(gen)
        results += self.sandbox.judge(gen, tests)
        results += self.coherence.judge(gen)
        return results

    # ---- Agrégation par claim : une claim est PROUVÉE si tous les
    # juges qui l'ont évaluée sont passés et au moins un fournit evidence.
    @staticmethod
    def _claims_status(gen: Generation, results: list[JudgeResult]) -> tuple[dict[int, bool], dict[int, str]]:
        per_claim: dict[int, list[JudgeResult]] = {}
        for r in results:
            if r.claim_index is not None:
                per_claim.setdefault(r.claim_index, []).append(r)
        status: dict[int, bool] = {}
        evidence: dict[int, str] = {}
        for i in range(len(gen.claims)):
            rs = per_claim.get(i, [])
            ok = bool(rs) and all(r.passed for r in rs) and any(r.evidence for r in rs)
            status[i] = ok
            ev = "; ".join(r.evidence for r in rs if r.evidence)
            evidence[i] = ev
        return status, evidence

    def run(self, question: str, context: str, unit_tests: str | None = None) -> VerificationReport:
        t0 = time.perf_counter()
        feedback_history: list[str] = []
        last_gen: Generation | None = None
        last_results: list[JudgeResult] = []

        for attempt in range(self.max_attempts):
            feedback = "\n".join(feedback_history[-1:]) if feedback_history else None
            gen = self.generator.generate(question, context, feedback, attempt)
            last_gen = gen
            results = self._verify(gen, context, unit_tests)
            last_results = results

            failures = [r for r in results if not r.passed]
            if not failures:
                status, evidence = self._claims_status(gen, results)
                if all(status.values()):
                    proofs = [f"claim[{i}]: {gen.claims[i].text} <- {evidence[i]}"
                              for i in sorted(status) if status[i]]
                    latency = (time.perf_counter() - t0) * 1000
                    return VerificationReport(
                        verdict=Verdict.VERIFIED, answer=gen.answer,
                        attempts=attempt + 1, latency_ms=latency,
                        results=results, proofs=proofs,
                        feedback_history=feedback_history,
                    )

            # Étape 4 bis : re-génération guidée par l'erreur EXACTE du solveur.
            fb_parts = []
            for r in failures[:6]:
                loc = f"[claim {r.claim_index}] " if r.claim_index is not None else ""
                fb_parts.append(f"{loc}{r.reason}")
            feedback_history.append("\n".join(fb_parts))

        # Budget épuisé -> synthèse corrigée : on ne garde QUE les claims prouvées.
        assert last_gen is not None
        status, evidence = self._claims_status(last_gen, last_results)
        proven = [c.text for i, c in enumerate(last_gen.claims) if status.get(i)]
        rejected = [c.text for i, c in enumerate(last_gen.claims) if not status.get(i)]
        latency = (time.perf_counter() - t0) * 1000

        if proven and not rejected:
            # Ne devrait pas arriver ici (sinon on aurait validé plus haut),
            # mais on reste défensif.
            verdict = Verdict.VERIFIED
            answer = last_gen.answer
        elif proven:
            verdict = Verdict.PARTIAL
            answer = ("Réponse partielle — seules les affirmations suivantes sont prouvées :\n"
                      + "\n".join(f"- {p}" for p in proven))
        else:
            verdict = Verdict.REFUSED
            answer = ("REFUS (protocole NEXUS-SENIOR) : aucune affirmation n'a pu être "
                      "prouvée de façon formelle. Je préfère me taire que mentir.")
        return VerificationReport(
            verdict=verdict, answer=answer, attempts=self.max_attempts,
            latency_ms=latency, results=last_results,
            proofs=[f"claim[{i}]: {c.text} <- {evidence.get(i, '')}"
                    for i, c in enumerate(last_gen.claims) if status.get(i)],
            rejected_claims=rejected, feedback_history=feedback_history,
        )
