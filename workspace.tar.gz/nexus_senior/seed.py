"""Initialisation de la base de connaissances SQLite (source de vérité du Juge 2).

Usage : python -m nexus_senior.seed [--db data/knowledge.db]
"""

from __future__ import annotations

import argparse
from pathlib import Path

from nexus_senior.judges.facts import init_db

# Exemple de documentation serveur "NEXUS" — la seule vérité admise par le Juge 2.
DEFAULT_KNOWLEDGE = [
    ("serveur_a", "cpu", "8", "docs/infra.md#L12"),
    ("serveur_a", "ram_gb", "32", "docs/infra.md#L13"),
    ("serveur_a", "stockage_go", "512", "docs/infra.md#L14"),
    ("serveur_b", "cpu", "16", "docs/infra.md#L20"),
    ("serveur_b", "ram_gb", "64", "docs/infra.md#L21"),
    ("cve-2021-44228", "composant", "log4j", "nvd.gov/CVE-2021-44228"),
    ("cve-2021-44228", "severite", "critique", "nvd.gov/CVE-2021-44228"),
    ("cve-2021-44228", "score_cvss", "10.0", "nvd.gov/CVE-2021-44228"),
    ("cve-2023-34992", "composant", "xz-utils", "nvd.gov/CVE-2023-34992"),
    ("cve-2023-34992", "severite", "haute", "nvd.gov/CVE-2023-34992"),
    ("protocole_morpheus", "juges", "3", "rapport-morpheus-v2.pdf#p4"),
    ("protocole_morpheus", "taux_detection", "80%", "rapport-morpheus-v2.pdf#p7"),
    ("protocole_morpheus", "latence_ms", "45", "rapport-morpheus-v2.pdf#p7"),
]


def seed(db_path: str | Path, rows=DEFAULT_KNOWLEDGE) -> int:
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = init_db(db_path)
    with conn:
        conn.execute("DELETE FROM knowledge")
        conn.executemany(
            "INSERT INTO knowledge(subject, predicate, value, source) VALUES (?,?,?,?)", rows
        )
    return len(rows)


def main() -> None:
    ap = argparse.ArgumentParser(description="Seed la base de connaissances NEXUS-SENIOR")
    ap.add_argument("--db", default=str(Path(__file__).parent / "data" / "knowledge.db"))
    args = ap.parse_args()
    n = seed(args.db)
    print(f"OK : {n} entrées insérées dans {args.db}")


if __name__ == "__main__":
    main()
