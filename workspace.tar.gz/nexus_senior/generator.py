"""Couche 1 : le Générateur.

Le LLM "propose" uniquement. Il n'a AUCUN pouvoir de décision : sa sortie
est systématiquement soumise aux juges déterministes de la Couche 2.

Deux implémentations :
  - OpenAIGenerator : branchement réel (compatible API /chat/completions).
  - ScriptedGenerator : mock déterministe pour les tests unitaires et le
    développement hors-ligne (aucune clé API requise).
"""

from __future__ import annotations

import json
import os
import urllib.request
from abc import ABC, abstractmethod
from typing import Any

from nexus_senior.types import Claim, ClaimType, Generation

SYSTEM_PROMPT = (
    "Tu es Aether, un assistant soumis au protocole NEXUS-SENIOR. "
    "Tu dois décomposer ta réponse en affirmations atomiques. "
    "Format de sortie STRICT JSON : "
    '{"answer": str, "claims": [{"text": str, '
    '"type": "fact|code|numeric|opinion", "subject": str|null, '
    '"predicate": str|null, "value": str|null, "language": "python"|null, '
    '"code": str|null}]}. Aucune prose hors JSON.'
)


def parse_generation(raw: str, attempt: int = 0, feedback: str | None = None) -> Generation:
    """Parsage strict et défensif de la sortie du LLM.

    Si le JSON est invalide ou incomplet, on retourne une Generation sans
    claims : les juges la rejetteront (le pipeline ne "devine" jamais).
    """
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return Generation(answer=raw.strip(), claims=[], attempt=attempt, feedback=feedback)

    answer = str(data.get("answer", ""))
    claims: list[Claim] = []
    for c in data.get("claims", []) or []:
        try:
            ctype = ClaimType(str(c.get("type", "fact")))
        except ValueError:
            ctype = ClaimType.FACT
        claims.append(
            Claim(
                text=str(c.get("text", "")),
                claim_type=ctype,
                subject=c.get("subject"),
                predicate=c.get("predicate"),
                value=(str(c["value"]) if c.get("value") is not None else None),
                language=str(c.get("language") or "python"),
                code=c.get("code"),
            )
        )
    return Generation(answer=answer, claims=claims, attempt=attempt, feedback=feedback)


class BaseGenerator(ABC):
    @abstractmethod
    def generate(self, question: str, context: str, feedback: str | None, attempt: int) -> Generation:
        ...


class OpenAIGenerator(BaseGenerator):
    """Générateur réel via une API compatible OpenAI (base_url configurable)."""

    def __init__(self, model: str | None = None, base_url: str | None = None, api_key: str | None = None):
        self.model = model or os.environ.get("NEXUS_LLM_MODEL", "gpt-4o-mini")
        self.base_url = (base_url or os.environ.get("NEXUS_LLM_BASE_URL", "https://api.openai.com/v1")).rstrip("/")
        self.api_key = api_key or os.environ.get("NEXUS_LLM_API_KEY", "")

    def generate(self, question: str, context: str, feedback: str | None, attempt: int) -> Generation:
        user_msg = f"CONTEXTE (seule source de vérité autorisée) :\n{context}\n\nQUESTION :\n{question}"
        if feedback:
            user_msg += f"\n\nRETOUR DU SOLVEUR (corrige précisément ce point) :\n{feedback}"
        payload: dict[str, Any] = {
            "model": self.model,
            "temperature": 0.0,  # Déterminisme maximal côté proposition.
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_msg},
            ],
        }
        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {self.api_key}"},
        )
        with urllib.request.urlopen(req, timeout=60) as resp:
            body = json.loads(resp.read().decode())
        raw = body["choices"][0]["message"]["content"]
        return parse_generation(raw, attempt=attempt, feedback=feedback)


class ScriptedGenerator(BaseGenerator):
    """Mock déterministe : renvoie des réponses scriptées par index d'itération.

    Utilisé par les tests et la boucle de correction : à chaque tentative,
    l'agent "apprend" du feedback en passant à la réponse suivante du script.
    """

    def __init__(self, scripts: list[str]):
        self.scripts = scripts
        self.calls: list[str | None] = []  # Traçabilité des feedbacks reçus.

    def generate(self, question: str, context: str, feedback: str | None, attempt: int) -> Generation:
        self.calls.append(feedback)
        idx = min(attempt, len(self.scripts) - 1)
        return parse_generation(self.scripts[idx], attempt=attempt, feedback=feedback)
