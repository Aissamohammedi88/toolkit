#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
# NEXUS CI GENERATOR — Ultimate Workflow Injector
# Génère et installe des pipelines CI/CD de niveau production.
# Auteur : Aissa Mohammedi (DGK)
# ═══════════════════════════════════════════════════════════════════════════════
# [PROTON règle 5] Spec originale DGK v1 — conservée VERBATIM, aucun mot modifié.
# La v2 (3999 lignes) est une greffe : cette spec reste la référence d'origine.
# ═══════════════════════════════════════════════════════════════════════════════

set -euo pipefail

# Couleurs
G='\033[1;32m'; R='\033[1;31m'; Y='\033[1;33m'; C='\033[1;36m'; M='\033[1;35m'; N='\033[0m'

WORKFLOWS_DIR=".github/workflows"

usage() {
    echo -e "${M}╔══════════════════════════════════════════════════════════════════════╗${N}"
    echo -e "${M}║   NEXUS CI GENERATOR — Workflow Injector                             ║${N}"
    echo -e "${M}╚══════════════════════════════════════════════════════════════════════╝${N}"
    echo -e "\n${C}Usage:${N} $0 <type>"
    echo -e "\n${C}Types disponibles:${N}"
    echo -e "  ${Y}aegis${N}   : Pipeline prédictif, zéro-trust, SLSA (Le plus avancé)"
    echo -e "  ${Y}java${N}    : Build Maven/Gradle, google-java-format, Trivy"
    echo -e "  ${Y}python${N}  : Ruff, Mypy, Pytest avec cache intelligent"
    echo -e "  ${Y}node${N}    : Next.js/Node.js Build & Lint"
    echo -e "\n${C}Exemple:${N} $0 aegis\n"
    exit 1
}

check_env() {
    if [ ! -d ".git" ]; then
        echo -e "${R}[ERREUR]${N} Ce dossier n'est pas un dépôt Git."
        exit 1
    fi
    mkdir -p "$WORKFLOWS_DIR"
}

inject_aegis() {
    echo -e "${C}▶ Injection du workflow NEXUS AEGIS...${N}"
    cat > "$WORKFLOWS_DIR/nexus-aegis.yml" << 'EOF'
name: "👑 NEXUS AEGIS"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true
permissions:
  contents: read
jobs:
  triage:
    name: "🧠 Predictive Triage"
    runs-on: ubuntu-latest
    outputs:
      matrix: ${{ steps.set-matrix.outputs.matrix }}
    steps:
      - uses: actions/checkout@v4
      - name: Detect Changes
        uses: dorny/paths-filter@v3
        id: filter
        with:
          filters: |
            api:
              - 'packages/api/**'
            ui:
              - 'packages/ui/**'
            core:
              - 'packages/core/**'
      - name: Generate Dynamic Matrix
        id: set-matrix
        run: |
          MATRIX="[]"
          if [[ "${{ steps.filter.outputs.api }}" == "true" ]]; then MATRIX=$(echo "$MATRIX" | jq -c '. + [{"pkg":"api", "cmd":"npm test --workspace=api"}]'); fi
          if [[ "${{ steps.filter.outputs.ui }}" == "true" ]]; then MATRIX=$(echo "$MATRIX" | jq -c '. + [{"pkg":"ui", "cmd":"npm run test:ui"}]'); fi
          if [[ "${{ steps.filter.outputs.core }}" == "true" ]]; then MATRIX=$(echo "$MATRIX" | jq -c '. + [{"pkg":"core", "cmd":"cargo test"}]'); fi
          if [[ "$MATRIX" == "[]" ]]; then MATRIX='[{"pkg":"core", "cmd":"cargo test"}]'; fi
          echo "matrix={\"include\":$MATRIX}" >> $GITHUB_OUTPUT
  security:
    name: "🛡️ Security Fortress"
    needs: triage
    runs-on: ubuntu-latest
    permissions:
      contents: read
      security-events: write
      id-token: write
    steps:
      - uses: actions/checkout@v4
      - name: Scan Secrets (Gitleaks)
        uses: gitleaks/gitleaks-action@v2
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
        continue-on-error: true
      - name: Scan Filesystem (Trivy)
        uses: aquasecurity/trivy-action@0.28.0
        with:
          scan-type: 'fs'
          scan-ref: '.'
          format: 'sarif'
          output: 'trivy-results.sarif'
          severity: 'CRITICAL,HIGH'
        continue-on-error: true
      - name: Upload Trivy Results
        uses: github/codeql-action/upload-sarif@v3
        if: always()
        with:
          sarif_file: 'trivy-results.sarif'
  build:
    name: "⚙️ Build: ${{ matrix.pkg }}"
    needs: [triage, security]
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix: ${{ fromJSON(needs.triage.outputs.matrix) }}
    steps:
      - uses: actions/checkout@v4
      - name: Setup Environment
        run: |
          if [ "${{ matrix.pkg }}" == "core" ]; then
            rustup default stable
          else
            actions/setup-node@v4
            node-version: '20'
          fi
      - name: Execute Build
        run: |
          echo "Executing: ${{ matrix.cmd }}"
          echo "Build successful for ${{ matrix.pkg }}."
      - name: Package Artifact
        run: |
          mkdir -p dist
          echo "Binary output of ${{ matrix.pkg }}" > dist/${{ matrix.pkg }}.bin
      - name: Upload Artifact
        uses: actions/upload-artifact@v4
        with:
          name: build-${{ matrix.pkg }}
          path: dist/
  provenance:
    name: "🔏 SLSA Attestation"
    needs: [triage, build]
    runs-on: ubuntu-latest
    permissions:
      actions: read
      id-token: write
      contents: read
      attestations: write
    steps:
      - name: Download Artifacts
        uses: actions/download-artifact@v4
        with:
          path: dist/
          merge-multiple: true
      - name: Generate SLSA Provenance
        uses: actions/attest-build-provenance@v1
        with:
          subject-path: 'dist/*'
EOF
    echo -e "${G}[✓] Workflow AEGIS généré dans $WORKFLOWS_DIR/nexus-aegis.yml${N}"
}

inject_java() {
    echo -e "${C}▶ Injection du workflow NEXUS JAVA...${N}"
    cat > "$WORKFLOWS_DIR/nexus-java.yml" << 'EOF'
name: "⚡ NEXUS OMEGA - Java"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
permissions:
  contents: read
env:
  JAVA_VERSION: "17"
  JAVA_DISTRIBUTION: "temurin"
jobs:
  build_and_test:
    name: "🏗️ Build & Test Java"
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Setup Java
        uses: actions/setup-java@v4
        with:
          java-version: ${{ env.JAVA_VERSION }}
          distribution: ${{ env.JAVA_DISTRIBUTION }}
          cache: ${{ hashFiles('**/pom.xml') != '' && 'maven' || hashFiles('**/build.gradle') != '' && 'gradle' || '' }}
      - name: Maven Verify
        if: hashFiles('**/pom.xml') != ''
        run: mvn -B clean verify
      - name: Gradle Check
        if: hashFiles('**/build.gradle') != '' || hashFiles('**/build.gradle.kts') != ''
        run: |
          if [ -f "./gradlew" ]; then chmod +x ./gradlew && ./gradlew clean check; else gradle clean check; fi
      - name: Trivy Scan
        uses: aquasecurity/trivy-action@0.28.0
        with:
          scan-type: 'fs'
          scan-ref: '.'
          format: 'table'
          exit-code: '0'
          severity: 'CRITICAL,HIGH'
EOF
    echo -e "${G}[✓] Workflow JAVA généré dans $WORKFLOWS_DIR/nexus-java.yml${N}"
}

inject_python() {
    echo -e "${C}▶ Injection du workflow NEXUS PYTHON...${N}"
    cat > "$WORKFLOWS_DIR/nexus-python.yml" << 'EOF'
name: "🐍 NEXUS PYTHON"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
permissions:
  contents: read
jobs:
  quality_and_test:
    name: "🔍 Quality & Test"
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Setup Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'
          cache: ${{ hashFiles('requirements.txt', 'pyproject.toml') != '' && 'pip' || '' }}
      - name: Install Dependencies
        run: |
          python -m pip install --upgrade pip
          if [ -f "requirements.txt" ]; then pip install -r requirements.txt; fi
          if [ -f "pyproject.toml" ]; then pip install .; fi
          pip install ruff mypy pytest
      - name: Lint (Ruff)
        run: ruff check .
      - name: Type Check (Mypy)
        run: mypy . --ignore-missing-imports
      - name: Run Tests
        run: |
          if [ -d "tests" ]; then pytest tests/ -v --tb=short; else echo "No tests found."; fi
EOF
    echo -e "${G}[✓] Workflow PYTHON généré dans $WORKFLOWS_DIR/nexus-python.yml${N}"
}

inject_node() {
    echo -e "${C}▶ Injection du workflow NEXUS NODE...${N}"
    cat > "$WORKFLOWS_DIR/nexus-node.yml" << 'EOF'
name: "🟢 NEXUS NODE"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
permissions:
  contents: read
jobs:
  build_and_test:
    name: "⚙️ Build & Test Node"
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - name: Install Dependencies
        run: npm ci || npm install
      - name: Lint
        run: npm run lint || echo "No lint script."
      - name: Build
        run: npm run build || echo "No build script."
      - name: Test
        run: npm test || echo "No test script."
EOF
    echo -e "${G}[✓] Workflow NODE généré dans $WORKFLOWS_DIR/nexus-node.yml${N}"
}

# ─── MAIN ───
if [ $# -eq 0 ]; then usage; fi

check_env

case "$1" in
    aegis)  inject_aegis ;;
    java)   inject_java ;;
    python) inject_python ;;
    node)   inject_node ;;
    *)      echo -e "${R}[ERREUR]${N} Type inconnu : $1"; usage ;;
esac

echo -e "\n${M}═══════════════════════════════════════════════════════════════════════${N}"
echo -e "  ${G}✓ GÉNÉRATION TERMINÉE${N}"
echo -e "  Prochaine étape : ${Y}git add .github/workflows/ && git commit -m \"ci: inject nexus workflow\" && git push${N}"
echo -e "${M}═══════════════════════════════════════════════════════════════════════${N}"
