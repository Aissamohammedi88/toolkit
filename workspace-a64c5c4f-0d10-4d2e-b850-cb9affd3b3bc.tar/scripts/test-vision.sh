#!/usr/bin/env bash
# Test intégral du serveur GENT Build Vision (une seule session de shell)
set -u
T=tokentokentokentokentokentokentokentoken
B=http://127.0.0.1:43111
H="X-Gent-Token: $T"
export GENT_HOME=/tmp/gent-vision-test2
rm -rf "$GENT_HOME"
mkdir -p "$GENT_HOME/identity" "$GENT_HOME/workspace"
printf '{"instance_id":"GENT-VISION-TEST","build_id":"vision-test","auth_token":"%s"}' "$T" > "$GENT_HOME/identity/instance.json"

PORT=43111 node /home/z/my-project/download/gent/app/gent-server.js > /tmp/gent-vision.log 2>&1 &
SRV=$!
for i in $(seq 1 40); do curl -fsS $B/api/health >/dev/null 2>&1 && break; sleep 0.2; done

pass=0; fail=0
chk() { # chk "nom" "attendu" "reel"
  if printf '%s' "$3" | grep -qF -- "$2"; then echo "  ✔ $1"; pass=$((pass+1)); else echo "  ✘ $1 — attendu [$2] obtenu : $3"; fail=$((fail+1)); fi
}

echo "── PAGES ──"
chk "GET / = 200" 'HTTP/1.1 200' "$(curl -s -o /dev/null -w '%{http_code}' $B/ | sed 's/^/HTTP\/1.1 /')"
chk "GET /vision = 200" 'HTTP/1.1 200' "$(curl -s -o /dev/null -w '%{http_code}' $B/vision | sed 's/^/HTTP\/1.1 /')"
chk "health a edition Build Vision" '"edition":"Build Vision 1.0"' "$(curl -s $B/api/health)"

echo "── VALIDATION SANS EXÉCUTION ──"
R=$(curl -s -H "$H" -H 'Content-Type: application/json' -d '{"p":"test.js","code":"const a = 2;\nconsole.log(a + 3);"}' $B/api/validate)
chk "code sain : blocked=false" '"blocked":false' "$R"
chk "code sain : syntaxe v8-ast ok" '"engine":"v8-ast"' "$R"

R=$(curl -s -H "$H" -H 'Content-Type: application/json' -d '{"p":"test.js","code":"let a = 1;\nlet b = (2 + ;\n"}' $B/api/validate)
chk "erreur syntaxe : blocked=true" '"blocked":true' "$R"
chk "erreur syntaxe : ligne 2 pointée" '"line":2' "$R"

R=$(curl -s -H "$H" -H 'Content-Type: application/json' -d '{"p":"test.js","code":"var x = 1;\nif (x == 1) {}\ndebugger;\neval(\"2+2\");"}' $B/api/validate)
chk "lint : debugger repéré" 'no-debugger' "$R"
chk "lint : eval repéré" 'no-eval' "$R"
chk "lint : == repéré" 'eqeqeq' "$R"
chk "lint : var repéré" 'no-var' "$R"
chk "lint : bloquant (error level)" '"blocked":true' "$R"

R=$(curl -s -H "$H" -H 'Content-Type: application/json' -d '{"p":"page.html","code":"<!doctype html>\n<html><head><link rel=stylesheet href=\"style.css\"></head><body><script src=\"app.js\"></script></body>"}' $B/api/validate)
chk "html : ref manquante détectée" 'missing-ref' "$R"

echo "── BUILD & RUN ──"
R=$(curl -s -H "$H" -H 'Content-Type: application/json' -d '{"p":"hello.js","content":"console.log(\"GENT build\", 40 + 2);"}' $B/api/build)
chk "build js : stdout capté" 'GENT build 42' "$R"
chk "build js : compile ok" '"ok":true,"output":""' "$R"
chk "build js : sandbox active" '"sandbox":true' "$R"
chk "build js : exit 0" '"code":0' "$R"

R=$(curl -s -H "$H" -H 'Content-Type: application/json' -d '{"p":"bad.js","content":"debugger;\nconsole.log(1);"}' $B/api/build)
chk "build bloqué par lint error" '"blocked":true' "$R"
chk "build bloqué : ni compile ni exécution" '"compile":null' "$R"

R=$(curl -s -H "$H" -H 'Content-Type: application/json' -d '{"p":"demo-vision/index.html"}' $B/api/build)
chk "build html : publication directe" '"skipped":".html"' "$R"
chk "build html : ok" '"ok":true' "$R"

echo "── PREVIEW ──"
chk "preview index.html = 200 html" 'HTTP/1.1 200' "$(curl -s -o /dev/null -w '%{http_code}' "$B/preview/demo-vision/index.html?t=$T" | sed 's/^/HTTP\/1.1 /')"
chk "preview contient le titre" 'BUILD VISION' "$(curl -s "$B/preview/demo-vision/index.html?t=$T")"
chk "preview css = 200" 'HTTP/1.1 200' "$(curl -s -o /dev/null -w '%{http_code}' "$B/preview/demo-vision/style.css?t=$T" | sed 's/^/HTTP\/1.1 /')"
chk "preview sans jeton = 401" '401' "$(curl -s -o /dev/null -w '%{http_code}' "$B/preview/demo-vision/index.html")"
chk "preview traversal = 400" '400' "$(curl -s -o /dev/null -w '%{http_code}' "$B/preview/..%2f..%2fetc%2fpasswd?t=$T")"
chk "preview type interdit (.sh) = 415" '415' "$(printf '#!/bin/bash\necho hi\n' > $GENT_HOME/workspace/sc.sh; curl -s -o /dev/null -w '%{http_code}' "$B/preview/sc.sh?t=$T")"

echo "── SSE HOT RELOAD ──"
(curl -s -N --max-time 4 "$B/api/events?t=$T" > /tmp/sse.out) &
SSEPID=$!
sleep 0.8
curl -s -H "$H" -H 'Content-Type: application/json' -d '{"p":"hello.js","content":"console.log(\"hot!\");"}' $B/api/build > /dev/null
wait $SSEPID 2>/dev/null
chk "SSE : event reload reçu" 'event: reload' "$(cat /tmp/sse.out)"
chk "SSE : event build reçu" 'event: build' "$(cat /tmp/sse.out)"

echo "── SÉCURITÉ ──"
chk "API sans jeton = 401" '401' "$(curl -s -o /dev/null -w '%{http_code}' $B/api/info)"
chk "API mauvais jeton = 401" '401' "$(curl -s -o /dev/null -w '%{http_code}' -H 'X-Gent-Token: nope' $B/api/info)"
chk "read traversal = 400" '400' "$(curl -s -o /dev/null -w '%{http_code}' -H "X-Gent-Token: $T" "$B/api/read?p=../../etc/passwd")"

echo; echo "════ RÉSULTAT : $pass PASS · $fail FAIL ════"
kill $SRV 2>/dev/null
exit $fail
