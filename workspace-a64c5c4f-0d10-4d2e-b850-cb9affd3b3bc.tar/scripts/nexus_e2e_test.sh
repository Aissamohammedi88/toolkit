#!/usr/bin/env bash
# ==============================================================================
# Banc de test e2e PROTON — nexus-nextjs-generator.sh
# Tout le cycle s'exécute DANS UN SEUL appel shell (le sandbox tue les
# processus d'arrière-plan entre deux appels : mortalité prouvée 21:02-21:04).
# stdin maintenu ouvert 480s pour que `next dev` ne meure pas sur EOF.
# ==============================================================================
set -u
cd /home/z/my-project/scripts

rm -rf nexus-lab nexus_run.log
: > nexus_run.log

# Lancement du générateur (nom injecté via pipe, comme un utilisateur)
{ printf "nexus-lab\n"; sleep 480; } | bash ./nexus-nextjs-generator.sh > nexus_run.log 2>&1 &
GEN_PID=$!

echo "GEN_PID=$GEN_PID"
READY=0
for i in $(seq 1 90); do
    sleep 5
    if ! kill -0 "$GEN_PID" 2>/dev/null; then
        echo "!! processus générateur mort à t=$((i*5))s"
        break
    fi
    if rg -q "Ready in" nexus_run.log 2>/dev/null; then
        READY=1
        echo "== serveur prêt à t=$((i*5))s =="
        break
    fi
done

if [ "$READY" -eq 1 ]; then
    sleep 2
    echo "=== TEST 1 : GET /api/hello (JSON attendu) ==="
    curl -s --max-time 20 http://localhost:3000/api/hello
    printf '\n'
    echo "=== TEST 2 : GET / (page d'accueil, code HTTP) ==="
    curl -s -o /dev/null -w "HTTP %{http_code}\n" --max-time 45 http://localhost:3000/
    echo "=== TEST 3 : POST /api/hello (echo JSON attendu) ==="
    curl -s --max-time 20 -X POST -H "Content-Type: application/json" \
        -d '{"agent":"DGK","protocole":"PROTON"}' http://localhost:3000/api/hello
    printf '\n'
else
    echo "!! serveur jamais prêt — log complet :"
    cat nexus_run.log
fi

echo "=== arrêt du banc ==="
pkill -P "$GEN_PID" 2>/dev/null
kill "$GEN_PID" 2>/dev/null
sleep 2
pkill -f "next dev" 2>/dev/null
pkill -f "npm run dev" 2>/dev/null

echo "=== journal terminal complet (codes couleur retirés) ==="
sed -e 's/\x1b\[[0-9;]*m//g' nexus_run.log | tail -n 40
