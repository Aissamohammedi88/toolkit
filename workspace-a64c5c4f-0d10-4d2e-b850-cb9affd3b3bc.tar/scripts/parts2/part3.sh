#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════
#  NEXUS AETHER — UPGRADE PRO v2.0.0 (PARTIE 3/5)
#  Phase 3 : patchs précis du serveur et de l'app (ancres exactes, idempotents)
#  Phase 4 : interface MOTEUR (résultats, pas du code cœur)
# ══════════════════════════════════════════════════════════════════════
cd "$APP_DIR"

cat > scripts/patch-v2.js <<'AE_PATCHJ'
'use strict';
// Patchs v2 — ancres exactes du code v1, remplacement unique vérifié.
// Idempotent : re-exécuter ne casse rien (SKIP si déjà appliqué).
const fs = require('fs');
const path = require('path');
const APP = process.argv[2] || process.cwd();

const PATCHES = [
  // ── server/core.js ──────────────────────────────────────────────────
  { file: 'server/core.js', tag: 'import moteur',
    from: ['const { chat, loadConfig, saveConfig } = require(\'../core/router\');',
           'const { remember, getMemory } = require(\'../core/memory\');'].join('\n'),
    to: ['const { chat, loadConfig, saveConfig } = require(\'../core/router\');',
         'const { remember, getMemory } = require(\'../core/memory\');',
         'const ENGINE = require(\'../core/engine\');'].join('\n') },
  { file: 'server/core.js', tag: 'version 2.0.0',
    from: "const APP_VERSION = '1.0.0';",
    to: "const APP_VERSION = '2.0.0';" },
  { file: 'server/core.js', tag: 'mode PRODUCTION (workspace verrouillé)',
    from: ['function safePath(p) {',
           '  const real = path.resolve(String(p || \'\'));',
           '  if (real === HOME || real.indexOf(HOME + path.sep) === 0) return real;',
           '  return null;',
           '}'].join('\n'),
    to: ['const WORKSPACE = process.env.AETHER_WORKSPACE || path.join(HOME, \'Aether\', \'workspace\');',
         'const PROD_MODE = process.env.AETHER_PROD === \'1\' || process.env.AETHER_PROD === \'true\';',
         'function scopeDefault() { return PROD_MODE ? WORKSPACE : HOME; }',
         'function safePath(p) {',
         '  const real = path.resolve(String(p || \'\'));',
         '  if (PROD_MODE) {',
         '    if (real === WORKSPACE || real.indexOf(WORKSPACE + path.sep) === 0) return real;',
         '    return null;',
         '  }',
         '  if (real === HOME || real.indexOf(HOME + path.sep) === 0) return real;',
         '  return null;',
         '}'].join('\n') },
  { file: 'server/core.js', tag: 'graphe par défaut = workspace en PROD',
    from: "  const dir = safePath(u.searchParams.get('path') || HOME);",
    to: "  const dir = safePath(u.searchParams.get('path') || scopeDefault());" },
  { file: 'server/core.js', tag: 'routes GET moteur',
    from: "    if (p === '/api/health') return json(res, { ok: true, app: 'NEXUS AETHER', version: APP_VERSION, port: srvPort, uptimeS: Math.round((Date.now() - startedAt) / 1000) });",
    to: ["    if (p.indexOf('/api/engine/') === 0) return ENGINE.httpGet(u, p, res);",
         "    if (p === '/api/health') return json(res, { ok: true, app: 'NEXUS AETHER', version: APP_VERSION, port: srvPort, uptimeS: Math.round((Date.now() - startedAt) / 1000) });"].join('\n') },
  { file: 'server/core.js', tag: 'routes POST moteur',
    from: "  if (p === '/api/file') return apiFileSave(data, res);",
    to: ["  if (p.indexOf('/api/engine/') === 0) return ENGINE.httpPost(p, data, res);",
         "  if (p === '/api/file') return apiFileSave(data, res);"].join('\n') },
  { file: 'server/core.js', tag: 'terminal ancré au workspace en PROD (pty script)',
    from: ["    proc = spawn('/usr/bin/script', ['-qfc', shell, '/dev/null'], {",
           '      cwd: HOME,'].join('\n'),
    to: ["    proc = spawn('/usr/bin/script', ['-qfc', shell, '/dev/null'], {",
         '      cwd: PROD_MODE ? WORKSPACE : HOME,'].join('\n') },
  { file: 'server/core.js', tag: 'terminal ancré au workspace en PROD (repli)',
    from: "    proc = spawn(shell, ['-i'], { cwd: HOME, env: process.env });",
    to: "    proc = spawn(shell, ['-i'], { cwd: PROD_MODE ? WORKSPACE : HOME, env: process.env });" },

  // ── main.js ─────────────────────────────────────────────────────────
  { file: 'main.js', tag: 'daemon headless ne verrouille pas l\u2019instance (la fenêtre reste ouvrable)',
    from: "if (!app.requestSingleInstanceLock()) { app.quit(); }",
    to: ["const HEADLESS = process.env.AETHER_HEADLESS === '1';",
         'if (!HEADLESS && !app.requestSingleInstanceLock()) { app.quit(); }'].join('\n') },
  { file: 'main.js', tag: 'preload hors coffre (asar-safe)',
    from: "      preload: path.join(__dirname, 'preload.js'),",
    to: "      preload: path.join(process.env.AETHER_ROOT || __dirname, 'preload.js')," },
  { file: 'main.js', tag: 'réutilise le serveur système si actif',
    from: ['app.whenReady().then(async function () {',
           "  const { startServer } = require('./server/core');",
           '  try {',
           '    const srv = await startServer(PORT);'].join('\n'),
    to: ['async function serverAlive(port) {',
         '  try {',
         "    const r = await fetch('http://127.0.0.1:' + port + '/api/health');",
         '    const j = await r.json();',
         "    return !!(j && j.ok && j.app === 'NEXUS AETHER');",
         '  } catch (e) { return false; }',
         '}',
         'app.whenReady().then(async function () {',
         "  const { startServer } = require('./server/core');",
         '  try {',
         '    if (await serverAlive(PORT)) {',
         '      try { fs.mkdirSync(CONF_DIR, { recursive: true }); fs.writeFileSync(PID_FILE, String(process.pid)); } catch (e) {}',
         "      if (process.env.AETHER_HEADLESS === '1') { console.log('[nexus-aether] daemon headless — le serveur système ' + PORT + ' reste maître'); return; }",
         '      createWindow(PORT);',
         "      console.log('[nexus-aether] serveur système déjà actif sur 127.0.0.1:' + PORT + ' — fenêtre branchée');",
         '      return;',
         '    }',
         '    const srv = await startServer(PORT);'].join('\n') },
  { file: 'main.js', tag: 'daemon headless sans fenêtre',
    from: '    createWindow(srv.port);',
    to: ["    if (process.env.AETHER_HEADLESS === '1') {",
         "      console.log('[nexus-aether] daemon headless prêt sur 127.0.0.1:' + srv.port + ' — service système actif');",
         '      return;',
         '    }',
         '    createWindow(srv.port);'].join('\n') },

  // ── ui/index.html ───────────────────────────────────────────────────
  { file: 'ui/index.html', tag: 'onglet MOTEUR (actif par défaut — production)',
    from: ['      <button class="tab" data-tab="code">&#9672; Code</button>',
           '      <button class="tab active" data-tab="term">&#9646; Terminal</button>'].join('\n'),
    to: ['      <button class="tab" data-tab="code">&#9672; Code</button>',
         '      <button class="tab active" data-tab="engine">&#9737; Moteur</button>',
         '      <button class="tab" data-tab="term">&#9646; Terminal</button>'].join('\n') },
  { file: 'ui/index.html', tag: 'panneau Moteur (résultats)',
    from: '    <div id="panel-term" class="panel"><div id="term"></div></div>',
    to: ['    <div id="panel-engine" class="panel"><div id="engine-root"></div></div>',
         '    <div id="panel-term" class="panel hidden"><div id="term"></div></div>'].join('\n') },
  { file: 'ui/index.html', tag: 'script moteur',
    from: '<script src="/ui/app.js"></script>',
    to: ['<script src="/ui/engine.js"></script>',
         '<script src="/ui/app.js"></script>'].join('\n') },
  { file: 'ui/index.html', tag: 'version 2.0.0',
    from: '<span class="ver">v1.0.0</span>',
    to: '<span class="ver">v2.0.0</span>' },

  // ── ui/app.js ───────────────────────────────────────────────────────
  { file: 'ui/app.js', tag: 'onglet moteur enregistré',
    from: "  const TABS = ['code', 'term', 'grid', 'memory'];",
    to: "  const TABS = ['code', 'term', 'engine', 'grid', 'memory'];" },
  { file: 'ui/app.js', tag: 'activation du Moteur au clic',
    from: ["    if (name === 'memory') loadMemory();",
           "    if (name === 'grid') loadGrid();"].join('\n'),
    to: ["    if (name === 'engine' && window.AetherEngine) window.AetherEngine.show();",
         "    if (name === 'memory') loadMemory();",
         "    if (name === 'grid') loadGrid();"].join('\n') },
  { file: 'ui/app.js', tag: 'événements exposés au Moteur',
    from: ['    tl.insertBefore(d, tl.firstChild);',
           '  }'].join('\n'),
    to: ['    tl.insertBefore(d, tl.firstChild);',
         '  }',
         '  window.AetherEvent = event;'].join('\n') },
  { file: 'ui/app.js', tag: 'commande orbe /gen · /moteur',
    from: "    if (cmd === 'grid') { switchTab('grid'); return; }",
    to: ["    if (cmd === 'grid') { switchTab('grid'); return; }",
         "    if (cmd === 'moteur' || cmd === 'gen') {",
         "      switchTab('engine');",
         '      if (arg && window.AetherEngine) window.AetherEngine.quickGen(arg);',
         '      return;',
         '    }'].join('\n') }
];

let fails = 0;
PATCHES.forEach(function (p) {
  const abs = path.join(APP, p.file);
  let src;
  try { src = fs.readFileSync(abs, 'utf8'); } catch (e) { console.log('FAIL  ' + p.file + ' — lecture impossible'); fails++; return; }
  // Règle idempotente : si le résultat est déjà présent, on ne touche JAMAIS
  // (le « to » est unique et spécifique → présence = déjà appliqué)
  if (src.indexOf(p.to) !== -1) { console.log('SKIP  ' + p.file + ' — ' + p.tag + ' (déjà appliqué)'); return; }
  const count = src.split(p.from).length - 1;
  if (count !== 1) { console.log('FAIL  ' + p.file + ' — ' + p.tag + ' : ancre ' + (count === 0 ? 'introuvable' : 'non unique (×' + count + ')')); fails++; return; }
  fs.writeFileSync(abs, src.replace(p.from, p.to));
  console.log('PATCH ' + p.file + ' — ' + p.tag);
});
if (fails) { console.log('ERREUR : ' + fails + ' patch(s) refusé(s) — code v1 intact, sauvegarde dans .backup-v2-*'); process.exit(1); }
console.log('PATCHES_OK');
AE_PATCHJ
if node scripts/patch-v2.js "$APP_DIR"; then
  ok "patchs v2 appliqués (ancres exactes, code v1 optimisé — rien détruit)"
else
  ko "patchs refusés — installation v1 restée intacte (voir messages ci-dessus)"
  echo; exit 1
fi

# ── CSS moteur (ajout en fin de style.css — aucun remplacement) ──────
cat >> ui/style.css <<'AE_CSS2'

/* ═══════════════ MOTEUR v2 (production) ═══════════════ */
#panel-engine{overflow:auto}
.eng-wrap{display:flex;flex-direction:column;gap:10px}
.eng-head{display:flex;align-items:baseline;gap:12px;flex-wrap:wrap}
.eng-head h1{font-family:var(--serif);font-size:20px;font-weight:500;color:#fff}
.eng-stat{font-size:11px;color:var(--dim);font-family:var(--mono)}
.eng-stat b{color:var(--cyan)}
.eng-btn{
  border:1px solid rgba(0,229,255,.35);background:rgba(0,229,255,.08);color:var(--cyan);
  padding:6px 14px;border-radius:9px;cursor:pointer;font-size:11px;letter-spacing:1px;
}
.eng-btn:hover{background:rgba(0,229,255,.18)}
.eng-btn:disabled{opacity:.4;cursor:wait}
.eng-btn.go{border-color:rgba(0,255,136,.4);background:rgba(0,255,136,.1);color:var(--green)}
.eng-btn.go:hover{background:rgba(0,255,136,.2)}
.eng-chips{display:flex;gap:6px;flex-wrap:wrap}
.eng-chip{
  border:1px solid rgba(255,255,255,.12);background:transparent;color:var(--dim);
  padding:4px 12px;border-radius:16px;cursor:pointer;font-size:11px;letter-spacing:1px;
}
.eng-chip.on{border-color:rgba(0,229,255,.5);color:var(--cyan);background:rgba(0,229,255,.08)}
.eng-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(215px,1fr));gap:8px}
.eng-card{
  background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.07);
  border-radius:11px;padding:9px 11px;cursor:pointer;transition:border-color .15s, background .15s;
}
.eng-card:hover{background:rgba(0,229,255,.06)}
.eng-card.sel{border-color:rgba(0,229,255,.6);box-shadow:0 0 18px rgba(0,229,255,.12)}
.eng-card .nm{font-size:11.5px;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.eng-card .dt{font-size:9.5px;color:var(--dim);margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.eng-card .row{display:flex;align-items:center;gap:6px}
.eng-dot{width:8px;height:8px;border-radius:50%;flex:none}
.eng-dot.online{background:var(--green);box-shadow:0 0 8px var(--green)}
.eng-dot.pret{background:#7dd8ff;box-shadow:0 0 8px #7dd8ff}
.eng-dot.needs-key{background:var(--magenta);box-shadow:0 0 8px var(--magenta)}
.eng-dot.offline,.eng-dot.erreur{background:#FF5C7A}
.eng-badge{font-size:8.5px;letter-spacing:1px;padding:2px 7px;border-radius:10px;border:1px solid;text-transform:uppercase;margin-left:auto}
.eng-badge.gratuit{color:var(--green);border-color:rgba(0,255,136,.4)}
.eng-badge.clé-gratuit{color:#FFD166;border-color:rgba(255,209,102,.4)}
.eng-badge.local{color:var(--cyan);border-color:rgba(0,229,255,.4)}
.eng-badge.payant{color:#FF9DB0;border-color:rgba(255,157,176,.4)}
.eng-prompt{display:flex;gap:8px;align-items:stretch}
.eng-prompt textarea{
  flex:1;min-height:64px;resize:vertical;border-radius:10px;border:1px solid rgba(0,229,255,.22);
  background:rgba(0,0,0,.3);color:var(--txt);font-family:var(--mono);font-size:12.5px;padding:10px;outline:none;
}
.eng-prompt textarea:focus{border-color:var(--cyan)}
.eng-opts{display:flex;gap:10px;align-items:center;font-size:10.5px;color:var(--dim);flex-wrap:wrap}
.eng-opts input{width:70px;background:rgba(0,0,0,.3);border:1px solid rgba(255,255,255,.12);color:var(--txt);border-radius:6px;padding:4px 6px;font-family:var(--mono);font-size:11px}
.eng-out{background:rgba(0,0,0,.32);border:1px solid rgba(255,255,255,.08);border-radius:11px;padding:11px;font-family:var(--mono);font-size:12px;white-space:pre-wrap;word-break:break-word;color:#c9cff2;max-height:300px;overflow:auto}
.eng-out img{max-width:100%;max-height:320px;border-radius:8px;display:block}
.eng-out .ok-line{color:var(--green);font-size:10.5px;margin-top:6px}
.eng-out .err-line{color:#FF9DB0}
.eng-cols{display:grid;grid-template-columns:1fr 1fr;gap:10px;align-items:start}
.eng-cols h3{font-size:10px;letter-spacing:2px;text-transform:uppercase;color:var(--dim);margin-bottom:6px}
.eng-list{display:flex;flex-direction:column;gap:4px;max-height:230px;overflow:auto}
.eng-item{
  display:flex;gap:8px;align-items:center;background:rgba(255,255,255,.03);
  border-radius:8px;padding:6px 9px;cursor:pointer;font-size:11px;color:#c9cff2;
}
.eng-item:hover{background:rgba(0,229,255,.07)}
.eng-item .sz{margin-left:auto;color:var(--dim);font-size:9.5px;font-family:var(--mono)}
.eng-mini{font-size:9.5px;color:var(--dim)}
@media (max-width:1100px){.eng-cols{grid-template-columns:1fr}}
AE_CSS2
ok "style.css — styles Moteur ajoutés (append, rien remplacé)"
