#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════
#  NEXUS AETHER — UPGRADE PRO v2.0.0 (PARTIE 3bis/5)
#  ui/engine.js — l'interface MOTEUR : services réels, résultats, workflow
# ══════════════════════════════════════════════════════════════════════
cd "$APP_DIR"

cat > ui/engine.js <<'AE_ENGINE_UI'
(function () {
  'use strict';
  // NEXUS AETHER v2 — Moteur : 90+ services RÉELS, résultats extraits
  // dans le workspace, workflow YAML généré et validé. Zéro maquette.
  var $ = function (id) { return document.getElementById(id); };
  var root = $('engine-root');
  var log = function (kind, text) { if (window.AetherEvent) window.AetherEvent(kind, text); };

  var S = {
    services: [], health: {}, selected: localStorage.getItem('aether-service') || 'pollinations-text',
    cat: 'tout', busy: false, built: false
  };

  function jget(url) { return fetch(url).then(function (r) { return r.json(); }); }
  function jpost(url, body) {
    return fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) })
      .then(function (r) { return r.json(); });
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function findSel() {
    return S.services.filter(function (s) { return s.id === S.selected; })[0] || null;
  }

  function build() {
    if (S.built) return;
    S.built = true;
    root.innerHTML = [
      '<div class="eng-wrap">',
      '  <div class="eng-head">',
      '    <h1>Moteur de génération</h1>',
      '    <span class="eng-stat" id="eng-stat">chargement…</span>',
      '    <button class="eng-btn" id="eng-refresh" title="Re-tester tous les services en direct">Re-tester</button>',
      '  </div>',
      '  <div class="eng-chips" id="eng-chips"></div>',
      '  <div class="eng-cards" id="eng-cards"></div>',
      '  <div class="eng-prompt">',
      '    <textarea id="eng-prompt" placeholder="Décris ce qu\u2019il faut générer… (texte, YAML GitHub Actions, image, recherche scientifique — selon le service choisi)"></textarea>',
      '  </div>',
      '  <div class="eng-opts" id="eng-opts"></div>',
      '  <div class="eng-prompt">',
      '    <button class="eng-btn go" id="eng-go">⚡ Générer</button>',
      '    <button class="eng-btn" id="eng-yml">◈ Workflow GitHub Actions (YAML réel)</button>',
      '  </div>',
      '  <div class="eng-out" id="eng-out" hidden></div>',
      '  <div class="eng-cols">',
      '    <div><h3>Résultats extraits (workspace)</h3><div class="eng-list" id="eng-results"></div></div>',
      '    <div><h3>Historique du moteur</h3><div class="eng-list" id="eng-history"></div></div>',
      '  </div>',
      '</div>'
    ].join('\n');

    $('eng-refresh').addEventListener('click', function () { refreshHealth(true); });
    $('eng-go').addEventListener('click', function () { doGenerate(false); });
    $('eng-yml').addEventListener('click', function () { doWorkflow(); });
    $('eng-prompt').addEventListener('keydown', function (e) {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); doGenerate(false); }
    });
    renderChips();
  }

  var CATS = [['tout', 'Tout'], ['texte', 'Texte'], ['image', 'Image'], ['vision', 'Vision'], ['science', 'Science'], ['audio', 'Audio'], ['embed', 'Embed']];

  function renderChips() {
    var box = $('eng-chips');
    box.innerHTML = '';
    CATS.forEach(function (c) {
      var b = document.createElement('button');
      b.className = 'eng-chip' + (S.cat === c[0] ? ' on' : '');
      b.textContent = c[1];
      b.addEventListener('click', function () { S.cat = c[0]; renderChips(); renderCards(); });
      box.appendChild(b);
    });
  }

  function renderCards() {
    var box = $('eng-cards');
    box.innerHTML = '';
    S.services.forEach(function (s) {
      if (S.cat !== 'tout' && s.cat !== S.cat) return;
      var h = S.health[s.id] || { status: '?', detail: 'pas encore mesuré' };
      var card = document.createElement('div');
      card.className = 'eng-card' + (s.id === S.selected ? ' sel' : '');
      card.title = (s.docs || '') + '\nÉtat : ' + h.status + ' — ' + (h.detail || '');
      card.innerHTML = '<div class="row"><span class="eng-dot ' + esc(h.status) + '"></span>' +
        '<span class="nm">' + esc(s.name) + '</span>' +
        '<span class="eng-badge ' + esc(s.tier) + '">' + esc(s.tier) + '</span></div>' +
        '<div class="dt">' + esc(h.detail || '') + '</div>';
      card.addEventListener('click', function () {
        S.selected = s.id;
        localStorage.setItem('aether-service', s.id);
        renderCards(); renderOpts();
        log('sys', 'Moteur → service actif : ' + s.name + ' (' + h.status + ')');
      });
      box.appendChild(card);
    });
  }

  function renderOpts() {
    var s = findSel();
    var box = $('eng-opts');
    box.innerHTML = '<span>service : <b style="color:var(--cyan)">' + esc(s ? s.name : '—') + '</b></span>';
    if (!s) return;
    if (s.adapter === 'pollinations-image' || s.adapter === 'horde-image' || s.adapter === 'comfy' || s.adapter === 'a1111' || s.adapter === 'openai-image' || s.adapter === 'hf-image' || s.adapter === 'cloudflare-image') {
      box.innerHTML += '<label>largeur <input id="eng-w" value="768"></label><label>hauteur <input id="eng-h" value="768"></label>';
    }
    if (s.adapter === 'horde-image' || s.adapter === 'horde-text' || s.adapter === 'comfy') {
      box.innerHTML += '<label>attente max (s) <input id="eng-wait" value="120"></label>';
    }
  }

  function renderStat() {
    var online = 0, pret = 0, nk = 0, off = 0, free = 0;
    S.services.forEach(function (s) {
      var st = (S.health[s.id] || {}).status || '?';
      if (st === 'online') { online++; if (s.free) free++; }
      else if (st === 'pret') pret++;
      else if (st === 'needs-key') nk++;
      else if (st === 'offline' || st === 'erreur') off++;
    });
    $('eng-stat').innerHTML = S.services.length + ' services · <b>' + online + ' en ligne</b> · ' +
      pret + ' prêts avec clé · ' + nk + ' en attente de clé · ' + off + ' hors ligne · <b>' + free + ' gratuits sans clé actifs</b>';
  }

  function refreshHealth(force) {
    $('eng-refresh').disabled = true;
    return jget('/api/engine/health' + (force ? '' : '?full=1')).then(function (j) {
      if (j.services) {
        S.health = {};
        j.services.forEach(function (s) { S.health[s.id] = { status: s.status, detail: s.detail }; });
      } else { S.health = j; }
      renderCards(); renderStat();
    }).catch(function (e) {
      log('err', 'santé moteur : ' + (e && e.message || e));
    }).then(function () { $('eng-refresh').disabled = false; });
  }

  function showOut(html) {
    var o = $('eng-out');
    o.hidden = false;
    o.innerHTML = html;
  }

  function doGenerate(isQuick) {
    if (S.busy) return;
    var prompt = $('eng-prompt').value.trim();
    if (!prompt) { showOut('<span class="err-line">Décris d\u2019abord ce qu\u2019il faut générer.</span>'); return; }
    var s = findSel();
    if (!s) { showOut('<span class="err-line">Choisis un service dans la grille.</span>'); return; }
    S.busy = true;
    $('eng-go').disabled = true;
    var t0 = Date.now();
    showOut('⏳ ' + esc(s.name) + ' — appel RÉEL en cours' + (s.tier === 'local' ? ' (local)…' : ' (réseau)…'));
    log('user', '[' + s.id + '] ' + prompt.slice(0, 160));
    var body = { service: s.id, prompt: prompt, maxWaitS: 120 };
    var w = $('eng-w'), h = $('eng-h'), wt = $('eng-wait');
    if (w) body.width = parseInt(w.value, 10) || 768;
    if (h) body.height = parseInt(h.value, 10) || 768;
    if (wt) body.maxWaitS = parseInt(wt.value, 10) || 120;
    jpost('/api/engine/generate', body).then(function (j) {
      var ms = ((Date.now() - t0) / 1000).toFixed(1);
      if (j.ok === false && j.error) {
        showOut('<span class="err-line">✗ ' + esc(j.error) + '</span>');
        log('err', 'moteur ' + s.id + ' : ' + j.error.slice(0, 200));
      } else if (j.pending) {
        showOut('⏳ Service ' + esc(j.service) + ' — file d\u2019attente communautaire (job ' + esc(j.jobId || '') + ')\n' +
          '<span class="ok-line">Le résultat arrive via /api/engine/poll — le job reste valide quelques minutes.</span>');
        log('sys', 'moteur ' + s.id + ' : job soumis (' + esc(j.jobId || '') + ')');
      } else if (j.file) {
        var ext = (j.file.split('.').pop() || '').toLowerCase();
        var inner = (['png', 'jpg', 'jpeg', 'webp', 'gif'].indexOf(ext) !== -1)
          ? '<img src="/api/engine/raw?path=' + encodeURIComponent(j.file) + '">'
          : '(fichier ' + esc(ext) + ' — ' + (j.bytes ? Math.round(j.bytes / 1024) + ' Ko' : '?') + ')';
        showOut(inner + '<div class="ok-line">✓ ' + esc(j.name || s.name) + ' — ' + ms + ' s — extrait : ' + esc(j.file) + '</div>');
        log('file', 'généré : ' + j.file + ' (' + ms + ' s)');
        renderResults();
      } else {
        showOut(esc(j.text || '(réponse vide)') + '<div class="ok-line">✓ ' + esc(j.name || s.name) + ' — ' + ms + ' s — aussi extrait dans workspace/textes/</div>');
        log('ai', '[' + s.id + '] ' + String(j.text || '').slice(0, 300));
        renderResults();
      }
      refreshHistory();
    }).catch(function (e) {
      showOut('<span class="err-line">✗ ' + esc((e && e.message) || e) + '</span>');
    }).then(function () {
      S.busy = false;
      $('eng-go').disabled = false;
    });
  }

  function doWorkflow() {
    if (S.busy) return;
    var desc = $('eng-prompt').value.trim();
    if (!desc) { showOut('<span class="err-line">Décris le workflow à générer (ex : « CI Node qui teste et déploie sur VPS »).</span>'); return; }
    S.busy = true;
    $('eng-yml').disabled = true;
    showOut('⏳ Génération YAML RÉELLE via le service « ' + esc(S.selected) + ' »…');
    jpost('/api/engine/workflow', { description: desc, service: S.selected }).then(function (j) {
      if (j.ok && j.file) {
        showOut(esc(j.yaml) + '<div class="ok-line">✓ YAML VALIDÉ (' + esc((j.validation || {}).parser || '?') + ') — extrait : ' + esc(j.file) + ' — service : ' + esc(j.service) + '</div>');
        log('file', 'workflow YAML validé : ' + j.file);
        renderResults();
      } else if (j.yaml) {
        showOut(esc(j.yaml) + '<div class="err-line">✗ Validation : ' + esc((j.validation || {}).error || '?') + ' — le YAML brut est affiché, corrige-le dans l\u2019onglet Code.</div>');
        log('err', 'workflow : validation YAML échouée');
      } else {
        showOut('<span class="err-line">✗ ' + esc(j.error || j.rawText || 'échec') + '</span>');
        log('err', 'workflow : ' + String(j.error || '').slice(0, 200));
      }
      refreshHistory();
    }).catch(function (e) {
      showOut('<span class="err-line">✗ ' + esc((e && e.message) || e) + '</span>');
    }).then(function () { S.busy = false; $('eng-yml').disabled = false; });
  }

  function renderResults() {
    jget('/api/engine/results').then(function (j) {
      var box = $('eng-results');
      box.innerHTML = '';
      (j.items || []).slice(0, 18).forEach(function (f) {
        var d = document.createElement('div');
        d.className = 'eng-item';
        d.innerHTML = '<span>' + esc(f.dir) + '/' + esc(f.name) + '</span><span class="sz">' + Math.max(1, Math.round(f.size / 1024)) + ' Ko</span>';
        d.addEventListener('click', function () { preview(f); });
        box.appendChild(d);
      });
      if (!box.children.length) box.innerHTML = '<div class="eng-mini">Le workspace se remplira ici à chaque génération.</div>';
    }).catch(function (e) {});
  }

  function preview(f) {
    var ext = (f.name.split('.').pop() || '').toLowerCase();
    if (['png', 'jpg', 'jpeg', 'webp', 'gif'].indexOf(ext) !== -1) {
      showOut('<img src="/api/engine/raw?path=' + encodeURIComponent(f.path) + '"><div class="ok-line">' + esc(f.path) + '</div>');
    } else {
      jget('/api/file?path=' + encodeURIComponent(f.path)).then(function (j) {
        showOut(esc(j.content || j.error || '') + '<div class="ok-line">' + esc(f.path) + '</div>');
      });
    }
  }

  function refreshHistory() {
    jget('/api/engine/history?n=12').then(function (j) {
      var box = $('eng-history');
      box.innerHTML = '';
      (j.items || []).slice().reverse().forEach(function (it) {
        var d = document.createElement('div');
        d.className = 'eng-item';
        var label = it.kind === 'workflow' ? '◈ workflow' : (it.pending ? '⏳ ' + it.service : (it.file ? it.service : it.service));
        d.innerHTML = '<span>' + esc(label) + '</span><span class="sz">' + esc(String(it.ts || '').slice(11, 19)) + (it.ms ? ' · ' + Math.round(it.ms / 100) / 10 + ' s' : '') + '</span>';
        d.addEventListener('click', function () {
          showOut(esc(it.prompt ? '« ' + it.prompt + ' »' : '') + '\n\n' + esc((it.text || it.file || it.jobId || '') + ''));
        });
        box.appendChild(d);
      });
      if (!box.children.length) box.innerHTML = '<div class="eng-mini">Aucune génération encore — lance la première ⚡</div>';
    }).catch(function (e) {});
  }

  window.AetherEngine = {
    show: function () {
      build();
      if (!S.services.length) {
        jget('/api/engine/services').then(function (j) {
          S.services = j.services || [];
          window.AETHER_WORKSPACE = j.workspace;
          renderCards(); renderOpts(); renderStat(); renderResults(); refreshHistory();
          return refreshHealth(false);
        }).catch(function (e) { showOut('<span class="err-line">moteur injoignable : ' + esc(e && e.message || e) + '</span>'); });
      } else { renderCards(); refreshHealth(false); }
    },
    quickGen: function (prompt) {
      build();
      window.__switchTab && null;
      $('eng-prompt').value = String(prompt);
      if (!S.services.length) {
        jget('/api/engine/services').then(function (j) {
          S.services = j.services || [];
          renderCards(); renderOpts(); renderStat(); refreshHealth(false);
          setTimeout(function () { doGenerate(true); }, 300);
        });
      } else setTimeout(function () { doGenerate(true); }, 150);
    }
  };
})();
AE_ENGINE_UI
ok "ui/engine.js — Moteur : grille des services avec états réels, génération, YAML validé, résultats extraits"
if node --check ui/engine.js; then ok "node --check ui/engine.js"; else ko "syntaxe ui/engine.js"; fi
