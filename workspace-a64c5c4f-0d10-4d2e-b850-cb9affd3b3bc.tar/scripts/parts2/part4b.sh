#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════
#  NEXUS AETHER — UPGRADE PRO v2.0.0 (PARTIE 4bis/5)
#  Phase 6 : PRODUCTION — coffre app.asar, lanceur v2, auto-réparation
# ══════════════════════════════════════════════════════════════════════
cd "$APP_DIR"

ELECTRON_BIN="$APP_DIR/node_modules/electron/dist/electron"
SYNTAX_OK=1
for f in server/core.js main.js core/engine.js ui/engine.js core/router.js core/memory.js; do
  node --check "$APP_DIR/$f" 2>/dev/null || SYNTAX_OK=0
done
if [ "$NO_VAULT" = "1" ]; then
  warn "AETHER_NO_VAULT=1 — coffre sauté (mode développement conservé)"
elif [ "$SYNTAX_OK" = "0" ]; then
  warn "vérification de syntaxe insuffisante — scellement refusé (aucune casse ; corrige puis relance)"
elif [ -x "$ELECTRON_BIN" ]; then
  rm -rf "$APP_DIR/.vault-stage"
  mkdir -p "$APP_DIR/.vault-stage"
  cp main.js package.json preload.js "$APP_DIR/.vault-stage/"
  cp -r core server ui config "$APP_DIR/.vault-stage/"
  if (cd "$APP_DIR" && npx --yes @electron/asar pack .vault-stage app.asar >/dev/null 2>&1) && [ -s "$APP_DIR/app.asar" ]; then
    ok "coffre de production scellé : app.asar ($(du -h "$APP_DIR/app.asar" | cut -f1)) — le code cœur n'est plus lisible dans le dossier"
    BKP="$HIDDEN_DIR/src-backup-$TS"
    mkdir -p "$BKP"
    mv core server ui config "$BKP/" 2>/dev/null || true
    mv main.js "$BKP/main-impl.js" 2>/dev/null || true
    # chargeur minimal : le cœur vit dans le coffre
    cat > main.js <<'AE_LOADER'
'use strict';
// NEXUS AETHER v2 — chargeur de PRODUCTION. Le cœur applicatif vit scellé
// dans app.asar (coffre Electron). Source de secours : ~/.nexus-aether/
require('./app.asar/main.js');
AE_LOADER
    node --check main.js && ok "chargeur main.js — 4 lignes, aucun code cœur visible"
    rm -rf "$APP_DIR/.vault-stage"
    # preuve : le dossier de l'app ne montre plus que la production
    VISIBLE="$(ls "$APP_DIR" | tr '\n' ' ')"
    info "contenu visible de ~/Aether : $VISIBLE"
    cat > scripts/aether-repair.sh <<'AE_REPAIR'
#!/usr/bin/env bash
# NEXUS AETHER v2 — réparation : restaurer le cœur depuis la réserve cachée
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LAST="$(ls -1dt "$HOME/.nexus-aether"/src-backup-* 2>/dev/null | head -1 || true)"
if [ -z "$LAST" ]; then echo "· aucune réserve ~/.nexus-aether/src-backup-* — rien à restaurer"; exit 1; fi
cp -r "$LAST/core" "$LAST/server" "$LAST/ui" "$LAST/config" "$DIR/" 2>/dev/null || true
if [ -f "$LAST/main-impl.js" ]; then cp "$LAST/main-impl.js" "$DIR/main.js"; fi
[ -f "$DIR/app.asar" ] && mv "$DIR/app.asar" "$DIR/app.asar.broken-$(date +%s)"
echo "✓ cœur restauré depuis $LAST — relance NEXUS AETHER"
AE_REPAIR
    chmod +x scripts/aether-repair.sh
    ok "auto-réparation : scripts/aether-repair.sh (repart du coffre ou de la réserve)"
  else
    warn "scellement asar échoué — le code reste en clair mais TOUT fonctionne pareil (aucune casse)"
    rm -rf "$APP_DIR/.vault-stage"
  fi
else
  warn "Electron non installé (mode test) — coffre sauté, les phases suivantes continuent"
fi

cat > scripts/aether-launch.sh <<'AE_LCH2'
#!/usr/bin/env bash
# NEXUS AETHER v2 — lanceur PRODUCTION
# · PROD : graphe verrouillé sur workspace, code cœur invisible
# · si le service système (aether.service) est actif, la fenêtre s'y branche
# · auto-réparation si le coffre est cassé
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export AETHER_ROOT="$DIR"
export AETHER_PORT="${AETHER_PORT:-8420}"
export AETHER_PROD=1
export AETHER_WORKSPACE="$DIR/workspace"
mkdir -p "$HOME/.aether" "$AETHER_WORKSPACE"
ELECTRON_BIN="$DIR/node_modules/.bin/electron"
[ -x "$ELECTRON_BIN" ] || ELECTRON_BIN="$DIR/node_modules/electron/dist/electron"
if [ ! -x "$ELECTRON_BIN" ]; then
  echo "Electron absent — cd $DIR && npm install" >&2
  exit 1
fi
nohup "$ELECTRON_BIN" "$DIR" >> "$DIR/aether.log" 2>&1 &
LPID=$!
disown 2>/dev/null || true
sleep 8
if ! kill -0 "$LPID" 2>/dev/null && [ -f "$DIR/app.asar" ] && ! curl -s --max-time 2 "http://127.0.0.1:$AETHER_PORT/api/health" >/dev/null 2>&1; then
  echo "! l'app ne démarre pas avec le coffre — auto-réparation…"
  "$DIR/scripts/aether-repair.sh" || true
  nohup "$ELECTRON_BIN" "$DIR" >> "$DIR/aether.log" 2>&1 &
  disown 2>/dev/null || true
fi
echo "◉ NEXUS AETHER v2 — port $AETHER_PORT · moteur 90+ services · workspace : $AETHER_WORKSPACE"
AE_LCH2
chmod +x scripts/aether-launch.sh

cat > scripts/aether-stop.sh <<'AE_STP2'
#!/usr/bin/env bash
# NEXUS AETHER v2 — arrêt (fenêtre + daemon ; le service système reste paramétrable)
set -uo pipefail
command -v systemctl >/dev/null 2>&1 && systemctl --user stop aether.service 2>/dev/null
PIDF="$HOME/.aether/aether.pid"
if [ -f "$PIDF" ]; then
  PID="$(cat "$PIDF" 2>/dev/null || true)"
  [ -n "${PID:-}" ] && kill "$PID" 2>/dev/null
  rm -f "$PIDF"
fi
pkill -f "Aether/node_modules/electron" 2>/dev/null && echo "◉ NEXUS AETHER arrêté" || echo "· NEXUS AETHER ne tournait pas"
exit 0
AE_STP2
chmod +x scripts/aether-stop.sh
ok "lanceur v2 + arrêt v2 (service système intégré, auto-réparation)"
