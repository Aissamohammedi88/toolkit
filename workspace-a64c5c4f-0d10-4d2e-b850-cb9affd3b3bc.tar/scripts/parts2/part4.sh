#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════
#  NEXUS AETHER — UPGRADE PRO v2.0.0 (PARTIE 4/5)
#  Phase 5 : TESTS RÉELS — moteur branché, API vivantes, PROD vérifiée
# ══════════════════════════════════════════════════════════════════════
cd "$APP_DIR"

info "installation de js-yaml (validation YAML réelle) + asar (coffre de production)…"
npm install --no-audit --no-fund --no-save --loglevel=error js-yaml @electron/asar 2>/dev/null \
  && ok "js-yaml + @electron/asar installés" \
  || warn "npm partiel — la validation YAML passera en mode structurel"

for f in server/core.js main.js core/engine.js ui/engine.js scripts/patch-v2.js; do
  chk "node --check $f" "node --check '$APP_DIR/$f'"
done
chk "config/services.json (JSON valide)" "node -e \"const j=JSON.parse(require('fs').readFileSync('$APP_DIR/config/services.json','utf8')); if(j.services.length<90) process.exit(1)\""
chk "routes moteur présentes" "grep -q 'api/engine' '$APP_DIR/server/core.js'"
chk "PROD workspace verrouillé" "grep -q 'PROD_MODE' '$APP_DIR/server/core.js'"
chk "onglet Moteur dans l'UI" "grep -q 'data-tab=\"engine\"' '$APP_DIR/ui/index.html'"

if [ "$FAIL" -gt 0 ]; then
  ko "des vérifications statiques ont échoué — tests vivants sautés"
else
  echo
  info "démarrage du serveur de test (node pur, port $PORT)…"
  AETHER_PORT="$PORT" AETHER_WORKSPACE="$WORKSPACE" nohup node server/core.js > /tmp/aether-v2-test.log 2>&1 &
  TEST_PID=$!
  TP="$PORT"; HEALTH_OK=0
  for i in $(seq 1 30); do
    if curl -s --max-time 2 "http://127.0.0.1:$TP/api/health" | grep -q '"ok":true'; then HEALTH_OK=1; break; fi
    sleep 0.4
  done
  if [ "$HEALTH_OK" = "1" ]; then
    ok "serveur v2 en ligne sur 127.0.0.1:$TP"
    H="$(curl -s "http://127.0.0.1:$TP/api/health")"
    ok "version annoncée : $(printf '%s' "$H" | node -e "let d='';process.stdin.on('data',c=>d+=c).on('end',()=>{try{console.log(JSON.parse(d).version)}catch(e){console.log('?')}})")"
  else
    ko "serveur de test injoignable — log : $(tail -3 /tmp/aether-v2-test.log 2>/dev/null)"
  fi

  if [ "$HEALTH_OK" = "1" ]; then
    # ── 1. Catalogue ──
    SVC="$(curl -s "http://127.0.0.1:$TP/api/engine/services")"
    N="$(printf '%s' "$SVC" | node -e "let d='';process.stdin.on('data',c=>d+=c).on('end',()=>{try{console.log(JSON.parse(d).count)}catch(e){console.log(0)}})")"
    if [ "${N:-0}" -ge 90 ]; then ok "MOTEUR : $N services chargés (≥ 90)"; else ko "MOTEUR : $N services (< 90)"; fi

    # ── 2. Santé réelle de tous les services ──
    info "santé en direct de tous les services (vrais pings réseau, ~15 s)…"
    HS="$(curl -s --max-time 90 "http://127.0.0.1:$TP/api/engine/health?full=1")"
    printf '%s' "$HS" > /tmp/aether-health.json
    node -e "
      const j=JSON.parse(require('fs').readFileSync('/tmp/aether-health.json','utf8'));
      const s=j.summary||{};
      console.log('      total='+s.total+' en_ligne='+s.online+' prêts_clé='+s['pret']+' attente_clé='+s['needs-key']+' hors_ligne='+s.offline+' erreur='+s.erreur+' gratuits_actifs='+s.freeOnline);
      if((s.online||0)+(s.pret||0)<10) process.exit(1);
    " && ok "santé mesurée : services en ligne + prêts (détail : /tmp/aether-health.json)" \
       || ko "santé — trop peu de services joignables (réseau ?)"

    # ── 3. Génération texte RÉELLE (sans clé — quota frais en premier) ──
    info "test Pollinations texte (appel réel, sans clé)…"
    GT="$(curl -s --max-time 90 -X POST "http://127.0.0.1:$TP/api/engine/generate" -H 'Content-Type: application/json' -d '{"service":"pollinations-text","prompt":"Réponds exactement : AETHER_MOTEUR_OK"}')"
    printf '%s' "$GT" > /tmp/aether-gt.json
    if printf '%s' "$GT" | grep -q "AETHER_MOTEUR_OK"; then
      ok "génération TEXTE réelle sans clé : l'IA a répondu AETHER_MOTEUR_OK ✓"
    elif printf '%s' "$GT" | grep -qi "limite\|429\|30 s"; then
      warn "texte : limite gratuite atteinte pendant le test — l'endpoint répond (réel), réessaie"
    else
      ko "génération texte : $(printf '%s' "$GT" | head -c 160)"
    fi

    # ── 4. Workflow YAML RÉEL (attente honnête de la limite gratuite : 30 s) ──
    info "workflow YAML réel — attente de la limite gratuite Pollinations (30 s)…"
    sleep 31
    WF="$(curl -s --max-time 90 -X POST "http://127.0.0.1:$TP/api/engine/workflow" -H 'Content-Type: application/json' -d '{"description":"CI Node.js qui installe, teste et construit"}')"
    printf '%s' "$WF" > /tmp/aether-wf.json
    node -e "
      const j=JSON.parse(require('fs').readFileSync('/tmp/aether-wf.json','utf8'));
      if(j.ok && j.file && j.validation && j.validation.ok){ console.log('WF_OK '+j.file); } else { console.log('WF_ERR '+(j.error||(j.validation&&j.validation.error)||'inconnu')); }
    " > /tmp/aether-wf.out
    if grep -q WF_OK /tmp/aether-wf.out; then
      ok "workflow YAML RÉEL généré + validé : $(sed 's/^WF_OK //' /tmp/aether-wf.out)"
    else
      MSG="$(sed 's/^WF_ERR //' /tmp/aether-wf.out)"
      if printf '%s' "$MSG" | grep -qi "limite\|429\|30 s\|satur"; then
        warn "Pollinations a répondu : limite gratuite (1 réponse / 30 s par IP) — l'API EST réelle, réessaie dans 30 s"
      else
        ko "workflow YAML : $MSG"
      fi
    fi

    # ── 5. Recherche scientifique RÉELLE (arXiv) ──
    SC="$(curl -s --max-time 60 -X POST "http://127.0.0.1:$TP/api/engine/generate" -H 'Content-Type: application/json' -d '{"service":"arxiv","prompt":"nebula star formation"}')"
    if printf '%s' "$SC" | grep -q '"text":"🔎 arXiv'; then
      ok "science RÉELLE : arXiv a renvoyé de vrais articles"
    else
      warn "arXiv : $(printf '%s' "$SC" | head -c 140)"
    fi

    # ── 6. Image RÉELLE (AI Horde sans clé — file communautaire) ──
    IM="$(curl -s --max-time 60 -X POST "http://127.0.0.1:$TP/api/engine/generate" -H 'Content-Type: application/json' -d '{"service":"aihorde-image","prompt":"a glowing blue nebula","width":512,"height":512,"maxWaitS":8}')"
    if printf '%s' "$IM" | grep -q '"pending":true'; then
      ok "image RÉELLE : AI Horde a accepté le job (clé anonyme) — résultat via la ruche (poll)"
    elif printf '%s' "$IM" | grep -q '"file"'; then
      ok "image RÉELLE générée et extraite dans workspace/images/"
    else
      warn "AI Horde : $(printf '%s' "$IM" | head -c 140)"
    fi

    # ── 7. Résultats extraits ──
    RES="$(curl -s "http://127.0.0.1:$TP/api/engine/results")"
    NR="$(printf '%s' "$RES" | node -e "let d='';process.stdin.on('data',c=>d+=c).on('end',()=>{try{console.log(JSON.parse(d).items.length)}catch(e){console.log(0)}})")"
    if [ "${NR:-0}" -ge 1 ]; then ok "extraction : $NR fichier(s) dans workspace/ (textes, workflows…)"; else ko "aucun résultat extrait"; fi
    ls "$WORKSPACE/textes" "$WORKSPACE/workflows" >/dev/null 2>&1 && ok "dossiers workspace : textes · images · workflows · audio · projets"

    # ── 8. MODE PRODUCTION : le code cœur disparaît du graphe ──
    kill "$TEST_PID" 2>/dev/null || true; wait "$TEST_PID" 2>/dev/null || true
    AETHER_PORT="$TP" AETHER_PROD=1 AETHER_WORKSPACE="$WORKSPACE" nohup node server/core.js > /tmp/aether-v2-prod.log 2>&1 &
    TEST_PID=$!
    for i in $(seq 1 30); do curl -s --max-time 2 "http://127.0.0.1:$TP/api/health" | grep -q '"ok":true' && break; sleep 0.4; done
    P403="$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$TP/api/files?path=$(printf '%s' "$HOME" | sed 's/ /%20/g')")"
    P200="$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$TP/api/files?path=$(printf '%s' "$WORKSPACE" | sed 's/ /%20/g')")"
    if [ "$P403" = "403" ] && [ "$P200" = "200" ]; then
      ok "PRODUCTION : $HOME refusé (403) · workspace autorisé (200) — le code cœur n'est plus exposé"
    else
      ko "PRODUCTION : attendu 403/200, obtenu $P403/$P200"
    fi
    TERM_FILE="$(find "$WORKSPACE/textes" -type f | head -1)"
    if [ -n "$TERM_FILE" ]; then
      RAW="$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$TP/api/engine/raw?path=$(printf '%s' "$TERM_FILE" | sed 's/ /%20/g')")"
      [ "$RAW" = "200" ] && ok "résultats servis en direct (/api/engine/raw → 200)" || ko "raw → $RAW"
    fi
    kill "$TEST_PID" 2>/dev/null || true; wait "$TEST_PID" 2>/dev/null || true
  fi
fi
