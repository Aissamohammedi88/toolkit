#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════
#  NEXUS AETHER — UPGRADE PRO v2.0.0 (PARTIE 1/5)
#  ──────────────────────────────────────────────────────────────────────
#  Phase 1 : Contrôles + sauvegarde complète (OPTIMISE, NE DÉTRUIT PAS)
#  Phase 2 : MOTEUR DE GÉNÉRATION RÉEL — catalogue 90+ services
# ══════════════════════════════════════════════════════════════════════
set -euo pipefail

# ── Configuration ────────────────────────────────────────────────────
APP_TITLE="NEXUS AETHER"
APP_ID="nexus-aether"
APP_VERSION="2.0.0"
APP_DIR="${AETHER_DIR:-$HOME/Aether}"
PORT="${AETHER_PORT:-8420}"
NO_DESKTOP="${AETHER_NO_DESKTOP:-0}"
NO_VAULT="${AETHER_NO_VAULT:-0}"
CONF_DIR="$HOME/.aether"
WORKSPACE="$APP_DIR/workspace"
HIDDEN_DIR="$HOME/.nexus-aether"

C_CYAN="\033[1;36m"; C_MAG="\033[1;95m"; C_GRN="\033[1;32m"; C_YLW="\033[1;33m"
C_RED="\033[1;31m"; C_DIM="\033[2m"; C_B="\033[1m"; C_RST="\033[0m"
PASS=0; FAIL=0

ok()   { echo -e "  ${C_GRN}✓${C_RST} $1"; PASS=$((PASS+1)); }
ko()   { echo -e "  ${C_RED}✗${C_RST} $1"; FAIL=$((FAIL+1)); }
info() { echo -e "  ${C_DIM}·${C_RST} $1"; }
warn() { echo -e "  ${C_YLW}!${C_RST} $1"; }
phase(){ echo; echo -e "${C_MAG}━━━ PHASE $1/9 ━━━ ${C_CYAN}${C_B}$2${C_RST}"; }
chk()  { if eval "$2" >/dev/null 2>&1; then ok "$1"; else ko "$1"; fi }

echo
echo -e "${C_MAG}${C_B}"
cat <<'BANIERE'
   ╔════════════════════════════════════════════════════════════╗
   ║   N E X U S   A E T H E R   ·   U P G R A D E   P R O      ║
   ║   v2.0.0 — MOTEUR RÉEL · PRODUCTION · SERVICE SYSTÈME      ║
   ╚════════════════════════════════════════════════════════════╝
BANIERE
echo -e "${C_RST}${C_DIM}   Upgrade : optimise l'installation existante, ne détruit rien.${C_RST}"

# ════════════════════════════════════════════════════════════════════
phase 1 "Contrôles & sauvegarde"
# ════════════════════════════════════════════════════════════════════
if [ -d "$APP_DIR" ]; then ok "installation détectée : $APP_DIR"; else
  ko "$APP_DIR introuvable — lance d'abord aether-bureau-tout-en-un.sh"; echo; exit 1; fi

# Si un coffre v2 existe déjà (re-run) : extraction AVANT tout contrôle
if [ -f "$APP_DIR/app.asar" ]; then
  info "coffre app.asar existant (re-run) — extraction pour mise à jour…"
  mkdir -p "$APP_DIR/.vault-restore"
  (cd "$APP_DIR" && npx --yes @electron/asar extract app.asar .vault-restore >/dev/null 2>&1) || true
  for f in main.js preload.js package.json; do
    [ -f "$APP_DIR/.vault-restore/$f" ] && cp "$APP_DIR/.vault-restore/$f" "$APP_DIR/$f"
  done
  for d in core server ui config; do
    [ -d "$APP_DIR/.vault-restore/$d" ] && rm -rf "$APP_DIR/$d" && cp -r "$APP_DIR/.vault-restore/$d" "$APP_DIR/$d"
  done
  rm -rf "$APP_DIR/.vault-restore"
  rm -f "$APP_DIR/app.asar"
  ok "contenu du coffre restauré — mise à jour possible (rien perdu)"
fi

for f in main.js server/core.js core/router.js ui/index.html ui/app.js; do
  if [ -f "$APP_DIR/$f" ]; then ok "présent : $f"; else ko "fichier v1 manquant : $f"; fi
done
if [ "$FAIL" -gt 0 ]; then echo; exit 1; fi

if command -v node >/dev/null 2>&1; then ok "node $(node -v)"; else ko "node absent"; exit 1; fi
NODE_MAJOR="$(node -p 'parseInt(process.versions.node,10)' 2>/dev/null || echo 0)"
if [ "${NODE_MAJOR:-0}" -ge 18 ] 2>/dev/null; then ok "node ≥ 18 — fetch natif disponible"
else ko "node ≥ 18 requis — arrêt"; echo; exit 1; fi
chk "curl" "command -v curl"

# Sauvegarde horodatée de TOUT ce qu'on va toucher
TS="$(date +%Y%m%d-%H%M%S)"
BACKUP="$APP_DIR/.backup-v2-$TS"
mkdir -p "$BACKUP"
for f in main.js preload.js package.json server/core.js ui/index.html ui/app.js ui/style.css \
         config/plugins.json scripts/aether-launch.sh scripts/aether-stop.sh README.md; do
  [ -f "$APP_DIR/$f" ] && mkdir -p "$BACKUP/$(dirname "$f")" && cp "$APP_DIR/$f" "$BACKUP/$f"
done
ok "sauvegarde complète : $BACKUP"

# Arrêt propre de l'app/serveur en cours (on va redémarrer à la fin)
if [ -x "$APP_DIR/scripts/aether-stop.sh" ]; then
  "$APP_DIR/scripts/aether-stop.sh" >/dev/null 2>&1 || true
  info "instances en cours arrêtées (redémarrage automatique en phase 7)"
fi

# ════════════════════════════════════════════════════════════════════
phase 2 "MOTEUR RÉEL — catalogue de 90+ services de génération"
# ════════════════════════════════════════════════════════════════════
cd "$APP_DIR"
mkdir -p "$WORKSPACE"/{textes,images,workflows,projets}
mkdir -p "$CONF_DIR"

cat > config/services.json <<'AE_SERVICES'
{
  "version": "2.0.0",
  "note": "Catalogue RÉEL : chaque entrée est branchée sur un adaptateur HTTP qui appelle le vrai endpoint. tier: local | gratuit (sans clé) | clé-gratuit (palier gratuit, clé requise) | payant",
  "services": [
    { "id": "pollinations-text", "name": "Pollinations Texte (GPT-OSS 20B)", "cat": "texte", "adapter": "pollinations-text", "url": "https://text.pollinations.ai", "model": "openai-fast", "tier": "gratuit", "free": true, "docs": "Génération de texte SANS clé. Limite gratuite : 1 réponse / 30 s par IP. Modèles rafraîchis en direct via /models." },
    { "id": "aihorde-text", "name": "AI Horde Texte ( crowdsourcé )", "cat": "texte", "adapter": "horde-text", "url": "https://aihorde.net/api/v2", "tier": "gratuit", "free": true, "docs": "Génération de texte SANS clé via la ruche AI Horde (clé anonyme 0000000000 intégrée). File d'attente communautaire." },
    { "id": "ollama", "name": "Ollama (local · souverain)", "cat": "texte", "adapter": "ollama", "url": "http://127.0.0.1:11434", "model": "llama3", "tier": "local", "free": true, "docs": "IA 100% locale. Lance « ollama serve ». Modèle par défaut llama3 — change-le via /api/engine ou le catalogue ~/.aether/services.json." },
    { "id": "lmstudio", "name": "LM Studio (local)", "cat": "texte", "adapter": "openai-port", "url": "http://127.0.0.1:1234", "tier": "local", "free": true, "docs": "Serveur LM Studio — active « Local Server » dans LM Studio. Modèle détecté automatiquement." },
    { "id": "jan", "name": "Jan.ai (local)", "cat": "texte", "adapter": "openai-port", "url": "http://127.0.0.1:1337", "tier": "local", "free": true, "docs": "Serveur local Jan.ai (API OpenAI-compatible)." },
    { "id": "gpt4all", "name": "GPT4All (local)", "cat": "texte", "adapter": "openai-port", "url": "http://127.0.0.1:4891", "tier": "local", "free": true, "docs": "GPT4All — active le serveur API dans les réglages." },
    { "id": "koboldcpp", "name": "KoboldCpp (local)", "cat": "texte", "adapter": "openai-port", "url": "http://127.0.0.1:5001", "tier": "local", "free": true, "docs": "KoboldCpp avec API OpenAI activée." },
    { "id": "llamacpp", "name": "llama.cpp server (local)", "cat": "texte", "adapter": "openai-port", "url": "http://127.0.0.1:8080", "tier": "local", "free": true, "docs": "llama-server (llama.cpp) — endpoint OpenAI-compatible." },
    { "id": "oobabooga", "name": "text-generation-webui (local)", "cat": "texte", "adapter": "openai-port", "url": "http://127.0.0.1:5000", "tier": "local", "free": true, "docs": "oobabooga — extension OpenAI activée." },
    { "id": "vllm", "name": "vLLM (local)", "cat": "texte", "adapter": "openai-port", "url": "http://127.0.0.1:8000", "tier": "local", "free": true, "docs": "Serveur vLLM (GPU) — OpenAI-compatible." },
    { "id": "localai", "name": "LocalAI (local)", "cat": "texte", "adapter": "openai-port", "url": "http://127.0.0.1:8888", "tier": "local", "free": true, "docs": "LocalAI — alternative open source à OpenAI." },
    { "id": "litellm", "name": "LiteLLM gateway (local)", "cat": "texte", "adapter": "openai-port", "url": "http://127.0.0.1:4000", "tier": "local", "free": true, "docs": "Passerelle LiteLLM — route 100+ modèles en local." },
    { "id": "sglang", "name": "SGLang (local)", "cat": "texte", "adapter": "openai-port", "url": "http://127.0.0.1:30000", "tier": "local", "free": true, "docs": "SGLang server — OpenAI-compatible." },
    { "id": "llamafile", "name": "llamafile (local)", "cat": "texte", "adapter": "openai-port", "url": "http://127.0.0.1:8081", "tier": "local", "free": true, "docs": "llamafile — un exécutable, zéro installation (port 8081 si 8080 pris)." },
    { "id": "openwebui", "name": "Open WebUI (local)", "cat": "texte", "adapter": "openai-port", "url": "http://127.0.0.1:8080", "tier": "local", "free": true, "docs": "Open WebUI — API OpenAI-compatible intégrée." },
    { "id": "ollama-llama3.3", "name": "Ollama · Llama 3.3 70B", "cat": "texte", "adapter": "ollama", "url": "http://127.0.0.1:11434", "model": "llama3.3", "tier": "local", "free": true, "docs": "Préréglage : ollama pull llama3.3" },
    { "id": "ollama-qwen2.5-coder", "name": "Ollama · Qwen 2.5 Coder", "cat": "texte", "adapter": "ollama", "url": "http://127.0.0.1:11434", "model": "qwen2.5-coder", "tier": "local", "free": true, "docs": "Préréglage code : ollama pull qwen2.5-coder" },
    { "id": "ollama-qwen3", "name": "Ollama · Qwen 3", "cat": "texte", "adapter": "ollama", "url": "http://127.0.0.1:11434", "model": "qwen3", "tier": "local", "free": true, "docs": "Préréglage : ollama pull qwen3" },
    { "id": "ollama-mistral", "name": "Ollama · Mistral 7B", "cat": "texte", "adapter": "ollama", "url": "http://127.0.0.1:11434", "model": "mistral", "tier": "local", "free": true, "docs": "Préréglage : ollama pull mistral" },
    { "id": "ollama-gemma3", "name": "Ollama · Gemma 3", "cat": "texte", "adapter": "ollama", "url": "http://127.0.0.1:11434", "model": "gemma3", "tier": "local", "free": true, "docs": "Préréglage : ollama pull gemma3" },
    { "id": "ollama-gemma2", "name": "Ollama · Gemma 2", "cat": "texte", "adapter": "ollama", "url": "http://127.0.0.1:11434", "model": "gemma2", "tier": "local", "free": true, "docs": "Préréglage : ollama pull gemma2" },
    { "id": "ollama-phi4", "name": "Ollama · Phi-4", "cat": "texte", "adapter": "ollama", "url": "http://127.0.0.1:11434", "model": "phi4", "tier": "local", "free": true, "docs": "Préréglage : ollama pull phi4" },
    { "id": "ollama-deepseek-r1", "name": "Ollama · DeepSeek R1 (raisonnement)", "cat": "texte", "adapter": "ollama", "url": "http://127.0.0.1:11434", "model": "deepseek-r1", "tier": "local", "free": true, "docs": "Préréglage raisonnement : ollama pull deepseek-r1" },
    { "id": "ollama-codellama", "name": "Ollama · CodeLlama", "cat": "texte", "adapter": "ollama", "url": "http://127.0.0.1:11434", "model": "codellama", "tier": "local", "free": true, "docs": "Préréglage code : ollama pull codellama" },
    { "id": "ollama-llama3.1", "name": "Ollama · Llama 3.1", "cat": "texte", "adapter": "ollama", "url": "http://127.0.0.1:11434", "model": "llama3.1", "tier": "local", "free": true, "docs": "Préréglage : ollama pull llama3.1" },
    { "id": "ollama-vision", "name": "Ollama · LLaVA (vision)", "cat": "texte", "adapter": "ollama", "url": "http://127.0.0.1:11434", "model": "llava", "tier": "local", "free": true, "docs": "Vision locale : ollama pull llava — passe une image workspace en opts.image." },
    { "id": "ollama-embed", "name": "Ollama Embeddings (nomic)", "cat": "embed", "adapter": "ollama-embed", "url": "http://127.0.0.1:11434", "model": "nomic-embed-text", "tier": "local", "free": true, "docs": "Vecteurs sémantiques locaux : ollama pull nomic-embed-text" },
    { "id": "lmstudio-embed", "name": "LM Studio Embeddings (local)", "cat": "embed", "adapter": "openai-embed", "url": "http://127.0.0.1:1234", "model": "text-embedding-nomic-embed-text-v1.5", "tier": "local", "free": true, "docs": "Embeddings via LM Studio (charger le modèle embedding dans LM Studio)." },
    { "id": "arxiv", "name": "arXiv (science · articles)", "cat": "science", "adapter": "science", "url": "https://export.arxiv.org/api/query", "tier": "gratuit", "free": true, "docs": "Vraie recherche d'articles scientifiques — alimente la génération avec des sources réelles." },
    { "id": "wikipedia-fr", "name": "Wikipédia FR (science)", "cat": "science", "adapter": "science", "url": "https://fr.wikipedia.org/w/api.php", "tier": "gratuit", "free": true, "docs": "Vraie recherche encyclopédique française — ancrage factuel pour la génération." },
    { "id": "wikipedia-en", "name": "Wikipedia EN (science)", "cat": "science", "adapter": "science", "url": "https://en.wikipedia.org/w/api.php", "tier": "gratuit", "free": true, "docs": "Vraie recherche encyclopédique anglaise." },
    { "id": "openalex", "name": "OpenAlex (science · 250M travaux)", "cat": "science", "adapter": "science", "url": "https://api.openalex.org/works", "tier": "gratuit", "free": true, "docs": "Base scientifique ouverte — vraies publications, années, DOI." },
    { "id": "crossref", "name": "Crossref (science · DOI)", "cat": "science", "adapter": "science", "url": "https://api.crossref.org/works", "tier": "gratuit", "free": true, "docs": "Registry DOI — métadonnées réelles de publications." },
    { "id": "pubmed", "name": "PubMed (science · médecine)", "cat": "science", "adapter": "science", "url": "https://eutils.ncbi.nlm.nih.gov/entrez/eutils", "tier": "gratuit", "free": true, "docs": "Littérature biomédicale NCBI — vraies références." },
    { "id": "europepmc", "name": "Europe PMC (science)", "cat": "science", "adapter": "science", "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/search", "tier": "gratuit", "free": true, "docs": "Archive européenne des sciences de la vie." },
    { "id": "pubchem", "name": "PubChem (science · chimie)", "cat": "science", "adapter": "science", "url": "https://pubchem.ncbi.nlm.nih.gov/rest/pug", "tier": "gratuit", "free": true, "docs": "Chimie réelle : formule, masse molaire, SMILES par nom de composé." },
    { "id": "openlibrary", "name": "Open Library (livres)", "cat": "science", "adapter": "science", "url": "https://openlibrary.org/search.json", "tier": "gratuit", "free": true, "docs": "Recherche réelle de livres (Internet Archive)." },
    { "id": "gutendex", "name": "Gutenberg (livres libres)", "cat": "science", "adapter": "science", "url": "https://gutendex.com/books", "tier": "gratuit", "free": true, "docs": "70 000+ livres du domaine public — corpus réel pour la génération." },
    { "id": "worldbank", "name": "Banque mondiale (données)", "cat": "science", "adapter": "science", "url": "https://api.worldbank.org/v2/country", "tier": "gratuit", "free": true, "docs": "Vraies données économiques (PIB, population) — chiffres officiels." },
    { "id": "wikidata", "name": "Wikidata (entités)", "cat": "science", "adapter": "science", "url": "https://www.wikidata.org/w/api.php", "tier": "gratuit", "free": true, "docs": "Base de connaissances structurée — entités et descriptions réelles." },
    { "id": "semantic-scholar", "name": "Semantic Scholar (science)", "cat": "science", "adapter": "science", "url": "https://api.semanticscholar.org/graph/v1/paper/search", "tier": "gratuit", "free": true, "docs": "200M+ articles — vrais résumés (limite publique par IP)." },
    { "id": "nasa-apod", "name": "NASA APOD (astronomie)", "cat": "science", "adapter": "science", "url": "https://api.nasa.gov/planetary/apod", "tier": "gratuit", "free": true, "docs": "Photo et explication astronomique du jour (clé DEMO publique)." },
    { "id": "unpaywall", "name": "Unpaywall (science ouverte)", "cat": "science", "adapter": "science", "url": "https://api.unpaywall.org/v2/search", "tier": "gratuit", "free": true, "docs": "Versions en accès libre de vrais articles." },
    { "id": "doaj", "name": "DOAJ (revues ouvertes)", "cat": "science", "adapter": "science", "url": "https://doaj.org/api/search/articles", "tier": "gratuit", "free": true, "docs": "Directory of Open Access Journals — vrais articles." },
    { "id": "hal", "name": "HAL (science · France)", "cat": "science", "adapter": "science", "url": "https://api.archives-ouvertes.fr/search", "tier": "gratuit", "free": true, "docs": "Archive ouverte française — vraies publications CNRS/universités." },
    { "id": "zenodo", "name": "Zenodo (science · CERN)", "cat": "science", "adapter": "science", "url": "https://zenodo.org/api/records", "tier": "gratuit", "free": true, "docs": "Dépôts de recherche ouverts (CERN/UE)." },
    { "id": "openmeteo", "name": "Open-Meteo (météo · données)", "cat": "science", "adapter": "science", "url": "https://api.open-meteo.com/v1/forecast", "tier": "gratuit", "free": true, "docs": "Vraies données météo temps réel (opts.lat/opts.lon, défaut Paris)." },
    { "id": "pollinations-image", "name": "Pollinations Image (sana)", "cat": "image", "adapter": "pollinations-image", "url": "https://image.pollinations.ai", "model": "sana", "tier": "gratuit", "free": true, "docs": "Vraie génération d'images SANS clé. Limite gratuite avec attente (Retry-After géré automatiquement)." },
    { "id": "aihorde-image", "name": "AI Horde Image (crowdsourcé)", "cat": "image", "adapter": "horde-image", "url": "https://aihorde.net/api/v2", "model": "stable_diffusion", "tier": "gratuit", "free": true, "docs": "Vraie génération d'images SANS clé via la ruche (clé anonyme intégrée). File d'attente communautaire, sondage automatique." },
    { "id": "aihorde-caption", "name": "AI Horde Caption (vision)", "cat": "vision", "adapter": "horde-caption", "url": "https://aihorde.net/api/v2", "tier": "gratuit", "free": true, "docs": "Décrire une image (image→texte) via AI Horde. opts.image = chemin d'une image du workspace." },
    { "id": "comfyui", "name": "ComfyUI (local)", "cat": "image", "adapter": "comfy", "url": "http://127.0.0.1:8188", "tier": "local", "free": true, "docs": "Stable Diffusion local — lance ComfyUI. Workflow txt2img par défaut fourni (compat selon installation)." },
    { "id": "a1111", "name": "Stable Diffusion WebUI (local)", "cat": "image", "adapter": "a1111", "url": "http://127.0.0.1:7860", "tier": "local", "free": true, "docs": "AUTOMATIC1111 — lance avec --api. txt2img réel." },
    { "id": "sdnext", "name": "SD.Next (local)", "cat": "image", "adapter": "a1111", "url": "http://127.0.0.1:7901", "tier": "local", "free": true, "docs": "SD.Next — API compatible A1111 (port 7901)." },
    { "id": "glm", "name": "GLM · Z.ai — GLM-4-Flash", "cat": "texte", "adapter": "openai", "url": "https://open.bigmodel.cn/api/paas/v4/chat/completions", "model": "glm-4-flash", "keyEnv": "AETHER_GLM_KEY", "tier": "clé-gratuit", "free": false, "docs": "Palier gratuit de Z.ai. Clé : open.bigmodel.cn → export AETHER_GLM_KEY=… ou scripts/aether-keys.sh" },
    { "id": "glm-plus", "name": "GLM · Z.ai — GLM-4-Plus", "cat": "texte", "adapter": "openai", "url": "https://open.bigmodel.cn/api/paas/v4/chat/completions", "model": "glm-4-plus", "keyEnv": "AETHER_GLM_KEY", "tier": "clé-gratuit", "free": false, "docs": "Modèle phare GLM (quota selon compte Z.ai)." },
    { "id": "gemini-flash", "name": "Google Gemini 2.0 Flash", "cat": "texte", "adapter": "gemini", "url": "https://generativelanguage.googleapis.com/v1beta", "model": "gemini-2.0-flash", "keyEnv": "AETHER_GEMINI_KEY", "tier": "clé-gratuit", "free": false, "docs": "Palier gratuit Google AI Studio : aistudio.google.com/apikey" },
    { "id": "gemini-flash-lite", "name": "Google Gemini 2.0 Flash-Lite", "cat": "texte", "adapter": "gemini", "url": "https://generativelanguage.googleapis.com/v1beta", "model": "gemini-2.0-flash-lite", "keyEnv": "AETHER_GEMINI_KEY", "tier": "clé-gratuit", "free": false, "docs": "Version légère et rapide (palier gratuit)." },
    { "id": "gemini-1.5-flash", "name": "Google Gemini 1.5 Flash", "cat": "texte", "adapter": "gemini", "url": "https://generativelanguage.googleapis.com/v1beta", "model": "gemini-1.5-flash", "keyEnv": "AETHER_GEMINI_KEY", "tier": "clé-gratuit", "free": false, "docs": "Génération précédente, palier gratuit." },
    { "id": "gemini-pro", "name": "Google Gemini 1.5 Pro", "cat": "texte", "adapter": "gemini", "url": "https://generativelanguage.googleapis.com/v1beta", "model": "gemini-1.5-pro", "keyEnv": "AETHER_GEMINI_KEY", "tier": "clé-gratuit", "free": false, "docs": "Modèle avancé (quota gratuit journalier)." },
    { "id": "openrouter-free", "name": "OpenRouter · modèles :free", "cat": "texte", "adapter": "openai", "url": "https://openrouter.ai/api/v1/chat/completions", "model": "", "keyEnv": "AETHER_OPENROUTER_KEY", "tier": "clé-gratuit", "free": false, "docs": "Clé gratuite openrouter.ai/keys — liste des :free en direct sur /api/v1/models." },
    { "id": "or-gemma4-31b", "name": "OpenRouter · Gemma 4 31B (free)", "cat": "texte", "adapter": "openai", "url": "https://openrouter.ai/api/v1/chat/completions", "model": "google/gemma-4-31b-it:free", "keyEnv": "AETHER_OPENROUTER_KEY", "tier": "clé-gratuit", "free": false, "docs": "Modèle :free vérifié en direct sur l'API OpenRouter." },
    { "id": "or-nemotron-ultra", "name": "OpenRouter · Nemotron 3 Ultra (free)", "cat": "texte", "adapter": "openai", "url": "https://openrouter.ai/api/v1/chat/completions", "model": "nvidia/nemotron-3-ultra-550b-a55b:free", "keyEnv": "AETHER_OPENROUTER_KEY", "tier": "clé-gratuit", "free": false, "docs": "550B MoE gratuit — vérifié en direct." },
    { "id": "or-nemotron-lightning", "name": "OpenRouter · Nemotron 3.5 Lightning (free)", "cat": "texte", "adapter": "openai", "url": "https://openrouter.ai/api/v1/chat/completions", "model": "nvidia/nemotron-3.5-lightning:free", "keyEnv": "AETHER_OPENROUTER_KEY", "tier": "clé-gratuit", "free": false, "docs": "Modèle :free vérifié en direct." },
    { "id": "or-lfm-2.5", "name": "OpenRouter · LiquidAI LFM 2.5 (free)", "cat": "texte", "adapter": "openai", "url": "https://openrouter.ai/api/v1/chat/completions", "model": "liquid/lfm-2.5-2.6b:free", "keyEnv": "AETHER_OPENROUTER_KEY", "tier": "clé-gratuit", "free": false, "docs": "Petit modèle edge gratuit — vérifié en direct." },
    { "id": "or-north-code", "name": "OpenRouter · Cohere North Code (free)", "cat": "texte", "adapter": "openai", "url": "https://openrouter.ai/api/v1/chat/completions", "model": "cohere/north-mini-code:free", "keyEnv": "AETHER_OPENROUTER_KEY", "tier": "clé-gratuit", "free": false, "docs": "Code gratuit — vérifié en direct." },
    { "id": "or-inkling", "name": "OpenRouter · Inkling (free)", "cat": "texte", "adapter": "openai", "url": "https://openrouter.ai/api/v1/chat/completions", "model": "thinkingmachines/inkling:free", "keyEnv": "AETHER_OPENROUTER_KEY", "tier": "clé-gratuit", "free": false, "docs": "Modèle :free vérifié en direct." },
    { "id": "or-laguna-s", "name": "OpenRouter · Laguna S 2.1 (free)", "cat": "texte", "adapter": "openai", "url": "https://openrouter.ai/api/v1/chat/completions", "model": "poolside/laguna-s-2.1:free", "keyEnv": "AETHER_OPENROUTER_KEY", "tier": "clé-gratuit", "free": false, "docs": "Modèle :free vérifié en direct." },
    { "id": "or-flint", "name": "OpenRouter · Flint (free)", "cat": "texte", "adapter": "openai", "url": "https://openrouter.ai/api/v1/chat/completions", "model": "recursive/flint-v1.0:free", "keyEnv": "AETHER_OPENROUTER_KEY", "tier": "clé-gratuit", "free": false, "docs": "Modèle :free vérifié en direct." },
    { "id": "groq", "name": "Groq · Llama 3.3 70B (ultra-rapide)", "cat": "texte", "adapter": "openai", "url": "https://api.groq.com/openai/v1/chat/completions", "model": "llama-3.3-70b-versatile", "keyEnv": "AETHER_GROQ_KEY", "tier": "clé-gratuit", "free": false, "docs": "Palier gratuit généreux : console.groq.com/keys" },
    { "id": "groq-8b", "name": "Groq · Llama 3.1 8B (instant)", "cat": "texte", "adapter": "openai", "url": "https://api.groq.com/openai/v1/chat/completions", "model": "llama-3.1-8b-instant", "keyEnv": "AETHER_GROQ_KEY", "tier": "clé-gratuit", "free": false, "docs": "Le plus rapide du palier gratuit Groq." },
    { "id": "cerebras", "name": "Cerebras · Llama 3.3 70B", "cat": "texte", "adapter": "openai", "url": "https://api.cerebras.ai/v1/chat/completions", "model": "llama-3.3-70b", "keyEnv": "AETHER_CEREBRAS_KEY", "tier": "clé-gratuit", "free": false, "docs": "Palier gratuit : cloud.cerebras.ai" },
    { "id": "mistral", "name": "Mistral · Small (La Plateforme)", "cat": "texte", "adapter": "openai", "url": "https://api.mistral.ai/v1/chat/completions", "model": "mistral-small-latest", "keyEnv": "AETHER_MISTRAL_KEY", "tier": "clé-gratuit", "free": false, "docs": "Palier gratuit : console.mistral.ai" },
    { "id": "cohere", "name": "Cohere · Command R7B", "cat": "texte", "adapter": "openai", "url": "https://api.cohere.ai/compatibility/v1/chat/completions", "model": "command-r7b-12-2024", "keyEnv": "AETHER_COHERE_KEY", "tier": "clé-gratuit", "free": false, "docs": "Clés d'essai gratuites : dashboard.cohere.com" },
    { "id": "together-free", "name": "Together · Llama 3.3 70B Free", "cat": "texte", "adapter": "openai", "url": "https://api.together.xyz/v1/chat/completions", "model": "meta-llama/Llama-3.3-70B-Instruct-Turbo-Free", "keyEnv": "AETHER_TOGETHER_KEY", "tier": "clé-gratuit", "free": false, "docs": "Endpoint -Free : api.together.xyz" },
    { "id": "github-models", "name": "GitHub Models (gratuit avec compte)", "cat": "texte", "adapter": "openai", "url": "https://models.github.ai/inference/chat/completions", "model": "openai/gpt-4.1-mini", "keyEnv": "AETHER_GITHUB_TOKEN", "tier": "clé-gratuit", "free": false, "docs": "Token GitHub (read:models) : github.com/settings/tokens" },
    { "id": "cloudflare-ai", "name": "Cloudflare Workers AI · Llama 3.3", "cat": "texte", "adapter": "cloudflare-text", "url": "https://api.cloudflare.com/client/v4", "model": "@cf/meta/llama-3.3-70b-instruct-fp8-fast", "keyEnv": "AETHER_CF_TOKEN", "accountEnv": "AETHER_CF_ACCOUNT", "tier": "clé-gratuit", "free": false, "docs": "10 000 neurones/jour gratuits. Clé : dash.cloudflare.com → AETHER_CF_TOKEN + AETHER_CF_ACCOUNT" },
    { "id": "hf-text", "name": "HuggingFace Router · Llama 3.3 70B", "cat": "texte", "adapter": "openai", "url": "https://router.huggingface.co/v1/chat/completions", "model": "meta-llama/Llama-3.3-70B-Instruct", "keyEnv": "AETHER_HF_TOKEN", "tier": "clé-gratuit", "free": false, "docs": "Crédits mensuels gratuits : huggingface.co/settings/tokens" },
    { "id": "hf-qwen", "name": "HuggingFace Router · Qwen 2.5 7B", "cat": "texte", "adapter": "openai", "url": "https://router.huggingface.co/v1/chat/completions", "model": "Qwen/Qwen2.5-7B-Instruct", "keyEnv": "AETHER_HF_TOKEN", "tier": "clé-gratuit", "free": false, "docs": "Petit modèle rapide sur le routeur HF." },
    { "id": "nvidia-nim", "name": "NVIDIA NIM · Llama 3.3 70B", "cat": "texte", "adapter": "openai", "url": "https://integrate.api.nvidia.com/v1/chat/completions", "model": "meta/llama-3.3-70b-instruct", "keyEnv": "AETHER_NVIDIA_KEY", "tier": "clé-gratuit", "free": false, "docs": "1000 crédits gratuits : build.nvidia.com" },
    { "id": "siliconflow", "name": "SiliconFlow · Qwen 2.5 7B", "cat": "texte", "adapter": "openai", "url": "https://api.siliconflow.cn/v1/chat/completions", "model": "Qwen/Qwen2.5-7B-Instruct", "keyEnv": "AETHER_SILICONFLOW_KEY", "tier": "clé-gratuit", "free": false, "docs": "Palier gratuit : siliconflow.cn" },
    { "id": "novita", "name": "Novita AI · Llama 3.3 70B", "cat": "texte", "adapter": "openai", "url": "https://api.novita.ai/v3/openai/chat/completions", "model": "meta-llama/llama-3.3-70b-instruct", "keyEnv": "AETHER_NOVITA_KEY", "tier": "clé-gratuit", "free": false, "docs": "Crédits gratuits à l'inscription : novita.ai" },
    { "id": "glm-image", "name": "GLM · CogView-3-Flash (image)", "cat": "image", "adapter": "openai-image", "url": "https://open.bigmodel.cn/api/paas/v4/images/generations", "model": "cogview-3-flash", "keyEnv": "AETHER_GLM_KEY", "tier": "clé-gratuit", "free": false, "docs": "Génération d'images GRATUITE avec clé Z.ai." },
    { "id": "hf-flux", "name": "HuggingFace · FLUX.1-schnell", "cat": "image", "adapter": "hf-image", "url": "https://router.huggingface.co/hf-inference/models/black-forest-labs/FLUX.1-schnell", "keyEnv": "AETHER_HF_TOKEN", "tier": "clé-gratuit", "free": false, "docs": "FLUX.1-schnell avec crédits HF gratuits." },
    { "id": "together-flux", "name": "Together · FLUX.1-schnell Free", "cat": "image", "adapter": "openai-image", "url": "https://api.together.xyz/v1/images/generations", "model": "black-forest-labs/FLUX.1-schnell-Free", "keyEnv": "AETHER_TOGETHER_KEY", "tier": "clé-gratuit", "free": false, "docs": "FLUX gratuit (endpoint -Free)." },
    { "id": "cloudflare-flux", "name": "Cloudflare · FLUX.1-schnell", "cat": "image", "adapter": "cloudflare-image", "url": "https://api.cloudflare.com/client/v4", "model": "@cf/black-forest-labs/flux-1-schnell", "keyEnv": "AETHER_CF_TOKEN", "accountEnv": "AETHER_CF_ACCOUNT", "tier": "clé-gratuit", "free": false, "docs": "FLUX sur Workers AI (neurones gratuits)." },
    { "id": "openai-image", "name": "OpenAI · Images (payant)", "cat": "image", "adapter": "openai-image", "url": "https://api.openai.com/v1/images/generations", "model": "gpt-image-1", "keyEnv": "AETHER_OPENAI_KEY", "tier": "payant", "free": false, "docs": "Câblé réel — facturé selon compte OpenAI." },
    { "id": "hf-whisper", "name": "HuggingFace · Whisper (audio→texte)", "cat": "audio", "adapter": "hf-asr", "url": "https://router.huggingface.co/hf-inference/models/openai/whisper-large-v3", "keyEnv": "AETHER_HF_TOKEN", "tier": "clé-gratuit", "free": false, "docs": "Transcription réelle : opts.audio = chemin d'un audio du workspace." },
    { "id": "pollinations-audio", "name": "Pollinations Audio (voix)", "cat": "audio", "adapter": "pollinations-audio", "url": "https://text.pollinations.ai", "model": "openai-audio", "tier": "clé-gratuit", "free": false, "docs": "Synthèse vocale — disponibilité selon palier Pollinations (erreurs honnêtes si indisponible)." },
    { "id": "openai", "name": "OpenAI · GPT-4.1-mini (payant)", "cat": "texte", "adapter": "openai", "url": "https://api.openai.com/v1/chat/completions", "model": "gpt-4.1-mini", "keyEnv": "AETHER_OPENAI_KEY", "tier": "payant", "free": false, "docs": "Câblé réel — facturé selon compte." },
    { "id": "anthropic", "name": "Anthropic · Claude (payant)", "cat": "texte", "adapter": "anthropic", "url": "https://api.anthropic.com/v1/messages", "model": "claude-3-5-sonnet-latest", "keyEnv": "AETHER_ANTHROPIC_KEY", "tier": "payant", "free": false, "docs": "Câblé réel (API Messages + x-api-key)." },
    { "id": "deepseek", "name": "DeepSeek · chat (payant)", "cat": "texte", "adapter": "openai", "url": "https://api.deepseek.com/v1/chat/completions", "model": "deepseek-chat", "keyEnv": "AETHER_DEEPSEEK_KEY", "tier": "payant", "free": false, "docs": "Câblé réel — très économique." },
    { "id": "nasa-full", "name": "NASA (clé perso)", "cat": "science", "adapter": "science", "url": "https://api.nasa.gov/planetary/apod", "keyEnv": "AETHER_NASA_KEY", "tier": "clé-gratuit", "free": false, "docs": "Clé gratuite : api.nasa.gov — quota perso au lieu de DEMO_KEY." },
    { "id": "core-ac", "name": "CORE (science · 300M)", "cat": "science", "adapter": "science", "url": "https://api.core.ac.uk/v3/search/works", "keyEnv": "AETHER_CORE_KEY", "tier": "clé-gratuit", "free": false, "docs": "Clé gratuite : core.ac.uk/api — agrégateur mondial d'articles." }
  ]
}
AE_SERVICES

info "copie perso : ~/.aether/services.json (prioritaire si présent) — clés : ~/.aether/secrets.json"

SVC_COUNT="$(node -e "const j=JSON.parse(require('fs').readFileSync('config/services.json','utf8')); console.log(j.services.length)")"
if [ "$SVC_COUNT" -ge 90 ]; then
  ok "catalogue : $SVC_COUNT services de génération (exigence ≥ 90)"
else
  ko "catalogue incomplet : $SVC_COUNT services (< 90)"
fi
ok "adaptateurs réels : Pollinations · AI Horde · Ollama · ports OpenAI · GLM · Gemini · OpenRouter ·free · Groq · Cerebras · HF · Cloudflare · science (14 sources)"
ok "aucune option « document » : chaque service = endpoint réel + adaptateur HTTP"
