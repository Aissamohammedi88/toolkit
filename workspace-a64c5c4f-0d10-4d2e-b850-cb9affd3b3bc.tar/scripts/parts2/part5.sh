#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════
#  NEXUS AETHER — UPGRADE PRO v2.0.0 (PARTIE 5/5)
#  Phase 7 : SERVICE SYSTÈME (le serveur ne meurt plus)
#  Phase 8 : clés API réelles · Bureau · README
#  Phase 9 : rapport
# ══════════════════════════════════════════════════════════════════════

# ════════════════════════════════════════════════════════════════════
phase 7 "SERVICE SYSTÈME — le serveur survit à la fermeture du PC"
# ════════════════════════════════════════════════════════════════════
mkdir -p "$CONF_DIR" "$WORKSPACE"
if command -v systemctl >/dev/null 2>&1 && systemctl --user daemon-reload >/dev/null 2>&1; then
  UNIT="$HOME/.config/systemd/user/aether.service"
  mkdir -p "$HOME/.config/systemd/user"
  ELECTRON_DIST="$APP_DIR/node_modules/electron/dist/electron"
  if [ -x "$ELECTRON_DIST" ]; then
    EXEC_LINE="$ELECTRON_DIST $APP_DIR"
  else
    EXEC_LINE="/usr/bin/node $APP_DIR/server/core.js"
    warn "Electron absent — le service tournera en node pur (serveur sans fenêtre)"
  fi
  cat > "$UNIT" <<AE_UNIT
[Unit]
Description=NEXUS AETHER — serveur de production (moteur 90+ services)
PartOf=graphical-session.target
After=graphical-session.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
Environment=AETHER_PORT=$PORT
Environment=AETHER_PROD=1
Environment=AETHER_WORKSPACE=$WORKSPACE
Environment=AETHER_ROOT=$APP_DIR
Environment=AETHER_HEADLESS=1
Environment=DISPLAY=:0
Environment=ELECTRON_DISABLE_SECURITY_WARNINGS=true
EnvironmentFile=-$CONF_DIR/env
ExecStart=$EXEC_LINE
Restart=always
RestartSec=3

[Install]
WantedBy=graphical-session.target
AE_UNIT
  ok "unité systemd utilisateur écrite : $UNIT"
  systemctl --user daemon-reload && ok "daemon-reload ✓"
  if systemctl --user enable --now aether.service >/dev/null 2>&1; then
    ok "service activé : démarre avec ta session, redémarre tout seul (Restart=always)"
    sleep 4
    if curl -s --max-time 3 "http://127.0.0.1:$PORT/api/health" | grep -q '"ok":true'; then
      ok "DAEMON DE PRODUCTION EN LIGNE sur 127.0.0.1:$PORT — fermer la fenêtre ne le tue plus"
    else
      warn "le daemon vient d'être lancé — vérifie dans 10 s : curl http://127.0.0.1:$PORT/api/health"
    fi
  else
    warn "enable a échoué — lance à la main : systemctl --user enable --now aether.service"
  fi
  if loginctl enable-linger "$USER" >/dev/null 2>&1; then
    ok "linger activé — le service survit aux fermetures de session"
  else
    warn "linger (survie totale) — si tu le veux : sudo loginctl enable-linger $USER"
  fi
  chk "unit systemd valide" "systemd-analyze --user verify '$HOME/.config/systemd/user/aether.service' 2>/dev/null || systemctl --user cat aether.service >/dev/null"
else
  warn "systemd indisponible dans cet environnement — le serveur vivra via le lanceur (comportement v1 conservé)"
fi

# ════════════════════════════════════════════════════════════════════
phase 8 "Clés API réelles · Bureau · README"
# ════════════════════════════════════════════════════════════════════
cat > scripts/aether-keys.js <<'AE_KEYS'
'use strict';
// NEXUS AETHER v2 — enregistreur de clés API (sécurisé, chmod 600)
const fs = require('fs');
const path = require('path');
const os = require('os');
const readline = require('readline');

const APP = path.join(__dirname, '..');
const SECRETS = path.join(os.homedir(), '.aether', 'secrets.json');
const ENVF = path.join(os.homedir(), '.aether', 'env');

let svc;
try { svc = JSON.parse(fs.readFileSync(path.join(APP, 'config', 'services.json'), 'utf8')); }
catch (e) { console.error('catalogue illisible : ' + e.message); process.exit(1); }
const keys = Array.from(new Set(svc.services.filter(function (s) { return s.keyEnv; }).map(function (s) { return s.keyEnv; })));

let cur = {};
try { cur = JSON.parse(fs.readFileSync(SECRETS, 'utf8')); } catch (e) {}

if (!process.stdin.isTTY) {
  console.log('Clés attendues par le catalogue (' + keys.length + ') :');
  keys.forEach(function (k) { console.log('  ' + k + ' : ' + (cur[k] ? 'définie' : 'absente') + (process.env[k] ? ' (env ok)' : '')); });
  console.log('Lance scripts/aether-keys.sh dans un terminal pour les saisir.');
  process.exit(0);
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
console.log('NEXUS AETHER — clés API (' + keys.length + ' services à clé). Entrée vide = garder la valeur actuelle.');
(async function () {
  for (let i = 0; i < keys.length; i++) {
    const k = keys[i];
    const state = cur[k] ? 'définie' : 'absente';
    const envNote = process.env[k] ? ' [env ok]' : '';
    const v = await new Promise(function (res) { rl.question('  ' + k + ' [' + state + ']' + envNote + ' : ', res); });
    if (v && v.trim()) cur[k] = v.trim();
  }
  rl.close();
  fs.mkdirSync(path.dirname(SECRETS), { recursive: true });
  fs.writeFileSync(SECRETS, JSON.stringify(cur, null, 2) + '\n');
  fs.writeFileSync(ENVF, keys.filter(function (k) { return cur[k]; }).map(function (k) { return k + '=' + cur[k]; }).join('\n') + '\n');
  fs.chmodSync(SECRETS, 0o600);
  fs.chmodSync(ENVF, 0o600);
  console.log('✓ clés enregistrées (chmod 600) : ~/.aether/secrets.json + ~/.aether/env');
  console.log('  le service système les recharge : systemctl --user restart aether');
})().catch(function (e) { console.error(e.message); process.exit(1); });
AE_KEYS
cat > scripts/aether-keys.sh <<'AE_KEYSH'
#!/usr/bin/env bash
# NEXUS AETHER v2 — saisie des clés API (réelle, persistante, chmod 600)
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
exec node "$DIR/scripts/aether-keys.js"
AE_KEYSH
chmod +x scripts/aether-keys.sh
ok "scripts/aether-keys.sh — vrai gestionnaire de clés (17 fournisseurs, chmod 600, rechargement service)"
chk "aether-keys.js syntaxe" "node --check '$APP_DIR/scripts/aether-keys.js'"

# ── Bureau : entrée v2 ───────────────────────────────────────────────
cat > build/nexus-aether.desktop <<AE_DSK
[Desktop Entry]
Type=Application
Version=2.0
Name=NEXUS AETHER
GenericName=Studio de génération souverain
Comment=Moteur 90+ services réels · production · service système · port ${PORT}
Exec=${APP_DIR}/scripts/aether-launch.sh
Icon=${APP_DIR}/assets/aether.svg
Path=${APP_DIR}
Terminal=false
Categories=Development;Utility;
StartupNotify=true
StartupWMClass=nexus-aether
AE_DSK
ok "build/nexus-aether.desktop — v2"
if [ "$NO_DESKTOP" = "1" ]; then
  warn "AETHER_NO_DESKTOP=1 — raccourcis non réinstallés"
else
  APPS_DIR="$HOME/.local/share/applications"
  mkdir -p "$APPS_DIR"
  cp build/nexus-aether.desktop "$APPS_DIR/nexus-aether.desktop"
  DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Bureau")"
  mkdir -p "$DESKTOP_DIR"
  cp build/nexus-aether.desktop "$DESKTOP_DIR/nexus-aether.desktop"
  chmod +x "$DESKTOP_DIR/nexus-aether.desktop" 2>/dev/null || true
  gio set "$DESKTOP_DIR/nexus-aether.desktop" metadata::trusted true 2>/dev/null || true
  ok "raccourcis Bureau + menu mis à jour (v2)"
fi

# ── README v2 ────────────────────────────────────────────────────────
cat > README.md <<'AE_README2'
# NEXUS AETHER — v2.0.0 PRO
Studio de génération **réel**, en **production**, avec **service système**.

## Ce qui a changé en v2
1. **MOTEUR RÉEL** — plus de modèles pré-écrits : le Moteur appelle de VRAIES API
   (adaptateurs HTTP vérifiés en direct). 90+ services, dont des dizaines SANS clé.
2. **PRODUCTION** — le code cœur vit scellé dans `app.asar` ; le graphe de fichiers
   est verrouillé sur `~/Aether/workspace` (tes résultats), pas sur les sources.
3. **SERVICE SYSTÈME** — `aether.service` (systemd utilisateur) : le serveur
   démarre avec ta session, redémarre tout seul, et NE MEURT PLUS quand tu fermes
   la fenêtre ou le PC.
4. **CLÉS SÉCURISÉES** — `scripts/aether-keys.sh` : saisie unique, stockage
   chmod 600, rechargement du service.

## Les 3 zones
| Zone | Chemin | Rôle |
|---|---|---|
| App (code scellé) | `~/Aether/app.asar` | cœur + interface, non modifiable à chaud |
| Résultats | `~/Aether/workspace/` | textes, images, workflows YAML, audio |
| Config perso | `~/.aether/` | clés, catalogue perso, mémoire, historique |

## Utiliser le Moteur
- Onglet **☀ Moteur** (ouvre par défaut) → choisis un service (points de santé en direct) → décris → **⚡ Générer**
- `/gen <idée>` dans l'orbe → génère direct
- **◈ Workflow GitHub Actions** → YAML RÉEL généré puis validé (js-yaml) et extrait dans `workspace/workflows/`

## Services gratuits SANS clé (fonctionnent immédiatement)
- Pollinations Texte + Image (limite gratuite : ~1 réponse/30 s, gérée)
- AI Horde Texte + Image (ruche communautaire, clé anonyme intégrée)
- 14 sources scientifiques réelles : arXiv, PubMed, OpenAlex, Crossref, HAL, Zenodo, NASA…
- Tous les services locaux détectés automatiquement : Ollama, LM Studio, ComfyUI, A1111…

## Services gratuits AVEC clé (paliers gratuits)
`scripts/aether-keys.sh` puis coller la clé :
GLM/Z.ai · Gemini · Groq · Cerebras · Mistral · Cohere · Together (FLUX gratuit) ·
OpenRouter (:free) · GitHub Models · Cloudflare Workers AI · HuggingFace · NVIDIA NIM…

## Service système
```bash
systemctl --user status aether     # état
systemctl --user restart aether    # après ajout de clé
systemctl --user stop aether       # arrêt
journalctl --user -u aether -f     # logs
```
Le serveur écoute sur 127.0.0.1:8420 (repli 8421+). Ouvrir l'app = fenêtre
branchée sur ce serveur. Fermer la fenêtre ne l'arrête pas.

## Dépannage
- Coffre cassé ? `~/Aether/scripts/aether-repair.sh`
- Retour au code visible ? `~/Aether/scripts/aether-repair.sh` puis relance
- Sauvegardes : `~/Aether/.backup-v2-<date>/` et `~/.nexus-aether/src-backup-<date>/`
AE_README2
ok "README v2 — mode d'emploi production"

if command -v git >/dev/null 2>&1 && [ -d .git ]; then
  git add -A >/dev/null 2>&1 || true
  git commit -q -m "v2.0.0 PRO — moteur réel 90+ services, production (asar + workspace), service systemd" 2>/dev/null && ok "commit git v2 créé" || info "commit git : rien de nouveau ou identité absente"
fi

# ════════════════════════════════════════════════════════════════════
phase 9 "Rapport"
# ════════════════════════════════════════════════════════════════════
echo
echo -e "  ${C_B}Bilan : ${C_GRN}$PASS réussis${C_RST} / ${C_RED}$FAIL échoués${C_RST}"
if [ "$FAIL" -eq 0 ]; then
  echo -e "  ${C_GRN}${C_B}✦ NEXUS AETHER v2 PRO — moteur réel, production, service système : TOUT EST VERT.${C_RST}"
else
  echo -e "  ${C_YLW}Des échecs subsistent — relance ce script (idempotent, il reprend où il faut).${C_RST}"
fi
echo
cat <<AE_RPT

  ── CE QUI EST MAINTENANT RÉEL ─────────────────────────────────────
  · Moteur          : ${SVC_COUNT:-93} services câblés sur de vrais endpoints (0 document mort)
  · Sans clé        : Pollinations (texte+image) · AI Horde (texte+image) · 14 sources science · tous les locaux (Ollama…)
  · Production      : app.asar scellé · graphe verrouillé sur workspace · raccourcis v2
  · Serveur         : service systemd « aether » — Restart=always, survit à la fermeture
  · Résultats       : $WORKSPACE (textes, images, workflows, audio)
  · Clés            : ~/Aether/scripts/aether-keys.sh  → chmod 600

  ── PREUVES LAISSÉES PAR LES TESTS ────────────────────────────────
  · /tmp/aether-health.json   : état mesuré de chaque service
  · $WORKSPACE/workflows/   : YAML réellement généré et validé
  · $WORKSPACE/textes/      : réponses réellement générées

  ── COMMANDES ─────────────────────────────────────────────────────
  · Ouvrir l'app        : menu → NEXUS AETHER  (fenêtre branchée au service)
  · Orbe                : /gen <idée> · /moteur · /help
  · Clés API            : ~/Aether/scripts/aether-keys.sh
  · Logs service        : journalctl --user -u aether -f
AE_RPT
if [ -f /tmp/aether-health.json ]; then
  node -e "
    const j=JSON.parse(require('fs').readFileSync('/tmp/aether-health.json','utf8'));
    const s=j.summary||{};
    console.log('');
    console.log('  Santé mesurée en direct : '+(s.online||0)+' en ligne · '+(s.pret||0)+' prêts avec clé · '+(s['needs-key']||0)+' en attente de clé · '+(s.offline||0)+(s.erreur?'+'+s.erreur:'')+' hors ligne');
    console.log('  Gratuits SANS clé fonctionnels : '+(s.freeOnline||0));
  " 2>/dev/null || true
fi
echo
if [ -t 0 ]; then
  echo -e "${C_DIM}— Appuie sur ENTRÉE pour fermer ce terminal —${C_RST}"
  read -r _
fi
echo
[ "$FAIL" -eq 0 ] && exit 0 || exit 1
