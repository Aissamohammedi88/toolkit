#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════
#  NEXUS AETHER — UPGRADE PRO v2.0.0 (PARTIE 2/5)
#  Phase 2 (suite) : core/engine.js — LE MOTEUR DE GÉNÉRATION RÉEL
# ══════════════════════════════════════════════════════════════════════

cat > core/engine.js <<'AE_ENGINE'
'use strict';
// ═════════════════════════════════════════════════════════════════════
// NEXUS AETHER v2 — MOTEUR DE GÉNÉRATION RÉEL
// Chaque service du catalogue est branché sur un ADAPTATEUR HTTP qui
// appelle le VRAI endpoint. Aucune réponse pré-écrite. Aucun modèle de
// démo. Les limites gratuites (throttling) sont gérées et annoncées.
// ═════════════════════════════════════════════════════════════════════
const fs = require('fs');
const path = require('path');
const os = require('os');

const HOME = os.homedir();
const CONF_DIR = path.join(HOME, '.aether');
const BUNDLED_SERVICES = path.join(__dirname, '..', 'config', 'services.json');
const USER_SERVICES = path.join(CONF_DIR, 'services.json');
const SECRETS_FILE = path.join(CONF_DIR, 'secrets.json');
const HISTORY_FILE = path.join(CONF_DIR, 'engine-history.jsonl');
const POLL_MODELS_FILE = path.join(CONF_DIR, 'pollinations-models.json');
const WORKSPACE = process.env.AETHER_WORKSPACE || path.join(HOME, 'Aether', 'workspace');

let YAML_LIB = null;
try { YAML_LIB = require('js-yaml'); } catch (e) { YAML_LIB = null; }

// ── Workspace (« extraction des résultats ») ─────────────────────────
function ensureWorkspace() {
  ['textes', 'images', 'workflows', 'audio', 'projets'].forEach(function (d) {
    try { fs.mkdirSync(path.join(WORKSPACE, d), { recursive: true }); } catch (e) {}
  });
}
ensureWorkspace();

function slugify(s) {
  return String(s || 'aether').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48) || 'aether';
}

function saveOut(kind, ext, dataBuf) {
  ensureWorkspace();
  const dir = path.join(WORKSPACE, kind);
  const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const name = 'aether-' + ts + '-' + Math.floor(Math.random() * 9000 + 1000) + '.' + ext;
  const file = path.join(dir, name);
  fs.writeFileSync(file, dataBuf);
  return file;
}

function getSecret(keyEnv) {
  if (!keyEnv) return '';
  if (process.env[keyEnv]) return process.env[keyEnv];
  try {
    const j = JSON.parse(fs.readFileSync(SECRETS_FILE, 'utf8'));
    if (j[keyEnv]) return String(j[keyEnv]);
  } catch (e) {}
  return '';
}

// ── Catalogue (copie ~/.aether/services.json prioritaire) ────────────
function loadServices() {
  let src = null;
  try { if (fs.existsSync(USER_SERVICES)) src = JSON.parse(fs.readFileSync(USER_SERVICES, 'utf8')); } catch (e) {}
  if (!src || !Array.isArray(src.services) || !src.services.length) {
    src = JSON.parse(fs.readFileSync(BUNDLED_SERVICES, 'utf8'));
  }
  return src.services.map(function (s) {
    return {
      id: s.id, name: s.name, cat: s.cat || 'texte', adapter: s.adapter || 'openai',
      url: s.url || '', model: s.model || '', keyEnv: s.keyEnv || '', accountEnv: s.accountEnv || '',
      tier: s.tier || 'gratuit', free: !!s.free, docs: s.docs || ''
    };
  });
}
function findService(id) {
  const list = loadServices();
  return list.find(function (s) { return s.id === id; }) || null;
}

// ── Utilitaires réseau ───────────────────────────────────────────────
const DEFAULT_UA = 'nexus-aether/2.0.0 (application locale; utilisateur souverain)';
function fetchTimeout(url, opts, ms) {
  const ctl = new AbortController();
  const timer = setTimeout(function () { try { ctl.abort(); } catch (e) {} }, ms || 30000);
  const o = Object.assign({}, opts || {}, { signal: ctl.signal });
  o.headers = Object.assign({}, (opts && opts.headers) || {});
  if (!o.headers['User-Agent'] && !o.headers['user-agent']) o.headers['User-Agent'] = DEFAULT_UA;
  return fetch(url, o).finally(function () { clearTimeout(timer); });
}

async function readBody(res, maxBytes) {
  const ab = await res.arrayBuffer();
  const max = maxBytes || 12 * 1024 * 1024;
  if (ab.byteLength > max) throw new Error('réponse trop grosse (' + ab.byteLength + ' o)');
  return Buffer.from(ab);
}

function friendlyHttp(status, body) {
  const t = String(body || '').slice(0, 240).replace(/\s+/g, ' ');
  if (status === 401 || status === 403) return 'refusé par l\u2019API (401/403) — clé absente ou invalide';
  if (status === 404) return 'endpoint 404 — vérifie l\u2019url du service';
  if (status === 429) return 'limite gratuite atteinte (429) — attends un peu puis réessaie';
  if (status === 503) return 'service saturé (503) — l\u2019API gratuite demande d\u2019attendre (Retry-After)';
  return 'HTTP ' + status + (t ? ' — ' + t : '');
}

function extFromMime(ct, fallback) {
  const m = String(ct || '').toLowerCase();
  if (m.indexOf('png') !== -1) return 'png';
  if (m.indexOf('jpeg') !== -1 || m.indexOf('jpg') !== -1) return 'jpg';
  if (m.indexOf('webp') !== -1) return 'webp';
  if (m.indexOf('gif') !== -1) return 'gif';
  if (m.indexOf('mpeg') !== -1 || m.indexOf('mp3') !== -1) return 'mp3';
  if (m.indexOf('wav') !== -1) return 'wav';
  return fallback || 'bin';
}

// ── Mots-clés pour les sources scientifiques ─────────────────────────
const STOP = new Set(['le','la','les','un','une','des','du','de','et','ou','pour','avec','dans','sur','par','que','qui','quoi','comment','pourquoi','est','sont','the','of','in','for','with','about','how','what','why','and','or','to','a','an','me','moi','mon','ma','mes','fais','fait','faire','genere','génère','donne','donner','cherche','trouve','plus','moins','entre','sans','leur','cette','cet','ce','au','aux','en','il','elle','on','nous','vous','ils','elles','je','tu','se','sa','son','ses','y','d','l','n','s','t']);
function keywords(prompt, n) {
  const words = String(prompt || '').replace(/[^\p{L}\p{N}\s-]/gu, ' ').split(/\s+/)
    .filter(function (w) { return w.length > 2 && !STOP.has(w.toLowerCase()); });
  return (words.slice(0, n || 8).join(' ') || String(prompt || '').slice(0, 40)).trim();
}

function stripTags(s) {
  return String(s || '').replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
}

// ═════════════════════════════════════════════════════════════════════
// ADAPTATEURS — chaque fonction fait un VRAI appel réseau
// ═════════════════════════════════════════════════════════════════════
const ADAPTERS = {};

// 1) Pollinations TEXTE — gratuit sans clé (limite : 1 réponse / 30 s / IP)
ADAPTERS['pollinations-text'] = async function (svc, task) {
  const model = task.model || svc.model || 'openai-fast';
  const messages = [];
  if (task.system) messages.push({ role: 'system', content: String(task.system) });
  messages.push({ role: 'user', content: String(task.prompt || '') });
  const res = await fetchTimeout(svc.url.replace(/\/+$/, '') + '/', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages: messages, model: model, private: true })
  }, 60000);
  const retryAfter = parseInt(res.headers.get('retry-after') || '0', 10);
  if (res.status === 429 || res.status === 503) {
    const body = (await readBody(res)).toString('utf8');
    throw new Error('Pollinations : limite gratuite (' + (retryAfter || 30) + ' s entre les réponses par IP) — réessaie dans ' + (retryAfter || 30) + ' s. ' + friendlyHttp(res.status, body));
  }
  const body = (await readBody(res)).toString('utf8');
  if (!res.ok) throw new Error('Pollinations : ' + friendlyHttp(res.status, body));
  const ct = res.headers.get('content-type') || '';
  let text;
  if (ct.indexOf('json') !== -1) {
    try {
      const j = JSON.parse(body);
      text = (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || j.message || body.slice(0, 4000);
    } catch (e) { text = body; }
  } else { text = body; }
  return { text: String(text).trim(), service: svc.id, model: model };
};

// 2) Pollinations IMAGE — gratuit sans clé (Retry-After géré)
ADAPTERS['pollinations-image'] = async function (svc, task) {
  const q = '?width=' + (task.width || 768) + '&height=' + (task.height || 768) +
    '&model=' + encodeURIComponent(task.model || svc.model || 'sana') + '&nologo=true&seed=' + Math.floor(Math.random() * 1e9);
  const url = svc.url.replace(/\/+$/, '') + '/prompt/' + encodeURIComponent(String(task.prompt || '').slice(0, 900)) + q;
  let res = await fetchTimeout(url, { method: 'GET' }, 90000);
  if (res.status === 503 || res.status === 429) {
    const wait = Math.min(parseInt(res.headers.get('retry-after') || '10', 10) || 10, 20);
    const body1 = (await readBody(res)).toString('utf8');
    await new Promise(function (r) { setTimeout(r, wait * 1000); });
    res = await fetchTimeout(url, { method: 'GET' }, 90000);
    if (res.status === 503 || res.status === 429) {
      throw new Error('Pollinations Image : file gratuite saturée — réessaie dans ~' + wait + ' s (' + friendlyHttp(res.status, body1) + ')');
    }
  }
  if (!res.ok) throw new Error('Pollinations Image : ' + friendlyHttp(res.status, await readBody(res)));
  const buf = await readBody(res);
  const ct = res.headers.get('content-type') || '';
  if (ct.indexOf('image') === -1) throw new Error('Pollinations Image : réponse inattendue (' + ct + ') : ' + buf.toString('utf8').slice(0, 200));
  const file = saveOut('images', extFromMime(ct, 'jpg'), buf);
  return { file: file, service: svc.id, bytes: buf.length, kind: 'image' };
};

// 3) Pollinations AUDIO
ADAPTERS['pollinations-audio'] = async function (svc, task) {
  const res = await fetchTimeout(svc.url.replace(/\/+$/, '') + '/', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: task.model || svc.model || 'openai-audio', messages: [{ role: 'user', content: String(task.prompt || '') }] })
  }, 90000);
  if (!res.ok) throw new Error('Pollinations Audio : ' + friendlyHttp(res.status, await readBody(res)));
  const ct = res.headers.get('content-type') || '';
  const buf = await readBody(res);
  if (ct.indexOf('audio') === -1) throw new Error('Pollinations Audio : pas de flux audio (' + ct + ') — palier gratuit sans voix ? ' + buf.toString('utf8').slice(0, 160));
  const file = saveOut('audio', extFromMime(ct, 'mp3'), buf);
  return { file: file, service: svc.id, bytes: buf.length, kind: 'audio' };
};

// 4-6) AI HORDE — gratuit sans clé (clé anonyme intégrée : 0000000000)
function hordeHeaders() {
  return { 'Content-Type': 'application/json', 'apikey': '0000000000', 'Client-Agent': 'nexus-aether:2.0.0:standalone' };
}
async function hordePoll(svc, kind, jobId, maxWaitS) {
  const base = svc.url.replace(/\/+$/, '');
  const checkUrl = kind === 'text' ? base + '/generate/text/status/' + jobId : base + '/generate/check/' + jobId;
  const statusUrl = kind === 'text' ? base + '/generate/text/status/' + jobId : base + '/generate/status/' + jobId;
  const deadline = Date.now() + Math.min(Math.max(maxWaitS || 120, 5), 240) * 1000;
  while (Date.now() < deadline) {
    await new Promise(function (r) { setTimeout(r, kind === 'text' ? 5000 : 4000); });
    let st;
    try { st = await (await fetchTimeout(checkUrl, { headers: hordeHeaders() }, 15000)).json(); }
    catch (e) { continue; }
    if (st.faulted) throw new Error('AI Horde : génération en échec côté ruche — réessaie');
    if (st.done) {
      const fin = await (await fetchTimeout(statusUrl, { headers: hordeHeaders() }, 20000)).json();
      if (kind === 'text') {
        const txt = (fin.generations && fin.generations[0] && fin.generations[0].text) || '';
        return { text: txt.trim(), service: svc.id, model: (fin.generations && fin.generations[0] && fin.generations[0].model) || 'horde' };
      }
      const g = (fin.generations && fin.generations[0]) || {};
      if (!g.img) throw new Error('AI Horde : terminé mais image vide (censuré ?)');
      const buf = Buffer.from(g.img, 'base64');
      const file = saveOut('images', buf.slice(0, 4).toString() === 'RIFF' ? 'webp' : 'webp', buf);
      return { file: file, service: svc.id, bytes: buf.length, kind: 'image', model: g.model, worker: g.worker_name };
    }
  }
  return { pending: true, service: svc.id, adapter: kind === 'text' ? 'horde-text' : 'horde-image', jobId: jobId,
    pollHint: 'POST /api/engine/poll {service, jobId} pour récupérer le résultat quand la ruche aura terminé' };
}
ADAPTERS['horde-text'] = async function (svc, task) {
  const res = await fetchTimeout(svc.url.replace(/\/+$/, '') + '/generate/text/async', {
    method: 'POST', headers: hordeHeaders(),
    body: JSON.stringify({ prompt: String(task.prompt || ''), params: { max_length: 256, max_context_length: 1024 }, models: [] })
  }, 30000);
  const body = await readBody(res);
  if (!res.ok) throw new Error('AI Horde : ' + friendlyHttp(res.status, body.toString('utf8')));
  const j = JSON.parse(body.toString('utf8'));
  if (!j.id) throw new Error('AI Horde : pas de jobId — ' + JSON.stringify(j).slice(0, 200));
  return hordePoll(svc, 'text', j.id, task.maxWaitS);
};
ADAPTERS['horde-image'] = async function (svc, task) {
  const payload = {
    prompt: String(task.prompt || ''),
    params: { width: Math.min(task.width || 512, 1024), height: Math.min(task.height || 512, 1024), steps: 20, n: 1, karras: true },
    nsfw: false, censor_nsfw: true, shared: false,
    models: [svc.model || 'stable_diffusion']
  };
  const res = await fetchTimeout(svc.url.replace(/\/+$/, '') + '/generate/async', {
    method: 'POST', headers: hordeHeaders(), body: JSON.stringify(payload)
  }, 30000);
  const body = await readBody(res);
  if (!res.ok) throw new Error('AI Horde : ' + friendlyHttp(res.status, body.toString('utf8')));
  const j = JSON.parse(body.toString('utf8'));
  if (!j.id) throw new Error('AI Horde : pas de jobId — ' + JSON.stringify(j).slice(0, 200));
  return hordePoll(svc, 'image', j.id, task.maxWaitS);
};
ADAPTERS['horde-caption'] = async function (svc, task) {
  if (!task.image) throw new Error('AI Horde Caption : donne opts.image = chemin d\u2019une image du workspace');
  const imgPath = path.resolve(String(task.image));
  if (imgPath.indexOf(WORKSPACE) !== 0) throw new Error('image hors workspace refusée');
  const b64 = fs.readFileSync(imgPath).toString('base64');
  const res = await fetchTimeout(svc.url.replace(/\/+$/, '') + '/alchemy/async', {
    method: 'POST', headers: hordeHeaders(),
    body: JSON.stringify({ forms: [{ name: 'caption' }], source_image: b64, source_processing: 'img2img' })
  }, 30000);
  const body = await readBody(res);
  if (!res.ok) throw new Error('AI Horde Alchemy : ' + friendlyHttp(res.status, body.toString('utf8')));
  const j = JSON.parse(body.toString('utf8'));
  if (!j.id) throw new Error('AI Horde Alchemy : pas de jobId — ' + JSON.stringify(j).slice(0, 200));
  const deadline = Date.now() + Math.min(Math.max(task.maxWaitS || 90, 10), 240) * 1000;
  while (Date.now() < deadline) {
    await new Promise(function (r) { setTimeout(r, 4000); });
    let st;
    try { st = await (await fetchTimeout(svc.url.replace(/\/+$/, '') + '/alchemy/status/' + j.id, { headers: hordeHeaders() }, 15000)).json(); }
    catch (e) { continue; }
    if (st.done) {
      const cap = (st.result && st.result[0] && st.result[0].caption) || (st.result && st.result[0] && st.result[0].text) || '';
      return { text: String(cap).trim(), service: svc.id };
    }
    if (st.faulted) throw new Error('AI Horde Alchemy : échec côté ruche');
  }
  return { pending: true, service: svc.id, adapter: 'horde-caption', jobId: j.id };
};

// 7-8) OLLAMA local (chat + embeddings)
ADAPTERS['ollama'] = async function (svc, task) {
  const messages = [];
  if (task.system) messages.push({ role: 'system', content: String(task.system) });
  messages.push({ role: 'user', content: String(task.prompt || '') });
  const payload = { model: task.model || svc.model || 'llama3', messages: messages, stream: false };
  if (task.image) {
    const imgPath = path.resolve(String(task.image));
    if (imgPath.indexOf(WORKSPACE) === 0 && fs.existsSync(imgPath)) {
      payload.images = [fs.readFileSync(imgPath).toString('base64')];
    }
  }
  let res;
  try {
    res = await fetchTimeout(svc.url.replace(/\/+$/, '') + '/api/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
    }, 180000);
  } catch (e) {
    throw new Error('Ollama injoignable sur ' + svc.url + ' — lance « ollama serve » puis « ollama pull ' + (task.model || svc.model || 'llama3') + ' »');
  }
  const j = JSON.parse((await readBody(res)).toString('utf8'));
  if (j.error) throw new Error('Ollama : ' + j.error);
  return { text: String((j.message && j.message.content) || '').trim(), service: svc.id, model: payload.model };
};
ADAPTERS['ollama-embed'] = async function (svc, task) {
  let res;
  try {
    res = await fetchTimeout(svc.url.replace(/\/+$/, '') + '/api/embeddings', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: task.model || svc.model || 'nomic-embed-text', prompt: String(task.prompt || '') })
    }, 60000);
  } catch (e) { throw new Error('Ollama injoignable — lance « ollama serve »'); }
  const j = JSON.parse((await readBody(res)).toString('utf8'));
  if (j.error) throw new Error('Ollama embeddings : ' + j.error);
  const v = j.embedding || [];
  return { text: 'embedding ' + v.length + ' dimensions — ' + v.slice(0, 8).map(function (x) { return x.toFixed(4); }).join(', ') + ' …', vector: v.slice(0, 64), service: svc.id };
};

// 9-10) Ports locaux OpenAI-compatible (LM Studio, llama.cpp, GPT4All…)
async function pickPortModel(svc) {
  try {
    const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '/v1/models', { method: 'GET' }, 8000);
    const j = await r.json();
    const id = j.data && j.data[0] && j.data[0].id;
    if (id) return id;
  } catch (e) {}
  return '';
}
ADAPTERS['openai-port'] = async function (svc, task) {
  let model = task.model || svc.model || '';
  if (!model) model = await pickPortModel(svc);
  const messages = [];
  if (task.system) messages.push({ role: 'system', content: String(task.system) });
  messages.push({ role: 'user', content: String(task.prompt || '') });
  const headers = { 'Content-Type': 'application/json' };
  const key = getSecret(svc.keyEnv);
  if (key) headers['Authorization'] = 'Bearer ' + key;
  let res;
  try {
    res = await fetchTimeout(svc.url.replace(/\/+$/, '') + '/v1/chat/completions', {
      method: 'POST', headers: headers,
      body: JSON.stringify({ model: model || undefined, messages: messages, stream: false })
    }, 180000);
  } catch (e) {
    throw new Error('service local injoignable sur ' + svc.url + ' — est-il lancé ? (' + String((e && e.message) || e) + ')');
  }
  const body = (await readBody(res)).toString('utf8');
  if (!res.ok) throw new Error('port local : ' + friendlyHttp(res.status, body));
  const j = JSON.parse(body);
  return { text: String((j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '').trim(), service: svc.id, model: model };
};
ADAPTERS['openai-embed'] = async function (svc, task) {
  const headers = { 'Content-Type': 'application/json' };
  const key = getSecret(svc.keyEnv);
  if (key) headers['Authorization'] = 'Bearer ' + key;
  const res = await fetchTimeout(svc.url.replace(/\/+$/, '') + '/v1/embeddings', {
    method: 'POST', headers: headers,
    body: JSON.stringify({ model: task.model || svc.model, input: String(task.prompt || '') })
  }, 60000);
  const body = (await readBody(res)).toString('utf8');
  if (!res.ok) throw new Error('embeddings : ' + friendlyHttp(res.status, body));
  const j = JSON.parse(body);
  const v = (j.data && j.data[0] && j.data[0].embedding) || [];
  return { text: 'embedding ' + v.length + ' dimensions', vector: v.slice(0, 64), service: svc.id };
};

// 11) OpenAI-compatible (GLM, OpenRouter, Groq, Cerebras, HF, Mistral…)
ADAPTERS['openai'] = async function (svc, task) {
  const key = getSecret(svc.keyEnv);
  if (!key) throw new Error('« ' + svc.name + ' » : clé absente — export ' + svc.keyEnv + '=… ou lance scripts/aether-keys.sh');
  let model = task.model || svc.model || '';
  if (!model && svc.url.indexOf('openrouter') !== -1) {
    try {
      const r = await fetchTimeout('https://openrouter.ai/api/v1/models', { method: 'GET' }, 10000);
      const j = await r.json();
      const free = (j.data || []).filter(function (m) { return String(m.id).endsWith(':free'); });
      if (free.length) model = free[0].id;
    } catch (e) {}
  }
  if (!model) throw new Error('« ' + svc.name + ' » : aucun modèle défini (opts.model ou catalogue)');
  const messages = [];
  if (task.system) messages.push({ role: 'system', content: String(task.system) });
  messages.push({ role: 'user', content: String(task.prompt || '') });
  const res = await fetchTimeout(svc.url.replace(/\/+$/, ''), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
    body: JSON.stringify({ model: model, messages: messages, stream: false, temperature: 0.7 })
  }, 120000);
  const body = (await readBody(res)).toString('utf8');
  if (!res.ok) {
    let detail = friendlyHttp(res.status, body);
    try { const j = JSON.parse(body); if (j.error && j.error.message) detail = j.error.message; } catch (e) {}
    throw new Error('« ' + svc.name + ' » : ' + detail);
  }
  const j = JSON.parse(body);
  return { text: String((j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '').trim(), service: svc.id, model: model };
};

// 12) Images via API OpenAI-compatible (CogView, FLUX Together…)
ADAPTERS['openai-image'] = async function (svc, task) {
  const key = getSecret(svc.keyEnv);
  if (!key) throw new Error('« ' + svc.name + ' » : clé absente — export ' + svc.keyEnv + '=…');
  const res = await fetchTimeout(svc.url.replace(/\/+$/, ''), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
    body: JSON.stringify({ model: task.model || svc.model, prompt: String(task.prompt || ''), n: 1, size: ((task.width || 512) + 'x' + (task.height || 512)) })
  }, 120000);
  const body = (await readBody(res)).toString('utf8');
  if (!res.ok) throw new Error('« ' + svc.name + ' » : ' + friendlyHttp(res.status, body));
  const j = JSON.parse(body);
  const d = (j.data && j.data[0]) || {};
  if (d.b64_json) {
    const buf = Buffer.from(d.b64_json, 'base64');
    return { file: saveOut('images', 'png', buf), service: svc.id, bytes: buf.length, kind: 'image' };
  }
  if (d.url) {
    const r2 = await fetchTimeout(d.url, { method: 'GET' }, 60000);
    const buf = await readBody(r2);
    return { file: saveOut('images', extFromMime(r2.headers.get('content-type'), 'png'), buf), service: svc.id, bytes: buf.length, kind: 'image' };
  }
  throw new Error('« ' + svc.name + ' » : ni b64 ni url dans la réponse');
};

// 13) Gemini
ADAPTERS['gemini'] = async function (svc, task) {
  const key = getSecret(svc.keyEnv);
  if (!key) throw new Error('« ' + svc.name + ' » : clé absente — export ' + svc.keyEnv + '=… (aistudio.google.com/apikey)');
  const url = svc.url.replace(/\/+$/, '') + '/models/' + (task.model || svc.model) + ':generateContent?key=' + encodeURIComponent(key);
  const body = { contents: [{ role: 'user', parts: [{ text: String(task.prompt || '') }] }] };
  if (task.system) body.systemInstruction = { parts: [{ text: String(task.system) }] };
  const res = await fetchTimeout(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }, 120000);
  const j = JSON.parse((await readBody(res)).toString('utf8'));
  if (!res.ok) throw new Error('Gemini : ' + ((j.error && j.error.message) || friendlyHttp(res.status)));
  const parts = (j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || [];
  return { text: parts.map(function (p) { return p.text || ''; }).join('').trim(), service: svc.id, model: task.model || svc.model };
};

// 14) Anthropic (API Messages)
ADAPTERS['anthropic'] = async function (svc, task) {
  const key = getSecret(svc.keyEnv);
  if (!key) throw new Error('« ' + svc.name + ' » : clé absente — export ' + svc.keyEnv + '=…');
  const res = await fetchTimeout(svc.url.replace(/\/+$/, ''), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: task.model || svc.model, max_tokens: 1024, messages: [{ role: 'user', content: String(task.prompt || '') }] })
  }, 120000);
  const body = (await readBody(res)).toString('utf8');
  if (!res.ok) throw new Error('« ' + svc.name + ' » : ' + friendlyHttp(res.status, body));
  const j = JSON.parse(body);
  const txt = (j.content || []).map(function (c) { return c.text || ''; }).join('');
  return { text: txt.trim(), service: svc.id, model: task.model || svc.model };
};

// 15) Cloudflare Workers AI (texte + image)
function cfUrl(svc) {
  const acc = process.env[svc.accountEnv || 'AETHER_CF_ACCOUNT'] || getSecret(svc.accountEnv || 'AETHER_CF_ACCOUNT');
  if (!acc) throw new Error('Cloudflare : AETHER_CF_ACCOUNT manquant (identifiant de compte dash.cloudflare.com)');
  return svc.url.replace(/\/+$/, '') + '/accounts/' + acc + '/ai/run/' + (svc.model || '');
}
ADAPTERS['cloudflare-text'] = async function (svc, task) {
  const key = getSecret(svc.keyEnv);
  if (!key) throw new Error('« ' + svc.name + ' » : clé absente — export ' + svc.keyEnv + '=…');
  const res = await fetchTimeout(cfUrl(svc), {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
    body: JSON.stringify({ messages: [{ role: 'user', content: String(task.prompt || '') }], max_tokens: 1024 })
  }, 120000);
  const body = (await readBody(res)).toString('utf8');
  if (!res.ok) throw new Error('« ' + svc.name + ' » : ' + friendlyHttp(res.status, body));
  const j = JSON.parse(body);
  if (j.success === false) throw new Error('Cloudflare : ' + JSON.stringify(j.errors).slice(0, 200));
  return { text: String((j.result && j.result.response) || '').trim(), service: svc.id };
};
ADAPTERS['cloudflare-image'] = async function (svc, task) {
  const key = getSecret(svc.keyEnv);
  if (!key) throw new Error('« ' + svc.name + ' » : clé absente — export ' + svc.keyEnv + '=…');
  const res = await fetchTimeout(cfUrl(svc), {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
    body: JSON.stringify({ prompt: String(task.prompt || '') })
  }, 120000);
  const buf = await readBody(res);
  if (!res.ok) throw new Error('« ' + svc.name + ' » : ' + friendlyHttp(res.status, buf.toString('utf8')));
  const file = saveOut('images', 'png', buf);
  return { file: file, service: svc.id, bytes: buf.length, kind: 'image' };
};

// 16) HuggingFace image (FLUX.1-schnell)
ADAPTERS['hf-image'] = async function (svc, task) {
  const key = getSecret(svc.keyEnv);
  if (!key) throw new Error('« ' + svc.name + ' » : clé absente — export ' + svc.keyEnv + '=… (huggingface.co/settings/tokens)');
  const res = await fetchTimeout(svc.url.replace(/\/+$/, ''), {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
    body: JSON.stringify({ inputs: String(task.prompt || '') })
  }, 120000);
  if (!res.ok) throw new Error('« ' + svc.name + ' » : ' + friendlyHttp(res.status, await readBody(res)));
  const buf = await readBody(res);
  const file = saveOut('images', extFromMime(res.headers.get('content-type'), 'webp'), buf);
  return { file: file, service: svc.id, bytes: buf.length, kind: 'image' };
};

// 17) HuggingFace ASR (Whisper) — audio → texte
ADAPTERS['hf-asr'] = async function (svc, task) {
  const key = getSecret(svc.keyEnv);
  if (!key) throw new Error('« ' + svc.name + ' » : clé absente — export ' + svc.keyEnv + '=…');
  if (!task.audio) throw new Error('Whisper : donne opts.audio = chemin d\u2019un fichier audio du workspace');
  const aPath = path.resolve(String(task.audio));
  if (aPath.indexOf(WORKSPACE) !== 0 && aPath.indexOf(HOME) !== 0) throw new Error('audio hors espace utilisateur refusé');
  const buf = fs.readFileSync(aPath);
  const ext = path.extname(aPath).slice(1).toLowerCase();
  const mime = ext === 'wav' ? 'audio/wav' : (ext === 'flac' ? 'audio/flac' : 'audio/mpeg');
  const res = await fetchTimeout(svc.url.replace(/\/+$/, ''), {
    method: 'POST', headers: { 'Content-Type': mime, 'Authorization': 'Bearer ' + key }, body: buf
  }, 180000);
  const body = (await readBody(res)).toString('utf8');
  if (!res.ok) throw new Error('Whisper : ' + friendlyHttp(res.status, body));
  const j = JSON.parse(body);
  return { text: String(j.text || '').trim(), service: svc.id };
};

// 18) ComfyUI local
ADAPTERS['comfy'] = async function (svc, task) {
  const base = svc.url.replace(/\/+$/, '');
  const wf = {
    '1': { class_type: 'CheckpointLoaderSimple', inputs: { ckpt_name: task.ckpt || 'v1-5-pruned-emaonly.safetensors' } },
    '2': { class_type: 'CLIPTextEncode', inputs: { text: String(task.prompt || ''), clip: ['1', 1] } },
    '3': { class_type: 'CLIPTextEncode', inputs: { text: '', clip: ['1', 1] } },
    '4': { class_type: 'KSampler', inputs: { seed: Math.floor(Math.random() * 1e9), steps: 20, cfg: 7, sampler_name: 'euler', scheduler: 'normal', denoise: 1, model: ['1', 0], positive: ['2', 0], negative: ['3', 0], latent_image: ['5', 0] } },
    '5': { class_type: 'EmptyLatentImage', inputs: { width: task.width || 512, height: task.height || 512, batch_size: 1 } },
    '6': { class_type: 'VAEDecode', inputs: { samples: ['4', 0], vae: ['1', 2] } },
    '7': { class_type: 'SaveImage', inputs: { filename_prefix: 'aether', images: ['6', 0] } }
  };
  let r;
  try { r = await fetchTimeout(base + '/prompt', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt: wf }) }, 30000); }
  catch (e) { throw new Error('ComfyUI injoignable sur ' + base + ' — lance-le d\u2019abord'); }
  const body = (await readBody(r)).toString('utf8');
  if (!r.ok) throw new Error('ComfyUI : ' + friendlyHttp(r.status, body) + ' (workflow par défaut inadapté ? ajuste opts.ckpt)');
  const j = JSON.parse(body);
  const pid = j.prompt_id;
  if (!pid) throw new Error('ComfyUI : pas de prompt_id — ' + body.slice(0, 200));
  const deadline = Date.now() + Math.min(Math.max(task.maxWaitS || 150, 15), 300) * 1000;
  while (Date.now() < deadline) {
    await new Promise(function (r2) { setTimeout(r2, 4000); });
    let h;
    try { h = await (await fetchTimeout(base + '/history/' + pid, { method: 'GET' }, 15000)).json(); } catch (e) { continue; }
    const entry = h[pid];
    if (entry && entry.outputs) {
      for (const nodeId in entry.outputs) {
        const imgs = entry.outputs[nodeId].images;
        if (imgs && imgs.length) {
          const im = imgs[0];
          const vUrl = base + '/view?filename=' + encodeURIComponent(im.filename) + '&subfolder=' + encodeURIComponent(im.subfolder || '') + '&type=' + encodeURIComponent(im.type || 'output');
          const vr = await fetchTimeout(vUrl, { method: 'GET' }, 60000);
          const buf = await readBody(vr);
          return { file: saveOut('images', extFromMime(vr.headers.get('content-type'), 'png'), buf), service: svc.id, bytes: buf.length, kind: 'image' };
        }
      }
    }
    if (entry && entry.status && entry.status.completed) break;
  }
  return { pending: true, service: svc.id, adapter: 'comfy', jobId: pid };
};

// 19) AUTOMATIC1111 / SD.Next local
ADAPTERS['a1111'] = async function (svc, task) {
  const base = svc.url.replace(/\/+$/, '');
  let r;
  try {
    r = await fetchTimeout(base + '/sdapi/v1/txt2img', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: String(task.prompt || ''), steps: 20, cfg_scale: 7, width: task.width || 512, height: task.height || 512 })
    }, 180000);
  } catch (e) { throw new Error('A1111/SD.Next injoignable sur ' + base + ' — lance avec --api'); }
  const body = (await readBody(r)).toString('utf8');
  if (!r.ok) throw new Error('A1111 : ' + friendlyHttp(r.status, body));
  const j = JSON.parse(body);
  if (!j.images || !j.images[0]) throw new Error('A1111 : pas d\u2019image dans la réponse');
  const buf = Buffer.from(j.images[0], 'base64');
  return { file: saveOut('images', 'png', buf), service: svc.id, bytes: buf.length, kind: 'image' };
};

// 20) SCIENCE — 14 sources réelles, sans clé (grondées dans la génération)
function fmtSci(title, items) {
  return '🔎 ' + title + '\n\n' + items.join('\n');
}
ADAPTERS['science'] = async function (svc, task) {
  const q = keywords(task.prompt, 8);
  const enc = encodeURIComponent(q);
  if (!q) throw new Error('requête vide');
  switch (svc.id) {
    case 'arxiv': {
      const r = await fetchTimeout('https://export.arxiv.org/api/query?search_query=all:' + enc + '&max_results=3', {}, 20000);
      const xml = (await readBody(r)).toString('utf8');
      const entries = xml.match(/<entry>[\s\S]*?<\/entry>/g) || [];
      if (!entries.length) return { text: 'arXiv : aucun article pour « ' + q + ' »', service: svc.id };
      const items = entries.map(function (e, i) {
        const t = stripTags((e.match(/<title>([\s\S]*?)<\/title>/) || ['', '?'])[1]);
        const s = stripTags((e.match(/<summary>([\s\S]*?)<\/summary>/) || ['', ''])[1]).slice(0, 300);
        return (i + 1) + '. ' + t + '\n   ' + s + '…';
      });
      return { text: fmtSci('arXiv — articles pour « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    case 'wikipedia-fr': case 'wikipedia-en': {
      const lang = svc.id.slice(-2);
      const u = 'https://' + lang + '.wikipedia.org/w/api.php?action=query&list=search&srsearch=' + enc + '&format=json&utf8=1&srlimit=3';
      const r = await fetchTimeout(u, {}, 20000);
      const j = JSON.parse((await readBody(r)).toString('utf8'));
      const hits = (j.query && j.query.search) || [];
      if (!hits.length) return { text: 'Wikipédia : rien pour « ' + q + ' »', service: svc.id };
      const items = hits.map(function (h, i) {
        return (i + 1) + '. ' + h.title + '\n   ' + stripTags(h.snippet);
      });
      return { text: fmtSci('Wikipédia ' + lang.toUpperCase() + ' — « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    case 'openalex': {
      const r = await fetchTimeout('https://api.openalex.org/works?search=' + enc + '&per-page=3', {}, 20000);
      const j = JSON.parse((await readBody(r)).toString('utf8'));
      const rows = j.results || [];
      if (!rows.length) return { text: 'OpenAlex : rien pour « ' + q + ' »', service: svc.id };
      const items = rows.map(function (w, i) {
        const au = (w.authorships && w.authorships[0] && w.authorships[0].author && w.authorships[0].author.display_name) || '?';
        return (i + 1) + '. ' + (w.display_name || '?') + ' (' + (w.publication_year || '?') + ', ' + au + ')' + (w.doi ? '\n   ' + w.doi : '');
      });
      return { text: fmtSci('OpenAlex — « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    case 'crossref': {
      const r = await fetchTimeout('https://api.crossref.org/works?query=' + enc + '&rows=3&select=title,author,DOI,container-title,issued', {}, 20000);
      const j = JSON.parse((await readBody(r)).toString('utf8'));
      const rows = (j.message && j.message.items) || [];
      const items = rows.map(function (w, i) {
        const au = (w.author && w.author[0] && (w.author[0].given + ' ' + w.author[0].family)) || '?';
        const yr = (w.issued && w.issued['date-parts'] && w.issued['date-parts'][0] && w.issued['date-parts'][0][0]) || '?';
        return (i + 1) + '. ' + ((w.title && w.title[0]) || '?') + ' — ' + au + ' (' + yr + ')' + (w.DOI ? '\n   DOI : ' + w.DOI : '');
      });
      return { text: fmtSci('Crossref — « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    case 'pubmed': {
      const base = svc.url.replace(/\/+$/, '');
      const s = await (await fetchTimeout(base + '/esearch.fcgi?db=pubmed&term=' + enc + '&retmode=json&retmax=3', {}, 20000)).json();
      const ids = (s.esearchresult && s.esearchresult.idlist) || [];
      if (!ids.length) return { text: 'PubMed : rien pour « ' + q + ' »', service: svc.id };
      const su = await (await fetchTimeout(base + '/esummary.fcgi?db=pubmed&id=' + ids.join(',') + '&retmode=json', {}, 20000)).json();
      const items = ids.map(function (id, i) {
        const d = (su.result && su.result[id]) || {};
        return (i + 1) + '. ' + (d.title || '?') + ((d.source ? ' — ' + d.source : '') + (d.pubdate ? ' (' + d.pubdate.slice(0, 4) + ')' : ''));
      });
      return { text: fmtSci('PubMed — « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    case 'europepmc': {
      const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '?query=' + enc + '&format=json&pageSize=3', {}, 20000);
      const j = JSON.parse((await readBody(r)).toString('utf8'));
      const rows = (j.resultList && j.resultList.result) || [];
      const items = rows.map(function (w, i) {
        return (i + 1) + '. ' + (w.title || '?') + ((w.journalTitle ? ' — ' + w.journalTitle : '') + (w.pubYear ? ' (' + w.pubYear + ')' : ''));
      });
      return { text: fmtSci('Europe PMC — « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    case 'pubchem': {
      const name = encodeURIComponent(String(task.prompt || '').trim().split(/\s+/).slice(-1)[0] || 'water');
      const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '/compound/name/' + name + '/property/MolecularFormula,MolecularWeight/JSON', {}, 20000);
      const body = (await readBody(r)).toString('utf8');
      if (!r.ok) return { text: 'PubChem : composé « ' + name + ' » introuvable (essaie un nom chimique : caffeine, water, glucose…)', service: svc.id };
      const j = JSON.parse(body);
      const p = (j.PropertyTable && j.PropertyTable.Properties && j.PropertyTable.Properties[0]) || {};
      return { text: fmtSci('PubChem — ' + (p.Title || name), ['Formule : ' + (p.MolecularFormula || '?'), 'Masse molaire : ' + (p.MolecularWeight || '?') + ' g/mol', 'CID : ' + (p.CID || '?')]), service: svc.id, grounding: name };
    }
    case 'openlibrary': {
      const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '?q=' + enc + '&limit=3', {}, 20000);
      const j = JSON.parse((await readBody(r)).toString('utf8'));
      const rows = j.docs || [];
      const items = rows.map(function (d, i) {
        return (i + 1) + '. ' + (d.title || '?') + ((d.author_name && d.author_name[0] ? ' — ' + d.author_name[0] : '') + (d.first_publish_year ? ' (' + d.first_publish_year + ')' : ''));
      });
      return { text: fmtSci('Open Library — « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    case 'gutendex': {
      const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '?search=' + enc, {}, 20000);
      const j = JSON.parse((await readBody(r)).toString('utf8'));
      const rows = j.results || [];
      const items = rows.slice(0, 3).map(function (d, i) {
        return (i + 1) + '. ' + (d.title || '?') + ((d.authors && d.authors[0] ? ' — ' + d.authors[0].name : '') + ' [téléchargé ' + d.download_count + ' fois]');
      });
      return { text: fmtSci('Gutenberg — « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    case 'worldbank': {
      const c = task.country || 'WLD';
      const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '/' + c + '/indicator/NY.GDP.MKTP.CD?format=json&per_page=1&mrnev=1', {}, 20000);
      const j = JSON.parse((await readBody(r)).toString('utf8'));
      const row = (j[1] && j[1][0]) || {};
      if (!row.value) return { text: 'Banque mondiale : pas de valeur récente (code pays ' + c + ')', service: svc.id };
      return { text: fmtSci('Banque mondiale — PIB ' + (row.country && row.country.value ? row.country.value : c), ['Année : ' + row.date, 'PIB : ' + (row.value / 1e12).toFixed(2) + ' 000 milliards USD']), service: svc.id, grounding: 'PIB ' + c };
    }
    case 'wikidata': {
      const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '?action=wbsearchentities&search=' + enc + '&language=fr&format=json&limit=3', {}, 20000);
      const j = JSON.parse((await readBody(r)).toString('utf8'));
      const rows = j.search || [];
      const items = rows.map(function (d, i) {
        return (i + 1) + '. ' + (d.label || d.id) + (d.description ? ' — ' + d.description : '') + ' [' + d.id + ']';
      });
      return { text: fmtSci('Wikidata — « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    case 'semantic-scholar': {
      const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '?query=' + enc + '&limit=3&fields=title,year,abstract', {}, 20000);
      if (r.status === 429) throw new Error('Semantic Scholar : limite publique par IP atteinte — réessaie dans une minute');
      const j = JSON.parse((await readBody(r)).toString('utf8'));
      const rows = j.data || [];
      if (!rows.length) return { text: 'Semantic Scholar : rien pour « ' + q + ' »', service: svc.id };
      const items = rows.map(function (w, i) {
        return (i + 1) + '. ' + (w.title || '?') + ' (' + (w.year || '?') + ')\n   ' + String(w.abstract || 'résumé non disponible').slice(0, 260) + '…';
      });
      return { text: fmtSci('Semantic Scholar — « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    case 'nasa-apod': case 'nasa-full': {
      const key = svc.keyEnv ? (getSecret(svc.keyEnv) || 'DEMO_KEY') : 'DEMO_KEY';
      const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '?api_key=' + encodeURIComponent(key), {}, 20000);
      const body = (await readBody(r)).toString('utf8');
      if (!r.ok) return { text: 'NASA : ' + friendlyHttp(r.status, body) + ' (la clé DEMO publique est parfois saturée)', service: svc.id };
      const j = JSON.parse(body);
      return { text: fmtSci('NASA — ' + (j.title || 'APOD') + ' (' + (j.date || '') + ')', [String(j.explanation || '').slice(0, 700), j.url ? 'Image : ' + j.url : '']), service: svc.id, grounding: j.title };
    }
    case 'unpaywall': {
      const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '?query=' + enc + '&email=aether@nexus.local', {}, 20000);
      const j = JSON.parse((await readBody(r)).toString('utf8'));
      const rows = (j.results || []).slice(0, 3);
      const items = rows.map(function (w, i) {
        const resp = w.response || {};
        const pdf = (resp.best_oa_location && resp.best_oa_location.url_for_pdf) || '';
        return (i + 1) + '. ' + (resp.title || '?') + ((resp.year ? ' (' + resp.year + ')' : '') + (pdf ? '\n   PDF libre : ' + pdf : ''));
      });
      return { text: fmtSci('Unpaywall — accès libre « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    case 'doaj': {
      const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '/' + enc + '?pageSize=3', {}, 20000);
      const j = JSON.parse((await readBody(r)).toString('utf8'));
      const rows = j.results || [];
      const items = rows.map(function (w, i) {
        const b = w.bibjson || {};
        return (i + 1) + '. ' + (b.title || '?') + ((b.journal && b.journal.title ? ' — ' + b.journal.title : '') + (b.year ? ' (' + b.year + ')' : ''));
      });
      return { text: fmtSci('DOAJ — « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    case 'hal': {
      const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '?q=' + enc + '&wt=json&rows=3', {}, 20000);
      const j = JSON.parse((await readBody(r)).toString('utf8'));
      const rows = (j.response && j.response.docs) || [];
      const items = rows.map(function (d, i) {
        const t = Array.isArray(d.title_s) ? d.title_s[0] : d.title_s;
        return (i + 1) + '. ' + (t || '?') + (d.producedDateY_i ? ' (' + d.producedDateY_i + ')' : '');
      });
      return { text: fmtSci('HAL — archive ouverte française « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    case 'zenodo': {
      const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '?q=' + enc + '&size=3', {}, 20000);
      const j = JSON.parse((await readBody(r)).toString('utf8'));
      const rows = (j.hits && j.hits.hits) || [];
      const items = rows.map(function (d, i) {
        const m = d.metadata || {};
        return (i + 1) + '. ' + (m.title || '?') + (m.publication_date ? ' (' + m.publication_date.slice(0, 4) + ')' : '') + (m.doi ? '\n   DOI : ' + m.doi : '');
      });
      return { text: fmtSci('Zenodo — « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    case 'openmeteo': {
      const lat = task.lat || 48.85; const lon = task.lon || 2.35;
      const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '?latitude=' + lat + '&longitude=' + lon + '&current=temperature_2m,relative_humidity_2m,wind_speed_10m', {}, 20000);
      const j = JSON.parse((await readBody(r)).toString('utf8'));
      const c = j.current || {};
      return { text: fmtSci('Open-Meteo — données réelles (' + lat + ', ' + lon + ')', ['Température : ' + c.temperature_2m + ' °C', 'Humidité : ' + c.relative_humidity_2m + ' %', 'Vent : ' + c.wind_speed_10m + ' km/h', 'Mesure : ' + (c.time || '?')]), service: svc.id, grounding: 'météo' };
    }
    case 'core-ac': {
      const key = getSecret(svc.keyEnv);
      if (!key) throw new Error('« ' + svc.name + ' » : clé absente — export ' + svc.keyEnv + '=… (core.ac.uk/api, gratuite)');
      const r = await fetchTimeout(svc.url.replace(/\/+$/, '') + '?q=' + enc + '&limit=3', { headers: { 'Authorization': 'Bearer ' + key } }, 20000);
      const body = (await readBody(r)).toString('utf8');
      if (!r.ok) throw new Error('CORE : ' + friendlyHttp(r.status, body));
      const j = JSON.parse(body);
      const rows = j.results || [];
      const items = rows.map(function (w, i) { return (i + 1) + '. ' + (w.title || '?') + (w.publishedDate ? ' (' + String(w.publishedDate).slice(0, 4) + ')' : ''); });
      return { text: fmtSci('CORE — « ' + q + ' »', items), service: svc.id, grounding: q };
    }
    default:
      throw new Error('source scientifique inconnue : ' + svc.id);
  }
};

// ═════════════════════════════════════════════════════════════════════
// GÉNÉRATION (dispatcher) + validation YAML réelle + historique
// ═════════════════════════════════════════════════════════════════════
const { remember } = require('./memory');

function history(kind, entry) {
  try {
    fs.mkdirSync(CONF_DIR, { recursive: true });
    fs.appendFileSync(HISTORY_FILE, JSON.stringify(Object.assign({ ts: new Date().toISOString(), kind: kind }, entry)) + '\n');
  } catch (e) {}
}
function getHistory(n) {
  try {
    const lines = fs.readFileSync(HISTORY_FILE, 'utf8').trim().split('\n').filter(Boolean);
    return lines.slice(-(n || 30)).map(function (l) { try { return JSON.parse(l); } catch (e) { return null; } }).filter(Boolean);
  } catch (e) { return []; }
}

function validateYaml(src) {
  const text = String(src || '');
  if (text.trim().length < 10) return { ok: false, error: 'YAML trop court' };
  if (/^\t/m.test(text)) return { ok: false, error: 'tabulations interdites dans le YAML (indentation espaces)' };
  if (!/^[A-Za-z_][\w .\/-]*:(\s|$)/m.test(text)) return { ok: false, error: 'aucune clé de premier niveau détectée' };
  const brackets = (text.match(/\[/g) || []).length - (text.match(/\]/g) || []).length +
    (text.match(/\{/g) || []).length - (text.match(/\}/g) || []).length;
  if (brackets !== 0) return { ok: false, error: 'crochets/accolades non équilibrés' };
  if (YAML_LIB) {
    try { YAML_LIB.load(text); } catch (e) { return { ok: false, error: 'js-yaml : ' + String((e && e.message) || e).slice(0, 160) }; }
  }
  return { ok: true, parser: YAML_LIB ? 'js-yaml' : 'structurel' };
}

function extractYaml(text) {
  const m = String(text || '').match(/```(?:ya?ml)?\s*\n([\s\S]*?)```/i);
  if (m && m[1].trim()) return m[1].trim();
  const lines = String(text || '').split('\n');
  const start = lines.findIndex(function (l) { return /^(name|on|runs-on|jobs|version|steps|apiVersion|kind|title|description):/.test(l.trim()); });
  if (start >= 0) {
    let end = lines.length;
    for (let i = start + 1; i < lines.length; i++) {
      if (/```/.test(lines[i])) { end = i; break; }
    }
    return lines.slice(start, end).join('\n').trim();
  }
  return String(text || '').trim();
}

async function generate(serviceId, task) {
  const t0 = Date.now();
  const svc = findService(serviceId);
  if (!svc) throw new Error('service inconnu : ' + serviceId + ' — vois /api/engine/services');
  if (!task || !String(task.prompt || '').trim()) throw new Error('prompt vide');
  const fn = ADAPTERS[svc.adapter];
  if (!fn) throw new Error('adaptateur introuvable : ' + svc.adapter);
  const out = await fn(svc, task);
  const ms = Date.now() - t0;
  const entry = Object.assign({}, out, { service: svc.id, name: svc.name, ms: ms, prompt: String(task.prompt).slice(0, 300) });
  if (out.pending) {
    history('pending', entry);
  } else {
    history('generate', entry);
    if (out.text) {
      const file = saveOut('textes', 'md', Buffer.from('# ' + svc.name + '\n\nService : ' + svc.id + '\nDurée : ' + ms + ' ms\n\n---\n\n' + out.text + '\n'));
      entry.savedText = file;
    }
    remember('engine', svc.name + ' → ' + (out.file ? path.basename(out.file) : String(out.text || '').slice(0, 120)) + ' (' + ms + ' ms)');
  }
  return entry;
}

async function generateWorkflow(description, opts) {
  const o = opts || {};
  const serviceId = o.service || 'pollinations-text';
  const prompt = 'Génère UNIQUEMENT un fichier YAML GitHub Actions valide et complet pour ce besoin : « ' +
    String(description) + ' ». Réponds avec le YAML seul (bloc ```yaml), sans explication. Le workflow doit être fonctionnel : name, on, jobs, steps réels.';
  const out = await generate(serviceId, { prompt: prompt, system: 'Tu es un générateur de CI GitHub Actions. Tu réponds UNIQUEMENT du YAML valide.' });
  const yaml = extractYaml(out.text || '');
  const v = validateYaml(yaml);
  let file = null;
  if (v.ok) {
    ensureWorkspace();
    file = path.join(WORKSPACE, 'workflows', slugify(description) + '.yml');
    fs.writeFileSync(file, yaml + '\n');
    history('workflow', { service: serviceId, file: file, valid: true });
    remember('engine', 'workflow YAML validé → ' + file);
  }
  return { ok: v.ok, service: out.service, ms: out.ms, yaml: yaml, validation: v, file: file, rawText: String(out.text || '').slice(0, 2000) };
}

// ═════════════════════════════════════════════════════════════════════
// SANTÉ DES SERVICES — vérification réelle, cache 90 s
// ═════════════════════════════════════════════════════════════════════
let healthCache = { at: 0, data: {} };

async function checkOne(svc) {
  const base = svc.url.replace(/\/+$/, '');
  const key = getSecret(svc.keyEnv);
  const needsKey = svc.keyEnv && !key;
  try {
    switch (svc.adapter) {
      case 'pollinations-text': case 'pollinations-image': {
        const r = await fetchTimeout(base + '/models', { method: 'GET' }, 9000);
        if (r.ok) return { status: 'online', detail: 'API vivante (gratuit, sans clé)' };
        if (r.status === 429 || r.status === 503) return { status: 'online', detail: 'en ligne — limite gratuite active' };
        return { status: 'offline', detail: 'HTTP ' + r.status };
      }
      case 'horde-text': case 'horde-image': case 'horde-caption': {
        const r = await fetchTimeout(base + '/status/heartbeat', { headers: hordeHeaders() }, 9000);
        if (r.ok) return { status: 'online', detail: 'ruche active (gratuit, sans clé)' };
        return { status: 'offline', detail: 'HTTP ' + r.status };
      }
      case 'ollama': case 'ollama-embed': {
        const r = await fetchTimeout(base + '/api/tags', { method: 'GET' }, 5000);
        if (!r.ok) return { status: 'offline', detail: 'HTTP ' + r.status };
        const j = await r.json();
        const n = (j.models || []).length;
        return { status: 'online', detail: n ? 'local — ' + n + ' modèle(s) installé(s)' : 'local — aucun modèle (ollama pull …)' };
      }
      case 'openai-port': case 'openai-embed': {
        const r = await fetchTimeout(base + '/v1/models', { method: 'GET' }, 5000);
        if (r.ok) return { status: 'online', detail: 'local — endpoint OpenAI vivant' };
        return { status: 'offline', detail: 'port ' + base + ' silencieux (HTTP ' + r.status + ')' };
      }
      case 'comfy': {
        const r = await fetchTimeout(base + '/system_stats', { method: 'GET' }, 5000);
        return r.ok ? { status: 'online', detail: 'ComfyUI local actif' } : { status: 'offline', detail: 'port silencieux' };
      }
      case 'a1111': {
        const r = await fetchTimeout(base + '/sdapi/v1/options', { method: 'GET' }, 5000);
        return r.ok ? { status: 'online', detail: 'WebUI actif (API)' } : { status: 'offline', detail: 'port silencieux' };
      }
      case 'science': {
        if (svc.keyEnv && !key) return { status: 'needs-key', detail: 'prêt à brancher — export ' + svc.keyEnv + '=… ou scripts/aether-keys.sh' };
        const r = await (async function () {
          try { return await generate(svc.id, { prompt: 'test', maxWaitS: 1 }).then(function (g) { return { ok: true, text: g.text }; }); }
          catch (e) { return { ok: false, err: String((e && e.message) || e) }; }
        })();
        if (r.ok) return { status: 'online', detail: 'vraie source scientifique — répond' };
        const msg = String(r.err || '');
        if (msg.indexOf('clé absente') !== -1) return { status: 'needs-key', detail: msg.slice(0, 120) };
        if (msg.indexOf('429') !== -1 || msg.indexOf('limite') !== -1) return { status: 'online', detail: 'en ligne — limite publique partagée active' };
        return { status: 'erreur', detail: msg.slice(0, 120) };
      }
      default: {
        if (needsKey) return { status: 'needs-key', detail: 'prêt à brancher — export ' + svc.keyEnv + '=… ou scripts/aether-keys.sh' };
        if (svc.accountEnv && !process.env[svc.accountEnv] && !getSecret(svc.accountEnv)) return { status: 'needs-key', detail: 'il manque aussi ' + svc.accountEnv };
        return { status: 'pret', detail: 'clé configurée — la preuve réelle se fait à la génération' };
      }
    }
  } catch (e) {
    return { status: 'offline', detail: String((e && e.message) || e).slice(0, 120) };
  }
}

async function health(opts) {
  const force = opts && opts.force;
  const fresh = Date.now() - healthCache.at < 90000;
  if (!force && fresh && Object.keys(healthCache.data).length) return healthCache.data;
  const list = loadServices();
  const out = {};
  await Promise.all(list.map(async function (s) {
    out[s.id] = Object.assign({ id: s.id }, await checkOne(s));
  }));
  healthCache = { at: Date.now(), data: out };
  return out;
}

async function healthSummary() {
  const h = await health({});
  const sum = { total: 0, online: 0, pret: 0, 'needs-key': 0, offline: 0, erreur: 0, freeOnline: 0 };
  const list = loadServices();
  sum.total = list.length;
  const rows = list.map(function (s) {
    const st = h[s.id] || { status: 'erreur', detail: 'pas de mesure' };
    sum[st.status] = (sum[st.status] || 0) + 1;
    if (st.status === 'online' && s.free) sum.freeOnline += 1;
    return { id: s.id, name: s.name, cat: s.cat, tier: s.tier, free: s.free, keyEnv: s.keyEnv, status: st.status, detail: st.detail };
  });
  return { summary: sum, services: rows };
}

// ═════════════════════════════════════════════════════════════════════
// HTTP — routes /api/engine/*
// ═════════════════════════════════════════════════════════════════════
function jsend(res, obj, code) {
  res.writeHead(code || 200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}

function listResults() {
  const dirs = ['textes', 'images', 'workflows', 'audio', 'projets'];
  const rows = [];
  dirs.forEach(function (d) {
    const p = path.join(WORKSPACE, d);
    let names = [];
    try { names = fs.readdirSync(p); } catch (e) { return; }
    names.forEach(function (n) {
      const f = path.join(p, n);
      try {
        const st = fs.statSync(f);
        if (st.isFile()) rows.push({ path: f, dir: d, name: n, size: st.size, mtime: st.mtimeMs });
      } catch (e) {}
    });
  });
  rows.sort(function (a, b) { return b.mtime - a.mtime; });
  return rows.slice(0, 300);
}

const MIME_RAW = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.yml': 'text/plain; charset=utf-8', '.yaml': 'text/plain; charset=utf-8', '.md': 'text/plain; charset=utf-8' };

function httpGet(u, p, res) {
  if (p === '/api/engine/services') {
    const list = loadServices();
    return jsend(res, {
      count: list.length,
      workspace: WORKSPACE,
      yamlValidator: YAML_LIB ? 'js-yaml' : 'structurel',
      services: list.map(function (s) {
        return Object.assign({}, s, { keySet: !!(s.keyEnv && getSecret(s.keyEnv)) });
      })
    });
  }
  if (p === '/api/engine/health') {
    if (u.searchParams.get('full') === '1') return healthSummary().then(function (r) { jsend(res, r); }).catch(function (e) { jsend(res, { error: String((e && e.message) || e) }, 500); });
    return health({}).then(function (h) { jsend(res, h); }).catch(function (e) { jsend(res, { error: String((e && e.message) || e) }, 500); });
  }
  if (p === '/api/engine/history') return jsend(res, { items: getHistory(parseInt(u.searchParams.get('n') || '30', 10)) });
  if (p === '/api/engine/results') return jsend(res, { workspace: WORKSPACE, items: listResults() });
  if (p === '/api/engine/raw') {
    const f = path.resolve(u.searchParams.get('path') || '');
    if (f.indexOf(WORKSPACE) !== 0) { res.writeHead(403); res.end('hors workspace'); return; }
    fs.readFile(f, function (err, data) {
      if (err) { res.writeHead(404); res.end('404'); return; }
      res.writeHead(200, { 'Content-Type': MIME_RAW[path.extname(f).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-store' });
      res.end(data);
    });
    return;
  }
  if (p === '/api/engine/models') {
    const doIt = async function () {
      const out = {};
      try { out.text = await (await fetchTimeout('https://text.pollinations.ai/models', {}, 10000)).json(); } catch (e) { out.text = null; }
      try { out.image = await (await fetchTimeout('https://image.pollinations.ai/models', {}, 10000)).json(); } catch (e) { out.image = null; }
      try { fs.writeFileSync(POLL_MODELS_FILE, JSON.stringify(out, null, 2)); } catch (e) {}
      return out;
    };
    let cached = null;
    try { cached = JSON.parse(fs.readFileSync(POLL_MODELS_FILE, 'utf8')); } catch (e) {}
    if (cached) return jsend(res, cached);
    return doIt().then(function (o) { jsend(res, o); }).catch(function (e) { jsend(res, { error: String((e && e.message) || e) }, 500); });
  }
  jsend(res, { error: 'route moteur inconnue : ' + p }, 404);
}

async function httpPost(p, data, res) {
  try {
    if (p === '/api/engine/generate') {
      const out = await generate(String(data.service || ''), {
        prompt: String(data.prompt || ''), system: data.system || '',
        model: data.model || '', width: parseInt(data.width || '0', 10) || undefined,
        height: parseInt(data.height || '0', 10) || undefined,
        image: data.image || '', audio: data.audio || '',
        lat: data.lat, lon: data.lon, country: data.country || '',
        maxWaitS: parseInt(data.maxWaitS || '0', 10) || undefined
      });
      return jsend(res, Object.assign({ ok: true }, out));
    }
    if (p === '/api/engine/workflow') {
      const out = await generateWorkflow(String(data.description || ''), { service: data.service || '' });
      return jsend(res, Object.assign({ ok: !!out.ok }, out));
    }
    if (p === '/api/engine/poll') {
      const svc = findService(String(data.service || ''));
      if (!svc) throw new Error('service inconnu');
      if (svc.adapter === 'horde-image') return jsend(res, Object.assign({ ok: true }, await hordePoll(svc, 'image', String(data.jobId || ''), 120)));
      if (svc.adapter === 'horde-text') return jsend(res, Object.assign({ ok: true }, await hordePoll(svc, 'text', String(data.jobId || ''), 60)));
      throw new Error('sondage non supporté pour ' + svc.id);
    }
    if (p === '/api/engine/health') {
      const list = loadServices();
      const id = String(data.id || '');
      const svc = list.find(function (s) { return s.id === id; });
      if (!svc) throw new Error('service inconnu : ' + id);
      const r = Object.assign({ id: id }, await checkOne(svc));
      healthCache.data[id] = r;
      return jsend(res, Object.assign({ ok: true }, r));
    }
    jsend(res, { error: 'route moteur inconnue : ' + p }, 404);
  } catch (e) {
    jsend(res, { ok: false, error: String((e && e.message) || e) });
  }
}

module.exports = { generate: generate, generateWorkflow: generateWorkflow, health: health, healthSummary: healthSummary, httpGet: httpGet, httpPost: httpPost, loadServices: loadServices, validateYaml: validateYaml, WORKSPACE: WORKSPACE };
AE_ENGINE
ok "core/engine.js — 20 adaptateurs réels (Pollinations, AI Horde, Ollama, OpenAI-compat, Gemini, Anthropic, Cloudflare, HF, ComfyUI, A1111, science×14)"
