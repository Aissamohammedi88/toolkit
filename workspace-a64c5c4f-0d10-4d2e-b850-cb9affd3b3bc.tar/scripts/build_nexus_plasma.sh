#!/usr/bin/env bash
# ═════════════════════════════════════════════════════════════════════════════
# build_nexus_plasma.sh — assemble le bash monolithique final
# ═════════════════════════════════════════════════════════════════════════════
set -euo pipefail

SRC_DIR="/home/z/my-project/scripts"
OUT="/home/z/my-project/download/nexus-plasma.sh"
PY_SRC="$SRC_DIR/plasma.py"
RS_SRC="$SRC_DIR/plasma_bench.rs"

# Vérifs
[[ -f "$PY_SRC" ]] || { echo "Missing $PY_SRC"; exit 1; }
[[ -f "$RS_SRC" ]] || { echo "Missing $RS_SRC"; exit 1; }

# Detect python for the build-time injection (the launcher's own detection
# is duplicated here because the heredoc below is data, not executed code)
PYBIN_BUILD=""
for cmd in python3 python; do
  if command -v "$cmd" &>/dev/null; then
    PYBIN_BUILD="$cmd"; break
  fi
done
[[ -n "$PYBIN_BUILD" ]] || { echo "python3 required to build"; exit 1; }

# ─── preamble ─────────────────────────────────────────────────────────────
cat > "$OUT" <<'__BASH_PREAMBLE_EOF__'
#!/usr/bin/env bash
# ═════════════════════════════════════════════════════════════════════════════
# ██╗  ██╗██████╗  ███████╗ ██████╗ ███████╗██╗███████╗██╗   ██╗███████╗██████╗
# ██║ ██╔╝██╔══██╗██╔════╝██╔═══██╗██╔════╝██║██╔════╝██║   ██║██╔════╝██╔══██╗
# █████╔╝ ██████╔╝███████╗██║   ██║█████╗  ██║█████╗  ██║   ██║█████╗  ██████╔╝
# ██╔═██╗ ██╔══██╗╚════██║██║   ██║██╔══╝  ██║██╔══╝  ╚██╗ ██╔╝██╔══╝  ██╔══██╗
# ██║  ██╗██████╔╝███████║╚██████╔╝██║     ██║███████╗ ╚████╔╝ ███████╗██║  ██║
# ╚═╝  ╚═╝╚═════╝ ╚══════╝ ╚═════╝ ╚═╝     ╚═╝╚══════╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝
# ═════════════════════════════════════════════════════════════════════════════
# NEXUS PLASMA STUDIO — Linus Edition v3.0.0
# ═════════════════════════════════════════════════════════════════════════════
# Monolithic Markdown Studio · Stdlib Only · Zero Deps · 100% Local
#
# "If you can't ship it in one file, you don't understand it."
#
#   · 100% stdlib       · zero pip install     · zero node_modules
#   · 100% local        · zero telemetry        · zero cloud
#   · 100% yours        · zero SaaS             · zero subscriptions
#   · 100% monolith     · zero microservices   · zero npm
#
# Le browser est l'UI.  Python est le backend.  Bash est le launcher.
# Rust est le muscle.    SQLite est la mémoire. Ça, c'est toute la stack.
#
# Author : Aissa Mohammedi (DGK)
# License: NEXUS-OPEN-3.0
# Port   : 2009 (override with PLASMA_PORT=...)
# ═════════════════════════════════════════════════════════════════════════════

set -euo pipefail

VERSION="3.0.0-linus"
CODENAME="Plasma Monolith"

# ─── detect python ─────────────────────────────────────────────────────────
PYBIN=""
for cmd in python3 python; do
  if command -v "$cmd" &>/dev/null; then
    PYBIN="$cmd"; break
  fi
done
if [[ -z "$PYBIN" ]]; then
  echo "✗ Python 3 requis (introuvable dans PATH). Installe-le : https://www.python.org/" >&2
  exit 1
fi
PYVER="$("$PYBIN" -c 'import sys; print("%d.%d.%d" % sys.version_info[:3])')"
echo "✓ Python détecté : $PYBIN ($PYVER)"

# ─── cache ─────────────────────────────────────────────────────────────────
CACHE_DIR="${PLASMA_CACHE:-${HOME}/.cache/nexus-plasma}"
mkdir -p "$CACHE_DIR"
PY_FILE="$CACHE_DIR/plasma.py"
RS_FILE="$CACHE_DIR/plasma_bench.rs"
RS_BIN="$CACHE_DIR/plasma_bench"

# ─── extract embedded python ──────────────────────────────────────────────
extract_python() {
  echo "→ Extraction du module Python embarqué..."
  cat > "$PY_FILE" <<'__PYTHON_EOF__'
__PYTHON_EOF__
  echo "  écrit : $PY_FILE ($(wc -l < "$PY_FILE") lignes)"
}

# ─── extract embedded rust ────────────────────────────────────────────────
extract_rust() {
  cat > "$RS_FILE" <<'__RUST_EOF__'
__RUST_EOF__
}

# ─── optional rust build ──────────────────────────────────────────────────
build_rust() {
  if ! command -v rustc &>/dev/null; then
    echo "✗ rustc absent — bench Rust désactivé (le bench Python reste dispo)"
    echo "  (installe Rust : https://rustup.rs/ — optionnel, pas bloquant)"
    return 1
  fi
  echo "✓ rustc détecté : $(rustc --version)"
  echo "→ Compilation du helper Rust (bench fibonacci)..."
  if rustc -O "$RS_FILE" -o "$RS_BIN" 2>/dev/null; then
    echo "  ✓ binaire : $RS_BIN"
    return 0
  fi
  echo "  ✗ compilation Rust échouée — bench Python seulement"
  return 1
}

# ─── cleanup on exit ──────────────────────────────────────────────────────
cleanup() {
  if [[ -n "${PLASMA_KEEP_CACHE:-1}" ]]; then
    :
  else
    rm -f "$PY_FILE" "$RS_FILE" 2>/dev/null || true
  fi
}
trap cleanup EXIT

# ─── main ──────────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════════════════════════╗"
echo "║        NEXUS PLASMA STUDIO  —  LINUS EDITION v$VERSION                         ║"
echo "║        $CODENAME                                                       ║"
echo "╚══════════════════════════════════════════════════════════════════════════╝"
echo ""

extract_python
extract_rust
build_rust || true

# Env vars handed to Python
export PLASMA_RUST_BIN="$RS_BIN"
export PLASMA_HOST="${PLASMA_HOST:-127.0.0.1}"
export PLASMA_PORT="${PLASMA_PORT:-2009}"
export PLASMA_NO_OPEN="${PLASMA_NO_OPEN:-0}"
export PLASMA_GIT="${PLASMA_GIT:-1}"

echo ""
echo "→ Lancement : $PYBIN $PY_FILE"
echo "  Host    : $PLASMA_HOST"
echo "  Port    : $PLASMA_PORT"
echo "  Rust    : $([[ -x "$RS_BIN" ]] && echo 'oui' || echo 'non')"
echo "  Git     : $([[ "$PLASMA_GIT" == "1" ]] && echo 'oui' || echo 'non')"
echo "  Browser : $([[ "$PLASMA_NO_OPEN" == "1" ]] && echo 'non (PLASMA_NO_OPEN=1)' || echo 'oui')"
echo ""

exec "$PYBIN" "$PY_FILE" "$@"
__BASH_PREAMBLE_EOF__

# ─── inject python source (replacing the empty heredoc) ────────────────────
# We do this by inserting the python lines right before the closing __PYTHON_EOF__ marker.
# Simpler approach: rewrite the extract_python function to inline the python lines.
# Strategy: locate the line '__PYTHON_EOF__' that's *inside* extract_python and prepend
# the python source above it.

# Use python to do the surgery cleanly
"$PYBIN_BUILD" - "$OUT" "$PY_SRC" "$RS_SRC" <<'PYINJ'
import sys, re
out_path, py_src, rs_src = sys.argv[1:4]
with open(out_path, "r", encoding="utf-8") as f:
    out = f.read()
with open(py_src, "r", encoding="utf-8") as f:
    py = f.read()
with open(rs_src, "r", encoding="utf-8") as f:
    rs = f.read()

# Find the unique line "  cat > \"$PY_FILE\" <<'__PYTHON_EOF__'\n__PYTHON_EOF__\n"
# and inject the python source between the two markers.
needle_py = "  cat > \"$PY_FILE\" <<'__PYTHON_EOF__'\n__PYTHON_EOF__\n"
if needle_py not in out:
    sys.exit("preamble marker (python) not found — cannot inject")
out = out.replace(needle_py, "  cat > \"$PY_FILE\" <<'__PYTHON_EOF__'\n" + py + "__PYTHON_EOF__\n", 1)

needle_rs = "  cat > \"$RS_FILE\" <<'__RUST_EOF__'\n__RUST_EOF__\n"
if needle_rs not in out:
    sys.exit("preamble marker (rust) not found — cannot inject")
out = out.replace(needle_rs, "  cat > \"$RS_FILE\" <<'__RUST_EOF__'\n" + rs + "__RUST_EOF__\n", 1)

with open(out_path, "w", encoding="utf-8") as f:
    f.write(out)

print(f"✓ injected {len(py.splitlines())} python lines + {len(rs.splitlines())} rust lines")
print(f"  final file: {out_path} ({len(out.splitlines())} lines, {len(out.encode('utf-8'))} bytes)")
PYINJ

chmod +x "$OUT"
echo ""
echo "✓ Livrable : $OUT"
