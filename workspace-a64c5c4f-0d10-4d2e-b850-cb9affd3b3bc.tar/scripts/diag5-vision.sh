#!/usr/bin/env bash
set -u
export GENT_HOME=/tmp/gent-e2e
cd /tmp
PORT=43112 "$GENT_HOME/runtime/current/bin/node" --max-semi-space-size=64 "$GENT_HOME/app/gent-server.js" > /tmp/e2e.log 2>&1 &
for i in $(seq 1 40); do curl -fsS http://127.0.0.1:43112/api/health >/dev/null 2>&1 && break; sleep 0.3; done
agent-browser open http://127.0.0.1:43112/vision >/dev/null 2>&1
sleep 2
echo "=== requêtes réseau vues par le navigateur ==="
agent-browser network requests --filter api
echo "=== load() pas-à-pas ==="
agent-browser eval 'api("GET","/api/read?p="+encodeURIComponent("demo-vision/index.html")).then(function(x){window.__dbg=JSON.stringify({ok:x.ok,keys:Object.keys(x.j),len:(x.j.content||"").length,err:x.j.error||null})})'
sleep 1
agent-browser eval 'window.__dbg'
agent-browser close >/dev/null 2>&1
pkill -f gent-server.js 2>/dev/null
true
