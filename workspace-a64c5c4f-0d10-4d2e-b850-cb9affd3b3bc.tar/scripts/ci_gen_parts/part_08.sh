
# ============================================================================
# SECTION 21 — TEMPLATE release (release GitHub sur tag v*)
# ============================================================================
# Release déclenchée par git tag v* : changelog construit depuis les PR
# merged, artefacts joints, release GitHub publiée, SLSA sur les binaires.
inject_release() {
    cat <<'NEXUS_YAML'
# =============================================================================
# NEXUS RELEASE — release GitHub sur tag v*
# Généré par NEXUS CI GENERATOR v__GENVER__ le __DATE__ (type: release)
# Fichier: __WORKFLOW_FILE__
# -----------------------------------------------------------------------------
# Déclencheur : git tag v1.2.3 && git push --tags
# Chaîne de contrôle :
#   1. build     : build via script du projet (build.sh/Makefile/package.json)
#   2. changelog : release-changelog-builder (depuis les PR merged)
#   3. publish   : gh-release avec artefacts + changelog
# Permissions minimales : contents:write (creation de la release).
# =============================================================================
name: 'NEXUS RELEASE (tag v*)'
on:
  push:
    tags: ['v*']
  workflow_dispatch:

permissions:
  contents: write

jobs:
  # -------------------------------------------------------------------
  # JOB 1/3 : build — tente build.sh, puis make, puis npm run build.
  #   --if-present en bash : aucun de ces mécanismes n'est imposé.
  # -------------------------------------------------------------------
  build:
    name: 'Build des artefacts de release'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Build du projet (script détecté automatiquement)'
        run: |
          if [ -x ./build.sh ]; then
            ./build.sh
          elif [ -f Makefile ]; then
            make build
          elif [ -f package.json ]; then
            npm ci && npm run build --if-present
          elif [ -f Cargo.toml ]; then
            cargo build --release
          elif [ -f go.mod ]; then
            go build ./...
          else
            echo "AVERTISSEMENT: aucun mécanisme de build détecté"
            echo "artefacts vides — adaptez ce job a votre projet"
          fi
      - name: 'Collecter les artefacts'
        run: |
          mkdir -p dist
          for d in dist build target/release .next out; do
            if [ -d "$d" ]; then
              cp -r "$d"/* dist/ 2>/dev/null || true
            fi
          done
      - name: 'Uploader en attente de publication'
        uses: actions/upload-artifact@v4
        with:
          name: nexus-release-dist
          path: dist/
          retention-days: 7
          if-no-files-found: ignore

  # -------------------------------------------------------------------
  # JOB 2/3 : changelog — construit depuis les PR merged entre le tag
  #   précédent et le tag courant. Configuration inline : categories par
  #   label, mention des contributeurs.
  # -------------------------------------------------------------------
  changelog:
    name: 'Changelog (PR merged)'
    needs: build
    outputs:
      changelog: ${{ steps.changelog.outputs.changelog }}
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Construire le changelog'
        id: changelog
        uses: mikepenz/release-changelog-builder-action@v4
        with:
          configuration: |
            {
              "categories": [
                { "title": "Ajouts", "labels": ["feature", "enhancement"] },
                { "title": "Corrections", "labels": ["fix", "bug"] },
                { "title": "Securite", "labels": ["security"] },
                { "title": "Autres changements", "labels": [] }
              ]
            }
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}

  # -------------------------------------------------------------------
  # JOB 3/3 : publish — création de la release GitHub avec les artefacts
  #   du job build et le changelog du job précédent.
  # -------------------------------------------------------------------
  publish:
    name: 'Publication de la release'
    needs: [build, changelog]
    runs-on: ubuntu-latest
    steps:
      - name: 'Récupérer les artefacts'
        uses: actions/download-artifact@v4
        with:
          name: nexus-release-dist
          path: dist
      - name: 'Publier la release GitHub'
        uses: softprops/action-gh-release@v2
        with:
          files: dist/**
          body: ${{ needs.changelog.outputs.changelog }}
          draft: false
          generate_release_notes: true

NEXUS_YAML
}

# ============================================================================
# SECTION 22 — TEMPLATE nightly (scan nocturne complet)
# ============================================================================
# Le nightly fait ce qu'un pipeline sur push ne peut PAS faire : scanner
# sur schedule, avec l'historique complet et sans pression de temps.
# Les jobs gitleaks/codeql/trivy réexaminent TOUT le dépôt à 03:00 UTC.
inject_nightly() {
    cat <<'NEXUS_YAML'
# =============================================================================
# NEXUS NIGHTLY — scan nocturne complet
# Généré par NEXUS CI GENERATOR v__GENVER__ le __DATE__ (type: nightly)
# Fichier: __WORKFLOW_FILE__ | Cron: __CRON__ (UTC)
# -----------------------------------------------------------------------------
# Pourquoi un nightly alors que le pipeline push scanne déjà ?
#   1. Les CVE sont publiées TOUS LES JOURS : le code n'a pas bougé,
#      mais le monde a changé autour de lui.
#   2. Le scan nightly tourne sur l'historique complet sans urgencer
#      le cycle de push (gitleaks full-history, NVD à jour).
#   3. dependency full: voit les dépendances transitives ignorées en
#      quick-check.
# Sécurité anti-dérive : pas de continue-on-error sur les CVE.
# =============================================================================
name: 'NEXUS NIGHTLY (scan nocturne)'
on:
  schedule:
    - cron: '__CRON__'
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: nexus-nightly
  cancel-in-progress: false

jobs:
  # -------------------------------------------------------------------
  # JOB 1/4 : secrets — gitleaks sur l'historique COMPLET (fetch-depth 0).
  #   Le push ne scannait que la diff ; ici on audite tout le dépôt.
  # -------------------------------------------------------------------
  secrets:
    name: 'Gitleaks (historique complet)'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout (historique complet)'
        uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - name: 'Gitleaks'
        uses: gitleaks/gitleaks-action@v2
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}

  # -------------------------------------------------------------------
  # JOB 2/4 : codeql — analyse de sécurité en mode schedule. GitHub
  #   documente ce mode pour les analyses périodiques.
  # -------------------------------------------------------------------
  codeql:
    name: 'CodeQL (analyse périodique)'
    runs-on: ubuntu-latest
    permissions:
      contents: read
      security-events: write
    strategy:
      matrix:
        language: [javascript-typescript, python]
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Initialisation CodeQL'
        uses: github/codeql-action/init@v3
        with:
          languages: ${{ matrix.language }}
          queries: security-extended
      - name: 'Autobuild'
        uses: github/codeql-action/autobuild@v3
      - name: 'Analyse CodeQL'
        uses: github/codeql-action/analyze@v3
        with:
          category: '/language:${{ matrix.language }}'

  # -------------------------------------------------------------------
  # JOB 3/4 : vulns — Trivy filesystem complet. exit-code 1 : un nightly
  #   qui ne fait rien échouer n'est qu'un rapport ignoré.
  # -------------------------------------------------------------------
  vulns:
    name: 'Trivy (filesystem complet)'
    runs-on: ubuntu-latest
    permissions:
      contents: read
      security-events: write
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Trivy scan complet'
        uses: aquasecurity/trivy-action@0.28.0
        with:
          scan-type: fs
          scan-ref: .
          severity: HIGH,CRITICAL
          exit-code: '1'
          ignore-unfixed: true
          format: sarif
          output: trivy-nightly.sarif
      - name: 'Uploader le SARIF'
        if: always()
        uses: github/codeql-action/upload-sarif@v3
        with:
          sarif_file: trivy-nightly.sarif

  # -------------------------------------------------------------------
  # JOB 4/4 : deps — audit des gestionnaires détectés. best-effort par
  #   écosystème (un dépôt peut n'avoir ni package-lock ni Cargo.lock),
  #   MAIS chaque audit détecté est bloquant.
  # -------------------------------------------------------------------
  deps:
    name: 'Audit dépendances (écosystèmes détectés)'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'npm audit (si lockfile npm)'
        if: hashFiles('package-lock.json') != ''
        run: |
          npm ci --ignore-scripts || true
          npm audit --audit-level=high
      - name: 'pip-audit (si requirements.txt)'
        if: hashFiles('requirements.txt') != ''
        run: |
          python -m pip install --upgrade pip pip-audit
          pip install -r requirements.txt
          pip-audit --strict
      - name: 'cargo audit (si Cargo.lock)'
        if: hashFiles('Cargo.lock') != ''
        run: |
          cargo install cargo-audit --locked || true
          cargo audit

NEXUS_YAML
}
