
# ============================================================================
# SECTION 29 — COMMANDE selftest (BANC D'ESSAI PROTON)
# ============================================================================
# Le selftest n'affirme rien : il EXÉCUTE. Il relance le générateur comme
# un vrai utilisateur (sous-processus bash "$NEXUS_SCRIPT_PATH"), dans un
# dépôt git temporaire, et vérifie les contrats un par un :
#
#   T1   outils requis présents (bash/git/python3/PyYAML/sed/mktemp)
#   T2   dépôt git temporaire opérationnel
#   T3   génération réelle des 9 types : fichier + non vide + marqueur
#   T4   validation structurelle des 9 YAML (python3 yaml.safe_load)
#   T5   anti-bug skeleton : AUCUN 'run: actions/' dans aegis (PROTON ④)
#   T6   --dry-run n'écrit JAMAIS rien
#   T7   type inconnu -> exit 2
#   T8   hors dépôt git -> exit 3
#   T9   collision sans --force -> exit 4
#   T10  cron invalide -> exit 2
#   T11  validate sur YAML cassé -> exit 5
#   T12  uninstall du marqueur + refuse un fichier non-NEXUS
#   T13  version --node invalide -> exit 2 (injection sed impossible)
#   T14  validate sur fichier non-YAML -> exit 5
#   T15  list : exit 0 et les 13 types présents
#   T16  --skip-validation : génération quand même + avertissement
#   T17  explain : les 13 documentations opérationnelles répondent
#   T18  doctor : exit 0 (environnement complet)
#
# Tout test échoué est rapporté avec sa preuve (sortie du sous-processus).
ST_PASS=0
ST_FAIL=0

st_pass() {
    ST_PASS=$((ST_PASS + 1))
    printf '  %sPASS%s  %s\n' "${C_GREEN}" "${C_RESET}" "$1"
}

st_fail() {
    ST_FAIL=$((ST_FAIL + 1))
    printf '  %sFAIL%s  %s\n' "${C_RED}" "${C_RESET}" "$1"
    if [ -n "${2:-}" ]; then
        printf '        preuve: %s\n' "$2"
    fi
}

# run_case : exécute le générateur en sous-processus, capture le code de
# retour dans RUN_RC et la sortie dans RUN_OUT. set -e est suspendu le
# temps de l'appel : un échec ATTENDU n'est pas un échec du selftest.
run_case() {
    RUN_RC=0
    RUN_OUT=""
    set +e
    RUN_OUT="$(bash "$NEXUS_SCRIPT_PATH" "$@" 2>&1)"
    RUN_RC=$?
    set -e
}

cmd_selftest() {
    local repo nonrepo t f count_before count_after fixture

    log_step "NEXUS CI GENERATOR v$NEXUS_VERSION — SELFTEST PROTON"
    printf '\n'

    # ------------------------------------------------------------- T1
    printf '  [T1] outils requis\n'
    if command -v git >/dev/null 2>&1 \
        && command -v python3 >/dev/null 2>&1 \
        && python3 -c "import yaml" >/dev/null 2>&1 \
        && command -v sed >/dev/null 2>&1 \
        && command -v mktemp >/dev/null 2>&1; then
        st_pass "outils requis présents (bash/git/python3/PyYAML/sed/mktemp)"
    else
        st_fail "outils manquants"
    fi

    # ------------------------------------------------------------- T2
    printf '  [T2] dépôt git temporaire\n'
    repo="$(nexus_tmpdir_new)"
    if git init -q "$repo" 2>/dev/null && [ -d "$repo/.git" ]; then
        st_pass "dépôt créé: $repo"
    else
        st_fail "impossible de créer le dépôt temporaire"
        die "selftest interrompu: environnement git cassé" "$EXIT_ENV"
    fi

    # ------------------------------------------------------------- T3
    printf "  [T3] génération réelle des ${#TYPES_ORDER[@]} types\n"
    local gen_ok=0
    local gen_fail=""
    local expected=${#TYPES_ORDER[@]}
    for t in "${TYPES_ORDER[@]}"; do
        f="$repo/.github/workflows/${WORKFLOW_FILE[$t]}"
        run_case "$t" --dir "$repo" --force
        if [ "$RUN_RC" -eq 0 ] && [ -s "$f" ]; then
            if head -n 3 "$f" | grep -q "$NEXUS_MARKER"; then
                gen_ok=$((gen_ok + 1))
            else
                gen_fail="$gen_fail $t(marqueur)"
            fi
        else
            gen_fail="$gen_fail $t(rc=$RUN_RC)"
        fi
    done
    if [ -z "$gen_fail" ] && [ "$gen_ok" -eq "$expected" ]; then
        st_pass "$expected/$expected workflows générés, non vides, marqueur présent"
    else
        st_fail "génération incomplète (ok=$gen_ok)$gen_fail" "$RUN_OUT"
    fi

    # ------------------------------------------------------------- T4
    printf "  [T4] validation structurelle des ${#TYPES_ORDER[@]} YAML\n"
    local val_ok=0
    local val_fail=""
    for t in "${TYPES_ORDER[@]}"; do
        f="$repo/.github/workflows/${WORKFLOW_FILE[$t]}"
        if python3 - "$f" <<'NEXUS_PY' >>/dev/null 2>&1
import sys, yaml
with open(sys.argv[1], "r", encoding="utf-8") as fh:
    data = yaml.safe_load(fh)
assert isinstance(data, dict)
assert ("on" in data) or (True in data)
assert isinstance(data.get("jobs"), dict) and data["jobs"]
for name, job in data["jobs"].items():
    assert isinstance(job, dict) and "runs-on" in job
NEXUS_PY
        then
            val_ok=$((val_ok + 1))
        else
            val_fail="$val_fail $t"
        fi
    done
    if [ -z "$val_fail" ] && [ "$val_ok" -eq "$expected" ]; then
        st_pass "$expected/$expected YAML syntaxiquement ET structurellement valides"
    else
        st_fail "validation en échec pour:$val_fail"
    fi

    # ------------------------------------------------------------- T5
    printf '  [T5] anti-bug skeleton (PROTON 4)\n'
    f="$repo/.github/workflows/nexus-aegis.yml"
    if grep -qE '^[[:space:]]*run:.*actions/' "$f"; then
        st_fail "pattern ILLÉGAL 'run: actions/' encore présent dans aegis" \
            "$(grep -nE '^[[:space:]]*run:.*actions/' "$f" | head -n 1)"
    else
        st_pass "aucun 'run: actions/' dans aegis — setup-node est bien un uses:"
        if grep -q 'uses: actions/setup-node@v4' "$f"; then
            st_pass "preuve du correctif: 'uses: actions/setup-node@v4' présent"
        else
            st_fail "setup-node@v4 introuvable dans aegis"
        fi
    fi

    # ------------------------------------------------------------- T6
    printf '  [T6] --dry-run n écrit rien\n'
    count_before="$(ls -A "$repo/.github/workflows" | wc -l)"
    run_case node --dir "$repo" --dry-run
    count_after="$(ls -A "$repo/.github/workflows" | wc -l)"
    if [ "$RUN_RC" -eq 0 ] && [ "$count_before" = "$count_after" ]; then
        st_pass "dry-run: 0 fichier écrit (avant=$count_before après=$count_after)"
    else
        st_fail "dry-run a écrit quelque chose (avant=$count_before après=$count_after)"
    fi

    # ------------------------------------------------------------- T7
    printf '  [T7] type inconnu -> exit 2\n'
    run_case kubernetes --dir "$repo"
    if [ "$RUN_RC" -eq 2 ]; then
        st_pass "type inconnu refusé, exit=$RUN_RC"
    else
        st_fail "type inconnu: exit=$RUN_RC attendu=2" "$RUN_OUT"
    fi

    # ------------------------------------------------------------- T8
    printf '  [T8] hors dépôt git -> exit 3\n'
    nonrepo="$(nexus_tmpdir_new)"
    run_case aegis --dir "$nonrepo"
    if [ "$RUN_RC" -eq 3 ]; then
        st_pass "répertoire non-git refusé, exit=$RUN_RC"
    else
        st_fail "non-git: exit=$RUN_RC attendu=3" "$RUN_OUT"
    fi

    # ------------------------------------------------------------- T9
    printf '  [T9] collision sans --force -> exit 4\n'
    run_case aegis --dir "$repo"
    if [ "$RUN_RC" -eq 4 ]; then
        st_pass "collision détectée, exit=$RUN_RC (et --force la contourne)"
    else
        st_fail "collision: exit=$RUN_RC attendu=4" "$RUN_OUT"
    fi

    # ------------------------------------------------------------ T10
    printf '  [T10] cron invalide -> exit 2\n'
    run_case nightly --dir "$repo" --cron 'pas un cron'
    if [ "$RUN_RC" -eq 2 ]; then
        st_pass "cron invalide refusé, exit=$RUN_RC"
    else
        st_fail "cron invalide: exit=$RUN_RC attendu=2" "$RUN_OUT"
    fi

    # ------------------------------------------------------------ T11
    printf '  [T11] validate sur YAML cassé -> exit 5\n'
    fixture="$repo/.github/workflows/casse.yml"
    printf 'name: YAML casse\non: [push\njobs:\n  bad job sans runs-on\n' >"$fixture"
    run_case validate "$fixture"
    if [ "$RUN_RC" -eq 5 ]; then
        st_pass "YAML cassé refusé par validate, exit=$RUN_RC"
    else
        st_fail "validate: exit=$RUN_RC attendu=5" "$RUN_OUT"
    fi
    rm -f "$fixture"

    # ------------------------------------------------------------ T12
    printf '  [T12] uninstall: marqueur requis + suppression réelle\n'
    run_case uninstall aegis --dir "$repo" --force
    f="$repo/.github/workflows/nexus-aegis.yml"
    if [ "$RUN_RC" -eq 0 ] && [ ! -f "$f" ]; then
        st_pass "uninstall aegis OK (fichier supprimé)"
    else
        st_fail "uninstall aegis: exit=$RUN_RC fichier=$([ -f "$f" ] && echo present || echo absent)"
    fi
    printf '# workflow écrit a la main\nname: main\n' >"$f"
    run_case uninstall aegis --dir "$repo" --force
    if [ "$RUN_RC" -ne 0 ] && [ -f "$f" ]; then
        st_pass "uninstall REFUSE un fichier sans marqueur NEXUS (protégé)"
    else
        st_fail "uninstall a supprimé un fichier non-NEXUS !"
    fi
    rm -f "$f"

    # ------------------------------------------------------------ T13
    printf '  [T13] version --node invalide -> exit 2\n'
    run_case aegis --dir "$repo" --force --node '22; rm -rf /'
    if [ "$RUN_RC" -eq 2 ]; then
        st_pass "tentative d'injection refusée, exit=$RUN_RC (regex valid_version)"
    else
        st_fail "valeur hostile acceptée: exit=$RUN_RC attendu=2" "$RUN_OUT"
    fi

    # ------------------------------------------------------------ T14
    printf '  [T14] validate sur fichier non-YAML -> exit 5\n'
    printf 'ceci nest pas du yaml: [unclosed\n' >"$repo/.github/workflows/pas-yaml.yml"
    run_case validate "$repo/.github/workflows/pas-yaml.yml"
    if [ "$RUN_RC" -eq 5 ]; then
        st_pass "non-YAML refusé, exit=$RUN_RC"
    else
        st_fail "non-YAML: exit=$RUN_RC attendu=5" "$RUN_OUT"
    fi
    rm -f "$repo/.github/workflows/pas-yaml.yml"

    # ------------------------------------------------------------ T15
    printf '  [T15] list : exit 0 et types complets\n'
    local miss_types=""
    run_case list
    if [ "$RUN_RC" -eq 0 ]; then
        for t in "${TYPES_ORDER[@]}"; do
            if ! printf '%s' "$RUN_OUT" | grep -q "^[[:space:]]*$t[[:space:]]"; then
                miss_types="$miss_types $t"
            fi
        done
        if [ -z "$miss_types" ]; then
            st_pass "list: exit 0, ${#TYPES_ORDER[@]}/${#TYPES_ORDER[@]} types affichés"
        else
            st_fail "types manquants dans list:$miss_types"
        fi
    else
        st_fail "list: exit=$RUN_RC attendu=0" "$RUN_OUT"
    fi

    # ------------------------------------------------------------ T16
    printf '  [T16] --skip-validation : avertissement + génération\n'
    run_case aegis --dir "$repo" --force --skip-validation --quiet
    f="$repo/.github/workflows/nexus-aegis.yml"
    if [ "$RUN_RC" -eq 0 ] && [ -s "$f" ]; then
        st_pass "skip-validation: généré avec exit=$RUN_RC (l'utilisateur a signé le risque)"
    else
        st_fail "skip-validation: exit=$RUN_RC fichier=$([ -s "$f" ] && echo present || echo absent)" "$RUN_OUT"
    fi

    # ------------------------------------------------------------ T17
    printf "  [T17] explain : les ${#TYPES_ORDER[@]} documentations\n"
    local exp_ok=0
    local exp_fail=""
    for t in "${TYPES_ORDER[@]}"; do
        run_case explain "$t"
        if [ "$RUN_RC" -eq 0 ] && [ -n "$RUN_OUT" ]; then
            exp_ok=$((exp_ok + 1))
        else
            exp_fail="$exp_fail $t(rc=$RUN_RC)"
        fi
    done
    if [ -z "$exp_fail" ] && [ "$exp_ok" -eq "$expected" ]; then
        st_pass "$expected/$expected explains répondent avec contenu"
    else
        st_fail "explain en échec pour:$exp_fail"
    fi

    # ------------------------------------------------------------ T18
    printf '  [T18] doctor : exit 0 attendu (environnement complet)\n'
    run_case doctor
    if [ "$RUN_RC" -eq 0 ]; then
        st_pass "doctor: exit 0, bilan complet rendu"
    else
        st_fail "doctor: exit=$RUN_RC attendu=0" "$RUN_OUT"
    fi

    # -------------------------------------------------------- BILAN
    printf '\n'
    hr
    printf '  BILAN SELFTEST: %sPASS=%s  FAIL=%s%s\n' "" "$ST_PASS" "$ST_FAIL" ""
    hr
    if [ "$ST_FAIL" -gt 0 ]; then
        die "selftest en échec: $ST_FAIL test(s) rouges — LIVRAISON REFUSÉE (PROTON 2)" "$EXIT_ERR"
    fi
    log_ok "SELFTEST TOUT VERT — livraison autorisée"
}
