
# ============================================================================
# SECTION 6 — CONSTANTES ET REGISTRE DES TYPES
# ============================================================================
NEXUS_VERSION="2.0.0"

DEFAULT_DIR="."
DEFAULT_BRANCH="main"
DEFAULT_NODE="22"
DEFAULT_JAVA="21"
DEFAULT_PYTHON="3.12"
DEFAULT_GO="1.23"
DEFAULT_PHP="8.3"
DEFAULT_DOTNET="9.0"
DEFAULT_REGISTRY="ghcr.io"
DEFAULT_CRON="0 3 * * *"

# Codes de retour (contrat public documenté dans l'en-tête)
EXIT_OK=0
EXIT_ERR=1
EXIT_USAGE=2
EXIT_ENV=3
EXIT_COLLISION=4
EXIT_YAML=5

# Ordre canonique d'affichage et de génération (selftest inclus)
TYPES_ORDER=(aegis java python node docker go rust release nightly php dotnet cpp android)

# Fichier YAML cible pour chaque type (dans .github/workflows/)
declare -A WORKFLOW_FILE=(
    [aegis]="nexus-aegis.yml"
    [java]="nexus-java.yml"
    [python]="nexus-python.yml"
    [node]="nexus-node.yml"
    [docker]="nexus-docker.yml"
    [go]="nexus-go.yml"
    [rust]="nexus-rust.yml"
    [release]="nexus-release.yml"
    [nightly]="nexus-nightly.yml"
    [php]="nexus-php.yml"
    [dotnet]="nexus-dotnet.yml"
    [cpp]="nexus-cpp.yml"
    [android]="nexus-android.yml"
)

# Description courte affichée par la commande list
declare -A WORKFLOW_DESC=(
    [aegis]="Securite & qualite Next.js: gitleaks, lint, tsc, tests, build, CodeQL, Trivy, SLSA"
    [java]="Maven multi-JDK 17/21: verify, OWASP dependency-check, artefacts JAR, CodeQL"
    [python]="ruff, pytest+coverage, mypy, pip-audit, multi-interpreteur 3.10-3.13, CodeQL"
    [node]="npm multi-runtime 20/22: ci, lint, test, build, audit, artefacts"
    [docker]="Image multi-arch amd64/arm64: hadolint, buildx, Trivy, SBOM, push ghcr"
    [go]="golangci-lint, vet, tests -race + coverage, goreleaser sur tag"
    [rust]="fmt, clippy -D warnings, test --all-features, cargo-audit, release sur tag"
    [release]="Release sur tag v*: changelog automatique, artefacts, SLSA provenance"
    [nightly]="Scan nocturne cron: gitleaks full-history, CodeQL, Trivy complet, deps"
    [php]="composer + php-cs-fixer + phpunit bloquant + composer audit, matrice PHP 8.2-8.4"
    [dotnet]="SDK [8.0.x,<dotnet>]: restore/build/test --no-restore, pack NuGet, CodeQL csharp"
    [cpp]="cmake [gcc,clang] -Werror, ctest, sanitizers ASan+UBSan, cppcheck"
    [android]="gradlew lint + tests + assembleDebug, APK artefact, release unsigned sur tag"
)

# Marqueur posé dans les 3 premières lignes de chaque workflow généré.
# uninstall refuse de supprimer un fichier qui ne porte PAS ce marqueur :
# on ne touche jamais à un workflow écrit à la main par quelqu'un d'autre.
NEXUS_MARKER="Généré par NEXUS CI GENERATOR"

# ============================================================================
# SECTION 7 — AIDE (usage)
# ============================================================================
usage() {
    cat <<'NEXUS_USAGE'
NEXUS CI GENERATOR v2.0.0
Générateur de pipelines GitHub Actions prêts pour la production.

USAGE:
    nexus-ci-generator.sh <commande> [options]
    nexus-ci-generator.sh <type>     [options]    # raccourci de génération

TYPES DE WORKFLOW:
    aegis      Securité & qualite Next.js complet (skeleton corrigé)
    java       Maven multi-JDK 17/21 + OWASP dependency-check
    python     ruff + pytest + coverage + mypy + pip-audit
    node       npm multi-runtime 20/22 + audit
    docker     image multi-arch + hadolint + Trivy + SBOM
    go         golangci-lint + tests -race + goreleaser
    rust       fmt + clippy + test + cargo-audit
    release    release sur tag v* + changelog + SLSA
    nightly    scan nocturne cron complet
    php        composer + php-cs-fixer + phpunit + audit
    dotnet     .NET restore/build/test + pack NuGet
    cpp        cmake multi-compilateur + sanitizers + cppcheck
    android    gradle + lint + tests + APK debug/release

COMMANDES:
    list       Liste les types supportés
    explain    Documentation opérationnelle détaillée d'un type
    validate   Valide la syntaxe/structure d'un fichier workflow
    doctor     Diagnostic de l'environnement
    uninstall  Supprime un workflow généré (confirmation requise)
    selftest   Test e2e: génère + valide les 9 types + tests négatifs
    manual     Manuel complet intégré
    changelog  Historique des versions

OPTIONS (génération):
    --dir <chemin>       Répertoire du dépôt cible (défaut: .)
    --branch <branche>   Branche déclencheuse (défaut: main)
    --node <version>     Version Node.js (défaut: 22)
    --java <version>     Version JDK (défaut: 21)
    --python <version>   Version Python (défaut: 3.12)
    --go <version>       Version Go (défaut: 1.23)
    --php <version>      Version PHP (défaut: 8.3)
    --dotnet <version>   Version .NET SDK (défaut: 9.0)
    --registry <hote>    Registre conteneurs (défaut: ghcr.io)
    --cron <expr>        Cron 5 champs (défaut: 0 3 * * *)
    --force              Écrase un workflow existant
    --dry-run            Génère sans écrire (sortie stdout)
    --skip-validation    Saute la validation YAML (DÉCONSEILLÉ)
    --no-color           Désactive les couleurs ANSI
    --quiet, -q          Seules les erreurs s'affichent
    -h, --help           Affiche cette aide

EXEMPLES:
    ./nexus-ci-generator.sh aegis --node 22
    ./nexus-ci-generator.sh python --dir ~/projets/api --python 3.11
    ./nexus-ci-generator.sh docker --registry ghcr.io --force
    ./nexus-ci-generator.sh nightly --cron '30 2 * * 1'
    ./nexus-ci-generator.sh validate .github/workflows/nexus-aegis.yml
    ./nexus-ci-generator.sh explain aegis
    ./nexus-ci-generator.sh selftest

CODES DE RETOUR:
    0  succès
    1  erreur générique
    2  usage incorrect
    3  environnement invalide (pas un dépôt git, outils absents)
    4  collision de fichier (workflow déjà présent, sans --force)
    5  validation YAML échouée

ENVIRONNEMENT:
    bash >= 4, git, python3 + module PyYAML (validation YAML).
    La variable NO_COLOR=1 est respectée (convention no-color.org).

NEXUS_USAGE
}

# ============================================================================
# SECTION 8 — UTILITAIRES GÉNÉRAUX
# ============================================================================
# Vérifie qu'un type fait partie du registre officiel.
is_known_type() {
    local t
    for t in "${TYPES_ORDER[@]}"; do
        if [ "$t" = "$1" ]; then
            return 0
        fi
    done
    return 1
}

# Vérifie qu'une commande externe existe, sinon message + échec.
require_cmd() {
    if command -v "$1" >/dev/null 2>&1; then
        return 0
    fi
    log_err "commande requise absente: $1"
    return 1
}

# Confirmation interactive. Règles de sécurité:
#   - OPT_FORCE=1 -> oui sans question (mode script/selftest)
#   - stdin non interactif (pipe, CI) -> REFUS: on ne supprime rien en
#     aveugle; l'utilisateur doit passer --force explicitement.
confirm() {
    local reply
    if [ "${OPT_FORCE:-0}" -eq 1 ]; then
        return 0
    fi
    if [ ! -t 0 ]; then
        log_warn "stdin non interactif -> refus automatique (utilise --force)"
        return 1
    fi
    printf '%s [y/N] ' "$1"
    read -r reply
    case "$reply" in
        y|Y|yes|oui|o|O) return 0 ;;
        *) return 1 ;;
    esac
}

# Conseils post-installation affichés après chaque génération réussie.
# Contenu réel et actionnable : commit, secrets éventuels, prochaines
# étapes spécifiques au type généré.
print_next_steps() {
    local type="$1"
    local target="$2"
    if [ "$NEXUS_QUIET" -eq 1 ]; then
        return 0
    fi
    printf '\n'
    log_info "prochaines étapes:"
    printf '  %s\n' "1. inspecter le fichier   : ${C_BOLD}less $target${C_RESET}"
    printf '  %s\n' "2. committer             : git add $target && git commit -m 'ci: add nexus $type workflow'"
    printf '  %s\n' "3. pousser et observer   : la première exécution partira au prochain push"
    case "$type" in
        aegis|node)
            printf '  %s\n' "4. le workflow exige 'npm test' -> sinon adapte la step test (voir --explain $type)"
            ;;
        python)
            printf '  %s\n' "4. pytest doit exister -> sinon: pip install pytest pytest-cov (voir --explain $type)"
            ;;
        java)
            printf '  %s\n' "4. le workflow exige pom.xml a la racine (voir --explain $type)"
            ;;
        docker)
            printf '  %s\n' "4. le workflow exige un Dockerfile a la racine (voir --explain $type)"
            ;;
        go)
            printf '  %s\n' "4. le workflow exige go.mod a la racine (voir --explain $type)"
            ;;
        php)
            printf '  %s\n' "4. le workflow exige composer.json + phpunit.xml (voir --explain $type)"
            ;;
        dotnet)
            printf '  %s\n' "4. le workflow exige un .sln ou .csproj a la racine (voir --explain $type)"
            ;;
        cpp)
            printf '  %s\n' "4. le workflow exige CMakeLists.txt + tests CTest (voir --explain $type)"
            ;;
        android)
            printf '  %s\n' "4. le workflow exige gradlew executable commite (voir --explain $type)"
            ;;
        rust)
            printf '  %s\n' "4. le workflow exige Cargo.toml a la racine (voir --explain $type)"
            ;;
        release)
            printf '  %s\n' "4. trigger: git tag v1.0.0 && git push --tags"
            ;;
        nightly)
            printf '  %s\n' "4. le cron tourne a l'heure UTC configuree (defaut: 03:00)"
            ;;
    esac
}
