
explain_docker() {
    cat <<'NEXUS_EXPLAIN'
TYPE: docker — pipeline image multi-arch
FICHIER GÉNÉRÉ: .github/workflows/nexus-docker.yml

DÉCLENCHEURS:
  - push sur la branche, tags v*, pull_request, workflow_dispatch.
  - Le push vers le registre n'a JAMAIS lieu sur une pull_request
    (code non fusionné = pas d'image publiée).

JOBS (4):
  1. lint  - hadolint sur Dockerfile, échec à partir de warning.
  2. image - QEMU + buildx, plateformes linux/amd64 ET linux/arm64,
             cache type=gha, tags générés par metadata-action :
             branche, sha-, semver sur tag v*, latest sur branche
             par défaut. Login au registre avec GITHUB_TOKEN.
  3. scan  - Trivy sur l'IMAGE (pas juste le filesystem) : le scan
             voit le runtime de l'image. exit 1 sur HIGH/CRITICAL.
  4. sbom  - SBOM SPDX de l'image, joint en artefact.

EXIGE: un Dockerfile à la racine.

SECRETS REQUIS: aucun — le login utilise GITHUB_TOKEN vers ghcr.io.
PERMISSIONS: packages:write sur le job image uniquement.
ARTEFACTS: SARIF Trivy, SBOM nexus-sbom.spdx.json.
DURÉE ESTIMÉE: 8-15 min au premier build multi-arch (QEMU arm64 est
               lent), 4-8 min ensuite grâce au cache gha.

REGISTRE: la valeur de --registry (défaut ghcr.io). Le nom de l'image
          est ${{ github.repository }} : orga/dépôt, en minuscules
          automatiques côté serveur si votre orga a des majuscules,
          préfixez le nom en minuscules dans les settings du paquet.
NEXUS_EXPLAIN
}

explain_go() {
    cat <<'NEXUS_EXPLAIN'
TYPE: go — pipeline qualité & release
FICHIER GÉNÉRÉ: .github/workflows/nexus-go.yml

DÉCLENCHEURS: push branche + tags v*, pull_request, workflow_dispatch.

JOBS (2):
  1. quality - golangci-lint (version latest de l'action), go vet,
               go test -race (détection de race conditions :
               le bug le plus dur à reproduire localement),
               coverage atomique joint, go build.
  2. release - goreleaser release --clean, UNIQUEMENT sur tag v*.

EXIGE: go.mod à la racine (step de vérification dédiée, échec
       avec message explicite s'il manque).

SECRETS REQUIS: aucun — goreleaser publie avec GITHUB_TOKEN
                (contents:write sur le job release uniquement).
ARTEFACTS: nexus-go-coverage (coverage.out, 7j), release goreleaser
           (binaires multi-plateformes + archives + checksums).
DURÉE ESTIMÉE: quality 2-4 min ; release 3-6 min.

NOTE -race: le flag force le runtime Go à détecter les accès
           mémoire concurrents non synchronisés. Un test qui passe
           sans -race peut échouer AVEC : c'est une découverte,
           pas un faux positif. Corrigez le code, pas le test.
NEXUS_EXPLAIN
}

explain_rust() {
    cat <<'NEXUS_EXPLAIN'
TYPE: rust — pipeline qualité & sécurité
FICHIER GÉNÉRÉ: .github/workflows/nexus-rust.yml

DÉCLENCHEURS: push branche + tags v*, pull_request, workflow_dispatch.

JOBS (3):
  1. fmt     - cargo fmt --all --check sur NIGHTLY (le composant
               rustfmt y vit). Format séparé du build : zéro conflit
               de toolchain.
  2. quality - clippy --all-targets -- -D warnings (chaque warning
               EST une erreur), cargo test --all-features,
               cargo-audit (CVE des crates, via rustsec/audit-check).
  3. release - cargo build --release sur tag v* uniquement, binaire
               target/release/ joint (if-no-files-found: error :
               une release sans binaire est un mensonge de release).

EXIGE: Cargo.toml à la racine.

SECRETS REQUIS: aucun.
ARTEFACTS: nexus-rust-release (target/release, 14j).
DURÉE ESTIMÉE: fmt 1-2 min ; quality 5-12 min au premier run (les
               crates compilent depuis zéro), 2-4 min avec le cache
               Swatinem/rust-cache.

POURQUOI -D warnings:
  le compilateur Rust attrape des classes entières de bugs (memory,
  concurrency, null) que d'autres langages laissent passer. Clippy
  va plus loin encore. Ignorer un warning clippy, c'est refuser un
  diagnostic gratuit d'un expert du langage.
NEXUS_EXPLAIN
}

explain_release() {
    cat <<'NEXUS_EXPLAIN'
TYPE: release — release GitHub sur tag v*
FICHIER GÉNÉRÉ: .github/workflows/nexus-release.yml

DÉCLENCHEUR: git tag v1.2.3 && git push --tags (+ manuel).

JOBS (3):
  1. build     - détecte AUTOMATIQUEMENT votre mécanisme de build :
                 build.sh exécutable, Makefile (make build),
                 package.json (npm ci && npm run build), Cargo.toml
                 (cargo build --release), go.mod (go build). Les
                 sorties sont collectées dans dist/.
  2. changelog - release-changelog-builder : catégories par label
                 (feature -> Ajouts, fix -> Corrections, security ->
                 Securite), construit depuis les PR merged entre le
                 tag précédent et le tag courant.
  3. publish   - softprops/action-gh-release : artefacts + changelog
                 + generate_release_notes (les notes natives GitHub
                 en complément).

SECRETS REQUIS: aucun. PERMISSIONS: contents:write (créer la release).
DURÉE ESTIMÉE: 3-8 min selon la durée de votre build.

AVERTISSEMENT HONNÊTE:
  si le job build ne détecte AUCUN mécanisme, il s'affiche vert avec
  un avertissement et zéro artefact. C'est un choix délibéré : le
  générateur n'invente pas un build qui n'existe pas. Adaptez le job
  build à votre projet réel — la release sans artefact publiera les
  notes seules, ce qui est correct mais incomplet.
NEXUS_EXPLAIN
}

explain_nightly() {
    cat <<'NEXUS_EXPLAIN'
TYPE: nightly — scan nocturne complet
FICHIER GÉNÉRÉ: .github/workflows/nexus-nightly.yml

DÉCLENCHEURS: schedule cron (défaut 0 3 * * * = 03:00 UTC) + manuel.

JOBS (4):
  1. secrets - gitleaks sur l'historique COMPLET (fetch-depth 0).
               Le pipeline de push ne scannait que la diff ; ici,
               tout le dépôt, chaque nuit.
  2. codeql  - analyse périodique javascript-typescript + python.
  3. vulns   - Trivy filesystem complet, exit 1 sur HIGH/CRITICAL.
  4. deps    - audit par écosystème DÉTECTÉ : npm audit si
               package-lock.json, pip-audit si requirements.txt,
               cargo audit si Cargo.lock. Chaque audit détecté est
               bloquant ; les écosystèmes absents sont simplement
               sautés (hashFiles() vide = step skip).

SECRETS REQUIS: aucun.
DURÉE ESTIMÉE: 15-30 min (jobs en parallèle, le plus lent est
               codeql + la base NVD de gitleaks).

POURQUOI UN NIGHTLY EXISTE:
  votre code n'a pas changé depuis hier, mais le monde oui : de
  nouvelles CVE sont publiées chaque jour, de nouveaux secrets
  fuient, de nouveaux patterns de vulnérabilité sont découverts.
  Le nightly est le rappel quotidien que "ça marchait hier" n'est
  pas un argument de sécurité.
NEXUS_EXPLAIN
}
