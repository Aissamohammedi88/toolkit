
# ============================================================================
# SECTION 14 — TEMPLATE aegis (Next.js) — BUG DU SKELETON CORRIGÉ (PROTON ④)
# ============================================================================
# PROTON ④ — Réparation chirurgicale, documentée :
#   Dans le skeleton v1, le job de setup contenait :
#       - name: Setup Environment
#         run: actions/setup-node@v4        <- ILLÉGAL
#   Une action GitHub s'invoque avec `uses:`, JAMAIS via `run:` (run =
#   commande shell). Résultat dans le skeleton : la ligne était exécutée
#   comme du shell par GitHub et le workflow plantait à chaque run.
#   Version corrigée ici :
#       - name: Setup Environment
#         uses: actions/setup-node@v4
#         with:
#           node-version: '__NODE__'
#           cache: 'npm'
#   Preuve d'exécution : cmd_selftest génère ce fichier, le valide en YAML,
#   ET vérifie qu'aucune ligne `run: actions/` n'existe (validate_yaml_file).
inject_aegis() {
    cat <<'NEXUS_YAML'
# =============================================================================
# NEXUS AEGIS — pipeline sécurité & qualité Next.js
# Généré par NEXUS CI GENERATOR v__GENVER__ le __DATE__ (type: aegis)
# Fichier: __WORKFLOW_FILE__ | Branche: __BRANCH__ | Node: __NODE__
# -----------------------------------------------------------------------------
# Chaîne de contrôle (fail fast : les étapes peu coûteuses d'abord) :
#   1. changes   : filtre les jobs sur les fichiers réellement touchés
#   2. secrets   : gitleaks — scan des secrets committés (bloquant)
#   3. lint      : ESLint zéro tolérance (--max-warnings=0)
#   4. typecheck : tsc --noEmit (sanction OMEGA R4 — pas de build sans types)
#   5. test      : suite de tests avec cache npm
#   6. build     : next build — preuve que le projet compile
#   7. codeql    : analyse statique de sécurité (SARIF -> onglet Security)
#   8. trivy     : scan CVE filesystem (SARIF -> onglet Security)
#   9. slsa      : attestation de provenance du build (supply chain)
# Secrets requis : aucun (GITHUB_TOKEN auto suffit).
# =============================================================================
name: 'NEXUS AEGIS (securite & qualite)'
on:
  push:
    branches: [__BRANCH__]
  pull_request:
    branches: [__BRANCH__]
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: 'nexus-aegis-${{ github.ref }}'
  cancel-in-progress: true

jobs:
  # -------------------------------------------------------------------
  # JOB 1/9 : changes — détection des fichiers modifiés (paths-filter).
  # But : ne pas faire tourner lint/test/build si seul un README a bougé.
  # -------------------------------------------------------------------
  changes:
    name: 'Detection des fichiers modifies'
    runs-on: ubuntu-latest
    permissions:
      contents: read
      pull-requests: read
    outputs:
      src: ${{ steps.filter.outputs.src }}
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Filtrer par chemin'
        id: filter
        uses: dorny/paths-filter@v3
        with:
          filters: |
            src:
              - 'src/**'
              - 'app/**'
              - 'pages/**'
              - 'components/**'
              - 'lib/**'
              - 'package.json'
              - 'package-lock.json'
              - 'tsconfig.json'
              - 'next.config.*'

  # -------------------------------------------------------------------
  # JOB 2/9 : secrets — gitleaks sur l'historique complet du dépôt.
  # Toujours actif (même sur doc) : un secret commité reste un incident.
  # -------------------------------------------------------------------
  secrets:
    name: 'Gitleaks — scan de secrets'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout (historique complet)'
        uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - name: 'Gitleaks'
        uses: gitleaks/gitleaks-action@v2
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}

  # -------------------------------------------------------------------
  # JOB 3/9 : lint — ESLint strict. Zéro warning toléré : un warning
  # laissé passer aujourd'hui, c'est une erreur ignorée demain.
  # -------------------------------------------------------------------
  lint:
    name: 'ESLint (zero warning)'
    needs: changes
    if: needs.changes.outputs.src == 'true'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup Environment'
        uses: actions/setup-node@v4
        with:
          node-version: '__NODE__'
          cache: 'npm'
      - name: 'Installer les dependances (lockfile requis)'
        run: npm ci
      - name: 'ESLint — max-warnings=0'
        run: npx eslint . --max-warnings=0

  # -------------------------------------------------------------------
  # JOB 4/9 : typecheck — tsc --noEmit. Le type est un test gratuit :
  #   il attrape la classe entière des bugs "undefined is not a function".
  # -------------------------------------------------------------------
  typecheck:
    name: 'TypeScript (tsc --noEmit)'
    needs: changes
    if: needs.changes.outputs.src == 'true'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup Environment'
        uses: actions/setup-node@v4
        with:
          node-version: '__NODE__'
          cache: 'npm'
      - name: 'Installer les dependances (lockfile requis)'
        run: npm ci
      - name: 'tsc --noEmit'
        run: npx tsc --noEmit

  # -------------------------------------------------------------------
  # JOB 5/9 : test — suite de tests (vitest/jest selon package.json).
  # Adapter le script 'test' dans package.json si besoin.
  # -------------------------------------------------------------------
  test:
    name: 'Tests unitaires'
    needs: changes
    if: needs.changes.outputs.src == 'true'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup Environment'
        uses: actions/setup-node@v4
        with:
          node-version: '__NODE__'
          cache: 'npm'
      - name: 'Installer les dependances (lockfile requis)'
        run: npm ci
      - name: 'Jouer la suite de tests'
        run: npm test -- --ci --coverage
      - name: 'Uploader le rapport de coverage'
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: nexus-coverage
          path: coverage/
          retention-days: 7
          if-no-files-found: ignore

  # -------------------------------------------------------------------
  # JOB 6/9 : build — next build. Un projet qui ne build pas en CI ne
  #   build nulle part. Produit un artefact consommé par le job SLSA.
  # -------------------------------------------------------------------
  build:
    name: 'Build production'
    needs: changes
    if: needs.changes.outputs.src == 'true'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup Environment'
        uses: actions/setup-node@v4
        with:
          node-version: '__NODE__'
          cache: 'npm'
      - name: 'Installer les dependances (lockfile requis)'
        run: npm ci
      - name: 'Build production (next build)'
        run: npm run build
        env:
          NEXT_TELEMETRY_DISABLED: '1'
      - name: 'Uploader l artefact de build'
        uses: actions/upload-artifact@v4
        with:
          name: nexus-build
          path: .next/
          retention-days: 7

  # -------------------------------------------------------------------
  # JOB 7/9 : codeql — analyse statique orientée sécurité (queries
  #   security-extended). Remonte en SARIF dans l'onglet Security.
  # -------------------------------------------------------------------
  codeql:
    name: 'CodeQL (securite statique)'
    needs: changes
    if: needs.changes.outputs.src == 'true'
    runs-on: ubuntu-latest
    permissions:
      contents: read
      security-events: write
    strategy:
      matrix:
        language: [javascript-typescript]
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Initialisation CodeQL'
        uses: github/codeql-action/init@v3
        with:
          languages: ${{ matrix.language }}
          queries: security-extended
      - name: 'Autobuild'
        uses: github/codeql-action/autobuild@v3
      - name: 'Analyse CodeQL'
        uses: github/codeql-action/analyze@v3
        with:
          category: '/language:${{ matrix.language }}'

  # -------------------------------------------------------------------
  # JOB 8/9 : trivy — scan CVE du filesystem (dépendances incluses).
  #   exit-code 1 sur HIGH/CRITICAL : fail ferme, pas de CVE ignorée.
  # -------------------------------------------------------------------
  trivy:
    name: 'Trivy (CVE filesystem)'
    runs-on: ubuntu-latest
    permissions:
      contents: read
      security-events: write
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Trivy filesystem scan'
        uses: aquasecurity/trivy-action@0.28.0
        with:
          scan-type: fs
          severity: HIGH,CRITICAL
          exit-code: '1'
          ignore-unfixed: true
          format: sarif
          output: trivy-results.sarif
      - name: 'Uploader le SARIF'
        uses: github/codeql-action/upload-sarif@v3
        with:
          sarif_file: trivy-results.sarif

  # -------------------------------------------------------------------
  # JOB 9/9 : slsa — attestation de provenance du build (supply chain).
  #   La pièce jointe .buildprovenance permet d'auditer QUI a buildé
  #   QUOI, sur quelle infra, avec quel commit — sans confiance aveugle.
  # -------------------------------------------------------------------
  slsa:
    name: 'SLSA (attestation provenance)'
    needs: [changes, build]
    if: needs.changes.outputs.src == 'true'
    runs-on: ubuntu-latest
    permissions:
      id-token: write
      attestations: write
      contents: read
    steps:
      - name: 'Recuperer l artefact de build'
        uses: actions/download-artifact@v4
        with:
          name: nexus-build
          path: .next-attest
      - name: 'Attestation SLSA build provenance'
        uses: actions/attest-build-provenance@v1
        with:
          subject-path: '.next-attest/**'

NEXUS_YAML
}
