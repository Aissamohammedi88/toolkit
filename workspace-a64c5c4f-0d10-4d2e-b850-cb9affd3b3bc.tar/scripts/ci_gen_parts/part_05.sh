
# ============================================================================
# SECTION 15 — TEMPLATE java (Maven multi-JDK)
# ============================================================================
# Pipeline Maven complet : la matrice JDK [17, __JAVA__] prouve la
# compatibilité LTS au lieu de la supposer. OWASP dependency-check tourne
# en job séparé (lourd) et ne bloque pas la matrice rapide.
inject_java() {
    cat <<'NEXUS_YAML'
# =============================================================================
# NEXUS JAVA — pipeline Maven multi-JDK
# Généré par NEXUS CI GENERATOR v__GENVER__ le __DATE__ (type: java)
# Fichier: __WORKFLOW_FILE__ | Branche: __BRANCH__ | JDK: __JAVA__
# -----------------------------------------------------------------------------
# Chaîne de contrôle :
#   1. build      : matrice JDK [17, __JAVA__] — compile + tests + package
#   2. owasp      : dependency-check CVE sur les dépendances Maven
#   3. codeql     : analyse statique de sécurité (language: java-kotlin)
# Exige : pom.xml à la racine du dépôt.
# Secrets requis : aucun (GITHUB_TOKEN auto suffit).
# =============================================================================
name: 'NEXUS JAVA (maven multi-jdk)'
on:
  push:
    branches: [__BRANCH__]
  pull_request:
    branches: [__BRANCH__]
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: 'nexus-java-${{ github.ref }}'
  cancel-in-progress: true

jobs:
  # -------------------------------------------------------------------
  # JOB 1/3 : build — matrice JDK. fail-fast désactivé : on veut voir
  #   les DEUX JDK échouer indépendamment, sinon le 17 cache le 21.
  # -------------------------------------------------------------------
  build:
    name: 'Maven (JDK ${{ matrix.java }})'
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix:
        java: [17, __JAVA__]
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup JDK ${{ matrix.java }} (temurin, cache maven)'
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: ${{ matrix.java }}
          cache: maven
      - name: 'Vérifier la structure du projet'
        run: |
          test -f pom.xml || {
            echo "ERREUR: pom.xml manquant a la racine du dépôt"
            exit 1
          }
      - name: 'Compiler sans tests (fail fast sur la compilation)'
        run: mvn -B -ntp -DskipTests clean compile
      - name: 'Tests + vérification complète (mvn verify)'
        run: mvn -B -ntp verify
      - name: 'Uploader les JAR produits'
        uses: actions/upload-artifact@v4
        with:
          name: nexus-java-jdk${{ matrix.java }}
          path: target/*.jar
          retention-days: 7
          if-no-files-found: ignore

  # -------------------------------------------------------------------
  # JOB 2/3 : owasp — dependency-check-maven. Lourd (télécharge la base
  #   NVD) donc isolé de la matrice. Le rapport est un artefact, jamais
  #   perdu, même si le job échoue (always()).
  # -------------------------------------------------------------------
  owasp:
    name: 'OWASP dependency-check'
    needs: build
    if: github.ref == 'refs/heads/__BRANCH__'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup JDK (temurin, cache maven)'
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: __JAVA__
          cache: maven
      - name: 'Dependency-check (CVE des dépendances)'
        run: mvn -B -ntp org.owasp:dependency-check-maven:check -DskipTests
      - name: 'Uploader le rapport OWASP'
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: nexus-owasp-report
          path: target/dependency-check-report.html
          retention-days: 14
          if-no-files-found: ignore

  # -------------------------------------------------------------------
  # JOB 3/3 : codeql — analyse statique de sécurité Java.
  # -------------------------------------------------------------------
  codeql:
    name: 'CodeQL (securite statique)'
    needs: build
    runs-on: ubuntu-latest
    permissions:
      contents: read
      security-events: write
    strategy:
      matrix:
        language: [java-kotlin]
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Initialisation CodeQL'
        uses: github/codeql-action/init@v3
        with:
          languages: ${{ matrix.language }}
      - name: 'Autobuild (Maven)'
        uses: github/codeql-action/autobuild@v3
      - name: 'Analyse CodeQL'
        uses: github/codeql-action/analyze@v3
        with:
          category: '/language:${{ matrix.language }}'

NEXUS_YAML
}

# ============================================================================
# SECTION 16 — TEMPLATE python (ruff + pytest + mypy + pip-audit)
# ============================================================================
# Pipeline qualité Python moderne : ruff (lint+format, remplace flake8/
# isort), pytest avec coverage XML, mypy tolérant par défaut (à durcir
# progressivement), pip-audit bloquant sur les CVE connues.
inject_python() {
    cat <<'NEXUS_YAML'
# =============================================================================
# NEXUS PYTHON — pipeline qualité et sécurité
# Généré par NEXUS CI GENERATOR v__GENVER__ le __DATE__ (type: python)
# Fichier: __WORKFLOW_FILE__ | Branche: __BRANCH__ | Python: __PYTHON__
# -----------------------------------------------------------------------------
# Chaîne de contrôle :
#   1. quality : matrice 3.10→3.13 — ruff, pytest+coverage, mypy
#   2. audit   : pip-audit — CVE des dépendances installées
#   3. codeql  : analyse statique de sécurité (language: python)
# Le job quality installe requirements.txt s'il existe, plus les outils
# de qualité en versions pinnées par le lockfile s'il y en a un.
# Secrets requis : aucun.
# =============================================================================
name: 'NEXUS PYTHON (qualite & securite)'
on:
  push:
    branches: [__BRANCH__]
  pull_request:
    branches: [__BRANCH__]
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: 'nexus-python-${{ github.ref }}'
  cancel-in-progress: true

jobs:
  # -------------------------------------------------------------------
  # JOB 1/3 : quality — matrice d'interpréteurs. La valeur --python est
  #   TOUJOURS dans la matrice : votre version cible est testée en
  #   premier, les autres garantissent la compatibilité descendante.
  # -------------------------------------------------------------------
  quality:
    name: 'Qualite (py${{ matrix.python }})'
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix:
        python: [__PYTHON__, '3.10', '3.11', '3.13']
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup Python ${{ matrix.python }} (cache pip)'
        uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python }}
          cache: pip
      - name: 'Installer les dépendances du projet'
        run: |
          python -m pip install --upgrade pip
          if [ -f requirements.txt ]; then
            pip install -r requirements.txt
          fi
          if [ -f requirements-dev.txt ]; then
            pip install -r requirements-dev.txt
          fi
          pip install ruff pytest pytest-cov mypy
      - name: 'Ruff — lint (bloquant)'
        run: ruff check .
      - name: 'Ruff — format (bloquant)'
        run: ruff format --check .
      - name: 'Pytest — tests + coverage'
        run: pytest --cov=. --cov-report=xml --cov-report=term -q
      - name: 'Mypy — types (tolérant par défaut, à durcir)'
        run: mypy . --ignore-missing-imports
      - name: 'Uploader le rapport de coverage'
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: nexus-coverage-py${{ matrix.python }}
          path: coverage.xml
          retention-days: 7
          if-no-files-found: ignore

  # -------------------------------------------------------------------
  # JOB 2/3 : audit — pip-audit sur l'environnement résolu. Ne tourne
  #   que sur la version cible (une seule passe suffit pour les CVE).
  # -------------------------------------------------------------------
  audit:
    name: 'pip-audit (CVE dépendances)'
    needs: quality
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup Python (cache pip)'
        uses: actions/setup-python@v5
        with:
          python-version: '__PYTHON__'
          cache: pip
      - name: 'Installer et auditer'
        run: |
          python -m pip install --upgrade pip pip-audit
          if [ -f requirements.txt ]; then
            pip install -r requirements.txt
          fi
          pip-audit --strict

  # -------------------------------------------------------------------
  # JOB 3/3 : codeql — analyse statique de sécurité Python.
  # -------------------------------------------------------------------
  codeql:
    name: 'CodeQL (securite statique)'
    needs: quality
    runs-on: ubuntu-latest
    permissions:
      contents: read
      security-events: write
    strategy:
      matrix:
        language: [python]
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Initialisation CodeQL'
        uses: github/codeql-action/init@v3
        with:
          languages: ${{ matrix.language }}
      - name: 'Autobuild'
        uses: github/codeql-action/autobuild@v3
      - name: 'Analyse CodeQL'
        uses: github/codeql-action/analyze@v3
        with:
          category: '/language:${{ matrix.language }}'

NEXUS_YAML
}
