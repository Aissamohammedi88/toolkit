
# ============================================================================
# SECTION 24 — COMMANDE list
# ============================================================================
cmd_list() {
    local t
    log_step "Types de workflows supportés (${#TYPES_ORDER[@]})"
    printf '\n'
    for t in "${TYPES_ORDER[@]}"; do
        printf '  %s%-10s%s  %s\n' "${C_BOLD}${C_CYAN}" "$t" "${C_RESET}" "${WORKFLOW_DESC[$t]}"
        printf '  %s          ->  %s%s%s\n' "${C_DIM}" ".github/workflows/${WORKFLOW_FILE[$t]}" "${C_RESET}" ""
    done
    printf '\n'
    log_info "générer un type: ./nexus-ci-generator.sh <type> [--dir <dépôt>]"
    log_info "documenter un type: ./nexus-ci-generator.sh explain <type>"
}

# ============================================================================
# SECTION 25 — COMMANDE explain
# ============================================================================
cmd_explain() {
    if [ "${#OPT_POSITIONAL[@]}" -lt 1 ]; then
        die "explain requiert un type (ex: explain aegis)" "$EXIT_USAGE"
    fi
    local type="${OPT_POSITIONAL[0]}"
    if ! is_known_type "$type"; then
        die "type inconnu: $type (voir: list)" "$EXIT_USAGE"
    fi
    explain_type "$type"
}

# ============================================================================
# SECTION 26 — COMMANDE validate
# ============================================================================
cmd_validate() {
    if [ "${#OPT_POSITIONAL[@]}" -lt 1 ]; then
        die "validate requiert un chemin de fichier (ex: validate .github/workflows/x.yml)" "$EXIT_USAGE"
    fi
    local file="${OPT_POSITIONAL[0]}"
    if [ ! -f "$file" ]; then
        die "fichier introuvable: $file" "$EXIT_ERR"
    fi
    log_step "Validation du workflow: $file"
    # La commande validate ignore OPT_SKIP_VALIDATION : elle EXISTE pour
    # valider. L'option n'aurait aucun sens ici et est refusée.
    if [ "$OPT_SKIP_VALIDATION" -eq 1 ]; then
        log_warn "--skip-validation ignorée: validate existe pour valider"
    fi
    local saved_flag="$OPT_SKIP_VALIDATION"
    OPT_SKIP_VALIDATION=0
    if validate_yaml_file "$file"; then
        log_ok "structure GitHub Actions valide: $file"
        log_ok "$(grep -c '^' "$file") lignes, $(grep -cE '^  [a-zA-Z0-9_-]+:' "$file") jobs détectés"
        return "$EXIT_OK"
    fi
    OPT_SKIP_VALIDATION="$saved_flag"
    die "validation échouée: $file" "$EXIT_YAML"
}

# ============================================================================
# SECTION 27 — COMMANDE doctor
# ============================================================================
# Diagnostic complet : chaque vérification affiche son verdict UN PAR UN
# (jamais de "tout va bien" global qui cache un détail mort).
cmd_doctor() {
    local ok=0
    local warn=0
    local ko=0
    local line

    log_step "Diagnostic de l'environnement"
    hr

    # 1. bash
    if [ "${BASH_VERSINFO[0]}" -ge 4 ]; then
        printf '  [OK]   bash %s (>= 4 requis: tableaux associatifs)\n' "${BASH_VERSION%%(*}"
        ok=$((ok + 1))
    else
        printf '  [KO]   bash %s (< 4)\n' "${BASH_VERSION%%(*}"
        ko=$((ko + 1))
    fi

    # 2. git
    if command -v git >/dev/null 2>&1; then
        printf '  [OK]   git %s (dépôt cible + détection .git)\n' "$(git --version | awk '{print $3}')"
        ok=$((ok + 1))
    else
        printf '  [KO]   git introuvable\n'
        ko=$((ko + 1))
    fi

    # 3. python3
    if command -v python3 >/dev/null 2>&1; then
        printf '  [OK]   python3 %s\n' "$(python3 --version 2>&1 | awk '{print $2}')"
        ok=$((ok + 1))
    else
        printf '  [KO]   python3 introuvable (validation YAML impossible)\n'
        ko=$((ko + 1))
    fi

    # 4. PyYAML
    if python3 -c "import yaml" >/dev/null 2>&1; then
        printf '  [OK]   PyYAML %s (validation YAML active)\n' "$(python3 -c 'import yaml; print(yaml.__version__)')"
        ok=$((ok + 1))
    else
        printf '  [KO]   module python yaml (PyYAML) introuvable -> pip install pyyaml\n'
        ko=$((ko + 1))
    fi

    # 5. sed (substitution des placeholders)
    if command -v sed >/dev/null 2>&1; then
        printf '  [OK]   sed (substitution placeholders)\n'
        ok=$((ok + 1))
    else
        printf '  [KO]   sed introuvable\n'
        ko=$((ko + 1))
    fi

    # 6. awk (rapports doctor/list)
    if command -v awk >/dev/null 2>&1; then
        printf '  [OK]   awk (rapports)\n'
        ok=$((ok + 1))
    else
        printf '  [ATT]  awk introuvable (rapports dégradés)\n'
        warn=$((warn + 1))
    fi

    # 7. mktemp (fichiers temporaires atomiques)
    if command -v mktemp >/dev/null 2>&1; then
        printf '  [OK]   mktemp (écriture atomique)\n'
        ok=$((ok + 1))
    else
        printf '  [KO]   mktemp introuvable (écriture non atomique)\n'
        ko=$((ko + 1))
    fi

    # 8. répertoire courant = dépôt git ?
    if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
        printf '  [OK]   répertoire courant: dépôt git (%s)\n' "$(git rev-parse --show-toplevel 2>/dev/null || printf '.')"
        ok=$((ok + 1))
    else
        printf '  [ATT]  répertoire courant PAS un dépôt git — utilise --dir <chemin>\n'
        warn=$((warn + 1))
    fi

    # 9. espace disque sur le répertoire courant (>50 Mo)
    local free_mb
    free_mb="$(df -Pm . 2>/dev/null | awk 'NR==2 {print $4}' || printf 0)"
    if [ "${free_mb:-0}" -gt 50 ]; then
        printf '  [OK]   espace disque: %s Mo libres\n' "$free_mb"
        ok=$((ok + 1))
    else
        printf '  [ATT]  espace disque faible: %s Mo\n' "${free_mb:-?}"
        warn=$((warn + 1))
    fi

    # 10. shellcheck (qualité du shell — optionnel, recommandé)
    if command -v shellcheck >/dev/null 2>&1; then
        printf '  [OK]   shellcheck %s (audit qualité shell disponible)\n' \
            "$(shellcheck --version 2>/dev/null | awk '/version:/ {print $2}' | head -n1)"
        ok=$((ok + 1))
    else
        printf '  [ATT]  shellcheck absent (audit qualité shell impossible)\n'
        warn=$((warn + 1))
    fi

    # 11. workflows NEXUS déjà installés dans le dépôt courant
    local wf_count
    wf_count=0
    if [ -d .github/workflows ]; then
        for f in .github/workflows/nexus-*.yml; do
            if [ -f "$f" ]; then
                wf_count=$((wf_count + 1))
            fi
        done
    fi
    if [ "$wf_count" -gt 0 ]; then
        printf '  [OK]   %s workflow(s) NEXUS déjà installé(s) (--force pour régénérer)\n' "$wf_count"
        ok=$((ok + 1))
    else
        printf '  [OK]   aucun workflow NEXUS préexistant (première installation)\n'
        ok=$((ok + 1))
    fi

    # 12. réseau vers github.com (validation des actions @v4/@v3)
    if command -v curl >/dev/null 2>&1; then
        if curl -fsS --max-time 5 -o /dev/null https://github.com 2>/dev/null; then
            printf '  [OK]   réseau: github.com joignable\n'
            ok=$((ok + 1))
        else
            printf '  [ATT]  github.com injoignable (offline ? workflows identiques quand même)\n'
            warn=$((warn + 1))
        fi
    else
        printf '  [ATT]  curl absent (sonde réseau ignorée)\n'
        warn=$((warn + 1))
    fi

    hr
    printf '  bilan: %s OK, %s attention, %s bloquant(s)\n\n' "$ok" "$warn" "$ko"
    if [ "$ko" -gt 0 ]; then
        die "environnement INCOMPLET — corrigez les [KO] ci-dessus" "$EXIT_ENV"
    fi
    if [ "$warn" -gt 0 ]; then
        log_warn "avertissements non bloquants: $warn"
    fi
    log_ok "environnement opérationnel"
}

# ============================================================================
# SECTION 28 — COMMANDE uninstall
# ============================================================================
# Sécurité à deux étages :
#   1. on ne touche QUE les fichiers portant le marqueur NEXUS_MARKER
#      (un workflow écrit à la main est REFUSÉ)
#   2. confirmation interactive obligatoire (sauf --force / stdin actif)
cmd_uninstall() {
    local type="" file="" target
    if [ "${#OPT_POSITIONAL[@]}" -ge 1 ]; then
        if is_known_type "${OPT_POSITIONAL[0]}"; then
            type="${OPT_POSITIONAL[0]}"
            file="${WORKFLOW_FILE[$type]}"
        else
            file="${OPT_POSITIONAL[0]}"
        fi
    else
        die "uninstall requiert un type (ex: uninstall aegis) ou un chemin" "$EXIT_USAGE"
    fi
    target="$OPT_DIR/.github/workflows/$file"

    if [ ! -f "$target" ]; then
        die "rien à supprimer: $target inexistant" "$EXIT_ERR"
    fi

    # Étage 1 : le marqueur. head -3 suffit : le marqueur est ligne 2
    # de tout workflow généré (ligne 1 = titre du bloc).
    if ! head -n 3 "$target" | grep -q "$NEXUS_MARKER"; then
        die "REFUS: $target ne porte pas le marqueur NEXUS (fichier écrit à la main ?)" "$EXIT_ERR"
    fi

    log_step "Suppression du workflow: $target"
    if ! confirm "Supprimer définitivement $target ?"; then
        log_warn "suppression annulée par l'utilisateur"
        return "$EXIT_OK"
    fi
    rm -f "$target"
    log_ok "supprimé: $target"
    log_info "pensez à committer la suppression (git add -A && git commit -m 'ci: remove nexus $type')"
}
