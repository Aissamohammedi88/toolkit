
explain_php() {
    cat <<'NEXUS_EXPLAIN'
TYPE: php — pipeline composer & qualité
FICHIER GÉNÉRÉ: .github/workflows/nexus-php.yml

DÉCLENCHEURS: push + pull_request sur la branche, workflow_dispatch.

JOBS (2):
  1. quality - matrice PHP [8.2, 8.3, votre --php] avec setup-php
               officiel (intl, mbstring, xml), composer validate
               --strict, composer install (lockfile), php-cs-fixer
               --dry-run --diff (style constaté, jamais réécrit),
               phpunit BLOQUANT : phpunit.xml absent = échec explicite.
  2. audit   - composer audit sur composer.lock (advisory Packagist).
               composer.lock absent = échec explicite.

SECRETS REQUIS: aucun.
ARTEFACTS: aucun (les rapports restent dans les logs du job).
DURÉE ESTIMÉE: quality 2-4 min par version de la matrice, audit 1 min.

POSITION HONNÊTE SUR PHPUNIT:
  là où node utilise --if-present (écosystème hétérogène), php exige
  phpunit.xml : un projet PHP moderne sans config de tests est une
  dette immédiate. Le pipeline le dit au lieu de sourire poliment.
NEXUS_EXPLAIN
}

explain_dotnet() {
    cat <<'NEXUS_EXPLAIN'
TYPE: dotnet — pipeline build/test/pack
FICHIER GÉNÉRÉ: .github/workflows/nexus-dotnet.yml

DÉCLENCHEURS: push + pull_request sur la branche, workflow_dispatch.

JOBS (3):
  1. build  - matrice SDK [8.0.x, votre --dotnet] avec cache NuGet.
              Pattern restore-once : dotnet restore explicite UNE fois,
              puis build --no-restore et test --no-restore. La
              couverture XPlat est collectée par test.
  2. pack   - dotnet pack --output ./artifacts sur la branche
              principale UNIQUEMENT (les PR ne produisent pas de
              paquets). Artefact .nupkg avec if-no-files-found: error :
              un pack qui ne packe rien est un échec, pas un succès.
  3. codeql - analyse statique csharp.

EXIGE: un .sln ou .csproj détectable (step de vérification dédiée).
SECRETS REQUIS: aucun.
ARTEFACTS: nexus-dotnet-nupkg (7j).
DURÉE ESTIMÉE: build 3-6 min par SDK, pack 2-3 min, codeql 4-8 min.

NOTE CACHE:
  le cache NuGet s'appuie sur packages.lock.json si votre projet en
  génère un ; sinon le cache par défaut de setup-dotnet s'applique.
NEXUS_EXPLAIN
}

explain_cpp() {
    cat <<'NEXUS_EXPLAIN'
TYPE: cpp — pipeline cmake & sanitizers
FICHIER GÉNÉRÉ: .github/workflows/nexus-cpp.yml

DÉCLENCHEURS: push + pull_request sur la branche, workflow_dispatch.

JOBS (3):
  1. build    - matrice [gcc, clang] en Release avec -Werror : tout
               avertissement EST une erreur. ctest --output-on-failure.
  2. sanitize - build Debug avec -fsanitize=address,undefined et
               -fno-omit-frame-pointer, puis ctest rejoué SOUS
               sanitizers : use-after-free, overflow, UB reproduits
               en CI au lieu d'attendre le crash en production.
  3. analyse  - cppcheck --enable=warning,style --inconclusive,
               error-exitcode=1. Indépendant du compilateur : il
               attrape les patterns que gcc ET clang acceptent.

EXIGE: CMakeLists.txt à la racine + tests enregistrés dans CTest.
SECRETS REQUIS: aucun.
DURÉE ESTIMÉE: build 4-8 min par compilateur, sanitize 4-8 min,
               analyse 1-2 min.

POURQUOI -Werror EN CI:
  un avertissement laissé vivre devient du bruit, et le bruit devient
  de la cécité. En CI, -Werror force le traitement immédiat : c'est
  le seul endroit où le coût de réparation est minimal.
NEXUS_EXPLAIN
}

explain_android() {
    cat <<'NEXUS_EXPLAIN'
TYPE: android — pipeline gradle & APK
FICHIER GÉNÉRÉ: .github/workflows/nexus-android.yml

DÉCLENCHEURS: push + tags v* + pull_request + workflow_dispatch.

JOBS (2):
  1. quality - vérification du wrapper (gradlew présent ET exécutable
               — erreur explicite sinon), JDK 17 temurin (imposé par
               AGP), setup-gradle avec cache, puis lint,
               testDebugUnitTest, assembleDebug, APK debug joint.
  2. release - assembleRelease sur tag v* uniquement. L'APK produit
               est UNSIGNED et joint en artefact (14j).

EXIGE: gradlew à la racine du dépôt (committez le wrapper : c'est la
       version de build du projet, pas un détail).

SECRETS REQUIS: aucun — ET C'EST UN CHOIX:
  la signature d'un APK avec un keystore stocké en secret CI
  transformerait ce secret en point de défaillance unique. La
  signature reste un acte humain (keystore local ou job dédié
  HSM). Le pipeline livre l'unsigned ; le release manager signe.

ARTEFACTS: nexus-android-debug (7j), nexus-android-release-unsigned (14j).
DURÉE ESTIMÉE: quality 6-15 min (gradle cold), release 4-10 min.
NEXUS_EXPLAIN
}
