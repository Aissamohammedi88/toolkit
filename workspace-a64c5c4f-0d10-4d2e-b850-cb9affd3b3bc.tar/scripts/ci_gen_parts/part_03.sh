
# ============================================================================
# SECTION 9 — OPTIONS ET PARSING
# ============================================================================
# Toutes les options ont une valeur par défaut assignée AVANT parse_args :
# set -u ne pardonne pas la variable non initialisée.
OPT_DIR="$DEFAULT_DIR"
OPT_BRANCH="$DEFAULT_BRANCH"
OPT_NODE="$DEFAULT_NODE"
OPT_JAVA="$DEFAULT_JAVA"
OPT_PYTHON="$DEFAULT_PYTHON"
OPT_GO="$DEFAULT_GO"
OPT_PHP="$DEFAULT_PHP"
OPT_DOTNET="$DEFAULT_DOTNET"
OPT_REGISTRY="$DEFAULT_REGISTRY"
OPT_CRON="$DEFAULT_CRON"
OPT_FORCE=0
OPT_DRYRUN=0
OPT_SKIP_VALIDATION=0
OPT_QUIET=0
OPT_HELP=0
OPT_POSITIONAL=()

# parse_args : consomme "$@" (après extraction de la commande principale).
# Les valeurs manquantes et options inconnues sont des erreurs d'usage
# (exit 2) — jamais de comportement implicite.
parse_args() {
    while [ $# -gt 0 ]; do
        case "$1" in
            --dir)
                if [ $# -lt 2 ]; then die "option --dir requiert une valeur" "$EXIT_USAGE"; fi
                OPT_DIR="$2"; shift 2 ;;
            --branch)
                if [ $# -lt 2 ]; then die "option --branch requiert une valeur" "$EXIT_USAGE"; fi
                OPT_BRANCH="$2"; shift 2 ;;
            --node)
                if [ $# -lt 2 ]; then die "option --node requiert une valeur" "$EXIT_USAGE"; fi
                OPT_NODE="$2"; shift 2 ;;
            --java)
                if [ $# -lt 2 ]; then die "option --java requiert une valeur" "$EXIT_USAGE"; fi
                OPT_JAVA="$2"; shift 2 ;;
            --python)
                if [ $# -lt 2 ]; then die "option --python requiert une valeur" "$EXIT_USAGE"; fi
                OPT_PYTHON="$2"; shift 2 ;;
            --go)
                if [ $# -lt 2 ]; then die "option --go requiert une valeur" "$EXIT_USAGE"; fi
                OPT_GO="$2"; shift 2 ;;
            --php)
                if [ $# -lt 2 ]; then die "option --php requiert une valeur" "$EXIT_USAGE"; fi
                OPT_PHP="$2"; shift 2 ;;
            --dotnet)
                if [ $# -lt 2 ]; then die "option --dotnet requiert une valeur" "$EXIT_USAGE"; fi
                OPT_DOTNET="$2"; shift 2 ;;
            --registry)
                if [ $# -lt 2 ]; then die "option --registry requiert une valeur" "$EXIT_USAGE"; fi
                OPT_REGISTRY="$2"; shift 2 ;;
            --cron)
                if [ $# -lt 2 ]; then die "option --cron requiert une valeur" "$EXIT_USAGE"; fi
                OPT_CRON="$2"; shift 2 ;;
            --force)
                OPT_FORCE=1; shift ;;
            --dry-run)
                OPT_DRYRUN=1; shift ;;
            --skip-validation)
                OPT_SKIP_VALIDATION=1; shift ;;
            --no-color)
                shift ;;
            --quiet|-q)
                OPT_QUIET=1
                NEXUS_QUIET=1
                shift ;;
            -h|--help)
                OPT_HELP=1; shift ;;
            --)
                shift
                while [ $# -gt 0 ]; do
                    OPT_POSITIONAL+=("$1"); shift
                done
                break ;;
            -*)
                die "option inconnue: $1 (voir --help)" "$EXIT_USAGE" ;;
            *)
                OPT_POSITIONAL+=("$1"); shift ;;
        esac
    done
}

# Si -h/--help est présent n'importe où : on affiche l'aide et on sort 0.
handle_help_flag() {
    if [ "$OPT_HELP" -eq 1 ]; then
        usage
        exit "$EXIT_OK"
    fi
}

# ============================================================================
# SECTION 10 — VALIDATEURS D'ENTRÉES
# ============================================================================
# Aucune valeur fournie par l'utilisateur n'atteint sed sans validation :
# les placeholders sont substitués via `s|__X__|v|g` (délimiteur |), donc
# tout caractère hostile dans v casserait la commande sed ET le YAML.

# Versions: 22, 3.12, 1.23, 21, 17 (chiffres et points, max 4 segments)
valid_version() {
    if [[ "$1" =~ ^[0-9]+(\.[0-9]+){0,3}$ ]]; then
        return 0
    fi
    return 1
}

# Branches: lettres, chiffres, . _ / - (ex: main, develop, release/1.2,
# feature/new-login). Les '..' et espaces sont interdits.
valid_branch() {
    if [[ "$1" =~ ^[A-Za-z0-9._/-]+$ ]] && [[ "$1" != *..* ]]; then
        return 0
    fi
    return 1
}

# Cron GitHub Actions: exactement 5 champs, caractères autorisés par la
# syntaxe POSIX cron étendue (pas de @units ici, GH les supporte mais on
# reste sur 5 champs pour des schedules auditéables).
valid_cron() {
    local -a fields
    read -ra fields <<<"$1"
    if [ "${#fields[@]}" -ne 5 ]; then
        return 1
    fi
    local f
    for f in "${fields[@]}"; do
        if ! [[ "$f" =~ ^[0-9*/,-]+$ ]]; then
            return 1
        fi
    done
    return 0
}

# Registre: hôte[:port]/chemin optionnel (ghcr.io, registry.local:5000/team)
valid_registry() {
    if [[ "$1" =~ ^[A-Za-z0-9._-]+(:[0-9]+)?(/[A-Za-z0-9._/-]*)?$ ]]; then
        return 0
    fi
    return 1
}

# Matrice par type: on ne valide QUE les options pertinentes au type
# demandé — les autres gardent leur valeur par défaut et ne sont pas
# injectées dans le template (elles seraient du bruit).
validate_generation_options() {
    local type="$1"
    log_step "Validation des options pour le type '$type'"
    if ! valid_branch "$OPT_BRANCH"; then
        die "branche invalide: '$OPT_BRANCH' (autorisé: A-Za-z0-9._/- , pas de ..)" "$EXIT_USAGE"
    fi
    case "$type" in
        aegis|node)
            if ! valid_version "$OPT_NODE"; then
                die "version Node invalide: '$OPT_NODE' (attendu: 22, 20, 18.19...)" "$EXIT_USAGE"
            fi
            ;;
        java)
            if ! valid_version "$OPT_JAVA"; then
                die "version JDK invalide: '$OPT_JAVA' (attendu: 21, 17, 11...)" "$EXIT_USAGE"
            fi
            ;;
        python)
            if ! valid_version "$OPT_PYTHON"; then
                die "version Python invalide: '$OPT_PYTHON' (attendu: 3.12, 3.11...)" "$EXIT_USAGE"
            fi
            ;;
        go)
            if ! valid_version "$OPT_GO"; then
                die "version Go invalide: '$OPT_GO' (attendu: 1.23, 1.22...)" "$EXIT_USAGE"
            fi
            ;;
        php)
            if ! valid_version "$OPT_PHP"; then
                die "version PHP invalide: '$OPT_PHP' (attendu: 8.3, 8.2...)" "$EXIT_USAGE"
            fi
            ;;
        dotnet)
            if ! valid_version "$OPT_DOTNET"; then
                die "version .NET SDK invalide: '$OPT_DOTNET' (attendu: 9.0, 8.0...)" "$EXIT_USAGE"
            fi
            ;;
        docker)
            if ! valid_registry "$OPT_REGISTRY"; then
                die "registre invalide: '$OPT_REGISTRY' (attendu: hôte[:port]/chemin)" "$EXIT_USAGE"
            fi
            ;;
        nightly)
            if ! valid_cron "$OPT_CRON"; then
                die "cron invalide: '$OPT_CRON' (attendu: 5 champs, ex: 0 3 * * *)" "$EXIT_USAGE"
            fi
            ;;
    esac
    log_ok "options valides (branch=$OPT_BRANCH)"
}

# ============================================================================
# SECTION 11 — CHECK ENVIRONNEMENT (fonction du skeleton, conservée)
# ============================================================================
# Contrats vérifiés, dans l'ordre du moins coûteux au plus coûteux:
#   1. le répertoire cible existe
#   2. c'est un dépôt git (.git ou rev-parse) — un workflow hors dépôt
#      n'a aucun sens et GitHub ne le lira jamais
#   3. python3 + PyYAML présents si la validation est demandée
#   4. le répertoire .github/workflows est créé proprement
check_env() {
    local dir="$OPT_DIR"
    if [ ! -d "$dir" ]; then
        die "répertoire cible inexistant: $dir" "$EXIT_ENV"
    fi
    if ! git -C "$dir" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
        die "$dir n'est pas un dépôt git (check_env exige un dépôt avec .git)" "$EXIT_ENV"
    fi
    if [ "$OPT_SKIP_VALIDATION" -eq 0 ]; then
        if ! require_cmd python3; then
            die "python3 requis pour la validation YAML (ou --skip-validation, déconseillé)" "$EXIT_ENV"
        fi
        if ! python3 -c "import yaml" >/dev/null 2>&1; then
            die "module python 'yaml' (PyYAML) introuvable -> pip install pyyaml, ou --skip-validation" "$EXIT_ENV"
        fi
    fi
    if [ "$OPT_DRYRUN" -eq 0 ]; then
        if ! mkdir -p "$dir/.github/workflows" 2>/dev/null; then
            die "impossible de créer $dir/.github/workflows (permissions ?)" "$EXIT_ENV"
        fi
    fi
    log_ok "environnement OK (dépôt git: $dir)"
}

# ============================================================================
# SECTION 12 — VALIDATEUR YAML (syntaxe + structure)
# ============================================================================
# Le validateur ne se contente pas de "ça parse" : il impose une structure
# de workflow GitHub Actions réelle :
#   - racine = mapping
#   - déclencheur présent ('on' — PyYAML 1.1 le parse parfois en clé True,
#     on gère les deux formes explicitement, quirk documenté)
#   - jobs non vide, chaque job a runs-on
#   - anti-bug skeleton : AUCUNE ligne `run: actions/...` (une action
#     GitHub n'est PAS une commande shell — PROTON ④)
#   - clés dupliquées rejetées : PyYAML standard les ignore (dernière
#     gagne, silencieusement) mais GitHub Actions les refuse au parse.
#     Un loader custom rend le bug visible AVANT l'installation.
validate_yaml_file() {
    local target="$1"
    if [ "$OPT_SKIP_VALIDATION" -eq 1 ]; then
        log_warn "validation YAML sautée (--skip-validation) — $target NON vérifié"
        return 0
    fi
    if [ ! -f "$target" ]; then
        log_err "fichier introuvable: $target"
        return 1
    fi
    if grep -qE '^[[:space:]]*run:.*actions/' "$target"; then
        log_err "YAML ILLÉGAL détecté: une action GitHub est exécutée comme du shell"
        log_err "pattern interdit trouvé: 'run: actions/...' dans $target"
        return 1
    fi
    python3 - "$target" <<'NEXUS_PY'
import sys
import yaml

class DuplicateKeyLoader(yaml.SafeLoader):
    """SafeLoader + rejet des clés dupliquées.
    PyYAML standard garde la derniere valeur sans erreur ; GitHub
    Actions, lui, refuse le fichier. On aligne le validateur sur la
    realite de GitHub : un doublon est une ERREUR, pas un choix."""
    pass

def _no_dupes(loader, node, deep=False):
    mapping = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if key in mapping:
            raise yaml.constructor.ConstructorError(
                "doublon",
                None,
                f"clé dupliquée: {key!r}",
                key_node.start_mark,
            )
        mapping[key] = loader.construct_object(value_node, deep=deep)
    return mapping

DuplicateKeyLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _no_dupes
)

path = sys.argv[1]
try:
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.load(fh, Loader=DuplicateKeyLoader)
except yaml.YAMLError as exc:
    print(f"YAML_SYNTAXE_INVALIDE: {exc}")
    sys.exit(5)
except OSError as exc:
    print(f"YAML_ILLISIBLE: {exc}")
    sys.exit(5)

if not isinstance(data, dict):
    print("YAML_STRUCTURE_INVALIDE: la racine n'est pas un mapping")
    sys.exit(5)

# Quirk PyYAML (spec YAML 1.1) : la clé 'on' est parsée en booléen True.
# GitHub Actions accepte les deux formes d'écriture dans le fichier.
has_trigger = ("on" in data) or (True in data)
if not has_trigger:
    print("YAML_STRUCTURE_INVALIDE: déclencheur 'on' absent")
    sys.exit(5)

jobs = data.get("jobs")
if not isinstance(jobs, dict) or len(jobs) == 0:
    print("YAML_STRUCTURE_INVALIDE: 'jobs' absent ou vide")
    sys.exit(5)

for name, job in jobs.items():
    if not isinstance(job, dict) or "runs-on" not in job:
        print(f"YAML_STRUCTURE_INVALIDE: job '{name}' sans 'runs-on'")
        sys.exit(5)

print("YAML_VALIDE")
sys.exit(0)
NEXUS_PY
}

# ============================================================================
# SECTION 13 — SUBSTITUTION DES PLACEHOLDERS ET ÉCRITURE ATOMIQUE
# ============================================================================
# Les templates YAML sont écrits dans des heredocs QUOTÉS (<<'NEXUS_YAML')
# pour que bash n'interprète RIEN : les expressions GitHub ${{ ... }} sont
# neutres. Les valeurs utilisateur entrent APRÈS coup par substitution de
# placeholders __X__ via sed avec délimiteur | (tolère les / des branches).
apply_placeholders() {
    local file="$1"
    NODE_MATRIX="[$(printf '%s\n' "$OPT_NODE" 20 22 | awk '!seen[$0]++' | paste -sd, - | sed 's/,/, /g')]"
    PHP_MATRIX="[$(printf "'%s'\n" '8.2' '8.3' "$OPT_PHP" | awk '!seen[$0]++' | paste -sd, - | sed 's/,/, /g')]"
    sed -i \
        -e "s|__BRANCH__|$OPT_BRANCH|g" \
        -e "s|__NODE__|$OPT_NODE|g" -e "s|__NODE_MATRIX__|$NODE_MATRIX|g" \
        -e "s|__JAVA__|$OPT_JAVA|g" \
        -e "s|__PYTHON__|$OPT_PYTHON|g" \
        -e "s|__GO__|$OPT_GO|g" \
        -e "s|__PHP__|$OPT_PHP|g" -e "s|__PHP_MATRIX__|$PHP_MATRIX|g" \
        -e "s|__DOTNET__|$OPT_DOTNET|g" \
        -e "s|__REGISTRY__|$OPT_REGISTRY|g" \
        -e "s|__CRON__|$OPT_CRON|g" \
        -e "s|__DATE__|$NEXUS_GEN_DATE|g" \
        -e "s|__GENVER__|$NEXUS_VERSION|g" \
        -e "s|__WORKFLOW_FILE__|$(basename "$file")|g" \
        "$file"
}

# Pipeline de génération complet pour un type donné :
#   inject_<type> > tmp -> placeholders -> validation -> installation.
# Contrats PROTON :
#   - jamais de YAML cassé installé (validation avant mv)
#   - installation atomique (mv sur le même filesystem)
#   - collision = exit 4 sauf --force ; --dry-run n'écrit jamais
generate_workflow() {
    local type="$1"
    local file="${WORKFLOW_FILE[$type]}"
    local target_dir="$OPT_DIR/.github/workflows"
    local target="$target_dir/$file"
    local tmp

    check_env

    if [ "$OPT_DRYRUN" -eq 0 ]; then
        if [ -e "$target" ] && [ "$OPT_FORCE" -eq 0 ]; then
            die "collision: $target existe déjà (utilise --force pour écraser)" "$EXIT_COLLISION"
        fi
    fi

    log_step "Génération du workflow '$type' -> $file"
    tmp="$(nexus_tmp_new "$target_dir")"
    "inject_${type}" >"$tmp"
    apply_placeholders "$tmp"

    if ! validate_yaml_file "$tmp"; then
        rm -f "$tmp"
        die "validation YAML échouée pour '$type' — fichier NON installé" "$EXIT_YAML"
    fi

    if [ "$OPT_DRYRUN" -eq 1 ]; then
        printf '%s\n' "${C_DIM}--- dry-run: $file (${NEXUS_GEN_DATE}) ---${C_RESET}"
        cat "$tmp"
        printf '%s\n' "${C_DIM}--- fin dry-run: rien n'a été écrit ---${C_RESET}"
        rm -f "$tmp"
        return 0
    fi

    mv -f "$tmp" "$target"
    chmod 0644 "$target"
    log_ok "workflow installé: $target ($(wc -l <"$target") lignes)"
    print_next_steps "$type" "$target"
}
