#!/usr/bin/env bash
# ============================================================================
#  ███  NEXUS CI GENERATOR v2.0.0  ███
#  Générateur de pipelines GitHub Actions — prêts pour la production
# ============================================================================
#  Auteur   : DGK — Aissa Mohammedi (protocole PROTON)
#  Origine  : NEXUS CI GENERATOR skeleton v1 — noms de fonctions préservés
#             verbatim : usage, check_env, inject_aegis, inject_java,
#             inject_python, inject_node, main
#  Licence  : MIT
# ----------------------------------------------------------------------------
#  SYNOPSIS
#      nexus-ci-generator.sh <commande> [options]
#      nexus-ci-generator.sh <type>     [options]   # raccourci de génération
#
#  DESCRIPTION
#      Génère des workflows GitHub Actions de qualité production dans
#      .github/workflows/. Chaque YAML produit est validé syntaxiquement
#      ET structurellement AVANT installation : le générateur n'installe
#      JAMAIS un fichier cassé. Si la validation échoue, le fichier
#      temporaire est détruit et tout workflow existant reste intact.
#      La génération est atomique (écriture en tmp + mv) et idempotente
#      avec --force.
#
#  COMMANDES / TYPES DE WORKFLOW
#      aegis      Pipeline sécurité & qualité Next.js (skeleton corrigé)
#      java       Pipeline Maven multi-JDK + OWASP dependency-check
#      python     Pipeline ruff + pytest + coverage + mypy + pip-audit
#      node       Pipeline npm multi-runtime + audit
#      docker     Pipeline image multi-arch + hadolint + Trivy + SBOM
#      go         Pipeline golangci-lint + tests -race + goreleaser
#      rust       Pipeline fmt + clippy + test + cargo-audit
#      release    Pipeline release sur tag v* + changelog + SLSA
#      nightly    Pipeline cron : scan nocturne complet
#      php        Pipeline composer + php-cs-fixer + phpunit + audit
#      dotnet     Pipeline .NET restore/build/test + pack NuGet
#      cpp        Pipeline cmake multi-compilateur + sanitizers
#      android    Pipeline gradle + lint + tests + APK debug/release
#      list       Liste les types supportés avec description
#      explain    Documentation opérationnelle d'un type
#      validate   Valide la syntaxe/structure d'un fichier workflow
#      doctor     Diagnostic complet de l'environnement
#      uninstall  Supprime un workflow généré (avec confirmation)
#      selftest   Test de bout en bout : génère et valide les 9 types
#      manual     Manuel complet intégré
#      changelog  Historique des versions
#
#  OPTIONS
#      --dir <chemin>       Répertoire du dépôt cible (défaut : .)
#      --branch <branche>   Branche déclencheuse (défaut : main)
#      --node <version>    Version Node.js (défaut : 22)
#      --java <version>    Version JDK (défaut : 21)
#      --python <version>  Version Python (défaut : 3.12)
#      --go <version>      Version Go (défaut : 1.23)
#      --php <version>     Version PHP (défaut : 8.3)
#      --dotnet <version>  Version .NET SDK (défaut : 9.0)
#      --registry <hote>   Registre conteneurs (défaut : ghcr.io)
#      --cron <expr>       Cron 5 champs (défaut : 0 3 * * *)
#      --force              Écrase un workflow existant
#      --dry-run            Génère sans écrire (sortie stdout)
#      --skip-validation   Saute la validation YAML (déconseillé)
#      --no-color           Désactive les couleurs ANSI
#      --quiet, -q          Seules les erreurs s'affichent
#      -h, --help           Aide courte
#
#  EXEMPLES
#      ./nexus-ci-generator.sh aegis --node 22
#      ./nexus-ci-generator.sh python --dir ~/projets/api --python 3.11
#      ./nexus-ci-generator.sh nightly --cron '30 2 * * 1'
#      ./nexus-ci-generator.sh selftest
#      ./nexus-ci-generator.sh validate .github/workflows/nexus-aegis.yml
#
#  CODES DE RETOUR
#      0  succès
#      1  erreur générique
#      2  usage incorrect
#      3  environnement invalide (pas un dépôt git, outils absents)
#      4  collision de fichier (workflow déjà présent, sans --force)
#      5  validation YAML échouée
#
#  CONFORMITÉ PROTON (appliquée à ce livrable)
#      1. Rien n'est affirmé sans preuve exécutable -> sous-commande selftest
#      2. Pas de livraison sans testbench            -> validation YAML
#                                                      intégrée au pipeline
#      3. Chaque écart a une preuve d'exécution      -> logs + codes retour
#      4. Réparation chirurgicale                    -> bug YAML du skeleton
#                                                      aegis corrigé (voir
#                                                      inject_aegis)
#      5. Spec d'origine préservée                   -> fonctions du skeleton
#                                                      conservées verbatim
# ============================================================================
set -euo pipefail

# ============================================================================
# SECTION 1 — GARDE-FOU RUNTIME ET PRÉ-SCAN
# ============================================================================
# bash >= 4 requis : le générateur utilise des tableaux associatifs
# (declare -A) pour le registre des types de workflows.
if [ "${BASH_VERSINFO[0]:-0}" -lt 4 ]; then
    printf 'ERREUR FATALE: bash >= 4.0 requis (tableaux associatifs). Version actuelle: %s\n' \
        "${BASH_VERSION:-inconnue}" >&2
    exit 3
fi

# --no-color doit agir même pour les erreurs d'usage : on l'extrait de "$@"
# AVANT tout affichage. On respecte aussi la convention NO_COLOR=1 et on
# coupe les couleurs quand stdout n'est pas un terminal (pipes, logs CI).
USE_COLOR=1
if [ "${NO_COLOR:-}" = "1" ] || [ "${TERM:-}" = "dumb" ] || [ ! -t 1 ]; then
    USE_COLOR=0
fi
for __arg in "$@"; do
    case "$__arg" in
        --no-color) USE_COLOR=0 ;;
    esac
done
unset __arg

# ============================================================================
# SECTION 2 — COULEURS ANSI
# ============================================================================
C_RESET=""; C_BOLD=""; C_DIM=""
C_RED=""; C_GREEN=""; C_YELLOW=""; C_CYAN=""; C_MAGENTA=""; C_BLUE=""

init_colors() {
    if [ "$USE_COLOR" -ne 1 ]; then
        return 0
    fi
    C_RESET=$'\033[0m'
    C_BOLD=$'\033[1m'
    C_DIM=$'\033[2m'
    C_RED=$'\033[31m'
    C_GREEN=$'\033[32m'
    C_YELLOW=$'\033[33m'
    C_CYAN=$'\033[36m'
    C_MAGENTA=$'\033[35m'
    C_BLUE=$'\033[34m'
}
init_colors

# ============================================================================
# SECTION 3 — JOURNALISATION
# ============================================================================
# NEXUS_QUIET=1 supprime les messages d'information (log_info, log_ok,
# log_step) mais JAMAIS les avertissements ni les erreurs (stderr).
NEXUS_QUIET=0

log_info() {
    if [ "$NEXUS_QUIET" -eq 1 ]; then
        return 0
    fi
    printf '%s\n' "${C_CYAN}[INFO]${C_RESET} $*"
}

log_ok() {
    if [ "$NEXUS_QUIET" -eq 1 ]; then
        return 0
    fi
    printf '%s\n' "${C_GREEN}[OK]${C_RESET}   $*"
}

log_warn() {
    printf '%s\n' "${C_YELLOW}[ATT]${C_RESET}  $*" >&2
}

log_err() {
    printf '%s\n' "${C_RED}[ERR]${C_RESET}  $*" >&2
}

# Étape majeure : séparateur visible pour les phases du pipeline.
log_step() {
    if [ "$NEXUS_QUIET" -eq 1 ]; then
        return 0
    fi
    printf '\n%s\n' "${C_BOLD}${C_MAGENTA}>>> $*${C_RESET}"
}

# Sortie d'échec immédiat avec message + code de retour documenté.
die() {
    local msg="$1"
    local code="${2:-1}"
    log_err "$msg"
    log_err "code de retour: $code (voir section CODES DE RETOUR, --help)"
    exit "$code"
}

# Ligne de séparation visuelle pour les rapports.
hr() {
    if [ "$NEXUS_QUIET" -eq 1 ]; then
        return 0
    fi
    printf '%s\n' "${C_DIM}------------------------------------------------------------${C_RESET}"
}

banner() {
    if [ "$NEXUS_QUIET" -eq 1 ]; then
        return 0
    fi
    printf '%s\n' "${C_BOLD}${C_CYAN}"
    printf '%s\n' '  == NEXUS CI GENERATOR v2.0.0 =='
    printf '%s\n' '  Pipelines GitHub Actions prets pour la production'
    printf '%s\n' "${C_RESET}"
}

# ============================================================================
# SECTION 4 — FICHIERS TEMPORAIRES ET NETTOYAGE
# ============================================================================
# Tout fichier temporaire passe par le registre NEXUS_TMPFILES : le trap
# EXIT garantit qu'aucun .nexus-tmp ne survit à une interruption (Ctrl-C,
# erreur set -e, fin normale). Double sécurité : cleanup est idempotent.
NEXUS_TMPFILES=()
NEXUS_TMPDIRS=()

nexus_tmp_new() {
    local t
    t="$(mktemp "${1:-/tmp}/.nexus-tmp.XXXXXX")"
    NEXUS_TMPFILES+=("$t")
    printf '%s' "$t"
}

nexus_tmpdir_new() {
    local d
    d="$(mktemp -d "${1:-/tmp}/nexus-dir.XXXXXX")"
    NEXUS_TMPDIRS+=("$d")
    printf '%s' "$d"
}

cleanup() {
    local f d
    for f in "${NEXUS_TMPFILES[@]}"; do
        if [ -e "$f" ]; then
            rm -f "$f"
        fi
    done
    for d in "${NEXUS_TMPDIRS[@]}"; do
        if [ -d "$d" ]; then
            rm -rf "$d"
        fi
    done
    return 0
}
trap cleanup EXIT
trap 'exit 130' INT

# ============================================================================
# SECTION 5 — CHEMIN DU SCRIPT ET HORODATAGE
# ============================================================================
# NEXUS_SCRIPT_PATH : chemin absolu fiable, utilisé par cmd_selftest pour
# relancer le générateur comme un vrai utilisateur (sous-processus bash).
NEXUS_SCRIPT_PATH="${BASH_SOURCE[0]}"
case "$NEXUS_SCRIPT_PATH" in
    /*) ;;
    */*) NEXUS_SCRIPT_PATH="$PWD/${NEXUS_SCRIPT_PATH#./}" ;;
    *)  NEXUS_SCRIPT_PATH="$PWD/$NEXUS_SCRIPT_PATH" ;;
esac

# Horodatage UTC injecté dans l'en-tête de chaque workflow généré.
NEXUS_GEN_DATE="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

# Raccourci pratique pour les rapports : date humaine.
nexus_date_human() {
    date -u +%Y-%m-%d
}
