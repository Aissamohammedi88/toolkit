
# ============================================================================
# SECTION 23 — EXPLAIN : DOCUMENTATION OPÉRATIONNELLE PAR TYPE
# ============================================================================
# explain_type : documente ce que le workflow fait DANS VOTRE DÉPÔT, avec
# les informations qu'on oublie toujours : secrets, permissions, durée
# estimée, artefacts produits, et comment l'adapter. Contenu = ce que le
# YAML généré contient réellement, rien d'inventé.
explain_type() {
    case "$1" in
        aegis)         explain_aegis ;;
        java)          explain_java ;;
        python)        explain_python ;;
        node)          explain_node ;;
        docker)        explain_docker ;;
        go)            explain_go ;;
        rust)          explain_rust ;;
        release)       explain_release ;;
        nightly)       explain_nightly ;;
        php)           explain_php ;;
        dotnet)        explain_dotnet ;;
        cpp)           explain_cpp ;;
        android)       explain_android ;;
        *) die "type inconnu pour explain: $1" "$EXIT_USAGE" ;;
    esac
}

explain_aegis() {
    cat <<'NEXUS_EXPLAIN'
TYPE: aegis — pipeline sécurité & qualité Next.js
FICHIER GÉNÉRÉ: .github/workflows/nexus-aegis.yml

DÉCLENCHEURS:
  - push et pull_request sur la branche configurée (défaut: main)
  - workflow_dispatch (déclenchement manuel depuis l'onglet Actions)

JOBS (9), DANS L'ORDRE DE COMPRÉHENSION:
  1. changes    - détecte si des fichiers sources ont bougé (paths-filter).
                  Sinon, lint/typecheck/test/build sautent : pas de CI
                  inutile pour un commit de documentation.
  2. secrets   - gitleaks, historique complet, TOUJOURS actif.
  3. lint      - npx eslint . --max-warnings=0 (zéro tolérance).
  4. typecheck - npx tsc --noEmit (les types sont des tests gratuits).
  5. test      - npm test -- --ci --coverage, artefact coverage/ joint.
  6. build     - npm run build, artefact .next/ joint (consommé par slsa).
  7. codeql    - analyse statique, queries security-extended, SARIF.
  8. trivy     - scan CVE filesystem, exit 1 sur HIGH/CRITICAL, SARIF.
  9. slsa      - attestation de provenance du build (supply chain).

SECRETS REQUIS: AUCUN. GITHUB_TOKEN automatique suffit.
PERMISSIONS: contents:read global; security-events:write (codeql/trivy);
             id-token+attestations:write (slsa) — au niveau des jobs
             concernés uniquement, pas global (principe du moindre privilège).

ARTEFACTS: nexus-coverage (7j), nexus-build (7j), attestation SLSA.
DURÉE ESTIMÉE: 6-10 min au premier run (pas de cache), 3-5 min ensuite.

ADAPTATION FRÉQUENTE:
  - le job test lance 'npm test' : si votre script de tests s'appelle
    autrement, adaptez la step dans package.json ou le YAML.

BUG DU SKELETON CORRIGÉ (PROTON ④):
  le skeleton exécutait 'actions/setup-node@v4' comme commande shell
  (run:) — illégal. Le générateur l'écrit correctement (uses:) et le
  selftest vérifie le pattern interdit par grep.
NEXUS_EXPLAIN
}

explain_java() {
    cat <<'NEXUS_EXPLAIN'
TYPE: java — pipeline Maven multi-JDK
FICHIER GÉNÉRÉ: .github/workflows/nexus-java.yml

DÉCLENCHEURS: push + pull_request sur la branche, workflow_dispatch.

JOBS (3):
  1. build  - matrice JDK [17, <votre --java>] avec cache Maven.
              Étapes: vérification pom.xml, compile sans tests (fail
              fast), mvn verify (tests inclus), upload des JAR.
              fail-fast=false : les deux JDK rapportent chacun leur
              verdict (le 17 ne masque pas le 21).
  2. owasp  - org.owasp:dependency-check-maven:check sur la branche
              principale uniquement (job lourd : base NVD à télécharger).
              Rapport HTML joint en artefact même en cas d'échec (always).
  3. codeql - analyse statique java-kotlin.

EXIGE: pom.xml à la racine. Sans lui le job build échoue avec un
       message explicite (step de vérification dédiée).

SECRETS REQUIS: aucun.
ARTEFACTS: nexus-java-jdk17 / nexus-java-jdk<java> (JAR, 7j),
           nexus-owasp-report (14j).
DURÉE ESTIMÉE: build 4-8 min ; owasp 10-20 min au premier run
               (téléchargement NVD), 2-4 min ensuite.

NOTE CVE: dependency-check échoue si une CVE CVSS >= 7 est trouvée
          (seuil par défaut du plugin) ; le seuil se règle dans pom.xml
          via la propriété failBuildOnCVSS.
NEXUS_EXPLAIN
}

explain_python() {
    cat <<'NEXUS_EXPLAIN'
TYPE: python — pipeline qualité & sécurité
FICHIER GÉNÉRÉ: .github/workflows/nexus-python.yml

DÉCLENCHEURS: push + pull_request sur la branche, workflow_dispatch.

JOBS (3):
  1. quality - matrice [votre --python, 3.10, 3.11, 3.13] :
               ruff check (lint bloquant), ruff format --check,
               pytest --cov (rapport XML joint), mypy (tolérant par
               défaut : --ignore-missing-imports).
  2. audit   - pip-audit --strict sur l'environnement résolu :
               chaque dépendance installée, transitives comprises.
  3. codeql  - analyse statique python.

EXIGE: rien à la racine, MAIS le job quality installe
      requirements.txt et requirements-dev.txt s'ils existent, puis
      les outils de qualité. Sans requirements.txt, ruff/pytest/mypy
      sont installés seuls — le pipeline reste vert sur un dépôt
      contenant déjà un setup.py/pyproject autonome.

SECRETS REQUIS: aucun.
ARTEFACTS: nexus-coverage-py<version> (coverage.xml, 7j).
DURÉE ESTIMÉE: quality 3-6 min par interpréteur (matrice parallèle),
               audit 1-3 min.

DURCIR MYPY (recommandé au fil du temps):
  retirer --ignore-missing-imports et ajouter un pyproject.toml avec
  [tool.mypy] strict = true. Le pipeline échouera plus souvent, et
  c'est le but : les types attrapent les bugs avant les utilisateurs.
NEXUS_EXPLAIN
}

explain_node() {
    cat <<'NEXUS_EXPLAIN'
TYPE: node — pipeline npm multi-runtime
FICHIER GÉNÉRÉ: .github/workflows/nexus-node.yml

DÉCLENCHEURS: push + pull_request sur la branche, workflow_dispatch.

JOBS (2):
  1. build - matrice Node [votre --node, 20, 22] avec cache npm :
             npm ci (strict : exige package-lock.json, échec explicite
             sinon), lint/test/build avec --if-present (aucun script
             imposé), artefacts dist/ build/ .next/ joints.
  2. audit - npm audit --audit-level=high, bloquant.

EXIGE: package.json + package-lock.json. npm ci est strict À DESEIN :
       un build sans lockfile n'est pas reproductible, et un build non
       reproductible n'est pas un build, c'est une prière.

SECRETS REQUIS: aucun.
ARTEFACTS: nexus-node-<runtime> (7j).
DURÉE ESTIMÉE: 3-5 min par runtime au premier run, 2-3 ensuite.

POURQUOI --if-present:
  le générateur ne sait pas si votre projet a un script 'lint'. Plutôt
  que d'imposer une convention et de casser les dépôts qui ne la
  suivent pas, les steps optionnelles utilisent --if-present et vous
  gardez le contrôle dans package.json.
NEXUS_EXPLAIN
}
