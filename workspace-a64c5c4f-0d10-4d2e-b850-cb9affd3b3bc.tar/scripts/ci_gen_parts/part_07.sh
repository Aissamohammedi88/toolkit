
# ============================================================================
# SECTION 19 — TEMPLATE go (lint + tests race + goreleaser)
# ============================================================================
# Pipeline Go : golangci-lint (le standard de facto), tests avec détection
# de race conditions (-race), coverage atomique, goreleaser sur tag.
inject_go() {
    cat <<'NEXUS_YAML'
# =============================================================================
# NEXUS GO — pipeline qualité et release
# Généré par NEXUS CI GENERATOR v__GENVER__ le __DATE__ (type: go)
# Fichier: __WORKFLOW_FILE__ | Branche: __BRANCH__ | Go: __GO__
# -----------------------------------------------------------------------------
# Chaîne de contrôle :
#   1. quality : golangci-lint, vet, tests -race + coverage, build
#   2. release : goreleaser UNIQUEMENT sur tag v* (sinon skip)
# Exige : go.mod à la racine du dépôt.
# Secrets requis : aucun (GITHUB_TOKEN suffit pour goreleaser).
# =============================================================================
name: 'NEXUS GO (qualite & release)'
on:
  push:
    branches: [__BRANCH__]
    tags: ['v*']
  pull_request:
    branches: [__BRANCH__]
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: 'nexus-go-${{ github.ref }}'
  cancel-in-progress: true

jobs:
  # -------------------------------------------------------------------
  # JOB 1/2 : quality — lint ET tests dans le même job : le runner est
  #   déjà payé, on évite de le gaspiller en deux jobs parallèles.
  # -------------------------------------------------------------------
  quality:
    name: 'Qualite (go __GO__)'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup Go (cache modules)'
        uses: actions/setup-go@v5
        with:
          go-version: '__GO__'
          cache: true
      - name: 'Vérifier la structure du projet'
        run: |
          test -f go.mod || {
            echo "ERREUR: go.mod manquant a la racine du dépôt"
            exit 1
          }
      - name: 'Golangci-lint'
        uses: golangci/golangci-lint-action@v6
        with:
          version: latest
      - name: 'Vet (analyse statique standard)'
        run: go vet ./...
      - name: 'Tests avec détection de race conditions'
        run: go test -race -covermode=atomic -coverprofile=coverage.out ./...
      - name: 'Build'
        run: go build ./...
      - name: 'Uploader le profil de coverage'
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: nexus-go-coverage
          path: coverage.out
          retention-days: 7
          if-no-files-found: ignore

  # -------------------------------------------------------------------
  # JOB 2/2 : release — goreleaser. if: startsWith(github.ref, 'refs/tags/')
  #   = le job apparaît skipped sur les push normaux, et tourne SEULEMENT
  #   sur tag. C'est le pattern officiel goreleaser.
  # -------------------------------------------------------------------
  release:
    name: 'Goreleaser (sur tag v*)'
    needs: quality
    if: startsWith(github.ref, 'refs/tags/')
    runs-on: ubuntu-latest
    permissions:
      contents: write
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - name: 'Setup Go (cache modules)'
        uses: actions/setup-go@v5
        with:
          go-version: '__GO__'
          cache: true
      - name: 'Goreleaser release'
        uses: goreleaser/goreleaser-action@v6
        with:
          version: latest
          args: release --clean
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}

NEXUS_YAML
}

# ============================================================================
# SECTION 20 — TEMPLATE rust (fmt + clippy + test + audit)
# ============================================================================
# Pipeline Rust : fmt sur nightly (le composant rustfmt), clippy
# -D warnings (zéro tolérance), tests toutes features, cargo-audit.
inject_rust() {
    cat <<'NEXUS_YAML'
# =============================================================================
# NEXUS RUST — pipeline qualité et sécurité
# Généré par NEXUS CI GENERATOR v__GENVER__ le __DATE__ (type: rust)
# Fichier: __WORKFLOW_FILE__ | Branche: __BRANCH__ | Toolchain: stable
# -----------------------------------------------------------------------------
# Chaîne de contrôle :
#   1. fmt     : cargo fmt --check (sur nightly, où vit rustfmt)
#   2. quality : clippy -D warnings, tests --all-features, audit
#   3. release : build --release + artefact, UNIQUEMENT sur tag v*
# Exige : Cargo.toml à la racine du dépôt.
# Secrets requis : aucun.
# =============================================================================
name: 'NEXUS RUST (qualite & securite)'
on:
  push:
    branches: [__BRANCH__]
    tags: ['v*']
  pull_request:
    branches: [__BRANCH__]
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: 'nexus-rust-${{ github.ref }}'
  cancel-in-progress: true

jobs:
  # -------------------------------------------------------------------
  # JOB 1/3 : fmt — format séparé du build : le composant rustfmt vit
  #   sur nightly, le build vit sur stable. Deux jobs = zéro compromis.
  # -------------------------------------------------------------------
  fmt:
    name: 'cargo fmt --check'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Toolchain nightly (rustfmt)'
        uses: dtolnay/rust-toolchain@nightly
        with:
          components: rustfmt
      - name: 'Vérifier le formatage'
        run: cargo fmt --all --check

  # -------------------------------------------------------------------
  # JOB 2/3 : quality — clippy avec -D warnings : tout warning EST une
  #   erreur. Le compilateur sait des choses que vous ne savez pas encore.
  # -------------------------------------------------------------------
  quality:
    name: 'clippy + tests + audit'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Toolchain stable'
        uses: dtolnay/rust-toolchain@stable
      - name: 'Cache cargo (Sarshal cache-action)'
        uses: Swatinem/rust-cache@v2
      - name: 'Clippy (zero warning toléré)'
        run: cargo clippy --all-targets -- -D warnings
      - name: 'Tests (toutes features)'
        run: cargo test --all-features
      - name: 'cargo-audit (CVE des crates)'
        uses: rustsec/audit-check@v2
        with:
          token: ${{ secrets.GITHUB_TOKEN }}

  # -------------------------------------------------------------------
  # JOB 3/3 : release — build --release sur tag uniquement. L'artefact
  #   binaire est join à la release GitHub (draft), jamais direct en
  #   prod sans revue humaine.
  # -------------------------------------------------------------------
  release:
    name: 'Build release (sur tag v*)'
    needs: [fmt, quality]
    if: startsWith(github.ref, 'refs/tags/')
    runs-on: ubuntu-latest
    permissions:
      contents: write
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Toolchain stable'
        uses: dtolnay/rust-toolchain@stable
      - name: 'Cache cargo'
        uses: Swatinem/rust-cache@v2
      - name: 'Build release'
        run: cargo build --release
      - name: 'Uploader le binaire'
        uses: actions/upload-artifact@v4
        with:
          name: nexus-rust-release
          path: target/release/
          retention-days: 14
          if-no-files-found: error

NEXUS_YAML
}
