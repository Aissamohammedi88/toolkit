
# ============================================================================
# SECTION 22b — TEMPLATE php (composer + phpunit + audit)
# ============================================================================
# Pipeline PHP moderne : setup-php officiel, matrice 8.2-8.4, code style
# via php-cs-fixer, phpunit bloquant si phpunit.xml existe, composer audit.
inject_php() {
    cat <<'NEXUS_YAML'
# =============================================================================
# NEXUS PHP — pipeline composer & qualité
# Généré par NEXUS CI GENERATOR v__GENVER__ le __DATE__ (type: php)
# Fichier: __WORKFLOW_FILE__ | Branche: __BRANCH__ | PHP: __PHP__
# -----------------------------------------------------------------------------
# Chaîne de contrôle :
#   1. quality : matrice PHP __PHP_MATRIX__ — install, style, tests
#   2. audit   : composer audit (CVE des dépendances packagist)
# Exige : composer.json à la racine.
# Secrets requis : aucun.
# =============================================================================
name: 'NEXUS PHP (composer & qualite)'
on:
  push:
    branches: [__BRANCH__]
  pull_request:
    branches: [__BRANCH__]
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: 'nexus-php-${{ github.ref }}'
  cancel-in-progress: true

jobs:
  # -------------------------------------------------------------------
  # JOB 1/2 : quality — la matrice prouve la compatibilité des versions
  #   PHP supportées actives. php-cs-fixer en --dry-run : il ne réécrit
  #   JAMAIS le code en CI, il constate. Si le style est cassé, c'est au
  #   développeur de corriger, pas à la machine de maquiller.
  # -------------------------------------------------------------------
  quality:
    name: 'Qualite (PHP ${{ matrix.php }})'
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix:
        php: __PHP_MATRIX__
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup PHP ${{ matrix.php }} (extensions: intl, mbstring)'
        uses: shivammathur/setup-php@v2
        with:
          php-version: '${{ matrix.php }}'
          extensions: intl, mbstring, xml
          tools: php-cs-fixer
          coverage: none
      - name: 'Vérifier la structure du projet'
        run: |
          test -f composer.json || {
            echo "ERREUR: composer.json manquant a la racine"
            exit 1
          }
          composer validate --strict
      - name: 'Installer les dépendances (lockfile requis)'
        run: composer install --prefer-dist --no-progress
      - name: 'Style de code (php-cs-fixer --dry-run)'
        run: |
          if [ -f .php-cs-fixer.dist.php ] || [ -f .php-cs-fixer.php ]; then
            PHP_CS_FIXER_IGNORE_ENV=1 php-cs-fixer fix --dry-run --diff
          else
            echo "pas de config php-cs-fixer détectée — style non vérifié"
          fi
      - name: 'Tests (phpunit, bloquant si config présente)'
        run: |
          if [ -f phpunit.xml ] || [ -f phpunit.xml.dist ]; then
            vendor/bin/phpunit --configuration phpunit.xml
          else
            echo "ERREUR: phpunit.xml absent — un projet PHP sans tests"
            echo "n'est pas un projet, c'est un prototype. Ajoutez phpunit."
            exit 1
          fi

  # -------------------------------------------------------------------
  # JOB 2/2 : audit — composer audit scanne les dépendances déclarées
  #   dans composer.lock contre l'advisory database Packagist.
  # -------------------------------------------------------------------
  audit:
    name: 'Composer audit (CVE dépendances)'
    needs: quality
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup PHP'
        uses: shivammathur/setup-php@v2
        with:
          php-version: '__PHP__'
          coverage: none
      - name: 'Audit des dépendances'
        run: |
          test -f composer.lock || {
            echo "ERREUR: composer.lock absent — commitez le lockfile"
            exit 1
          }
          composer audit

NEXUS_YAML
}

# ============================================================================
# SECTION 22c — TEMPLATE dotnet (restore/build/test/pack)
# ============================================================================
# Pipeline .NET : matrice SDK, restore explicite (cache NuGet), build et
# test --no-restore (le restore est déjà fait), pack sur la branche main.
inject_dotnet() {
    cat <<'NEXUS_YAML'
# =============================================================================
# NEXUS DOTNET — pipeline build/test/pack
# Généré par NEXUS CI GENERATOR v__GENVER__ le __DATE__ (type: dotnet)
# Fichier: __WORKFLOW_FILE__ | Branche: __BRANCH__ | SDK: __DOTNET__
# -----------------------------------------------------------------------------
# Chaîne de contrôle :
#   1. build  : matrice SDK [8.0, __DOTNET__] — restore, build, test
#   2. pack   : dotnet pack sur la branche principale, artefact .nupkg
#   3. codeql : analyse statique csharp
# Exige : un .sln ou .csproj détectable par dotnet CLI.
# Secrets requis : aucun.
# =============================================================================
name: 'NEXUS DOTNET (build/test/pack)'
on:
  push:
    branches: [__BRANCH__]
  pull_request:
    branches: [__BRANCH__]
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: 'nexus-dotnet-${{ github.ref }}'
  cancel-in-progress: true

jobs:
  # -------------------------------------------------------------------
  # JOB 1/3 : build — chaque step --no-restore : le restore est fait
  #   UNE fois, explicitement, avec cache. Repeter le restore par step
  #   est le pattern qui rend les pipelines .NET lents et flous.
  # -------------------------------------------------------------------
  build:
    name: 'Build & Test (SDK ${{ matrix.dotnet }})'
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix:
        dotnet: ['8.0.x', '__DOTNET__']
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup .NET SDK ${{ matrix.dotnet }} (cache nuget)'
        uses: actions/setup-dotnet@v4
        with:
          dotnet-version: '${{ matrix.dotnet }}'
          cache: true
          cache-dependency-path: '**/packages.lock.json'
      - name: 'Vérifier la structure du projet'
        run: |
          ls *.sln */*.csproj *.csproj 2>/dev/null | head -n 1 | grep -q . || {
            echo "ERREUR: aucun .sln/.csproj détecté a la racine"
            exit 1
          }
      - name: 'Restore (explicite, une seule fois)'
        run: dotnet restore
      - name: 'Build (release, sans re-restore)'
        run: dotnet build --no-restore --configuration Release
      - name: 'Tests (sans re-restore, coverage XPlat)'
        run: dotnet test --no-restore --collect:"XPlat Code Coverage"

  # -------------------------------------------------------------------
  # JOB 2/3 : pack — nuget packé UNIQUEMENT sur la branche principale :
  #   les PR ne produisent pas de paquet, elles produisent du code relu.
  # -------------------------------------------------------------------
  pack:
    name: 'Pack (nuget)'
    needs: build
    if: github.ref == 'refs/heads/__BRANCH__'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup .NET SDK (cache nuget)'
        uses: actions/setup-dotnet@v4
        with:
          dotnet-version: '__DOTNET__'
          cache: true
          cache-dependency-path: '**/packages.lock.json'
      - name: 'Restore + Pack'
        run: |
          dotnet restore
          dotnet pack --configuration Release --output ./artifacts
      - name: 'Uploader les .nupkg'
        uses: actions/upload-artifact@v4
        with:
          name: nexus-dotnet-nupkg
          path: artifacts/*.nupkg
          retention-days: 7
          if-no-files-found: error

  # -------------------------------------------------------------------
  # JOB 3/3 : codeql — analyse statique de sécurité C#.
  # -------------------------------------------------------------------
  codeql:
    name: 'CodeQL (securite statique)'
    needs: build
    runs-on: ubuntu-latest
    permissions:
      contents: read
      security-events: write
    strategy:
      matrix:
        language: [csharp]
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup .NET SDK'
        uses: actions/setup-dotnet@v4
        with:
          dotnet-version: '__DOTNET__'
      - name: 'Initialisation CodeQL'
        uses: github/codeql-action/init@v3
        with:
          languages: ${{ matrix.language }}
      - name: 'Autobuild'
        uses: github/codeql-action/autobuild@v3
      - name: 'Analyse CodeQL'
        uses: github/codeql-action/analyze@v3
        with:
          category: '/language:${{ matrix.language }}'

NEXUS_YAML
}

# ============================================================================
# SECTION 22d — TEMPLATE cpp (cmake multi-compilateur + sanitizers)
# ============================================================================
# Pipeline C/C++ : matrice gcc/clang, build Release via CMake, ctest,
# job sanitizers séparé (AddressSanitizer + UndefinedBehaviorSanitizer),
# analyse statique cppcheck.
inject_cpp() {
    cat <<'NEXUS_YAML'
# =============================================================================
# NEXUS CPP — pipeline cmake & sanitizers
# Généré par NEXUS CI GENERATOR v__GENVER__ le __DATE__ (type: cpp)
# Fichier: __WORKFLOW_FILE__ | Branche: __BRANCH__
# -----------------------------------------------------------------------------
# Chaîne de contrôle :
#   1. build     : matrice [gcc, clang] — cmake configure, build, ctest
#   2. sanitize  : ASan + UBSan (les bugs mémoire reproduits en CI)
#   3. analyse   : cppcheck (warning+style bloquants)
# Exige : CMakeLists.txt à la racine + CTest enregistré.
# Secrets requis : aucun.
# =============================================================================
name: 'NEXUS CPP (cmake & sanitizers)'
on:
  push:
    branches: [__BRANCH__]
  pull_request:
    branches: [__BRANCH__]
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: 'nexus-cpp-${{ github.ref }}'
  cancel-in-progress: true

jobs:
  # -------------------------------------------------------------------
  # JOB 1/3 : build — la matrice gcc/clang n'est pas du luxe : un code
  #   qui ne passe que sous gcc cache des UB que clang attrape (et
  #   réciproquement). Les deux verdicts, indépendants (fail-fast off).
  # -------------------------------------------------------------------
  build:
    name: 'Build & Test (${{ matrix.compiler }})'
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix:
        compiler: [gcc, clang]
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Vérifier la structure du projet'
        run: |
          test -f CMakeLists.txt || {
            echo "ERREUR: CMakeLists.txt manquant a la racine"
            exit 1
          }
      - name: 'Configurer (cmake, Release, Werror — warnings bloquants)'
        run: |
          mkdir -p build && cd build
          if [ "${{ matrix.compiler }}" = "gcc" ]; then
            CC=gcc CXX=g++ cmake -DCMAKE_BUILD_TYPE=Release \
              -DCMAKE_C_FLAGS="-Werror" -DCMAKE_CXX_FLAGS="-Werror" ..
          else
            CC=clang CXX=clang++ cmake -DCMAKE_BUILD_TYPE=Release \
              -DCMAKE_C_FLAGS="-Werror" -DCMAKE_CXX_FLAGS="-Werror" ..
          fi
      - name: 'Compiler (parallel)'
        run: cmake --build build --parallel "$(nproc)"
      - name: 'Tests (ctest, échec détaillé)'
        run: ctest --test-dir build --output-on-failure

  # -------------------------------------------------------------------
  # JOB 2/3 : sanitize — ASan et UBSan dans le même build : le coût
  #   d'un job séparé par sanitizer dépasse le bénéfice pour 95% des
  #   projets. ctest rejoué sous sanitizers = les bugs mémoire qui ne
  #   se voient QUE sous instrumentation.
  # -------------------------------------------------------------------
  sanitize:
    name: 'Sanitizers (ASan + UBSan)'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Configurer avec sanitizers'
        run: |
          mkdir -p build-san && cd build-san
          cmake -DCMAKE_BUILD_TYPE=Debug \
            -DCMAKE_C_FLAGS="-fsanitize=address,undefined -fno-omit-frame-pointer" \
            -DCMAKE_CXX_FLAGS="-fsanitize=address,undefined -fno-omit-frame-pointer" ..
      - name: 'Compiler (sanitize)'
        run: cmake --build build-san --parallel "$(nproc)"
      - name: 'Tests sous sanitizers'
        run: ctest --test-dir build-san --output-on-failure

  # -------------------------------------------------------------------
  # JOB 3/3 : analyse — cppcheck indépendant de la compilation : il
  #   voit des patterns que le compilateur accepte silencieusement.
  # -------------------------------------------------------------------
  analyse:
    name: 'Cppcheck (statique)'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Installer cppcheck'
        run: sudo apt-get update -qq && sudo apt-get install -y -qq cppcheck
      - name: 'Analyse statique (warning + style bloquants)'
        run: |
          cppcheck --enable=warning,style --inconclusive \
            --error-exitcode=1 --suppress=missingIncludeSystem \
            --inline-suppr -I . .

NEXUS_YAML
}

# ============================================================================
# SECTION 22e — TEMPLATE android (gradle + lint + tests + APK)
# ============================================================================
# Pipeline Android : wrapper gradlew exécutable (jamais un gradle système
# — la version du wrapper EST la version du projet), lint + tests unitaires
# + assembleDebug, APK joint en artefact, release unsigned sur tag.
inject_android() {
    cat <<'NEXUS_YAML'
# =============================================================================
# NEXUS ANDROID — pipeline gradle & APK
# Généré par NEXUS CI GENERATOR v__GENVER__ le __DATE__ (type: android)
# Fichier: __WORKFLOW_FILE__ | Branche: __BRANCH__
# -----------------------------------------------------------------------------
# Chaîne de contrôle :
#   1. quality : gradlew lint + testDebugUnitTest + assembleDebug
#   2. release : assembleRelease (unsigned) sur tag v* uniquement
# Exige : gradlew à la racine + JDK 17 (imposé par AGP moderne).
# Secrets requis : aucun — la release produite est UNSIGNED : la signature
# est un acte humain (keystore), jamais un job automatisé.
# =============================================================================
name: 'NEXUS ANDROID (gradle & apk)'
on:
  push:
    branches: [__BRANCH__]
    tags: ['v*']
  pull_request:
    branches: [__BRANCH__]
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: 'nexus-android-${{ github.ref }}'
  cancel-in-progress: true

jobs:
  # -------------------------------------------------------------------
  # JOB 1/2 : quality — ./gradlew EXÉCUTABLE requis : un wrapper non
  #   exécutable committé est une erreur de dépôt, le job le prouve
  #   avec un message explicite plutôt qu'un Permission denied obscur.
  # -------------------------------------------------------------------
  quality:
    name: 'Lint + Tests + Debug APK'
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Vérifier le wrapper gradle'
        run: |
          test -f gradlew || {
            echo "ERREUR: gradlew manquant a la racine"
            exit 1
          }
          test -x gradlew || {
            echo "ERREUR: gradlew n'est pas exécutable (chmod +x gradlew)"
            exit 1
          }
      - name: 'Setup JDK 17 (imposé par AGP)'
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17
      - name: 'Setup gradle (cache build)'
        uses: gradle/actions/setup-gradle@v4
      - name: 'Lint'
        run: ./gradlew lint --no-daemon
      - name: 'Tests unitaires'
        run: ./gradlew testDebugUnitTest --no-daemon
      - name: 'Assemble debug APK'
        run: ./gradlew assembleDebug --no-daemon
      - name: 'Uploader l APK debug'
        uses: actions/upload-artifact@v4
        with:
          name: nexus-android-debug
          path: app/build/outputs/apk/debug/*.apk
          retention-days: 7
          if-no-files-found: warn

  # -------------------------------------------------------------------
  # JOB 2/2 : release — assembleRelease sur tag. UNSIGNED par principe :
  #   la signature avec un keystore en secret de CI transforme le
  #   keystore en single point of failure. Le keystore reste sur la
  #   machine d'un humain responsable, ou dans un dédié signing job
  #   avec HSM — pas dans un secret GitHub.
  # -------------------------------------------------------------------
  release:
    name: 'Release APK (unsigned, sur tag v*)'
    needs: quality
    if: startsWith(github.ref, 'refs/tags/')
    runs-on: ubuntu-latest
    steps:
      - name: 'Checkout'
        uses: actions/checkout@v4
      - name: 'Setup JDK 17'
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17
      - name: 'Setup gradle (cache build)'
        uses: gradle/actions/setup-gradle@v4
      - name: 'Assemble release (unsigned)'
        run: ./gradlew assembleRelease --no-daemon
      - name: 'Uploader l APK release'
        uses: actions/upload-artifact@v4
        with:
          name: nexus-android-release-unsigned
          path: app/build/outputs/apk/release/*.apk
          retention-days: 14
          if-no-files-found: error

NEXUS_YAML
}
