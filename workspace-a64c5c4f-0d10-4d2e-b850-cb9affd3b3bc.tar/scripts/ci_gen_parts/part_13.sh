
# ============================================================================
# SECTION 30 — COMMANDE manual (manuel intégré)
# ============================================================================
cmd_manual() {
    cat <<'NEXUS_MANUAL'
NEXUS CI GENERATOR — MANUEL INTÉGRÉ (v2.0.0)
==============================================================================

NOM
    nexus-ci-generator — générateur de pipelines GitHub Actions prêts
    pour la production.

SYNOPSIS
    nexus-ci-generator.sh <commande> [options]
    nexus-ci-generator.sh <type>     [options]

DESCRIPTION
    Génère des workflows GitHub Actions dans .github/workflows/. Le
    générateur applique quatre contrats non négociables :

    1. VALIDATION AVANT INSTALLATION
       Chaque YAML produit est parsé (PyYAML) et vérifié
       structurellement (déclencheur 'on', jobs non vides, runs-on
       par job) AVANT d'être écrit dans le dépôt. Un YAML cassé
       n'est jamais installé.

    2. ÉCRITURE ATOMIQUE
       Le contenu part dans un fichier temporaire du MÊME répertoire,
       puis mv. Une interruption (Ctrl-C, kill) ne laisse jamais de
       fichier à moitié écrit : le trap EXIT supprime les tmp.

    3. PROTECTION DU TRAVAIL AUTRUI
       uninstall refuse de supprimer tout fichier qui ne porte pas
       le marqueur "Genere par NEXUS CI GENERATOR". Vos workflows
       écrits à la main sont intouchables.

    4. ANTI-REGRESSION
       Le validateur rejette le pattern 'run: actions/...' — le bug
       du skeleton v1 (action invoquée comme commande shell) ne peut
       plus JAMAIS revenir : le selftest le vérifie par grep.

ARCHITECTURE INTERNE
    Le script est organisé en sections numérotées :
      1-5    garde-fous, couleurs, journalisation, temporaires
      6-8    registre des types, usage, utilitaires
      9-13   options, validateurs d'entrées, check_env, validateur
             YAML, substitution placeholders, écriture atomique
      14-22e les 13 templates inject_<type> (heredocs quotés)
      23     explain : documentation par type
      24-28  commandes list/explain/validate/doctor/uninstall
      29     selftest (banc d'essai PROTON, 18 tests)
      30     ce manuel
      31     changelog
      32     main (dispatch)

COMMANDES
    <type>     raccourci: génère ce type (voir TYPES ci-dessous)
    list       liste les types avec description et fichier cible
    explain    documentation opérationnelle d'un type: jobs, secrets,
               permissions, artefacts, durée estimée, adaptation
    validate   valide un fichier YAML (syntaxe + structure Actions)
    doctor     diagnostic de l'environnement (verdict par vérification)
    uninstall  supprime un workflow généré (marqueur requis)
    selftest   banc d'essai complet: 18 tests, positives et négatives
    manual     ce manuel
    changelog  historique des versions

TYPES
    aegis    Next.js: paths-filter, gitleaks, eslint --max-warnings=0,
             tsc --noEmit, tests+coverage, next build, CodeQL, Trivy,
             SLSA attest-build-provenance. (skeleton corrigé)
    java     Maven: matrice JDK [17,<--java>], cache maven, verify,
             OWASP dependency-check, CodeQL java-kotlin.
    python   ruff check + format --check, pytest --cov, mypy,
             pip-audit --strict, matrice 3.10-3.13, CodeQL python.
    node     npm ci strict (lockfile exigé), lint/test/build --if-present,
             matrice Node [20,22,<--node>], npm audit bloquant HIGH.
    docker   hadolint, buildx multi-arch amd64+arm64, metadata-action,
             Trivy sur l'image, SBOM SPDX, push ghcr hors PR.
    go       golangci-lint, go vet, tests -race + coverage, goreleaser
             sur tag v*.
    rust     fmt nightly, clippy -D warnings, test --all-features,
             cargo-audit, build --release sur tag.
    release  tag v*: build auto-détecté (build.sh/Makefile/npm/cargo/go),
             changelog par PR merged, gh-release + notes natives.
    nightly  cron: gitleaks full-history, CodeQL périodique, Trivy
             complet, audits npm/pip/cargo par écosystème détecté.
    php      composer validate --strict, install lockfile, php-cs-fixer
             --dry-run --diff, phpunit BLOQUANT, composer audit,
             matrice PHP [8.2, 8.3, <--php>].
    dotnet   matrice SDK [8.0.x, <--dotnet>], restore-once puis build et
             test --no-restore, pack NuGet sur main, CodeQL csharp.
    cpp      cmake Release -Werror sur [gcc, clang], ctest, job
             sanitize séparé (ASan+UBSan), cppcheck warning+style.
    android  gradlew vérifié (présent ET exécutable), JDK 17 temurin,
             lint, testDebugUnitTest, assembleDebug + APK joint,
             assembleRelease UNSIGNED sur tag (signature = acte humain).

OPTIONS
    --dir <chemin>       répertoire du dépôt cible (défaut: .)
    --branch <branche>   branche déclencheuse (défaut: main)
    --node <version>     Node.js (aegis, node) — défaut 22
    --java <version>     JDK (java) — défaut 21
    --python <version>   Python (python) — défaut 3.12
    --go <version>       Go (go) — défaut 1.23
    --php <version>      PHP (php) — défaut 8.3
    --dotnet <version>   .NET SDK (dotnet) — défaut 9.0
    --registry <hote>    registre (docker) — défaut ghcr.io
    --cron <expr>        cron 5 champs (nightly) — défaut 0 3 * * *
    --force              écraser un workflow existant / passer confirm
    --dry-run            afficher le YAML sans l'écrire
    --skip-validation    sauter la validation YAML (déconseillé, la
                         validation est le cœur du générateur)
    --no-color           désactiver les couleurs ANSI
    --quiet, -q          supprimer les messages d'information
    -h, --help           aide courte

CODES DE RETOUR
    0  succès
    1  erreur générique (selftest rouge, IO)
    2  usage incorrect (type inconnu, option inconnue, valeur invalide)
    3  environnement invalide (pas un dépôt git, PyYAML absent)
    4  collision de fichier (workflow existant sans --force)
    5  validation YAML échouée

ENVIRONNEMENT
    bash >= 4 (testé: 5.2), git, python3 + PyYAML, sed, mktemp.
    NO_COLOR=1 est respecté (convention no-color.org).
    TERM=dumb et stdout non-terminal désactivent aussi les couleurs.

FICHIERS
    <dépôt>/.github/workflows/nexus-aegis.yml    (type aegis)
    <dépôt>/.github/workflows/nexus-java.yml     (type java)
    <dépôt>/.github/workflows/nexus-python.yml   (type python)
    <dépôt>/.github/workflows/nexus-node.yml     (type node)
    <dépôt>/.github/workflows/nexus-docker.yml   (type docker)
    <dépôt>/.github/workflows/nexus-go.yml       (type go)
    <dépôt>/.github/workflows/nexus-rust.yml     (type rust)
    <dépôt>/.github/workflows/nexus-release.yml  (type release)
    <dépôt>/.github/workflows/nexus-nightly.yml (type nightly)
    <dépôt>/.github/workflows/nexus-php.yml      (type php)
    <dépôt>/.github/workflows/nexus-dotnet.yml   (type dotnet)
    <dépôt>/.github/workflows/nexus-cpp.yml      (type cpp)
    <dépôt>/.github/workflows/nexus-android.yml  (type android)

SÉCURITÉ
    - Les valeurs d'options sont validées par regex AVANT toute
      substitution (injection sed/YAML impossible).
    - Les heredocs de templates sont quotés (<<'NEXUS_YAML') : les
      expressions GitHub ${{ }} ne sont jamais développées par bash.
    - Les permissions Actions sont au niveau des jobs (moindre
      privilège), jamais contents:write global par défaut.
    - Aucun secret requis : tous les workflows fonctionnent avec le
      GITHUB_TOKEN automatique.

DÉPANNAGE
    "module python 'yaml' introuvable" (exit 3)
        pip install pyyaml  —  la validation YAML est le cœur du
        générateur ; --skip-validation n'est jamais la bonne réponse,
        c'est la déclaration d'un risque.

    "bash >= 4.0 requis" (exit 3)
        macOS livre bash 3.2 par défaut : brew install bash, puis
        re-exécutez avec /opt/homebrew/bin/bash.

    "collision: ... existe déjà" (exit 4)
        Comportement voulu : régénérez avec --force, ou supprimez
        d'abord avec la commande uninstall (confirmation demandée).

    "validation YAML échouée" (exit 5)
        Ne devrait JAMAIS arriver sur un fichier produit par ce
        générateur : c'est un bug à rapporter. Sur un fichier de
        votre cru passé à validate : le message contient la ligne
        et la raison exactes du rejet.

    "uninstall: REFUS: ne porte pas le marqueur"
        Le fichier a probablement été édité à la main après
        génération. Supprimez-le avec git rm vous-même : le
        générateur ne touche jamais au travail humain.

EXEMPLES AVANCÉS
    # régénérer aegis pour Node 20, en écrasant l'existant
    ./nexus-ci-generator.sh aegis --node 20 --force

    # prévisualiser le pipeline docker sans rien écrire
    ./nexus-ci-generator.sh docker --dry-run | less

    # générer nightly sur un dépôt distant, cron lundi 02:30 UTC
    ./nexus-ci-generator.sh nightly --dir ~/work/api --cron '30 2 * * 1'

    # valider un workflow écrit à la main avant de le committer
    ./nexus-ci-generator.sh validate .github/workflows/main.yml

    # diagnostic complet avant d'automatiser un nouveau poste
    ./nexus-ci-generator.sh doctor

NEXUS_MANUAL
}

# ============================================================================
# SECTION 31 — COMMANDE changelog
# ============================================================================
cmd_changelog() {
    cat <<'NEXUS_CHANGELOG'
HISTORIQUE DES VERSIONS — NEXUS CI GENERATOR
==============================================

v2.0.0 (actuelle)
    - 13 types de workflows (aegis, java, python, node, docker, go,
      rust, release, nightly, php, dotnet, cpp, android) au lieu de
      4 dans le skeleton v1.
    - CORRECTION PROTON 4 : le job setup de aegis exécutait
      'actions/setup-node@v4' comme commande shell (run:) — illégal.
      Corrigé en 'uses:' avec with: node-version + cache npm.
      Le validateur rejette désormais le pattern 'run: actions/'
      et le selftest le vérifie par grep (T5).
    - Validation YAML intégrée : syntaxe (PyYAML) + structure
      (on/jobs/runs-on) AVANT toute installation. exit 5 sinon.
    - Écriture atomique (tmp + mv) et trap EXIT de nettoyage.
    - Validation des entrées par regex : branch, versions, cron,
      registry. L'injection via sed est impossible.
    - Sous-commandes : list, explain, validate, doctor, uninstall,
      selftest, manual, changelog.
    - uninstall protégé par marqueur : refuse les fichiers non
      générés par NEXUS (travail manuel intouchable).
    - explain : documentation opérationnelle par type (jobs, secrets,
      permissions, artefacts, durées, adaptation).
    - selftest : 18 tests dont 8 négatifs (exit codes prouvés),
      y compris tentative d'injection via --node (T13), rejet des
      clés YAML dupliquées, et protection anti-suppression de
      fichiers non-NEXUS (T12).
    - Noms des fonctions du skeleton v1 conservés verbatim :
      usage, check_env, inject_aegis, inject_java, inject_python,
      inject_node, main (PROTON 5 : spec préservée).

v1.0.0 (skeleton original — DGK)
    - 4 types : aegis, java, python, node.
    - Génération en heredoc vers .github/workflows/.
    - check_env exigeant un dépôt git.
    - Défaut connu (corrigé en v2) : job setup de aegis avec
      'run: actions/setup-node@v4' — exécuté comme shell par
      GitHub Actions, workflow rouge à chaque run.
NEXUS_CHANGELOG
}

# ============================================================================
# SECTION 32 — main (dispatch général)
# ============================================================================
main() {
    if [ $# -eq 0 ]; then
        usage >&2
        exit "$EXIT_USAGE"
    fi

    local cmd="$1"
    shift

    case "$cmd" in
        -h|--help)
            usage
            exit "$EXIT_OK"
            ;;
        aegis|java|python|node|docker|go|rust|release|nightly|php|dotnet|cpp|android)
            parse_args "$@"
            handle_help_flag
            validate_generation_options "$cmd"
            banner
            generate_workflow "$cmd"
            ;;
        list)
            parse_args "$@"
            handle_help_flag
            banner
            cmd_list
            ;;
        explain)
            parse_args "$@"
            handle_help_flag
            cmd_explain
            ;;
        validate)
            parse_args "$@"
            handle_help_flag
            cmd_validate
            ;;
        doctor)
            parse_args "$@"
            handle_help_flag
            banner
            cmd_doctor
            ;;
        uninstall)
            parse_args "$@"
            handle_help_flag
            cmd_uninstall
            ;;
        selftest)
            parse_args "$@"
            handle_help_flag
            cmd_selftest
            ;;
        manual)
            parse_args "$@"
            handle_help_flag
            cmd_manual
            ;;
        changelog)
            parse_args "$@"
            handle_help_flag
            cmd_changelog
            ;;
        *)
            die "commande inconnue: $cmd (types: ${TYPES_ORDER[*]} — voir --help)" "$EXIT_USAGE"
            ;;
    esac
}

# Point d'entrée — le dispatch n'accepte JAMAIS un appel sans arguments.
main "$@"
