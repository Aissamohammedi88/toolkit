#!/usr/bin/env bash
set -u
export GENT_HOME=/tmp/gent-e2e
cd /tmp
PORT=43112 GENT_HOME=$GENT_HOME node /tmp/server-probe.js > /tmp/e2e-probe.log 2>&1 &
for i in $(seq 1 40); do curl -fsS http://127.0.0.1:43112/api/health >/dev/null 2>&1 && break; sleep 0.3; done
agent-browser open http://127.0.0.1:43112/vision >/dev/null 2>&1
sleep 3
echo "=== console navigateur ==="
agent-browser console
echo "=== erreurs ==="
agent-browser errors
echo "=== tree enfants : $(agent-browser eval 'document.getElementById("tree").children.length') ==="
agent-browser close >/dev/null 2>&1
pkill -f server-probe.js 2>/dev/null
true
