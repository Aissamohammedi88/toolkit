//! AETHER UI — Tableau de bord natif (egui, zéro navigateur, zéro Chrome).
//! Supervise le maillage : nœuds connectés, jobs, registre chaîné ;
//! soumet des jobs au routeur cognitif par tunnel chiffré.

use aether_core::{InstantaneStatut, MsgClient, RepRouteur, SpecJob};
use aether_crypto::{envoyer_sync, poignee_de_main_sync, recevoir_sync};
use eframe::egui;
use eframe::egui::{Color32, RichText};
use std::net::{SocketAddr, TcpStream};
use std::sync::mpsc::{Receiver, Sender};
use std::time::Duration;

// Palette Aether — celle du diagramme d'architecture
const FOND: Color32 = Color32::from_rgb(0x1a, 0x1a, 0x2e);
const CYAN: Color32 = Color32::from_rgb(0x00, 0xe5, 0xff);
const MAGENTA: Color32 = Color32::from_rgb(0xff, 0x00, 0xc8);
const VERT: Color32 = Color32::from_rgb(0x00, 0xff, 0x88);
const GRIS: Color32 = Color32::from_rgb(0xb0, 0xb0, 0xc0);

// ───────────────────────── Fil réseau ↔ interface ─────────────────────────

enum OrdreUI {
    Statut,
    Soumettre(SpecJob),
}

enum MsgUI {
    Statut(Box<InstantaneStatut>),
    HorsLigne(String),
    JobAccepte(u64),
    JobFini { resume: String, verifie: bool },
    Erreur(String),
}

struct AetherApp {
    tx_ordres: Sender<OrdreUI>,
    rx_messages: Receiver<MsgUI>,
    statut: Option<Box<InstantaneStatut>>,
    connecte: bool,
    erreur_reseau: Option<String>,
    journal: Vec<String>,
    style_pose: bool,
    addr_routeur: SocketAddr,
}

impl AetherApp {
    fn nouveau() -> Self {
        let (tx_ordres, rx_ordres) = std::sync::mpsc::channel::<OrdreUI>();
        let (tx_messages, rx_messages) = std::sync::mpsc::channel::<MsgUI>();
        let addr: SocketAddr = std::env::var("AETHER_CLIENTS")
            .ok()
            .and_then(|s| s.parse().ok())
            .unwrap_or_else(|| SocketAddr::from(([127, 0, 0, 1], 4100)));
        let secret = std::env::var("AETHER_SECRET")
            .unwrap_or_else(|_| "aether-dev-secret-a-changer".to_string())
            .into_bytes();
        let addr_fil = addr;
        std::thread::spawn(move || boucle_reseau(rx_ordres, tx_messages, addr_fil, secret));
        AetherApp {
            tx_ordres,
            rx_messages,
            statut: None,
            connecte: false,
            erreur_reseau: None,
            journal: vec!["interface Aether démarrée — sondage du routeur toutes les 700 ms".to_string()],
            style_pose: false,
            addr_routeur: addr,
        }
    }
}

/// Fil réseau : sonde le routeur en continu, exécute les ordres de l'interface.
fn boucle_reseau(rx: Receiver<OrdreUI>, tx: Sender<MsgUI>, addr: SocketAddr, secret: Vec<u8>) {
    loop {
        let ordre = rx.recv_timeout(Duration::from_millis(700)).unwrap_or(OrdreUI::Statut);
        let message = match interroger(&addr, &secret, &ordre) {
            Ok(RepRouteur::Statut(s)) => MsgUI::Statut(Box::new(s)),
            Ok(RepRouteur::JobAccepte { job_id: id }) => MsgUI::JobAccepte(id),
            Ok(RepRouteur::JobFini { resume, verifie, .. }) => MsgUI::JobFini { resume, verifie },
            Ok(_) => MsgUI::Erreur("réponse inattendue du routeur".to_string()),
            Err(e) => {
                if matches!(ordre, OrdreUI::Soumettre(_)) {
                    MsgUI::Erreur(format!("soumission échouée : {e}"))
                } else {
                    MsgUI::HorsLigne(e)
                }
            }
        };
        if tx.send(message).is_err() {
            return; // interface fermée
        }
    }
}

/// Une requête complète : connexion, poignée de main chiffrée, aller-retour.
fn interroger(addr: &SocketAddr, secret: &[u8], ordre: &OrdreUI) -> Result<RepRouteur, String> {
    let mut flux = TcpStream::connect_timeout(addr, Duration::from_secs(3)).map_err(|e| e.to_string())?;
    let attente = match ordre {
        OrdreUI::Soumettre(_) => Duration::from_secs(180),
        OrdreUI::Statut => Duration::from_secs(8),
    };
    flux.set_read_timeout(Some(attente)).ok();
    flux.set_write_timeout(Some(Duration::from_secs(8))).ok();
    let mut tunnel = poignee_de_main_sync(&mut flux, secret, false).map_err(|e| e.to_string())?;
    let requete = match ordre {
        OrdreUI::Statut => MsgClient::Statut,
        OrdreUI::Soumettre(spec) => MsgClient::Soumettre(spec.clone()),
    };
    envoyer_sync(&mut flux, &mut tunnel.emission, &requete).map_err(|e| e.to_string())?;
    let premiere = recevoir_sync::<RepRouteur>(&mut flux, &mut tunnel.reception).map_err(|e| e.to_string())?;
    if !matches!(ordre, OrdreUI::Soumettre(_)) {
        return Ok(premiere);
    }
    if let RepRouteur::Erreur(m) = premiere {
        return Err(m);
    }
    recevoir_sync::<RepRouteur>(&mut flux, &mut tunnel.reception).map_err(|e| e.to_string())
}

// ───────────────────────── Interface egui ─────────────────────────

impl eframe::App for AetherApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if !self.style_pose {
            ctx.style_mut(|s| {
                s.visuals = egui::Visuals::dark();
                s.visuals.panel_fill = FOND;
                s.visuals.window_fill = FOND;
                s.visuals.extreme_bg_color = Color32::from_rgb(0x10, 0x10, 0x20);
            });
            self.style_pose = true;
        }

        // consommer les messages réseau
        while let Ok(msg) = self.rx_messages.try_recv() {
            match msg {
                MsgUI::Statut(s) => {
                    self.statut = Some(s);
                    self.connecte = true;
                    self.erreur_reseau = None;
                }
                MsgUI::HorsLigne(e) => {
                    self.connecte = false;
                    self.erreur_reseau = Some(e);
                }
                MsgUI::JobAccepte(id) => {
                    self.journal.push(format!("[job {id}] accepté — calcul distribué en cours…"));
                }
                MsgUI::JobFini { resume, verifie } => {
                    let verdict = if verifie { "VÉRIFIÉ ✓" } else { "NON CONFORME ✗" };
                    self.journal.push(format!("[job] {resume} — {verdict}"));
                }
                MsgUI::Erreur(e) => self.journal.push(format!("[erreur] {e}")),
            }
        }
        if self.journal.len() > 400 {
            let coupe = self.journal.len() - 400;
            self.journal.drain(0..coupe);
        }

        egui::TopBottomPanel::top("entete").show(ctx, |ui| {
            ui.add_space(6.0);
            ui.horizontal(|ui| {
                ui.heading(RichText::new("◆ AETHER").color(CYAN).strong());
                ui.label(RichText::new("routeur cognitif — maillage P2P chiffré").color(GRIS));
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if self.connecte {
                        ui.label(RichText::new("● EN LIGNE").color(VERT).strong());
                    } else {
                        ui.label(RichText::new("● HORS LIGNE").color(MAGENTA).strong());
                    }
                });
            });
            if let Some(err) = &self.erreur_reseau {
                ui.label(
                    RichText::new(format!("routeur {} injoignable : {err}", self.addr_routeur))
                        .color(MAGENTA)
                        .small(),
                );
            }
            ui.add_space(4.0);
        });

        egui::SidePanel::left("noeuds").min_width(440.0).show(ctx, |ui| {
            ui.add_space(6.0);
            ui.heading(RichText::new("NŒUDS DU MAILLAGE").color(CYAN));
            ui.add_space(4.0);
            match &self.statut {
                None => {
                    ui.label(RichText::new("aucun instantané — routeur pas encore sondé").color(GRIS));
                }
                Some(s) if s.noeuds.is_empty() => {
                    ui.label(
                        RichText::new("aucun nœud connecté — dans un terminal :\n  cargo run -p aether-node -- --profil gpu")
                            .color(GRIS),
                    );
                }
                Some(s) => {
                    egui::Grid::new("grille_noeuds").num_columns(4).spacing([16.0, 4.0]).show(ui, |ui| {
                        ui.label(RichText::new("IDENTITÉ").color(MAGENTA).strong());
                        ui.label(RichText::new("PROFIL").color(MAGENTA).strong());
                        ui.label(RichText::new("ADRESSE").color(MAGENTA).strong());
                        ui.label(RichText::new("TÂCHES").color(MAGENTA).strong());
                        ui.end_row();
                        for n in &s.noeuds {
                            ui.label(n.noeud_id.as_str());
                            ui.label(n.profil.etiquette());
                            ui.label(n.addr.as_str());
                            ui.label(RichText::new(n.taches_finies.to_string()).color(VERT));
                            ui.end_row();
                        }
                    });
                    ui.add_space(8.0);
                    ui.label(format!(
                        "jobs actifs : {}    finis : {}    blocs registre : {}",
                        s.jobs_actifs, s.jobs_finis, s.blocs_registre
                    ));
                    let seconde = aether_core::maintenant_ms().saturating_sub(s.demarre_le_ms) / 1000;
                    ui.label(format!("routeur en ligne depuis {seconde} s — protocole {}", s.libelle_version));
                }
            }
        });

        egui::CentralPanel::default().show(ctx, |ui| {
            ui.add_space(6.0);
            ui.heading(RichText::new("SOUMETTRE UN JOB").color(CYAN));
            ui.add_space(4.0);
            ui.horizontal(|ui| {
                if ui.button("Mandelbrot 160x120").clicked() {
                    let _ = self.tx_ordres.send(OrdreUI::Soumettre(SpecJob::Mandelbrot {
                        largeur: 160,
                        hauteur: 120,
                        max_iter: 255,
                    }));
                }
                if ui.button("Premiers 60 000").clicked() {
                    let _ = self.tx_ordres.send(OrdreUI::Soumettre(SpecJob::Premiers {
                        debut: 2,
                        total: 60_000,
                        segment: 5_000,
                    }));
                }
                if ui.button("PoW 16 bits").clicked() {
                    let _ = self.tx_ordres.send(OrdreUI::Soumettre(SpecJob::Pou {
                        bits: 16,
                        sel: aether_core::maintenant_ms(),
                        tranches: 8,
                    }));
                }
            });
            ui.label(
                RichText::new("chaque job est découpé, chiffré (ChaCha20-Poly1305) et distribué aux nœuds disponibles")
                    .small()
                    .color(GRIS),
            );
            ui.add_space(10.0);
            ui.heading(RichText::new("JOURNAL").color(CYAN));
            ui.add_space(4.0);
            egui::ScrollArea::vertical().stick_to_bottom(true).show(ui, |ui| {
                for ligne in &self.journal {
                    ui.label(RichText::new(ligne.as_str()).monospace().color(couleur_ligne(ligne)));
                }
            });
        });

        ctx.request_repaint_after(Duration::from_millis(500));
    }
}

fn couleur_ligne(ligne: &str) -> Color32 {
    if ligne.contains('✓') || ligne.contains("VÉRIFIÉ") {
        VERT
    } else if ligne.contains("erreur") || ligne.contains('✗') {
        MAGENTA
    } else {
        Color32::from_rgb(0xd0, 0xd0, 0xe0)
    }
}

fn main() -> eframe::Result<()> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1020.0, 660.0])
            .with_title("Aether — tableau de bord natif"),
        ..Default::default()
    };
    eframe::run_native("aether-ui", options, Box::new(|_cc| Ok(Box::new(AetherApp::nouveau()))))
}
