//! AETHER NŒUD — Un travailleur du maillage.
//! Se connecte au routeur par un tunnel chiffré, annonce son profil,
//! exécute les tâches reçues et renvoie les résultats. Reconnexion auto.

use aether_core::{executer_tache, identifiant_noeud, MsgNoeud, MsgRouteur, ProfilNoeud};
use aether_crypto::{envoyer_async, poignee_de_main_async, recevoir_async, Tunnel};
use clap::Parser;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tokio::net::TcpStream;
use tokio::sync::mpsc;

#[derive(Parser, Debug)]
#[command(name = "aether-node", version, about = "Nœud de calcul Aether — exécute les tâches du maillage")]
struct Args {
    /// Adresse nœuds du routeur
    #[arg(long, default_value = "127.0.0.1:4101")]
    routeur: String,
    /// Profil de capacité déclaré (gpu | cpu | edge)
    #[arg(long, default_value = "cpu")]
    profil: String,
    /// Identifiant lisible (défaut : auto)
    #[arg(long)]
    id: Option<String>,
    /// Nom d'hôte annoncé (défaut : variable AETHER_HOTE ou « local »)
    #[arg(long)]
    hote: Option<String>,
    /// Secret réseau
    #[arg(long, default_value = "aether-dev-secret-a-changer")]
    secret: String,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .compact()
        .with_target(false)
        .with_max_level(tracing::Level::INFO)
        .init();
    let args = Args::parse();
    let profil = ProfilNoeud::depuis_etiquette(&args.profil)
        .ok_or_else(|| anyhow::anyhow!("profil inconnu : {} (attendu : gpu | cpu | edge)", args.profil))?;
    if let Some(h) = &args.hote {
        std::env::set_var("AETHER_HOTE", h);
    }
    let noeud_id = args.id.clone().filter(|s| !s.trim().is_empty()).unwrap_or_else(|| identifiant_noeud(profil));
    let secret: Arc<Vec<u8>> = Arc::new(args.secret.clone().into_bytes());
    let addr = args.routeur.trim().to_string();

    println!("═ NŒUD AETHER ═");
    println!("  identité : {noeud_id}");
    println!("  profil   : {} (capacité {})", profil.etiquette(), profil.capacite());
    println!("  routeur  : {addr}");
    loop {
        if let Err(e) = boucle_connexion(&addr, secret.clone(), &noeud_id, profil).await {
            tracing::warn!("connexion perdue : {e:#}");
        }
        println!("↻ reconnexion au routeur dans 2 s…");
        tokio::time::sleep(Duration::from_secs(2)).await;
    }
}

/// Une session connectée complète. Retourne quand la connexion tombe.
async fn boucle_connexion(
    addr: &str,
    secret: Arc<Vec<u8>>,
    noeud_id: &str,
    profil: ProfilNoeud,
) -> anyhow::Result<()> {
    let mut flux = TcpStream::connect(addr).await?;
    let tunnel = poignee_de_main_async(&mut flux, &secret, false).await?;
    let (lecteur, ecrivain) = flux.into_split();
    let Tunnel { emission, reception } = tunnel;

    // écrivain dédié (messages sortants)
    let (sortant, mut entree_ecriture) = mpsc::unbounded_channel::<MsgNoeud>();
    tokio::spawn(async move {
        let mut ecrivain = ecrivain;
        let mut emission = emission;
        while let Some(msg) = entree_ecriture.recv().await {
            if envoyer_async(&mut ecrivain, &mut emission, &msg).await.is_err() {
                break;
            }
        }
    });

    sortant.send(MsgNoeud::Bonjour { noeud_id: noeud_id.to_string(), profil })?;

    let mut lecteur = lecteur;
    let mut reception = reception;
    let total = Arc::new(AtomicU64::new(0));
    loop {
        match recevoir_async::<_, MsgRouteur>(&mut lecteur, &mut reception).await? {
            MsgRouteur::Bienvenue { noeud_id: id, capacite } => {
                println!("✓ accepté par le routeur (bienvenue {id}, capacité {capacite})");
            }
            MsgRouteur::Tache(tache) => {
                // calcul réel sur un thread dédié — la boucle réseau reste réactive
                let sortant = sortant.clone();
                let ident = noeud_id.to_string();
                let total = total.clone();
                tokio::spawn(async move {
                    let res = tokio::task::spawn_blocking(move || executer_tache(&tache, &ident)).await;
                    if let Ok(res) = res {
                        let n = total.fetch_add(1, Ordering::Relaxed) + 1;
                        if n % 25 == 0 {
                            println!("  … {n} tâches exécutées");
                        }
                        let _ = sortant.send(MsgNoeud::Resultat(res));
                    }
                });
            }
            MsgRouteur::Rien => {}
        }
    }
}
