//! ═══════════════════════════════════════════════════════════════════
//! AETHER ROUTEUR — Le cœur cognitif du réseau.
//! Accepte les nœuds (port nœuds) et les clients (port clients),
//! découpe les jobs, distribue les tâches selon la capacité des nœuds,
//! assemble, vérifie par recomptage et inscrit au registre chaîné.
//! ═══════════════════════════════════════════════════════════════════

use aether_core::{
    assembler_job, decouper_job, maintenant_ms, FicheNoeud, InstantaneStatut, MsgClient, MsgNoeud,
    MsgRouteur, RepRouteur, ResultatTache, SpecJob, Tache, VERSION_PROTOCOLE,
};
use aether_crypto::{envoyer_async, poignee_de_main_async, recevoir_async, Tunnel};
use aether_ledger::Registre;
use std::collections::{HashMap, HashSet, VecDeque};
use std::net::SocketAddr;
use std::path::PathBuf;
use std::sync::Arc;
use tokio::net::TcpListener;
use tokio::sync::mpsc::{self, UnboundedReceiver, UnboundedSender};

/// Configuration du routeur.
#[derive(Debug, Clone)]
pub struct ConfigRouteur {
    pub secret: Arc<Vec<u8>>,
    pub addr_noeuds: SocketAddr,
    pub addr_clients: SocketAddr,
    /// Fichier de persistance du registre (JSON), optionnel.
    pub fichier_registre: Option<PathBuf>,
}

/// Poignée sur le routeur démarré.
pub struct PoigneeRouteur {
    pub addr_noeuds: SocketAddr,
    pub addr_clients: SocketAddr,
    pub taches: Vec<tokio::task::JoinHandle<()>>,
}

// ───────────────────────── Événements internes ─────────────────────────

enum Evenement {
    NoeudConnecte {
        fiche: FicheNoeud,
        capacite: u32,
        sortant: UnboundedSender<MsgRouteur>,
    },
    NoeudDeconnecte {
        noeud_id: String,
    },
    Resultat(ResultatTache),
    RequeteClient {
        requete: MsgClient,
        reponse: UnboundedSender<RepRouteur>,
    },
}

// ───────────────────────── État interne ─────────────────────────

struct NoeudInterne {
    fiche: FicheNoeud,
    capacite: u32,
    en_cours: HashSet<u64>,
    sortant: UnboundedSender<MsgRouteur>,
}

struct JobInterne {
    spec: SpecJob,
    taches: HashMap<u64, Tache>,
    attente: HashSet<u64>,
    resultats: Vec<ResultatTache>,
    reponse_client: Option<UnboundedSender<RepRouteur>>,
    soumis_le_ms: u64,
}

// ───────────────────────── L'ordonnanceur central ─────────────────────────

struct Ordonnanceur {
    noeuds: HashMap<String, NoeudInterne>,
    jobs: HashMap<u64, JobInterne>,
    file: VecDeque<Tache>,
    registre: Registre,
    compteur_jobs: u64,
    compteur_taches: u64,
    jobs_finis: u64,
    demarre_le_ms: u64,
    fichier_registre: Option<PathBuf>,
}

impl Ordonnanceur {
    fn nouveau(fichier_registre: Option<PathBuf>) -> Self {
        let registre = match &fichier_registre {
            Some(chemin) if chemin.exists() => std::fs::read_to_string(chemin)
                .ok()
                .and_then(|txt| serde_json::from_str::<Registre>(&txt).ok())
                .filter(|r| r.verifier().is_ok())
                .unwrap_or_else(|| {
                    tracing::warn!("registre existant illisible ou invalide — repart de zéro");
                    Registre::neuf()
                }),
            _ => Registre::neuf(),
        };
        Ordonnanceur {
            noeuds: HashMap::new(),
            jobs: HashMap::new(),
            file: VecDeque::new(),
            registre,
            compteur_jobs: 0,
            compteur_taches: 0,
            jobs_finis: 0,
            demarre_le_ms: maintenant_ms(),
            fichier_registre,
        }
    }

    async fn boucle(&mut self, mut entree: UnboundedReceiver<Evenement>) {
        while let Some(ev) = entree.recv().await {
            self.traiter(ev).await;
        }
    }

    async fn traiter(&mut self, ev: Evenement) {
        match ev {
            Evenement::NoeudConnecte { fiche, capacite, sortant } => {
                let id = fiche.noeud_id.clone();
                tracing::info!("nœud connecté : {} ({}, capacité {capacite})", id, fiche.profil.etiquette());
                let _ = sortant.send(MsgRouteur::Bienvenue { noeud_id: id.clone(), capacite });
                self.noeuds.insert(id, NoeudInterne { fiche, capacite, en_cours: HashSet::new(), sortant });
                self.distribuer();
            }
            Evenement::NoeudDeconnecte { noeud_id } => {
                if let Some(noeud) = self.noeuds.remove(&noeud_id) {
                    tracing::warn!("nœud parti : {noeud_id} — {} tâches remises en file", noeud.en_cours.len());
                    for tache_id in &noeud.en_cours {
                        if let Some(t) = self.trouver_tache(*tache_id) {
                            self.file.push_front(t);
                        }
                    }
                    self.distribuer();
                }
            }
            Evenement::Resultat(res) => self.traiter_resultat(res).await,
            Evenement::RequeteClient { requete, reponse } => self.traiter_requete(requete, reponse).await,
        }
    }

    async fn traiter_resultat(&mut self, res: ResultatTache) {
        let noeud_id = res.noeud_id.clone();
        let tache_id = res.tache_id;
        let job_id = res.job_id;
        if let Some(noeud) = self.noeuds.get_mut(&noeud_id) {
            noeud.en_cours.remove(&tache_id);
            noeud.fiche.taches_finies += 1;
        }
        let termine = {
            let Some(job) = self.jobs.get_mut(&job_id) else { return };
            job.attente.remove(&tache_id);
            job.resultats.push(res);
            job.attente.is_empty()
        };
        if termine {
            let job = self.jobs.remove(&job_id).expect("job présent");
            let mut taches_triees: Vec<Tache> = job.taches.values().cloned().collect();
            taches_triees.sort_by_key(|t| t.tache_id);
            let resume = assembler_job(&job.spec, job_id, &taches_triees, &job.resultats);
            self.registre.ajouter(
                job_id,
                &resume.genre,
                resume.contributions.clone(),
                &resume.hash_resultat,
                resume.verifie,
            );
            self.jobs_finis += 1;
            self.persister_registre();
            let duree_ms = maintenant_ms().saturating_sub(job.soumis_le_ms);
            tracing::info!(
                "job {job_id} terminé en {duree_ms} ms — {} — bloc {} inscrit au registre",
                resume.resume,
                self.registre.len() - 1
            );
            if let Some(tx) = &job.reponse_client {
                let _ = tx.send(RepRouteur::JobFini {
                    job_id,
                    resume: resume.resume.clone(),
                    hash_resultat: resume.hash_resultat.clone(),
                    verifie: resume.verifie,
                });
            }
        }
        self.distribuer();
    }

    async fn traiter_requete(&mut self, requete: MsgClient, reponse: UnboundedSender<RepRouteur>) {
        match requete {
            MsgClient::Soumettre(spec) => {
                self.compteur_jobs += 1;
                let job_id = self.compteur_jobs;
                let taches = decouper_job(&spec, job_id, self.compteur_taches + 1);
                self.compteur_taches += taches.len() as u64;
                let attente: HashSet<u64> = taches.iter().map(|t| t.tache_id).collect();
                let taches_map: HashMap<u64, Tache> = taches.iter().map(|t| (t.tache_id, t.clone())).collect();
                for t in taches {
                    self.file.push_back(t);
                }
                self.jobs.insert(
                    job_id,
                    JobInterne {
                        spec,
                        taches: taches_map,
                        attente,
                        resultats: Vec::new(),
                        reponse_client: Some(reponse.clone()),
                        soumis_le_ms: maintenant_ms(),
                    },
                );
                let _ = reponse.send(RepRouteur::JobAccepte { job_id });
                tracing::info!("job {job_id} accepté — {} tâches en file", self.jobs[&job_id].attente.len());
                self.distribuer();
            }
            MsgClient::Statut => {
                let statut = InstantaneStatut {
                    noeuds: self.noeuds.values().map(|n| n.fiche.clone()).collect(),
                    jobs_actifs: self.jobs.len() as u64,
                    jobs_finis: self.jobs_finis,
                    blocs_registre: self.registre.len() as u64,
                    demarre_le_ms: self.demarre_le_ms,
                    libelle_version: VERSION_PROTOCOLE.to_string(),
                };
                let _ = reponse.send(RepRouteur::Statut(statut));
            }
            MsgClient::Registre => {
                let _ = reponse.send(RepRouteur::RegistreJson(self.registre.en_json()));
            }
        }
    }

    /// Confie les tâches en file aux nœuds disponibles (capacité libre maximale d'abord).
    fn distribuer(&mut self) {
        while let Some(tache) = self.file.pop_front() {
            let choisi = self
                .noeuds
                .iter()
                .filter(|(_, n)| (n.en_cours.len() as u32) < n.capacite)
                .max_by_key(|(_, n)| n.capacite - n.en_cours.len() as u32)
                .map(|(id, _)| id.clone());
            let Some(id) = choisi else {
                self.file.push_front(tache);
                break; // aucun nœud disponible : on garde en file
            };
            let Some(noeud) = self.noeuds.get_mut(&id) else {
                self.file.push_front(tache);
                continue;
            };
            if noeud.sortant.send(MsgRouteur::Tache(tache.clone())).is_ok() {
                noeud.en_cours.insert(tache.tache_id);
                tracing::debug!("tâche {} → {}", tache.tache_id, id);
            } else {
                // émetteur mort : nœud considéré parti, ses tâches repartent en file
                let mort = self.noeuds.remove(&id);
                self.file.push_front(tache);
                if let Some(n) = mort {
                    for tid in n.en_cours {
                        if let Some(t) = self.trouver_tache(tid) {
                            self.file.push_front(t);
                        }
                    }
                }
            }
        }
    }

    fn trouver_tache(&self, tache_id: u64) -> Option<Tache> {
        self.jobs
            .values()
            .find(|j| j.taches.contains_key(&tache_id))
            .and_then(|j| j.taches.get(&tache_id).cloned())
    }

    fn persister_registre(&self) {
        if let Some(chemin) = &self.fichier_registre {
            if let Some(dossier) = chemin.parent() {
                let _ = std::fs::create_dir_all(dossier);
            }
            let _ = std::fs::write(chemin, self.registre.en_json());
        }
    }
}

// ───────────────────────── Connexions nœuds ─────────────────────────

async fn tache_accept_noeuds(listener: TcpListener, secret: Arc<Vec<u8>>, vers_ord: UnboundedSender<Evenement>) {
    loop {
        let (mut flux, addr) = match listener.accept().await {
            Ok(x) => x,
            Err(e) => {
                tracing::warn!("accept nœuds : {e}");
                tokio::time::sleep(std::time::Duration::from_millis(200)).await;
                continue;
            }
        };
        let secret = secret.clone();
        let vers_ord = vers_ord.clone();
        tokio::spawn(async move {
            let tunnel = match poignee_de_main_async(&mut flux, &secret, true).await {
                Ok(t) => t,
                Err(e) => {
                    tracing::debug!("poignée de main nœud échouée ({addr}) : {e}");
                    return;
                }
            };
            let (lecteur, ecrivain) = flux.into_split();
            let Tunnel { emission, reception } = tunnel;
            // écrivain dédié : consomme la file sortante de ce nœud
            let (sortant, mut entree_ecriture) = mpsc::unbounded_channel::<MsgRouteur>();
            tokio::spawn(async move {
                let mut ecrivain = ecrivain;
                let mut emission = emission;
                while let Some(msg) = entree_ecriture.recv().await {
                    if envoyer_async(&mut ecrivain, &mut emission, &msg).await.is_err() {
                        break;
                    }
                }
            });
            let mut lecteur = lecteur;
            let mut reception = reception;
            let mut enregistre = false;
            let mut mon_id = String::new();
            loop {
                match recevoir_async::<_, MsgNoeud>(&mut lecteur, &mut reception).await {
                    Ok(MsgNoeud::Bonjour { noeud_id, profil }) => {
                        mon_id = noeud_id.clone();
                        enregistre = true;
                        let fiche = FicheNoeud {
                            noeud_id,
                            profil,
                            addr: addr.to_string(),
                            taches_finies: 0,
                            connecte_le_ms: maintenant_ms(),
                        };
                        let capacite = fiche.profil.capacite();
                        let _ = vers_ord.send(Evenement::NoeudConnecte { fiche, capacite, sortant: sortant.clone() });
                    }
                    Ok(MsgNoeud::Resultat(res)) => {
                        let _ = vers_ord.send(Evenement::Resultat(res));
                    }
                    Err(_) => break, // connexion coupée
                }
            }
            if enregistre {
                let _ = vers_ord.send(Evenement::NoeudDeconnecte { noeud_id: mon_id });
            }
            drop(sortant); // ferme l'écrivain dédié
        });
    }
}

// ───────────────────────── Connexions clients ─────────────────────────

async fn tache_accept_clients(listener: TcpListener, secret: Arc<Vec<u8>>, vers_ord: UnboundedSender<Evenement>) {
    loop {
        let (mut flux, addr) = match listener.accept().await {
            Ok(x) => x,
            Err(e) => {
                tracing::warn!("accept clients : {e}");
                tokio::time::sleep(std::time::Duration::from_millis(200)).await;
                continue;
            }
        };
        let secret = secret.clone();
        let vers_ord = vers_ord.clone();
        tokio::spawn(async move {
            let tunnel = match poignee_de_main_async(&mut flux, &secret, true).await {
                Ok(t) => t,
                Err(e) => {
                    tracing::debug!("poignée de main client échouée ({addr}) : {e}");
                    return;
                }
            };
            let (lecteur, ecrivain) = flux.into_split();
            let Tunnel { emission, reception } = tunnel;
            let (sortant, mut entree_ecriture) = mpsc::unbounded_channel::<RepRouteur>();
            tokio::spawn(async move {
                let mut ecrivain = ecrivain;
                let mut emission = emission;
                while let Some(msg) = entree_ecriture.recv().await {
                    if envoyer_async(&mut ecrivain, &mut emission, &msg).await.is_err() {
                        break;
                    }
                }
            });
            let mut lecteur = lecteur;
            let mut reception = reception;
            loop {
                match recevoir_async::<_, MsgClient>(&mut lecteur, &mut reception).await {
                    Ok(requete) => {
                        let _ = vers_ord.send(Evenement::RequeteClient { requete, reponse: sortant.clone() });
                    }
                    Err(_) => break,
                }
            }
            drop(sortant);
        });
    }
}

// ───────────────────────── Démarrage ─────────────────────────

/// Démarre le routeur : écoute nœuds + clients, ordonnanceur central.
/// Supporte le port 0 (éphémère) pour les tests.
pub async fn demarrer(cfg: ConfigRouteur) -> anyhow::Result<PoigneeRouteur> {
    let ecoute_noeuds = TcpListener::bind(cfg.addr_noeuds).await?;
    let ecoute_clients = TcpListener::bind(cfg.addr_clients).await?;
    let addr_noeuds = ecoute_noeuds.local_addr()?;
    let addr_clients = ecoute_clients.local_addr()?;

    let (vers_ord, entree_ord) = mpsc::unbounded_channel::<Evenement>();
    let mut ordonnanceur = Ordonnanceur::nouveau(cfg.fichier_registre.clone());
    let tache_ord = tokio::spawn(async move { ordonnanceur.boucle(entree_ord).await });

    let secret = cfg.secret.clone();
    let t1 = tokio::spawn(tache_accept_noeuds(ecoute_noeuds, secret.clone(), vers_ord.clone()));
    let t2 = tokio::spawn(tache_accept_clients(ecoute_clients, secret, vers_ord));

    tracing::info!("routeur en ligne — nœuds {addr_noeuds} / clients {addr_clients}");
    Ok(PoigneeRouteur { addr_noeuds, addr_clients, taches: vec![tache_ord, t1, t2] })
}

// ═════════════════════════ TESTS UNITAIRES ═════════════════════════

#[cfg(test)]
mod tests {
    use super::*;
    use aether_core::ProfilNoeud;

    #[test]
    fn capacites_par_profil() {
        assert_eq!(ProfilNoeud::Gpu.capacite(), 4);
        assert_eq!(ProfilNoeud::Cpu.capacite(), 2);
        assert_eq!(ProfilNoeud::Edge.capacite(), 1);
    }

    #[test]
    fn registre_charge_depuis_fichier_invalide() {
        // fichier corrompu → registre neuf (ne doit jamais paniquer)
        let mut chemin = std::env::temp_dir();
        chemin.push(format!("aether-test-{}.json", std::process::id()));
        std::fs::write(&chemin, "{ ceci n'est pas du json valide").unwrap();
        let ord = Ordonnanceur::nouveau(Some(chemin.clone()));
        assert_eq!(ord.registre.len(), 1, "genèse seule");
        let _ = std::fs::remove_file(&chemin);
    }

    #[tokio::test]
    async fn ordonnanceur_avale_les_evenements_sans_paniquer() {
        // fumée : l'ordonnanceur traite un cycle complet connecte/soumet/déconnecte
        let (vers_ord, mut entree_ord) = mpsc::unbounded_channel::<Evenement>();
        let mut ord = Ordonnanceur::nouveau(None);
        let (sortant, mut entree_sortant) = mpsc::unbounded_channel::<MsgRouteur>();
        vers_ord
            .send(Evenement::NoeudConnecte {
                fiche: FicheNoeud {
                    noeud_id: "gpu-x".into(),
                    profil: ProfilNoeud::Gpu,
                    addr: "127.0.0.1:1".into(),
                    taches_finies: 0,
                    connecte_le_ms: 0,
                },
                capacite: 4,
                sortant,
            })
            .unwrap();
        vers_ord
            .send(Evenement::RequeteClient {
                requete: MsgClient::Soumettre(SpecJob::Pou { bits: 4, sel: 3, tranches: 2 }),
                reponse: mpsc::unbounded_channel().0,
            })
            .unwrap();
        vers_ord.send(Evenement::NoeudDeconnecte { noeud_id: "gpu-x".into() }).unwrap();
        // un cycle de traitement
        for _ in 0..3 {
            if let Some(ev) = entree_ord.recv().await {
                ord.traiter(ev).await;
            }
        }
        // la file doit contenir les tâches non distribuées (nœud parti)
        assert_eq!(ord.file.len(), 2, "les tâches du nœud parti retournent en file");
        let _ = entree_sortant.try_recv(); // Bienvenue émise
    }
}
