//! Binaire aether-router — le routeur cognitif Aether.

use aether_router::{demarrer, ConfigRouteur};
use clap::Parser;
use std::net::SocketAddr;
use std::path::PathBuf;
use std::sync::Arc;

#[derive(Parser, Debug)]
#[command(name = "aether-router", version, about = "Routeur cognitif Aether — découpe, distribue, assemble, inscrit")]
struct Args {
    /// Adresse d'écoute des nœuds
    #[arg(long, default_value = "127.0.0.1:4101")]
    noeuds: SocketAddr,
    /// Adresse d'écoute des clients (CLI / interface)
    #[arg(long, default_value = "127.0.0.1:4100")]
    clients: SocketAddr,
    /// Secret réseau (tunnels chiffrés) — sinon variable AETHER_SECRET
    #[arg(long)]
    secret: Option<String>,
    /// Fichier de persistance du registre
    #[arg(long, default_value = "data/registre.json")]
    registre: PathBuf,
}

fn main() -> anyhow::Result<()> {
    let args = Args::parse();
    tracing_subscriber::fmt()
        .compact()
        .with_target(false)
        .with_max_level(tracing::Level::INFO)
        .init();
    let secret = args
        .secret
        .or_else(|| std::env::var("AETHER_SECRET").ok())
        .filter(|s| !s.trim().is_empty())
        .unwrap_or_else(|| "aether-dev-secret-a-changer".to_string());

    let runtime = tokio::runtime::Runtime::new()?;
    runtime.block_on(async move {
        let cfg = ConfigRouteur {
            secret: Arc::new(secret.into_bytes()),
            addr_noeuds: args.noeuds,
            addr_clients: args.clients,
            fichier_registre: Some(args.registre),
        };
        let poignee = demarrer(cfg).await?;
        println!("═ ROUTEUR COGNITIF AETHER ═");
        println!("  nœuds   : {}", poignee.addr_noeuds);
        println!("  clients : {}", poignee.addr_clients);
        println!("  registre: data/registre.json (persisté à chaque job)");
        println!("  Ctrl-C pour arrêter");
        tokio::select! {
            _ = tokio::signal::ctrl_c() => println!("\narrêt du routeur — à bientôt."),
            _ = async {
                for t in poignee.taches {
                    let _ = t.await;
                }
            } => {}
        }
        Ok::<(), anyhow::Error>(())
    })?;
    Ok(())
}
