//! Test d'intégration : réseau complet en mémoire.
//! Routeur + 2 nœuds factices + client — job distribué de bout en bout :
//! découpe, chiffrement, distribution, assemblage, vérification, registre.

use aether_core::*;
use aether_crypto::{envoyer_async, poignee_de_main_async, recevoir_async, Tunnel};
use std::sync::Arc;
use std::time::Duration;

/// Un nœud factice : poignée de main chiffrée, puis exécute chaque tâche reçue.
async fn noeud_factice(
    addr: std::net::SocketAddr,
    secret: Arc<Vec<u8>>,
    id: &str,
    profil: ProfilNoeud,
) -> anyhow::Result<()> {
    let mut flux = tokio::net::TcpStream::connect(addr).await?;
    let mut tunnel = poignee_de_main_async(&mut flux, &secret, false).await?;
    envoyer_async(&mut flux, &mut tunnel.emission, &MsgNoeud::Bonjour { noeud_id: id.to_string(), profil }).await?;
    let (lecteur, ecrivain) = flux.into_split();
    let Tunnel { emission, reception } = tunnel;
    let mut lecteur = lecteur;
    let mut reception = reception;
    let mut ecrivain = ecrivain;
    let mut emission = emission;
    loop {
        match recevoir_async::<_, MsgRouteur>(&mut lecteur, &mut reception).await? {
            MsgRouteur::Bienvenue { .. } | MsgRouteur::Rien => {}
            MsgRouteur::Tache(t) => {
                let res = executer_tache(&t, id);
                envoyer_async(&mut ecrivain, &mut emission, &MsgNoeud::Resultat(res)).await?;
            }
        }
    }
}

#[tokio::test]
async fn job_distribue_de_bout_en_bout() -> anyhow::Result<()> {
    let secret: Arc<Vec<u8>> = Arc::new(b"secret-integration".to_vec());
    let poignee = aether_router::demarrer(aether_router::ConfigRouteur {
        secret: secret.clone(),
        addr_noeuds: "127.0.0.1:0".parse()?,
        addr_clients: "127.0.0.1:0".parse()?,
        fichier_registre: None,
    })
    .await?;

    // deux nœuds factices : un GPU (PC gamer) et un CPU (serveur Linux)
    tokio::spawn(noeud_factice(poignee.addr_noeuds, secret.clone(), "gpu-test-1", ProfilNoeud::Gpu));
    tokio::spawn(noeud_factice(poignee.addr_noeuds, secret.clone(), "cpu-test-1", ProfilNoeud::Cpu));
    tokio::time::sleep(Duration::from_millis(400)).await;

    // client : soumission d'un job de comptage de premiers
    let mut flux = tokio::net::TcpStream::connect(poignee.addr_clients).await?;
    let mut tunnel = poignee_de_main_async(&mut flux, &secret, false).await?;
    envoyer_async(
        &mut flux,
        &mut tunnel.emission,
        &MsgClient::Soumettre(SpecJob::Premiers { debut: 2, total: 20_000, segment: 2_500 }),
    )
    .await?;
    let accepte = recevoir_async::<_, RepRouteur>(&mut flux, &mut tunnel.reception).await?;
    assert!(matches!(accepte, RepRouteur::JobAccepte { .. }), "job non accepté : {accepte:?}");

    let fini = tokio::time::timeout(Duration::from_secs(30), recevoir_async::<_, RepRouteur>(&mut flux, &mut tunnel.reception))
        .await
        .map_err(|_| anyhow::anyhow!("délai dépassé : le job ne finit pas"))??;
    match fini {
        RepRouteur::JobFini { resume, hash_resultat, verifie, .. } => {
            assert!(verifie, "le recomptage doit confirmer : {resume}");
            assert_eq!(hash_resultat.len(), 64);
            assert!(resume.contains("2262"), "π(20 000) = 2262 attendu ; résumé : {resume}");
        }
        autre => panic!("réponse inattendue : {autre:?}"),
    }

    // statut : 2 nœuds, 1 job fini, registre à 2 blocs (genèse + job)
    envoyer_async(&mut flux, &mut tunnel.emission, &MsgClient::Statut).await?;
    match recevoir_async::<_, RepRouteur>(&mut flux, &mut tunnel.reception).await? {
        RepRouteur::Statut(s) => {
            assert_eq!(s.noeuds.len(), 2, "les deux nœuds doivent être connectés");
            assert_eq!(s.jobs_finis, 1);
            assert_eq!(s.blocs_registre, 2);
            let total_taches: u64 = s.noeuds.iter().map(|n| n.taches_finies).sum();
            assert_eq!(total_taches, 8, "20 000 / 2 500 = 8 tâches distribuées");
        }
        autre => panic!("statut inattendu : {autre:?}"),
    }

    // registre chaîné, vérifiable, avec les contributions des deux nœuds
    envoyer_async(&mut flux, &mut tunnel.emission, &MsgClient::Registre).await?;
    match recevoir_async::<_, RepRouteur>(&mut flux, &mut tunnel.reception).await? {
        RepRouteur::RegistreJson(json) => {
            let registre: aether_ledger::Registre = serde_json::from_str(&json)?;
            assert!(registre.verifier().is_ok(), "la chaîne doit être valide");
            let bloc_job = &registre.blocs[1];
            assert_eq!(bloc_job.genre, "premiers");
            assert_eq!(bloc_job.contributions.len(), 2, "les deux nœuds ont contribué");
        }
        autre => panic!("registre inattendu : {autre:?}"),
    }
    Ok(())
}

#[tokio::test]
async fn job_en_attente_puis_noeud_arrive() -> anyhow::Result<()> {
    let secret: Arc<Vec<u8>> = Arc::new(b"secret-tardif".to_vec());
    let poignee = aether_router::demarrer(aether_router::ConfigRouteur {
        secret: secret.clone(),
        addr_noeuds: "127.0.0.1:0".parse()?,
        addr_clients: "127.0.0.1:0".parse()?,
        fichier_registre: None,
    })
    .await?;

    // soumission AVANT tout nœud : les tâches patientent en file
    let mut flux = tokio::net::TcpStream::connect(poignee.addr_clients).await?;
    let mut tunnel = poignee_de_main_async(&mut flux, &secret, false).await?;
    envoyer_async(
        &mut flux,
        &mut tunnel.emission,
        &MsgClient::Soumettre(SpecJob::Pou { bits: 8, sel: 7, tranches: 4 }),
    )
    .await?;
    assert!(matches!(
        recevoir_async::<_, RepRouteur>(&mut flux, &mut tunnel.reception).await?,
        RepRouteur::JobAccepte { .. }
    ));

    // le nœud arrive après coup : la file doit se vider vers lui
    tokio::spawn(noeud_factice(poignee.addr_noeuds, secret.clone(), "edge-tardif", ProfilNoeud::Edge));
    let fini = tokio::time::timeout(Duration::from_secs(30), recevoir_async::<_, RepRouteur>(&mut flux, &mut tunnel.reception))
        .await
        .map_err(|_| anyhow::anyhow!("délai dépassé : le job ne finit pas"))??;
    assert!(
        matches!(fini, RepRouteur::JobFini { verifie: true, .. }),
        "job non fini/vérifié : {fini:?}"
    );
    Ok(())
}
