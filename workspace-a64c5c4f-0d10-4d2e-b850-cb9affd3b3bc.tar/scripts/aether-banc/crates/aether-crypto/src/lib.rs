//! ═══════════════════════════════════════════════════════════════════
//! AETHER CRYPTO — Tunnels chiffrés authentifiés (ChaCha20-Poly1305)
//! Poignée de main : échange de sels puis dérivation HKDF-SHA256.
//! Phase 1 : secret réseau partagé. Phase 2 : échange de clés X25519.
//! ═══════════════════════════════════════════════════════════════════

use chacha20poly1305::aead::{Aead, KeyInit};
use chacha20poly1305::{ChaCha20Poly1305, Key, Nonce};
use hkdf::Hkdf;
use serde::de::DeserializeOwned;
use serde::Serialize;
use sha2::Sha256;
use std::io::{Read, Write};
use std::net::TcpStream;
use std::time::{SystemTime, UNIX_EPOCH};
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};

/// Magie du protocole : chaque poignée de main commence par AETH.
pub const MAGIE: [u8; 4] = *b"AETH";
/// Taille maximale d'une trame chiffrée (64 Mio) — garde-fou.
pub const TAILLE_MAX_TRAME: u32 = 64 * 1024 * 1024;
/// Sens client → serveur (premier octet du nonce).
pub const SENS_CLIENT: u8 = 0x01;
/// Sens serveur → client.
pub const SENS_SERVEUR: u8 = 0x02;

// ───────────────────────── Sel local ─────────────────────────

/// Sel de connexion : temps ^ pid ^ compteur — unique par appel (unicité, pas de secret).
pub fn sel_local() -> [u8; 16] {
    use std::sync::atomic::{AtomicU64, Ordering};
    static COMPTEUR: AtomicU64 = AtomicU64::new(0);
    let n = COMPTEUR.fetch_add(1, Ordering::Relaxed);
    let duree = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default();
    let secs = duree.as_secs();
    let nanos = duree.subsec_nanos() as u64;
    let pid = std::process::id() as u64;
    let brut = secs ^ ((nanos << 17) ^ (pid << 32) ^ n.wrapping_mul(0x9E37_79B9_7F4A_7C15));
    let mut sel = [0u8; 16];
    sel[..8].copy_from_slice(&brut.to_le_bytes());
    sel[8..].copy_from_slice(&(brut ^ 0xAB12_CD34_EF56_0978).to_le_bytes());
    sel
}

// ───────────────────────── Clé de session ─────────────────────────

/// Dérive la clé de session : HKDF-SHA256(secret, sel_client ‖ sel_serveur).
/// Les deux côtés concatènent dans le même ordre canonique (client d'abord).
pub fn cle_session(secret: &[u8], sel_client: &[u8; 16], sel_serveur: &[u8; 16]) -> Key {
    let mut sel = Vec::with_capacity(32);
    sel.extend_from_slice(sel_client);
    sel.extend_from_slice(sel_serveur);
    let hk = Hkdf::<Sha256>::new(Some(&sel), secret);
    let mut okm = [0u8; 32];
    hk.expand(b"aether-session-v1", &mut okm).expect("taille de sortie valide");
    *Key::from_slice(&okm)
}

// ───────────────────────── Session directionnelle ─────────────────────────

/// Une direction du tunnel : clé partagée + compteur de nonces.
/// Nonce 96 bits : [sens][3 nuls][compteur u64] — jamais réutilisé.
pub struct Session {
    chiffre: ChaCha20Poly1305,
    sens: u8,
    compteur: u64,
}

impl Session {
    pub fn nouvelle(cle: &Key, sens: u8) -> Self {
        Session { chiffre: ChaCha20Poly1305::new(cle), sens, compteur: 0 }
    }

    fn nonce(&mut self) -> Nonce {
        let mut brut = [0u8; 12];
        brut[0] = self.sens;
        brut[4..12].copy_from_slice(&self.compteur.to_le_bytes());
        self.compteur += 1;
        *Nonce::from_slice(&brut)
    }

    /// Chiffre et authentifie un message (ChaCha20-Poly1305).
    pub fn sceller(&mut self, clair: &[u8]) -> Vec<u8> {
        let n = self.nonce();
        self.chiffre
            .encrypt(&n, clair)
            .expect("chiffrement ACD impossible (message trop grand ?)")
    }

    /// Déchiffre et vérifie le sceau. Échoue si altéré ou désynchronisé.
    pub fn ouvrir(&mut self, sceau: &[u8]) -> Result<Vec<u8>, String> {
        let n = self.nonce();
        self.chiffre
            .decrypt(&n, sceau)
            .map_err(|_| "trame altérée ou clé désynchronisée".to_string())
    }
}

/// Paire de sessions après poignée de main : (émission, réception).
pub struct Tunnel {
    pub emission: Session,
    pub reception: Session,
}

fn construire(secret: &[u8], serveur: bool, sel_distant: &[u8; 16], sel_proche: &[u8; 16]) -> Tunnel {
    // ordre canonique : sel du client d'abord
    let (sel_client, sel_serveur) = if serveur {
        (sel_distant, sel_proche)
    } else {
        (sel_proche, sel_distant)
    };
    let cle = cle_session(secret, sel_client, sel_serveur);
    let (sens_emis, sens_recu) = if serveur {
        (SENS_SERVEUR, SENS_CLIENT)
    } else {
        (SENS_CLIENT, SENS_SERVEUR)
    };
    Tunnel {
        emission: Session::nouvelle(&cle, sens_emis),
        reception: Session::nouvelle(&cle, sens_recu),
    }
}

// ───────────────────────── Poignées de main ─────────────────────────

/// Poignée de main synchrone (CLI / interface) sur un flux TCP bloquant.
pub fn poignee_de_main_sync(flux: &mut TcpStream, secret: &[u8], serveur: bool) -> std::io::Result<Tunnel> {
    let sel_proche = sel_local();
    let mut paquet = [0u8; 20];
    paquet[..4].copy_from_slice(&MAGIE);
    paquet[4..].copy_from_slice(&sel_proche);
    flux.write_all(&paquet)?;
    let mut recu = [0u8; 20];
    flux.read_exact(&mut recu)?;
    if recu[..4] != MAGIE {
        return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "magie invalide : le pair n'est pas Aether"));
    }
    let mut sel_distant = [0u8; 16];
    sel_distant.copy_from_slice(&recu[4..]);
    Ok(construire(secret, serveur, &sel_distant, &sel_proche))
}

/// Poignée de main asynchrone (routeur / nœuds).
pub async fn poignee_de_main_async<S>(flux: &mut S, secret: &[u8], serveur: bool) -> std::io::Result<Tunnel>
where
    S: AsyncRead + AsyncWrite + Unpin,
{
    let sel_proche = sel_local();
    let mut paquet = [0u8; 20];
    paquet[..4].copy_from_slice(&MAGIE);
    paquet[4..].copy_from_slice(&sel_proche);
    flux.write_all(&paquet).await?;
    let mut recu = [0u8; 20];
    flux.read_exact(&mut recu).await?;
    if recu[..4] != MAGIE {
        return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "magie invalide : le pair n'est pas Aether"));
    }
    let mut sel_distant = [0u8; 16];
    sel_distant.copy_from_slice(&recu[4..]);
    Ok(construire(secret, serveur, &sel_distant, &sel_proche))
}

// ───────────────────────── Trames chiffrées ─────────────────────────

/// Trame : longueur (u32 LE) puis sceau ACD.
pub fn encoder_trame(sceau: &[u8]) -> Vec<u8> {
    let mut tampon = Vec::with_capacity(4 + sceau.len());
    tampon.extend_from_slice(&(sceau.len() as u32).to_le_bytes());
    tampon.extend_from_slice(sceau);
    tampon
}

/// Envoie un message sérialisé (bincode) puis chiffré — asynchrone.
/// `emission` : la session d'émission de ce côté du tunnel.
pub async fn envoyer_async<S, M>(flux: &mut S, emission: &mut Session, message: &M) -> std::io::Result<()>
where
    S: AsyncWrite + Unpin,
    M: Serialize,
{
    let clair = bincode::serialize(message).map_err(erreur_io)?;
    let sceau = emission.sceller(&clair);
    flux.write_all(&encoder_trame(&sceau)).await?;
    flux.flush().await
}

/// Reçoit un message chiffré puis désérialisé — asynchrone.
/// `reception` : la session de réception de ce côté du tunnel.
pub async fn recevoir_async<S, M>(flux: &mut S, reception: &mut Session) -> std::io::Result<M>
where
    S: AsyncRead + Unpin,
    M: DeserializeOwned,
{
    let sceau = lire_sceau_async(flux).await?;
    let clair = reception.ouvrir(&sceau).map_err(erreur_io)?;
    bincode::deserialize(&clair).map_err(erreur_io)
}

async fn lire_sceau_async<S: AsyncRead + Unpin>(flux: &mut S) -> std::io::Result<Vec<u8>> {
    let mut entete = [0u8; 4];
    flux.read_exact(&mut entete).await?;
    let taille = u32::from_le_bytes(entete);
    if taille == 0 || taille > TAILLE_MAX_TRAME {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            format!("taille de trame invalide : {taille}"),
        ));
    }
    let mut sceau = vec![0u8; taille as usize];
    flux.read_exact(&mut sceau).await?;
    Ok(sceau)
}

/// Variante synchrone (CLI / interface).
pub fn envoyer_sync<M: Serialize>(flux: &mut TcpStream, emission: &mut Session, message: &M) -> std::io::Result<()> {
    let clair = bincode::serialize(message).map_err(erreur_io)?;
    let sceau = emission.sceller(&clair);
    flux.write_all(&encoder_trame(&sceau))?;
    flux.flush()
}

/// Variante synchrone (CLI / interface).
pub fn recevoir_sync<M: DeserializeOwned>(flux: &mut TcpStream, reception: &mut Session) -> std::io::Result<M> {
    let mut entete = [0u8; 4];
    flux.read_exact(&mut entete)?;
    let taille = u32::from_le_bytes(entete);
    if taille == 0 || taille > TAILLE_MAX_TRAME {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            format!("taille de trame invalide : {taille}"),
        ));
    }
    let mut sceau = vec![0u8; taille as usize];
    flux.read_exact(&mut sceau)?;
    let clair = reception.ouvrir(&sceau).map_err(erreur_io)?;
    bincode::deserialize(&clair).map_err(erreur_io)
}

fn erreur_io<E: std::fmt::Display>(e: E) -> std::io::Error {
    std::io::Error::new(std::io::ErrorKind::InvalidData, e.to_string())
}

// ═════════════════════════ TESTS ═════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cle_identique_des_deux_cotes() {
        let (c, s) = ([1u8; 16], [2u8; 16]);
        assert_eq!(
            cle_session(b"secret", &c, &s).as_slice(),
            cle_session(b"secret", &c, &s).as_slice()
        );
        assert_ne!(
            cle_session(b"secret", &c, &s).as_slice(),
            cle_session(b"autre-secret", &c, &s).as_slice()
        );
    }

    #[test]
    fn sceller_ouvrir_boucle() {
        let cle = cle_session(b"secret", &[1u8; 16], &[2u8; 16]);
        let mut emetteur = Session::nouvelle(&cle, SENS_CLIENT);
        let mut recepteur = Session::nouvelle(&cle, SENS_CLIENT);
        let sceau = emetteur.sceller(b"bonjour aether");
        assert_ne!(&sceau[..14.min(sceau.len())], b"bonjour aeth");
        let clair = recepteur.ouvrir(&sceau).expect("déchiffrement");
        assert_eq!(clair, b"bonjour aether");
    }

    #[test]
    fn trame_alteree_rejetee() {
        let cle = cle_session(b"secret", &[1u8; 16], &[2u8; 16]);
        let mut emetteur = Session::nouvelle(&cle, SENS_CLIENT);
        let mut recepteur = Session::nouvelle(&cle, SENS_CLIENT);
        let mut sceau = emetteur.sceller(b"donnees critiques");
        sceau[3] ^= 0xFF; // un seul octet modifié
        assert!(recepteur.ouvrir(&sceau).is_err(), "l'ACD doit rejeter la trame altérée");
    }

    #[test]
    fn nonces_jamais_reutilises() {
        let cle = cle_session(b"secret", &[1u8; 16], &[2u8; 16]);
        let mut s = Session::nouvelle(&cle, SENS_SERVEUR);
        let a = s.sceller(b"x");
        let b = s.sceller(b"x");
        assert_ne!(a, b, "même clair → sceaux différents (nonce unique)");
    }

    #[tokio::test]
    async fn poignee_async_sur_paire_locale() {
        let secret = b"secret-test";
        let ecoute = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = ecoute.local_addr().unwrap();
        let serveur = tokio::spawn(async move {
            let (mut flux, _) = ecoute.accept().await.unwrap();
            let mut tunnel = poignee_de_main_async(&mut flux, secret, true).await.unwrap();
            envoyer_async(&mut flux, &mut tunnel.emission, &"bienvenue".to_string()).await.unwrap();
        });
        let mut flux = tokio::net::TcpStream::connect(addr).await.unwrap();
        let mut tunnel = poignee_de_main_async(&mut flux, secret, false).await.unwrap();
        let recu: String = recevoir_async(&mut flux, &mut tunnel.reception).await.unwrap();
        assert_eq!(recu, "bienvenue");
        serveur.await.unwrap();
    }
}
