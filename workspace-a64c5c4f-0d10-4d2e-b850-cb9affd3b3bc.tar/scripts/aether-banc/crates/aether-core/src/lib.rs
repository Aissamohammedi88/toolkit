//! ═══════════════════════════════════════════════════════════════════
//! AETHER CORE — Protocole, messages, tâches et noyaux de calcul
//! Partagé par : le routeur, les nœuds, le CLI, l'interface, le registre.
//! ═══════════════════════════════════════════════════════════════════

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

/// Version du protocole Aether.
pub const VERSION_PROTOCOLE: &str = "AETHER/1.0";

// ───────────────────────── Identité des nœuds ─────────────────────────

/// Profil de capacité d'un nœud du maillage.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ProfilNoeud {
    /// Nœud GPU — forte puissance déclarée (ex. PC gamer).
    Gpu,
    /// Nœud CPU — puissance moyenne (ex. serveur Linux).
    Cpu,
    /// Nœud Edge — petite machine (ex. Mac M3).
    Edge,
}

impl ProfilNoeud {
    /// Nombre de tâches simultanées que le routeur confie à ce profil.
    pub fn capacite(self) -> u32 {
        match self {
            ProfilNoeud::Gpu => 4,
            ProfilNoeud::Cpu => 2,
            ProfilNoeud::Edge => 1,
        }
    }

    /// Étiquette courte (gpu / cpu / edge).
    pub fn etiquette(self) -> &'static str {
        match self {
            ProfilNoeud::Gpu => "gpu",
            ProfilNoeud::Cpu => "cpu",
            ProfilNoeud::Edge => "edge",
        }
    }

    /// Analyse une étiquette (indulgente sur la casse).
    pub fn depuis_etiquette(s: &str) -> Option<Self> {
        match s.trim().to_ascii_lowercase().as_str() {
            "gpu" => Some(ProfilNoeud::Gpu),
            "cpu" => Some(ProfilNoeud::Cpu),
            "edge" => Some(ProfilNoeud::Edge),
            _ => None,
        }
    }
}

/// Fiche d'identité d'un nœud, telle que vue par le routeur.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FicheNoeud {
    pub noeud_id: String,
    pub profil: ProfilNoeud,
    pub addr: String,
    pub taches_finies: u64,
    pub connecte_le_ms: u64,
}

// ───────────────────────── Tâches et résultats ─────────────────────────

/// Nature d'une tâche envoyée à un nœud.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum GenreTache {
    /// Une rangée de l'ensemble de Mandelbrot (valeurs d'échappement ≤ 255).
    MandelbrotLigne { y: u32, largeur: u32, hauteur: u32, max_iter: u32 },
    /// Compter les nombres premiers dans [debut, debut+longueur).
    SegmentPremiers { debut: u64, longueur: u64 },
    /// Preuve de travail SHA-256 : trouver un nonce avec `bits` bits à zéro en tête.
    PouSha { sel: u64, bits: u32, nonce_debut: u64, balayage: u64 },
}

/// Une tâche individuelle, morceau d'un job découpé par le routeur.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Tache {
    pub tache_id: u64,
    pub job_id: u64,
    pub genre: GenreTache,
}

/// Contenu du résultat renvoyé par un nœud.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ContenuResultat {
    LigneMandelbrot(Vec<u8>),
    NombrePremiers(u64),
    NoncePou { nonce: u64, empreinte: String },
    Introuvable,
}

/// Résultat d'une tâche (Phase 1 : identité déclarée ; Phase 2 : signature Ed25519).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResultatTache {
    pub tache_id: u64,
    pub job_id: u64,
    pub noeud_id: String,
    pub contenu: ContenuResultat,
    pub duree_ms: u64,
}

// ───────────────────────── Spécifications de job ─────────────────────────

/// Demande de job envoyée par un client (CLI ou interface) au routeur.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum SpecJob {
    Mandelbrot { largeur: u32, hauteur: u32, max_iter: u32 },
    Premiers { debut: u64, total: u64, segment: u64 },
    Pou { bits: u32, sel: u64, tranches: u64 },
}

impl SpecJob {
    /// Libellé court du genre de job.
    pub fn libelle(&self) -> &'static str {
        match self {
            SpecJob::Mandelbrot { .. } => "mandelbrot",
            SpecJob::Premiers { .. } => "premiers",
            SpecJob::Pou { .. } => "pow",
        }
    }
}

// ───────────────────────── Messages du protocole ─────────────────────────

/// Messages nœud → routeur.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum MsgNoeud {
    Bonjour { noeud_id: String, profil: ProfilNoeud },
    Resultat(ResultatTache),
}

/// Messages routeur → nœud.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum MsgRouteur {
    Bienvenue { noeud_id: String, capacite: u32 },
    Tache(Tache),
    Rien,
}

/// Messages client → routeur (CLI / interface native).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum MsgClient {
    Soumettre(SpecJob),
    Statut,
    Registre,
}

/// Instantané d'état du réseau, pour la supervision.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct InstantaneStatut {
    pub noeuds: Vec<FicheNoeud>,
    pub jobs_actifs: u64,
    pub jobs_finis: u64,
    pub blocs_registre: u64,
    pub demarre_le_ms: u64,
    pub libelle_version: String,
}

/// Réponses routeur → client.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum RepRouteur {
    JobAccepte { job_id: u64 },
    JobFini { job_id: u64, resume: String, hash_resultat: String, verifie: bool },
    Statut(InstantaneStatut),
    RegistreJson(String),
    Erreur(String),
}

// ───────────────────────── Outils communs ─────────────────────────

/// Horodatage UNIX en millisecondes.
pub fn maintenant_ms() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

/// SHA-256 hexadécimal d'un flux d'octets.
pub fn hex_sha256(donnees: &[u8]) -> String {
    let mut h = Sha256::new();
    h.update(donnees);
    let d: [u8; 32] = h.finalize().into();
    d.iter().map(|o| format!("{o:02x}")).collect()
}

/// Identifiant de nœud lisible et quasi unique : profil-hôte-empreinte.
pub fn identifiant_noeud(profil: ProfilNoeud) -> String {
    let hote = std::env::var("AETHER_HOTE")
        .ok()
        .filter(|s| !s.trim().is_empty())
        .unwrap_or_else(|| "local".to_string());
    let brut = format!("{}|{}|{}", hote, std::process::id(), maintenant_ms());
    let sel = hex_sha256(brut.as_bytes());
    format!("{}-{}-{}", profil.etiquette(), hote, &sel[..6])
}

// ───────────────────────── Noyaux de calcul ─────────────────────────

/// Rangée y d'une vue Mandelbrot [x ∈ −2..1 ; y ∈ −1.5..1.5].
/// Chaque point : nombre d'itérations avant évasion, borné à 255.
pub fn mandelbrot_ligne(y: u32, largeur: u32, hauteur: u32, max_iter: u32) -> Vec<u8> {
    let ci = if hauteur <= 1 {
        0.0
    } else {
        -1.5 + 3.0 * (y as f64) / (hauteur as f64 - 1.0)
    };
    let mut ligne = Vec::with_capacity(largeur as usize);
    for x in 0..largeur {
        let cr = if largeur <= 1 {
            0.0
        } else {
            -2.0 + 3.0 * (x as f64) / (largeur as f64 - 1.0)
        };
        let (mut zr, mut zi) = (0.0f64, 0.0f64);
        let mut n = 0u32;
        while n < max_iter && zr * zr + zi * zi <= 4.0 {
            let (zr2, zi2) = (zr * zr, zi * zi);
            zi = 2.0 * zr * zi + ci;
            zr = zr2 - zi2 + cr;
            n += 1;
        }
        ligne.push(n.min(255) as u8);
    }
    ligne
}

/// Test de primalité par divisions 6k ± 1.
pub fn est_premier(n: u64) -> bool {
    if n < 2 {
        return false;
    }
    if n % 2 == 0 {
        return n == 2;
    }
    if n % 3 == 0 {
        return n == 3;
    }
    let mut d = 5u64;
    while d.saturating_mul(d) <= n {
        if n % d == 0 || n % (d + 2) == 0 {
            return false;
        }
        d += 6;
    }
    true
}

/// Nombre de premiers dans [debut, debut+longueur).
pub fn compter_premiers(debut: u64, longueur: u64) -> u64 {
    (debut..debut.saturating_add(longueur)).filter(|n| est_premier(*n)).count() as u64
}

/// Empreinte PoW : sha256(sel_le || nonce_le).
pub fn empreinte_pow(sel: u64, nonce: u64) -> [u8; 32] {
    let mut h = Sha256::new();
    h.update(sel.to_le_bytes());
    h.update(nonce.to_le_bytes());
    h.finalize().into()
}

/// Vrai si l'empreinte commence par `bits` bits à zéro.
pub fn bits_zero_en_tete(emp: &[u8; 32], bits: u32) -> bool {
    let mut restants = bits;
    for &o in emp {
        if restants == 0 {
            return true;
        }
        let prenables = restants.min(8);
        if (o >> (8 - prenables)) != 0 {
            return false;
        }
        restants -= prenables;
    }
    restants == 0
}

/// Cherche un nonce dans [nonce_debut, nonce_debut+balayage).
pub fn chercher_pow(sel: u64, bits: u32, nonce_debut: u64, balayage: u64) -> Option<(u64, [u8; 32])> {
    for nonce in nonce_debut..nonce_debut.saturating_add(balayage) {
        let emp = empreinte_pow(sel, nonce);
        if bits_zero_en_tete(&emp, bits) {
            return Some((nonce, emp));
        }
    }
    None
}

/// Vérifie un nonce de preuve de travail (côté routeur, recomptage).
pub fn verifier_pow(sel: u64, bits: u32, nonce: u64) -> Option<[u8; 32]> {
    let emp = empreinte_pow(sel, nonce);
    if bits_zero_en_tete(&emp, bits) {
        Some(emp)
    } else {
        None
    }
}

/// Exécute une tâche localement — utilisée par les nœuds réels et les tests.
pub fn executer_tache(t: &Tache, noeud_id: &str) -> ResultatTache {
    let debut = std::time::Instant::now();
    let contenu = match &t.genre {
        GenreTache::MandelbrotLigne { y, largeur, hauteur, max_iter } => {
            ContenuResultat::LigneMandelbrot(mandelbrot_ligne(*y, *largeur, *hauteur, *max_iter))
        }
        GenreTache::SegmentPremiers { debut, longueur } => {
            ContenuResultat::NombrePremiers(compter_premiers(*debut, *longueur))
        }
        GenreTache::PouSha { sel, bits, nonce_debut, balayage } => match chercher_pow(*sel, *bits, *nonce_debut, *balayage) {
            Some((nonce, emp)) => ContenuResultat::NoncePou {
                nonce,
                empreinte: emp.iter().map(|o| format!("{o:02x}")).collect(),
            },
            None => ContenuResultat::Introuvable,
        },
    };
    ResultatTache {
        tache_id: t.tache_id,
        job_id: t.job_id,
        noeud_id: noeud_id.to_string(),
        contenu,
        duree_ms: debut.elapsed().as_millis() as u64,
    }
}

// ───────────────────────── Découpage (le routeur cognitif) ─────────────────────────

fn pousser(taches: &mut Vec<Tache>, suivant: &mut u64, job_id: u64, genre: GenreTache) {
    taches.push(Tache { tache_id: *suivant, job_id, genre });
    *suivant += 1;
}

/// Découpe une spécification de job en tâches distribuables.
/// C'est le « Découpage Tâche » du routeur cognitif.
pub fn decouper_job(spec: &SpecJob, job_id: u64, premier_id: u64) -> Vec<Tache> {
    let mut taches = Vec::new();
    let mut suivant = premier_id;
    match spec {
        SpecJob::Mandelbrot { largeur, hauteur, max_iter } => {
            for y in 0..*hauteur {
                pousser(
                    &mut taches,
                    &mut suivant,
                    job_id,
                    GenreTache::MandelbrotLigne { y, largeur: *largeur, hauteur: *hauteur, max_iter: *max_iter },
                );
            }
        }
        SpecJob::Premiers { debut, total, segment } => {
            let segment = (*segment).max(1);
            let mut fait = 0u64;
            while fait < *total {
                let longueur = (*total - fait).min(segment);
                pousser(
                    &mut taches,
                    &mut suivant,
                    job_id,
                    GenreTache::SegmentPremiers { debut: *debut + fait, longueur },
                );
                fait += longueur;
            }
        }
        SpecJob::Pou { bits, sel, tranches } => {
            for t in 0..*tranches {
                pousser(
                    &mut taches,
                    &mut suivant,
                    job_id,
                    GenreTache::PouSha { sel: *sel, bits: *bits, nonce_debut: t.saturating_mul(65_536), balayage: 65_536 },
                );
            }
        }
    }
    taches
}

// ───────────────────────── Assemblage et vérification ─────────────────────────

/// Contribution d'un nœud à un job (engagement SHA-256 — base de la Phase 2 ZK).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Contribution {
    pub noeud_id: String,
    pub taches: u64,
    pub engagement: String,
}

/// Résumé assemblé d'un job terminé.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResumeJob {
    pub job_id: u64,
    pub genre: String,
    pub hash_resultat: String,
    pub verifie: bool,
    pub resume: String,
    pub contributions: Vec<Contribution>,
}

/// Assemble les résultats d'un job, vérifie par recomptage, produit le résumé.
/// Phase 1 : vérification honnête par échantillonnage. Phase 2 : preuves zk-SNARK.
pub fn assembler_job(spec: &SpecJob, job_id: u64, taches: &[Tache], resultats: &[ResultatTache]) -> ResumeJob {
    use std::collections::BTreeMap;
    let par_tache: BTreeMap<u64, &ResultatTache> = resultats.iter().map(|r| (r.tache_id, r)).collect();

    // empreinte globale = sha256 du flux canonique des résultats triés par tâche
    let mut canon = String::new();
    for r in par_tache.values() {
        canon.push_str(&serde_json::to_string(r).unwrap_or_default());
        canon.push('|');
    }
    let hash_resultat = hex_sha256(canon.as_bytes());

    let mut verifie = true;
    let resume = match spec {
        SpecJob::Mandelbrot { largeur, hauteur, max_iter } => {
            // vérification par recomptage : rangées haute, milieu, basse
            for y in [0u32, hauteur / 2, hauteur.saturating_sub(1)] {
                let attendu = mandelbrot_ligne(y, *largeur, *hauteur, *max_iter);
                let t = taches.iter().find(|t| matches!(&t.genre, GenreTache::MandelbrotLigne { y: ty, .. } if *ty == y));
                if let Some(t) = t {
                    let conforme = matches!(
                        par_tache.get(&t.tache_id).map(|r| &r.contenu),
                        Some(ContenuResultat::LigneMandelbrot(recu)) if recu == &attendu
                    );
                    if !conforme {
                        verifie = false;
                    }
                }
            }
            format!("Mandelbrot {largeur}x{hauteur} — {hauteur} rangées assemblées")
        }
        SpecJob::Premiers { debut, total, .. } => {
            let mut somme = 0u64;
            for t in taches {
                if let Some(ContenuResultat::NombrePremiers(c)) = par_tache.get(&t.tache_id).map(|r| &r.contenu) {
                    somme += c;
                }
            }
            // vérification par recomptage du premier segment
            if let Some(premiere_tache) = taches.first() {
                if let GenreTache::SegmentPremiers { debut: d, longueur: l } = premiere_tache.genre {
                    let attendu = compter_premiers(d, l);
                    let ok = matches!(
                        par_tache.get(&premiere_tache.tache_id).map(|r| &r.contenu),
                        Some(ContenuResultat::NombrePremiers(c)) if *c == attendu
                    );
                    if !ok {
                        verifie = false;
                    }
                }
            }
            format!("Nombres premiers dans [{debut}, {}) : {somme} trouvés", debut.saturating_add(*total))
        }
        SpecJob::Pou { bits, sel, tranches } => {
            let mut trouve: Option<(u64, String)> = None;
            for r in par_tache.values() {
                if let ContenuResultat::NoncePou { nonce, empreinte } = &r.contenu {
                    if verifier_pow(*sel, *bits, *nonce).is_some() {
                        if trouve.is_none() {
                            trouve = Some((*nonce, empreinte.clone()));
                        }
                    } else {
                        verifie = false; // nonce frauduleux
                    }
                }
            }
            match trouve {
                Some((nonce, emp)) => {
                    let prefixe: String = emp.chars().take(16).collect();
                    format!("PoW {bits} bits validée — nonce {nonce} (empreinte {prefixe}…)")
                }
                None => {
                    verifie = false;
                    format!("PoW {bits} bits : aucun nonce trouvé dans {tranches} tranches")
                }
            }
        }
    };

    // contributions par nœud — engagement = sha256 du flux des résultats du nœud
    let mut par_noeud: BTreeMap<String, Vec<&ResultatTache>> = BTreeMap::new();
    for r in resultats {
        par_noeud.entry(r.noeud_id.clone()).or_default().push(r);
    }
    let contributions: Vec<Contribution> = par_noeud
        .iter()
        .map(|(id, liste)| {
            let flux = liste
                .iter()
                .map(|r| serde_json::to_string(r).unwrap_or_default())
                .collect::<Vec<_>>()
                .join("|");
            Contribution { noeud_id: id.clone(), taches: liste.len() as u64, engagement: hex_sha256(flux.as_bytes()) }
        })
        .collect();

    ResumeJob {
        job_id,
        genre: spec.libelle().to_string(),
        hash_resultat,
        verifie,
        resume,
        contributions,
    }
}

// ═════════════════════════ TESTS ═════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn mandelbrot_centre_et_bord() {
        // le centre (0,0) appartient à l'ensemble → max_iter
        let (w, h) = (101usize, 101usize);
        let centre = mandelbrot_ligne((h / 2) as u32, w as u32, h as u32, 255);
        assert_eq!(centre[w / 2], 255, "le centre doit rester 255 itérations");
        // le coin haut-gauche échappe vite
        let haut = mandelbrot_ligne(0, w as u32, h as u32, 255);
        assert!(haut[0] < 10, "le coin doit échapper en moins de 10 itérations");
    }

    #[test]
    fn premiers_valeurs_connues() {
        assert_eq!(compter_premiers(2, 100), 26, "[2, 102) : les 25 premiers ≤ 100, plus 101");
        assert_eq!(compter_premiers(0, 10), 4, "2, 3, 5, 7");
        assert!(est_premier(97));
        assert!(!est_premier(91), "91 = 7 × 13");
        assert!(!est_premier(1));
    }

    #[test]
    fn pow_trouve_et_verifie() {
        let sel = 42u64;
        let (nonce, emp) = chercher_pow(sel, 8, 0, 100_000).expect("8 bits trouvables en 100k essais");
        assert!(bits_zero_en_tete(&emp, 8));
        assert!(verifier_pow(sel, 8, nonce).is_some(), "le nonce trouvé doit se vérifier");
        // il doit exister des nonces qui ne satisfont pas la difficulté
        let mut mauvais_trouve = false;
        for n in 0..64u64 {
            if verifier_pow(sel, 8, n).is_none() {
                mauvais_trouve = true;
                break;
            }
        }
        assert!(mauvais_trouve, "il doit exister des nonces invalides");
    }

    #[test]
    fn decoupage_coherent() {
        let spec = SpecJob::Mandelbrot { largeur: 64, hauteur: 48, max_iter: 255 };
        let taches = decouper_job(&spec, 1, 100);
        assert_eq!(taches.len(), 48);
        assert!(taches.iter().all(|t| t.job_id == 1));
        assert!(taches.iter().all(|t| t.tache_id >= 100));

        let spec2 = SpecJob::Premiers { debut: 2, total: 10_000, segment: 2_500 };
        assert_eq!(decouper_job(&spec2, 2, 0).len(), 4);

        let spec3 = SpecJob::Pou { bits: 8, sel: 1, tranches: 6 };
        assert_eq!(decouper_job(&spec3, 3, 0).len(), 6);
    }

    #[test]
    fn assemblage_premiers_verifie() {
        let spec = SpecJob::Premiers { debut: 2, total: 1000, segment: 500 };
        let taches = decouper_job(&spec, 7, 0);
        let resultats: Vec<ResultatTache> = taches.iter().map(|t| executer_tache(t, "cpu-test")).collect();
        let r = assembler_job(&spec, 7, &taches, &resultats);
        assert!(r.verifie, "le recomptage doit confirmer");
        assert!(r.resume.contains("168"), "π(1000) = 168 ; résumé : {}", r.resume);
        assert_eq!(r.contributions.len(), 1);
        assert_eq!(r.contributions[0].taches, 2);
        assert_eq!(r.hash_resultat.len(), 64);
    }

    #[test]
    fn assemblage_detecte_falsification() {
        let spec = SpecJob::Premiers { debut: 2, total: 1000, segment: 500 };
        let taches = decouper_job(&spec, 8, 0);
        let mut resultats: Vec<ResultatTache> = taches.iter().map(|t| executer_tache(t, "gpu-test")).collect();
        // falsification : le nœud ment sur son segment
        if let ContenuResultat::NombrePremiers(c) = &mut resultats[0].contenu {
            *c += 1000;
        }
        let r = assembler_job(&spec, 8, &taches, &resultats);
        assert!(!r.verifie, "un compte falsifié doit être détecté");
    }

    #[test]
    fn assemblage_mandelbrot_et_pow() {
        let spec = SpecJob::Mandelbrot { largeur: 32, hauteur: 24, max_iter: 128 };
        let taches = decouper_job(&spec, 9, 0);
        let resultats: Vec<ResultatTache> = taches.iter().map(|t| executer_tache(t, "edge-test")).collect();
        let r = assembler_job(&spec, 9, &taches, &resultats);
        assert!(r.verifie);
        assert!(r.resume.contains("24 rangées"));

        let spec2 = SpecJob::Pou { bits: 8, sel: 7, tranches: 4 };
        let taches2 = decouper_job(&spec2, 10, 0);
        let resultats2: Vec<ResultatTache> = taches2.iter().map(|t| executer_tache(t, "gpu-test")).collect();
        let r2 = assembler_job(&spec2, 10, &taches2, &resultats2);
        assert!(r2.verifie, "PoW 8 bits doit être trouvée et vérifiée : {}", r2.resume);
    }

    #[test]
    fn profils_et_identites() {
        assert_eq!(ProfilNoeud::Gpu.capacite(), 4);
        assert_eq!(ProfilNoeud::Cpu.capacite(), 2);
        assert_eq!(ProfilNoeud::Edge.capacite(), 1);
        assert_eq!(ProfilNoeud::depuis_etiquette("GPU"), Some(ProfilNoeud::Gpu));
        assert_eq!(ProfilNoeud::depuis_etiquette("Edge"), Some(ProfilNoeud::Edge));
        assert_eq!(ProfilNoeud::depuis_etiquette("quantique"), None);
        let id = identifiant_noeud(ProfilNoeud::Gpu);
        assert!(id.starts_with("gpu-"), "l'identité commence par le profil : {id}");
    }
}
