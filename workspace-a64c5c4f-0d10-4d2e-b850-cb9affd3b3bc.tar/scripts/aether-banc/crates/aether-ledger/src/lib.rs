//! ═══════════════════════════════════════════════════════════════════
//! AETHER LEDGER — Registre append-only chaîné par SHA-256.
//! Chaque bloc porte les engagements de contribution des nœuds ;
//! c'est l'ancêtre honnête de la Phase 2 « Preuve ZK » du diagramme.
//! ═══════════════════════════════════════════════════════════════════

use aether_core::Contribution;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

/// Libellé du bloc genèse.
pub const GENESIS: &str = "GENESIS";

/// Un bloc du registre : un job terminé et ses contributions.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Bloc {
    pub index: u64,
    pub horodatage_ms: u64,
    pub job_id: u64,
    pub genre: String,
    pub contributions: Vec<Contribution>,
    pub hash_resultat: String,
    pub verifie: bool,
    pub hash_precedent: String,
    pub hash: String,
}

/// Empreinte canonique d'un bloc (le champ hash vidé).
fn empreinte(bloc_sans_hash: &Bloc) -> String {
    let canonique = serde_json::to_string(bloc_sans_hash).unwrap_or_default();
    let mut h = Sha256::new();
    h.update(canonique.as_bytes());
    h.finalize().iter().map(|o| format!("{o:02x}")).collect()
}

/// Le registre chaîné.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Registre {
    pub blocs: Vec<Bloc>,
}

impl Registre {
    /// Registre neuf avec bloc genèse.
    pub fn neuf() -> Self {
        let squelette = Bloc {
            index: 0,
            horodatage_ms: aether_core::maintenant_ms(),
            job_id: 0,
            genre: GENESIS.to_string(),
            contributions: Vec::new(),
            hash_resultat: String::new(),
            verifie: true,
            hash_precedent: "0".repeat(64),
            hash: String::new(),
        };
        let mut bloc = squelette.clone();
        bloc.hash = empreinte(&squelette);
        Registre { blocs: vec![bloc] }
    }

    /// Reconstruit un registre depuis des blocs sérialisés (fichier).
    pub fn depuis_blocs(blocs: Vec<Bloc>) -> Self {
        Registre { blocs }
    }

    pub fn len(&self) -> usize {
        self.blocs.len()
    }

    pub fn est_vide(&self) -> bool {
        self.blocs.is_empty()
    }

    pub fn dernier_hash(&self) -> String {
        self.blocs.last().map(|b| b.hash.clone()).unwrap_or_default()
    }

    /// Ajoute le bloc d'un job terminé et le retourne.
    pub fn ajouter(
        &mut self,
        job_id: u64,
        genre: &str,
        contributions: Vec<Contribution>,
        hash_resultat: &str,
        verifie: bool,
    ) -> Bloc {
        let squelette = Bloc {
            index: self.len() as u64,
            horodatage_ms: aether_core::maintenant_ms(),
            job_id,
            genre: genre.to_string(),
            contributions,
            hash_resultat: hash_resultat.to_string(),
            verifie,
            hash_precedent: self.dernier_hash(),
            hash: String::new(),
        };
        let mut bloc = squelette.clone();
        bloc.hash = empreinte(&squelette);
        self.blocs.push(bloc.clone());
        bloc
    }

    /// Vérifie toute la chaîne : ordre, maillons, empreintes.
    pub fn verifier(&self) -> Result<(), String> {
        let mut precedent = "0".repeat(64);
        for (i, bloc) in self.blocs.iter().enumerate() {
            if bloc.index != i as u64 {
                return Err(format!("bloc {i} : index {} inattendu", bloc.index));
            }
            if bloc.hash_precedent != precedent {
                return Err(format!("bloc {} : maillon cassé", bloc.index));
            }
            let mut squelette = bloc.clone();
            squelette.hash = String::new();
            let attendu = empreinte(&squelette);
            if bloc.hash != attendu {
                return Err(format!("bloc {} : empreinte invalide (falsifié ?)", bloc.index));
            }
            precedent = bloc.hash.clone();
        }
        Ok(())
    }

    /// Sérialisation lisible (fichier, CLI).
    pub fn en_json(&self) -> String {
        serde_json::to_string_pretty(self).unwrap_or_else(|_| "{}".to_string())
    }
}

// ═════════════════════════ TESTS ═════════════════════════

#[cfg(test)]
mod tests {
    use super::*;
    use aether_core::Contribution;

    fn contribution(noeud: &str, taches: u64) -> Contribution {
        Contribution {
            noeud_id: noeud.to_string(),
            taches,
            engagement: "ab".repeat(32),
        }
    }

    #[test]
    fn chaine_valide_puis_falsifiee() {
        let mut r = Registre::neuf();
        r.ajouter(1, "premiers", vec![contribution("gpu-1", 3)], &"c".repeat(64), true);
        r.ajouter(2, "pow", vec![contribution("cpu-1", 2)], &"d".repeat(64), true);
        r.ajouter(3, "mandelbrot", vec![contribution("edge-1", 1)], &"e".repeat(64), false);
        assert_eq!(r.len(), 4, "genèse + 3 blocs");
        assert!(r.verifier().is_ok(), "chaîne fraîchement construite : valide");

        // falsification d'une contribution → détection
        r.blocs[2].contributions[0].taches = 999;
        assert!(r.verifier().is_err(), "la falsification doit être détectée");
    }

    #[test]
    fn maillons_relies() {
        let mut r = Registre::neuf();
        let b1 = r.ajouter(1, "premiers", vec![], &"a".repeat(64), true);
        assert_eq!(b1.hash_precedent, r.blocs[0].hash, "lié au genèse");
        assert_eq!(r.dernier_hash(), b1.hash);
        assert_eq!(b1.index, 1);
    }

    #[test]
    fn export_import_json() {
        let mut r = Registre::neuf();
        r.ajouter(1, "pow", vec![contribution("gpu-9", 4)], &"f".repeat(64), true);
        let json = r.en_json();
        let relue: Registre = serde_json::from_str(&json).expect("json valide");
        assert_eq!(relue.len(), r.len());
        assert!(relue.verifier().is_ok(), "chaîne relue : valide");
    }
}
