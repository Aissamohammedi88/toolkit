#!/usr/bin/env bash
set -u
export GENT_HOME=/tmp/gent-e2e
cd /tmp
PORT=43112 "$GENT_HOME/runtime/current/bin/node" --max-semi-space-size=64 "$GENT_HOME/app/gent-server.js" > /tmp/e2e.log 2>&1 &
for i in $(seq 1 40); do curl -fsS http://127.0.0.1:43112/api/health >/dev/null 2>&1 && break; sleep 0.3; done
bash /home/z/my-project/download/gent/gent-upgrade-vision.sh 2>&1 | grep -E "✔|ERREUR" | head -6
for i in $(seq 1 30); do curl -fsS http://127.0.0.1:43112/api/health >/dev/null 2>&1 && break; sleep 0.3; done
agent-browser open http://127.0.0.1:43112/vision >/dev/null 2>&1
sleep 3.5
echo "── iframe : CSS + JS appliqués ? ──"
agent-browser frame "#preview"
echo "blocs .blk   : $(agent-browser eval 'document.querySelectorAll(".blk").length')"
echo "blocs posés  : $(agent-browser eval 'document.querySelectorAll(".blk.on").length')"
echo "h1 color     : $(agent-browser eval 'getComputedStyle(document.querySelector("h1")).color')"
agent-browser frame main
echo "── build JS sandboxé via UI ──"
agent-browser eval 'document.getElementById("file").value="hello.js"; document.getElementById("editor").value="console.log(\"VISION \"+(21*2));"; document.getElementById("btn-build").click()' > /dev/null
sleep 3
agent-browser eval 'document.getElementById("term").innerText.includes("VISION 42") && document.getElementById("term").innerText.includes("BUILD RÉUSSI") ? "JS : exécution sandbox OK + BUILD RÉUSSI" : "échec JS"'
agent-browser screenshot /tmp/render/vision-def.png > /dev/null 2>&1 && echo "capture OK"
agent-browser close >/dev/null 2>&1
pkill -f gent-server.js 2>/dev/null
true
