// plasma_bench.rs — tiny Fibonacci benchmark helper for Plasma Studio
// Compiled at first launch by nexus-plasma.sh if rustc is available.
// Output: JSON {"fib":N, "result":M, "ns":K} to stdout.

use std::env;
use std::time::Instant;

fn fib(n: u64) -> u64 {
    if n < 2 {
        return n;
    }
    let mut a: u64 = 0;
    let mut b: u64 = 1;
    for _ in 0..(n - 1) {
        let c = a + b;
        a = b;
        b = c;
    }
    b
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let n: u64 = args
        .get(1)
        .and_then(|s| s.parse::<u64>().ok())
        .unwrap_or(35);
    let n = n.min(45); // safety cap
    let start = Instant::now();
    let result = fib(n);
    let elapsed_ns = start.elapsed().as_nanos();
    println!(
        "{{\"fib\":{},\"result\":{},\"ns\":{}}}",
        n, result, elapsed_ns
    );
}
