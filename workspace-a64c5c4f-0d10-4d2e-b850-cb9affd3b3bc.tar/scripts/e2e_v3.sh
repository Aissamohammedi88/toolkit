#!/usr/bin/env bash
# E2E v3 — simule la machine de l'utilisateur : v1 → v2 (mélange) → v3 (démêlage)
# Stages : s1=v1 | s2=v2 | s3=v3 | s4=statique | s5=runtime réel | s6=verdict
set -uo pipefail
STAGE="${1:-s1}"
export HOME=/tmp/a3home
export APP_DIR="$HOME/Aether"
export npm_config_cache=/home/z/.npm
export npm_config_loglevel=error
export CI=1
DL=/home/z/my-project/download
LOG=/tmp/a3e2e.log
PASS=0; FAIL=0
ok() { echo "  ✓ $1"; PASS=$((PASS+1)); }
ko() { echo "  ✗ $1"; FAIL=$((FAIL+1)); }

case "$STAGE" in
s1)
  rm -rf /tmp/a3home && mkdir -p /tmp/a3home
  echo "── Installation v1 (base propre) ──"
  printf 'n\n' | bash "$DL/aether-bureau-tout-en-un.sh" > "$LOG" 2>&1
  RC=$?
  [ $RC -eq 0 ] && ok "installateur v1 rc=0" || ko "installateur v1 rc=$RC (voir $LOG)"
  [ -f "$APP_DIR/server/core.js" ] && ok "core.js v1 présent" || ko "core.js v1 absent"
  [ -d "$APP_DIR/node_modules/electron" ] && ok "electron installé" || ko "electron absent"
  tail -5 "$LOG"
  ;;
s2)
  echo "── Application v2 (état « machine utilisateur » : coffre + catalogue mélangé) ──"
  bash "$DL/aether-pro-v2.sh" > "$LOG" 2>&1
  RC=$?
  [ $RC -eq 0 ] && ok "upgrade v2 rc=0" || ko "upgrade v2 rc=$RC"
  [ -f "$APP_DIR/app.asar" ] && ok "coffre v2 présent" || ko "coffre v2 absent"
  (cd "$APP_DIR" && npx --yes @electron/asar list app.asar 2>/dev/null | grep -q "core/engine.js") \
    && ok "mélange scellé dans le coffre (v3 va le retirer)" || ko "mélange introuvable — état inattendu"
  ls -d "$APP_DIR"/.backup-v2-* >/dev/null 2>&1 && ok "sauvegarde v2 présente" || ko "pas de sauvegarde v2"
  ;;
s3)
  echo "── Upgrade v3 (démêlage + poste agentique) ──"
  bash "$DL/aether-v3-poste-agentique.sh" > "$LOG" 2>&1
  RC=$?
  [ $RC -eq 0 ] && ok "upgrade v3 rc=0" || { ko "upgrade v3 rc=$RC"; tail -30 "$LOG"; }
  grep -q "patched:7" "$LOG" && ok "core.js : 7 greffes v3" || ko "greffes core.js ≠ 7"
  grep -q "POSTE AGENTIQUE EN PLACE" "$LOG" && ok "rapport v3 : tout vert" || ko "rapport v3 en échec"
  grep -c "✓" "$LOG" | xargs -I{} echo "  · contrôles verts : {}"
  grep "✗" "$LOG" || echo "  · aucun ✗"
  tail -14 "$LOG"
  ;;
s4)
  echo "── Assertions statiques ──"
  [ ! -f "$APP_DIR/config/services.json" ] && ok "services.json (hub) RETIRÉ d'Aether" || ko "services.json encore là"
  [ ! -f "$APP_DIR/core/engine.js" ] && ok "core/engine.js (hub) RETIRÉ" || ko "engine.js encore là"
  [ ! -f "$APP_DIR/ui/engine.js" ] && ok "ui/engine.js (hub) RETIRÉ" || ko "ui/engine.js encore là"
  for jf in server/core.js core/router.js core/agents.js core/sysmon.js core/aether-v3.js ui/v3.js main.js main-app.js preload.js; do
    node --check "$APP_DIR/$jf" >/dev/null 2>&1 && ok "syntaxe $jf" || ko "syntaxe $jf"
  done
  grep -q "ollamaModels" "$APP_DIR/core/router.js" && ok "router v3 : auto-détection /api/tags" || ko "router sans auto-détection"
  grep -q "AETHER_V3" "$APP_DIR/server/core.js" && ok "core.js greffé v3" || ko "core.js non greffé"
  grep -q "app.asar/main.js" "$APP_DIR/main.js" && ok "main.js = chargeur production" || ko "chargeur absent"
  grep -q "AETHER_V3" "$APP_DIR/main-app.js" && ok "main-app.js branché au daemon" || ko "main-app.js sans branchement"
  grep -q "av3-dock" "$APP_DIR/ui/style.css" && ok "styles v3 présents" || ko "styles v3 absents"
  grep -q "ui/v3.js" "$APP_DIR/ui/index.html" && ok "index.html : dock branché" || ko "dock non branché"
  bash -n "$APP_DIR/scripts/aether-launch.sh" && ok "lanceur v3 syntaxe" || ko "lanceur cassé"
  [ -f "$APP_DIR/app.asar" ] && ok "coffre app.asar rescellé" || ko "app.asar absent"
  (cd "$APP_DIR" && npx --yes @electron/asar list app.asar 2>/dev/null | grep -q "core/agents.js") \
    && ok "coffre contient core/agents.js" || ko "coffre incomplet"
  (cd "$APP_DIR" && npx --yes @electron/asar list app.asar 2>/dev/null | grep -q "core/engine.js") \
    && ko "coffre contient encore engine.js !" || ok "coffre SANS le hub (engine.js exclu)"
  [ -f "$HOME/.aether/agents.json" ] || ok "agents.json se créera au boot (ok)"
  ;;
s5)
  echo "── Runtime réel : daemon + IA réelle + agents réels ──"
  pkill -f "node $APP_DIR/server/core.js" 2>/dev/null || true
  sleep 1
  export AETHER_HEADLESS=1 AETHER_PORT=8420
  nohup node "$APP_DIR/server/core.js" > /tmp/a3daemon.log 2>&1 &
  echo $! > /tmp/a3daemon.pid
  for i in $(seq 1 15); do curl -s --max-time 1 http://127.0.0.1:8420/api/health >/dev/null 2>&1 && break; sleep 1; done
  H="$(curl -s http://127.0.0.1:8420/api/health)"
  echo "$H" | grep -q '"ok":true' && ok "daemon en ligne : $H" || { ko "daemon mort"; cat /tmp/a3daemon.log; exit 1; }
  IA="$(curl -s http://127.0.0.1:8420/api/ia)"
  echo "$IA" | grep -q '"pollinations-text"' && ok "4 fournisseurs IA exposés" || ko "providers absents"
  echo "$IA" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{const j=JSON.parse(d);console.log("  · ollama présent :",j.ollama&&j.ollama.present,"| modèles :",JSON.stringify(j.ollama&&j.ollama.models));})'
  T="$(curl -s -X POST http://127.0.0.1:8420/api/ia/test -H 'Content-Type: application/json' -d '{"id":"pollinations-text"}')"
  echo "$T" | grep -q '"ok":true' && ok "TEST RÉEL Pollinations : $(echo "$T" | head -c 160)" || ko "Pollinations KO : $T"
  T2="$(curl -s -X POST http://127.0.0.1:8420/api/ia/test -H 'Content-Type: application/json' -d '{"id":"ollama"}')"
  echo "$T2" | grep -q '"ok":true' \
    && ok "repli Ollama→cléless PROUVÉ en direct ($(echo "$T2" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{const j=JSON.parse(d);console.log("provider:",j.provider);})'))" \
    || ko "repli cassé : $T2"
  SY="$(curl -s http://127.0.0.1:8420/api/sysmon)"
  NPROC="$(echo "$SY" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{const j=JSON.parse(d);console.log((j.sysmon.procs||[]).length);})')"
  [ "${NPROC:-0}" -ge 3 ] && ok "moniteur OS : $NPROC processus lus dans /proc" || ko "sysmon: $NPROC proc"
  echo "$SY" | grep -q '"ramTotalMb"' && ok "CPU/RAM réels exposés" || ko "ram absente"
  AG="$(curl -s -X POST http://127.0.0.1:8420/api/agents -H 'Content-Type: application/json' -d '{"task":"En UNE phrase : définition de HTTP. Puis donne une commande curl minimale vers https://example.com."}')"
  AGID="$(echo "$AG" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{const j=JSON.parse(d);console.log((j.agent&&j.agent.id)||"");})')"
  [ -n "$AGID" ] && ok "agent créé : $AGID" || { ko "création agent : $AG"; exit 1; }
  DONE=""
  for i in $(seq 1 90); do
    ST="$(curl -s http://127.0.0.1:8420/api/agents/$AGID | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{const j=JSON.parse(d);console.log((j.agent&&j.agent.status)||"?");})')"
    if [ "$ST" = "terminé" ] || [ "$ST" = "échec" ]; then DONE="$ST"; break; fi
    sleep 4
  done
  [ "$DONE" = "terminé" ] && ok "agent TERMINÉ (plan IA + étapes réelles)" || ko "agent non terminé : ${DONE:-timeout}"
  RES="$(curl -s http://127.0.0.1:8420/api/agents/$AGID/result)"
  [ ${#RES} -gt 100 ] && ok "résultat réel (${#RES} octets) : $(echo "$RES" | head -c 120 | tr '\n' ' ')…" || ko "résultat vide"
  [ -f "$APP_DIR/workspace/agents/$AGID/result.md" ] && ok "result.md écrit sur disque" || ko "result.md absent"
  [ -f "$HOME/.aether/agents.json" ] && ok "agents.json persisté" || ko "persistance absente"
  kill "$(cat /tmp/a3daemon.pid)" 2>/dev/null; sleep 1
  nohup node "$APP_DIR/server/core.js" > /tmp/a3daemon2.log 2>&1 &
  echo $! > /tmp/a3daemon.pid
  for i in $(seq 1 15); do curl -s --max-time 1 http://127.0.0.1:8420/api/health >/dev/null 2>&1 && break; sleep 1; done
  curl -s http://127.0.0.1:8420/api/agents | grep -q "$AGID" && ok "agent SURVIT au redémarrage du daemon" || ko "agent perdu au redémarrage"
  kill "$(cat /tmp/a3daemon.pid)" 2>/dev/null || true
  ;;
s6)
  echo "── Verdict ──"
  echo "  PASS=$PASS FAIL=$FAIL"
  ;;
esac
echo "STAGE $STAGE : PASS=$PASS FAIL=$FAIL"
exit $FAIL
