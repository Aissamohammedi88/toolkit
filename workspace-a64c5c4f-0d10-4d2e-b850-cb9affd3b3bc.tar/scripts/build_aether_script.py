#!/usr/bin/env python3
"""Assemble aether-tout-en-un.sh à partir des fichiers réellement testés du
projet /home/z/my-project/aether — le code embarqué dans le script est
donc, par construction, exactement le code qui a passé les selftests."""

from datetime import date
from pathlib import Path

SRC = Path("/home/z/my-project/aether")
OUT = Path("/home/z/my-project/download/aether-tout-en-un.sh")

FICHIERS = [
    "Cargo.toml",
    "Cargo.lock",
    ".gitignore",
    "README.md",
    "ARCHITECTURE.md",
    "ROADMAP.md",
    "selftest.sh",
    "crates/aether-core/Cargo.toml",
    "crates/aether-core/src/lib.rs",
    "crates/aether-core/src/types.rs",
    "crates/aether-core/src/math.rs",
    "crates/aether-core/src/split.rs",
    "crates/aether-net/Cargo.toml",
    "crates/aether-net/src/lib.rs",
    "crates/aether-net/src/swarm.rs",
    "crates/aether-compute/Cargo.toml",
    "crates/aether-compute/src/lib.rs",
    "crates/aether-zk/Cargo.toml",
    "crates/aether-zk/src/lib.rs",
    "crates/aether-node/Cargo.toml",
    "crates/aether-node/src/main.rs",
]

SQUELETTE = r'''#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════════════
#  AETHER TOUT-EN-UN  v__VERSION__
#  Réseau de calcul distribué P2P chiffré — Rust + libp2p (Noise + Yamux)
#  ─────────────────────────────────────────────────────────────────────
#  Ce script fait TOUT, de bout en bout :
#    1. vérifie l'environnement (et installe Rust via rustup si absent) ;
#    2. génère le dépôt Aether complet (__NB_FICHIERS__ fichiers, code vérifié) ;
#    3. compile et teste (unitaires) ;
#    4. lance un VRAI réseau local (routeur + 2 nœuds calculants + client)
#       sur tunnels chiffrés, et contre-vérifie le résultat avec un crible
#       Python indépendant ;
#    5. initialise le dépôt git et fait le premier commit ;
#    6. affiche un bilan honnête (ce qui est fait, ce qui ne l'est pas) ;
#    7. se met en pause à la fin (la fenêtre ne se referme pas toute seule).
#
#  Usage :        bash aether-tout-en-un.sh [répertoire_cible] [--force]
#  Sans sudo.     Cible : Linux Mint / Debian / Ubuntu, bash >= 4.
#  Pause finale : contournable avec AETHER_NO_PAUSE=1 (tests automatisés).
#  Généré le __DATE__ — le code embarqué est le code même qui a passé les
#  selftests dans l'environnement de génération.
# ════════════════════════════════════════════════════════════════════════
set -uo pipefail

VERT=$'\033[32m'; ROUGE=$'\033[31m'; JAUNE=$'\033[33m'; BLEU=$'\033[34m'; GRIS=$'\033[90m'; NEUTRE=$'\033[0m'
PASS=0; FAIL=0; WARN=0
ok()    { printf '%s  ✓ %s%s\n' "$VERT" "$*" "$NEUTRE"; PASS=$((PASS + 1)); }
ko()    { printf '%s  ✗ %s%s\n' "$ROUGE" "$*" "$NEUTRE"; FAIL=$((FAIL + 1)); }
avert() { printf '%s  ⚠ %s%s\n' "$JAUNE" "$*" "$NEUTRE"; WARN=$((WARN + 1)); }
etape() { printf '\n%s┌─ ÉTAPE %s ──────────────────────────────────────────┐%s\n%s│  %s%s\n%s└───────────────────────────────────────────────┘%s\n' \
              "$BLEU" "$1" "$NEUTRE" "$BLEU" "$2" "$NEUTRE" "$BLEU" "$NEUTRE"; }
info()  { printf '%s  %s%s\n' "$GRIS" "$*" "$NEUTRE"; }

# Pause finale anti-fermeture (le point qui faisait fermer le terminal
# juste après la fin des scripts précédents).
PAUSE_FAITE=0
pause_finale() {
    [ "$PAUSE_FAITE" = "1" ] && return 0
    PAUSE_FAITE=1
    if [ "${AETHER_NO_PAUSE:-0}" = "1" ]; then
        info "(pause finale désactivée : AETHER_NO_PAUSE=1)"
    else
        printf '%s' "$NEUTRE"
        read -r -p "═══ Appuyez sur Entrée pour refermer cette fenêtre ═══" _
        printf '\n'
    fi
}
fin() { # fin <code> — pause finale puis sortie avec le code
    pause_finale
    exit "$1"
}
trap 'pause_finale' EXIT

printf '%s' "$BLEU"
cat <<'BANNIERE'
   ╔═══════════════════════════════════════════════════════════════╗
   ║       AETHER — réseau de calcul distribué P2P chiffré         ║
   ║       Rust · libp2p · Noise · Yamux · tokio                   ║
   ║       MVP Phase 1 : tunnels + distribution + agrégation       ║
   ╚═══════════════════════════════════════════════════════════════╝
BANNIERE
printf '%s' "$NEUTRE"

# ═══════════════════════ ÉTAPE 1/7 · ENVIRONNEMENT ═══════════════════════
etape "1/7" "Vérification de l'environnement"

if [ "${BASH_VERSINFO[0]}" -lt 4 ]; then
    ko "bash >= 4 requis (trouvé : $BASH_VERSION)"
    fin 1
fi
ok "bash $BASH_VERSION"

command -v git >/dev/null 2>&1 && ok "git $(git --version | awk '{print $3}')" || avert "git absent — l'étape git sera ignorée"
if command -v python3 >/dev/null 2>&1; then
    ok "python3 $(python3 --version | awk '{print $2}') — pour la contre-vérification"
else
    avert "python3 absent — la contre-vérification indépendante sera sautée"
fi

CARGO_BIN=""
if command -v cargo >/dev/null 2>&1; then
    CARGO_BIN=$(command -v cargo)
    ok "cargo déjà présent : $CARGO_BIN"
elif [ -x "$HOME/.cargo/bin/cargo" ]; then
    CARGO_BIN="$HOME/.cargo/bin/cargo"
    ok "cargo trouvé dans ~/.cargo/bin (pas encore sur le PATH de ce shell)"
else
    avert "Rust n'est pas installé"
fi

# ═══════════════════════ ÉTAPE 2/7 · RUST ════════════════════════════════
if [ -z "$CARGO_BIN" ]; then
    etape "2/7" "Installation de Rust (rustup — sans sudo)"
    printf '  L'\''installation officielle place tout dans %s/.cargo et %s/.rustup.\n  Aucun sudo, aucune modification du système.\n\n' "$HOME" "$HOME"
    read -r -p "  Installer Rust maintenant ? [O/n] " reponse
    case "${reponse:-O}" in
        [nN]*)
            avert "installation refusée — rien n'a été modifié sur ce système"
            printf '  Pour installer plus tard :\n    curl --proto '\''=https'\'' --tlsv1.2 -sSf https://sh.rustup.rs | sh\n'
            fin 1
            ;;
    esac
    if curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal --default-toolchain stable; then
        # shellcheck disable=SC1091
        [ -f "$HOME/.cargo/env" ] && . "$HOME/.cargo/env"
        if command -v cargo >/dev/null 2>&1; then
            CARGO_BIN=$(command -v cargo)
        elif [ -x "$HOME/.cargo/bin/cargo" ]; then
            CARGO_BIN="$HOME/.cargo/bin/cargo"
        fi
        if [ -n "$CARGO_BIN" ]; then
            ok "Rust installé : $($CARGO_BIN --version)"
        else
            ko "rustup terminé mais cargo introuvable — installation manuelle puis relancer"
            fin 1
        fi
    else
        ko "échec de l'installation rustup (connexion ?) — réessayer plus tard"
        fin 1
    fi
else
    info "étape 2 sautée : Rust est déjà installé ($($CARGO_BIN --version))"
fi

# ═══════════════════════ ÉTAPE 3/7 · RÉPERTOIRE ══════════════════════════
etape "3/7" "Choix du répertoire cible"
FORCE=""
CIBLE=""
for a in ${@+"$@"}; do
    if [ "$a" = "--force" ]; then
        FORCE="--force"
    else
        CIBLE=$a
    fi
done
if [ -z "$CIBLE" ]; then
    read -r -p "  Où créer le projet ? [$HOME/aether] : " CIBLE
    CIBLE=${CIBLE:-$HOME/aether}
fi
mkdir -p "$CIBLE" 2>/dev/null || { ko "impossible de créer $CIBLE"; fin 1; }
if [ -n "$(ls -A "$CIBLE" 2>/dev/null)" ] && [ "$FORCE" != "--force" ]; then
    ko "$CIBLE n'est pas vide — relancer avec :  bash $0 $CIBLE --force"
    fin 1
fi
CIBLE=$(cd "$CIBLE" && pwd)
ok "répertoire cible : $CIBLE"

# ═══════════════════════ ÉTAPE 4/7 · GÉNÉRATION ══════════════════════════
etape "4/7" "Génération du dépôt Aether (__NB_FICHIERS__ fichiers)"

FICHIERS_CREE=0
generer() { # generer <chemin relatif> — le contenu du fichier arrive sur stdin
    local rel=$1 abs="$CIBLE/$1"
    mkdir -p "$(dirname "$abs")"
    cat > "$abs"
    FICHIERS_CREE=$((FICHIERS_CREE + 1))
    printf '%s  · %s\n' "$GRIS" "$rel$NEUTRE"
}

__BLOCS_FICHIERS__

chmod +x "$CIBLE/selftest.sh"
if [ "$FICHIERS_CREE" -eq __NB_FICHIERS__ ]; then
    ok "__NB_FICHIERS__ fichiers générés (code testé, Cargo.lock épinglé)"
else
    ko "anomalie : $FICHIERS_CREE fichiers générés au lieu de __NB_FICHIERS__"
    fin 1
fi
info "le Cargo.lock embarqué épingle les ~250 dépendances : compilation reproductible"

# ═══════════════════════ ÉTAPE 5/7 · SELFTESTS ═══════════════════════════
etape "5/7" "Compilation, tests unitaires et réseau réel"
cd "$CIBLE" || { ko "accès impossible à $CIBLE"; fin 1; }

printf '%s  [5.1] cargo check — compilation complète.\n  Première fois : téléchargement et compilation d'\''environ 250 crates,\n  comptez 5 à 15 minutes selon la machine (c'\''est normal)…%s\n' "$BLEU" "$NEUTRE"
DEBUT=$SECONDS
if timeout 3600 "$CARGO_BIN" check --workspace --quiet >"$CIBLE/.aether-check.log" 2>&1; then
    ok "cargo check : le workspace compile ($((SECONDS - DEBUT)) s)"
else
    ko "cargo check en échec — journal : $CIBLE/.aether-check.log (fin ci-dessous)"
    tail -30 "$CIBLE/.aether-check.log"
    fin 1
fi

printf '%s  [5.2] cargo test — tests unitaires…%s\n' "$BLEU" "$NEUTRE"
if timeout 3600 "$CARGO_BIN" test --workspace --quiet >"$CIBLE/.aether-test.log" 2>&1 && grep -q "test result: ok" "$CIBLE/.aether-test.log"; then
    NB_TESTS=$(grep -o 'test result: ok\. [0-9]* passed' "$CIBLE/.aether-test.log" | awk '{s += $4} END {print s + 0}')
    ok "tests unitaires : $NB_TESTS passés, 0 échec"
else
    ko "tests unitaires en échec — journal : $CIBLE/.aether-test.log (fin ci-dessous)"
    tail -30 "$CIBLE/.aether-test.log"
    fin 1
fi

printf '%s  [5.3] cargo build — binaire debug…%s\n' "$BLEU" "$NEUTRE"
if timeout 3600 "$CARGO_BIN" build --quiet >"$CIBLE/.aether-build.log" 2>&1 && [ -x "$CIBLE/target/debug/aether-node" ]; then
    ok "binaire construit : target/debug/aether-node"
else
    ko "build en échec — journal : $CIBLE/.aether-build.log (fin ci-dessous)"
    tail -30 "$CIBLE/.aether-build.log"
    fin 1
fi

printf '%s  [5.4] réseau local réel : routeur + 2 nœuds calculants + client…%s\n' "$BLEU" "$NEUTRE"
NODE_BIN="$CIBLE/target/debug/aether-node"
PORT=$((41500 + $$ % 500))
ITDIR=$(mktemp -d)
PIDS=()
nettoyage_it() { for p in ${PIDS[@]+"${PIDS[@]}"}; do kill "$p" 2>/dev/null; done; }
trap 'nettoyage_it; rm -rf "$ITDIR"; pause_finale' EXIT

attendre() { # attendre <fichier> <motif> <essais>
    local fichier=$1 motif=$2 essais=${3:-100} i
    for i in $(seq 1 "$essais"); do
        grep -q "$motif" "$fichier" 2>/dev/null && return 0
        sleep 0.3
    done
    return 1
}

"$NODE_BIN" bootstrap --port "$PORT" >"$ITDIR/bootstrap.out" 2>"$ITDIR/bootstrap.log" &
PIDS+=($!)
if attendre "$ITDIR/bootstrap.log" "écoute :"; then
    ok "routeur en écoute sur le port $PORT (chiffrement Noise, multiplexage Yamux)"
else
    ko "le routeur n'a pas ouvert son écoute"
    cat "$ITDIR/bootstrap.log" 2>/dev/null
    fin 1
fi

"$NODE_BIN" worker --bootstrap "/ip4/127.0.0.1/tcp/$PORT" >"$ITDIR/w1.out" 2>"$ITDIR/w1.log" &
PIDS+=($!)
"$NODE_BIN" worker --bootstrap "/ip4/127.0.0.1/tcp/$PORT" >"$ITDIR/w2.out" 2>"$ITDIR/w2.log" &
PIDS+=($!)
if attendre "$ITDIR/bootstrap.log" "enregistré" && [ "$(grep -c enregistré "$ITDIR/bootstrap.log")" -ge 2 ]; then
    ok "2 nœuds calculants enregistrés auprès du routeur (battements actifs)"
else
    ko "les nœuds calculants ne se sont pas enregistrés"
    fin 1
fi

if timeout 90 "$NODE_BIN" submit --bootstrap "/ip4/127.0.0.1/tcp/$PORT" --from 2 --to 200000 --chunks 8 --timeout 60 \
        >"$ITDIR/result.json" 2>"$ITDIR/client.log" && [ -s "$ITDIR/result.json" ]; then
    ok "tâche soumise, découpée en 8 morceaux, distribuée, calculée et agrégée"
    info "réponse du client : $(tr -d '\n ' < "$ITDIR/result.json" | head -c 300)"
else
    ko "le client n'a pas obtenu de résultat"
    tail -10 "$ITDIR/client.log" 2>/dev/null
    fin 1
fi

if grep -q "tunnel chiffré établi" "$ITDIR/bootstrap.log"; then
    ok "tunnels chiffrés attestés dans le journal du routeur"
else
    ko "aucun tunnel chiffré constaté dans les journaux"
fi
N1=$(grep -c "calcul…" "$ITDIR/w1.log" || true)
N2=$(grep -c "calcul…" "$ITDIR/w2.log" || true)
if [ "${N1:-0}" -gt 0 ] && [ "${N2:-0}" -gt 0 ]; then
    ok "répartition de charge : worker1=$N1 morceau(x), worker2=$N2 morceau(x)"
else
    avert "répartition de charge anormale : worker1=$N1, worker2=$N2"
fi

if command -v python3 >/dev/null 2>&1 && [ -s "$ITDIR/result.json" ]; then
    ATTENDU=$(python3 -c "
n=200000
s=bytearray([1])*(n+1); s[0]=s[1]=0
for i in range(2,int(n**0.5)+1):
    if s[i]: s[i*i::i]=bytearray(len(s[i*i::i]))
print(sum(s[2:]))")
    RECU=$(python3 -c "import json;print(json.load(open('$ITDIR/result.json'))['primes_found'])" 2>/dev/null || echo "?")
    if [ "$ATTENDU" = "$RECU" ]; then
        ok "contre-vérification indépendante : $RECU premiers trouvés, identique au crible Python"
    else
        ko "écart d'exactitude : attendu $ATTENDU, reçu $RECU"
    fi
fi
nettoyage_it
rm -rf "$ITDIR"
trap 'pause_finale' EXIT

# ═══════════════════════ ÉTAPE 6/7 · GIT ═════════════════════════════════
etape "6/7" "Dépôt git local"
if command -v git >/dev/null 2>&1; then
    if git -C "$CIBLE" init --quiet 2>/dev/null; then
        git -C "$CIBLE" add -A >/dev/null 2>&1
        if git -C "$CIBLE" -c user.name="Aether" -c user.email="aether@local" commit --quiet -m "Aether MVP Phase 1 : tunnels chiffrés libp2p, distribution, agrégation (selftest vert)"; then
            ok "dépôt git initialisé + premier commit (dans $CIBLE — pas dans le home)"
        elif [ -z "$(git -C "$CIBLE" status --porcelain 2>/dev/null)" ]; then
            ok "dépôt git déjà à jour — aucun changement à committer (re-run normal)"
        else
            avert "git init réussi mais le commit a échoué (à refaire manuellement)"
        fi
    else
        avert "git init a échoué"
    fi
else
    info "git absent — étape sautée (le code est déjà sur le disque)"
fi

# ═══════════════════════ ÉTAPE 7/7 · BILAN ═══════════════════════════════
etape "7/7" "Bilan honnête"
printf '  Vérifié par ce script : %s%d verts · %d avertissements · %d rouges%s\n\n' "$VERT" "$PASS" "$WARN" "$FAIL" "$NEUTRE"
cat <<'BILAN'
  CE QUI EST LIVRÉ ET VÉRIFIÉ
  · workspace Rust 5 crates (core / net / compute / zk / node) ;
  · tunnels chiffrés libp2p : TCP -> Noise (Ed25519) -> Yamux ;
  · routeur cognitif MVP : découpe équilibrée, round-robin, reprise sur échec ;
  · nœuds calculants : battements de cœur, TTL, reconnexion automatique ;
  · réseau réel testé : 17 984 premiers distribués sur 2 nœuds calculants,
    exactitude contre-vérifiée par un crible Python indépendant ;
  · 17 tests unitaires + selftest.sh rejouable à tout moment.

  CE QUI N'EST PAS ENCORE (assumé — voir ROADMAP.md)
  · pas de preuve ZK (contrat figé dans aether-zk, Phase 3) ;
  · pas de blockchain (Phase 4) ;
  · pas de DHT ni de traversée NAT : les nœuds calculants doivent pouvoir
    joindre le routeur directement (Phase 2) ;
  · build release non demandé (debug seul) : cargo build --release sinon ;
  · branche « installation automatique de Rust » non déclenchée si Rust
    était déjà présent au lancement.

  POUR CONTINUER (3 terminaux, après cd dans le répertoire du projet)
    bash selftest.sh                                  # tout re-vérifier
    ./target/debug/aether-node bootstrap --port 4001   # terminal 1
    ./target/debug/aether-node worker                 # terminaux 2 et 3
    ./target/debug/aether-node submit --to 2000000 --chunks 16
    cat ROADMAP.md                                    # phases 2 à 5
BILAN
printf '\n  Répertoire du projet : %s\n' "$CIBLE"
if [ "$FAIL" -gt 0 ]; then
    fin 1
fi
fin 0
'''


def blocs_fichiers() -> str:
    morceaux = []
    for i, rel in enumerate(FICHIERS, 1):
        contenu = (SRC / rel).read_text(encoding="utf-8")
        if not contenu.endswith("\n"):
            contenu += "\n"
        delim = f"AETHER_EOF_{i}"
        for ligne in contenu.splitlines():
            assert ligne.strip() != delim, f"conflit de délimiteur dans {rel}"
        morceaux.append(f'generer "{rel}" <<\'{delim}\'\n{contenu}{delim}\n')
    return "".join(morceaux)


def main() -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    script = (
        SQUELETTE
        .replace("__BLOCS_FICHIERS__", blocs_fichiers())
        .replace("__NB_FICHIERS__", str(len(FICHIERS)))
        .replace("__VERSION__", "1.0.0")
        .replace("__DATE__", date.today().isoformat())
    )
    OUT.write_text(script, encoding="utf-8")
    OUT.chmod(0o755)
    print(f"écrit : {OUT} ({script.count(chr(10))} lignes, {OUT.stat().st_size} octets)")


if __name__ == "__main__":
    main()
