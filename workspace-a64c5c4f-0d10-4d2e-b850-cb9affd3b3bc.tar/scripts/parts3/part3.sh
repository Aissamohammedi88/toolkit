
# ════════════════════════════════════════════════════════════════════
phase 4 "AGENTS EN ARRIÈRE-PLAN — file réelle, étapes, journal, résultat"
# ════════════════════════════════════════════════════════════════════
mkdir -p "$WORKSPACE/agents" "$CONF_DIR"

cat > core/agents.js <<'AE_AGENTS_V3'
'use strict';
// NEXUS AETHER v3 — agents en arrière-plan.
// Un agent = une tâche → plan par l'IA maîtresse → étapes exécutées une à une
// (VRAIS appels IA) → résultat écrit dans workspace/agents/<id>/result.md.
// La file vit DANS le daemon persistant : fermer la fenêtre n'arrête rien.
const fs = require('fs');
const path = require('path');
const os = require('os');
const { chat, loadConfig } = require('./router');
const { remember } = require('./memory');

const HOME = os.homedir();
const STORE = path.join(HOME, '.aether', 'agents.json');

let agents = {};
let timer = null;

function wsDir() {
  return path.join(process.env.AETHER_WORKSPACE || path.join(HOME, 'Aether', 'workspace'), 'agents');
}
function cfgVal(k, d) {
  try {
    const c = loadConfig();
    return (c.agentique && typeof c.agentique[k] !== 'undefined') ? c.agentique[k] : d;
  } catch (e) { return d; }
}
function save() {
  try {
    fs.mkdirSync(path.dirname(STORE), { recursive: true });
    fs.writeFileSync(STORE, JSON.stringify(agents, null, 2) + '\n');
  } catch (e) {}
}
function load() {
  try { agents = JSON.parse(fs.readFileSync(STORE, 'utf8')) || {}; } catch (e) { agents = {}; }
  // au boot du daemon : les agents « en cours » deviennent « interrompu » (honnête)
  Object.keys(agents).forEach(function (id) {
    if (agents[id].status === 'en-cours') { agents[id].status = 'interrompu'; log(agents[id], 'daemon redémarré — agent marqué interrompu'); }
  });
  save();
}
function log(a, line) {
  a.log = a.log || [];
  a.log.push({ t: Date.now(), line: String(line).slice(0, 600) });
  if (a.log.length > 400) a.log = a.log.slice(-300);
}
function broadcast(a) {
  try {
    if (global.__AETHER_V3_WS) global.__AETHER_V3_WS({
      kind: 'agent', id: a.id, status: a.status, stepIndex: a.stepIndex,
      steps: (a.steps || []).map(function (s) { return { label: s.label, status: s.status }; })
    });
  } catch (e) {}
}
function summary(a) {
  return {
    id: a.id, task: a.task, status: a.status, createdAt: a.createdAt, endedAt: a.endedAt,
    stepIndex: a.stepIndex, steps: (a.steps || []).map(function (s) { return { label: s.label, status: s.status }; }),
    resultFile: a.resultFile || null, error: a.error || null,
    logTail: (a.log || []).slice(-12)
  };
}
function create(task, opts) {
  const id = 'ag-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);
  const a = {
    id: id, task: String(task || '').slice(0, 4000), status: 'en-file',
    createdAt: Date.now(), startedAt: null, endedAt: null,
    steps: [], stepIndex: -1, log: [], resultFile: null, error: null,
    cancelRequested: false
  };
  agents[id] = a;
  log(a, 'agent créé — placé en file d\u2019attente');
  save(); kick(); broadcast(a);
  return summary(a);
}
function get(id) { const a = agents[id]; return a ? summary(a) : null; }
function detail(id) { return agents[id] ? JSON.parse(JSON.stringify(agents[id])) : null; }
function list() {
  return Object.keys(agents).map(function (id) { return summary(agents[id]); })
    .sort(function (x, y) { return y.createdAt - x.createdAt; }).slice(0, 60);
}
function cancel(id) {
  const a = agents[id]; if (!a) return null;
  if (a.status === 'en-file') { a.status = 'annulé'; a.endedAt = Date.now(); log(a, 'annulé (encore en file)'); }
  else if (a.status === 'en-cours') { a.cancelRequested = true; log(a, 'annulation demandée — arrêt à la fin de l\u2019étape en cours'); }
  save(); broadcast(a); return summary(a);
}
function runningCount() {
  return Object.keys(agents).filter(function (id) { return agents[id].status === 'en-cours'; }).length;
}
function kick() { if (!timer) timer = setInterval(tick, 1500); }
function tick() {
  const max = Math.max(1, Math.min(4, parseInt(cfgVal('maxConcurrent', 2), 10) || 2));
  if (runningCount() >= max) return;
  const next = Object.keys(agents).map(function (id) { return agents[id]; })
    .filter(function (a) { return a.status === 'en-file'; })
    .sort(function (x, y) { return x.createdAt - y.createdAt; })[0];
  if (next) run(next);
  const busy = Object.keys(agents).some(function (id) {
    return agents[id].status === 'en-file' || agents[id].status === 'en-cours';
  });
  if (!busy && timer) { clearInterval(timer); timer = null; }
}
function extractJson(t) {
  const m = String(t || '').match(/\{[\s\S]*\}/);
  if (!m) return null;
  try { return JSON.parse(m[0]); } catch (e) { return null; }
}
async function callIA(messages) {
  const out = await chat(messages, {});
  return String(out.text || '');
}
async function run(a) {
  a.status = 'en-cours'; a.startedAt = Date.now(); save(); broadcast(a);
  try {
    log(a, 'IA maîtresse : planification…'); broadcast(a);
    let planTxt = '';
    try {
      planTxt = await callIA([
        { role: 'system', content: 'Tu es le planificateur d\u2019agents de NEXUS AETHER. Découpe la tâche en 2 à 4 étapes courtes et concrètes. Réponds UNIQUEMENT avec un JSON {"etapes":["...","..."]}.' },
        { role: 'user', content: a.task }
      ]);
    } catch (e) { throw new Error('IA maîtresse injoignable : ' + String((e && e.message) || e)); }
    const plan = extractJson(planTxt);
    const etapes = (plan && Array.isArray(plan.etapes) && plan.etapes.length)
      ? plan.etapes : ['Analyser la tâche', 'Produire le résultat', 'Vérifier et rédiger'];
    a.steps = etapes.slice(0, 5).map(function (s) { return { label: String(s).slice(0, 200), status: 'en-attente' }; });
    save(); broadcast(a);
    let context = '';
    for (let i = 0; i < a.steps.length; i++) {
      if (a.cancelRequested) throw new Error('annulé à la demande de l\u2019utilisateur');
      a.stepIndex = i; a.steps[i].status = 'en-cours'; save(); broadcast(a);
      const out = await callIA([
        { role: 'system', content: 'Tu es un agent de NEXUS AETHER. Exécute UNE étape de façon directe et utile, sans bavardage.' },
        { role: 'user', content: 'Tâche globale : ' + a.task + '\nContexte des étapes précédentes :\n' + (context || '(aucun)') + '\n\nÉtape à exécuter : ' + a.steps[i].label }
      ]);
      a.steps[i].status = 'terminé';
      a.steps[i].resume = String(out).slice(0, 300);
      context += '\n[' + a.steps[i].label + ']\n' + String(out).slice(0, 1500);
      log(a, 'étape ' + (i + 1) + '/' + a.steps.length + ' terminée'); save(); broadcast(a);
    }
    if (a.cancelRequested) throw new Error('annulé à la demande de l\u2019utilisateur');
    const dir = path.join(wsDir(), a.id);
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, 'result.md');
    fs.writeFileSync(file, '# Agent ' + a.id + '\n\n**Tâche :** ' + a.task + '\n\n' + context.trim() + '\n');
    a.resultFile = file; a.status = 'terminé'; a.endedAt = Date.now();
    log(a, 'terminé — résultat : ' + file);
    try { remember('agent', 'agent ' + a.id + ' terminé : ' + a.task.slice(0, 120)); } catch (e) {}
    save(); broadcast(a);
  } catch (e) {
    a.status = a.cancelRequested ? 'annulé' : 'échec';
    a.error = String((e && e.message) || e); a.endedAt = Date.now();
    log(a, 'échec : ' + a.error); save(); broadcast(a);
  }
}
module.exports = { create: create, list: list, get: get, detail: detail, cancel: cancel, load: load, runningCount: runningCount };
AE_AGENTS_V3
ok "core/agents.js — file d'attente réelle, plan IA, étapes, résultat sur disque, survit à la fermeture"
chk "syntaxe agents.js" "node --check '$APP_DIR/core/agents.js'"

# ════════════════════════════════════════════════════════════════════
phase 5 "MONITEUR OS AGENTIQUE — CPU/RAM réels + processus (comme un vrai)"
# ════════════════════════════════════════════════════════════════════
cat > core/sysmon.js <<'AE_SYSMON_V3'
'use strict';
// NEXUS AETHER v3 — moniteur OS : lectures /proc réelles (aucune dépendance).
// CPU global (%), RAM, charge, uptime + TABLE DES PROCESSUS (pid, nom, CPU %,
// RAM Mo, état) avec étiquettes aether / ollama / electron.
const fs = require('fs');
const os = require('os');

let cpuLast = null;
let procLast = {};   // pid → {t, jiffies}
let CLK = 100;
try { CLK = os.sysconf ? os.sysconf('SC_CLK_TCK') : 100; } catch (e) { CLK = 100; }
if (!CLK || CLK < 1) CLK = 100;

function cpuGlobal() {
  try {
    const parts = fs.readFileSync('/proc/stat', 'utf8').split('\n')[0].trim().split(/\s+/).slice(1).map(Number);
    const idle = parts[3] + (parts[4] || 0);
    const total = parts.reduce(function (a, b) { return a + b; }, 0);
    let pct = 0;
    if (cpuLast) {
      const dT = total - cpuLast.total, dI = idle - cpuLast.idle;
      pct = dT > 0 ? Math.round((1 - dI / dT) * 100) : 0;
    }
    cpuLast = { idle: idle, total: total };
    return Math.max(0, Math.min(100, pct));
  } catch (e) { return 0; }
}
function readStat(pid) {
  try {
    const s = fs.readFileSync('/proc/' + pid + '/stat', 'utf8');
    const close = s.lastIndexOf(')');
    const f = s.slice(close + 2).split(' ');
    // après state(0) : ppid(1)… utime = f[11], stime = f[12]
    return { state: f[0], utime: parseInt(f[11], 10) || 0, stime: parseInt(f[12], 10) || 0 };
  } catch (e) { return null; }
}
function readCmd(pid) {
  try {
    return fs.readFileSync('/proc/' + pid + '/cmdline', 'utf8')
      .split('\u0000').filter(Boolean).join(' ').slice(0, 90) || '(kernel)';
  } catch (e) { return ''; }
}
function readRss(pid) {
  try {
    const pages = parseInt(fs.readFileSync('/proc/' + pid + '/statm', 'utf8').trim().split(/\s+/)[1], 10) || 0;
    return Math.round(pages * 4096 / 1048576);
  } catch (e) { return 0; }
}
function tagOf(cmd) {
  const c = String(cmd).toLowerCase();
  if (c.indexOf('ollama') !== -1) return 'ollama';
  if (c.indexOf('electron') !== -1) return 'aether-fenêtre';
  if (c.indexOf('aether') !== -1 || c.indexOf('nexus') !== -1) return 'aether';
  return '';
}
function snapshot() {
  const total = os.totalmem(), free = os.freemem();
  const now = Date.now();
  const procs = [];
  let names = [];
  try { names = fs.readdirSync('/proc'); } catch (e) { names = []; }
  names.forEach(function (n) {
    if (!/^[0-9]+$/.test(n)) return;
    const pid = parseInt(n, 10);
    const st = readStat(pid);
    if (!st) return;
    const cmd = readCmd(pid);
    if (!cmd) return; // processus kernel sans cmdline
    const j = st.utime + st.stime;
    const prev = procLast[pid];
    let cpu = 0;
    if (prev && now > prev.t) {
      const dJ = j - prev.j, dT = (now - prev.t) / 1000;
      cpu = dT > 0 ? Math.max(0, Math.min(160, (dJ / CLK) / dT * 100)) : 0;
    }
    procLast[pid] = { t: now, j: j };
    procs.push({ pid: pid, cmd: cmd, cpu: +cpu.toFixed(1), rssMb: readRss(pid), state: st.state, tag: tagOf(cmd) });
  });
  // purge les pids disparus (évite la fuite mémoire de la map)
  const alive = {};
  procs.forEach(function (p) { alive[p.pid] = true; });
  Object.keys(procLast).forEach(function (k) { if (!alive[parseInt(k, 10)]) delete procLast[k]; });
  procs.sort(function (a, b) { return b.cpu - a.cpu; });
  const load = os.loadavg();
  return {
    cpu: cpuGlobal(),
    cpuCores: os.cpus().length,
    ramUsedMb: Math.round((total - free) / 1048576),
    ramTotalMb: Math.round(total / 1048576),
    ramPct: Math.round((total - free) / total * 100),
    load: [+load[0].toFixed(2), +load[1].toFixed(2), +load[2].toFixed(2)],
    uptimeS: Math.round(os.uptime()),
    serverPid: process.pid,
    procs: procs.slice(0, 14)
  };
}
module.exports = { snapshot: snapshot };
AE_SYSMON_V3
ok "core/sysmon.js — /proc réel : CPU %, RAM, charge, table processus (ollama/aether repérés)"
chk "syntaxe sysmon.js" "node --check '$APP_DIR/core/sysmon.js'"

# ── Module de colle : routes v3 branchées dans le cœur v1 sans le réécrire ──
cat > core/aether-v3.js <<'AE_GLUE_V3'
'use strict';
// NEXUS AETHER v3 — colle entre le cœur v1 (server/core.js) et les modules v3.
// AUCUNE logique ici : juste le routage HTTP vers agents.js / sysmon.js / router.js.
const agents = require('./agents');
const sysmon = require('./sysmon');
const router = require('./router');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');

let deps = function () { return {}; };
function init(fn) { deps = fn; }

function onServerUp(port) {
  try { agents.load(); } catch (e) {}
  try {
    const c = router.loadConfig();
    if (c.agentique && c.agentique.ollamaAutoStart && process.env.AETHER_HEADLESS !== '0') {
      // systemd s'en charge via aether-ollama.service — ici on ne spawn PAS de doublon
      return;
    }
  } catch (e) {}
}

function j(res, obj, code) {
  const d = deps();
  if (d && d.json) return d.json(res, obj, code);
  res.writeHead(code || 200, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}

async function ollamaStatus() {
  try {
    const models = await router.ollamaModels('http://127.0.0.1:11434', 2500);
    return { present: true, models: models, activeModel: models.length ? models[0] : null };
  } catch (e) { return { present: false, models: [], activeModel: null }; }
}

async function iaStatus() {
  const cfg = router.loadConfig();
  const ollama = await ollamaStatus();
  return {
    ok: true,
    active: cfg.active || '',
    providers: (cfg.providers || []).map(function (p) {
      return {
        id: p.id, name: p.name, type: p.type, model: p.model || 'auto',
        tier: p.tier || '', fallback: p.fallback || null,
        keySet: !!(p.key || (p.keyEnv && process.env[p.keyEnv])),
        keyEnv: p.keyEnv || null
      };
    }),
    ollama: ollama,
    agentique: cfg.agentique || { masterIA: 'auto', ollamaAutoStart: false, maxConcurrent: 2 }
  };
}

function httpGet(u, p, res) {
  if (p === '/api/agents') return j(res, { ok: true, agents: agents.list() });
  if (p === '/api/sysmon') return j(res, { ok: true, sysmon: sysmon.snapshot() });
  if (p === '/api/ia') return iaStatus().then(function (s) { j(res, s); }).catch(function (e) { j(res, { ok: false, error: String((e && e.message) || e) }); });
  const mAgent = p.match(/^\/api\/agents\/([^\/]+)$/);
  if (mAgent) { const d = agents.detail(mAgent[1]); return d ? j(res, { ok: true, agent: d }) : j(res, { ok: false, error: 'agent inconnu' }, 404); }
  const mRes = p.match(/^\/api\/agents\/([^\/]+)\/result$/);
  if (mRes) {
    const a = agents.detail(mRes[1]);
    if (!a || !a.resultFile) return j(res, { ok: false, error: 'pas de résultat' }, 404);
    try {
      const txt = fs.readFileSync(a.resultFile, 'utf8');
      res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end(txt);
    } catch (e) { return j(res, { ok: false, error: 'lecture impossible' }, 404); }
  }
  return j(res, { ok: false, error: 'route v3 inconnue : ' + p }, 404);
}

function httpPost(u, p, data, res) {
  data = data || {};
  if (p === '/api/agents') {
    const task = String(data.task || '').trim();
    if (!task) return j(res, { ok: false, error: 'tâche vide' }, 400);
    const a = agents.create(task, {});
    return j(res, { ok: true, agent: a });
  }
  let m = p.match(/^\/api\/agents\/([^\/]+)\/cancel$/);
  if (m) { const a = agents.cancel(m[1]); return a ? j(res, { ok: true, agent: a }) : j(res, { ok: false, error: 'agent inconnu' }, 404); }
  if (p === '/api/ia/test') {
    const id = String(data.id || '');
    return router.testProvider(id).then(function (r) { j(res, Object.assign({ ok: !!r.ok }, r)); });
  }
  if (p === '/api/ia/active') {
    const cfg = router.loadConfig();
    const id = String(data.id || '');
    if (!(cfg.providers || []).some(function (x) { return x.id === id; })) return j(res, { ok: false, error: 'fournisseur inconnu' }, 400);
    cfg.active = id; router.saveConfig(cfg);
    return j(res, { ok: true, active: id });
  }
  if (p === '/api/ia/config') {
    const cfg = router.loadConfig();
    cfg.agentique = cfg.agentique || {};
    ['masterIA', 'ollamaAutoStart', 'maxConcurrent'].forEach(function (k) {
      if (typeof data[k] !== 'undefined') cfg.agentique[k] = data[k];
    });
    router.saveConfig(cfg);
    return j(res, { ok: true, agentique: cfg.agentique });
  }
  if (p === '/api/ia/ollama-autostart') {
    const on = !!data.on;
    const cfg = router.loadConfig();
    cfg.agentique = cfg.agentique || {};
    cfg.agentique.ollamaAutoStart = on;
    router.saveConfig(cfg);
    const act = on ? 'enable' : 'disable';
    spawn('systemctl', ['--user', act, 'aether-ollama.service'], { stdio: 'ignore' }).on('error', function () {});
    return j(res, { ok: true, ollamaAutoStart: on, note: on ? 'aether-ollama.service activé' : 'aether-ollama.service désactivé' });
  }
  return j(res, { ok: false, error: 'route v3 inconnue : ' + p }, 404);
}

module.exports = { init: init, onServerUp: onServerUp, httpGet: httpGet, httpPost: httpPost };
AE_GLUE_V3
ok "core/aether-v3.js — routes /api/agents · /api/sysmon · /api/ia (test réel, config, auto-start)"
chk "syntaxe aether-v3.js" "node --check '$APP_DIR/core/aether-v3.js'"

# ── Patch chirurgical de server/core.js (4 insertions, ancre par ancre) ──
cat > scripts/.patch-core-v3.js <<'AE_PATCH_CORE'
'use strict';
const fs = require('fs');
const f = process.argv[2];
let s = fs.readFileSync(f, 'utf8');
if (s.indexOf('AETHER_V3') !== -1) { console.log('already'); process.exit(0); }
let n = 0;
const rep = function (anchor, add) {
  if (s.indexOf(anchor) === -1) { console.log('MISS:' + n); process.exit(3 + n); }
  s = s.replace(anchor, anchor + add);
  n += 1;
};
const swap = function (from, to) {
  if (s.indexOf(from) === -1) { console.log('MISS:' + n); process.exit(3 + n); }
  s = s.replace(from, to);
  n += 1;
};
// 1) require du module v3 juste après les requires existants
rep("const { remember, getMemory } = require('../core/memory');",
"\n// AETHER_V3 — modules agentiques (agents, moniteur OS, IA v3)\n" +
"let V3 = null;\n" +
"try { V3 = require('../core/aether-v3'); V3.init(function () { return { json: json, metrics: metrics, srvPort: srvPort }; }); } catch (e3) { V3 = null; }");
// 2) routes GET v3
rep("if (p === '/api/grid/status') return apiGrid(res);",
"\n    if (V3 && (p === '/api/agents' || p === '/api/sysmon' || p === '/api/ia' || p.indexOf('/api/agents/') === 0 || p.indexOf('/api/ia/') === 0)) return V3.httpGet(u, p, res);");
// 3) routes POST v3 (AVANT /api/ai) — SWAP. NB : handlePost(p, body, res) n'a PAS
//    accès à « u » (local à handler) → on reconstruit l'URL depuis le pathname.
swap("  if (p === '/api/ai') {",
     "  if (V3 && (p.indexOf('/api/agents') === 0 || p.indexOf('/api/ia/') === 0)) { V3.httpPost(new URL('http://127.0.0.1' + p), p, data, res); return; }\n  if (p === '/api/ai') {");
// 4) au démarrage du serveur : recharger les agents + marquer le boot
rep("        srvPort = port;",
"\n        if (V3) { try { V3.onServerUp(port); } catch (e5) {} }");
// 5) vendor xterm + assets : servis depuis le VRAI dossier (hors coffre asar)
rep("const ROOT = path.join(__dirname, '..');",
"\nconst ROOT_FS = (process.env.AETHER_ROOT && fs.existsSync(path.join(process.env.AETHER_ROOT, 'node_modules'))) ? process.env.AETHER_ROOT : ROOT;");
swap("sendFile(res, path.join.apply(path, [ROOT, 'node_modules'].concat(rel)));",
     "sendFile(res, path.join.apply(path, [ROOT_FS, 'node_modules'].concat(rel)));");
swap("if (p.indexOf('/assets/') === 0) return sendFile(res, path.join(ROOT, p.slice(1)));",
     "if (p.indexOf('/assets/') === 0) return sendFile(res, path.join(ROOT_FS, p.slice(1)));");
fs.writeFileSync(f, s);
console.log('patched:' + n);
AE_PATCH_CORE
PATCH_OUT="$(node "$APP_DIR/scripts/.patch-core-v3.js" "$APP_DIR/server/core.js" 2>&1 || true)"
info "patch core.js : $PATCH_OUT"
if echo "$PATCH_OUT" | grep -q "patched:7"; then
  ok "server/core.js — 7 greffes v3 (routes agents/sysmon/ia + boot hook + vendor hors coffre)"
elif echo "$PATCH_OUT" | grep -q "already"; then
  ok "server/core.js déjà patché v3 (re-run sans casse)"
else
  ko "patch core.js : $PATCH_OUT — restaure depuis la sauvegarde et vérifie la base v1"
  exit 1
fi
rm -f "$APP_DIR/scripts/.patch-core-v3.js"
chk "syntaxe server/core.js" "node --check '$APP_DIR/server/core.js'"
