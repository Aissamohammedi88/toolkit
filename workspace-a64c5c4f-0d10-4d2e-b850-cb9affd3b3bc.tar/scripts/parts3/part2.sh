
# ════════════════════════════════════════════════════════════════════
phase 2 "DÉMÊLAGE — Aether redevient un poste agentique, pas un hub"
# ════════════════════════════════════════════════════════════════════
cd "$APP_DIR"

# 1) Restauration de la base v1 propre
if [ "$V2_STATE" = "1" ] && [ -n "${BACKUP_V2:-}" ]; then
  for f in main.js preload.js package.json server/core.js ui/index.html ui/app.js \
           ui/style.css config/plugins.json; do
    if [ -f "$BACKUP_V2/$f" ]; then
      mkdir -p "$(dirname "$APP_DIR/$f")"
      cp "$BACKUP_V2/$f" "$APP_DIR/$f"
    fi
  done
  ok "fichiers d'origine restaurés depuis $BACKUP_V2"
fi

# 2) Récupération du cœur v1 (TOUJOURS — v2 scellait core/ dans le coffre,
#    et un run interrompu peut laisser la machine à moitié démontée).
#    Sources, dans l'ordre : coffre app.asar → ~/.nexus-aether/src-backup-*
MISSING_CORE=0
[ -f "$APP_DIR/core/router.js" ] || MISSING_CORE=1
[ -f "$APP_DIR/core/memory.js" ] || MISSING_CORE=1
if [ "$MISSING_CORE" = "1" ]; then
  mkdir -p "$APP_DIR/core"
  VREST="$APP_DIR/.vault-restore"
  if [ -f "$APP_DIR/app.asar" ] && [ ! -d "$VREST" ]; then
    (cd "$APP_DIR" && npx --yes @electron/asar extract app.asar "$VREST" >/dev/null 2>&1) || true
  fi
  SRC_BACKUP=""
  for d in $(ls -d "$HOME/.nexus-aether/src-backup-"* 2>/dev/null | sort | tail -n 1 || true); do
    [ -d "$d" ] && SRC_BACKUP="$d"
  done
  for f in core/router.js core/memory.js; do
    if [ ! -f "$APP_DIR/$f" ]; then
      if [ -d "$VREST" ] && [ -f "$VREST/$f" ]; then
        cp "$VREST/$f" "$APP_DIR/$f"; ok "récupéré du coffre : $f"
      elif [ -n "$SRC_BACKUP" ] && [ -f "$SRC_BACKUP/$f" ]; then
        cp "$SRC_BACKUP/$f" "$APP_DIR/$f"; ok "récupéré de $SRC_BACKUP : $f"
      fi
    fi
  done
  rm -rf "$VREST"
fi

# 3) Retrait du catalogue GenHub qui avait été mélangé dans Aether
MIXED=0
for f in config/services.json core/engine.js ui/engine.js scripts/patch-v2.js \
         "$CONF_DIR/services.json" "$CONF_DIR/engine-history.jsonl"; do
  if [ -f "$f" ]; then rm -f "$f"; MIXED=$((MIXED+1)); fi
done
if [ "$MIXED" -gt 0 ]; then
  ok "catalogue « 90+ services » retiré d'Aether ($MIXED fichier(s)) — il reste dans nexus-genedit"
else
  info "aucun fichier du mélange en clair — il était scellé dans le coffre (retiré ci-dessous)"
fi
# Le coffre v2 est retiré : il sera recompilé proprement en phase 8
[ -f "$APP_DIR/app.asar" ] && { rm -f "$APP_DIR/app.asar"; ok "ancien coffre app.asar retiré (recompilation propre en phase 8)"; } || true

# 3) Vérification des marqueurs v1 (base connue et stable)
# NB : core/router.js n'est pas exigé ici — la phase 3 le réécrit intégralement.
BASE_OK=1
grep -q "startServer" "$APP_DIR/server/core.js" 2>/dev/null || BASE_OK=0
grep -q "</body>" "$APP_DIR/ui/index.html" 2>/dev/null || BASE_OK=0
[ -f "$APP_DIR/core/memory.js" ] || BASE_OK=0
if [ "$BASE_OK" = "1" ]; then ok "base v1 vérifiée (core.js / index.html / memory.js)"
else
  ko "base inconnue : marqueurs v1 introuvables — arrêt par sécurité"
  echo "  → relance d'abord aether-bureau-tout-en-un.sh, puis ce script."; echo; exit 1
fi

# ════════════════════════════════════════════════════════════════════
phase 3 "CERVEAU IA — Ollama auto-détecté (fin du bug « model not found »)"
# ════════════════════════════════════════════════════════════════════
# Le bug : l'ancien code codait « model: llama3 » en dur. S'il n'était pas
# téléchargé → « model 'llama3' not found ». La vraie correction d'ingénieur :
# interroger GET /api/tags d'Ollama et utiliser un modèle INSTALLÉ, avec un
# repli cléless RÉEL (text.pollinations.ai) si Ollama est absent.

cat > core/router.js <<'AE_ROUTER_V3'
'use strict';
// NEXUS AETHER v3 — routeur IA réel.
//  · type "port"        → service local (Ollama 127.0.0.1:11434), modèle AUTO-DÉTECTÉ
//  · type "pollinations"→ cléless RÉEL (text.pollinations.ai) — repli par défaut
//  · type "gemini"      → Google Gemini (clé)
//  · type "openai"      → toute API compatible OpenAI (clé)
// AUCUN modèle n'est codé en dur : si p.model vaut "auto", on lit /api/tags.
const fs = require('fs');
const path = require('path');
const os = require('os');

const CONF_DIR = path.join(os.homedir(), '.aether');
const USER_FILE = path.join(CONF_DIR, 'plugins.json');
const BUNDLED_FILE = path.join(__dirname, '..', 'config', 'plugins.json');

function loadConfig() {
  try { if (fs.existsSync(USER_FILE)) return JSON.parse(fs.readFileSync(USER_FILE, 'utf8')); } catch (e) {}
  try { return JSON.parse(fs.readFileSync(BUNDLED_FILE, 'utf8')); } catch (e) {}
  return { active: '', providers: [], agentique: {} };
}
function saveConfig(cfg) {
  fs.mkdirSync(CONF_DIR, { recursive: true });
  fs.writeFileSync(USER_FILE, JSON.stringify(cfg, null, 2) + '\n');
}

function fetchTimeout(url, opts, ms) {
  const c = new AbortController();
  const t = setTimeout(function () { try { c.abort(); } catch (e) {} }, ms || 30000);
  return fetch(url, Object.assign({}, opts || {}, { signal: c.signal })).then(function (r) {
    clearTimeout(t); return r;
  }, function (e) { clearTimeout(t); throw e; });
}

async function readJson(res) {
  const t = await res.text();
  try { return JSON.parse(t); } catch (e) {
    throw new Error('réponse non-JSON (' + res.status + ') : ' + t.slice(0, 200));
  }
}

// ── Ollama : la liste des modèles RÉELLEMENT installés ──────────────
async function ollamaModels(base, ms) {
  const r = await fetchTimeout(String(base).replace(/\/+$/, '') + '/api/tags', {}, ms || 4000);
  if (!r.ok) throw new Error('Ollama HTTP ' + r.status);
  const j = await r.json();
  return (j.models || []).map(function (m) { return m.name; }).filter(Boolean);
}

// préfère un modèle causonnable déjà installé, sinon le premier de la liste
function pickModel(list) {
  const pref = ['llama3.2', 'qwen2.5', 'qwen3', 'mistral', 'llama3.1', 'llama3', 'gemma3', 'gemma2', 'phi', 'deepseek', 'codellama', 'tinyllama'];
  for (let i = 0; i < pref.length; i++) {
    const hit = list.find(function (m) { return m.indexOf(pref[i]) === 0; });
    if (hit) return hit;
  }
  return list[0];
}

async function chatWithOllama(p, messages) {
  const base = String(p.url || 'http://127.0.0.1:11434');
  let model = p.model;
  if (!model || model === 'auto') {
    let list;
    try { list = await ollamaModels(base, 4000); }
    catch (e) { throw new Error('Ollama injoignable sur ' + base + ' — il démarre tout seul si l\u2019option est active, sinon : ollama serve'); }
    if (!list.length) throw new Error('Ollama ne compte AUCUN modèle — télécharge-en un : ollama pull llama3.2:1b');
    model = pickModel(list);
  }
  let res;
  try {
    res = await fetchTimeout(base.replace(/\/+$/, '') + '/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: model, messages: messages, stream: false })
    }, 180000);
  } catch (e) {
    throw new Error('Ollama injoignable sur ' + base + ' (' + String((e && e.message) || e) + ')');
  }
  const j = await readJson(res);
  if (j.error) throw new Error('Ollama : ' + ((j.error && j.error.message) || j.error));
  return (j.message && j.message.content) || '(réponse vide)';
}

// ── Pollinations : cléless RÉEL, testé en direct ─────────────────────
// Free tier : 1 réponse / 30 s / IP → HTTP 402. Vraie correction d'ingénieur :
// on RETIENT (backoff indiqué par le service) et on réessaie — pas d'échec sec.
async function chatWithPollinations(p, messages) {
  const body = { messages: messages, model: p.model || 'openai-fast' };
  let lastErr = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    if (attempt > 0) {
      const d = (lastErr && lastErr.waitMs) ? lastErr.waitMs : 31000;
      await new Promise(function (r) { setTimeout(r, d); });
    }
    const res = await fetchTimeout('https://text.pollinations.ai/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }, 120000);
    const t = await res.text();
    if (res.status === 402 || res.status === 429) {
      const m = t.match(/wait (\d+) seconds/);
      const err = new Error('Pollinations HTTP ' + res.status + ' (quota gratuit) — nouvelle tentative automatique');
      err.waitMs = Math.min(45000, ((m ? parseInt(m[1], 10) : 30) + 4) * 1000);
      lastErr = err;
      continue;
    }
    if (res.status >= 400) throw new Error('Pollinations HTTP ' + res.status + ' — ' + t.slice(0, 160));
    try {
      const j = JSON.parse(t);
      return (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content)
        || j.message || j.text || t;
    } catch (e) { return t; }
  }
  throw lastErr || new Error('Pollinations : échec après 3 tentatives');
}

async function chatWithGemini(p, key, messages) {
  if (!key) throw new Error('clé Gemini absente — export ' + (p.keyEnv || 'AETHER_GEMINI_KEY') + '=…');
  const url = String(p.url).replace(/\/+$/, '') + '/models/' + p.model + ':generateContent?key=' + encodeURIComponent(key);
  const sys = messages.find(function (m) { return m.role === 'system'; });
  const contents = messages.filter(function (m) { return m.role !== 'system'; }).map(function (m) {
    return { role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: String(m.content) }] };
  });
  const body = { contents: contents };
  if (sys) body.systemInstruction = { parts: [{ text: String(sys.content) }] };
  const res = await fetchTimeout(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }, 120000);
  const j = await readJson(res);
  if (j.error) throw new Error('Gemini : ' + ((j.error && j.error.message) || JSON.stringify(j.error).slice(0, 200)));
  const parts = (j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || [];
  return parts.map(function (x) { return x.text || ''; }).join('') || '(réponse vide)';
}

async function chatWithOpenAI(p, key, messages) {
  if (!p.url) throw new Error('fournisseur « ' + (p.name || p.id) + ' » : url manquante');
  if (!key) throw new Error('fournisseur « ' + (p.name || p.id) + ' » : clé absente — export ' + (p.keyEnv || 'AETHER_CUSTOM_KEY') + '=…');
  const res = await fetchTimeout(String(p.url).replace(/\/+$/, ''), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
    body: JSON.stringify({ model: p.model, messages: messages, stream: false, temperature: 0.7 })
  }, 120000);
  const j = await readJson(res);
  if (j.error) throw new Error('API : ' + ((j.error && j.error.message) || JSON.stringify(j.error).slice(0, 200)));
  return (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '(réponse vide)';
}

// ── chat() : compatible v1 (même signature) + repli automatique ──────
async function chat(messages, opts) {
  const cfg = loadConfig();
  const providers = cfg.providers || [];
  let p = providers.find(function (x) { return x.id === ((opts && opts.providerId) || cfg.active); })
       || providers[0];
  if (!p) throw new Error('aucun fournisseur IA — vérifie ~/.aether/plugins.json');
  let tries = 0;
  for (;;) {
    tries += 1;
    const key = p.key || (p.keyEnv ? (process.env[p.keyEnv] || '') : '');
    try {
      let text;
      if (p.type === 'port') text = await chatWithOllama(p, messages);
      else if (p.type === 'pollinations') text = await chatWithPollinations(p, messages);
      else if (p.type === 'gemini') text = await chatWithGemini(p, key, messages);
      else text = await chatWithOpenAI(p, key, messages);
      return { text: text, provider: p.id, model: p.model || 'auto' };
    } catch (e) {
      if (p.fallback && tries === 1) {
        const fb = providers.find(function (x) { return x.id === p.fallback; });
        if (fb) { p = fb; continue; } // repli réel (ex : Ollama absent → Pollinations cléless)
      }
      throw e;
    }
  }
}

// ── testProvider : un VRAI appel, pour le bouton « Tester » ──────────
async function testProvider(id) {
  const t0 = Date.now();
  try {
    const out = await chat([{ role: 'user', content: 'Réponds exactement : TEST_OK' }], { providerId: id });
    return { ok: true, ms: Date.now() - t0, provider: out.provider, extrait: String(out.text).slice(0, 80) };
  } catch (e) {
    return { ok: false, ms: Date.now() - t0, error: String((e && e.message) || e) };
  }
}

module.exports = { chat: chat, loadConfig: loadConfig, saveConfig: saveConfig, testProvider: testProvider, ollamaModels: ollamaModels };
AE_ROUTER_V3
ok "core/router.js v3 — modèle auto-détecté via /api/tags, repli cléless réel, testProvider"
chk "syntaxe router.js v3" "node --check '$APP_DIR/core/router.js'"

# Config officielle v3 : Aether ne référence QUE ses 4 fournisseurs IA.
# Les clés déjà posées par l'utilisateur (key/keyEnv) sont conservées.
cat > config/plugins.json <<'AE_PLUG_V3'
{
  "active": "ollama",
  "providers": [
    {
      "id": "ollama",
      "name": "Ollama (local · souverain)",
      "type": "port",
      "url": "http://127.0.0.1:11434",
      "model": "auto",
      "fallback": "pollinations-text",
      "tier": "local",
      "docs": "Modèle auto-détecté via /api/tags — plus jamais « model not found »."
    },
    {
      "id": "pollinations-text",
      "name": "Pollinations Text (cléless · réel)",
      "type": "pollinations",
      "url": "https://text.pollinations.ai/",
      "model": "openai-fast",
      "tier": "cléless",
      "docs": "Aucune clé requise — testé en direct."
    },
    {
      "id": "gemini",
      "name": "Google Gemini (clé)",
      "type": "gemini",
      "url": "https://generativelanguage.googleapis.com/v1beta",
      "model": "gemini-2.0-flash",
      "keyEnv": "AETHER_GEMINI_KEY",
      "tier": "clé-gratuit"
    },
    {
      "id": "openai-compat",
      "name": "API compatible OpenAI (clé)",
      "type": "openai",
      "url": "https://api.openai.com/v1/chat/completions",
      "model": "gpt-4o-mini",
      "keyEnv": "AETHER_CUSTOM_KEY",
      "tier": "clé"
    }
  ],
  "agentique": {
    "masterIA": "auto",
    "ollamaAutoStart": true,
    "maxConcurrent": 2
  }
}
AE_PLUG_V3
# Fusion : garder les clés posées par l'utilisateur dans l'ancien plugins.json
node -e '
const fs = require("fs");
const p = process.argv[1], b = process.argv[2];
try {
  const old = JSON.parse(fs.readFileSync(p, "utf8"));
  const nw = JSON.parse(fs.readFileSync(b, "utf8"));
  const oldById = {}; (old.providers || []).forEach(function (x) { oldById[x.id] = x; });
  nw.providers.forEach(function (x) {
    const o = oldById[x.id];
    if (o && o.key) x.key = o.key;
    if (o && o.keyEnv && !x.keyEnv) x.keyEnv = o.keyEnv;
  });
  if (old.active && nw.providers.some(function (x) { return x.id === old.active; })) nw.active = old.active;
  fs.writeFileSync(b, JSON.stringify(nw, null, 2) + "\n");
} catch (e) {}
' "$CONF_DIR/plugins.json" "$APP_DIR/config/plugins.json" 2>/dev/null || true
cp "$APP_DIR/config/plugins.json" "$CONF_DIR/plugins.json" 2>/dev/null || true
ok "config IA v3 écrite (~/.aether/plugins.json) — clés utilisateur conservées"

# main.js : si le daemon persistant tourne déjà, la fenêtre s'y BRANCHE au lieu
# de démarrer un second serveur.
MAIN_PATCH_OUT="$(node -e '
const fs = require("fs");
const f = process.argv[1];
let s = fs.readFileSync(f, "utf8");
if (s.indexOf("AETHER_V3") !== -1) { console.log("already"); process.exit(0); }
const anchor = "  const { startServer } = require(\u0027./server/core\u0027);\n  try {";
const rep =
"  const { startServer } = require(\u0027./server/core\u0027);\n" +
"  // AETHER_V3 : si le daemon persistant (systemd) est vivant, on s\u0027y branche\n" +
"  try {\n" +
"    const pr = await fetch(\u0027http://127.0.0.1:\u0027 + PORT + \u0027/api/health\u0027, { signal: AbortSignal.timeout(1500) });\n" +
"    const pj = await pr.json();\n" +
"    if (pj && pj.ok) { createWindow(PORT); console.log(\u0027[nexus-aether] branché au daemon persistant :\u0027 + PORT); return; }\n" +
"  } catch (e) {}\n" +
"  try {";
if (s.indexOf(anchor) === -1) { console.log("anchor-missing"); process.exit(2); }
s = s.replace(anchor, rep).replace("// NEXUS AETHER — processus principal Electron.", "// NEXUS AETHER — processus principal Electron. (AETHER_V3)");
fs.writeFileSync(f, s);
console.log("patched");
' "$APP_DIR/main.js" 2>&1)" || true
if echo "$MAIN_PATCH_OUT" | grep -q "^patched"; then
  ok "main.js — branchement automatique au daemon persistant"
elif echo "$MAIN_PATCH_OUT" | grep -q "already"; then
  ok "main.js déjà patché v3 (re-run sans casse)"
else
  warn "ancre main.js introuvable — comportement v1 conservé (sans casse) : $MAIN_PATCH_OUT"
fi
chk "syntaxe main.js" "node --check '$APP_DIR/main.js'"
