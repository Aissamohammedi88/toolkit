#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════
#  NEXUS AETHER v3 — POSTE AGENTIQUE  (script d'upgrade, partie 1/6)
# ══════════════════════════════════════════════════════════════════════
#  CE QUE C'EST  : Aether = terminal réel + mémoire + AGENTS en arrière-plan
#                  + MONITEUR OS agentique + IA maîtresse (Ollama auto-détecté,
#                  repli cléless réel). Serveur persistant (systemd + linger).
#  CE QUE CE N'EST PAS : un hub de services. Le hub (141 services) vit dans
#                  ~/Bureau/nexus-genedit/ (genedit.py + genhub.sh) et CE
#                  SCRIPT N'Y TOUCHE JAMAIS. Le catalogue « 90+ services »
#                  ajouté par erreur dans Aether est RETIRÉ (démêlage).
#  PRINCIPE      : optimise l'installation existante, ne détruit rien
#                  (sauvegarde horodatée + restauration depuis .backup-v2-*).
#  Usage : bash aether-v3-poste-agentique.sh
#          AETHER_OLLAMA_AUTOSTART=0  → Ollama ne démarre pas tout seul
#          AETHER_SKIP_LINGER=1      → ne touche pas à linger
# ══════════════════════════════════════════════════════════════════════
set -euo pipefail

APP_TITLE="NEXUS AETHER"
APP_ID="nexus-aether"
APP_VERSION="3.0.0"
APP_DIR="${AETHER_DIR:-$HOME/Aether}"
PORT="${AETHER_PORT:-8420}"
CONF_DIR="$HOME/.aether"
WORKSPACE="$APP_DIR/workspace"

C_CYAN="\033[1;36m"; C_MAG="\033[1;95m"; C_GRN="\033[1;32m"; C_YLW="\033[1;33m"
C_RED="\033[1;31m"; C_DIM="\033[2m"; C_B="\033[1m"; C_RST="\033[0m"
PASS=0; FAIL=0

ok()   { echo -e "  ${C_GRN}✓${C_RST} $1"; PASS=$((PASS+1)); }
ko()   { echo -e "  ${C_RED}✗${C_RST} $1"; FAIL=$((FAIL+1)); }
info() { echo -e "  ${C_DIM}·${C_RST} $1"; }
warn() { echo -e "  ${C_YLW}!${C_RST} $1"; }
phase(){ echo; echo -e "${C_MAG}━━━ PHASE $1/9 ━━━ ${C_CYAN}${C_B}$2${C_RST}"; }
chk()  { if eval "$2" >/dev/null 2>&1; then ok "$1"; else ko "$1"; fi }

echo
echo -e "${C_MAG}${C_B}"
cat <<'BANIERE'
   ╔════════════════════════════════════════════════════════════════╗
   ║   N E X U S   A E T H E R   ·   v 3   P O S T E   A G E N T    ║
   ║   Terminal · Mémoire · Agents arrière-plan · Moniteur OS       ║
   ║   IA réelle : Ollama auto-détecté · daemon persistant          ║
   ╚════════════════════════════════════════════════════════════════╝
BANIERE
echo -e "${C_RST}${C_DIM}   Démêlage : Aether ≠ GenHub. Le hub 141 services reste dans"
echo -e "   ~/Bureau/nexus-genedit/ (genedit.py + genhub.sh) — ici, on n'y touche pas.${C_RST}"

# ════════════════════════════════════════════════════════════════════
phase 1 "Contrôles, sauvegarde, arrêt propre"
# ════════════════════════════════════════════════════════════════════
if [ -d "$APP_DIR" ]; then ok "installation détectée : $APP_DIR"; else
  ko "$APP_DIR introuvable — lance d'abord aether-bureau-tout-en-un.sh"; echo; exit 1; fi

if command -v node >/dev/null 2>&1; then ok "node $(node -v)"; else ko "node absent"; exit 1; fi
NODE_MAJOR="$(node -p 'parseInt(process.versions.node,10)' 2>/dev/null || echo 0)"
if [ "${NODE_MAJOR:-0}" -ge 18 ] 2>/dev/null; then ok "node ≥ 18 — fetch natif + AbortSignal disponibles"
else ko "node ≥ 18 requis — arrêt"; echo; exit 1; fi
chk "curl" "command -v curl"

# État actuel : v1 propre, ou v2 appliqué (coffre asar + catalogue mélangé) ?
V2_STATE=0
[ -f "$APP_DIR/app.asar" ] && V2_STATE=1
[ -f "$APP_DIR/config/services.json" ] && V2_STATE=1
[ -f "$APP_DIR/core/engine.js" ] && V2_STATE=1
if [ "$V2_STATE" = "1" ]; then
  info "état v2 détecté (coffre asar / catalogue 93 services) — démêlage en phase 2"
else
  info "état v1 détecté — pas de catalogue mélangé, démêlage non nécessaire"
fi

# Dernière sauvegarde v2 disponible (base v1 propre pour restauration)
BACKUP_V2=""
for d in $(ls -d "$APP_DIR"/.backup-v2-* 2>/dev/null | sort | tail -n 1 || true); do
  [ -d "$d" ] && BACKUP_V2="$d"
done
if [ -n "$BACKUP_V2" ]; then ok "sauvegarde v2 trouvée (base v1 propre) : $BACKUP_V2"
else info "aucune .backup-v2-* — les fichiers actuels servent de base"; fi

# Arrêt propre de l'app/serveur en cours
if [ -x "$APP_DIR/scripts/aether-stop.sh" ]; then
  "$APP_DIR/scripts/aether-stop.sh" >/dev/null 2>&1 || true
  info "instances en cours arrêtées (le daemon reviendra en phase 6)"
fi
command -v systemctl >/dev/null 2>&1 && systemctl --user stop aether.service >/dev/null 2>&1 || true

# Sauvegarde horodatée v3 de TOUT ce qu'on va toucher
TS="$(date +%Y%m%d-%H%M%S)"
BACKUP="$APP_DIR/.backup-v3-$TS"
mkdir -p "$BACKUP"
for f in main.js preload.js package.json server/core.js core/router.js core/memory.js \
         ui/index.html ui/app.js ui/style.css config/plugins.json \
         scripts/aether-launch.sh scripts/aether-stop.sh README.md; do
  [ -f "$APP_DIR/$f" ] && mkdir -p "$BACKUP/$(dirname "$f")" && cp "$APP_DIR/$f" "$BACKUP/$f"
done
ok "sauvegarde complète : $BACKUP"
echo "$BACKUP" > "$CONF_DIR/last-backup-v3.txt" 2>/dev/null || true
