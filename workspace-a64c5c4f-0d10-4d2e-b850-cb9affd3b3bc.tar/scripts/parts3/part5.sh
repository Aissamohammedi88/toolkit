
# ════════════════════════════════════════════════════════════════════
phase 7 "VISUEL PRODUCTION — dock Agents · Moniteur OS · Réglages IA"
# ════════════════════════════════════════════════════════════════════
# Un seul fichier : ui/v3.js. Il crée son propre dock et ses panneaux —
# AUCUNE modification invasive du thème OMEGA existant.

cat > ui/v3.js <<'AE_UI_V3'
'use strict';
/* NEXUS AETHER v3 — poste agentique : dock + panneaux (Agents, Moniteur OS, Réglages IA). */
(function () {
  if (window.__AETHER_V3__) return;
  window.__AETHER_V3__ = true;

  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function fmtDur(ms) {
    var s = Math.round(ms / 1000);
    if (s < 60) return s + ' s';
    var m = Math.floor(s / 60);
    if (m < 60) return m + ' min ' + (s % 60) + ' s';
    return Math.floor(m / 60) + ' h ' + (m % 60) + ' min';
  }
  function chip(status) {
    var cls = { 'en-file': 'av3-chip-wait', 'en-cours': 'av3-chip-run', 'terminé': 'av3-chip-ok',
                'échec': 'av3-chip-ko', 'annulé': 'av3-chip-cancel', 'interrompu': 'av3-chip-int' }[status] || 'av3-chip-wait';
    return '<span class="av3-chip ' + cls + '">' + esc(status) + '</span>';
  }

  /* ── Dock ─────────────────────────────────────────────────────────── */
  var dock = el('div', 'av3-dock');
  dock.innerHTML =
    '<button class="av3-dock-btn" id="av3-open-agents" title="Agents en arrière-plan">🤖<small>Agents</small></button>' +
    '<button class="av3-dock-btn" id="av3-open-sysmon" title="Moniteur OS agentique">📊<small>OS</small></button>' +
    '<button class="av3-dock-btn" id="av3-open-ia" title="Réglages IA réelle">⚙️<small>IA</small></button>';
  document.body.appendChild(dock);

  var panel = el('div', 'av3-panel');
  panel.innerHTML = '<div class="av3-panel-head"><span id="av3-panel-title"></span>' +
                    '<button class="av3-x" id="av3-close">✕</button></div>' +
                    '<div class="av3-panel-body" id="av3-panel-body"></div>';
  document.body.appendChild(panel);
  var body = document.getElementById('av3-panel-body');
  var title = document.getElementById('av3-panel-title');
  var current = null;
  var timers = [];

  function clearTimers() { timers.forEach(function (t) { clearInterval(t); }); timers = []; }
  function openPanel(name) {
    current = name;
    panel.classList.add('av3-open');
    clearTimers();
    if (name === 'agents') renderAgents();
    if (name === 'sysmon') renderSysmon();
    if (name === 'ia') renderIA();
  }
  function closePanel() { current = null; panel.classList.remove('av3-open'); clearTimers(); }
  document.getElementById('av3-close').onclick = closePanel;
  document.getElementById('av3-open-agents').onclick = function () { current === 'agents' ? closePanel() : openPanel('agents'); };
  document.getElementById('av3-open-sysmon').onclick = function () { current === 'sysmon' ? closePanel() : openPanel('sysmon'); };
  document.getElementById('av3-open-ia').onclick = function () { current === 'ia' ? closePanel() : openPanel('ia'); };

  function api(path, opts) {
    return fetch(path, opts || {}).then(function (r) {
      var ct = r.headers.get('content-type') || '';
      return (ct.indexOf('json') !== -1) ? r.json() : r.text();
    });
  }

  /* ── Panneau AGENTS ───────────────────────────────────────────────── */
  var detailId = null;
  function renderAgents() {
    title.innerHTML = '🤖 Agents en arrière-plan';
    body.innerHTML =
      '<div class="av3-new-agent">' +
      '<textarea id="av3-task" rows="3" placeholder="Tâche pour l\u2019agent — ex : « Rédige un plan de test pour mon script bash et note les risques »"></textarea>' +
      '<button class="av3-btn" id="av3-launch">⚡ Lancer l\u2019agent</button>' +
      '<span class="av3-hint">file réelle dans le daemon — fermer la fenêtre n\u2019arrête rien</span></div>' +
      '<div id="av3-agent-list" class="av3-list"></div>' +
      '<div id="av3-agent-detail"></div>';
    document.getElementById('av3-launch').onclick = function () {
      var t = document.getElementById('av3-task').value.trim();
      if (!t) return;
      api('/api/agents', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ task: t }) })
        .then(function (r) {
          if (r && r.ok) { document.getElementById('av3-task').value = ''; detailId = r.agent.id; refreshAgents(); }
          else alert(r && r.error ? r.error : 'création impossible');
        });
    };
    refreshAgents();
    timers.push(setInterval(refreshAgents, 3000));
  }
  function refreshAgents() {
    if (current !== 'agents') return;
    api('/api/agents').then(function (r) {
      var list = (r && r.agents) || [];
      var box = document.getElementById('av3-agent-list');
      if (!box) return;
      if (!list.length) { box.innerHTML = '<div class="av3-empty">Aucun agent encore lancé. Écris une tâche ci-dessus ⚡</div>'; }
      else {
        box.innerHTML = list.map(function (a) {
          return '<div class="av3-agent' + (a.id === detailId ? ' av3-agent-sel' : '') + '" data-id="' + a.id + '">' +
            '<div class="av3-agent-top"><span class="av3-agent-id">' + esc(a.id) + '</span>' + chip(a.status) + '</div>' +
            '<div class="av3-agent-task">' + esc(a.task.slice(0, 110)) + '</div>' +
            (a.steps && a.steps.length ? '<div class="av3-agent-steps">' + a.steps.length + ' étapes · étape ' + (a.stepIndex + 1) + '</div>' : '') +
            '</div>';
        }).join('');
        Array.prototype.forEach.call(box.querySelectorAll('.av3-agent'), function (d) {
          d.onclick = function () { detailId = d.getAttribute('data-id'); refreshAgents(); };
        });
      }
      renderAgentDetail();
    }).catch(function () {});
  }
  function renderAgentDetail() {
    var box = document.getElementById('av3-agent-detail');
    if (!box || !detailId) { if (box) box.innerHTML = ''; return; }
    api('/api/agents/' + detailId).then(function (r) {
      var a = r && r.agent;
      if (!a) { box.innerHTML = ''; return; }
      var stepsHtml = (a.steps || []).map(function (s, i) {
        var ic = s.status === 'terminé' ? '✓' : (s.status === 'en-cours' ? '⟳' : '·');
        var cls = s.status === 'terminé' ? 'ok' : (s.status === 'en-cours' ? 'run' : 'wait');
        return '<div class="av3-step av3-step-' + cls + '"><span class="av3-step-ic">' + ic + '</span> Étape ' + (i + 1) + ' — ' + esc(s.label) + '</div>';
      }).join('');
      var logHtml = (a.log || []).slice(-10).map(function (l) { return '<div>' + esc(new Date(l.t).toLocaleTimeString() + ' · ' + l.line) + '</div>'; }).join('');
      box.innerHTML =
        '<div class="av3-detail">' +
        '<div class="av3-detail-head"><b>' + esc(a.id) + '</b> ' + chip(a.status) +
        ' <button class="av3-btn-sm" id="av3-cancel">annuler</button></div>' +
        '<div class="av3-steps">' + (stepsHtml || '<i>planification…</i>') + '</div>' +
        '<div class="av3-log">' + (logHtml || '<i>journal vide</i>') + '</div>' +
        (a.resultFile ? '<button class="av3-btn-sm" id="av3-result">📄 voir le résultat</button>' : '') +
        (a.error ? '<div class="av3-err">' + esc(a.error) + '</div>' : '') +
        '<div id="av3-result-view"></div></div>';
      var cb = document.getElementById('av3-cancel');
      if (cb) cb.onclick = function () {
        api('/api/agents/' + a.id + '/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })
          .then(function () { refreshAgents(); });
      };
      var rb = document.getElementById('av3-result');
      if (rb) rb.onclick = function () {
        fetch('/api/agents/' + a.id + '/result').then(function (x) { return x.text(); }).then(function (t) {
          document.getElementById('av3-result-view').innerHTML = '<pre class="av3-result">' + esc(t.slice(0, 6000)) + '</pre>';
        });
      };
    }).catch(function () {});
  }
  timers.push(setInterval(function () { if (current === 'agents' && detailId) renderAgentDetail(); }, 2500));

  /* ── Panneau MONITEUR OS ──────────────────────────────────────────── */
  function renderSysmon() {
    title.innerHTML = '📊 Moniteur OS agentique';
    body.innerHTML = '<div id="av3-sys"></div>';
    refreshSysmon();
    timers.push(setInterval(refreshSysmon, 2000));
  }
  function refreshSysmon() {
    if (current !== 'sysmon') return;
    api('/api/sysmon').then(function (r) {
      var s = r && r.sysmon;
      var box = document.getElementById('av3-sys');
      if (!s || !box) return;
      var rows = (s.procs || []).map(function (p) {
        return '<tr' + (p.tag ? ' class="av3-tagged"' : '') + '><td>' + p.pid + '</td><td class="av3-cmd">' + esc(p.cmd) + '</td>' +
               '<td>' + p.cpu + '%</td><td>' + p.rssMb + ' Mo</td>' +
               (p.tag ? '<td><span class="av3-tag">' + esc(p.tag) + '</span></td>' : '<td></td>') + '</tr>';
      }).join('');
      box.innerHTML =
        '<div class="av3-gauges">' +
        '<div class="av3-gauge"><label>CPU global <b>' + s.cpu + '%</b> · ' + s.cpuCores + ' cœurs</label>' +
        '<div class="av3-bar"><i style="width:' + s.cpu + '%"></i></div></div>' +
        '<div class="av3-gauge"><label>RAM <b>' + s.ramUsedMb + '</b> / ' + s.ramTotalMb + ' Mo (' + s.ramPct + '%)</label>' +
        '<div class="av3-bar"><i style="width:' + s.ramPct + '%"></i></div></div>' +
        '<div class="av3-gauge"><label>Charge (1/5/15 min) <b>' + s.load.join(' · ') + '</b></label>' +
        '<div class="av3-bar"><i style="width:' + Math.min(100, s.load[0] * 100 / s.cpuCores) + '%"></i></div></div>' +
        '<div class="av3-gauge"><label>Uptime machine <b>' + fmtDur(s.uptimeS * 1000) + '</b> · daemon pid ' + s.serverPid + '</label></div>' +
        '</div>' +
        '<table class="av3-table"><thead><tr><th>PID</th><th>Commande</th><th>CPU</th><th>RAM</th><th></th></tr></thead>' +
        '<tbody>' + (rows || '<tr><td colspan="5"><i>lecture /proc…</i></td></tr>') + '</tbody></table>' +
        '<div class="av3-hint">lectures réelles dans /proc — repère <span class="av3-tag">ollama</span> et <span class="av3-tag">aether</span></div>';
    }).catch(function () {});
  }

  /* ── Panneau RÉGLAGES IA ──────────────────────────────────────────── */
  function renderIA() {
    title.innerHTML = '⚙️ Réglages IA réelle';
    body.innerHTML = '<div id="av3-ia"><div class="av3-empty">lecture de la config…</div></div>';
    refreshIA();
  }
  function refreshIA() {
    api('/api/ia').then(function (s) {
      if (!s || !s.ok) return;
      var box = document.getElementById('av3-ia');
      if (!box) return;
      var cards = (s.providers || []).map(function (p) {
        return '<div class="av3-prov' + (p.id === s.active ? ' av3-prov-active' : '') + '" data-id="' + p.id + '">' +
          '<div class="av3-prov-top"><b>' + esc(p.name) + '</b>' +
          (p.id === s.active ? '<span class="av3-tag av3-tag-on">ACTIVE</span>' : '') + '</div>' +
          '<div class="av3-prov-sub">type : ' + esc(p.type) + ' · modèle : ' + esc(p.model) +
          (p.keySet ? ' · <span class="av3-oktxt">clé ✓</span>' : (p.type === 'gemini' || p.type === 'openai') ? ' · <span class="av3-errtxt">clé absente</span>' : ' · <span class="av3-oktxt">sans clé</span>') +
          (p.fallback ? ' · repli : ' + esc(p.fallback) : '') + '</div>' +
          '<div class="av3-prov-actions"><button class="av3-btn-sm av3-test" data-id="' + p.id + '">⚡ Tester (vrai appel)</button>' +
          (p.id !== s.active ? '<button class="av3-btn-sm av3-use" data-id="' + p.id + '">utiliser</button>' : '') +
          '<span class="av3-test-out" data-out="' + p.id + '"></span></div></div>';
      }).join('');
      var o = s.ollama || {};
      var ag = s.agentique || {};
      box.innerHTML = cards +
        '<div class="av3-prov"><div class="av3-prov-top"><b>Ollama</b>' +
        (o.present ? '<span class="av3-tag av3-tag-on">en ligne</span>' : '<span class="av3-tag">absent — repli cléless actif</span>') + '</div>' +
        '<div class="av3-prov-sub">modèles installés : ' + (o.models && o.models.length ? esc(o.models.join(', ')) : '<i>aucun — ollama pull llama3.2:1b</i>') + '</div>' +
        '<div class="av3-prov-actions"><label class="av3-switch"><input type="checkbox" id="av3-ollastart"' + (ag.ollamaAutoStart ? ' checked' : '') + '> Ollama se lance TOUT SEUL au boot</label></div></div>' +
        '<div class="av3-prov"><div class="av3-prov-top"><b>Agents</b></div>' +
        '<div class="av3-prov-actions"><label>agents en parallèle : <input type="number" id="av3-maxc" min="1" max="4" value="' + (ag.maxConcurrent || 2) + '" style="width:52px"></label>' +
        '<button class="av3-btn-sm" id="av3-save-ag">enregistrer</button></div></div>';
      Array.prototype.forEach.call(box.querySelectorAll('.av3-test'), function (b) {
        b.onclick = function () {
          var id = b.getAttribute('data-id');
          var out = box.querySelector('[data-out="' + id + '"]');
          out.textContent = ' appel réel en cours…';
          api('/api/ia/test', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: id }) })
            .then(function (r) {
              out.innerHTML = r && r.ok
                ? '<span class="av3-oktxt"> ✓ ' + r.ms + ' ms — « ' + esc((r.extrait || '').slice(0, 40)) + ' »</span>'
                : '<span class="av3-errtxt"> ✗ ' + esc((r && r.error) || 'échec') + '</span>';
            });
        };
      });
      Array.prototype.forEach.call(box.querySelectorAll('.av3-use'), function (b) {
        b.onclick = function () {
          api('/api/ia/active', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: b.getAttribute('data-id') }) })
            .then(function () { refreshIA(); });
        };
      });
      var oa = document.getElementById('av3-ollastart');
      if (oa) oa.onchange = function () {
        api('/api/ia/ollama-autostart', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ on: oa.checked }) })
          .then(function (r) { alert(r && r.note ? r.note : 'enregistré'); });
      };
      var sa = document.getElementById('av3-save-ag');
      if (sa) sa.onclick = function () {
        var v = parseInt(document.getElementById('av3-maxc').value, 10) || 2;
        api('/api/ia/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ maxConcurrent: v }) })
          .then(function () { sa.textContent = '✓ enregistré'; });
      };
    }).catch(function (e) {
      var box = document.getElementById('av3-ia');
      if (box) box.innerHTML = '<div class="av3-empty">daemon v3 injoignable</div>';
    });
  }

  console.log('[aether-v3] poste agentique prêt — dock en bas à droite');
})();
AE_UI_V3
ok "ui/v3.js — dock Agents / Moniteur OS / Réglages IA (polling réel, aucun framework)"
chk "syntaxe ui/v3.js" "node --check '$APP_DIR/ui/v3.js'"

# ── Styles v3 (ajoutés à la fin : le thème OMEGA reste intact) ──────────
cat >> ui/style.css <<'AE_CSS_V3'

/* ═══ AETHER V3 — poste agentique (dock + panneaux) ═══ */
.av3-dock { position: fixed; right: 18px; bottom: 18px; z-index: 9000; display: flex; gap: 8px;
  padding: 8px; border-radius: 16px; background: rgba(10, 12, 28, .82); border: 1px solid rgba(64, 224, 255, .25);
  box-shadow: 0 8px 32px rgba(0, 0, 0, .55); backdrop-filter: blur(10px); }
.av3-dock-btn { display: flex; flex-direction: column; align-items: center; gap: 2px; width: 62px;
  padding: 8px 4px; border-radius: 12px; border: 1px solid transparent; background: transparent;
  color: #bfe9ff; cursor: pointer; font: 600 11px/1.2 system-ui, sans-serif; }
.av3-dock-btn small { font-size: 9px; opacity: .75; letter-spacing: .04em; }
.av3-dock-btn:hover { background: rgba(64, 224, 255, .12); border-color: rgba(64, 224, 255, .35); }
.av3-panel { position: fixed; top: 0; right: -560px; width: 540px; max-width: 94vw; height: 100vh; z-index: 9100;
  background: rgba(8, 10, 24, .96); border-left: 1px solid rgba(64, 224, 255, .3);
  box-shadow: -18px 0 48px rgba(0, 0, 0, .6); transition: right .25s ease; display: flex; flex-direction: column; }
.av3-panel.av3-open { right: 0; }
.av3-panel-head { display: flex; align-items: center; justify-content: space-between; padding: 14px 18px;
  border-bottom: 1px solid rgba(64, 224, 255, .18); color: #7ee7ff; font: 700 14px system-ui, sans-serif; }
.av3-x { background: none; border: none; color: #7ee7ff; font-size: 16px; cursor: pointer; }
.av3-panel-body { flex: 1; overflow-y: auto; padding: 14px 18px; color: #d7e6f5; font: 13px/1.5 system-ui, sans-serif; }
.av3-new-agent textarea { width: 100%; background: #0b0e22; color: #d7e6f5; border: 1px solid rgba(64, 224, 255, .3);
  border-radius: 10px; padding: 10px; font: 13px/1.5 inherit; resize: vertical; }
.av3-btn { margin-top: 8px; padding: 9px 16px; border-radius: 10px; border: 1px solid rgba(64, 224, 255, .5);
  background: linear-gradient(135deg, rgba(64, 224, 255, .2), rgba(64, 224, 255, .08)); color: #aef1ff;
  cursor: pointer; font-weight: 700; }
.av3-btn:hover { background: rgba(64, 224, 255, .25); }
.av3-btn-sm { padding: 4px 10px; border-radius: 8px; border: 1px solid rgba(64, 224, 255, .4); background: transparent;
  color: #aef1ff; cursor: pointer; font-size: 12px; margin-right: 6px; }
.av3-btn-sm:hover { background: rgba(64, 224, 255, .15); }
.av3-hint { display: block; margin-top: 6px; color: #6b7f99; font-size: 11px; }
.av3-list { margin-top: 12px; display: flex; flex-direction: column; gap: 8px; }
.av3-agent { padding: 10px 12px; border-radius: 12px; background: rgba(20, 26, 52, .6);
  border: 1px solid rgba(64, 224, 255, .14); cursor: pointer; }
.av3-agent-sel { border-color: rgba(64, 224, 255, .6); }
.av3-agent-top { display: flex; justify-content: space-between; align-items: center; gap: 8px; }
.av3-agent-id { font-family: ui-monospace, monospace; font-size: 11px; color: #7ee7ff; }
.av3-agent-task { margin-top: 4px; font-size: 12.5px; color: #d7e6f5; }
.av3-agent-steps { margin-top: 3px; font-size: 11px; color: #6b7f99; }
.av3-chip { padding: 2px 9px; border-radius: 99px; font-size: 10.5px; font-weight: 700; letter-spacing: .03em; }
.av3-chip-wait { background: rgba(140, 150, 170, .18); color: #aeb9c9; }
.av3-chip-run { background: rgba(64, 224, 255, .16); color: #7ee7ff; animation: av3pulse 1.4s infinite; }
.av3-chip-ok { background: rgba(46, 204, 113, .16); color: #7be3a6; }
.av3-chip-ko { background: rgba(231, 76, 60, .16); color: #ff9a8d; }
.av3-chip-cancel { background: rgba(241, 196, 15, .16); color: #ffe08a; }
.av3-chip-int { background: rgba(230, 126, 34, .16); color: #ffbf8a; }
@keyframes av3pulse { 50% { opacity: .55; } }
.av3-detail { margin-top: 14px; padding: 12px; border-radius: 12px; background: rgba(20, 26, 52, .5);
  border: 1px solid rgba(64, 224, 255, .18); }
.av3-detail-head { display: flex; align-items: center; gap: 10px; }
.av3-steps { margin-top: 10px; display: flex; flex-direction: column; gap: 6px; }
.av3-step { font-size: 12.5px; padding: 6px 10px; border-radius: 8px; background: rgba(10, 14, 32, .6); }
.av3-step-ok { color: #7be3a6; } .av3-step-run { color: #7ee7ff; } .av3-step-wait { color: #8b9bb0; }
.av3-step-ic { font-weight: 900; margin-right: 4px; }
.av3-log { margin-top: 10px; padding: 8px 10px; border-radius: 8px; background: #07091a;
  font: 11px/1.6 ui-monospace, monospace; color: #7f97b3; max-height: 160px; overflow-y: auto; }
.av3-result { margin-top: 10px; padding: 12px; border-radius: 10px; background: #07091a; color: #cde7ff;
  font: 12px/1.6 ui-monospace, monospace; white-space: pre-wrap; max-height: 320px; overflow-y: auto;
  border: 1px solid rgba(64, 224, 255, .2); }
.av3-err { margin-top: 8px; color: #ff9a8d; font-size: 12px; }
.av3-gauges { display: flex; flex-direction: column; gap: 12px; margin-bottom: 14px; }
.av3-gauge label { font-size: 12px; color: #9fb3c8; display: flex; justify-content: space-between; }
.av3-gauge label b { color: #7ee7ff; }
.av3-bar { margin-top: 5px; height: 10px; border-radius: 99px; background: rgba(20, 26, 52, .8); overflow: hidden; }
.av3-bar i { display: block; height: 100%; border-radius: 99px;
  background: linear-gradient(90deg, #22d3ee, #7c5cff); transition: width .6s ease; }
.av3-table { width: 100%; border-collapse: collapse; font-size: 11.5px; }
.av3-table th { text-align: left; color: #6b7f99; padding: 6px 8px; border-bottom: 1px solid rgba(64, 224, 255, .18); }
.av3-table td { padding: 5px 8px; border-bottom: 1px solid rgba(255, 255, 255, .05); color: #c3d3e3; }
.av3-table .av3-cmd { font-family: ui-monospace, monospace; font-size: 10.5px; color: #8ba3bd; max-width: 240px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.av3-table .av3-tagged td { background: rgba(64, 224, 255, .06); }
.av3-tag { padding: 1px 8px; border-radius: 99px; font-size: 10px; font-weight: 700;
  background: rgba(64, 224, 255, .14); color: #7ee7ff; }
.av3-tag-on { background: rgba(46, 204, 113, .18); color: #7be3a6; }
.av3-prov { margin-top: 10px; padding: 12px; border-radius: 12px; background: rgba(20, 26, 52, .55);
  border: 1px solid rgba(64, 224, 255, .14); }
.av3-prov-active { border-color: rgba(46, 204, 113, .45); }
.av3-prov-top { display: flex; justify-content: space-between; align-items: center; gap: 8px; color: #d7e6f5; }
.av3-prov-sub { margin-top: 4px; font-size: 12px; color: #8b9bb0; }
.av3-prov-actions { margin-top: 8px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; font-size: 12px; }
.av3-test-out { font-size: 12px; }
.av3-oktxt { color: #7be3a6; } .av3-errtxt { color: #ff9a8d; }
.av3-switch { display: flex; align-items: center; gap: 8px; cursor: pointer; color: #d7e6f5; }
.av3-empty { color: #6b7f99; font-style: italic; padding: 18px 0; text-align: center; }
AE_CSS_V3
ok "style.css — thème v3 ajouté (OMEGA intact)"

# ── index.html : une seule insertion (le script v3) ─────────────────────
node -e '
const fs = require("fs");
const f = process.argv[1];
let s = fs.readFileSync(f, "utf8");
if (s.indexOf("ui/v3.js") !== -1) { console.log("already"); process.exit(0); }
if (s.indexOf("</body>") === -1) { console.log("no-body"); process.exit(2); }
s = s.replace("</body>", "<script src=\"/ui/v3.js\"></script></body>");
fs.writeFileSync(f, s);
console.log("patched");
' "$APP_DIR/ui/index.html" 2>/dev/null || true
grep -q "ui/v3.js" "$APP_DIR/ui/index.html" \
  && ok "index.html — script v3 branché (dock apparaît dans la fenêtre)" \
  || warn "index.html : insertion à refaire (voir plus bas)"
chk "syntaxe index.html contient dock" "grep -q 'ui/v3.js' '$APP_DIR/ui/index.html'"
