
# ════════════════════════════════════════════════════════════════════
phase 8 "COMPILATION PRODUCTION — coffre app.asar, vérifs réelles, Bureau"
# ════════════════════════════════════════════════════════════════════
cd "$APP_DIR"
mkdir -p "$WORKSPACE"/{agents,textes,images,projets} build 2>/dev/null || true

# Dépendance temps réel présente ?
if node -e "require('ws')" >/dev/null 2>&1; then ok "module ws présent (terminal temps réel)"
else
  npm install --no-audit --no-fund --no-save --loglevel=error ws >/dev/null 2>&1 \
    && ok "module ws installé" || warn "ws absent — terminal sans WebSocket (le reste marche)"
fi

# Vérification syntaxique de TOUT le JavaScript v3 + cœur
SYNT_OK=1
for jf in main.js main-app.js preload.js server/core.js core/router.js core/agents.js core/sysmon.js core/aether-v3.js ui/v3.js; do
  if [ -f "$APP_DIR/$jf" ]; then
    if node --check "$APP_DIR/$jf" >/dev/null 2>&1; then ok "syntaxe : $jf"; else ko "syntaxe : $jf"; SYNT_OK=0; fi
  fi
done

# Auto-test du cœur sur un port jetable (serveur RÉEL, réponse RÉELLE)
SMOKE_PORT=$((PORT + 7))
if AETHER_PORT="$SMOKE_PORT" timeout 25 node server/core.js --smoke 2>/dev/null | grep -q "SMOKE_OK"; then
  ok "auto-test cœur : SMOKE_OK (port $SMOKE_PORT)"
else
  warn "auto-test cœur non concluant ici (port $SMOKE_PORT occupé ?) — le daemon reste prioritaire sur $PORT"
fi

# ── Coffre de production : le code cœur vit dans app.asar, plus lisible ──
LOADER_WRITTEN=0
if [ -f "$APP_DIR/main.js" ] && [ ! -f "$APP_DIR/main-app.js" ]; then
  cp "$APP_DIR/main.js" "$APP_DIR/main-app.js"
fi
cat > "$APP_DIR/main.js" <<'AE_LOADER_V3'
'use strict';
// NEXUS AETHER v3 — chargeur de production.
// Le cœur de l'app vit dans app.asar (code cœur non lisible dans le dossier).
// Si le coffre manque ou est cassé → repli TRANSPARENT sur main-app.js : rien ne casse.
try {
  require('./app.asar/main.js');
} catch (e) {
  console.error('[nexus-aether] coffre indisponible — repli local :', (e && e.message) || e);
  try { require('./main-app.js'); }
  catch (e2) { console.error('[nexus-aether] démarrage impossible :', (e2 && e2.message) || e2); process.exit(1); }
}
AE_LOADER_V3
ok "chargeur de production écrit (app.asar prioritaire, repli transparent)"
chk "syntaxe chargeur" "node --check '$APP_DIR/main.js'"

STAGE="$APP_DIR/.vault-stage"
rm -rf "$STAGE" && mkdir -p "$STAGE"
cp "$APP_DIR/main-app.js" "$STAGE/main.js"
for f in preload.js package.json; do [ -f "$APP_DIR/$f" ] && cp "$APP_DIR/$f" "$STAGE/"; done
for d in server core config ui build; do
  [ -d "$APP_DIR/$d" ] && mkdir -p "$STAGE/$d" && cp -r "$APP_DIR/$d/." "$STAGE/$d/"
done
rm -f "$STAGE/core/engine.js" "$STAGE/config/services.json" "$STAGE/ui/engine.js" 2>/dev/null || true
if (cd "$APP_DIR" && npx --yes @electron/asar pack .vault-stage app.asar >/dev/null 2>&1) && [ -s "$APP_DIR/app.asar" ]; then
  ok "coffre de production scellé : app.asar ($(du -h "$APP_DIR/app.asar" | cut -f1)) — code cœur plus lisible, repli automatique si casse"
  rm -rf "$STAGE"
else
  warn "scellement asar impossible ici — l'app fonctionne en clair (aucune casse, tu pourras resceller plus tard)"
  rm -rf "$STAGE"
fi

# ── Raccourci Bureau / menu ─────────────────────────────────────────
DESK_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
mkdir -p "$DESK_DIR"
cat > "$APP_DIR/build/nexus-aether.desktop" <<AE_DESK_V3
[Desktop Entry]
Type=Application
Name=NEXUS AETHER
Comment=Poste agentique — terminal, mémoire, agents arrière-plan, moniteur OS
Exec=$APP_DIR/scripts/aether-launch.sh
Icon=utilities-system-monitor
Terminal=false
Categories=Development;System;
StartupWMClass=nexus-aether
AE_DESK_V3
cp "$APP_DIR/build/nexus-aether.desktop" "$DESK_DIR/nexus-aether.desktop" 2>/dev/null || true
DESKTOP_USER="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Bureau")"
if [ -d "$DESKTOP_USER" ]; then
  cp "$APP_DIR/build/nexus-aether.desktop" "$DESKTOP_USER/nexus-aether.desktop" 2>/dev/null || true
  gio set "$DESKTOP_USER/nexus-aether.desktop" metadata::trusted true 2>/dev/null || true
  ok "raccourci posé : menu + $DESKTOP_USER"
else
  ok "raccourci posé : menu des applications"
fi

# ════════════════════════════════════════════════════════════════════
phase 9 "RAPPORT"
# ════════════════════════════════════════════════════════════════════
cat > "$APP_DIR/README.md" <<'AE_README_V3'
# NEXUS AETHER v3 — POSTE AGENTIQUE

**Aether = terminal réel + mémoire + agents en arrière-plan + moniteur OS + IA maîtresse réelle.**
Ce n'est PAS un hub de services : le hub (141 services) vit dans `~/Bureau/nexus-genedit/`
(genedit.py + genhub.sh), un projet séparé que cette installation ne touche jamais.

## Démarrage
- Menu des applications → **NEXUS AETHER**, ou : `~/Aether/scripts/aether-launch.sh`
- Le daemon persistant tourne SANS fenêtre : `systemctl --user status aether.service`
- Fermer la fenêtre n'arrête PAS le serveur ; redémarrer le PC le relance tout seul
  (systemd `Restart=always` + linger). Arrêt volontaire : `~/Aether/scripts/aether-stop.sh`.

## Agents (dock en bas à droite → 🤖)
- Écris une tâche → l'IA maîtresse planifie → les étapes s'exécutent en VRAI (appels IA réels)
- Résultat : `~/Aether/workspace/agents/<id>/result.md` · mémoire alimentée automatiquement
- La file vit dans le daemon : tu peux fermer la fenêtre, ça continue.

## IA réelle (dock → ⚙️)
- **Ollama** : modèle AUTO-DÉTECTÉ via `/api/tags` — plus jamais « model not found ».
  Un modèle manquant ? `ollama pull llama3.2:1b` (ou ton choix).
- **Repli cléless réel** : text.pollinations.ai (aucune clé) si Ollama est absent.
- Bouton **⚡ Tester** : un vrai appel API, ms réelles — pas de fausse option.
- Option « Ollama se lance tout seul » : cochable/décochable dans Réglages IA
  (unité systemd `aether-ollama.service`).

## Moniteur OS (dock → 📊)
Lectures réelles de `/proc` : CPU, RAM, charge, uptime, table des processus
avec repérage `ollama` / `aether`, pid du daemon.

## Séparation des projets
- `~/Aether` → poste agentique (CE dossier).
- `~/Bureau/nexus-genedit` → GenEdit (générateur CI/YAML) + GenHub (hub 141 services).
  Aucun fichier du hub ne vit dans Aether ; le catalogue ajouté par erreur a été retiré.

## Dépannage
- `journalctl --user -u aether.service -f` (logs daemon) · `curl http://127.0.0.1:8420/api/health`
- Sauvegardes : `~/Aether/.backup-v3-*` (et `.backup-v2-*` conservées).
- Re-sceller le coffre après modif : voir `npx @electron/asar pack` (le chargeur replie tout seul sinon).
AE_README_V3
ok "README.md v3 — identité, commandes, séparation des projets"

echo
if [ "$FAIL" -gt 0 ]; then
  echo -e "  ${C_RED}${C_B}✗ $FAIL contrôle(s) en échec — corrige avant d'investir du temps.${C_RST}"
  echo -e "  ${C_DIM}Sauvegarde : $BACKUP${C_RST}"
else
  echo -e "  ${C_GRN}${C_B}✦ NEXUS AETHER v3 — POSTE AGENTIQUE EN PLACE ($PASS contrôles verts).${C_RST}"
fi
echo
echo -e "  ${C_B}Maintenant :${C_RST}"
echo -e "   · lance  ${C_CYAN}$APP_DIR/scripts/aether-launch.sh${C_RST}  → fenêtre + dock en bas à droite"
echo -e "   · 🤖 Agents : écris une tâche, ça tourne en arrière-plan (résultat .md)"
echo -e "   · 📊 OS : CPU/RAM/processus réels · ⚙️ IA : bouton Tester = vrai appel"
echo -e "   · daemon : ${C_CYAN}systemctl --user status aether.service${C_RST} — survit aux fermetures"
echo -e "   · GenEdit + GenHub : ${C_DIM}~/Bureau/nexus-genedit — intouchés, comme convenu${C_RST}"
echo
