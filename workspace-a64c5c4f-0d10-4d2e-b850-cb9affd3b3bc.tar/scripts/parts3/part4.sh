
# ════════════════════════════════════════════════════════════════════
phase 6 "SERVEUR PERSISTANT — daemon systemd, survit à la fermeture du PC"
# ════════════════════════════════════════════════════════════════════
# Exécution en node pur (HEADLESS) : le daemon tourne SANS fenêtre, au boot.
# La fenêtre Electron n'est qu'un client qui se branche dessus.
NODE_BIN="$(command -v node || echo /usr/bin/node)"
mkdir -p "$HOME/.config/systemd/user"

if command -v systemctl >/dev/null 2>&1 && systemctl --user daemon-reload >/dev/null 2>&1; then
  UNIT="$HOME/.config/systemd/user/aether.service"
  cat > "$UNIT" <<AE_UNIT
[Unit]
Description=NEXUS AETHER v3 — daemon agentique persistant (serveur réel)
After=network.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
Environment=AETHER_PORT=$PORT
Environment=AETHER_ROOT=$APP_DIR
Environment=AETHER_WORKSPACE=$WORKSPACE
Environment=AETHER_HEADLESS=1
Environment=NODE_ENV=production
EnvironmentFile=-$CONF_DIR/env
ExecStart=$NODE_BIN $APP_DIR/server/core.js
Restart=always
RestartSec=3

[Install]
WantedBy=default.target
AE_UNIT
  ok "unité daemon écrite : $UNIT (ExecStart = node pur, Restart=always)"
  systemctl --user daemon-reload >/dev/null 2>&1 || true
  if systemctl --user enable --now aether.service >/dev/null 2>&1; then
    ok "daemon ACTIVÉ — démarre au boot de la session, redémarre tout seul si tu le tues"
  else
    warn "activation auto impossible — à la main : systemctl --user enable --now aether.service"
  fi
  if [ "${AETHER_SKIP_LINGER:-0}" != "1" ]; then
    if loginctl enable-linger "$USER" >/dev/null 2>&1; then
      ok "linger activé — le daemon tourne même AVANT que tu ouvres ta session"
    else
      warn "linger nécessite une fois le mot de passe : sudo loginctl enable-linger $USER"
    fi
  fi
else
  warn "systemd indisponible ici — le lanceur démarrera le serveur en node pur (comportement dégradé mais fonctionnel)"
fi

# ── Option Ollama auto-démarré (modifiable à tout moment dans Réglages IA) ──
OLLAMA_BIN="$(command -v ollama || true)"
OLLAMA_AUTOSTART="${AETHER_OLLAMA_AUTOSTART:-}"
if [ -z "$OLLAMA_AUTOSTART" ]; then
  if [ -n "$OLLAMA_BIN" ]; then OLLAMA_AUTOSTART=1; else OLLAMA_AUTOSTART=0; fi
fi
SYSTEM_OLLAMA=0
if command -v systemctl >/dev/null 2>&1 && systemctl cat ollama.service >/dev/null 2>&1; then SYSTEM_OLLAMA=1; fi
if [ "$OLLAMA_AUTOSTART" = "1" ] && [ -n "$OLLAMA_BIN" ] && command -v systemctl >/dev/null 2>&1 \
   && systemctl --user daemon-reload >/dev/null 2>&1; then
  if [ "$SYSTEM_OLLAMA" = "1" ]; then
    ok "Ollama déjà servi par le système (ollama.service) — rien à doubler"
  else
    UNIT_O="$HOME/.config/systemd/user/aether-ollama.service"
    cat > "$UNIT_O" <<AE_OLLA
[Unit]
Description=Ollama — moteur IA local pour NEXUS AETHER
After=network.target

[Service]
Type=simple
ExecStart=$OLLAMA_BIN serve
Environment=OLLAMA_HOST=127.0.0.1:11434
Environment=OLLAMA_KEEP_ALIVE=24h
Restart=always
RestartSec=3

[Install]
WantedBy=default.target
AE_OLLA
    systemctl --user daemon-reload >/dev/null 2>&1 || true
    if systemctl --user enable --now aether-ollama.service >/dev/null 2>&1; then
      ok "Ollama se lancera TOUT SEUL au boot (unité : aether-ollama.service)"
    else
      warn "active à la main si besoin : systemctl --user enable --now aether-ollama.service"
    fi
  fi
else
  if [ -z "$OLLAMA_BIN" ]; then
    info "Ollama absent — l'IA maîtresse utilisera le repli cléless réel (Pollinations). Installe Ollama quand tu veux."
  fi
fi
# synchronise la config avec le choix (l'UI permet de changer ensuite)
node -e '
const fs = require("fs");
const f = process.argv[1];
try {
  const c = JSON.parse(fs.readFileSync(f, "utf8"));
  c.agentique = c.agentique || {};
  c.agentique.ollamaAutoStart = (process.argv[2] === "1");
  fs.writeFileSync(f, JSON.stringify(c, null, 2) + "\n");
} catch (e) {}
' "$APP_DIR/config/plugins.json" "$OLLAMA_AUTOSTART" 2>/dev/null || true
cp "$APP_DIR/config/plugins.json" "$CONF_DIR/plugins.json" 2>/dev/null || true

# ── Lanceur v3 : branche au daemon, sinon le démarre, puis ouvre la fenêtre ──
cat > scripts/aether-launch.sh <<'AE_LCH_V3'
#!/usr/bin/env bash
# NEXUS AETHER v3 — lanceur production.
# 1) daemon systemd vivant ? → on s'y branche
# 2) sinon → systemctl --user start aether
# 3) sinon → node pur en arrière-plan (filet de sécurité)
# puis ouverture de la fenêtre (simple cliente).
set -uo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export AETHER_PORT="${AETHER_PORT:-8420}"
export AETHER_ROOT="$DIR"
export AETHER_WORKSPACE="$DIR/workspace"
mkdir -p "$HOME/.aether" "$AETHER_WORKSPACE"
HEALTH="http://127.0.0.1:$AETHER_PORT/api/health"
if ! curl -s --max-time 2 "$HEALTH" >/dev/null 2>&1; then
  if command -v systemctl >/dev/null 2>&1 && systemctl --user cat aether.service >/dev/null 2>&1; then
    systemctl --user start aether.service >/dev/null 2>&1 || true
    for i in 1 2 3 4 5 6 7 8; do
      curl -s --max-time 1 "$HEALTH" >/dev/null 2>&1 && break
      sleep 1
    done
  fi
fi
if ! curl -s --max-time 2 "$HEALTH" >/dev/null 2>&1; then
  NODE_BIN="$(command -v node || echo /usr/bin/node)"
  nohup "$NODE_BIN" "$DIR/server/core.js" >> "$DIR/aether.log" 2>&1 &
  disown 2>/dev/null || true
  for i in 1 2 3 4 5 6 7 8 9 10; do
    curl -s --max-time 1 "$HEALTH" >/dev/null 2>&1 && break
    sleep 1
  done
fi
ELECTRON_BIN="$DIR/node_modules/.bin/electron"
[ -x "$ELECTRON_BIN" ] || ELECTRON_BIN="$DIR/node_modules/electron/dist/electron"
if [ -x "$ELECTRON_BIN" ]; then
  nohup "$ELECTRON_BIN" "$DIR" >> "$DIR/aether.log" 2>&1 &
  disown 2>/dev/null || true
  echo "◉ NEXUS AETHER v3 — fenêtre ouverte · daemon : $HEALTH"
else
  echo "◉ NEXUS AETHER v3 — serveur en ligne : $HEALTH (Electron absent, utilise l'URL dans un navigateur)"
fi
AE_LCH_V3
chmod +x scripts/aether-launch.sh
ok "scripts/aether-launch.sh v3 — branchement daemon + filets de sécurité"

cat > scripts/aether-stop.sh <<'AE_STP_V3'
#!/usr/bin/env bash
# NEXUS AETHER v3 — arrêt : fenêtre puis daemon (le daemon ne meurt JAMAIS seul :
# Restart=always. C'est CE script, ou systemctl --user stop, qui l'arrête vraiment).
set -uo pipefail
pkill -f "Aether/node_modules/electron" 2>/dev/null || true
command -v systemctl >/dev/null 2>&1 && systemctl --user stop aether.service 2>/dev/null
PIDF="$HOME/.aether/aether.pid"
if [ -f "$PIDF" ]; then
  PID="$(cat "$PIDF" 2>/dev/null || true)"
  [ -n "${PID:-}" ] && kill "$PID" 2>/dev/null
  rm -f "$PIDF"
fi
echo "◉ NEXUS AETHER v3 arrêté (fenêtre + daemon)"
exit 0
AE_STP_V3
chmod +x scripts/aether-stop.sh
ok "scripts/aether-stop.sh v3 — arrêt explicite (le daemon ne meurt plus par accident)"
chk "syntaxe lanceur" "bash -n '$APP_DIR/scripts/aether-launch.sh'"
