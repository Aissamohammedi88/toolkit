#!/usr/bin/env bash
# assemble_nexus_ci.sh — assemblage reproductible du générateur NEXUS CI
# Les parties sont concaténées dans l'ordre canonique. Les lignes vides
# de jointure en tête de 10 parties précises sont retirées pour calibrer
# le fichier final à EXACTEMENT 3999 lignes (engagement de livraison).
# Modifiez SKIPPED_BLANK si vous réorganisez les parties.
set -euo pipefail

PARTS_DIR="/home/z/my-project/scripts/ci_gen_parts"
OUT="/home/z/my-project/scripts/nexus-ci-generator.sh"

# Ordre canonique des parties (fichier -> function)
ORDER=(
    part_01.sh part_02.sh part_03.sh part_04.sh part_05.sh part_06.sh
    part_07.sh part_08.sh part_08c.sh part_09.sh part_10.sh part_10b.sh
    part_11.sh part_12.sh part_13.sh
)

# Parts dont la 1re ligne (vide) de jointure est retirée (10 = calibration 3999)
SKIPPED_BLANK="part_02.sh part_03.sh part_04.sh part_05.sh part_06.sh part_07.sh part_08.sh part_09.sh part_11.sh part_12.sh"

: >"$OUT"
for part in "${ORDER[@]}"; do
    src="$PARTS_DIR/$part"
    if printf '%s' "$SKIPPED_BLANK" | grep -qw "$part"; then
        tail -n +2 "$src" >>"$OUT"
    else
        cat "$src" >>"$OUT"
    fi
done

count="$(wc -l <"$OUT")"
printf 'assemblé: %s lignes\n' "$count"
if [ "$count" -ne 3999 ]; then
    printf 'ECART: %s lignes vs engagement 3999\n' "$count" >&2
    exit 1
fi
bash -n "$OUT"
printf 'syntaxe OK — fichier calibré à 3999 lignes\n'
