#!/usr/bin/env bash
# Test e2e : serveur démarré → upgrade appliqué → santé re-vérifiée (même session)
set -u
export GENT_HOME=/tmp/gent-e2e
PORT=43112
cd /tmp
PORT=$PORT "$GENT_HOME/runtime/current/bin/node" --max-semi-space-size=64 "$GENT_HOME/app/gent-server.js" > /tmp/e2e.log 2>&1 &
SRV=$!
for i in $(seq 1 40); do curl -fsS http://127.0.0.1:$PORT/api/health >/dev/null 2>&1 && break; sleep 0.3; done
echo "pré-upgrade  /vision : $(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$PORT/vision)"
echo "pré-upgrade  server pid : $SRV"
bash /home/z/my-project/download/gent/gent-upgrade-vision.sh 2>&1 | tail -16
sleep 1
UP=0
for i in $(seq 1 30); do curl -fsS http://127.0.0.1:$PORT/api/health >/dev/null 2>&1 && { UP=1; break; }; sleep 0.3; done
echo "post-upgrade health up : $UP"
echo "post-upgrade /vision : $(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$PORT/vision)"
echo "post-upgrade health  : $(curl -s http://127.0.0.1:$PORT/api/health)"
echo "instance conservée   : $(python3 -c "import json;print(json.load(open('$GENT_HOME/identity/instance.json'))['instance_id'])")"
echo "backups              : $(ls $GENT_HOME/backup/ | tr '\n' ' ')"
kill $SRV 2>/dev/null
pkill -f "gent-server.js" 2>/dev/null
true
