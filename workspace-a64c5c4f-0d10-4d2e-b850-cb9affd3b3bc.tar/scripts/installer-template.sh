#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
#  NEXUS GEN HUB · Plasma — Installateur tout-en-un
#  ─────────────────────────────────────────────────────────────────────────
#  • Installe l'app dans  ~/Bureau/nexus-genhub-plasma/
#  • Relie GenEdit  (genedit.py + genhub.sh) via GENEDIT_HOME — lecture/édition
#    uniquement à travers l'app ; AUCUN fichier GenEdit n'est déplacé.
#  • Ne touche JAMAIS à ~/Aether (projet strictement séparé).
#  • Options :
#      --autostart   service systemd utilisateur (relance auto à chaque session)
#      --no-start    ne pas démarrer l'app à la fin
#      --port N      port du serveur (défaut 4310)
# ═══════════════════════════════════════════════════════════════════════════
set -euo pipefail

AUTOSTART=0; START_APP=1
PORT="${NEXUS_PORT:-4310}"
for arg in "$@"; do
  case "$arg" in
    --autostart) AUTOSTART=1 ;;
    --no-start)  START_APP=0 ;;
    --port)      : ;; # géré ci-dessous
  esac
done
# support "--port N"
while [[ $# -gt 0 ]]; do
  if [[ "$1" == "--port" && -n "${2:-}" ]]; then PORT="$2"; shift 2; else shift; fi
done

APP_DIR="$HOME/Bureau/nexus-genhub-plasma"
GENEDIT_DEFAULT="$HOME/Bureau/nexus-genedit"
AETHER_DIR="$HOME/Aether"
C=$'\033[0m'; B=$'\033[1m'; V=$'\033[35m'; G=$'\033[32m'; J=$'\033[33m'; R=$'\033[31m'

log()  { printf "${B}${V}▸${C} %s\n" "$1"; }
ok()   { printf "${B}${G}✔${C} %s\n" "$1"; }
warn() { printf "${B}${J}⚠${C} %s\n" "$1"; }
err()  { printf "${B}${R}✖ %s${C}\n" "$1" >&2; }

cat <<'BANNER'
     ███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗    █████╗
     ████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝   ╚███ ██╗
     ██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗   ████ ██║
     ██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║  ╚███ ██╔╝
     ██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║   ╚█ ███╔╝
     ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝    ╚═╝ ══╝
        GEN HUB · PLASMA — studio code + visuels + vidéo
BANNER
echo ""
log "Dossier cible   : ${B}$APP_DIR${C}"
log "GenEdit (relié) : ${B}$GENEDIT_DEFAULT${C}"
log "Aether          : ${B}$AETHER_DIR${C} — ${G}aucune modification, projet séparé${C}"
echo ""

# ── 0. Vérification Aether (sécurité) ─────────────────────────────────────
if [ -d "$AETHER_DIR" ]; then
  AETHER_BEFORE=$(find "$AETHER_DIR" -type f 2>/dev/null | wc -l)
  ok "Aether présent ($AETHER_BEFORE fichiers) — l'installateur n'y écrira rien."
fi

# ── 1. Extraction du paquet ───────────────────────────────────────────────
log "Extraction de l'application…"
PAYLOAD_LINE=$(grep -nm1 "^__NEXUS_PAYLOAD__$" "$0" | cut -d: -f1)
if [ -z "$PAYLOAD_LINE" ]; then err "Charge utile introuvable."; exit 1; fi
mkdir -p "$APP_DIR"
tail -n +"$((PAYLOAD_LINE + 1))" "$0" | base64 -d | tar xzf - --strip-components=1 -C "$APP_DIR"
ok "Fichiers extraits dans $APP_DIR"

# ── 2. Node.js ≥ 20.9 (via nvm si besoin, sans sudo) ─────────────────────
node_ok() { command -v node >/dev/null 2>&1 && [ "$(node -p 'parseInt(process.versions.node)')" -ge 20 ] 2>/dev/null; }
if ! node_ok; then
  log "Node.js ≥ 20 requis — installation via nvm (sans sudo)…"
  export NVM_DIR="$HOME/.nvm"
  if [ ! -s "$NVM_DIR/nvm.sh" ]; then
    curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash >/dev/null 2>&1
  fi
  # shellcheck disable=SC1091
  [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"
  nvm install 22 >/dev/null 2>&1 || nvm install --lts >/dev/null 2>&1
  nvm use 22 >/dev/null 2>&1 || nvm use node >/dev/null 2>&1
fi
if ! node_ok; then
  err "Node.js ≥ 20 introuvable après installation nvm. Installez Node 22 puis relancez."
  exit 1
fi
ok "Node $(node --version) — npm $(npm --version)"

# ── 3. Dépendances ────────────────────────────────────────────────────────
cd "$APP_DIR"
log "Installation des dépendances (1–3 min)…"
NPM_OK=0
for i in 1 2 3; do
  if npm install --no-audit --no-fund --loglevel=error; then NPM_OK=1; break; fi
  warn "Tentative $i échouée — nouvel essai…"; sleep 3
done
[ "$NPM_OK" = "1" ] || { err "npm install a échoué 3 fois (réseau ?). Relancez l'installateur."; exit 1; }
ok "Dépendances installées"

# ── 4. Base de données (Prisma + SQLite) ──────────────────────────────────
mkdir -p "$APP_DIR/db/media"
export DATABASE_URL="file:$APP_DIR/db/custom.db"
log "Création de la base de données…"
npx prisma db push --accept-data-loss --skip-generate >/dev/null 2>&1 || npx prisma db push --accept-data-loss >/dev/null
npx prisma generate >/dev/null
ok "Base prête : $APP_DIR/db/custom.db"

# ── 5. Compilation production ─────────────────────────────────────────────
log "Compilation de l'application (2–4 min)…"
if npm run build >"$APP_DIR/build.log" 2>&1; then
  ok "Build production terminé"
else
  err "Build échoué — voir $APP_DIR/build.log"; tail -20 "$APP_DIR/build.log"; exit 1
fi

# ── 6. Lanceur + raccourci Bureau ────────────────────────────────────────
NODE_BIN="$(command -v node)"
mkdir -p "$APP_DIR"
cat > "$APP_DIR/genhub-plasma.sh" <<LAUNCH
#!/usr/bin/env bash
# NEXUS GEN HUB · Plasma — lanceur (généré par l'installateur)
set -euo pipefail
APP_DIR="\$HOME/Bureau/nexus-genhub-plasma"
PORT="\${NEXUS_PORT:-$PORT}"
GENEDIT_HOME="\${GENEDIT_HOME:-$GENEDIT_DEFAULT}"
NODE_BIN="\${NEXUS_NODE:-$NODE_BIN}"
if [ -z "\$NODE_BIN" ]; then
  NODE_BIN="\$(command -v node || true)"
fi
if [ -z "\$NODE_BIN" ]; then
  NODE_BIN="\$(ls -1 "\$HOME"/.nvm/versions/node/*/bin/node 2>/dev/null | sort -V | tail -1 || true)"
fi
if [ -z "\$NODE_BIN" ]; then echo "✖ Node introuvable — lancez l'installateur à nouveau."; exit 1; fi
export DATABASE_URL="file:\$APP_DIR/db/custom.db"
export NEXUS_DATA_DIR="\$APP_DIR/db/media"
export GENEDIT_HOME PORT
mkdir -p "\$NEXUS_DATA_DIR"
cd "\$APP_DIR"

# Déjà en ligne ? → on ouvre simplement le navigateur
if curl -sf "http://localhost:\$PORT/api/auth" >/dev/null 2>&1; then
  echo "◆ GenHub Plasma est déjà en ligne : http://localhost:\$PORT"
  xdg-open "http://localhost:\$PORT" >/dev/null 2>&1 || true
  exit 0
fi

echo "◆ Démarrage de NEXUS GEN HUB · Plasma (port \$PORT)…"
nohup "\$NODE_BIN" "\$APP_DIR/.next/standalone/server.js" >> "\$APP_DIR/server.log" 2>&1 &
for i in \$(seq 1 30); do
  curl -sf "http://localhost:\$PORT/api/auth" >/dev/null 2>&1 && break
  sleep 1
done
if curl -sf "http://localhost:\$PORT/api/auth" >/dev/null 2>&1; then
  echo "✔ En ligne : http://localhost:\$PORT"
  echo "  (journal : \$APP_DIR/server.log)"
else
  echo "✖ Le serveur ne répond pas — vérifiez \$APP_DIR/server.log"
  exit 1
fi
xdg-open "http://localhost:\$PORT" >/dev/null 2>&1 || true
LAUNCH
chmod +x "$APP_DIR/genhub-plasma.sh"
cp -f "$APP_DIR/genhub-plasma.sh" "$HOME/Bureau/genhub-plasma.sh" 2>/dev/null || true
ok "Lanceur : ~/Bureau/genhub-plasma.sh"

DESKTOP="$HOME/Bureau/GenHub-Plasma.desktop"
cat > "$DESKTOP" <<DESK
[Desktop Entry]
Version=1.0
Type=Application
Name=GenHub · Plasma
Comment=Studio de génération NEXUS — code, visuels, vidéo
Exec=$HOME/Bureau/genhub-plasma.sh
Icon=applications-graphics
Terminal=false
Categories=Development;
DESK
chmod +x "$DESKTOP" 2>/dev/null || true
command -v gio >/dev/null 2>&1 && gio set "$DESKTOP" metadata::trusted true 2>/dev/null || true
ok "Raccourci Bureau : GenHub-Plasma.desktop"

# ── 7. Service auto (option --autostart) ─────────────────────────────────
if [ "$AUTOSTART" = "1" ]; then
  mkdir -p "$HOME/.config/systemd/user"
  UNIT="$HOME/.config/systemd/user/nexus-genhub.service"
  cat > "$UNIT" <<UNIT
[Unit]
Description=NEXUS GEN HUB · Plasma (port $PORT)
After=default.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
Environment=DATABASE_URL=file:$APP_DIR/db/custom.db
Environment=NEXUS_DATA_DIR=$APP_DIR/db/media
Environment=GENEDIT_HOME=$GENEDIT_DEFAULT
Environment=PORT=$PORT
Environment=HOSTNAME=127.0.0.1
ExecStart=$NODE_BIN $APP_DIR/.next/standalone/server.js
Restart=always
RestartSec=3

[Install]
WantedBy=default.target
UNIT
  systemctl --user daemon-reload 2>/dev/null || true
  systemctl --user enable --now nexus-genhub.service 2>/dev/null \
    && ok "Service auto activé : systemctl --user status nexus-genhub" \
    || warn "systemd user indisponible — utilisez ./genhub-plasma.sh pour démarrer."
fi

# ── 8. Démarrage + vérification ───────────────────────────────────────────
if [ "$START_APP" = "1" ]; then
  log "Démarrage initial…"
  "$APP_DIR/genhub-plasma.sh" || true
fi

echo ""
echo "${B}${V}══════════════════════════════════════════════════════════${C}"
ok "NEXUS GEN HUB · Plasma installé"
echo "   ${B}App          :${C} http://localhost:$PORT"
echo "   ${B}Démarrage    :${C} ~/Bureau/genhub-plasma.sh  (ou double-clic raccourci)"
echo "   ${B}GenEdit      :${C} relié via GENEDIT_HOME (lecture/édition depuis l'app)"
echo "   ${B}Aether       :${C} intact — aucun fichier modifié"
echo "   ${B}Premier compte:${C} la 1ʳᵉ inscription devient compte ${V}fondateur${C}"
echo "   ${B}Service auto :${C} relancez avec --autostart si non fait"
echo "${V}══════════════════════════════════════════════════════════${C}"
exit 0

__NEXUS_PAYLOAD__
