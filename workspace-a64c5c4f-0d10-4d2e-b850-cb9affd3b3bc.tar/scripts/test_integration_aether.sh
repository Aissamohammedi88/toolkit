#!/usr/bin/env bash
# Test d'intégration réseau Aether : bootstrap + 2 workers + client.
# Vérifie : tunnel chiffré, distribution des morceaux, agrégation, exactitude
# du résultat (contre-vérification Python indépendante).
set -uo pipefail

DIR=${1:-/tmp/aether-it}
PORT=${2:-41231}
NODE=/home/z/my-project/aether/target/debug/aether-node
mkdir -p "$DIR"
rm -f "$DIR"/*.log "$DIR"/result.json

cleanup() { pkill -f "aether-node (bootstrap|worker)" 2>/dev/null; }
trap cleanup EXIT

attendre() { # attendre <fichier> <motif> <essais>
    local fichier=$1 motif=$2 essais=${3:-100}
    for _ in $(seq 1 "$essais"); do
        grep -q "$motif" "$fichier" 2>/dev/null && return 0
        sleep 0.3
    done
    echo "ATTENTE ÉCHOUÉE : '$motif' introuvable dans $fichier" >&2
    return 1
}

echo "[IT] démarrage du routeur (port $PORT)…"
"$NODE" bootstrap --port "$PORT" >"$DIR/bootstrap.out" 2>"$DIR/bootstrap.log" &
BOOT_PID=$!
attendre "$DIR/bootstrap.log" "écoute :" || exit 1

echo "[IT] démarrage de 2 nœuds calculants…"
"$NODE" worker --bootstrap "/ip4/127.0.0.1/tcp/$PORT" >"$DIR/w1.out" 2>"$DIR/w1.log" &
"$NODE" worker --bootstrap "/ip4/127.0.0.1/tcp/$PORT" >"$DIR/w2.out" 2>"$DIR/w2.log" &
attendre "$DIR/bootstrap.log" "enregistré" || exit 1
sleep 1
NB_ENREG=$(grep -c "enregistré" "$DIR/bootstrap.log")
echo "[IT] nœuds calculants enregistrés : $NB_ENREG"

echo "[IT] soumission : premiers dans [2, 200000], 8 morceaux…"
"$NODE" submit --bootstrap "/ip4/127.0.0.1/tcp/$PORT" --from 2 --to 200000 --chunks 8 --timeout 60 \
    >"$DIR/result.json" 2>"$DIR/client.log"
RC=$?

echo "[IT] code retour du client : $RC"
if [ $RC -ne 0 ]; then
    echo "--- journal client ---"; cat "$DIR/client.log"
    echo "--- journal routeur (fin) ---"; tail -5 "$DIR/bootstrap.log"
    exit 1
fi

cat "$DIR/result.json"

# Contre-vérification indépendante (crible Python)
attendu=$(python3 -c "
n=200000
s=bytearray([1])*(n+1); s[0]=s[1]=0
for i in range(2,int(n**0.5)+1):
    if s[i]: s[i*i::i]=bytearray(len(s[i*i::i]))
print(sum(s[2:]))")
recu=$(python3 -c "import json;print(json.load(open('$DIR/result.json'))['primes_found'])")
echo "[IT] premiers attendus (Python) : $attendu — reçus (Aether) : $recu"
[ "$attendu" = "$recu" ] || { echo "MISMATCH !"; exit 1; }

# Le tunnel chiffré doit être attesté dans les journaux
grep -q "tunnel chiffré établi" "$DIR/bootstrap.log" && echo "[IT] tunnel chiffré attesté dans le journal du routeur ✓"

# Les deux workers ont-ils travaillé ?
N1=$(grep -c "calcul…" "$DIR/w1.log" || true)
N2=$(grep -c "calcul…" "$DIR/w2.log" || true)
echo "[IT] morceaux calculés : worker1=$N1 worker2=$N2"

echo "[IT] SUCCÈS TOTAL"
