#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
NEXUS DEVQUEST — Engine
═══════════════════════════════════════════════════════════════════════════════
Transforme un repo GitHub en RPG. À chaque push :
  1. Calcule XP (lignes ajoutées, supprimées, fichiers touchés, commits)
  2. Met à jour niveau + titre (Novice → Légende)
  3. Génère 3 badges SVG animés (level, xp, title)
  4. Génère un avatar ASCII basé sur les langages du repo
  5. Génère des "quêtes" basées sur l'état du repo
  6. Écrit README-devquest.md (fiche de personnage)
  7. Archive chaque niveau dans .devquest/history.jsonl

Stack : Python 3 stdlib pur (json, os, subprocess, math, datetime, hashlib, urllib)
Auteur : Aissa Mohammedi (DGK)
═══════════════════════════════════════════════════════════════════════════════
"""

import os
import sys
import json
import math
import time
import random
import hashlib
import datetime
import subprocess
from pathlib import Path

# ═══════════════════════════════════════════════════════════════════════════════
# §1 — CONFIG
# ═══════════════════════════════════════════════════════════════════════════════

VERSION  = "1.0.0"
CODENAME = "Repo RPG Engine"

REPO_ROOT  = Path(os.environ.get("GITHUB_WORKSPACE", os.getcwd()))
DEVQUEST   = REPO_ROOT / ".devquest"
STATE_FILE = DEVQUEST / "state.json"
HISTORY    = DEVQUEST / "history.jsonl"
BADGES_DIR = REPO_ROOT / "badges"
README_OUT = REPO_ROOT / "README-devquest.md"

DEVQUEST.mkdir(parents=True, exist_ok=True)
BADGES_DIR.mkdir(parents=True, exist_ok=True)

# XP per unit
XP_PER_LINE_ADD  = 1
XP_PER_LINE_DEL  = 0.5
XP_PER_FILE      = 2
XP_PER_COMMIT    = 5
XP_PER_PR_MERGE  = 25
DAILY_XP_BONUS   = 10  # if last push was > 24h ago, streak bonus

# Levels: 100 * (N-1)^2 cumulative XP
# Level 1 = 0, Level 2 = 100, Level 3 = 400, Level 5 = 1600, Level 10 = 8100, Level 20 = 36100
def xp_for_level(n: int) -> int:
    if n <= 1:
        return 0
    return 100 * (n - 1) ** 2


def level_from_xp(xp: int) -> tuple:
    """Returns (level, current_level_xp, next_level_xp, progress_pct)."""
    n = 1
    while xp_for_level(n + 1) <= xp:
        n += 1
    cur = xp_for_level(n)
    nxt = xp_for_level(n + 1)
    progress = (xp - cur) / max(1, nxt - cur) * 100
    return n, xp - cur, nxt - cur, round(progress, 1)


# Titles per level
TITLES = [
    (2,  "Novice"),
    (4,  "Apprenti"),
    (7,  "Codeur"),
    (11, "Artisan"),
    (16, "Architecte"),
    (26, "Maître"),
    (41, "Légende"),
    (999, "Mythe"),
]


def title_for_level(level: int) -> str:
    for threshold, title in TITLES:
        if level < threshold:
            return title
    return "Mythe"


# Achievements — unlocked by state inspection
ACHIEVEMENTS = [
    ("first_commit",  "🌱 First Blood",       "Premier commit",            lambda s: s["total_commits"] >= 1),
    ("level_5",       "⚡ Spark",             "Atteint le niveau 5",       lambda s: s["level"] >= 5),
    ("level_10",      "🔥 On Fire",          "Atteint le niveau 10",       lambda s: s["level"] >= 10),
    ("level_25",      "👑 Demigod",          "Atteint le niveau 25",      lambda s: s["level"] >= 25),
    ("level_50",      "🌟 Ascending",        "Atteint le niveau 50",      lambda s: s["level"] >= 50),
    ("100_commits",   "💯 Centurion",        "100 commits cumulés",       lambda s: s["total_commits"] >= 100),
    ("1000_commits",  "🚀 Millennium",       "1000 commits cumulés",      lambda s: s["total_commits"] >= 1000),
    ("polyglot",      "🌍 Polyglot",         "5+ langages différents",     lambda s: len(s["languages"]) >= 5),
    ("night_owl",     "🦉 Night Owl",        "Push entre 23h et 5h",      lambda s: 23 <= s["last_hour"] or s["last_hour"] < 5),
    ("weekend",       "🎮 Weekender",        "Push le week-end",          lambda s: s["last_dow"] in (5, 6)),
    ("tests_warrior", "⚔️ Tests Warrior",    "10+ fichiers de test",       lambda s: s["test_count"] >= 10),
    ("doc_master",    "📚 Doc Master",       "README > 1KB",              lambda s: s["readme_size"] >= 1024),
]


# ═══════════════════════════════════════════════════════════════════════════════
# §2 — GIT STATS
# ═══════════════════════════════════════════════════════════════════════════════

def git(*args, check: bool = True) -> str:
    try:
        r = subprocess.run(
            ["git", *args],
            cwd=REPO_ROOT, capture_output=True, text=True,
            timeout=30, check=check,
        )
        return r.stdout.strip()
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
        return ""


def get_commit_stats(before: str, after: str) -> dict:
    """Returns dict with insertions, deletions, files_touched, commits_count."""
    stats = {"insertions": 0, "deletions": 0, "files_touched": 0, "commits_count": 0}
    if not before or not after or before == "0000000000000000000000000000000000000000":
        # Initial commit — count everything
        out = git("log", "--oneline", "--numstat")
    else:
        out = git("log", "--oneline", "--numstat", f"{before}..{after}")
    if not out:
        return stats
    for line in out.splitlines():
        # Format: "abc1234 message" (commit) OR "+X  -Y  path" (numstat)
        parts = line.split("\t")
        if len(parts) == 3:
            try:
                ins = int(parts[0]) if parts[0] != "-" else 0
                dele = int(parts[1]) if parts[1] != "-" else 0
                stats["insertions"] += ins
                stats["deletions"] += dele
                stats["files_touched"] += 1
            except ValueError:
                pass
        elif line and not line.startswith(" ") and len(line) > 8:
            # commit line
            stats["commits_count"] += 1
    return stats


def get_repo_languages() -> dict:
    """Returns {ext: lines_count} approximative."""
    out = git("ls-files")
    if not out:
        return {}
    counts = {}
    for fname in out.splitlines():
        if "." not in fname:
            continue
        ext = "." + fname.rsplit(".", 1)[-1].lower()
        # Skip noise
        if ext in (".lock", ".sum", ".mod"):
            continue
        try:
            size = (REPO_ROOT / fname).stat().st_size
        except (FileNotFoundError, OSError):
            continue
        counts[ext] = counts.get(ext, 0) + size
    return dict(sorted(counts.items(), key=lambda x: -x[1])[:10])


def get_test_count() -> int:
    out = git("ls-files")
    if not out:
        return 0
    n = 0
    for fname in out.splitlines():
        b = fname.lower()
        if b.startswith("test") or b.endswith(("_test.go", "_test.py", "test.js", "test.ts")) \
           or "/test" in b or "/tests/" in b or "spec." in b:
            n += 1
    return n


def get_readme_size() -> int:
    for name in ("README.md", "README.MD", "README.rst", "README.txt", "README"):
        p = REPO_ROOT / name
        if p.exists():
            try:
                return p.stat().st_size
            except OSError:
                pass
    return 0


def get_total_commits() -> int:
    out = git("rev-list", "--count", "HEAD")
    try:
        return int(out)
    except ValueError:
        return 0


def get_now_local() -> tuple:
    """Returns (hour, dow) — hour 0-23, dow 0-6 (Mon=0)."""
    now = datetime.datetime.now()
    return now.hour, now.weekday()


# ═══════════════════════════════════════════════════════════════════════════════
# §3 — STATE
# ═══════════════════════════════════════════════════════════════════════════════

def load_state() -> dict:
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {
        "version": VERSION,
        "actor": os.environ.get("ACTOR", "unknown"),
        "repo": os.environ.get("REPOSITORY", "unknown"),
        "xp": 0,
        "level": 1,
        "title": "Novice",
        "total_commits": 0,
        "total_insertions": 0,
        "total_deletions": 0,
        "total_files_touched": 0,
        "achievements": [],
        "languages": {},
        "streak_days": 0,
        "last_push": None,
        "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "history_levels": [],
    }


def save_state(state: dict) -> None:
    STATE_FILE.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")


def append_history(event: dict) -> None:
    with HISTORY.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


# ═══════════════════════════════════════════════════════════════════════════════
# §4 — BADGES SVG (animated, no deps)
# ═══════════════════════════════════════════════════════════════════════════════

def svg_badge(label: str, value: str, color_left: str, color_right: str,
              animated: bool = True) -> str:
    """Returns a single animated SVG badge (shields.io-style)."""
    width = 100
    height = 28
    # Pulse animation for the right side
    anim = ""
    style = ""
    if animated:
        anim = f"""
        <animate attributeName="fill" values="{color_right};{color_left};{color_right}"
                 dur="3s" repeatCount="indefinite"/>
        """
        style = ' style="animation: pulse 2s ease-in-out infinite"'
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" role="img">
<rect width="{width}" height="{height}" rx="4" fill="{color_left}"/>
<rect x="35" width="65" height="{height}" rx="4" fill="{color_right}"{style}/>
<text x="17" y="18" fill="#fff" font-family="-apple-system,Segoe UI,Ubuntu,sans-serif"
      font-size="11" font-weight="700" text-anchor="middle">{label}</text>
<text x="67" y="18" fill="#fff" font-family="-apple-system,Segoe UI,Ubuntu,sans-serif"
      font-size="11" font-weight="700" text-anchor="middle">{value}</text>{anim}
</svg>"""


def svg_xp_bar(level: int, cur_xp_in_level: int, xp_to_next: int, progress: float) -> str:
    """Returns an animated XP progress bar SVG."""
    width = 200
    height = 28
    bar_w = int(width * progress / 100)
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" role="img">
<rect width="{width}" height="{height}" rx="14" fill="#1a1a1a" stroke="#27272a"/>
<rect width="{bar_w}" height="{height}" rx="14" fill="#00f0ff">
  <animate attributeName="width" from="0" to="{bar_w}" dur="1s" fill="freeze"/>
</rect>
<text x="{width//2}" y="18" fill="#fff" font-family="-apple-system,Segoe UI,Ubuntu,sans-serif"
      font-size="11" font-weight="700" text-anchor="middle">
  LVL {level} · {cur_xp_in_level}/{xp_to_next} XP ({progress:.1f}%)
</text>
</svg>"""


def save_badge(name: str, svg: str) -> None:
    (BADGES_DIR / f"{name}.svg").write_text(svg, encoding="utf-8")


# ═══════════════════════════════════════════════════════════════════════════════
# §5 — ASCII AVATAR
# ═══════════════════════════════════════════════════════════════════════════════

# Different ASCII avatars per primary language family
AVATARS = {
    "python": r"""
    ⠀⠀⠀⣀⣤⠤⠤⠤⠤⠤⠤⠤⠤⠤⠤⠤⠤⠤⣄⡀
    ⠀⢠⡞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢳
    ⠀⡏⠀⠀⣠⣶⣶⣶⣶⣶⣶⣦⣄⠀⠀⠀⠀⠀⢸
    ⠀⡇⠀⠀⣿⣿⡟⢹⣿⣿⢹⣿⣿⠀⠀⠀⠀⠀⢸
    ⠀⡇⠀⠀⣿⣿⡄⣀⣿⣿⣀⣸⣿⡇⠀⠀⠀⠀⠀⢸
    ⠀⡇⠀⠀⣿⣿⡇⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⢸
    ⠀⡇⠀⠀⣿⣿⡇⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⢸
    ⠀⡇⠀⠀⣿⣿⡇⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⢸
    ⠀⡇⠀⠀⣿⣿⡇⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⢸
    ⠀⡇⠀⠀⣿⣿⡄⣀⣿⣿⣀⣸⣿⡇⠀⠀⠀⠀⠀⢸
    ⠀⡇⠀⠀⣿⣿⡟⢹⣿⣿⢹⣿⣿⠀⠀⠀⠀⠀⢸
    ⠀⡇⠀⠀⠙⠛⠛⠛⠛⠛⠛⠛⠋⠀⠀⠀⠀⠀⢸
    ⠀⠙⠒⠤⠤⠤⠤⠤⠤⠤⠤⠤⠤⠤⠒⠒⠒⠋
""",
    "rust": r"""
    ⠀⢀⣠⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣄⡀
    ⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇
    ⠀⣿⣿⡇⢹⣿⣿⢹⣿⣿⢹⣿⡇⢹⣿⣿⣿⣿⡇
    ⠀⣿⣿⡇⢸⣿⣿⢸⣿⣿⢸⣿⡇⢸⣿⣿⣿⣿⡇
    ⠀⣿⣿⡇⢸⣿⣿⢸⣿⣿⢸⣿⡇⢸⣿⣿⣿⣿⡇
    ⠀⣿⣿⡇⢸⣿⣿⢸⣿⣿⢸⣿⡇⢸⣿⣿⣿⣿⡇
    ⠀⣿⣿⡇⢸⣿⣿⢸⣿⣿⢸⣿⡇⢸⣿⣿⣿⣿⡇
    ⠀⣿⣿⡇⢸⣿⣿⢸⣿⣿⢸⣿⡇⢸⣿⣿⣿⣿⡇
    ⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇
    ⠀⠈⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉
""",
    "js": r"""
    ⠀⢀⣠⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣄⡀
    ⠀⣿⣿⠟⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠻⣿⡇
    ⠀⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇
    ⠀⣿⣿⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇
    ⠀⣿⣿⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇
    ⠀⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇
    ⠀⣿⣿⠀⠀⢹⣿⣿⢹⣿⣿⢹⣿⣿⢹⣿⣿⡇
    ⠀⣿⣿⠀⠀⢸⣿⣿⢸⣿⣿⢸⣿⣿⢸⣿⣿⡇
    ⠀⣿⣿⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣿⡇
    ⠀⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉
""",
    "go": r"""
    ⠀⠀⠀⢀⣠⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣄⡀
    ⠀⢠⡞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢳
    ⠀⡏⠀⠀⣠⣄⣀⣀⣀⣀⣀⣀⣀⣀⣠⣄⠀⠀⠀⢸
    ⠀⡇⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⢸
    ⠀⡇⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⢸
    ⠀⡇⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⢸
    ⠀⡇⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⢸
    ⠀⠻⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣴⠛
""",
    "default": r"""
    ⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣤⣤⣤⣄⡀⠀⠀⠀⠀
    ⠀⠀⠀⠀⠀⠀⠀⢠⣶⠋⠉⠀⠀⠉⠙⣦⡀⠀⠀⠀
    ⠀⠀⠀⠀⠀⠀⠀⣼⡇⠀⠀⣀⣀⠀⠀⢸⣷⠀⠀⠀
    ⠀⠀⠀⠀⠀⠀⠀⣿⣇⠀⢠⣿⣿⡄⠀⣸⣿⠀⠀⠀
    ⠀⠀⠀⠀⠀⠀⠀⠈⠙⠇⣼⣿⣿⣷⠸⠋⠁⠀⠀⠀
    ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠀⠀⠀⠀⠀⠀
""",
}


def detect_primary_language(languages: dict) -> str:
    """Map file extensions to language families."""
    if not languages:
        return "default"
    # ext is the dominant one
    top_ext = list(languages.keys())[0]
    mapping = {
        ".py":   "python",
        ".rs":   "rust",
        ".js":   "js", ".mjs": "js", ".cjs": "js",
        ".ts":   "js", ".tsx": "js",
        ".go":   "go",
        ".java": "default", ".kt": "default",
        ".c":    "default", ".cpp": "default", ".h": "default",
        ".rb":   "default",
        ".php":  "default",
        ".sh":   "default",
        ".yml":  "default", ".yaml": "default",
        ".md":   "default",
    }
    return mapping.get(top_ext, "default")


def render_avatar(languages: dict) -> str:
    return AVATARS.get(detect_primary_language(languages), AVATARS["default"])


# ═══════════════════════════════════════════════════════════════════════════════
# §6 — QUESTS
# ═══════════════════════════════════════════════════════════════════════════════

def generate_quests(state: dict) -> list:
    """Generate 3 quests based on current repo state."""
    quests = []
    test_count = state.get("test_count", 0)
    readme_size = state.get("readme_size", 0)
    n_languages = len(state.get("languages", {}))
    level = state.get("level", 1)

    # Test quest
    target_tests = max(10, test_count + 5)
    needed = target_tests - test_count
    if needed > 0:
        quests.append({
            "id": "tests",
            "title": "⚔️ Test Knight",
            "desc": f"Ajoute {needed} fichier(s) de test pour débloquer le titre 'Test Knight'.",
            "progress": f"{test_count}/{target_tests}",
            "pct": round(test_count / target_tests * 100, 1),
        })

    # Doc quest
    target_readme = max(2048, readme_size + 500)
    needed = target_readme - readme_size
    if needed > 0:
        quests.append({
            "id": "docs",
            "title": "📚 Doc Scribe",
            "desc": f"Étends ton README de {needed} caractères pour débloquer 'Doc Scribe'.",
            "progress": f"{readme_size}/{target_readme} octets",
            "pct": round(readme_size / target_readme * 100, 1),
        })

    # Language quest
    target_lang = max(5, n_languages + 1)
    needed = target_lang - n_languages
    if needed > 0:
        quests.append({
            "id": "polyglot",
            "title": "🌍 Polyglot",
            "desc": f"Ajoute {needed} langage(s) de plus pour débloquer 'Polyglot'.",
            "progress": f"{n_languages}/{target_lang} langages",
            "pct": round(n_languages / target_lang * 100, 1),
        })

    # Level quest
    next_level = level + 1
    xp_now = state.get("xp", 0)
    xp_target = xp_for_level(next_level)
    needed = xp_target - xp_now
    if needed > 0:
        quests.append({
            "id": "levelup",
            "title": "⭐ Next Level",
            "desc": f"Encore {needed} XP pour atteindre le niveau {next_level} ({title_for_level(next_level)}).",
            "progress": f"{xp_now}/{xp_target} XP",
            "pct": round(xp_now / xp_target * 100, 1),
        })

    # Pick top 3 by progress (closest to completion = most addictive)
    quests.sort(key=lambda q: -q["pct"])
    return quests[:3]


# ═══════════════════════════════════════════════════════════════════════════════
# §7 — README WRITER
# ═══════════════════════════════════════════════════════════════════════════════

def render_readme(state: dict, quests: list, stats: dict) -> str:
    """Renders the fiche de personnage as README-devquest.md."""
    level = state["level"]
    title = state["title"]
    xp = state["xp"]
    avatar = render_avatar(state.get("languages", {}))

    # HP = total lines (insertions), MP = test files
    hp = state["total_insertions"]
    mp = state.get("test_count", 0)
    atk = state["total_commits"]
    defense = len(state.get("languages", {}))

    # Achievements unlocked this session
    unlocked = state.get("achievements", [])

    # Recent history (last 5 level-ups)
    history = state.get("history_levels", [])[-5:]

    # Top languages as table
    langs = state.get("languages", {})
    total_lang = sum(langs.values()) or 1
    lang_rows = "\n".join(
        f"| {ext} | {size:,} | {size/total_lang*100:.1f}% |"
        for ext, size in list(langs.items())[:5]
    ) if langs else "| (none) | 0 | 0% |"

    # Quests block
    quest_block = "\n\n".join(
        f"### {q['title']}\n\n> {q['desc']}\n\n**Progression** : `{q['progress']}` ({q['pct']}%)\n\n"
        f"`{'█' * int(q['pct'] // 10)}{'░' * (10 - int(q['pct'] // 10))}`"
        for q in quests
    ) if quests else "_Aucune quête active._"

    # Achievements block
    ach_block = "\n".join(
        f"- {a[1]} — {a[2]}" for a in ACHIEVEMENTS if a[0] in unlocked
    ) if unlocked else "_Aucun achievement débloqué._"

    # History block
    hist_block = "\n".join(
        f"- `{h['at']}` → niveau **{h['level']}** ({h['title']}) · {h['xp']} XP"
        for h in reversed(history)
    ) if history else "_Premier push de DevQuest — ton histoire commence ici._"

    return f"""# ⚛ Nexus DevQuest — Fiche de personnage

> *"Code is the new XP. Push is the new quest."*

![Level Badge](badges/level.svg)
![Title Badge](badges/title.svg)
![XP Bar](badges/xp.svg)

---

## 🧙 Joueur

| Attribut | Valeur |
|----------|--------|
| **Nom** | `{state.get("actor", "unknown")}` |
| **Repo** | `{state.get("repo", "unknown")}` |
| **Niveau** | `{level}` |
| **Titre** | `{title}` |
| **XP total** | `{xp:,}` |
| **Commencé le** | `{state.get("started_at", "")}` |
| **Dernier push** | `{state.get("last_push", "")}` |

---

## 🎭 Avatar

```
{avatar}
```

---

## 📊 Stats de combat

| Stat | Valeur | Signification |
|------|--------|---------------|
| ❤️ HP | `{hp:,}` | Lignes de code ajoutées (insertions cumulées) |
| 💎 MP | `{mp}` | Fichiers de test (`test_*` / `*_test.*`) |
| ⚔️ ATQ | `{atk}` | Commits cumulés |
| 🛡️ DEF | `{defense}` | Langages différents utilisés |
| 🌟 NIV | `{level}` | Niveau actuel |

---

## 🗺️ Langages

| Extension | Volume | % |
|-----------|--------|---|
{lang_rows}

---

## 🎯 Quêtes actives

{quest_block}

---

## 🏆 Achievements

{ach_block}

---

## 📜 Historique des montées de niveau

{hist_block}

---

## ⚛ Manifesto

> *"If you can't ship it in one file, you don't understand it."*

Chaque push te rapproche de la **Légende**. Le workflow `nexus-devquest.yml` calcule ton XP, génère les badges SVG animés et réécrit ce fichier à chaque commit. **100% stdlib, zéro dépendance, 100% local**.

- 🔁 Plus tu push, plus tu montes en niveau
- 🎯 Les quêtes s'adaptent à ton état de repo
- 🏆 Les achievements se débloquent automatiquement
- 📈 Ton README principal peut afficher ton badge niveau en live

---

_Généré automatiquement par **Nexus DevQuest v{VERSION}** · {datetime.datetime.now().isoformat(timespec='seconds')}_
"""


# ═══════════════════════════════════════════════════════════════════════════════
# §8 — MAIN PIPELINE
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    # 1. Get push info from env
    before = os.environ.get("BEFORE", "")
    after  = os.environ.get("AFTER", "")
    actor  = os.environ.get("ACTOR", "unknown")
    repo   = os.environ.get("REPOSITORY", "unknown")

    # 2. Compute commit stats
    stats = get_commit_stats(before, after)
    gained_xp = (
        stats["insertions"] * XP_PER_LINE_ADD +
        stats["deletions"]  * XP_PER_LINE_DEL +
        stats["files_touched"] * XP_PER_FILE +
        stats["commits_count"] * XP_PER_COMMIT
    )

    # 3. Load state
    state = load_state()
    old_level = state.get("level", 1)

    # 4. Update totals
    state["actor"] = actor
    state["repo"]  = repo
    state["total_commits"]       += stats["commits_count"]
    state["total_insertions"]    += stats["insertions"]
    state["total_deletions"]     += stats["deletions"]
    state["total_files_touched"] += stats["files_touched"]
    state["xp"]                  += gained_xp
    state["last_push"]            = datetime.datetime.now(datetime.timezone.utc).isoformat()

    # 5. Refresh repo state
    state["languages"]    = get_repo_languages()
    state["test_count"]   = get_test_count()
    state["readme_size"]  = get_readme_size()
    # Pull total_commits from git if higher (covers manual commits)
    git_commits = get_total_commits()
    if git_commits > state["total_commits"]:
        state["total_commits"] = git_commits

    # 6. Compute level
    level, cur_in_level, to_next, progress = level_from_xp(state["xp"])
    state["level"] = level
    state["title"] = title_for_level(level)

    # 7. Hour / dow for achievements
    hour, dow = get_now_local()
    state["last_hour"] = hour
    state["last_dow"]  = dow

    # 8. Achievements
    newly_unlocked = []
    for ach_id, ach_label, ach_desc, check in ACHIEVEMENTS:
        if ach_id not in state.get("achievements", []) and check(state):
            state.setdefault("achievements", []).append(ach_id)
            newly_unlocked.append((ach_id, ach_label, ach_desc))

    # 9. Level-up history
    if level > old_level:
        event = {
            "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "level": level,
            "title": state["title"],
            "xp": state["xp"],
            "gained_xp": gained_xp,
            "stats": stats,
        }
        state.setdefault("history_levels", []).append(event)
        append_history({"type": "levelup", **event})
    else:
        append_history({
            "type": "push",
            "at":   datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "gained_xp": gained_xp,
            "stats": stats,
            "level": level,
        })

    # 10. Generate badges
    save_badge("level", svg_badge("LVL", str(level), "#1a1a1a", "#00f0ff"))
    save_badge("title", svg_badge("TITLE", state["title"][:10], "#1a1a1a", "#ff00aa"))
    save_badge("xp", svg_xp_bar(level, cur_in_level, to_next, progress))

    # 11. Generate quests
    quests = generate_quests(state)

    # 12. Write README
    README_OUT.write_text(render_readme(state, quests, stats), encoding="utf-8")

    # 13. Save state
    save_state(state)

    # 14. Summary (printed in Actions log)
    print("╔══════════════════════════════════════════════════════════════╗")
    print(f"║  ⚛ NEXUS DEVQUEST — push résolu                                    ║")
    print("╠══════════════════════════════════════════════════════════════╣")
    print(f"║  Acteur      : {actor:<46}║")
    print(f"║  Repo        : {repo:<46}║")
    print(f"║  XP gagnée   : {gained_xp:<46.1f}║")
    print(f"║  Stats       : +{stats['insertions']} / -{stats['deletions']} / {stats['files_touched']} fichiers / {stats['commits_count']} commits")
    print(f"║  Niveau      : {old_level} → {level} ({state['title']})")
    print(f"║  XP total    : {state['xp']:,}")
    print(f"║  Progression : {progress}% vers niveau {level+1}")
    if newly_unlocked:
        print(f"║  Achievement : {len(newly_unlocked)} débloqué(s)")
        for _, label, _ in newly_unlocked:
            print(f"║    · {label}")
    print(f"║  Quêtes      : {len(quests)} active(s)")
    for q in quests:
        print(f"║    · {q['title']} — {q['pct']}% ({q['progress']})")
    print("╚══════════════════════════════════════════════════════════════╝")


if __name__ == "__main__":
    main()
