#!/usr/bin/env python3
"""Validation du workflow « Nexus Sovereign Audit & Auto-Heal ».
1) Parsing YAML + structure      2) Invariants (zéro ${{ }} dans run, heredocs)
3) Exécution réelle des scripts critiques en bac à sable
"""
import json, os, re, shutil, subprocess, sys, tempfile

import yaml

WF = "/home/z/my-project/download/nexus-sovereign-audit.yml"
FAILURES = []


def check(label, cond, detail=""):
    print(("  [OK]    " if cond else "  [ÉCHEC] ") + label + ("" if cond else "  -> " + str(detail)))
    if not cond:
        FAILURES.append(label)


with open(WF, encoding="utf-8") as fh:
    raw = fh.read()
doc = yaml.safe_load(raw)

print("== 1. Parsing YAML ==")
check("YAML valide et parsé", isinstance(doc, dict))
on_block = doc.get("on") or doc.get(True)  # YAML 1.1 : « on » devient True
check("Déclencheurs (push, pull_request, workflow_dispatch)",
      all(k in on_block for k in ("push", "pull_request", "workflow_dispatch")))
check("Permission security-events: write (requis par upload-sarif)",
      doc.get("permissions", {}).get("security-events") == "write")

print("== 2. Jobs et graphe needs ==")
jobs = doc["jobs"]
for j in ["detect-stack", "security-gate", "build-test", "auto-heal", "sovereign-certificate"]:
    check("job « " + j + " » défini", j in jobs)
for name, job in jobs.items():
    needs = job.get("needs", [])
    needs = [needs] if isinstance(needs, str) else needs
    for dep in needs:
        check("needs " + name + " -> " + dep + " : cible existante", dep in jobs)

print("== 3. Invariants anti-bug ==")
for jname, job in jobs.items():
    for step in job.get("steps", []):
        run = step.get("run")
        if not run:
            continue
        sname = step.get("name", "?")
        check(jname + " > " + sname + " : aucun ${{ }} brut dans run (anti-injection)",
              "${{" not in run)
        if re.search(r"<<-?\s*EOF\b", run):
            check(jname + " > " + sname + " : heredoc fermé (EOF en colonne 0)",
                  "EOF" in run.splitlines())
heal = jobs["auto-heal"]
cpr = next(s for s in heal["steps"] if "create-pull-request" in str(s.get("uses", "")))
check("anti-boucle [skip ci] dans le commit auto-heal", "[skip ci]" in cpr["with"]["commit-message"])
heal_if = heal["if"].replace("\n", " ")
check("auto-heal conditionné à l'échec de build-test",
      "needs.build-test.result == 'failure'" in heal_if)

print("== 4. Exécution réelle en bac à sable ==")


def sandbox(script, files=(), env_extra=None, keep=()):
    d = tempfile.mkdtemp(prefix="nexus_")
    for rel in files:
        p = os.path.join(d, rel)
        parent = os.path.dirname(p)
        if parent:
            os.makedirs(parent, exist_ok=True)
        open(p, "w").close()
    out = os.path.join(d, "gh_output")
    env = {"PATH": os.environ["PATH"], "HOME": d,
           "GITHUB_OUTPUT": out, "GITHUB_REPOSITORY": "acme/sovereign"}
    env.update(env_extra or {})
    sp = os.path.join(d, "s.sh")
    open(sp, "w").write(script)
    r = subprocess.run(["bash", sp], cwd=d, env=env, capture_output=True, text=True)
    gout = open(out).read() if os.path.exists(out) else ""
    kept = {}
    for rel in keep:
        p = os.path.join(d, rel)
        kept[rel] = open(p, encoding="utf-8").read() if os.path.exists(p) else None
    shutil.rmtree(d, ignore_errors=True)
    return r, gout, kept


# 4a. Script de détection : 4 scénarios
detect_run = next(s["run"] for s in jobs["detect-stack"]["steps"] if s.get("id") == "detect")
for label, files, want in [
    ("dépôt vide -> generic", [], ["generic"]),
    ("node + python", ["package.json", "requirements.txt"], ["python", "node"]),
    ("rust + cobol", ["Cargo.toml", "PROG.cbl"], ["rust", "cobol"]),
    ("pyproject seul", ["pyproject.toml"], ["python"]),
]:
    r, gout, _ = sandbox(detect_run, files)
    m = re.search(r"languages=(\{.*\})", gout)
    langs = None
    try:
        langs = [e["lang"] for e in json.loads(m.group(1))["include"]] if m else None
    except Exception:
        langs = None
    check("détection : " + label + " -> " + str(want), r.returncode == 0 and langs == want,
          "rc=%s stderr=%s langs=%s" % (r.returncode, r.stderr[-200:], langs))

# 4b. Empreinte SHA-256 : branche principale + fallback renommé
hash_run = next(s["run"] for s in jobs["sovereign-certificate"]["steps"] if s.get("id") == "hash")
r, gout, _ = sandbox(hash_run, [".github/workflows/nexus-sovereign-audit.yml"])
check("empreinte SHA-256 (fichier au nom attendu)",
      re.search(r"workflow_sha=([0-9a-f]{64})", gout) is not None, r.stderr[-200:])
r, gout, _ = sandbox(hash_run, [".github/workflows/autre-ci.yml"])
check("empreinte SHA-256 (fallback fichier renommé)",
      re.search(r"workflow_sha=([0-9a-f]{64})", gout) is not None, r.stderr[-200:])

# 4c. Certificat : le bug des backticks (heredoc) est-il bien mort ?
cert_run = next(s["run"] for s in jobs["sovereign-certificate"]["steps"]
                if "certificat" in s.get("name", "").lower() and s.get("env"))
r, _, kept = sandbox(cert_run, [], {
    "COMMIT_SHA": "abc123def", "WORKFLOW_SHA": "f00dcafe",
    "SECURITY_RESULT": "success", "BUILD_RESULT": "failure",
}, keep=("CERTIFICATE.md",))
cert = kept.get("CERTIFICATE.md") or ""
check("certificat : backticks préservés (l'ancien bug heredoc est mort)",
      "**Commit :** `abc123def`" in cert, repr(cert[:200]))
check("certificat : statuts injectés",
      "**Sécurité :** success" in cert and "**Build :** failure" in cert)
check("certificat : timestamp rendu",
      bool(re.search(r"\*\*Timestamp :\*\* 20\d{2}-\d{2}-\d{2}T", cert)))
check("certificat : aucun backtick vide (symptôme de l'ancien bug)", "``" not in cert)

print()
if FAILURES:
    print("RÉSULTAT : %d échec(s) -> %s" % (len(FAILURES), FAILURES))
    sys.exit(1)
print("RÉSULTAT : 100% des vérifications passent.")
