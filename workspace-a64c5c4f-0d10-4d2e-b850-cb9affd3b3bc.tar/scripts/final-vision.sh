#!/usr/bin/env bash
set -u
export GENT_HOME=/tmp/gent-e2e
cd /tmp
PORT=43112 "$GENT_HOME/runtime/current/bin/node" --max-semi-space-size=64 "$GENT_HOME/app/gent-server.js" > /tmp/e2e.log 2>&1 &
for i in $(seq 1 40); do curl -fsS http://127.0.0.1:43112/api/health >/dev/null 2>&1 && break; sleep 0.3; done
agent-browser open http://127.0.0.1:43112/vision >/dev/null 2>&1
sleep 2.5
echo "tree enfants : $(agent-browser eval 'document.getElementById("tree").children.length')"
echo "éditeur car. : $(agent-browser eval 'document.getElementById("editor").value.length')"
echo "fichier cour.: $(agent-browser eval 'document.getElementById("ed-file").textContent')"
echo "preview src  : $(agent-browser eval 'document.getElementById("preview").src.slice(0,60)')"
echo "— clic BUILD & RUN —"
agent-browser eval 'document.getElementById("btn-build").click()' > /dev/null
sleep 2.5
echo "statut       : $(agent-browser eval 'document.getElementById("status-txt").textContent')"
echo "terminal (6 dernières lignes) :"
agent-browser eval 'document.getElementById("term").innerText.trim().split("\n").slice(-6).join("\n")'
agent-browser screenshot /tmp/render/vision-final.png > /dev/null 2>&1 && echo "capture finale OK"
agent-browser close > /dev/null 2>&1
pkill -f gent-server.js 2>/dev/null
true
