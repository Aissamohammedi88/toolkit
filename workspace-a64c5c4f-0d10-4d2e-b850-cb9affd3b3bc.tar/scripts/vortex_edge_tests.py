#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Banc d'essai VORTEX AI (DGK) — Protocole PROTON : prouver par exécution.
Usage : python3 vortex_edge_tests.py <chemin_module> <label>
"""
import importlib.util
import sys
import warnings

import torch
import torch.nn as nn


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def verdict(ok):
    return "[OK]  " if ok else "[FAIL]"


path, label = sys.argv[1], sys.argv[2]
m = load(path, label)
print(f"===== {label} =====")
print(f"PyTorch : {torch.__version__} | nn.RMSNorm natif : {hasattr(nn, 'RMSNorm')}")

TINY = dict(vocab_size=64, hidden_size=32, num_hidden_layers=2,
            num_attention_heads=4, num_key_value_heads=4,
            intermediate_size=64, max_position_embeddings=128,
            rms_norm_eps=1e-6, eos_token_id=2, pad_token_id=None)

# P1 — forward + loss + train_step + greedy generate
torch.manual_seed(42)
model = m.VortexModel(dict(TINY))
tokens = torch.randint(0, 64, (1, 8))
out = model(input_ids=tokens, labels=tokens)
loss = out["loss"].item()
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    trainer = m.VortexTrainer(model)
    l2 = trainer.train_step({"input_ids": tokens, "labels": tokens})
model.eval()
with torch.no_grad():
    gen = model.generate(tokens, max_new_tokens=4, temperature=0.0)
p1 = loss > 0 and gen.shape[1] > 8
print(f"[P1] forward OK, loss={loss:.3f}, train_step={l2:.3f}, greedy_generate={tuple(gen.shape)} {verdict(p1)}")

# P2 — KV-cache : les positions RoPE sont-elles décalées de la longueur du cache ?
torch.manual_seed(7)
model2 = m.VortexModel(dict(TINY))
model2.eval()
tokens = torch.randint(0, 64, (1, 8))
with torch.no_grad():
    full = model2(input_ids=tokens)["logits"][:, -1, :]
    past = None
    for t in tokens[0].tolist():
        out = model2(input_ids=torch.tensor([[t]]), past_key_values=past, use_cache=True)
        past = out["past_key_values"]
    cached = out["logits"][:, -1, :]
    diff = (full - cached).abs().max().item()
print(f"[P2] KV-cache vs forward complet : écart max logits = {diff:.6f} {verdict(diff < 1e-3)}  (<0.001 = cache sain)")

# P3 — attention standalone sans position_ids (broadcast 3D ?)
try:
    attn = m.VortexAttention(32, 4, 4, max_position_embeddings=128)
    attn.eval()
    with torch.no_grad():
        attn(torch.randn(1, 6, 32))
    print(f"[P3] attention standalone (position_ids=None) : OK {verdict(True)}")
except Exception as e:
    print(f"[P3] attention standalone (position_ids=None) : CRASH {verdict(False)} -> {type(e).__name__}: {str(e)[:90]}")

# P4 — top_p minuscule : le noyau peut-il tout éliminer (0/0 = NaN) ?
try:
    model3 = m.VortexModel(dict(TINY))
    model3.eval()
    with torch.no_grad():
        model3.generate(tokens, max_new_tokens=2, temperature=0.7, top_p=1e-9)
    print(f"[P4] generate(top_p=1e-9) : OK {verdict(True)}")
except Exception as e:
    print(f"[P4] generate(top_p=1e-9) : CRASH {verdict(False)} -> {type(e).__name__}: {str(e)[:90]}")

# P5 — checkpoint préfixé HF/Llama "model.*" : combien de poids chargés ?
model4 = m.VortexModel(dict(TINY))
fake = {f"model.{k}": v.clone() for k, v in model4.state_dict().items()}
if hasattr(m.VortexModel, "_remap_state_dict"):
    sd = m.VortexModel._remap_state_dict(fake)
    _missing, unexpected = model4.load_state_dict(sd, strict=False)
    ok = torch.equal(model4.embed_tokens.weight, fake["model.embed_tokens.weight"])
    print(f"[P5] checkpoint 'model.*' : {len(fake) - len(unexpected)}/{len(fake)} poids chargés {verdict(ok)}")
else:
    _missing, unexpected = model4.load_state_dict(fake, strict=False)
    print(f"[P5] checkpoint 'model.*' : {len(fake) - len(unexpected)}/{len(fake)} poids chargés {verdict(len(unexpected) == 0)}  (0 chargé = échec silencieux)")

# P6 — GQA : moins de têtes K/V que de têtes Q
try:
    gqa = dict(TINY)
    gqa["num_key_value_heads"] = 2
    model5 = m.VortexModel(gqa)
    model5.eval()
    with torch.no_grad():
        model5(input_ids=tokens)
    print(f"[P6] GQA (4 têtes Q / 2 têtes K/V) : forward OK {verdict(True)}")
except Exception as e:
    print(f"[P6] GQA (4 têtes Q / 2 têtes K/V) : CRASH {verdict(False)} -> {type(e).__name__}: {str(e)[:90]}")
print()
