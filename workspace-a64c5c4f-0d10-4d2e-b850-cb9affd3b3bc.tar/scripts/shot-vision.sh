#!/usr/bin/env bash
set -u
export GENT_HOME=/tmp/gent-e2e
cd /tmp
PORT=43112 "$GENT_HOME/runtime/current/bin/node" --max-semi-space-size=64 "$GENT_HOME/app/gent-server.js" > /tmp/e2e.log 2>&1 &
for i in $(seq 1 40); do curl -fsS http://127.0.0.1:43112/api/health >/dev/null 2>&1 && break; sleep 0.3; done
agent-browser open http://127.0.0.1:43112/vision >/dev/null 2>&1
sleep 2.5
echo "— sondes —"
agent-browser eval 'document.getElementById("tree").children.length'
agent-browser eval 'document.getElementById("editor").value.length'
agent-browser eval 'document.getElementById("ed-file").textContent'
agent-browser eval 'document.getElementById("status-txt").textContent'
agent-browser eval 'document.getElementById("pv-select").options.length'
echo "— build via UI (clic) —"
agent-browser find text "⚡ BUILD & RUN" click >/dev/null 2>&1 || agent-browser eval 'document.getElementById("btn-build").click()' >/dev/null
sleep 2
agent-browser eval 'document.getElementById("term").innerText.split("\n").filter(function(l){return l.indexOf("BUILD")>=0 || l.indexOf("SUCC")>=0}).slice(0,4).join(" | ")'
agent-browser eval 'document.getElementById("status-txt").textContent'
agent-browser screenshot /tmp/render/vision-ui2.png >/dev/null 2>&1 && echo "capture 2 OK"
agent-browser close >/dev/null 2>&1
pkill -f gent-server.js 2>/dev/null
true
