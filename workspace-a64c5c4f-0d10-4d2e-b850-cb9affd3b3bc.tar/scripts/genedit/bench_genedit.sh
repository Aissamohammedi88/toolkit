#!/usr/bin/env bash
# ============================================================================
# BANC EXTERNE PROTON — NEXUS GENEDIT v1.0.0
# P0  sources présentes                    P5  bench interne AVEC générateur
# P1  assemblage + bash -n                 P6  smoke GUI réel sous Xvfb
# P2  base64 embarqué == canonique (cmp)   P7  launcher --help (non-interactif)
# P3  py_compile canonique + extrait       P8  launcher --bench END-TO-END réel
# P4  bench interne SANS générateur        P9  idempotence d'assemblage
# P10 raccourci .desktop créé par launcher
# Échoue FORT au premier FAIL. Sortie : BILAN BENCH EXTERNE: PASS=n FAIL=m
# ============================================================================
set -uo pipefail

BASE="/home/z/my-project/scripts/genedit"
OUT="/home/z/my-project/download/nexus-genedit.sh"
GEN="/home/z/my-project/download/nexus-ci-generator.sh"
CANON="$BASE/genedit.py"
export BASE OUT GEN CANON

PASS=0; FAIL=0
t() {  # t <nom> <commande...> : rc 0 = PASS
    local name="$1"; shift
    if "$@" >/tmp/bench_out.txt 2>&1; then
        PASS=$((PASS+1)); printf '  [OK]   %s\n' "$name"
    else
        FAIL=$((FAIL+1)); printf '  [ERR]  %s\n' "$name"
        sed -n '1,6p' /tmp/bench_out.txt | sed 's/^/         /'
    fi
}

echo "════════════ BANC EXTERNE NEXUS GENEDIT ════════════"

# ---- P0 : sources ----------------------------------------------------------
p0() { [ -f "$BASE/genedit_part1.py" ] && [ -f "$BASE/genedit_part2.py" ] \
       && [ -f "$BASE/launcher_head.sh" ] && [ -f "$BASE/launcher_tail.sh" ]; }
t "P0 sources présentes" p0

# ---- P1 : assemblage + bash -n ---------------------------------------------
t "P1 assemblage + bash -n" bash "$BASE/assemble_genedit.sh"

# ---- P2 : base64 embarqué == canonique --------------------------------------
p2() {
    local b64
    b64="$(sed -n "s/^GENEDIT_PY_B64='\(.*\)'\$/\1/p" "$OUT")"
    [ -n "$b64" ] || return 1
    printf '%s' "$b64" | base64 -d > /tmp/extracted_genedit.py
    cmp -s /tmp/extracted_genedit.py "$CANON"
}
t "P2 app embarquée == canonique" p2

# ---- P3 : py_compile des deux copies ----------------------------------------
p3() { python3 -m py_compile "$CANON" \
       && python3 -m py_compile /tmp/extracted_genedit.py; }
t "P3 py_compile canonique + extrait" p3

# ---- P4 : bench interne SANS générateur -------------------------------------
p4() {
    cd /tmp || return 1
    env -u NEXUS_CI_GENERATOR python3 "$CANON" --bench 2>&1 | grep -q "FAIL=0"
}
t "P4 bench interne pur (sans générateur)" p4

# ---- P5 : bench interne AVEC générateur (selftest réel inclus) --------------
p5() {
    cd /tmp || return 1
    local out
    out="$(NEXUS_CI_GENERATOR="$GEN" python3 "$CANON" --bench 2>&1)"
    printf '%s\n' "$out" | grep -q "FAIL=0" \
      && printf '%s\n' "$out" | grep -q "T13"
}
t "P5 bench intégration réelle (T13 selftest)" p5

# ---- P6 : smoke GUI réel sous Xvfb ------------------------------------------
p6() {
    pkill -f "Xvfb :98" >/dev/null 2>&1
    sleep 0.4
    Xvfb :98 -screen 0 1400x900x24 >/dev/null 2>&1 &
    local xpid=$!
    sleep 1.2
    DISPLAY=:98 GENEDIT_SMOKE_MS=3000 timeout 40 \
        python3 "$CANON" --smoke > /tmp/smoke_out.txt 2>&1
    local rc=$?
    kill "$xpid" >/dev/null 2>&1
    [ "$rc" -eq 0 ] && grep -q "GENEDIT SMOKE OK" /tmp/smoke_out.txt
}
t "P6 smoke GUI réel sous Xvfb" p6

# ---- P7 : launcher --help (non-interactif → exit direct) --------------------
p7() { bash "$OUT" --help 2>&1 | grep -q "NEXUS GENEDIT TOUT-EN-UN"; }
t "P7 launcher --help" p7

# ---- P8 : launcher --bench END-TO-END (déploiement réel + banc) ------------
p8() { bash "$OUT" --bench --gen "$GEN" </dev/null 2>&1 \
       | grep -q "BANC TOUT VERT"; }
t "P8 launcher --bench end-to-end" p8

# ---- P9 : idempotence d'assemblage -------------------------------------------
p9() {
    local s1 s2
    s1="$(sha256sum "$OUT" | awk '{print $1}')"
    bash "$BASE/assemble_genedit.sh" >/dev/null 2>&1 || return 1
    s2="$(sha256sum "$OUT" | awk '{print $1}')"
    [ "$s1" = "$s2" ]
}
t "P9 idempotence d'assemblage" p9

# ---- P10 : raccourci .desktop créé -------------------------------------------
p10() { [ -f "$HOME/.local/share/applications/nexus-genedit.desktop" ] \
        && grep -q "Name=NEXUS GenEdit" \
              "$HOME/.local/share/applications/nexus-genedit.desktop"; }
t "P10 raccourci menu .desktop" p10

# ---- bilan -------------------------------------------------------------------
pkill -f "Xvfb :98" >/dev/null 2>&1 || true
echo "─────────────────────────────────────────────────────"
echo "  BILAN BENCH EXTERNE: PASS=$PASS FAIL=$FAIL"
echo "  livrable : $OUT"
echo "  sha256   : $(sha256sum "$OUT" | awk '{print $1}')"
[ "$FAIL" -eq 0 ] || exit 1
exit 0
