# ============================================================================
# (fin de main_genedit ci-dessus) — déclenchement + anti-fermeture
# ----------------------------------------------------------------------------
# Garde anti-fermeture n°2 : le travail tourne dans un SOUS-SHELL ( ... ),
# et en shell INTERACTIF on ne fait JAMAIS exit avant la pause finale.
# Ton terminal survit, même lancé par double-clic depuis Mint.
# ----------------------------------------------------------------------------
rc=0
( main_genedit "$@" ) || rc=$?
case "$-" in
    *i*) if [ -n "${NEXUS_GENEDIT_NOPAUSE:-}" ]; then
             :
         else
             printf '%s[INFO]%s rc=%s — ' "$C_INFO" "$C_OFF" "$rc"
             printf 'appuie sur ENTREE pour fermer cette fenetre...\n'
             read -r _ || true
         fi
         exit "$rc" ;;
    *)   exit "$rc" ;;
esac
