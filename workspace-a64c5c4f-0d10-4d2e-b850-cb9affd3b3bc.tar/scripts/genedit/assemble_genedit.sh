#!/usr/bin/env bash
# ============================================================================
# ASSEMBLE NEXUS GENEDIT — pipeline d'assemblage + auto-vérification
#   part1 + part2            -> genedit.py (canonique, unique fichier app)
#   head + genedit.py(b64)   -> download/nexus-genedit.sh (livrable)
# Vérifie à chaque exécution : py_compile, bash -n, extraction base64
# identique au canonique. Échoue FORT si quoi que ce soit cloche.
# ============================================================================
set -euo pipefail

BASE="/home/z/my-project/scripts/genedit"
OUT="/home/z/my-project/download/nexus-genedit.sh"
GENEDIT="$BASE/genedit.py"
PART1="$BASE/genedit_part1.py"
PART2="$BASE/genedit_part2.py"
HEAD="$BASE/launcher_head.sh"
TAIL="$BASE/launcher_tail.sh"

# ---- 0. préconditions ------------------------------------------------------
for f in "$PART1" "$PART2" "$HEAD" "$TAIL"; do
    [ -f "$f" ] || { echo "[ASSEMBLE][ERR] source manquant : $f"; exit 1; }
done

# ---- 1. canonique : concaténation des deux parties -------------------------
cat "$PART1" "$PART2" > "$GENEDIT"
# la partie 2 doit commencer par son propre en-tête de section
head -n 1 "$PART2" | grep -q "====" || {
    echo "[ASSEMBLE][ERR] part2 ne commence pas par son en-tête"; exit 1; }
python3 -m py_compile "$GENEDIT"
NLINES="$(wc -l < "$GENEDIT")"
echo "[ASSEMBLE] genedit.py : $NLINES lignes — py_compile OK"

# ---- 2. sécurité heredoc : le marqueur base64 ne doit JAMAIS apparaître ----
if grep -q 'GENEDIT_PY_B64' "$GENEDIT"; then
    echo "[ASSEMBLE][ERR] le code Python contient le marqueur base64 !"
    exit 1
fi

# ---- 3. assemblage du livrable ---------------------------------------------
cat "$HEAD" > "$OUT"
printf "GENEDIT_PY_B64='%s'\n" "$(base64 -w0 "$GENEDIT")" >> "$OUT"
cat "$TAIL" >> "$OUT"
chmod +x "$OUT"

# ---- 4. auto-vérifications --------------------------------------------------
bash -n "$OUT"
B64="$(sed -n "s/^GENEDIT_PY_B64='\(.*\)'\$/\1/p" "$OUT")"
if [ -z "$B64" ]; then
    echo "[ASSEMBLE][ERR] ligne base64 introuvable dans le livrable"
    exit 1
fi
TMP="$(mktemp)"
printf '%s' "$B64" | base64 -d > "$TMP"
if ! cmp -s "$TMP" "$GENEDIT"; then
    echo "[ASSEMBLE][ERR] app embarquée != canonique — assemblage corrompu"
    rm -f "$TMP"
    exit 1
fi
rm -f "$TMP"
# le python extrait compile aussi (double preuve)
EXT="$(mktemp -d)"
printf '%s' "$B64" | base64 -d > "$EXT/genedit_extracted.py"
python3 -m py_compile "$EXT/genedit_extracted.py"
rm -rf "$EXT"

# ---- 5. rapport -------------------------------------------------------------
OUTLINES="$(wc -l < "$OUT")"
OUTBYTES="$(wc -c < "$OUT")"
SHA="$(sha256sum "$OUT" | awk '{print $1}')"
echo "[ASSEMBLE] livrable   : $OUT"
echo "[ASSEMBLE] lignes     : $OUTLINES"
echo "[ASSEMBLE] octets     : $OUTBYTES"
echo "[ASSEMBLE] sha256     : $SHA"
echo "[ASSEMBLE] TOUT VERT — app embarquée == canonique, bash -n OK"
