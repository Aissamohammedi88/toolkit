#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ============================================================================
#  NEXUS GENEDIT v1.0.0 — Éditeur génératif NATIF Linux (Tkinter / X11)
# ----------------------------------------------------------------------------
#  ZÉRO NAVIGATEUR. ZÉRO ELECTRON. ZÉRO HTML. 100% natif X11.
#  Intègre nexus-ci-generator.sh (DGK) :
#     - selftest / doctor / list / manual / changelog / explain
#     - génération des 13 workflows CI  (--force, --dry-run, versions)
#  Architecture : logique PURE (testable sans écran) + GUI Tkinter isolée
#  derrière HAS_TK — le banc interne ne touche JAMAIS l'interface.
#
#  Auteur : Aissa Mohammedi (DGK) — NEXUS-OPEN-3.0 / PROTON
#  PROTON ① : CLI du générateur repris VERBATIM de `--help` officiel v2.0.0.
# ============================================================================
"""NEXUS GenEdit — éditeur de code natif + panneau génératif NEXUS CI."""

import os
import re
import sys
import shlex
import bisect
import queue
import threading
import subprocess
from pathlib import Path

APP_NAME = "NEXUS GenEdit"
VERSION = "1.0.0"

# ---------------------------------------------------------------------------
# CONSTANTES MÉTIER — reprises VERBATIM du générateur (PROTON ①)
# ---------------------------------------------------------------------------
# Les 13 types, dans l'ordre officiel affiché par `nexus-ci-generator.sh list`
ALL_TYPES = (
    "aegis", "java", "python", "node", "docker", "go", "rust",
    "release", "nightly", "php", "dotnet", "cpp", "android",
)

# Sous-commandes officielles (nexus-ci-generator.sh --help)
GEN_SUBCOMMANDS = (
    "list", "explain", "validate", "doctor", "uninstall",
    "selftest", "manual", "changelog",
)

# Valeurs par défaut du générateur (--help officiel)
DEFAULT_OPTIONS = {
    "branch":   "main",
    "node":     "22",
    "java":     "21",
    "python":   "3.12",
    "go":       "1.23",
    "php":      "8.3",
    "dotnet":   "9.0",
    "registry": "ghcr.io",
    "cron":     "0 3 * * *",
}

# Ordre DÉTERMINISTE des flags transmis au générateur (le banc l'exige).
GEN_OPTION_ORDER = (
    "branch", "node", "java", "python", "go",
    "php", "dotnet", "registry", "cron",
)

# Anti-injection : chaque option doit matcher son motif, sinon elle est
# REJETÉE et déclarée (jamais passée en silence au générateur). PROTON ③.
OPTION_PATTERNS = {
    "branch":   r"[A-Za-z0-9._/-]+",
    "node":     r"[0-9][A-Za-z0-9._-]*",
    "java":     r"[0-9][A-Za-z0-9._-]*",
    "python":   r"[0-9][A-Za-z0-9._-]*",
    "go":       r"[0-9][A-Za-z0-9._-]*",
    "php":      r"[0-9][A-Za-z0-9._-]*",
    "dotnet":   r"[0-9][A-Za-z0-9._-]*",
    "registry": r"[A-Za-z0-9._/-]+",
    "cron":     r"[0-9*,\- ]+",
}

# Dossiers ignorés par l'arborescence (bruit inutile, pas de perte de données)
SKIP_DIRS = {
    "node_modules", "__pycache__", ".venv", "venv", "dist", "build",
    "target", ".next", ".cache", ".git", ".idea", ".vscode",
}

# ---------------------------------------------------------------------------
# THÈME SOMBRE PROFESSIONNEL (Catppuccin Mocha adapté) — données pures
# ---------------------------------------------------------------------------
THEME = {
    "bg":       "#1e1e2e",   # fond éditeur
    "bg2":      "#181825",   # fond panneaux
    "bg3":      "#313244",   # fond champs / barres
    "fg":       "#cdd6f4",   # texte principal
    "muted":    "#6c7086",   # texte discret
    "accent":   "#89b4fa",   # accent bleu
    "kw":       "#cba6f7",   # mots-clés (violet)
    "key":      "#89b4fa",   # clés YAML / noms (bleu)
    "str":      "#a6e3a1",   # chaînes (vert)
    "com":      "#6c7086",   # commentaires (gris)
    "num":      "#fab387",   # nombres (orange)
    "bool":     "#94e2d5",   # booléens (turquoise)
    "anchor":   "#f5c2e7",   # ancres / flags / décorateurs (rose)
    "decor":    "#f5c2e7",
    "heading":  "#89b4fa",   # titres markdown
    "ok":       "#a6e3a1",
    "err":      "#f38ba8",
    "warn":     "#f9e2af",
    "sel":      "#45475a",
    "border":   "#45475a",
}

FONT_EDITOR = ("DejaVu Sans Mono", 11)
FONT_UI = ("DejaVu Sans", 10)
FONT_TREE = ("DejaVu Sans", 10)
FONT_STATUS = ("DejaVu Sans", 9)

# ---------------------------------------------------------------------------
# LOGIQUE PURE — localisation du générateur (PROTON : ordre déclarée)
# ---------------------------------------------------------------------------
def find_generator(explicit=None):
    """Cherche nexus-ci-generator.sh.

    Ordre de recherche (déclaré, pas caché) :
      1. chemin explicite (option --gen)
      2. variable d'environnement NEXUS_CI_GENERATOR
      3. $HOME/Bureau, $HOME/Desktop, /home/nexus/Bureau, $HOME, cwd
    Retourne un chemin str lisible, ou None.
    On exige seulement R_OK : le script est TOUJOURS invoqué via `bash <f>`,
    le bit d'exécution n'est donc pas nécessaire (PROTON : pas de magie).
    """
    cands = []
    if explicit and str(explicit).strip():
        cands.append(Path(str(explicit).strip()).expanduser())
    env = os.environ.get("NEXUS_CI_GENERATOR", "").strip()
    if env:
        cands.append(Path(env).expanduser())
    home = Path.home()
    for base in (home / "Bureau", home / "Desktop",
                 Path("/home/nexus/Bureau"), home, Path.cwd()):
        cands.append(base / "nexus-ci-generator.sh")
    for c in cands:
        try:
            if c.is_file() and os.access(str(c), os.R_OK):
                return str(c)
        except OSError:
            continue
    return None


# ---------------------------------------------------------------------------
# LOGIQUE PURE — détection du langage (pour la coloration)
# ---------------------------------------------------------------------------
LANG_BY_EXT = {
    ".yml": "yaml", ".yaml": "yaml",
    ".sh": "bash", ".bash": "bash", ".conf": "bash", ".service": "bash",
    ".py": "python",
    ".md": "markdown", ".rst": "markdown",
    ".json": "json",
    ".txt": "text",
}


def detect_lang(path):
    """Déduit le langage de coloration depuis le nom de fichier."""
    p = Path(path)
    name = p.name.lower()
    if name in ("dockerfile", "makefile"):
        return "bash"
    if name.startswith(".env") or name in (".gitignore", ".bashrc", ".profile"):
        return "bash"
    ext = p.suffix.lower()
    if ext in ("", ".example", ".sample", ".template"):
        if name.startswith("."):
            return "bash"
        return "text"
    return LANG_BY_EXT.get(ext, "text")


# ---------------------------------------------------------------------------
# LOGIQUE PURE — règles de coloration syntaxique
# ---------------------------------------------------------------------------
# Dictionnaire langage -> [(tag, motif regex)] — motifs compilés MULTILINE.
#
# RÈGLE @auto (chaîne vs commentaire — bug réel trouvé au banc T7) :
# une règle « #commentaire » passant AVANT « "chaîne" » colore le # DANS
# une chaîne comme commentaire. Une seule règle alternée @auto règle le
# problème DÉFINITIVEMENT : le scan positionnel fait gagner celui qui
# commence le PREMIER dans la ligne — guillemet → chaîne, # → commentaire.
# Les règles suivantes ne recouvrent jamais une zone déjà prise (bisect).
HIGHLIGHT_RULES = {
    "yaml": [
        ("@auto",   r'"[^"\n]*"|' + "'" + r"[^'\n]*" + "'" + r'|#[^\n]*'),
        ("key",     r"^[ \t]*[\w.\-]+(?=[ \t]*:)"),
        ("kw",      r"\b(?:needs|runs-on|uses|with|env|jobs|steps|strategy|matrix|if|name|on|outputs|secrets|inputs|permissions|timeout-minutes|continue-on-error|concurrency|schedule|workflow_call|working-directory|shell|run)\b"),
        ("number",  r"\b\d+(?:\.\d+)?\b"),
        ("bool",    r"\b(?:true|false|null|yes|no|on|off)\b"),
        ("anchor",  r"&\w+|\*\w+|\$\{\{[^}\n]*\}\}"),
    ],
    "bash": [
        ("@auto",   r'"[^"\n]*"|' + "'" + r"[^'\n]*" + "'" + r'|#[^\n]*'),
        ("kw",      r"\b(?:if|then|else|elif|fi|for|in|do|done|while|until|case|esac|function|return|local|export|set|unset|source|alias|trap|shift|read|cd|echo|printf|exit|command|eval|exec|getopts)\b"),
        ("anchor",  r"(?<![A-Za-z0-9])--?[A-Za-z][A-Za-z0-9_-]*"),
        ("str",     r"\$\{[^}\n]*\}|\$[A-Za-z_][A-Za-z0-9_]*|\$[#?$!@*]"),
        ("number",  r"\b\d+\b"),
        ("decor",   r"\$\(\(|\)\)"),
    ],
    "python": [
        ("@auto",   r'"""[\s\S]*?"""|' + "'''" + r"[\s\S]*?" + "'''"
                    + r'|"[^"\n]*"|' + "'" + r"[^'\n]*" + "'"
                    + r'|#[^\n]*'),
        ("decor",   r"@[A-Za-z_][\w.]*"),
        ("kw",      r"\b(?:def|class|import|from|as|return|if|elif|else|for|while|try|except|finally|with|in|is|not|and|or|None|True|False|lambda|yield|raise|pass|break|continue|global|nonlocal|assert|async|await|del)\b"),
        ("number",  r"\b\d+(?:\.\d+)?\b"),
        ("bool",    r"\b(?:None|True|False)\b"),
    ],
    "markdown": [
        ("comment", r"^```[^\n]*$|^~~~[^\n]*$"),
        ("heading", r"^\#{1,6}[^\n]*"),
        ("anchor",  r"\*\*[^*\n]+\*\*|`[^`\n]+`"),
        ("str",     r"\[[^\]\n]*\]\([^)\n]*\)"),
        ("kw",      r"^\s*[-*+]\s|^\s*>\s|^\s*\d+\.\s"),
    ],
    "json": [
        ("key",     r'"[^"\n]*"(?=\s*:)'),
        ("string",  r'"[^"\n]*"'),
        ("number",  r"-?\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b"),
        ("bool",    r"\b(?:true|false|null)\b"),
    ],
    "text": [],
}

# Tags effectifs à configurer dans le widget (couleurs du THÈME)
HIGHLIGHT_TAG_COLORS = {
    "comment": "com", "string": "str", "str2": "str", "key": "key",
    "kw": "kw", "number": "num", "bool": "bool", "anchor": "anchor",
    "decor": "decor", "heading": "heading",
}

_RULES_CACHE = {}


def compile_rules(lang):
    """Compile (une seule fois) les règles d'un langage. Pur + mémoïsé."""
    if lang not in _RULES_CACHE:
        rules = []
        for tag, pattern in HIGHLIGHT_RULES.get(lang, []):
            rules.append((tag, re.compile(pattern, re.MULTILINE)))
        _RULES_CACHE[lang] = rules
    return _RULES_CACHE[lang]


def compute_highlights(content, lang):
    """Calcule les zones à colorer : [(tag, debut, fin)] en offsets chars.

    PUR et testable au banc sans écran. Les zones déjà prises par une règle
    de priorité supérieure (@auto : chaînes/commentaires) ne sont JAMAIS
    recouvertes par les règles suivantes — d'où l'index d'intervalles triés
    (bisect). Le tag « @auto » est résolu par le PREMIER caractère de la
    zone : '#' -> commentaire, guillemet -> chaîne.
    """
    out = []
    taken_starts = []   # débuts triés des intervalles pris
    taken_ends = []     # fins correspondantes (prises[n])
    for tag, rx in compile_rules(lang):
        for m in rx.finditer(content):
            s, e = m.start(), m.end()
            if tag == "@auto":
                if e == s:
                    continue
                tag = "comment" if content[s] == "#" else "string"
            # borne : dernier intervalle commençant <= s
            n = bisect.bisect_right(taken_starts, s) - 1
            overlapped = False
            j = n
            while j >= 0:
                if s < taken_ends[j] and e > taken_starts[j]:
                    overlapped = True
                    break
                if j == 0 or taken_starts[j - 1] < s and taken_ends[j - 1] <= s:
                    break
                j -= 1
            if overlapped:
                continue
            k = bisect.bisect_left(taken_starts, s)
            taken_starts.insert(k, s)
            taken_ends.insert(k, e)
            out.append((tag, s, e))
    return out


# ---------------------------------------------------------------------------
# LOGIQUE PURE — options et ligne de commande du générateur
# ---------------------------------------------------------------------------
def sanitize_options(options):
    """Filtre les options du générateur.

    Retourne (propres, rejetées) :
      - propres   : dict clé->valeur valides (motifs OPTION_PATTERNS)
      - rejetées  : liste (clé, valeur) refusées — déclarées, jamais cachées
    Une valeur vide ou blanche est simplement ignorée (défaut du générateur).
    """
    clean, rejected = {}, []
    for key, raw in (options or {}).items():
        val = str(raw).strip()
        if not val:
            continue
        pat = OPTION_PATTERNS.get(key)
        if pat is None:
            rejected.append((key, val))
            continue
        if re.fullmatch(pat, val) is None:
            rejected.append((key, val))
            continue
        clean[key] = val
    return clean, rejected


def build_gen_command(generator, mode, target_dir=".",
                      options=None, force=False, dry_run=False):
    """Construit la ligne de commande EXACTE pour nexus-ci-generator.sh.

    Toujours une LISTE (jamais une chaîne shell) : zéro injection possible.
      mode = selftest|doctor|list|manual|changelog  -> sous-commande nue
      mode = explain (options['type'])              -> explain <type>
      mode = <un des 13 types>                      -> génération
    Lève ValueError si le mode est inconnu (échoue fort, PROTON ④).
    """
    gen = str(generator)
    if mode in ("selftest", "doctor", "list", "manual", "changelog"):
        return ["bash", gen, mode]
    if mode == "explain":
        t = str((options or {}).get("type", ""))
        if t not in ALL_TYPES:
            raise ValueError("explain: type invalide: %r" % t)
        return ["bash", gen, "explain", t]
    if mode in ALL_TYPES:
        clean, _ = sanitize_options(options)
        cmd = ["bash", gen, mode, "--dir", str(target_dir or ".")]
        for key in GEN_OPTION_ORDER:
            if key in clean:
                cmd += ["--" + key, clean[key]]
        if force:
            cmd.append("--force")
        if dry_run:
            cmd.append("--dry-run")
        return cmd
    raise ValueError("mode inconnu: %r" % (mode,))


def format_command(argv):
    """Représentation lisible (et sûre) d'une commande pour la console."""
    return "  $ " + " ".join(shlex.quote(a) for a in argv)


# ---------------------------------------------------------------------------
# BANC INTERNE — tourne SANS écran, SANS tkinter, SANS générateur obligatoire
# ---------------------------------------------------------------------------
def run_bench():
    """Banc interne PROTON ②. Sortie : BILAN BENCH: PASS=n FAIL=m."""
    import tempfile

    results = []  # [(nom, ok, détail)]

    def t(name, fn):
        try:
            fn()
            results.append((name, True, ""))
        except Exception as e:                                # noqa: BLE001
            results.append((name, False, "%s: %s" % (type(e).__name__, e)))

    def eq(a, b):
        if a != b:
            raise AssertionError("%r != %r" % (a, b))

    # ---- T1 : find_generator honore le chemin explicite
    def t1():
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "nexus-ci-generator.sh"
            f.write_text("#!/bin/bash\n", encoding="utf-8")
            eq(find_generator(str(f)), str(f))
    t("T1 find_generator(explicite)", t1)

    # ---- T2 : find_generator honore $NEXUS_CI_GENERATOR
    def t2():
        old = os.environ.get("NEXUS_CI_GENERATOR")
        try:
            with tempfile.TemporaryDirectory() as d:
                f = Path(d) / "nexus-ci-generator.sh"
                f.write_text("#!/bin/bash\n", encoding="utf-8")
                os.environ["NEXUS_CI_GENERATOR"] = str(f)
                eq(find_generator(), str(f))
        finally:
            if old is None:
                os.environ.pop("NEXUS_CI_GENERATOR", None)
            else:
                os.environ["NEXUS_CI_GENERATOR"] = old
    t("T2 find_generator($NEXUS_CI_GENERATOR)", t2)

    # ---- T3 : find_generator retourne None si introuvable
    def t3():
        old = os.environ.get("NEXUS_CI_GENERATOR")
        oldcwd = os.getcwd()
        os.environ.pop("NEXUS_CI_GENERATOR", None)
        try:
            with tempfile.TemporaryDirectory() as d:
                os.chdir(d)
                eq(find_generator(), None)
        finally:
            os.chdir(oldcwd)
            if old is not None:
                os.environ["NEXUS_CI_GENERATOR"] = old
    t("T3 find_generator(None si absent)", t3)

    # ---- T4 : détection de langage
    def t4():
        eq(detect_lang(".github/workflows/nexus-node.yml"), "yaml")
        eq(detect_lang("pipeline.yaml"), "yaml")
        eq(detect_lang("script.sh"), "bash")
        eq(detect_lang("Dockerfile"), "bash")
        eq(detect_lang(".env.example"), "bash")
        eq(detect_lang("main.py"), "python")
        eq(detect_lang("README.md"), "markdown")
        eq(detect_lang("package.json"), "json")
        eq(detect_lang("notes.txt"), "text")
        eq(detect_lang("image.png"), "text")
    t("T4 detect_lang", t4)

    # ---- T5 : toutes les regex de coloration compilent
    def t5():
        for lang in HIGHLIGHT_RULES:
            compile_rules(lang)          # lève si motif invalide
    t("T5 regex coloration valides", t5)

    # ---- T6 : compute_highlights — commentaire non recouvert
    def t6():
        content = "on:\n  push:\njobs:\n  build:\n    runs-on: ubuntu-latest # cpu\n"
        zones = compute_highlights(content, "yaml")
        tags = [z[0] for z in zones]
        if "comment" not in tags:
            raise AssertionError("commentaire non détecté")
        cs = content.index("# cpu")
        for tag, s, e in zones:
            if tag != "comment" and s <= cs < e:
                raise AssertionError("commentaire recouvert par %s" % tag)
    t("T6 coloration YAML priorités", t6)

    # ---- T7 : compute_highlights — bash, chaîne non recouverte
    def t7():
        content = 'echo "# pas un commentaire"\nNAME="x"\n'
        zones = compute_highlights(content, "bash")
        pos = content.index("# pas un commentaire")
        for tag, s, e in zones:
            if tag != "string" and s <= pos < e:
                raise AssertionError("chaîne recouverte par %s" % tag)
    t("T7 coloration bash priorités", t7)

    # ---- T8 : sanitize_options — rejet des valeurs piégées
    def t8():
        clean, rejected = sanitize_options({
            "node": "20", "php": "  ", "go": "1.23; rm -rf /",
            "cron": "0 3 * * *", "evil": "x",
        })
        eq(clean, {"node": "20", "cron": "0 3 * * *"})
        eq(sorted(k for k, _ in rejected), ["evil", "go"])
    t("T8 sanitize_options", t8)

    # ---- T9 : build_gen_command — sous-commande nue
    def t9():
        eq(build_gen_command("/g.sh", "selftest"), ["bash", "/g.sh", "selftest"])
        eq(build_gen_command("/g.sh", "doctor"), ["bash", "/g.sh", "doctor"])
        eq(build_gen_command("/g.sh", "list"), ["bash", "/g.sh", "list"])
        eq(build_gen_command("/g.sh", "manual"), ["bash", "/g.sh", "manual"])
    t("T9 cmd sous-commandes", t9)

    # ---- T10 : build_gen_command — génération, ordre déterministe
    def t10():
        cmd = build_gen_command(
            "/g.sh", "node", "/repo",
            {"branch": "main", "node": "20", "cron": "0 1 * * *",
             "php": "", "java": "21"},
            force=True, dry_run=False,
        )
        eq(cmd, ["bash", "/g.sh", "node", "--dir", "/repo",
                 "--branch", "main", "--node", "20", "--java", "21",
                 "--cron", "0 1 * * *", "--force"])
    t("T10 cmd génération ordre exact", t10)

    # ---- T11 : build_gen_command — dry-run + mode inconnu échoue fort
    def t11():
        cmd = build_gen_command("/g.sh", "aegis", ".", {}, False, True)
        eq(cmd[-1], "--dry-run")
        try:
            build_gen_command("/g.sh", "nexus")
            raise AssertionError("mode inconnu accepté")
        except ValueError:
            pass
        try:
            build_gen_command("/g.sh", "explain", options={"type": "zzz"})
            raise AssertionError("explain type invalide accepté")
        except ValueError:
            pass
    t("T11 dry-run + échec fort", t11)

    # ---- T12 : cohérence des constantes métier
    def t12():
        eq(len(ALL_TYPES), 13)
        eq(len(GEN_OPTION_ORDER), len(OPTION_PATTERNS))
        for k in DEFAULT_OPTIONS:
            if k not in OPTION_PATTERNS:
                raise AssertionError("défaut sans motif: %s" % k)
        for sub in ("selftest", "doctor", "list", "manual", "changelog"):
            if sub in ALL_TYPES:
                raise AssertionError("collision type/sous-commande: %s" % sub)
    t("T12 constantes cohérentes", t12)

    # ---- T13/T14 : INTÉGRATION RÉELLE (si générateur présent)
    gen = find_generator()
    if gen is None:
        print("[SKIP] T13 intégration générateur : générateur absent")
        print("[SKIP] T14 intégration générateur : générateur absent")
    else:
        def t13():
            r = subprocess.run(
                ["bash", gen, "selftest"],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, timeout=900,
            )
            if r.returncode != 0:
                raise AssertionError("selftest rc=%d" % r.returncode)
        t("T13 SELFTEST RÉEL du générateur", t13)

        def t14():
            with tempfile.TemporaryDirectory() as d:
                # check_env du générateur EXIGE un dépôt git (rc=3 sinon) —
                # en usage réel la cible est toujours un dépôt (le tout-en-un
                # fait « git init » à l'étape 4/6). On reproduit l'usage réel.
                gi = subprocess.run(
                    ["git", "init", "-q", d],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, timeout=30)
                if gi.returncode != 0:
                    raise AssertionError("git init échoué : %s" % gi.stdout)
                # DEFECT CONNU du générateur v2.0.0 (déclaré, non contourné
                # en silence) : en --dry-run, check_env NE crée PAS
                # .github/workflows (mkdir sous `if OPT_DRYRUN -eq 0`, l.730)
                # mais nexus_tmp_new (l.881) fait mktemp DANS ce dossier.
                # Sur un dépôt neuf, le dry-run échoue donc rc=1 — bug du
                # générateur, PAS de l'app. Ici : dépôt réel = dossier déjà
                # présent (usage quotidien). Documenté aussi dans le Mémo.
                os.makedirs(
                    os.path.join(d, ".github", "workflows"),
                    exist_ok=True)
                cmd = build_gen_command(
                    gen, "node", d,
                    {"node": "22", "branch": "main"}, force=True, dry_run=True,
                )
                r = subprocess.run(
                    cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, timeout=120,
                )
                if r.returncode != 0:
                    raise AssertionError("dry-run rc=%d" % r.returncode)
                if len(r.stdout) < 200:
                    raise AssertionError("dry-run: sortie trop courte")
                if "nexus-node.yml" not in r.stdout and "name:" not in r.stdout:
                    raise AssertionError("dry-run: YAML introuvable en sortie")
        t("T14 dry-run réel nexus-node.yml", t14)

    # ---- rapport
    print()
    print("-" * 60)
    npass = sum(1 for _, ok, _ in results if ok)
    nfail = len(results) - npass
    for name, ok, detail in results:
        if ok:
            print("  [OK]   %s" % name)
        else:
            print("  [ERR]  %s — %s" % (name, detail))
    print("-" * 60)
    print("  BILAN BENCH: PASS=%d FAIL=%d" % (npass, nfail))
    return 1 if nfail else 0


# ---------------------------------------------------------------------------
# IMPORT DE L'INTERFACE — ISOLÉ : absent = banc quand même utilisable
# ---------------------------------------------------------------------------
HAS_TK = True
try:
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
except Exception:                                                # noqa: BLE001
    HAS_TK = False
