#!/usr/bin/env bash
# ============================================================================
#  NEXUS GENEDIT TOUT-EN-UN v1.0.0 — éditeur GÉNÉRATIF natif Linux Mint
#  Zéro navigateur. Zéro Electron. Zéro HTML. Fenêtre X11 pure.
# ----------------------------------------------------------------------------
#  CE QUE CETTE UNIQUE COMMANDE FAIT :
#    1. localise nexus-ci-generator.sh (Bureau, Desktop, /home/nexus, find)
#    2. vérifie python3 (>= 3.8) et tkinter — INSTALLE python3-tk si absent
#    3. déploie l'application genedit.py (embarquée en BASE64 ci-dessous :
#       aucun heredoc → ce fichier reste sûr même collé ligne par ligne)
#    4. crée le raccourci « NEXUS GenEdit » dans le menu des applications
#    5. lance la fenêtre native ; à la fermeture, ta fenêtre ne se ferme
#       JAMAIS seule : pause anti-fermeture en mode interactif.
#
#  USAGE :
#    bash nexus-genedit.sh                       # fenêtre, tout auto
#    bash nexus-genedit.sh --gen /chemin/nexus-ci-generator.sh
#    bash nexus-genedit.sh --project /mon/depot  # dossier ouvert au départ
#    bash nexus-genedit.sh --bench               # banc interne, sans fenêtre
#    bash nexus-genedit.sh --smoke               # construction + sortie (banc)
#
#  Aucun chmod nécessaire. PROTON : banc externe vert avant livraison.
#  Auteur : Aissa Mohammedi (DGK) — NEXUS-OPEN-3.0
# ============================================================================
# Garde anti-fermeture n°1 (prouvée au banc, voir nexus-tout-en-un.sh) :
# SOURCÉ → re-exécution en enfant, le terminal parent vit.
if [ -n "${BASH_SOURCE[0]}" ] && [ "${BASH_SOURCE[0]}" != "$0" ] && [ -f "${BASH_SOURCE[0]}" ]; then
    bash "${BASH_SOURCE[0]}" "$@"
    return 0 2>/dev/null || exit 0
fi

GENEDIT_TOUT_VERSION="1.0.0"

if [ -t 1 ]; then
    C_OK=$'\033[92m'; C_INFO=$'\033[96m'; C_WARN=$'\033[93m'; C_ERR=$'\033[91m'; C_OFF=$'\033[0m'; C_GRAS=$'\033[1m'
else
    C_OK=''; C_INFO=''; C_WARN=''; C_ERR=''; C_OFF=''; C_GRAS=''
fi

log_ok()   { printf '%s[OK]%s %s\n'   "$C_OK"   "$C_OFF" "$*"; }
log_info() { printf '%s[INFO]%s %s\n' "$C_INFO" "$C_OFF" "$*"; }
log_warn() { printf '%s[WARN]%s %s\n' "$C_WARN" "$C_OFF" "$*"; }
log_err()  { printf '%s[ERR]%s %s\n'  "$C_ERR"  "$C_OFF" "$*"; }
etape()    { printf '\n%s%s── %s ──────────────────────────────%s\n' "$C_GRAS" "$C_INFO" "$*" "$C_OFF"; }
titre()    { printf '%s\n' "${C_GRAS}${C_INFO}============================================================${C_OFF}"
             printf '%s\n' "${C_GRAS}  $*${C_OFF}"; }

usage_genedit() {
    titre "NEXUS GENEDIT TOUT-EN-UN v${GENEDIT_TOUT_VERSION}"
    printf 'Usage: bash nexus-genedit.sh [options]\n\n'
    printf 'Options :\n'
    printf '  --gen <chemin>       chemin de nexus-ci-generator.sh\n'
    printf '  --project <dossier>  dossier projet ouvert au lancement\n'
    printf '  --bench              banc interne (sans fenêtre)\n'
    printf '  --smoke              construit la fenêtre puis sort (banc)\n'
    printf '  --help, -h           cette aide\n\n'
    printf 'Générateur cherché automatiquement dans :\n'
    printf '  $HOME/Bureau, $HOME/Desktop, /home/nexus/Bureau, $HOME, PWD\n'
    printf 'Sinon l app démarre en mode ÉDITEUR SEUL (rien de cassé).\n'
}

# ----------------------------------------------------------------------------
# LE TRAVAIL — dans un SOUS-SHELL ( ... ) : chaque « exit » ne tue que lui.
# ----------------------------------------------------------------------------
main_genedit() {
    set -uo pipefail

    OPT_GEN=""; OPT_PROJECT=""; OPT_BENCH=0; OPT_SMOKE=0
    while [ $# -gt 0 ]; do
        case "$1" in
            --gen)     if [ $# -ge 2 ]; then OPT_GEN="$2"; shift 2
                       else log_err "--gen exige un chemin"; exit 1; fi ;;
            --project) if [ $# -ge 2 ]; then OPT_PROJECT="$2"; shift 2
                       else log_err "--project exige un dossier"; exit 1; fi ;;
            --bench)   OPT_BENCH=1; shift ;;
            --smoke)   OPT_SMOKE=1; shift ;;
            --help|-h) usage_genedit; exit 0 ;;
            *)         log_err "option inconnue: $1 (voir --help)"; exit 1 ;;
        esac
    done

    titre "NEXUS GENEDIT TOUT-EN-UN v${GENEDIT_TOUT_VERSION} — éditeur génératif NATIF"

    # ---------------- 1/5 : localiser le générateur ----------------
    etape "1/5 — Localisation du générateur nexus-ci-generator.sh"
    GEN=""
    if [ -n "$OPT_GEN" ]; then
        if [ -f "$OPT_GEN" ]; then
            GEN="$OPT_GEN"
        else
            log_err "générateur introuvable : $OPT_GEN"
            exit 2
        fi
    else
        for c in "$HOME/Bureau/nexus-ci-generator.sh" \
                 "$HOME/Desktop/nexus-ci-generator.sh" \
                 "/home/nexus/Bureau/nexus-ci-generator.sh" \
                 "$HOME/nexus-ci-generator.sh" \
                 "$PWD/nexus-ci-generator.sh"; do
            if [ -f "$c" ]; then GEN="$c"; break; fi
        done
        if [ -z "$GEN" ]; then
            GEN="$(find "$HOME" -maxdepth 3 -name nexus-ci-generator.sh 2>/dev/null | head -n 1 || true)"
        fi
    fi
    if [ -n "$GEN" ]; then
        log_ok "générateur : $GEN"
        if grep -q '__NODE_MATRIX__' "$GEN" 2>/dev/null; then
            log_ok "version corrigée confirmée (matrices dédupliquées)"
        else
            log_warn "ANCIENNE VERSION détectée : re-télécharge nexus-ci-generator.sh"
            log_warn "(sha256 attendu doit commencer par 78e23787)"
        fi
    else
        log_warn "générateur introuvable — l'app démarre en mode ÉDITEUR SEUL"
        log_warn "(situe-le ensuite : menu Génération > Re-situer le générateur…)"
    fi

    # ---------------- 2/5 : python3 ----------------
    etape "2/5 — Vérification de Python"
    if command -v python3 >/dev/null 2>&1; then
        PYV="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null || echo '?')"
        log_ok "python3 $PYV"
        if ! python3 -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 8) else 1)'; then
            log_err "Python >= 3.8 requis (trouvé : $PYV)"; exit 1
        fi
    else
        log_err "python3 absent — installe-le : sudo apt install python3"
        exit 1
    fi

    # ---------------- 3/5 : tkinter (GUI native X11) ----------------
    etape "3/5 — Vérification de Tkinter (interface native, zéro navigateur)"
    if python3 -c 'import tkinter' >/dev/null 2>&1; then
        log_ok "tkinter présent"
    else
        log_warn "python3-tk manquant — installation…"
        if command -v apt-get >/dev/null 2>&1; then
            if command -v sudo >/dev/null 2>&1; then
                log_info "mot de passe sudo demandé (paquet système python3-tk)"
                sudo apt-get install -y python3-tk || true
            else
                apt-get install -y python3-tk || true
            fi
        else
            log_err "apt-get absent — installation manuelle requise"
        fi
        if python3 -c 'import tkinter' >/dev/null 2>&1; then
            log_ok "tkinter installé avec succès"
        else
            log_err "tkinter TOUJOURS absent — commande manuelle :"
            log_err "    sudo apt install python3-tk"
            exit 1
        fi
    fi

    # ---------------- 4/5 : déploiement de l'application ----------------
    etape "4/5 — Déploiement de l'application genedit.py"
    if [ -d "$HOME/Bureau" ]; then
        APP_DIR="$HOME/Bureau/nexus-genedit"
    else
        APP_DIR="$HOME/nexus-genedit"
    fi
    if ! mkdir -p "$APP_DIR"; then
        log_err "impossible de créer : $APP_DIR"
        exit 1
    fi
    PY_FILE="$APP_DIR/genedit.py"
    if ! printf '%s' "$GENEDIT_PY_B64" | base64 -d > "$PY_FILE" 2>/dev/null; then
        log_err "décodage base64 échoué — fichier livré corrompu ?"
        exit 1
    fi
    if ! python3 -m py_compile "$PY_FILE"; then
        log_err "genedit.py déployé CORROMPU — déploiement annulé (PROTON : rien de cassé)"
        rm -f "$PY_FILE"
        exit 1
    fi
    log_ok "application déployée : $PY_FILE ($(wc -l < "$PY_FILE") lignes)"
    log_ok "sha256 : $(sha256sum "$PY_FILE" | awk '{print $1}')"

    # ---------------- 5/5 : raccourci + lancement ----------------
    etape "5/5 — Raccourci menu + lancement"
    DESK="$HOME/.local/share/applications/nexus-genedit.desktop"
    if mkdir -p "$HOME/.local/share/applications" 2>/dev/null; then
        if { printf '%s\n' \
              "[Desktop Entry]" \
              "Type=Application" \
              "Name=NEXUS GenEdit" \
              "Comment=Editeur generatif natif (DGK / NEXUS-OPEN-3.0)" \
              "Exec=python3 ${PY_FILE}" \
              "Terminal=false" \
              "Categories=Development;Utility;" \
              "StartupNotify=true"; } > "$DESK" 2>/dev/null; then
            log_ok "raccourci menu : NEXUS GenEdit (catégorie Développement)"
        else
            log_warn "raccourci menu non écrit — NON FATAL, l'app reste lancable"
        fi
    else
        log_info "pas de dossier applications — raccourci ignoré (déclaré)"
    fi

    if [ -n "$GEN" ]; then
        export NEXUS_CI_GENERATOR="$GEN"
    fi

    if [ "$OPT_BENCH" -eq 1 ]; then
        log_info "mode BANC : aucun affichage, tests internes seulement"
        python3 "$PY_FILE" --bench
        rc=$?
        if [ "$rc" -eq 0 ]; then log_ok "BANC TOUT VERT — livraison autorisée"
        else log_err "banc en échec (rc=$rc)"; fi
        exit "$rc"
    fi

    if [ "$OPT_SMOKE" -eq 1 ]; then
        python3 "$PY_FILE" --smoke
        rc=$?
        if [ "$rc" -eq 0 ]; then log_ok "SMOKE OK — la fenêtre native se construit"
        else log_err "smoke échoué (rc=$rc)"; fi
        exit "$rc"
    fi

    EXTRA=()
    if [ -n "$GEN" ]; then EXTRA+=(--gen "$GEN"); fi
    if [ -n "$OPT_PROJECT" ]; then EXTRA+=(--project "$OPT_PROJECT"); fi

    log_info "lancement de la fenêtre native — referme-la pour revenir ici"
    if python3 "$PY_FILE" ${EXTRA+"${EXTRA[@]}"}; then
        log_ok "session GenEdit terminée proprement"
        rc=0
    else
        rc=$?
        log_warn "GenEdit sorti avec code $rc (détail au-dessus)"
    fi
    exit "$rc"
}
