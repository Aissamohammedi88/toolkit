#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Sonde synchronisée : lance genedit --smoke sous Xvfb :99, capture IN-APP
(dump géométries + PNG au MÊME instant). ÉCHOUE FORT si l'app crashe,
si SMOKE OK absent ou si un TclError paraît — jamais de PNG périmé
(leçon N17 : le banc vérifie ses propres instruments)."""
import os
import sys
import subprocess

PY = "/home/z/my-project/scripts/genedit/genedit.py"
PNG = "/home/z/my-project/download/nexus-genedit-apercu.png"
DUMP = "/tmp/widgets.txt"

env = dict(os.environ)
env["DISPLAY"] = ":99"
env["GENEDIT_SMOKE_MS"] = "5000"
env["GENEDIT_SMOKE_DUMP"] = "1"
env["GENEDIT_SMOKE_SHOT"] = PNG

try:
    p = subprocess.run(
        [sys.executable, PY, "--smoke"],
        env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, timeout=30)
except subprocess.TimeoutExpired:
    print("[SONDE][ERR] timeout — l'app ne s'est pas fermée")
    sys.exit(1)

out = p.stdout
open(DUMP, "w").write(out)

fail = []
if p.returncode != 0:
    fail.append("rc=%d" % p.returncode)
if "GENEDIT SMOKE OK" not in out:
    fail.append("SMOKE OK absent")
if "Traceback" in out or "TclError" in out:
    fail.append("exception Tk dans la construction")
if "SHOT-IN-APP OK" not in out:
    fail.append("capture in-app absente")
if not os.path.isfile(PNG) or os.path.getsize(PNG) < 10000:
    fail.append("PNG invalide")

if fail:
    print("[SONDE][ERR] " + "; ".join(fail))
    print(out[-1500:])
    sys.exit(1)
print("[SONDE] OK — SMOKE + capture + dump synchrones")
