#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ============================================================================
# CAPTURE D'ÉCRAN RÉELLE de NEXUS GenEdit sous Xvfb (preuve visuelle)
# 1. lance Xvfb :99          2. lance genedit --smoke (fenêtre réelle)
# 3. capture via Pillow ImageGrab (xdisplay)   4. PNG → download/
# ============================================================================
import os
import sys
import time
import subprocess

OUT = "/home/z/my-project/download/nexus-genedit-apercu.png"
APP = "/home/z/my-project/scripts/genedit/genedit.py"
DISPLAY = ":99"

# 1. Xvfb (re-)démarré proprement
subprocess.run(["pkill", "-f", "Xvfb :99"], stdout=subprocess.DEVNULL,
               stderr=subprocess.DEVNULL)
time.sleep(0.4)
xvfb = subprocess.Popen(
    ["Xvfb", DISPLAY, "-screen", "0", "1400x900x24"],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.5)

# 2. l'app réelle, fenêtre ouverte 5 s (smoke à délai long)
env = dict(os.environ)
env["DISPLAY"] = DISPLAY
env["GENEDIT_SMOKE_MS"] = "5000"
app = subprocess.Popen(
    [sys.executable, APP, "--smoke"],
    env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

# 3. laisser la fenêtre se construire + coloration s'appliquer
time.sleep(2.6)
try:
    from PIL import ImageGrab
    img = ImageGrab.grab(xdisplay=DISPLAY)
    img.save(OUT)
    print("[SHOT] capture : %s (%dx%d)" % (OUT, img.width, img.height))
except Exception as e:                                     # noqa: BLE001
    print("[SHOT][ERR] %s" % e)
    app.kill()
    xvfb.terminate()
    sys.exit(1)

# 4. attendre la fermeture propre (SMOKE OK attendu)
try:
    out, _ = app.communicate(timeout=12)
    print("[SHOT] app :", out.strip())
except subprocess.TimeoutExpired:
    app.kill()
    print("[SHOT][WARN] app pas fermée à temps")
xvfb.terminate()
rc = 0 if os.path.isfile(OUT) else 1
print("[SHOT] rc=%d" % rc)
sys.exit(rc)
