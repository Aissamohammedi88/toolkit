# ============================================================================
#  NEXUS GENEDIT v1.0.0 — PARTIE 2 : INTERFACE GRAPHIQUE NATIVE (Tkinter)
#  (assemblée après la partie 1 — logique pure. Ne pas éditer le fichier
#   assemblé : éditer genedit_part1.py / genedit_part2.py puis ré-assembler.)
# ============================================================================
if HAS_TK:

    class DarkTabs(tk.Frame):
        """Barre d'onglets 100% sombre — remplace ttk.Notebook.

        Le strip ttk.Notebook clam rend CLAIR quoi qu'on configure (élément
        C : lookup sombre, pixels #dcdad5 — prouvé au banc visuel, 953x11
        px). Cette barre n'utilise QUE des widgets classiques : chaque
        couleur est TOUJOURS honorée. API compatible : add(title),
        select(index)."""

        def __init__(self, master):
            super().__init__(master, bg=THEME["bg2"],
                             highlightthickness=0)
            self._bar = tk.Frame(self, bg=THEME["bg2"],
                                 highlightthickness=0)
            self._bar.pack(side="top", fill="x")
            self._body = tk.Frame(self, bg=THEME["bg2"],
                                  highlightthickness=0)
            self._body.pack(side="top", fill="both", expand=True)
            self._tabs = []          # [(bouton, cadre)]
            self._current = None

        def add(self, title):
            frame = tk.Frame(self._body, bg=THEME["bg2"],
                             highlightthickness=0)
            idx = len(self._tabs)
            btn = tk.Button(
                self._bar, text=title, bd=0, padx=14, pady=6,
                font=FONT_UI, bg=THEME["bg2"], fg=THEME["muted"],
                activebackground=THEME["bg3"],
                activeforeground=THEME["fg"],
                highlightthickness=0,
                command=lambda: self.select(idx))
            btn.pack(side="left", padx=(0, 2), pady=(3, 0))
            self._tabs.append((btn, frame))
            return frame

        def select(self, idx):
            for i, (btn, frame) in enumerate(self._tabs):
                if i == idx:
                    btn.config(bg=THEME["accent"], fg=THEME["bg2"])
                    frame.pack(fill="both", expand=True)
                else:
                    btn.config(bg=THEME["bg2"], fg=THEME["muted"])
                    frame.pack_forget()
            self._current = idx

        def index(self):
            return self._current

    class GenEditApp(tk.Tk):
        """Fenêtre principale : éditeur + arborescence + panneau génératif."""

        MAX_HIGHLIGHT_CHARS = 400000   # au-delà : coloration désactivée (déclaré)

        # -----------------------------------------------------------------
        def __init__(self, generator_path=None, project_dir=None, smoke=False):
            super().__init__()
            self.title("%s v%s" % (APP_NAME, VERSION))
            self.geometry("1280x820")
            self.minsize(1024, 640)
            self.configure(bg=THEME["bg2"])

            # état applicatif
            self.generator_path = find_generator(generator_path)
            self.current_file = None
            self.current_lang = "text"
            self.dirty = False
            self.busy = False
            self.loading = False
            self.highlighting = False
            self._highlight_job = None
            self._poll_job = None
            self.queue = queue.Queue()
            self._tree_paths = {}
            self._linenum_count = -1
            self._smoke = smoke
            self._gen_buttons = []
            self._on_done = None
            self.nb_bottom = None

            if project_dir:
                self.project_dir = os.path.expanduser(project_dir)
            else:
                bureau = os.path.join(os.path.expanduser("~"), "Bureau")
                if os.path.isdir(bureau):
                    self.project_dir = bureau
                else:
                    self.project_dir = os.getcwd()

            self._build_style()
            self._build_menu()
            self._build_genbar()
            self._build_panes()
            self._build_statusbar()
            self._bind_keys()

            self.refresh_tree()
            self._update_gen_status()
            self.protocol("WM_DELETE_WINDOW", self.on_close)
            self.after(80, self._poll_queue)

        # -----------------------------------------------------------------
        # STYLE SOMBRE PROFESSIONNEL
        # -----------------------------------------------------------------
        def _build_style(self):
            st = ttk.Style(self)
            try:
                st.theme_use("clam")
            except tk.TclError:
                pass
            bg2, bg3 = THEME["bg2"], THEME["bg3"]
            fg, muted, acc = THEME["fg"], THEME["muted"], THEME["accent"]
            st.configure("TNotebook", background=bg2, borderwidth=0)
            st.configure("TNotebook.Tab", background=bg3, foreground=fg,
                         padding=(14, 5), borderwidth=0)
            st.map("TNotebook.Tab",
                   background=[("selected", acc)],
                   foreground=[("selected", THEME["bg2"])])
            st.configure("Treeview", background=bg2, foreground=fg,
                         fieldbackground=bg2, rowheight=24,
                         borderwidth=0, indent=12)
            st.map("Treeview", background=[("selected", THEME["sel"])])
            st.configure("Vertical.TScrollbar", background=bg3,
                         troughcolor=bg2, bordercolor=bg2, arrowcolor=fg)
            st.configure("Horizontal.TScrollbar", background=bg3,
                         troughcolor=bg2, bordercolor=bg2, arrowcolor=fg)
            st.configure("TCombobox", fieldbackground=bg3, background=bg3,
                         foreground=fg, arrowcolor=fg, bordercolor=bg3)
            st.map("TCombobox",
                   fieldbackground=[("readonly", bg3)],
                   foreground=[("readonly", fg)])
            # NB : ttk.Entry/Combobox n'acceptent PAS l'option -font directe
            # (TclError) — la police passe par le STYLE ou la base d'options.
            st.configure("TEntry", fieldbackground=bg3, foreground=fg,
                         insertcolor=fg, bordercolor=bg3, lightcolor=bg3,
                         darkcolor=bg3, font=FONT_UI)
            st.configure("TCombobox", selectbackground=THEME["sel"],
                         insertcolor=fg, font=FONT_UI)
            self.option_add("*TCombobox*Font", FONT_UI)
            self.option_add("*TCombobox*Listbox.background", bg3)
            self.option_add("*TCombobox*Listbox.foreground", fg)
            self.option_add("*TCombobox*Listbox.selectBackground",
                            THEME["sel"])
            st.configure("TCheckbutton", background=bg2, foreground=fg,
                         font=FONT_UI)
            st.map("TCheckbutton", background=[("active", bg2)])
            # SASH des PanedWindow : clam la peint CLAIRE par défaut (#dcdad5,
            # mesuré au banc visuel — 16 559 px) → on la peint sombre.
            st.configure("Sash", background=bg3, lightcolor=bg3,
                         darkcolor=bg3, bordercolor=THEME["border"])
            st.configure("TPanedwindow", background=bg2)
            st.configure("Panedwindow", background=bg2)

        # -----------------------------------------------------------------
        # BARRE DE MENUS
        # -----------------------------------------------------------------
        def _build_menu(self):
            menubar = tk.Menu(self, bg=THEME["bg2"], fg=THEME["fg"],
                              activebackground=THEME["bg3"],
                              activeforeground=THEME["fg"],
                              bd=0, tearoff=False)

            m_file = tk.Menu(menubar, tearoff=False, bg=THEME["bg2"],
                             fg=THEME["fg"], activebackground=THEME["bg3"])
            m_file.add_command(label="Nouveau", accelerator="Ctrl+N",
                               command=self.new_file)
            m_file.add_command(label="Ouvrir…", accelerator="Ctrl+O",
                               command=self.open_dialog)
            m_file.add_command(label="Enregistrer", accelerator="Ctrl+S",
                               command=self.save_file)
            m_file.add_command(label="Enregistrer sous…",
                               command=self.save_as)
            m_file.add_separator()
            m_file.add_command(label="Changer de dossier projet…",
                               command=self.change_project)
            m_file.add_separator()
            m_file.add_command(label="Quitter", accelerator="Ctrl+Q",
                               command=self.on_close)
            menubar.add_cascade(label="Fichier", menu=m_file)

            m_gen = tk.Menu(menubar, tearoff=False, bg=THEME["bg2"],
                            fg=THEME["fg"], activebackground=THEME["bg3"])
            m_gen.add_command(label="Selftest du générateur",
                              command=self.on_selftest)
            m_gen.add_command(label="Doctor (environnement)",
                             command=self.on_doctor)
            m_gen.add_command(label="Lister les 13 types",
                              command=self.on_list)
            m_gen.add_command(label="Explain du type choisi",
                              command=self.on_explain)
            m_gen.add_command(label="Manuel du générateur",
                              command=self.on_manual)
            m_gen.add_command(label="Changelog",
                              command=self.on_changelog)
            m_gen.add_separator()
            m_gen.add_command(label="Générer le type choisi",
                              command=self.on_generate)
            m_gen.add_command(label="Générer les 13 workflows",
                              command=self.on_generate_all)
            m_gen.add_separator()
            m_gen.add_command(label="Re-situer le générateur…",
                              command=self.relocate_generator)
            menubar.add_cascade(label="Génération", menu=m_gen)

            m_help = tk.Menu(menubar, tearoff=False, bg=THEME["bg2"],
                             fg=THEME["fg"], activebackground=THEME["bg3"])
            m_help.add_command(label="Mémo intégré",
                               command=self.show_memo)
            m_help.add_command(label="À propos",
                               command=self.show_about)
            menubar.add_cascade(label="Aide", menu=m_help)

            self.config(menu=menubar)

        # -----------------------------------------------------------------
        # BARRE GÉNÉRATION (le cœur « génératif » de l'app)
        # -----------------------------------------------------------------
        def _build_genbar(self):
            bar = tk.Frame(self, bg=THEME["bg2"], padx=10, pady=7)
            bar.pack(fill="x", side="top")

            def lbl(parent, text):
                return tk.Label(parent, text=text, bg=THEME["bg2"],
                                 fg=THEME["muted"], font=FONT_UI)

            def entry(parent, width, var):
                # PAS d'option font (TclError en ttk) — style TEntry gère
                return ttk.Entry(parent, width=width, textvariable=var)

            # -- rangée 1 : type + cible + options principales
            r1 = tk.Frame(bar, bg=THEME["bg2"])
            r1.pack(fill="x")
            lbl(r1, "TYPE CI :").pack(side="left")
            self.v_type = tk.StringVar(value=ALL_TYPES[0])
            self.cb_type = ttk.Combobox(
                r1, textvariable=self.v_type, values=list(ALL_TYPES),
                state="readonly", width=9)
            self.cb_type.pack(side="left", padx=(4, 14))

            lbl(r1, "CIBLE :").pack(side="left")
            self.v_dir = tk.StringVar(value=self.project_dir)
            e_dir = entry(r1, 38, self.v_dir)
            e_dir.pack(side="left", padx=(4, 4))
            b_browse = tk.Button(
                r1, text="Parcourir", font=FONT_UI, bd=0, padx=10, pady=3,
                bg=THEME["bg3"], fg=THEME["fg"],
                activebackground=THEME["accent"], activeforeground=THEME["bg2"],
                highlightthickness=0, command=self.browse_target)
            b_browse.pack(side="left", padx=(0, 14))
            self._gen_buttons.append(b_browse)

            for key, label in (("branch", "Branche"), ("node", "Node"),
                               ("python", "Python"), ("php", "PHP")):
                lbl(r1, label).pack(side="left")
                var = tk.StringVar(value=DEFAULT_OPTIONS[key])
                setattr(self, "v_" + key, var)
                entry(r1, 6 if key != "branch" else 8, var).pack(
                    side="left", padx=(4, 12))

            # -- rangée 2 : autres options + flags + boutons
            r2 = tk.Frame(bar, bg=THEME["bg2"])
            r2.pack(fill="x", pady=(6, 0))
            for key, label in (("java", "Java"), ("go", "Go"),
                               ("dotnet", ".NET"), ("cron", "Cron"),
                               ("registry", "Registre")):
                lbl(r2, label).pack(side="left")
                var = tk.StringVar(value=DEFAULT_OPTIONS[key])
                setattr(self, "v_" + key, var)
                w = 11 if key == "cron" else (9 if key == "registry" else 5)
                entry(r2, w, var).pack(side="left", padx=(4, 12))

            self.v_force = tk.BooleanVar(value=True)
            self.v_dry = tk.BooleanVar(value=False)
            ttk.Checkbutton(r2, text="Force (écrase)", variable=self.v_force
                           ).pack(side="left", padx=(0, 10))
            ttk.Checkbutton(r2, text="Dry-run (sans écrire)",
                            variable=self.v_dry).pack(side="left",
                                                      padx=(0, 16))

            def mkbtn(parent, text, cmd, primary=False):
                if primary:
                    b = tk.Button(
                        parent, text=text, font=FONT_UI, bd=0, padx=14,
                        pady=4, bg=THEME["accent"], fg=THEME["bg2"],
                        activebackground=THEME["ok"], highlightthickness=0,
                        command=cmd)
                else:
                    b = tk.Button(
                        parent, text=text, font=FONT_UI, bd=0, padx=10,
                        pady=4, bg=THEME["bg3"], fg=THEME["fg"],
                        activebackground=THEME["accent"],
                        activeforeground=THEME["bg2"], highlightthickness=0,
                        command=cmd)
                b.pack(side="left", padx=(0, 8))
                self._gen_buttons.append(b)
                return b

            mkbtn(r2, "Selftest", self.on_selftest)
            mkbtn(r2, "Doctor", self.on_doctor)
            mkbtn(r2, "Lister", self.on_list)
            mkbtn(r2, "\u25B6 G\u00C9N\u00C9RER", self.on_generate,
                  primary=True)
            mkbtn(r2, "LES 13", self.on_generate_all)

            sep = tk.Frame(self, bg=THEME["border"], height=1)
            sep.pack(fill="x", side="top")

        # -----------------------------------------------------------------
        # PANEAUX : arborescence | (éditeur / console+mémo)
        # -----------------------------------------------------------------
        def _build_panes(self):
            bg2 = THEME["bg2"]
            # tk.PanedWindow CLASSIQUES : la sash est peinte avec le fond du
            # widget (sombre, maîtrisé). La sash clam/ttk reste CLAIRE quoi
            # qu'on configure (élément C — prouvé au banc A/B : ttk ignore
            # background/troughcolor/lightcolor, classic rend #181825).
            pw = tk.PanedWindow(
                self, orient="horizontal", bg=bg2, bd=0,
                sashrelief="flat", sashwidth=4, sashpad=0, opaqueresize=True)
            pw.pack(fill="both", expand=True)

            # ---- panneau gauche : projet + arborescence
            left = tk.Frame(pw, bg=bg2, width=250)
            left.pack_propagate(False)   # largeur fixe demandée au PanedWindow
            head = tk.Frame(left, bg=THEME["bg2"])
            head.pack(fill="x", padx=8, pady=(8, 4))
            tk.Label(head, text="PROJET", bg=THEME["bg2"],
                     fg=THEME["muted"], font=FONT_UI).pack(side="left")

            btnrow = tk.Frame(left, bg=THEME["bg2"])
            btnrow.pack(fill="x", padx=8, pady=(0, 4))
            for text, cmd in (
                    ("Dossier", self.change_project),
                    ("Rafraîchir (F5)", self.refresh_tree)):
                tk.Button(btnrow, text=text, font=FONT_UI, bd=0,
                          padx=8, pady=2, bg=THEME["bg3"], fg=THEME["fg"],
                          activebackground=THEME["accent"],
                          activeforeground=THEME["bg2"],
                          highlightthickness=0,
                          command=cmd).pack(side="left", padx=(0, 6))

            self.tree = ttk.Treeview(left, show="tree",
                                     selectmode="browse")
            self.tree.pack(fill="both", expand=True, padx=4, pady=(0, 8))
            bold = (FONT_TREE[0], FONT_TREE[1], "bold")
            self.tree.tag_configure("dir", font=bold, foreground=THEME["fg"])
            self.tree.tag_configure("file", font=FONT_TREE,
                                    foreground=THEME["fg"])
            self.tree.bind("<Double-1>", self._on_tree_double)
            pw.add(left, minsize=220, stretch="never")

            # ---- zone droite : éditeur au-dessus, console en-dessous
            right = tk.PanedWindow(
                pw, orient="vertical", bg=bg2, bd=0,
                sashrelief="flat", sashwidth=4, sashpad=0, opaqueresize=True)
            pw.add(right, minsize=300, stretch="always")

            edframe = tk.Frame(right, bg=THEME["bg"])
            self.linenum = tk.Text(
                edframe, width=6, font=FONT_EDITOR, bd=0, padx=6, pady=6,
                bg=THEME["bg2"], fg=THEME["muted"], state="disabled",
                takefocus=False, wrap="none", cursor="arrow",
                highlightthickness=0)
            self.linenum.grid(row=0, column=0, rowspan=2, sticky="nsw")

            self.editor = tk.Text(
                edframe, font=FONT_EDITOR, bd=0, padx=10, pady=6,
                bg=THEME["bg"], fg=THEME["fg"], insertbackground=THEME["fg"],
                wrap="none", undo=True, selectbackground=THEME["sel"],
                selectforeground=THEME["fg"], highlightthickness=0,
                spacing1=2, spacing2=2, spacing3=2)
            self.editor.grid(row=0, column=1, sticky="nsew")

            self.ysb = tk.Scrollbar(
                edframe, orient="vertical", command=self.editor.yview,
                bg=THEME["bg3"], troughcolor=THEME["bg2"], bd=0,
                activebackground=THEME["accent"], relief="flat",
                highlightthickness=0)
            self.ysb.grid(row=0, column=2, sticky="ns")
            self.xsb = tk.Scrollbar(
                edframe, orient="horizontal", command=self.editor.xview,
                bg=THEME["bg3"], troughcolor=THEME["bg2"], bd=0,
                activebackground=THEME["accent"], relief="flat",
                highlightthickness=0)
            self.xsb.grid(row=1, column=1, sticky="ew")
            edframe.grid_columnconfigure(1, weight=1)
            edframe.grid_rowconfigure(0, weight=1)
            self.editor.config(yscrollcommand=self._on_editor_scroll,
                               xscrollcommand=self.xsb.set)
            # mêmes interlignes côté numéros → alignement parfait
            self.linenum.config(spacing1=2, spacing2=2, spacing3=2)

            for tag, key in HIGHLIGHT_TAG_COLORS.items():
                self.editor.tag_configure(tag, foreground=THEME[key])
            self.editor.bind("<<Modified>>", self._on_modified)
            self.editor.bind("<KeyRelease>", self._on_edit_move)
            self.editor.bind("<ButtonRelease-1>", self._on_edit_move)
            right.add(edframe, minsize=200, stretch="always")

            # ---- console + mémo : barre d'onglets CUSTOM (clam/ttk rend
            # le strip CLAIR — voir DarkTabs) — couleurs 100% maîtrisées.
            bottom = DarkTabs(right)
            self.nb_bottom = bottom
            right.add(bottom, minsize=150, stretch="never")

            conf = bottom.add("  Console Génération  ")
            self.console = tk.Text(
                conf, font=("DejaVu Sans Mono", 10), bd=0, padx=10, pady=8,
                bg=THEME["bg2"], fg=THEME["fg"], state="disabled",
                wrap="word", height=8, highlightthickness=0)
            self.console.pack(fill="both", expand=True)
            for tag, key in (("ok", "ok"), ("err", "err"),
                             ("warn", "warn"), ("cmd", "accent"),
                             ("dim", "muted")):
                self.console.tag_configure(tag, foreground=THEME[key])

            memof = bottom.add("  Mémo / Aide  ")
            memo = tk.Text(
                memof, font=("DejaVu Sans", 10), bd=0, padx=14, pady=10,
                bg=THEME["bg2"], fg=THEME["fg"], wrap="word", height=8,
                state="disabled", highlightthickness=0)
            memo.pack(fill="both", expand=True)
            memo.config(state="normal")
            memo.insert("1.0", self._memo_text())
            memo.config(state="disabled")
            bottom.select(0)

        # -----------------------------------------------------------------
        # BARRE D'ÉTAT
        # -----------------------------------------------------------------
        def _build_statusbar(self):
            bar = tk.Frame(self, bg=THEME["bg3"], padx=10)
            bar.pack(fill="x", side="bottom")
            self.st_file = tk.Label(bar, text="Aucun fichier", bg=THEME["bg3"],
                                    fg=THEME["fg"], font=FONT_STATUS,
                                    anchor="w")
            self.st_file.pack(side="left")
            self.st_lang = tk.Label(bar, text="—", bg=THEME["bg3"],
                                    fg=THEME["muted"], font=FONT_STATUS)
            self.st_lang.pack(side="left", padx=(16, 0))
            self.st_pos = tk.Label(bar, text="Ln 1, Col 1", bg=THEME["bg3"],
                                   fg=THEME["muted"], font=FONT_STATUS)
            self.st_pos.pack(side="left", padx=(16, 0))
            self.st_gen = tk.Label(bar, text="Générateur : …", bg=THEME["bg3"],
                                   fg=THEME["muted"], font=FONT_STATUS,
                                   anchor="e")
            self.st_gen.pack(side="right")

        # -----------------------------------------------------------------
        # RACCOURCIS CLAVIER
        # -----------------------------------------------------------------
        def _bind_keys(self):
            self.bind("<Control-n>", lambda e: self.new_file())
            self.bind("<Control-o>", lambda e: self.open_dialog())
            self.bind("<Control-s>", lambda e: self.save_file())
            self.bind("<Control-q>", lambda e: self.on_close())
            self.bind("<F5>", lambda e: self.refresh_tree())

        # -----------------------------------------------------------------
        # ÉDITEUR : numéros de ligne + coloration + statut
        # -----------------------------------------------------------------
        def _on_editor_scroll(self, first, last):
            # 1) alimente la BARRE (thumb) 2) aligne les numéros de ligne
            try:
                self.ysb.set(first, last)
            except tk.TclError:
                pass
            try:
                self.linenum.yview_moveto(float(first))
            except (tk.TclError, ValueError):
                pass
            self._update_line_numbers()

        def _update_line_numbers(self):
            try:
                nlines = int(self.editor.index("end-1c").split(".")[0])
            except tk.TclError:
                return
            if nlines < 1:
                nlines = 1
            if nlines != self._linenum_count:
                self._linenum_count = nlines
                self.linenum.config(state="normal")
                self.linenum.delete("1.0", "end")
                self.linenum.insert(
                    "1.0", "\n".join(str(i) for i in range(1, nlines + 1)))
                self.linenum.config(
                    state="disabled",
                    width=max(4, len(str(nlines)) + 2))
            try:
                first = self.editor.yview()[0]
                self.linenum.yview_moveto(first)
            except (tk.TclError, ValueError):
                pass

        def _on_modified(self, _event):
            if self.loading or self.highlighting:
                try:
                    self.editor.edit_modified(False)
                except tk.TclError:
                    pass
                return
            try:
                if not self.editor.edit_modified():
                    return
                self.editor.edit_modified(False)
            except tk.TclError:
                pass
            self.dirty = True
            self._set_title()
            self._schedule_highlight()
            self._update_line_numbers()

        def _schedule_highlight(self):
            if self._highlight_job is not None:
                try:
                    self.after_cancel(self._highlight_job)
                except tk.TclError:
                    pass
            self._highlight_job = self.after(220, self._apply_highlight)

        def _apply_highlight(self):
            self._highlight_job = None
            self.highlighting = True
            try:
                for tag in HIGHLIGHT_TAG_COLORS:
                    self.editor.tag_remove(tag, "1.0", "end")
                content = self.editor.get("1.0", "end-1c")
                if len(content) <= self.MAX_HIGHLIGHT_CHARS:
                    zones = compute_highlights(content, self.current_lang)
                    base = "1.0"
                    for tag, s, e in zones:
                        self.editor.tag_add(
                            tag, "%s+%dc" % (base, s), "%s+%dc" % (base, e))
            finally:
                self.highlighting = False
                try:
                    self.editor.edit_modified(False)
                except tk.TclError:
                    pass

        def _on_edit_move(self, _event):
            try:
                idx = self.editor.index("insert").split(".")
                self.st_pos.config(text="Ln %s, Col %s"
                                   % (int(idx[0]), int(idx[1]) + 1))
            except (tk.TclError, ValueError, IndexError):
                pass

        def _set_title(self):
            name = "Sans titre"
            if self.current_file:
                name = os.path.basename(self.current_file)
            star = "*" if self.dirty else ""
            self.title("%s%s — %s v%s" % (star, name, APP_NAME, VERSION))

        # -----------------------------------------------------------------
        # FICHIERS
        # -----------------------------------------------------------------
        def new_file(self):
            if not self._confirm_discard():
                return
            self.loading = True
            try:
                self.editor.delete("1.0", "end")
                self.editor.edit_reset()
            finally:
                self.loading = False
            self.current_file = None
            self.current_lang = "text"
            self.dirty = False
            self._set_title()
            self._update_line_numbers()
            self._apply_highlight()
            self.st_file.config(text="Aucun fichier")
            self.st_lang.config(text="texte")
            self._console_write("Nouveau fichier. (PROTON : rien d'effacé "
                                "sur disque sans ton accord)", "dim")

        def open_dialog(self):
            path = filedialog.askopenfilename(
                parent=self, title="Ouvrir un fichier",
                initialdir=self.project_dir)
            if path:
                self.open_file(path)

        def open_file(self, path):
            try:
                with open(path, "r", encoding="utf-8",
                          errors="replace") as f:
                    content = f.read()
            except OSError as e:
                messagebox.showerror(APP_NAME,
                                    "Impossible d'ouvrir :\n%s\n(%s)"
                                    % (path, e), parent=self)
                return
            self.loading = True
            try:
                self.editor.delete("1.0", "end")
                self.editor.insert("1.0", content)
                self.editor.edit_reset()
            finally:
                self.loading = False
            self.current_file = path
            self.current_lang = detect_lang(path)
            self.dirty = False
            self._set_title()
            self._update_line_numbers()
            self._apply_highlight()
            self.st_file.config(text=os.path.basename(path))
            self.st_lang.config(text=self.current_lang.upper())
            self._console_write("Ouvert : %s" % path, "dim")

        def save_file(self):
            if not self.current_file:
                return self.save_as()
            return self._write_current(self.current_file)

        def save_as(self):
            path = filedialog.asksaveasfilename(
                parent=self, title="Enregistrer sous…",
                initialdir=self.project_dir,
                confirmoverwrite=True)
            if not path:
                return False
            self.current_file = path
            self.current_lang = detect_lang(path)
            self.st_lang.config(text=self.current_lang.upper())
            self.st_file.config(text=os.path.basename(path))
            ok = self._write_current(path)
            if ok:
                self.refresh_tree()
            return ok

        def _write_current(self, path):
            content = self.editor.get("1.0", "end-1c")
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)
            except OSError as e:
                messagebox.showerror(APP_NAME,
                                    "Écriture impossible :\n%s\n(%s)"
                                    % (path, e), parent=self)
                return False
            self.dirty = False
            self._set_title()
            self._console_write("Enregistré : %s" % path, "ok")
            return True

        def _confirm_discard(self):
            if not self.dirty:
                return True
            r = messagebox.askyesnocancel(
                APP_NAME,
                "Modifications non enregistrées.\nEnregistrer avant de "
                "continuer ?", parent=self)
            if r is None:
                return False
            if r:
                return self.save_file()
            return True

        # -----------------------------------------------------------------
        # ARBORESCENCE PROJET
        # -----------------------------------------------------------------
        def change_project(self):
            d = filedialog.askdirectory(
                parent=self, title="Dossier projet",
                initialdir=self.project_dir)
            if d:
                self.project_dir = os.path.realpath(d)
                self.v_dir.set(self.project_dir)
                self.refresh_tree()
                self._console_write("Projet : %s" % self.project_dir, "dim")

        def refresh_tree(self):
            self.tree.delete(*self.tree.get_children())
            self._tree_paths = {}
            rootname = os.path.basename(self.project_dir) or self.project_dir
            iid = self.tree.insert(
                "", "end", text=rootname, open=True, tags=("dir",))
            self._tree_paths[iid] = self.project_dir
            self._insert_dir(self.project_dir, iid, 1)

        def _insert_dir(self, d, parent, depth):
            if depth > 3:
                return
            try:
                entries = sorted(
                    os.scandir(d),
                    key=lambda e: (not e.is_dir(), e.name.lower()))
            except OSError:
                return
            for entry in entries:
                name = entry.name
                if name in SKIP_DIRS:
                    continue
                if name.startswith(".") and name != ".github":
                    continue
                try:
                    is_dir = entry.is_dir()
                except OSError:
                    continue
                if is_dir:
                    node = self.tree.insert(
                        parent, "end", text=name, open=False, tags=("dir",))
                    self._tree_paths[node] = entry.path
                    self._insert_dir(entry.path, node, depth + 1)
                else:
                    node = self.tree.insert(
                        parent, "end", text=name, tags=("file",))
                    self._tree_paths[node] = entry.path

        def _on_tree_double(self, _event):
            iid = self.tree.focus()
            path = self._tree_paths.get(iid)
            if not path:
                return
            if os.path.isfile(path):
                self.open_file(path)

        # -----------------------------------------------------------------
        # CONSOLE INTÉGRÉE (thread-safe : queue + after, jamais de Tk
        # depuis le thread travail — règle Tk stricte)
        # -----------------------------------------------------------------
        def _console_write(self, line, tag=None):
            self.console.config(state="normal")
            self.console.insert("end", line + "\n", tag or ())
            self.console.see("end")
            self.console.config(state="disabled")

        def _console_clear(self):
            self.console.config(state="normal")
            self.console.delete("1.0", "end")
            self.console.config(state="disabled")

        @staticmethod
        def _classify_line(line):
            low = line.lower()
            # d'abord les bilans chiffrés : « BILAN SELFTEST: PASS=20 FAIL=0 »
            # est une RÉUSSITE — un naïf `"fail" in low` la peindrait rouge.
            m = re.search(r"fail\s*[:=]*\s*(\d+)", low)
            if m:
                return "ok" if m.group(1) == "0" else "err"
            if any(k in low for k in ("fail", "[err]", "[x]", "échec",
                                      "erreur", "error")):
                return "err"
            if any(k in low for k in ("pass", "[ok]", "[+]", "injecté",
                                      "tout vert", "selftest")):
                return "ok"
            if any(k in low for k in ("[warn]", "[!]", "attention",
                                      "missing", "manquant")):
                return "warn"
            return None

        def _poll_queue(self):
            try:
                while True:
                    kind, payload = self.queue.get_nowait()
                    if kind == "line":
                        self._console_write(payload,
                                             self._classify_line(payload))
                    elif kind == "done":
                        rc = payload
                        self.busy = False
                        self._set_gen_state(True)
                        if rc == 0:
                            self._console_write(
                                "== TERMINÉ (rc=0) — TOUT VERT ==", "ok")
                        else:
                            self._console_write(
                                "== ÉCHEC (rc=%d) ==" % rc, "err")
                        cb = self._on_done
                        self._on_done = None
                        if cb:
                            cb(rc)
                    elif kind == "alldone":
                        ok, total = payload
                        self.busy = False
                        self._set_gen_state(True)
                        if ok == total:
                            self._console_write(
                                "== 13 WORKFLOWS : %d/%d TOUT VERT =="
                                % (ok, total), "ok")
                        else:
                            self._console_write(
                                "== GÉNÉRATION INCOMPLÈTE : %d/%d =="
                                % (ok, total), "err")
                        self.refresh_tree()
            except queue.Empty:
                pass
            self._poll_job = self.after(80, self._poll_queue)

        def _set_gen_state(self, enabled):
            state = "normal" if enabled else "disabled"
            for b in self._gen_buttons:
                try:
                    b.config(state=state)
                except tk.TclError:
                    pass

        def _run_task(self, argv, title, on_done=None):
            if self.busy:
                self._console_write("[GENEDIT] une tâche tourne déjà…",
                                    "warn")
                return
            if not self.generator_path:
                self._console_write(
                    "[GENEDIT] générateur introuvable — utilise "
                    "Génération > Re-situer le générateur…", "err")
                return
            self.busy = True
            self._on_done = on_done
            self._set_gen_state(False)
            self._console_clear()
            self._console_write("== %s ==" % title, "cmd")
            self._console_write(format_command(argv), "dim")
            self.queue = queue.Queue()   # file neuve : pas de mélange
            q = self.queue

            def worker():
                try:
                    proc = subprocess.Popen(
                        argv, stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT, text=True,
                        errors="replace", bufsize=1)
                    for line in proc.stdout:
                        q.put(("line", line.rstrip("\n")))
                    rc = proc.wait()
                except Exception as e:                         # noqa: BLE001
                    q.put(("line", "[GENEDIT] interne : %s" % e))
                    rc = 127
                q.put(("done", rc))

            threading.Thread(target=worker, daemon=True).start()

        # -----------------------------------------------------------------
        # COLLECTE DES OPTIONS (validées par build_gen_command)
        # -----------------------------------------------------------------
        def _collect_options(self):
            opts = {}
            for key in DEFAULT_OPTIONS:
                var = getattr(self, "v_" + key, None)
                if var is not None:
                    opts[key] = var.get()
            _, rejected = sanitize_options(opts)
            for key, val in rejected:
                self._console_write(
                    "[GENEDIT] option REJETÉE (caractères interdits) : "
                    "%s=%r → défaut du générateur utilisé" % (key, val),
                    "warn")
            return opts

        def _target_dir(self):
            raw = self.v_dir.get().strip()
            target = os.path.expanduser(raw) if raw else self.project_dir
            if not os.path.isdir(target):
                if messagebox.askyesno(
                        APP_NAME,
                        "Dossier cible inexistant :\n%s\n\nLe créer ?"
                        % target, parent=self):
                    try:
                        os.makedirs(target, exist_ok=True)
                    except OSError as e:
                        messagebox.showerror(APP_NAME,
                                             "Création impossible : %s" % e,
                                             parent=self)
                        return None
                else:
                    return None
            return os.path.realpath(target)

        def _ensure_git_repo(self, target):
            """check_env du générateur EXIGE un dépôt git (rc=3 sinon).
            Même logique que nexus-tout-en-un.sh étape 4/6 : on PROPOSE
            « git init » — jamais à l'insu. Retourne True si on continue."""
            if os.path.isdir(os.path.join(target, ".git")):
                return True
            r = messagebox.askyesno(
                APP_NAME,
                "Le dossier cible n'est pas un dépôt git :\n%s\n\n"
                "Le générateur l'EXIGE (check_env → rc=3 sinon).\n"
                "Faire « git init » maintenant ?" % target,
                parent=self)
            if not r:
                self._console_write(
                    "[GENEDIT] annulé : la cible n'est pas un dépôt git "
                    "(le générateur l'exige)", "err")
                return False
            try:
                p = subprocess.run(
                    ["git", "init", "-q", target],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, timeout=30)
            except FileNotFoundError:
                self._console_write(
                    "[GENEDIT] git absent — git init impossible", "err")
                return False
            if p.returncode == 0:
                self._console_write("git init fait : %s" % target, "ok")
                return True
            self._console_write(
                "[ERR] git init échoué : %s" % p.stdout.strip(), "err")
            return False
        # -----------------------------------------------------------------
        # ACTIONS GÉNÉRATION
        # -----------------------------------------------------------------
        def on_selftest(self):
            cmd = build_gen_command(self.generator_path, "selftest")
            self._run_task(cmd, "SELFTEST du générateur")

        def on_doctor(self):
            cmd = build_gen_command(self.generator_path, "doctor")
            self._run_task(cmd, "DOCTOR — diagnostic environnement")

        def on_list(self):
            cmd = build_gen_command(self.generator_path, "list")
            self._run_task(cmd, "LISTE des 13 types")

        def on_manual(self):
            cmd = build_gen_command(self.generator_path, "manual")
            self._run_task(cmd, "MANUEL du générateur")

        def on_changelog(self):
            cmd = build_gen_command(self.generator_path, "changelog")
            self._run_task(cmd, "CHANGELOG")

        def on_explain(self):
            t = self.v_type.get()
            cmd = build_gen_command(
                self.generator_path, "explain",
                options={"type": t})
            self._run_task(cmd, "EXPLAIN : %s" % t)

        def on_generate(self):
            target = self._target_dir()
            if not target:
                return
            if not self._ensure_git_repo(target):
                return
            mode = self.v_type.get()
            opts = self._collect_options()
            try:
                cmd = build_gen_command(
                    self.generator_path, mode, target, opts,
                    force=bool(self.v_force.get()),
                    dry_run=bool(self.v_dry.get()))
            except ValueError as e:
                self._console_clear()
                self._console_write("[GENEDIT] %s" % e, "err")
                return

            def after(rc):
                if rc == 0 and not self.v_dry.get():
                    self.refresh_tree()
                    produced = os.path.join(
                        target, ".github", "workflows",
                        "nexus-%s.yml" % mode)
                    if os.path.isfile(produced):
                        self.open_file(produced)
                        self._console_write(
                            "Le workflow généré s'ouvre dans l'éditeur.",
                            "ok")

            self._run_task(cmd, "GÉNÉRATION %s → %s" % (mode, target),
                           on_done=after)

        def on_generate_all(self):
            target = self._target_dir()
            if not target:
                return
            if not self._ensure_git_repo(target):
                return
            if not messagebox.askyesno(
                    APP_NAME,
                    "Générer les 13 workflows dans :\n%s\n\n"
                    "(Force=%s — les nexus-*.yml existants sont écrasés)"
                    % (target, "oui" if self.v_force.get() else "non"),
                    parent=self):
                return
            opts = self._collect_options()
            force = bool(self.v_force.get())
            dry = bool(self.v_dry.get())
            gen = self.generator_path
            self.busy = True
            self._on_done = None
            self._set_gen_state(False)
            self._console_clear()
            self._console_write("== GÉNÉRATION DES 13 TYPES → %s ==" % target,
                                 "cmd")
            self.queue = queue.Queue()
            q = self.queue

            def worker():
                ok = 0
                for t in ALL_TYPES:
                    try:
                        cmd = build_gen_command(
                            gen, t, target, opts, force=force, dry_run=dry)
                    except ValueError as e:                     # noqa: BLE001
                        q.put(("line", "[GENEDIT] %s" % e))
                        continue
                    q.put(("line", "\u2500\u2500 %s \u2500\u2500" % t))
                    try:
                        proc = subprocess.Popen(
                            cmd, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True,
                            errors="replace", bufsize=1)
                        for line in proc.stdout:
                            q.put(("line", line.rstrip("\n")))
                        rc = proc.wait()
                    except Exception as e:                     # noqa: BLE001
                        q.put(("line", "[GENEDIT] interne : %s" % e))
                        rc = 127
                    if rc == 0:
                        ok += 1
                        q.put(("line", "[OK] %s injecté" % t))
                    else:
                        q.put(("line", "[ERR] %s : rc=%d" % (t, rc)))
                q.put(("alldone", (ok, len(ALL_TYPES))))

            threading.Thread(target=worker, daemon=True).start()

        def browse_target(self):
            d = filedialog.askdirectory(
                parent=self, title="Dossier cible des workflows",
                initialdir=self.project_dir)
            if d:
                self.v_dir.set(os.path.realpath(d))

        def relocate_generator(self):
            path = filedialog.askopenfilename(
                parent=self, title="Situer nexus-ci-generator.sh",
                filetypes=[("nexus-ci-generator", "nexus-ci-generator.sh"),
                           ("Scripts shell", "*.sh"),
                           ("Tous", "*")])
            if path:
                found = find_generator(path)
                if found:
                    self.generator_path = found
                    self._update_gen_status()
                    self._console_write("Générateur : %s" % found, "ok")
                else:
                    messagebox.showerror(
                        APP_NAME, "Fichier illisible : %s" % path,
                        parent=self)

        def _update_gen_status(self):
            if self.generator_path:
                self.st_gen.config(
                    text="Générateur : %s" % self.generator_path,
                    fg=THEME["ok"])
            else:
                self.st_gen.config(
                    text="Générateur : ABSENT (mode éditeur seul)",
                    fg=THEME["err"])

        # -----------------------------------------------------------------
        # AIDE
        # -----------------------------------------------------------------
        def show_memo(self):
            if self.nb_bottom is not None:
                self.nb_bottom.select(1)   # onglet Mémo / Aide

        def show_about(self):
            messagebox.showinfo(
                "À propos — %s" % APP_NAME,
                "%s v%s\n\n"
                "Éditeur GÉNÉRATIF natif Linux (Tkinter / X11).\n"
                "Zéro navigateur. Zéro Electron. Zéro HTML.\n\n"
                "Générateur intégré : %s\n\n"
                "Auteur : Aissa Mohammedi (DGK)\n"
                "NEXUS-OPEN-3.0 — protocole PROTON"
                % (APP_NAME, VERSION,
                   self.generator_path or "INTROUVABLE (éditeur seul)"),
                parent=self)

        @staticmethod
        def _memo_text():
            return (
                "NEXUS GENEDIT — MÉMO\n"
                "=====================\n\n"
                "Éditeur de code natif + panneau génératif NEXUS CI.\n"
                "Zéro navigateur, zéro Electron : fenêtre X11 pure.\n\n"
                "GÉNÉRER UN WORKFLOW\n"
                "  1. choisis le TYPE CI (aegis, java, python, node, docker,\n"
                "     go, rust, release, nightly, php, dotnet, cpp, android)\n"
                "  2. choisis la CIBLE (dossier du dépôt)\n"
                "  3. règle Branche / Node / Java / Python / Go / PHP / .NET /\n"
                "     Cron / Registre — chaque option est VALIDÉE avant\n"
                "     d'être transmise (rejet déclaré, jamais silencieux)\n"
                "  4. [▶ GÉNÉRER] → le nexus-<type>.yml est écrit dans\n"
                "     .github/workflows/ puis s'ouvre coloré dans l'éditeur.\n"
                "  5. [LES 13] → les 13 workflows d'un coup (comme le\n"
                "     tout-en-un). Dry-run = simulation sans écrire.\n\n"
                "DÉFAUT CONNU du générateur v2.0.0 (déclaré, PROTON ③) :\n"
                "  en --dry-run sur un dépôt NEUF, il échoue rc=1 car il ne\n"
                "  crée pas .github/workflows avant d'y faire son mktemp.\n"
                "  → sur un dépôt où les workflows existent déjà : normal.\n\n"
                "BOUTONS DIAGNOSTIC\n"
                "  Selftest — banc interne du générateur (PASS=20 FAIL=0)\n"
                "  Doctor  — diagnostic de l'environnement\n"
                "  Lister  — les 13 types avec description\n"
                "  Manuel  — le manuel complet intégré\n\n"
                "SÉCURITÉ (PROTON)\n"
                "  - commandes en LISTE argv, jamais en chaîne shell\n"
                "  - options filtrées par motifs anti-injection\n"
                "  - uninstall n'est PAS exposé dans la GUI : passe par le\n"
                "    terminal → bash nexus-ci-generator.sh uninstall\n\n"
                "RACCOURCIS\n"
                "  Ctrl+N nouveau   Ctrl+O ouvrir   Ctrl+S enregistrer\n"
                "  F5 rafraîchir l'arborescence   Ctrl+Q quitter\n\n"
                "CLI du générateur (VERBATIM --help v2.0.0) :\n"
                "  <type> --dir <chemin> --branch <br> --node <v> --java <v>\n"
                "         --python <v> --go <v> --php <v> --dotnet <v>\n"
                "         --registry <hôte> --cron <expr> --force --dry-run\n\n"
                "Auteur : Aissa Mohammedi (DGK) — NEXUS-OPEN-3.0 / PROTON\n"
            )

        # -----------------------------------------------------------------
        def _smoke_quit(self):
            # mode banc : preuve que la fenêtre s'est réellement construite.
            # GENEDIT_SMOKE_DUMP=1 → dump des géométries (diagnostic visuel
            # au banc : croiser positions des widgets et pixels clairs).
            if os.environ.get("GENEDIT_SMOKE_DUMP"):
                def walk(w, depth):
                    for c in w.winfo_children():
                        try:
                            bg = "?"
                            if "background" in c.keys():
                                bg = c.cget("background")
                            print("WIDGET %-14s x=%4d y=%4d w=%4d h=%4d bg=%s %s"
                                  % (c.winfo_class(),
                                     c.winfo_rootx() - self.winfo_rootx(),
                                     c.winfo_rooty() - self.winfo_rooty(),
                                     c.winfo_width(), c.winfo_height(),
                                     bg, str(c)))
                        except Exception:                     # noqa: BLE001
                            pass
                        walk(c, depth + 1)
                try:
                    walk(self, 0)
                    if os.environ.get("GENEDIT_SMOKE_SHOT"):
                        # capture SYNCHRONE avec le dump : zéro décalage
                        try:
                            from PIL import ImageGrab
                            shot = ImageGrab.grab(
                                xdisplay=os.environ.get("DISPLAY"))
                            shot.save(os.environ["GENEDIT_SMOKE_SHOT"])
                            print("SHOT-IN-APP OK %dx%d"
                                  % (shot.width, shot.height))
                        except Exception as e:                 # noqa: BLE001
                            print("SHOT-IN-APP ERR %s" % e)
                    st2 = ttk.Style(self)
                    for sname in ("TNotebook", "TNotebook.Tab",
                                  "Vertical.TScrollbar",
                                  "Horizontal.TScrollbar",
                                  "Treeview", "TCombobox", "TEntry"):
                        print("LOOKUP %-22s bg=%s fg=%s trough=%s field=%s"
                              % (sname,
                                 st2.lookup(sname, "background"),
                                 st2.lookup(sname, "foreground"),
                                 st2.lookup(sname, "troughcolor"),
                                 st2.lookup(sname, "fieldbackground")))
                except Exception:                             # noqa: BLE001
                    pass
            print("GENEDIT SMOKE OK")
            sys.stdout.flush()
            self.destroy()

        def on_close(self):
            if not self._confirm_discard():
                return
            if self._poll_job is not None:
                try:
                    self.after_cancel(self._poll_job)
                except tk.TclError:
                    pass
            self.destroy()


# ---------------------------------------------------------------------------
# POINT D'ENTRÉE
# ---------------------------------------------------------------------------
def _usage():
    print("NEXUS GenEdit v%s — éditeur génératif natif (Tkinter/X11)" % VERSION)
    print()
    print("Usage :")
    print("  genedit.py [--gen <nexus-ci-generator.sh>] [--project <dossier>]")
    print("  genedit.py --bench       banc interne (sans écran)")
    print("  genedit.py --smoke       construction GUI + sortie immédiate (banc)")
    print("  genedit.py --version     version")
    print("  genedit.py --help        cette aide")
    print()
    print("Variable d'environnement reconnue : NEXUS_CI_GENERATOR")


def main(argv):
    gen = None
    project = None
    smoke = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--bench":
            return run_bench()
        if a in ("-h", "--help"):
            _usage()
            return 0
        if a == "--version":
            print("%s v%s" % (APP_NAME, VERSION))
            return 0
        if a == "--smoke":
            smoke = True
            i += 1
            continue
        if a in ("--gen", "--project"):
            if i + 1 >= len(argv):
                print("[ERR] %s exige une valeur" % a)
                return 2
            if a == "--gen":
                gen = argv[i + 1]
            else:
                project = argv[i + 1]
            i += 2
            continue
        print("[ERR] option inconnue : %s (voir --help)" % a)
        return 2

    if not HAS_TK:
        print("[ERR] tkinter est absent :  sudo apt install python3-tk")
        print("      (PROTON ③ : manquant DÉCLARÉ, rien n'est simulé)")
        return 1

    app = GenEditApp(generator_path=gen, project_dir=project, smoke=smoke)
    if smoke:
        if not project:
            # banc sans projet fourni : mini-projet échantillon réel
            import tempfile
            sample_yaml = (
                "name: NEXUS Node CI\n"
                "on:\n"
                "  push:\n"
                "    branches: [main]\n"
                "jobs:\n"
                "  build:\n"
                "    runs-on: ubuntu-latest\n"
                "    steps:\n"
                "      - uses: actions/checkout@v4  # comment\n"
                "      - run: echo \"NEXUS\"\n"
            )
            d = tempfile.mkdtemp(prefix="genedit-smoke-")
            wf = os.path.join(d, ".github", "workflows")
            os.makedirs(wf, exist_ok=True)
            with open(os.path.join(wf, "nexus-node.yml"), "w",
                      encoding="utf-8") as f:
                f.write(sample_yaml)
            with open(os.path.join(d, "build.sh"), "w",
                      encoding="utf-8") as f:
                f.write("#!/usr/bin/env bash\necho \"ok\"\n")
            with open(os.path.join(d, "main.py"), "w",
                      encoding="utf-8") as f:
                f.write("def main():\n    return 0  # test\n")
            app.project_dir = d
            app.v_dir.set(d)
            app.refresh_tree()
            app.open_file(os.path.join(wf, "nexus-node.yml"))
        # un seul scheduler, ici, après construction complète de l'UI
        # (délai pilotable : GENEDIT_SMOKE_MS — utilisé par le banc/capture)
        delay_ms = 1600
        try:
            delay_ms = max(200, int(os.environ.get("GENEDIT_SMOKE_MS",
                                                   "1600")))
        except ValueError:
            pass
        app.after(delay_ms, app._smoke_quit)
    app.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
