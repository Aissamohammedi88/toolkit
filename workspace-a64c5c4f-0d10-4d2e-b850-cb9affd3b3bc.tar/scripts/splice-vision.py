#!/usr/bin/env python3
"""Splice le serveur Build Vision dans gent-install.sh + génère gent-upgrade-vision.sh."""
import pathlib

ROOT = pathlib.Path('/home/z/my-project/download/gent')
SERVER = (ROOT / 'app' / 'gent-server.js').read_text(encoding='utf-8')
assert 'BUILD VISION' in SERVER and '/api/validate' in SERVER, 'serveur vision attendu'

# ── 1. gent-install.sh : remplacer le bloc heredoc du serveur ────────────────
inst_path = ROOT / 'gent-install.sh'
inst = inst_path.read_text(encoding='utf-8')
MARK_OPEN = "  cat > \"$GENT_HOME/app/gent-server.js\" <<'GENT_SERVER_EOF'"
MARK_CLOSE = 'GENT_SERVER_EOF'
i = inst.index(MARK_OPEN)
j = inst.index(MARK_CLOSE, i + len(MARK_OPEN))
new_block = MARK_OPEN + '\n' + SERVER.rstrip('\n') + '\n' + MARK_CLOSE
inst = inst[:i] + new_block + inst[j + len(MARK_CLOSE):]
inst_path.write_text(inst, encoding='utf-8')
print(f'gent-install.sh : serveur splicé ({len(SERVER)} octets), fichier {inst_path.stat().st_size} o')

# ── 2. gent-upgrade-vision.sh : script d'upgrade autonome ────────────────────
TEMPLATE = r'''#!/usr/bin/env bash
# =============================================================================
#  GENT — UPGRADE "BUILD VISION 1.0"
#  Installe le serveur 3 panneaux (Éditeur | Terminal | Live Preview) dans une
#  installation existante, SANS toucher à l'identité ni à ~/Aether.
#
#  Usage :  bash gent-upgrade-vision.sh
#  Idempotent : relançable autant de fois que nécessaire. Sauvegarde l'ancien
#  serveur dans ~/gent/backup/vision-<date>/ et valide le nouveau (node --check)
#  AVANT de redémarrer — rollback automatique si invalide.
# =============================================================================
set -Eeuo pipefail
umask 077

log()  { printf '\033[1;35m[gent:vision]\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32m  ✔\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m  ⚠\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[gent:vision:ERREUR]\033[0m %s\n' "$*" >&2; exit 1; }

GENT_HOME="${GENT_HOME:-$HOME/gent}"
[ -d "$GENT_HOME" ] || die "GENT absent dans $GENT_HOME — lance d'abord gent-install.sh"
AETHER="$HOME/Aether"
case "$GENT_HOME/" in "$AETHER"/*|"$AETHER") die "GENT_HOME est dans ~/Aether — refus" ;; esac
log "Zone sacrée ~/Aether : intouchée"

NODE_BIN="$GENT_HOME/runtime/current/bin/node"
[ -x "$NODE_BIN" ] || NODE_BIN="$(command -v node || true)"
[ -n "$NODE_BIN" ] || die "aucun node disponible"

# ── sauvegarde ──
TS="$(date +%Y%m%d-%H%M%S)"
BK="$GENT_HOME/backup/vision-$TS"
mkdir -p "$BK"
[ -f "$GENT_HOME/app/gent-server.js" ] && cp "$GENT_HOME/app/gent-server.js" "$BK/gent-server.js" && \
  ok "ancien serveur sauvegardé : backup/vision-$TS/gent-server.js"

# ── installation du nouveau serveur ──
cat > "$GENT_HOME/app/gent-server.js" <<'GENT_VISION_SERVER_EOF'
@@SERVER@@
GENT_VISION_SERVER_EOF
chmod 600 "$GENT_HOME/app/gent-server.js"
ok "serveur Build Vision écrit ($(wc -c < "$GENT_HOME/app/gent-server.js") octets)"

# ── validation AVANT redémarrage (protocole zéro erreur appliqué à nous-mêmes) ──
if "$NODE_BIN" --check "$GENT_HOME/app/gent-server.js" 2>"$BK/check.err"; then
  ok "compilation sèche : node --check OK"
else
  cp "$BK/gent-server.js" "$GENT_HOME/app/gent-server.js" 2>/dev/null || true
  die "node --check a échoué — ancien serveur restauré. Détails : $(cat "$BK/check.err")"
fi

# ── redémarrage du service ──
RESTARTED=0
if command -v systemctl >/dev/null 2>&1 && systemctl --user daemon-reload >/dev/null 2>&1; then
  systemctl --user restart gent-node.service >/dev/null 2>&1 || systemctl --user enable --now gent-node.service >/dev/null 2>&1 || true
  RESTARTED=1
  ok "service systemd redémarré"
else
  warn "systemd --user indisponible — relance directe"
  pkill -f "app/gent-server.js" 2>/dev/null || true
  sleep 0.5
  PORT="$(grep -o '"port": *[0-9]*' "$GENT_HOME/identity/instance.json" 2>/dev/null | grep -o '[0-9]*' || echo 4310)"
  NODE_BIN="$NODE_BIN" GENT_HOME="$GENT_HOME" PORT="$PORT" NODE_COMPILE_CACHE="$GENT_HOME/cache/v8" \
    setsid "$NODE_BIN" --max-semi-space-size=64 "$GENT_HOME/app/gent-server.js" >>"$GENT_HOME/logs/service.log" 2>&1 &
  disown 2>/dev/null || true
  RESTARTED=1
fi

# ── santé ──
PORT="$(grep -o '"port": *[0-9]*' "$GENT_HOME/identity/instance.json" 2>/dev/null | grep -o '[0-9]*' || echo 4310)"
UP=0; VISION=0
for i in $(seq 1 30); do
  if curl -fsS "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then UP=1; break; fi
  sleep 0.3
done
[ "$UP" = 1 ] && ok "santé HTTP : 200 sur http://127.0.0.1:$PORT" || warn "health KO — journal : journalctl --user -u gent-node -n 30"
for i in $(seq 1 20); do
  C="$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:${PORT}/vision" 2>/dev/null || true)"
  [ "$C" = "200" ] && { VISION=1; break; }
  sleep 0.3
done
[ "$VISION" = 1 ] && ok "Build Vision : /vision répond 200 (3 panneaux en ligne)" \
                 || die "/vision ne répond pas — rollback manuel : cp $BK/gent-server.js $GENT_HOME/app/gent-server.js"

cat <<SUM

  ══════════════════════════════════════════════════════════════════
   GENT BUILD VISION 1.0 — INSTALLÉ
  ══════════════════════════════════════════════════════════════════
   Ouvrir        : http://127.0.0.1:$PORT/vision
   IDE classique : http://127.0.0.1:$PORT/  (inchangé)
   Identité      : conservée (aucun changement d'instance)
   Sauvegarde    : $BK
   Protocole     : AST V8 → lint → node --check → sandbox → publication
   Démo seedée   : workspace/demo-vision/ (index.html · style.css · app.js)
  ══════════════════════════════════════════════════════════════════

SUM
'''
out = TEMPLATE.replace('@@SERVER@@', SERVER.rstrip('\n'))
up_path = ROOT / 'gent-upgrade-vision.sh'
up_path.write_text(out, encoding='utf-8')
up_path.chmod(0o755)
print(f'gent-upgrade-vision.sh généré : {up_path.stat().st_size} octets')

# ── 3. cohérence : le serveur splicé dans l'installeur == le fichier testé ──
import re
m = re.search(r"cat > \"\$GENT_HOME/app/gent-server\.js\" <<'GENT_SERVER_EOF'\n(.*?)\nGENT_SERVER_EOF\n",
              inst_path.read_text(encoding='utf-8'), re.S)
assert m and m.group(1) == SERVER.rstrip('\n'), 'le serveur embarqué diffère du fichier testé'
print('cohérence installeur ↔ serveur testé : OK')
