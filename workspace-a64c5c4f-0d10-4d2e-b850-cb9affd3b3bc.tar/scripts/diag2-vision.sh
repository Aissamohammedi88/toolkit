#!/usr/bin/env bash
set -u
export GENT_HOME=/tmp/gent-e2e
cd /tmp
PORT=43112 "$GENT_HOME/runtime/current/bin/node" --max-semi-space-size=64 "$GENT_HOME/app/gent-server.js" > /tmp/e2e.log 2>&1 &
for i in $(seq 1 40); do curl -fsS http://127.0.0.1:43112/api/health >/dev/null 2>&1 && break; sleep 0.3; done
SRVTOK=$(python3 -c "import json;print(json.load(open('$GENT_HOME/identity/instance.json'))['auth_token'])")
agent-browser open http://127.0.0.1:43112/vision >/dev/null 2>&1
sleep 2.5
echo "jeton serveur : ${SRVTOK:0:10}… (longueur ${#SRVTOK})"
echo "jeton page    : $(agent-browser eval 'T.length') $(agent-browser eval 'T.slice(0,10)')"
echo "tree enfants  : $(agent-browser eval 'document.getElementById("tree").children.length')"
echo "term texte    : $(agent-browser eval 'document.getElementById("term").innerText.slice(0,300)')"
agent-browser close >/dev/null 2>&1
pkill -f gent-server.js 2>/dev/null
true
