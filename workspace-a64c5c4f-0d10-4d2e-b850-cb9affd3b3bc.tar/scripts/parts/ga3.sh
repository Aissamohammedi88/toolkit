
# ════════════════════════════════════════════════════════════════════
#  PARTIE B — nexus_services.py (2/2) : LLM, voix, traduction, data…
# ════════════════════════════════════════════════════════════════════

cat >> "$APP_DIR/nexus_services.py" <<'NS2'

# ─────────────────────────────────────────────────────────────────────
#  TEXTE IA sans-clé (5)
# ─────────────────────────────────────────────────────────────────────
def _polli_txt(model):
    def _run(p):
        st, b, u = http_req("https://text.pollinations.ai/" + _q(p.get("prompt", "Dis bonjour en une phrase.")),
                            headers={"Accept": "text/plain"}, timeout=90)
        if st == 0:
            return R("texte", ok=False, info="réseau injoignable", status=0)
        if st >= 400:
            return R("texte", ok=False, info="HTTP %s — modèle %s en charge, essaye un autre" % (st, model), status=st)
        return R("texte", status=st, text=b.decode("utf-8", "replace")[:20000], info="Pollinations · " + model, url=u)
    return _run

TXT_PARAMS = [("prompt", "Explique en 3 phrases ce qu'est un workflow GitHub Actions.", "prompt")]

srv(id="txt-polli-openai", nom="Pollinations · GPT-4o-mini (sans clé)", cat="TEXTE IA (sans-clé)", acces="sans-clé", genre="texte",
    desc="LLM OpenAI servi gratuitement par Pollinations. Vérifié vivant sans aucune clé.",
    params=TXT_PARAMS, run=_polli_txt("openai"),
    ping=lambda: http_req("https://text.pollinations.ai/hello", timeout=12)[0])
srv(id="txt-polli-mistral", nom="Pollinations · Mistral (sans clé)", cat="TEXTE IA (sans-clé)", acces="sans-clé", genre="texte",
    desc="Mistral gratuit via Pollinations.",
    params=TXT_PARAMS, run=_polli_txt("mistral"),
    ping=lambda: http_req("https://text.pollinations.ai/hello?model=mistral", timeout=12)[0])
srv(id="txt-polli-llama", nom="Pollinations · Llama (sans clé)", cat="TEXTE IA (sans-clé)", acces="sans-clé", genre="texte",
    desc="Llama gratuit via Pollinations.",
    params=TXT_PARAMS, run=_polli_txt("llama"),
    ping=lambda: http_req("https://text.pollinations.ai/hello?model=llama", timeout=12)[0])
srv(id="txt-polli-deepseek", nom="Pollinations · DeepSeek (sans clé)", cat="TEXTE IA (sans-clé)", acces="sans-clé", genre="texte",
    desc="DeepSeek gratuit via Pollinations (bon en raisonnement).",
    params=TXT_PARAMS, run=_polli_txt("deepseek"),
    ping=lambda: http_req("https://text.pollinations.ai/hello?model=deepseek", timeout=12)[0])
srv(id="txt-polli-qwen", nom="Pollinations · Qwen-Coder (sans clé)", cat="TEXTE IA (sans-clé)", acces="sans-clé", genre="texte",
    desc="Qwen Coder gratuit : spécialiste du code et du YAML.",
    params=TXT_PARAMS, run=_polli_txt("qwen-coder"),
    ping=lambda: http_req("https://text.pollinations.ai/hello?model=qwen-coder", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  TEXTE IA local (9)
# ─────────────────────────────────────────────────────────────────────
srv(id="llm-ollama", nom="Ollama (local :11434)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="Ton IA 100% locale. Lance « ollama serve » puis « ollama run llama3 ».",
    params=TXT_PARAMS, run=local_openai(11434, "/api/chat"), ping=port_ping(11434))
srv(id="llm-lmstudio", nom="LM Studio (local :1234)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="Serveur local OpenAI-compatible de LM Studio.",
    params=TXT_PARAMS, run=local_openai(1234), ping=port_ping(1234))
srv(id="llm-llamacpp", nom="llama.cpp server (local :8080)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="Serveur llama.cpp en mode OpenAI-compatible.",
    params=TXT_PARAMS, run=local_openai(8080), ping=port_ping(8080))
srv(id="llm-jan", nom="Jan (local :1337)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="Application Jan, serveur local.",
    params=TXT_PARAMS, run=local_openai(1337), ping=port_ping(1337))
srv(id="llm-gpt4all", nom="GPT4All (local :4891)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="Serveur GPT4All.",
    params=TXT_PARAMS, run=local_openai(4891), ping=port_ping(4891))
srv(id="llm-kobold", nom="KoboldCpp (local :5001)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="KoboldCpp, API native.",
    params=TXT_PARAMS,
    run=lambda p: _kobold(p), ping=port_ping(5001))


def _kobold(p):
    st, j, _ = http_json("http://127.0.0.1:5001/api/v1/generate", method="POST",
                         headers={"Content-Type": "application/json"},
                         data=json.dumps({"prompt": p.get("prompt", "Bonjour"), "max_length": 400}), timeout=90)
    if st == 0:
        return R("texte", ok=False, info="KoboldCpp éteint (port 5001)", status=0)
    if st >= 400 or not j:
        return R("texte", ok=False, info="HTTP %s" % st, status=st)
    return R("texte", status=st, text=(j.get("results") or [{}])[0].get("text", ""))

srv(id="llm-tgwui", nom="text-generation-webui (local :5000)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="oobabooga, extension OpenAI activée.",
    params=TXT_PARAMS, run=local_openai(5000), ping=port_ping(5000))
srv(id="llm-vllm", nom="vLLM (local :8000)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="Serveur vLLM haute performance.",
    params=TXT_PARAMS, run=local_openai(8000), ping=port_ping(8000))
srv(id="llm-localai", nom="LocalAI (local :8081)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="LocalAI, alternative open-source à l'API OpenAI.",
    params=TXT_PARAMS, run=local_openai(8081), ping=port_ping(8081))

# ─────────────────────────────────────────────────────────────────────
#  TEXTE IA clé-gratuite (9)
# ─────────────────────────────────────────────────────────────────────
def _openai_cloud(base, model, envk, extra_headers=None):
    def _run(p):
        key = os.environ.get(envk, "")
        if not key:
            return R("texte", ok=False, info="clé absente — export %s=… (offre gratuite chez le fournisseur)" % envk)
        h = {"Content-Type": "application/json", "Authorization": "Bearer " + key}
        if extra_headers:
            h.update(extra_headers)
        st, j, _ = http_json(base, method="POST", headers=h,
                             data=json.dumps({"model": model, "messages": [{"role": "user", "content": p.get("prompt", "Bonjour")}]}),
                             timeout=90)
        if st >= 400 or not j:
            return R("texte", ok=False, info="HTTP %s — %s" % (st, json.dumps(j)[:150] if j else "?"), status=st)
        try:
            txt = j["choices"][0]["message"]["content"]
        except Exception:
            txt = json.dumps(j, ensure_ascii=False)[:2000]
        return R("texte", status=st, text=txt, info=model)
    return _run

srv(id="llm-groq", nom="Groq · Llama 3.3 70B", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="Le plus rapide du monde, offre gratuite généreuse. console.groq.com → NEXUS_GROQ_KEY.",
    params=TXT_PARAMS, run=_openai_cloud("https://api.groq.com/openai/v1/chat/completions", "llama-3.3-70b-versatile", "NEXUS_GROQ_KEY"),
    ping=lambda: http_req("https://api.groq.com/openai/v1/models", timeout=10)[0])
srv(id="llm-mistral-api", nom="Mistral · Small", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="Offre gratuite « experiment ». console.mistral.ai → NEXUS_MISTRAL_KEY.",
    params=TXT_PARAMS, run=_openai_cloud("https://api.mistral.ai/v1/chat/completions", "mistral-small-latest", "NEXUS_MISTRAL_KEY"),
    ping=lambda: http_req("https://api.mistral.ai/v1/models", timeout=10)[0])
def _gemini_run(p):
    key = os.environ.get("NEXUS_GEMINI_KEY", "")
    if not key:
        return R("texte", ok=False, info="clé absente — export NEXUS_GEMINI_KEY=… (gratuit aistudio.google.com)")
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + _q(key)
    st, j, _ = http_json(url, method="POST", headers={"Content-Type": "application/json"},
                         data=json.dumps({"contents": [{"parts": [{"text": p.get("prompt", "Bonjour")}]}]}), timeout=90)
    if st >= 400 or not j:
        return R("texte", ok=False, info="HTTP %s — %s" % (st, json.dumps(j)[:150] if j else "?"), status=st)
    try:
        txt = j["candidates"][0]["content"]["parts"][0]["text"]
    except Exception:
        txt = json.dumps(j, ensure_ascii=False)[:2000]
    return R("texte", status=st, text=txt, info="gemini-1.5-flash")

srv(id="llm-gemini", nom="Google Gemini 1.5 Flash", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="15 requêtes/min gratuites. aistudio.google.com → NEXUS_GEMINI_KEY.",
    params=TXT_PARAMS, run=_gemini_run,
    ping=lambda: http_req("https://generativelanguage.googleapis.com/v1beta/models", timeout=10)[0])

srv(id="llm-openrouter", nom="OpenRouter · modèles :free", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="Des dizaines de modèles gratuits (suffixe :free). openrouter.ai → NEXUS_OPENROUTER_KEY.",
    params=[("prompt", "Bonjour !", "prompt"), ("modele", "meta-llama/llama-3.1-8b-instruct:free", "modèle")],
    run=lambda p: _openai_cloud("https://openrouter.ai/api/v1/chat/completions", p.get("modele", "meta-llama/llama-3.1-8b-instruct:free"), "NEXUS_OPENROUTER_KEY", {"HTTP-Referer": "https://nexus.local", "X-Title": "NEXUS GenHub"})(p),
    ping=lambda: http_req("https://openrouter.ai/api/v1/models", timeout=10)[0])
srv(id="llm-github", nom="GitHub Models (token GitHub)", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="GPT-4o-mini gratuit avec ton token GitHub (settings → tokens).",
    params=TXT_PARAMS, run=_openai_cloud("https://models.inference.ai.azure.com/chat/completions", "gpt-4o-mini", "NEXUS_GITHUB_TOKEN"),
    ping=lambda: http_req("https://api.github.com/rate_limit", timeout=10)[0])
srv(id="llm-cerebras", nom="Cerebras · Llama 70B", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="1M tokens/jour gratuits. cloud.cerebras.ai → NEXUS_CEREBRAS_KEY.",
    params=TXT_PARAMS, run=_openai_cloud("https://api.cerebras.ai/v1/chat/completions", "llama-3.3-70b", "NEXUS_CEREBRAS_KEY"),
    ping=lambda: http_req("https://api.cerebras.ai/v1/models", timeout=10)[0])
srv(id="llm-sambanova", nom="SambaNova · Llama 3.3 70B", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="Offre développeur gratuite. cloud.sambanova.ai → NEXUS_SAMBANOVA_KEY.",
    params=TXT_PARAMS, run=_openai_cloud("https://api.sambanova.ai/v1/chat/completions", "Meta-Llama-3.3-70B-Instruct", "NEXUS_SAMBANOVA_KEY"),
    ping=lambda: http_req("https://api.sambanova.ai/", timeout=10)[0])
srv(id="llm-hf", nom="Hugging Face · Router LLM", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="Routeur HF unifié (token gratuit).",
    params=TXT_PARAMS, run=_openai_cloud("https://router.huggingface.co/v1/chat/completions", "meta-llama/Llama-3.1-8B-Instruct", "NEXUS_HF_KEY"),
    ping=lambda: http_req("https://huggingface.co/api/whoami-v2", timeout=10)[0])
srv(id="llm-cloudflare", nom="Cloudflare Workers AI", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="10k neurones/jour gratuits. Paramètre « compte » = ton account ID Cloudflare.",
    params=[("prompt", "Bonjour !", "prompt"), ("compte", "", "account ID Cloudflare")],
    run=lambda p: _cf_run(p),
    ping=lambda: http_req("https://api.cloudflare.com/client/v4/user", timeout=10)[0])


def _cf_run(p):
    tok = os.environ.get("NEXUS_CF_TOKEN", "")
    acc = p.get("compte", "")
    if not tok or not acc:
        return R("texte", ok=False, info="il faut NEXUS_CF_TOKEN=… et ton account ID dans le champ « compte »")
    st, j, _ = http_json("https://api.cloudflare.com/client/v4/accounts/%s/ai/run/@cf/meta/llama-3.1-8b-instruct" % _q(acc),
                         method="POST", headers={"Authorization": "Bearer " + tok, "Content-Type": "application/json"},
                         data=json.dumps({"messages": [{"role": "user", "content": p.get("prompt", "Bonjour")}]}), timeout=90)
    if st >= 400 or not j:
        return R("texte", ok=False, info="HTTP %s" % st, status=st)
    return R("texte", status=st, text=j.get("result", {}).get("response", json.dumps(j)[:1500]), info="llama-3.1-8b (workers AI)")

# ─────────────────────────────────────────────────────────────────────
#  VOIX & AUDIO (4)
# ─────────────────────────────────────────────────────────────────────
srv(id="tts-streamelements", nom="StreamElements · TTS (voix Polly)", cat="VOIX & AUDIO", acces="sans-clé", genre="audio",
    desc="Voix Amazon Polly gratuites (Brian, Amy, Celine, Mathieu…). Vérifié vivant.",
    params=[("texte", "Bonjour, je suis la voix de NEXUS AETHER.", "texte"), ("voix", "Brian", "voix (Brian, Amy, Emma, Celine, Mathieu, Joanna…)")],
    run=aget("https://api.streamelements.com/kappa/v2/speech?voice={voix}&text={texte_quote}"),
    ping=lambda: http_req("https://api.streamelements.com/kappa/v2/speech?voice=Brian&text=ok", headers=STREAM_HDRS, timeout=10)[0])
srv(id="tts-google", nom="Google Translate · TTS", cat="VOIX & AUDIO", acces="sans-clé", genre="audio",
    desc="Synthèse vocale Google (200 caractères max). Vérifié vivant.",
    params=[("texte", "Bienvenue dans NEXUS GEN HUB.", "texte (≤200 car.)"), ("langue", "fr", "langue (fr, en, es…)")],
    run=aget("https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&q={texte_quote}&tl={langue}"),
    ping=lambda: http_req("https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&q=ok&tl=fr", timeout=10)[0])
srv(id="tts-piper", nom="Piper (TTS local)", cat="VOIX & AUDIO", acces="local", genre="audio",
    desc="TTS neuronal local ultra-rapide si installé (sudo apt install piper).",
    params=[("texte", "Test de Piper.", "texte")],
    run=lambda p: _piper_run(p), ping=port_ping(0))


def _piper_run(p):
    if not shutil.which("piper"):
        return R("audio", ok=False, info="piper non installé — sudo apt install piper")
    wav = os.path.join(OUT_DIR, ts_name() + ".wav")
    try:
        r = subprocess.run(["piper", "--output_file", wav], input=p.get("texte", "test").encode(),
                           capture_output=True, timeout=60)
    except Exception as e:
        return R("audio", ok=False, info=str(e))
    if r.returncode != 0 or not os.path.exists(wav):
        return R("audio", ok=False, info="piper a échoué (voix installée ?)")
    return R("audio", path=wav, info="wav local généré")

srv(id="stt-groq", nom="Groq · Whisper (transcription)", cat="VOIX & AUDIO", acces="clé-gratuite", genre="texte",
    desc="Transcrit un fichier audio (wav/mp3) via Whisper sur Groq. NEXUS_GROQ_KEY.",
    params=[("audio", "/chemin/vers/audio.mp3", "chemin du fichier audio")],
    run=lambda p: _groq_stt(p),
    ping=lambda: http_req("https://api.groq.com/openai/v1/models", timeout=10)[0])


def _groq_stt(p):
    key = os.environ.get("NEXUS_GROQ_KEY", "")
    if not key:
        return R("texte", ok=False, info="clé absente — export NEXUS_GROQ_KEY=…")
    f = os.path.expanduser(p.get("audio", ""))
    if not os.path.isfile(f):
        return R("texte", ok=False, info="fichier introuvable : " + f)
    body, hdrs = _mp({"model": "whisper-large-v3", "language": "fr"}, [("file", os.path.basename(f), open(f, "rb").read())])
    st, j, _ = http_json("https://api.groq.com/openai/v1/audio/transcriptions", method="POST",
                         headers=dict(hdrs, Authorization="Bearer " + key), data=body, timeout=120)
    if st >= 400 or not j:
        return R("texte", ok=False, info="HTTP %s" % st, status=st)
    return R("texte", status=st, text=j.get("text", ""))

# ─────────────────────────────────────────────────────────────────────
#  OCR & VISION (2)
# ─────────────────────────────────────────────────────────────────────
srv(id="ocr-space", nom="OCR.space · lecture de texte", cat="OCR & VISION", acces="sans-clé", genre="texte",
    desc="OCR gratuit (clé de test publique « helloworld », 25k/mois). URL d'image en entrée.",
    params=[("url_image", "https://i.imgur.com/…", "URL de l'image"), ("langue", "fre", "langue (fre, eng)")],
    run=lambda p: _ocrspace(p),
    ping=lambda: http_req("https://api.ocr.space/parse/image", method="POST", data={"apikey": "helloworld"}, timeout=12)[0])


def _ocrspace(p):
    st, j, _ = http_json("https://api.ocr.space/parse/image", method="POST",
                         data={"apikey": "helloworld", "url": p.get("url_image", ""), "language": p.get("langue", "fre"), "OCREngine": "2"},
                         timeout=45)
    if st >= 400:
        return R("texte", ok=False, info="HTTP %s" % st, status=st)
    if not j:
        return R("texte", ok=False, info="réponse vide")
    if j.get("IsErroredOnProcessing"):
        return R("texte", ok=False, info="OCR : " + str(j.get("ErrorMessage"))[:150])
    res = (j.get("ParsedResults") or [{}])[0].get("ParsedText", "")
    return R("texte", status=st, text=res or "(aucun texte détecté)")

srv(id="ocr-tesseract", nom="Tesseract (OCR local)", cat="OCR & VISION", acces="local", genre="texte",
    desc="OCR 100% local (sudo apt install tesseract-ocr).",
    params=[("image", "/chemin/image.png", "chemin image"), ("langue", "fra", "langue")],
    run=lambda p: _tess(p), ping=port_ping(0))


def _tess(p):
    if not shutil.which("tesseract"):
        return R("texte", ok=False, info="tesseract non installé — sudo apt install tesseract-ocr")
    img = os.path.expanduser(p.get("image", ""))
    if not os.path.isfile(img):
        return R("texte", ok=False, info="image introuvable : " + img)
    out = os.path.join(OUT_DIR, "ocr-" + ts_name())
    try:
        subprocess.run(["tesseract", img, out, "-l", p.get("langue", "fra")], capture_output=True, timeout=120)
    except Exception as e:
        return R("texte", ok=False, info=str(e))
    if not os.path.exists(out + ".txt"):
        return R("texte", ok=False, info="tesseract n'a pas produit de sortie")
    return R("texte", text=open(out + ".txt", encoding="utf-8", errors="replace").read(), info="OCR local")

# ─────────────────────────────────────────────────────────────────────
#  TRADUCTION (5)
# ─────────────────────────────────────────────────────────────────────
srv(id="tr-google", nom="Google Traduction (endpoint public)", cat="TRADUCTION", acces="sans-clé", genre="texte",
    desc="Le endpoint public de Google Translate, sans clé. Détection auto de langue.",
    params=[("texte", "Hello world, this is NEXUS.", "texte"), ("cible", "fr", "langue cible")],
    run=lambda p: _gtr(p),
    ping=lambda: http_req("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=fr&dt=t&q=hi", timeout=10)[0])


def _gtr(p):
    url = ("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=%s&dt=t&q=%s"
           % (_q(p.get("cible", "fr")), _q(p.get("texte", ""))))
    st, j, _ = http_json(url, timeout=20)
    if st >= 400 or not j:
        return R("texte", ok=False, info="HTTP %s (limite IP datacenter possible — chez toi ça passera)" % st, status=st)
    try:
        txt = "".join(seg[0] for seg in j[0] if seg and seg[0])
    except Exception:
        txt = json.dumps(j, ensure_ascii=False)[:1500]
    return R("texte", status=st, text=txt)

srv(id="tr-lingva", nom="Lingva (miroir open-source)", cat="TRADUCTION", acces="sans-clé", genre="texte",
    desc="Frontend open-source de traduction, sans pub ni clé.",
    params=[("texte", "Hello!", "texte"), ("source", "en", "source"), ("cible", "fr", "cible")],
    run=jget("https://lingva.garudalinux.org/api/v1/{source}/{cible}/{texte_quote}", pick="translation"),
    ping=lambda: http_req("https://lingva.garudalinux.org/api/v1/en/fr/hi", timeout=10)[0])
srv(id="tr-mymemory", nom="MyMemory (mémoires de traduction)", cat="TRADUCTION", acces="sans-clé", genre="texte",
    desc="Mémoires de traduction EU, 5000 caractères/jour sans clé.",
    params=[("texte", "Bonjour le monde.", "texte"), ("paire", "fr|en", "paire (fr|en)")],
    run=jget("https://api.mymemory.translated.net/get?q={texte_quote}&langpair={paire}", pick="responseData.translatedText"),
    ping=lambda: http_req("https://api.mymemory.translated.net/get?q=hi&langpair=en|fr", timeout=10)[0])
srv(id="tr-apertium", nom="Apertium APy (open-source)", cat="TRADUCTION", acces="sans-clé", genre="texte",
    desc="Moteur de traduction libre Apertium (instance publique officielle).",
    params=[("texte", "Hello world", "texte"), ("paire", "en|fr", "paire")],
    run=jget("https://www.apertium.org/apy/translate?q={texte_quote}&langpair={paire}", pick="responseData.translatedText"),
    ping=lambda: http_req("https://www.apertium.org/apy/list?q=pairs", timeout=10)[0])
srv(id="tr-deepl", nom="DeepL API Free", cat="TRADUCTION", acces="clé-gratuite", genre="texte",
    desc="La meilleure traduction. 500k caractères/mois gratuits → NEXUS_DEEPL_KEY.",
    params=[("texte", "Bonjour.", "texte"), ("cible", "EN", "cible (EN, FR, DE…)")],
    run=lambda p: _deepl(p),
    ping=lambda: http_req("https://api-free.deepl.com/v2/usage", timeout=10)[0])


def _deepl(p):
    key = os.environ.get("NEXUS_DEEPL_KEY", "")
    if not key:
        return R("texte", ok=False, info="clé absente — export NEXUS_DEEPL_KEY=… (gratuit deepl.com/pro-api)")
    st, j, _ = http_json("https://api-free.deepl.com/v2/translate", method="POST",
                         headers={"Authorization": "DeepL-Auth-Key " + key, "Content-Type": "application/json"},
                         data=json.dumps({"text": [p.get("texte", "")], "target_lang": p.get("cible", "EN")}), timeout=30)
    if st >= 400 or not j:
        return R("texte", ok=False, info="HTTP %s" % st, status=st)
    return R("texte", status=st, text=(j.get("translations") or [{}])[0].get("text", ""))

# ─────────────────────────────────────────────────────────────────────
#  AVATARS & ILLUSTRATIONS génératives (7)
# ─────────────────────────────────────────────────────────────────────
srv(id="av-dicebear-bottts", nom="DiceBear · Bottts (robots PNG)", cat="AVATARS & ILLUSTRATIONS", acces="sans-clé", genre="image",
    desc="Avatars robots génératifs, 40+ collections disponibles. Vérifié vivant.",
    params=[("graine", "nexus-1", "graine"), ("taille", "256", "taille px")],
    run=imgget("https://api.dicebear.com/9.x/bottts/png?seed={graine}&size={taille}"),
    ping=lambda: http_req("https://api.dicebear.com/9.x/bottts/png?seed=x&size=64", timeout=10)[0])
srv(id="av-dicebear-adventurer", nom="DiceBear · Adventurer", cat="AVATARS & ILLUSTRATIONS", acces="sans-clé", genre="image",
    desc="Avatars personnages illustrés.",
    params=[("graine", "nexus-2", "graine"), ("taille", "256", "taille px")],
    run=imgget("https://api.dicebear.com/9.x/adventurer/png?seed={graine}&size={taille}"),
    ping=lambda: http_req("https://api.dicebear.com/9.x/adventurer/png?seed=x&size=64", timeout=10)[0])
srv(id="av-dicebear-shapes", nom="DiceBear · Shapes (abstrait)", cat="AVATARS & ILLUSTRATIONS", acces="sans-clé", genre="image",
    desc="Compositions abstraites génératives — parfait pour des pochettes.",
    params=[("graine", "nexus-3", "graine"), ("taille", "512", "taille px")],
    run=imgget("https://api.dicebear.com/9.x/shapes/png?seed={graine}&size={taille}"),
    ping=lambda: http_req("https://api.dicebear.com/9.x/shapes/png?seed=x&size=64", timeout=10)[0])
srv(id="av-robohash", nom="Robohash · Robots", cat="AVATARS & ILLUSTRATIONS", acces="sans-clé", genre="image",
    desc="Robots pixel/génératifs depuis n'importe quelle chaîne. Vérifié vivant.",
    params=[("graine", "nexus", "graine"), ("taille", "256x256", "taille WxH")],
    run=imgget("https://robohash.org/{graine}.png?size={taille}&set=set1"),
    ping=lambda: http_req("https://robohash.org/x.png?size=64x64", timeout=10)[0])
srv(id="av-robohash-monsters", nom="Robohash · Monstres", cat="AVATARS & ILLUSTRATIONS", acces="sans-clé", genre="image",
    desc="Variante monstres de Robohash.",
    params=[("graine", "nexus", "graine"), ("taille", "256x256", "taille WxH")],
    run=imgget("https://robohash.org/{graine}.png?size={taille}&set=set2"),
    ping=lambda: http_req("https://robohash.org/x.png?size=64x64&set=set2", timeout=10)[0])
srv(id="av-multavatar", nom="Multavatar", cat="AVATARS & ILLUSTRATIONS", acces="sans-clé", genre="image",
    desc="12 styles d'avatars combinatoires depuis une graine.",
    params=[("graine", "nexus", "graine")],
    run=imgget("https://api.multavatar.com/{graine}.png"),
    ping=lambda: http_req("https://api.multavatar.com/x.png", timeout=10)[0])
srv(id="av-boringavatars", nom="Boring Avatars (Beam)", cat="AVATARS & ILLUSTRATIONS", acces="sans-clé", genre="image",
    desc="Avatars géométriques élégants style Beam (SVG).",
    params=[("graine", "nexus", "graine")],
    run=imgget("https://source.boringavatars.com/beam/256/{graine}?colors=00E5FF,FF00C8,00FF88", ext="svg"),
    ping=lambda: http_req("https://source.boringavatars.com/beam/64/x", timeout=10)[0])
NS2
ok "nexus_services.py — LLM (23), voix, OCR, traduction, avatars"
