
# ════════════════════════════════════════════════════════════════════
#  PARTIE D — nexus_services.py (4/4) : connaissance, musique, outils…
# ════════════════════════════════════════════════════════════════════

cat >> "$APP_DIR/nexus_services.py" <<'NS4'

# ─────────────────────────────────────────────────────────────────────
#  CONNAISSANCE & SCIENCE (12)
# ─────────────────────────────────────────────────────────────────────
srv(id="kn-wiki-search", nom="Wikipédia · recherche", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="Recherche plein texte Wikipédia FR.",
    params=[("q", "intelligence artificielle", "recherche"), ("limite", "5", "résultats")],
    run=jget("https://fr.wikipedia.org/w/api.php?action=query&list=search&srsearch={q_quote}&srlimit={limite}&format=json"),
    ping=lambda: http_req("https://fr.wikipedia.org/w/api.php?action=query&list=search&srsearch=test&srlimit=1&format=json", timeout=12)[0])
srv(id="kn-wiki-summary", nom="Wikipédia · résumé REST", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="Résumé propre d'une page (REST v1).",
    params=[("page", "France", "titre de page")],
    run=jget("https://fr.wikipedia.org/api/rest_v1/page/summary/{page_quote}"),
    ping=lambda: http_req("https://fr.wikipedia.org/api/rest_v1/page/summary/France", timeout=12)[0])
srv(id="kn-ddg", nom="DuckDuckGo · Instant Answers", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="Réponses instantanées DuckDuckGo, sans clé.",
    params=[("q", "github", "question")],
    run=jget("https://api.duckduckgo.com/?q={q_quote}&format=json&no_html=1"),
    ping=lambda: http_req("https://api.duckduckgo.com/?q=test&format=json", timeout=12)[0])
srv(id="kn-openalex", nom="OpenAlex · 250M travaux scientifiques", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="Le catalogue scientifique ouvert (successeur de Microsoft Academic).",
    params=[("q", "fusion nucléaire", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://api.openalex.org/works?search={q_quote}&per-page={limite}&mailto=nexus@local"),
    ping=lambda: http_req("https://api.openalex.org/works?search=test&per-page=1", timeout=12)[0])
srv(id="kn-crossref", nom="Crossref · 150M DOI", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="Métadonnées de publications académiques. Vérifié vivant.",
    params=[("q", "quantum", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://api.crossref.org/works?query={q_quote}&rows={limite}"),
    ping=lambda: http_req("https://api.crossref.org/works?query=test&rows=1", timeout=12)[0])
srv(id="kn-arxiv", nom="arXiv · preprints", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="texte",
    desc="Papiers scientifiques bruts (XML Atom).",
    params=[("q", "all:electron", "recherche"), ("limite", "3", "résultats")],
    run=tget("http://export.arxiv.org/api/query?search_query=all:{q_quote}&max_results={limite}"),
    ping=lambda: http_req("http://export.arxiv.org/api/query?search_query=all:test&max_results=1", timeout=15)[0])
srv(id="kn-semantic", nom="Semantic Scholar", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="200M+ papiers avec citations (limite anonyme).",
    params=[("q", "transformer model", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://api.semanticscholar.org/graph/v1/paper/search?query={q_quote}&limit={limite}&fields=title,year,authors,citationCount"),
    ping=lambda: http_req("https://api.semanticscholar.org/graph/v1/paper/search?query=test&limit=1", timeout=12)[0])
srv(id="kn-pubmed", nom="PubMed · médecine", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="35M références biomédicales. Vérifié vivant.",
    params=[("q", "crispr", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term={q_quote}&retmax={limite}&retmode=json"),
    ping=lambda: http_req("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=test&retmode=json", timeout=12)[0])
srv(id="kn-europepmc", nom="Europe PMC · biomedical open", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="Texte intégral de publications biosciences.",
    params=[("q", "protein folding", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://www.ebi.ac.uk/europepmc/webservices/rest/search?query={q_quote}&format=json&pageSize={limite}"),
    ping=lambda: http_req("https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=test&format=json&pageSize=1", timeout=12)[0])
srv(id="kn-openlibrary", nom="Open Library · livres", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="20M+ livres (Internet Archive).",
    params=[("q", "dune", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://openlibrary.org/search.json?q={q_quote}&limit={limite}"),
    ping=lambda: http_req("https://openlibrary.org/search.json?q=dune&limit=1", timeout=15)[0])
srv(id="kn-gbooks", nom="Google Books", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="40M+ livres numérisés.",
    params=[("q", "verne", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://www.googleapis.com/books/v1/volumes?q={q_quote}&maxResults={limite}"),
    ping=lambda: http_req("https://www.googleapis.com/books/v1/volumes?q=test", timeout=12)[0])
srv(id="kn-archive", nom="Internet Archive", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="Tout le fonds d'archive.org (vidéo, audio, textes).",
    params=[("q", "moon landing", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://archive.org/advancedsearch.php?q={q_quote}&rows={limite}&output=json"),
    ping=lambda: http_req("https://archive.org/advancedsearch.php?q=test&rows=1&output=json", timeout=15)[0])

# ─────────────────────────────────────────────────────────────────────
#  DÉV & PAQUETS (10)
# ─────────────────────────────────────────────────────────────────────
srv(id="dv-github", nom="GitHub · recherche repos", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="API GitHub anonyme (60 req/h). Chez toi : OK.",
    params=[("q", "libp2p", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://api.github.com/search/repositories?q={q_quote}&per_page={limite}"),
    ping=lambda: http_req("https://api.github.com/rate_limit", timeout=10)[0])
srv(id="dv-npm", nom="npm registry", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Métadonnées de tout package npm. Vérifié vivant.",
    params=[("paquet", "react", "nom du package")],
    run=jget("https://registry.npmjs.org/{paquet}"),
    ping=lambda: http_req("https://registry.npmjs.org/react", timeout=12)[0])
srv(id="dv-pypi", nom="PyPI", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Packages Python. Vérifié vivant.",
    params=[("paquet", "requests", "nom du package")],
    run=jget("https://pypi.org/pypi/{paquet}/json"),
    ping=lambda: http_req("https://pypi.org/pypi/requests/json", timeout=12)[0])
srv(id="dv-crates", nom="crates.io · Rust", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Écosystème Rust. Vérifié vivant.",
    params=[("paquet", "tokio", "nom du crate")],
    run=jget("https://crates.io/api/v1/crates/{paquet}"),
    ping=lambda: http_req("https://crates.io/api/v1/crates/serde", timeout=12)[0])
srv(id="dv-maven", nom="Maven Central · Java", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Recherche de jars. Vérifié vivant.",
    params=[("q", "guice", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://search.maven.org/solrsearch/select?q={q_quote}&rows={limite}&wt=json"),
    ping=lambda: http_req("https://search.maven.org/solrsearch/select?q=guice&rows=1&wt=json", timeout=12)[0])
srv(id="dv-packagist", nom="Packagist · PHP", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="L'écosystème Composer.",
    params=[("paquet", "symfony/console", "vendor/package")],
    run=jget("https://repo.packagist.org/p2/{paquet}.json"),
    ping=lambda: http_req("https://repo.packagist.org/p2/symfony/console.json", timeout=12)[0])
srv(id="dv-rubygems", nom="RubyGems", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Gems Ruby. Vérifié vivant.",
    params=[("paquet", "rails", "nom de la gem")],
    run=jget("https://rubygems.org/api/v1/gems/{paquet}.json"),
    ping=lambda: http_req("https://rubygems.org/api/v1/gems/rails.json", timeout=12)[0])
srv(id="dv-nuget", nom="NuGet · .NET", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Recherche de packages C#. Vérifié vivant.",
    params=[("q", "newtonsoft", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://azuresearch-usnc.nuget.org/query?q={q_quote}&take={limite}"),
    ping=lambda: http_req("https://azuresearch-usnc.nuget.org/query?q=x&take=1", timeout=12)[0])
srv(id="dv-dockerhub", nom="Docker Hub", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Stats et tags d'images officielles. Vérifié vivant.",
    params=[("image", "alpine", "image library/")],
    run=jget("https://hub.docker.com/v2/repositories/library/{image}/"),
    ping=lambda: http_req("https://hub.docker.com/v2/repositories/library/alpine/", timeout=12)[0])
srv(id="dv-jsdelivr", nom="jsDelivr · packages CDN", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Versions et fichiers CDN d'un package. Vérifié vivant.",
    params=[("paquet", "react", "package npm")],
    run=jget("https://data.jsdelivr.com/v1/packages/npm/{paquet}"),
    ping=lambda: http_req("https://data.jsdelivr.com/v1/packages/npm/react", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  MUSIQUE (6)
# ─────────────────────────────────────────────────────────────────────
srv(id="mu-itunes", nom="iTunes Search", cat="MUSIQUE", acces="sans-clé", genre="json",
    desc="Musique, films, podcasts + extraits 30s jouables. Vérifié vivant.",
    params=[("q", "daft punk", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://itunes.apple.com/search?term={q_quote}&limit={limite}"),
    ping=lambda: http_req("https://itunes.apple.com/search?term=test&limit=1", timeout=12)[0])
srv(id="mu-musicbrainz", nom="MusicBrainz", cat="MUSIQUE", acces="sans-clé", genre="json",
    desc="L'encyclopédie musicale ouverte (Whosampled, Spotify l'utilisent).",
    params=[("q", "one more time", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://musicbrainz.org/ws/2/recording/?query={q_quote}&fmt=json&limit={limite}"),
    ping=lambda: http_req("https://musicbrainz.org/ws/2/recording/?query=test&fmt=json&limit=1", timeout=12)[0])
srv(id="mu-deezer", nom="Deezer", cat="MUSIQUE", acces="sans-clé", genre="json",
    desc="Recherche + extraits 30s (API publique Deezer).",
    params=[("q", "harder better", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://api.deezer.com/search?q={q_quote}&limit={limite}"),
    ping=lambda: http_req("https://api.deezer.com/search?q=test&limit=1", timeout=12)[0])
srv(id="mu-radio", nom="Radio Browser", cat="MUSIQUE", acces="sans-clé", genre="json",
    desc="50 000 radios du monde entier. Vérifié vivant.",
    params=[("q", "jazz", "nom de station"), ("limite", "5", "résultats")],
    run=jget("https://de1.api.radio-browser.info/json/stations/search?name={q_quote}&limit={limite}"),
    ping=lambda: http_req("https://de1.api.radio-browser.info/json/stations/search?name=jazz&limit=1", timeout=12)[0])
srv(id="mu-lrclib", nom="LRCLIB · paroles synchronisées", cat="MUSIQUE", acces="sans-clé", genre="json",
    desc="Paroles + LRC synchronisé, open-source. Vérifié vivant.",
    params=[("q", "creep radiohead", "recherche")],
    run=jget("https://lrclib.net/api/search?q={q_quote}&limit=3"),
    ping=lambda: http_req("https://lrclib.net/api/search?q=test&limit=1", timeout=12)[0])
srv(id="mu-coverart", nom="Cover Art Archive", cat="MUSIQUE", acces="sans-clé", genre="json",
    desc="Pochettes d'albums liées à MusicBrainz (paramètre = un MBID).",
    params=[("mbid", "9d7ec4fc-e542-4d1e-b0a5-2b2f4e5a4f5a", "MusicBrainz ID de release-group")],
    run=jget("https://coverartarchive.org/release-group/{mbid}"),
    ping=lambda: http_req("https://coverartarchive.org/", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  CONTENU & FUN (10)
# ─────────────────────────────────────────────────────────────────────
srv(id="fn-jokeapi", nom="JokeAPI v2", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Blagues en EN/FR filtrables (safe-mode inclus).",
    params=[("langue", "fr", "langue (fr, en)")],
    run=jget("https://v2.jokeapi.dev/joke/Any?safe-mode&lang={langue}"),
    ping=lambda: http_req("https://v2.jokeapi.dev/joke/Any?safe-mode", timeout=12)[0])
srv(id="fn-dadjoke", nom="icanhazdadjoke", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="La référence mondiale des blagues de papa.",
    params=[], run=jget("https://icanhazdadjoke.com/", headers={"Accept": "application/json"}),
    ping=lambda: http_req("https://icanhazdadjoke.com/", headers={"Accept": "application/json"}, timeout=12)[0])
srv(id="fn-chuck", nom="Chuck Norris API", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Fact aléatoire. Vérifié vivant.",
    params=[], run=jget("https://api.chucknorris.io/jokes/random"),
    ping=lambda: http_req("https://api.chucknorris.io/jokes/random", timeout=12)[0])
srv(id="fn-zenquotes", nom="ZenQuotes", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Citation inspirante du jour.",
    params=[], run=jget("https://zenquotes.io/api/random"),
    ping=lambda: http_req("https://zenquotes.io/api/random", timeout=12)[0])
srv(id="fn-quotable", nom="Quotable", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Citations filtrables par auteur/tags.",
    params=[("auteur", "einstein", "auteur (slug)")],
    run=jget("https://api.quotable.io/random?author={auteur}"),
    ping=lambda: http_req("https://api.quotable.io/random", timeout=12)[0])
srv(id="fn-advice", nom="Advice Slip", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Un conseil aléatoire (ou par id).",
    params=[], run=jget("https://api.adviceslip.com/advice"),
    ping=lambda: http_req("https://api.adviceslip.com/advice", timeout=12)[0])
srv(id="fn-catfacts", nom="Cat Facts", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Facts sur les chats, pour les démos qui marquent.",
    params=[], run=jget("https://catfact.ninja/fact"),
    ping=lambda: http_req("https://catfact.ninja/fact", timeout=12)[0])
srv(id="fn-dogceo", nom="Dog CEO · photos de chiens", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Photos de chiens aléatoires (image + URL).",
    params=[], run=jget("https://dog.ceo/api/breeds/image/random"),
    ping=lambda: http_req("https://dog.ceo/api/breeds/image/random", timeout=12)[0])
srv(id="fn-randomuser", nom="RandomUser · identités factices", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Profils factices complets (tests, seed data). Vérifié vivant.",
    params=[("nombre", "3", "nombre de profils")],
    run=jget("https://randomuser.me/api/?results={nombre}"),
    ping=lambda: http_req("https://randomuser.me/api/", timeout=12)[0])
srv(id="fn-dummyjson", nom="DummyJSON · données factices", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Produits, paniers, utilisateurs, quotes… pour maquettes. Vérifié vivant.",
    params=[("ressource", "products/1", "ressource (products, users, carts…)")],
    run=jget("https://dummyjson.com/{ressource}"),
    ping=lambda: http_req("https://dummyjson.com/products/1", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  DÉMOGRAPHIE (4)
# ─────────────────────────────────────────────────────────────────────
srv(id="nm-genderize", nom="Genderize · genre d'un prénom", cat="DÉMOGRAPHIE", acces="sans-clé", genre="json",
    desc="Probabilité de genre par prénom. Vérifié vivant.",
    params=[("prenom", "camille", "prénom")],
    run=jget("https://api.genderize.io?name={prenom}"),
    ping=lambda: http_req("https://api.genderize.io?name=alex", timeout=12)[0])
srv(id="nm-agify", nom="Agify · âge estimé", cat="DÉMOGRAPHIE", acces="sans-clé", genre="json",
    desc="Âge moyen estimé d'un prénom.",
    params=[("prenom", "emma", "prénom")],
    run=jget("https://api.agify.io?name={prenom}"),
    ping=lambda: http_req("https://api.agify.io?name=alex", timeout=12)[0])
srv(id="nm-nationalize", nom="Nationalize · nationalité estimée", cat="DÉMOGRAPHIE", acces="sans-clé", genre="json",
    desc="Probabilités de nationalité d'un prénom.",
    params=[("prenom", "lucas", "prénom")],
    run=jget("https://api.nationalize.io?name={prenom}"),
    ping=lambda: http_req("https://api.nationalize.io?name=alex", timeout=12)[0])
srv(id="nm-universities", nom="Universités du monde", cat="DÉMOGRAPHIE", acces="sans-clé", genre="json",
    desc="Base mondiale des universités (Hipolabs).",
    params=[("nom", "lyon", "nom (partiel)")],
    run=jget("http://universities.hipolabs.com/search?name={nom}"),
    ping=lambda: http_req("http://universities.hipolabs.com/search?name=paris", timeout=15)[0])

# ─────────────────────────────────────────────────────────────────────
#  COULEURS IA (2)
# ─────────────────────────────────────────────────────────────────────
def _colormind(p):
    model = p.get("modele", "default")
    st, j, _ = http_json("https://colormind.io/api/", method="POST",
                         headers={"Content-Type": "application/json"},
                         data=json.dumps({"model": model, "input": []}), timeout=25)
    if st >= 400 or not j or "result" not in j:
        return R("json", ok=False, info="HTTP %s" % st, status=st)
    lines = ["#%02X%02X%02X" % tuple(c) for c in j["result"]]
    return R("json", status=st, text="Palette IA (%s) :\n%s" % (model, "\n".join(lines)), info="colormind.io")

srv(id="cl-colormind", nom="Colormind · palettes par IA", cat="COULEURS IA", acces="sans-clé", genre="json",
    desc="Réseau neuronal qui invente des palettes harmonieuses.",
    params=[("modele", "default", "modèle (default, n, n_e, ui)")],
    run=_colormind,
    ping=lambda: http_req("https://colormind.io/list", timeout=12)[0])
srv(id="cl-thecolorapi", nom="The Color API · info couleur", cat="COULEURS IA", acces="sans-clé", genre="json",
    desc="Nom, conversion, schéma harmonique d'une couleur. Vérifié vivant.",
    params=[("hex", "00E5FF", "hex sans #")],
    run=jget("https://www.thecolorapi.com/id?hex={hex}"),
    ping=lambda: http_req("https://www.thecolorapi.com/id?hex=00E5FF", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  OUTILS WEB & PARTAGE (6)
# ─────────────────────────────────────────────────────────────────────
srv(id="ow-thumio", nom="thum.io · capture de site", cat="OUTILS WEB & PARTAGE", acces="sans-clé", genre="image",
    desc="Screenshot de n'importe quelle URL, gratuit, sans clé.",
    params=[("url", "https://github.com", "URL du site"), ("largeur", "1024", "largeur")],
    run=imgget("https://image.thum.io/get/width/{largeur}/{url}", timeout=45),
    ping=lambda: http_req("https://image.thum.io/get/width/300/https://example.com", timeout=20)[0])
srv(id="ow-mshots", nom="WordPress mShots · capture", cat="OUTILS WEB & PARTAGE", acces="sans-clé", genre="image",
    desc="Seconde source de screenshots (infrastructure WordPress.com).",
    params=[("url", "https://example.com", "URL encodée"), ("largeur", "600", "largeur")],
    run=imgget("https://s0.wp.com/mshots/v1/{url_quote}?w={largeur}", timeout=45),
    ping=lambda: http_req("https://s0.wp.com/mshots/v1/https%3A%2F%2Fexample.com?w=100", timeout=20)[0])
srv(id="ow-0x0", nom="0x0.st · hébergement de fichiers", cat="OUTILS WEB & PARTAGE", acces="sans-clé", genre="texte",
    desc="Upload anonyme (jusqu'à 512 Mo) → URL publique. Respecte leurs règles.",
    params=[("texte", "Contenu à héberger depuis NEXUS GEN HUB", "contenu texte")],
    run=lambda p: _upload_0x0(p),
    ping=lambda: http_req("https://0x0.st/", timeout=12)[0])


def _upload_0x0(p):
    body, hdrs = _mp({}, [("file", ts_name() + ".txt", p.get("texte", "").encode("utf-8"))])
    st, b, _ = http_req("https://0x0.st", method="POST", headers=hdrs, data=body, timeout=40)
    if st >= 400:
        return R("texte", ok=False, info="HTTP %s (0x0.st bloque parfois les datacenters — chez toi OK)" % st, status=st)
    return R("texte", status=st, text=b.decode("utf-8", "replace").strip(), info="URL publique 0x0.st")

srv(id="ow-tmpfiles", nom="tmpfiles.org · partage temporaire", cat="OUTILS WEB & PARTAGE", acces="sans-clé", genre="json",
    desc="Fichier en ligne 60 min → lien direct /dl/.",
    params=[("texte", "{\"nexus\": \"genhub\", \"v\": 2}", "contenu JSON/texte")],
    run=lambda p: _upload_tmpfiles(p),
    ping=lambda: http_req("https://tmpfiles.org/", timeout=12)[0])


def _upload_tmpfiles(p):
    body, hdrs = _mp({}, [("file", ts_name() + ".json", p.get("texte", "").encode("utf-8"))])
    st, j, _ = http_json("https://tmpfiles.org/api/v1/upload", method="POST", headers=hdrs, data=body, timeout=40)
    if st >= 400 or not j or not j.get("data"):
        return R("json", ok=False, info="HTTP %s" % st, status=st)
    url = j["data"].get("url", "").replace("tmpfiles.org/", "tmpfiles.org/dl/")
    return R("json", status=st, text="Lien direct (60 min) : " + url)

srv(id="ow-dpaste", nom="dpaste.org · pastebin", cat="OUTILS WEB & PARTAGE", acces="sans-clé", genre="texte",
    desc="Colle du code en ligne, expiration réglable.",
    params=[("contenu", "print('hello from NEXUS GEN HUB')", "contenu"), ("jours", "7", "expiration (jours)")],
    run=lambda p: _dpaste(p),
    ping=lambda: http_req("https://dpaste.org/api/", method="POST", data={"raw": "test", "format": "url", "expiry_days": 1}, timeout=15)[0])


def _dpaste(p):
    st, b, u = http_req("https://dpaste.org/api/", method="POST",
                        data={"raw": p.get("contenu", ""), "format": "url", "expiry_days": p.get("jours", "7")}, timeout=30)
    if st >= 400:
        return R("texte", ok=False, info="HTTP %s" % st, status=st)
    return R("texte", status=st, text=(b.decode("utf-8", "replace").strip() or u).strip(), info="lien dpaste.org")

srv(id="ow-fileio", nom="file.io · lien éphémère", cat="OUTILS WEB & PARTAGE", acces="sans-clé", genre="json",
    desc="Lien qui s'auto-détruit après 1 téléchargement (privacy maximale).",
    params=[("texte", "Secret NEXUS — à lire une seule fois", "contenu")],
    run=lambda p: _fileio(p),
    ping=lambda: http_req("https://file.io/", timeout=12)[0])


def _fileio(p):
    body, hdrs = _mp({}, [("file", ts_name() + ".txt", p.get("texte", "").encode("utf-8"))])
    st, j, _ = http_json("https://file.io/?expires=1w", method="POST", headers=hdrs, data=body, timeout=40)
    if st >= 400 or not j or not j.get("link"):
        return R("json", ok=False, info="HTTP %s" % st, status=st)
    return R("json", status=st, text="Lien éphémère : " + j["link"])

# ─────────────────────────────────────────────────────────────────────
#  Plugins (extensions .py dans ~/.nexus-hub/plugins/)
# ─────────────────────────────────────────────────────────────────────
def load_plugins():
    d = os.path.join(HUB_DIR, "plugins")
    if not os.path.isdir(d):
        return []
    loaded = []
    for f in sorted(glob.glob(os.path.join(d, "*.py"))):
        try:
            ns = {"srv": srv, "SERVICES": SERVICES, "http_req": http_req, "http_json": http_json,
                  "imgget": imgget, "jget": jget, "tget": tget, "aget": aget, "R": R,
                  "save_out": save_out, "_q": _q, "_mp": _mp, "_fmt": _fmt,
                  "local_openai": local_openai, "port_ping": port_ping,
                  "__name__": "nexus_plugin_" + os.path.basename(f)[:-3]}
            exec(compile(open(f, encoding="utf-8").read(), f, "exec"), ns)
            loaded.append(os.path.basename(f))
        except Exception as e:
            print("[plugin] %s ignoré : %s" % (os.path.basename(f), e))
    return loaded

load_plugins()
N_SERVICES = len(SERVICES)
if N_SERVICES < 90:
    raise RuntimeError("Catalogue incomplet : %d services (≥90 requis)" % N_SERVICES)

# ─────────────────────────────────────────────────────────────────────
#  Batterie de test réelle
# ─────────────────────────────────────────────────────────────────────
def classify(st, url=""):
    if st == 0:
        return "réseau"
    if st in (200, 201, 202, 204, 206, 301, 302, 303):
        return "✓"
    if st == 405:
        return "✓ POST"
    if st in (401, 402, 403):
        return "clé"
    if st == 429:
        return "limite"
    if st == 404:
        return "✗ 404"
    return "HS %s" % st


def battery(services=None, workers=12, timeout=10, progress=None):
    svcs = list(services or SERVICES)
    results = []
    lock = threading.Lock()
    done = [0]
    total = len(svcs)

    def one(s):
        t0 = time.time()
        st = 0
        try:
            pf = s.get("ping")
            if callable(pf):
                st = pf()
            elif pf:
                try:
                    st, _, _ = http_req(_fmt(pf, {k: v for k, v, _ in s.get("params", [])}), timeout=timeout)
                except Exception:
                    st = 0
        except Exception:
            st = 0
        ms = int((time.time() - t0) * 1000)
        if s.get("acces") == "local":
            etat = "✓ local" if st == 200 else "éteint"
        else:
            etat = classify(st)
        item = {"id": s["id"], "nom": s["nom"], "cat": s["cat"], "acces": s["acces"], "etat": etat, "ms": ms}
        with lock:
            done[0] += 1
            if progress:
                try:
                    progress(done[0], total, item)
                except Exception:
                    pass
        return item

    with ThreadPoolExecutor(max_workers=workers) as ex:
        results = list(ex.map(one, svcs))
    return results


def battery_summary(results):
    from collections import Counter
    c = Counter(r["etat"] for r in results)
    return dict(c)


if __name__ == "__main__":
    import sys
    print("NEXUS GEN HUB — %d services réels chargés" % N_SERVICES)
    from collections import Counter
    c = Counter(s["acces"] for s in SERVICES)
    print("Répartition :", dict(c))
    if "--battery" in sys.argv:
        n = int(sys.argv[sys.argv.index("--battery") + 1]) if "--battery" in sys.argv and len(sys.argv) > sys.argv.index("--battery") + 1 else 12
        res = battery(SERVICES[:n] if n else None)
        print("\n%-26s %-34s %-12s %s" % ("ID", "SERVICE", "ACCÈS", "ÉTAT"))
        for r in res:
            print("%-26s %-34s %-12s %s (%d ms)" % (r["id"], r["nom"][:32], r["acces"], r["etat"], r["ms"]))
        print("\nSynthèse :", battery_summary(res))
NS4
ok "nexus_services.py — connaissance, dév, musique, fun, outils + batterie + plugins"
