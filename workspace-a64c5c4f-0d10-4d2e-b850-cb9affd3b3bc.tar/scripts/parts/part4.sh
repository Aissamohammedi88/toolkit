
cat > ui/nebula.js <<'AE_NEB'
(function () {
  'use strict';
  // NEXUS AETHER — nébuleuse vivante : shader WebGL (fbm + warp de domaine),
  // réagit à l'activité système (u_act) et à la souris. Repli 2D si pas de WebGL.
  const canvas = document.getElementById('nebula');
  if (!canvas) return;
  window.__aetherActivity = 0.2;

  let gl = null;
  try { gl = canvas.getContext('webgl', { antialias: false, alpha: false, depth: false }); } catch (e) { gl = null; }
  if (gl) initWebGL(gl); else init2d();

  function initWebGL(gl) {
    const VS = 'attribute vec2 p;void main(){gl_Position=vec4(p,0.0,1.0);}';
    const FS = [
      'precision highp float;',
      'uniform vec2 u_res;',
      'uniform float u_time;',
      'uniform float u_act;',
      'uniform vec2 u_mouse;',
      'float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453123);}',
      'float noise(vec2 p){vec2 i=floor(p);vec2 f=fract(p);vec2 u=f*f*(3.0-2.0*f);',
      '  return mix(mix(hash(i),hash(i+vec2(1.0,0.0)),u.x),mix(hash(i+vec2(0.0,1.0)),hash(i+vec2(1.0,1.0)),u.x),u.y);}',
      'float fbm(vec2 p){float v=0.0;float a=0.5;for(int k=0;k<5;k++){v+=a*noise(p);p=p*2.03+vec2(1.7,9.2);a*=0.5;}return v;}',
      'void main(){',
      '  vec2 uv=(gl_FragCoord.xy*2.0-u_res)/min(u_res.x,u_res.y);',
      '  float t=u_time*(0.04+u_act*0.10);',
      '  vec2 m=u_mouse*0.3;',
      '  vec2 q=vec2(fbm(uv*1.3+t),fbm(uv*1.3-t*0.7+5.2));',
      '  vec2 r=vec2(fbm(uv*1.7+q*1.8+m+vec2(1.7,9.2)+t*0.4),fbm(uv*1.7+q*1.8+vec2(8.3,2.8)-t*0.3));',
      '  float f=fbm(uv*2.1+r*1.6);',
      '  vec3 deep=vec3(0.016,0.02,0.075);',
      '  vec3 violet=vec3(0.16,0.05,0.32);',
      '  vec3 cyan=vec3(0.0,0.9,1.0);',
      '  vec3 magenta=vec3(1.0,0.0,0.78);',
      '  vec3 col=deep;',
      '  col=mix(col,violet,clamp(f*f*1.9,0.0,1.0));',
      '  col=mix(col,cyan*0.5,clamp(pow(max(r.x,0.0),3.0)*(0.35+u_act*0.6),0.0,0.6));',
      '  col=mix(col,magenta*0.45,clamp(pow(max(r.y,0.0),4.0)*0.9,0.0,0.5));',
      '  col+=cyan*pow(clamp(f-0.70,0.0,1.0)*2.4,2.0)*(0.35+u_act*0.5);',
      '  float vig=smoothstep(1.9,0.3,length(uv));',
      '  col*=mix(0.5,1.0,vig);',
      '  gl_FragColor=vec4(col,1.0);',
      '}'
    ].join('\n');
    function sh(type, src) {
      const s = gl.createShader(type);
      gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) || 'shader');
      return s;
    }
    let prog;
    try {
      prog = gl.createProgram();
      gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS));
      gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FS));
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error('link');
    } catch (e) { init2d(); return; }
    gl.useProgram(prog);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, 'p');
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    const uRes = gl.getUniformLocation(prog, 'u_res');
    const uTime = gl.getUniformLocation(prog, 'u_time');
    const uAct = gl.getUniformLocation(prog, 'u_act');
    const uMouse = gl.getUniformLocation(prog, 'u_mouse');
    let mx = 0, my = 0;
    window.addEventListener('mousemove', function (e) {
      mx = (e.clientX / window.innerWidth - 0.5) * 2;
      my = (e.clientY / window.innerHeight - 0.5) * 2;
    });
    function resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = Math.max(1, Math.floor(window.innerWidth * dpr));
      canvas.height = Math.max(1, Math.floor(window.innerHeight * dpr));
      gl.viewport(0, 0, canvas.width, canvas.height);
    }
    resize();
    window.addEventListener('resize', resize);
    const t0 = Date.now();
    (function frame() {
      gl.uniform2f(uRes, canvas.width, canvas.height);
      gl.uniform1f(uTime, (Date.now() - t0) / 1000);
      gl.uniform1f(uAct, window.__aetherActivity || 0.2);
      gl.uniform2f(uMouse, mx, my);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      requestAnimationFrame(frame);
    })();
  }

  function init2d() {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const blobs = [
      { c: 'rgba(0,229,255,0.20)', r: 0.5, x: 0.3, y: 0.35, dx: 0.00007, dy: 0.00005 },
      { c: 'rgba(255,0,200,0.16)', r: 0.45, x: 0.7, y: 0.5, dx: -0.00006, dy: 0.00007 },
      { c: 'rgba(90,60,255,0.18)', r: 0.6, x: 0.5, y: 0.75, dx: 0.00005, dy: -0.00006 }
    ];
    function resize() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
    resize();
    window.addEventListener('resize', resize);
    (function frame() {
      ctx.fillStyle = '#050510';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      blobs.forEach(function (b) {
        b.x += b.dx; b.y += b.dy;
        if (b.x < 0.1 || b.x > 0.9) b.dx *= -1;
        if (b.y < 0.1 || b.y > 0.9) b.dy *= -1;
        const rr = b.r * Math.min(canvas.width, canvas.height);
        const g = ctx.createRadialGradient(b.x * canvas.width, b.y * canvas.height, 0, b.x * canvas.width, b.y * canvas.height, rr);
        g.addColorStop(0, b.c);
        g.addColorStop(1, 'rgba(5,5,16,0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      });
      requestAnimationFrame(frame);
    })();
  }
})();
AE_NEB
ok "ui/nebula.js — shader WebGL fbm, réagit CPU + souris (repli 2D automatique)"

cat > ui/terminal.js <<'AE_TERM'
(function () {
  'use strict';
  // NEXUS AETHER — vrai terminal : xterm.js ⇄ WebSocket ⇄ pty réel côté serveur.
  window.AetherTerm = { ready: false, ws: null, term: null, fit: null, run: function () {} };
  const el = document.getElementById('term');
  if (!el) return;
  if (!window.Terminal) {
    el.innerHTML = '<p class="term-miss">xterm.js non chargé — relance « npm install » dans le dossier de l\u2019app.</p>';
    return;
  }
  const term = new window.Terminal({
    fontFamily: "'JetBrains Mono','Fira Code','DejaVu Sans Mono',monospace",
    fontSize: 13,
    lineHeight: 1.15,
    cursorBlink: true,
    allowTransparency: true,
    scrollback: 5000,
    theme: {
      background: 'rgba(4,4,12,0.35)',
      foreground: '#E8ECFF',
      cursor: '#00E5FF',
      cursorAccent: '#050510',
      selectionBackground: 'rgba(0,229,255,0.28)',
      black: '#101020', red: '#FF5C7A', green: '#00FF88', yellow: '#FFD166',
      blue: '#4DA6FF', magenta: '#FF00C8', cyan: '#00E5FF', white: '#E8ECFF'
    }
  });
  const fit = new window.FitAddon.FitAddon();
  term.loadAddon(fit);
  term.open(el);
  try { fit.fit(); } catch (e) {}

  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const ws = new WebSocket(proto + '://' + location.host + '/terminal?cols=' + term.cols + '&rows=' + term.rows);
  ws.onopen = function () { window.AetherTerm.ready = true; term.focus(); };
  ws.onmessage = function (ev) { term.write(ev.data); };
  ws.onclose = function () {
    window.AetherTerm.ready = false;
    term.write('\r\n\x1b[38;5;245m[session terminal fermée — relance l\u2019app]\x1b[0m\r\n');
  };
  ws.onerror = function () {};
  term.onData(function (d) { if (ws.readyState === 1) ws.send(d); });
  term.onResize(function (sz) { if (ws.readyState === 1) ws.send(JSON.stringify({ resize: [sz.cols, sz.rows] })); });
  window.addEventListener('resize', function () { try { fit.fit(); } catch (e) {} });
  window.addEventListener('tab-shown-term', function () {
    setTimeout(function () { try { fit.fit(); term.focus(); } catch (e) {} }, 30);
  });

  window.AetherTerm.term = term;
  window.AetherTerm.fit = fit;
  window.AetherTerm.ws = ws;
  window.AetherTerm.run = function (cmd) { if (ws.readyState === 1) ws.send(cmd + '\n'); };
})();
AE_TERM
ok "ui/terminal.js — xterm.js branché au pty réel via WebSocket"

cat > ui/app.js <<'AE_APP'
(function () {
  'use strict';
  // NEXUS AETHER — orchestration : orbe, onglets, métriques, graphe,
  // éditeur, agents, mémoire vivante, Grid, Deep Work.
  const $ = function (id) { return document.getElementById(id); };
  const desk = window.aether || null;

  /* ── Fenêtre (Electron) ──*/
  $('btn-min').addEventListener('click', function () { if (desk) desk.minimize(); });
  $('btn-max').addEventListener('click', function () { if (desk) desk.maximize(); });
  $('btn-close').addEventListener('click', function () { if (desk) desk.close(); });

  /* ── Onglets ──*/
  const TABS = ['code', 'term', 'grid', 'memory'];
  const tabBtns = Array.prototype.slice.call(document.querySelectorAll('#tabs .tab'));
  tabBtns.forEach(function (b) { b.addEventListener('click', function () { switchTab(b.dataset.tab); }); });
  function switchTab(name) {
    tabBtns.forEach(function (b) { b.classList.toggle('active', b.dataset.tab === name); });
    TABS.forEach(function (t) { const el = $('panel-' + t); if (el) el.classList.toggle('hidden', t !== name); });
    if (name === 'term') window.dispatchEvent(new Event('tab-shown-term'));
    if (name === 'memory') loadMemory();
    if (name === 'grid') loadGrid();
  }

  /* ── Métriques temps réel (barre du haut + activité nébuleuse) ──*/
  const qs = new URLSearchParams(location.search);
  const PORT = qs.get('port') || location.port || '8420';
  $('m-port').textContent = PORT;
  async function pollMetrics() {
    try {
      const m = await (await fetch('/api/metrics')).json();
      $('m-cpu').textContent = m.cpu + '%';
      $('m-ram').textContent = m.ramUsedGb + '/' + m.ramTotalGb + 'G';
      $('m-agents').textContent = String(1 + m.terminalSessions + m.activeAi);
      window.__aetherActivity = Math.max(0.08, Math.min(1, m.cpu / 100));
    } catch (e) { /* serveur momentanément absent */ }
  }
  pollMetrics();
  setInterval(pollMetrics, 2000);

  /* ── Timeline agents ──*/
  function kindLabel(k) {
    return { user: 'toi', ai: 'Aether', cmd: 'terminal', sys: 'système', err: 'erreur', file: 'fichier' }[k] || k;
  }
  function event(kind, text) {
    const tl = $('timeline');
    const d = document.createElement('div');
    d.className = 'ev ' + kind;
    const t = new Date().toLocaleTimeString('fr-FR', { hour12: false });
    const head = document.createElement('span');
    head.className = 'ev-t';
    head.textContent = t + ' · ' + kindLabel(kind);
    const body = document.createElement('div');
    body.className = 'ev-b';
    body.textContent = text;
    d.appendChild(head); d.appendChild(body);
    tl.insertBefore(d, tl.firstChild);
  }

  /* ── Graphe fichiers ──*/
  function pjoin(a, b) { return a.replace(/\/+$/, '') + '/' + b; }
  async function fillTree(container, dirPath) {
    let j;
    try { j = await (await fetch('/api/files?path=' + encodeURIComponent(dirPath))).json(); }
    catch (e) { container.textContent = '⚠ serveur injoignable'; return; }
    if (j.error) { container.textContent = '⚠ ' + j.error; return; }
    j.dirs.forEach(function (n) { container.appendChild(makeNode(n, pjoin(dirPath || j.path, n), true)); });
    j.files.forEach(function (n) { container.appendChild(makeNode(n, pjoin(dirPath || j.path, n), false)); });
  }
  function makeNode(name, full, isDir) {
    const wrap = document.createElement('div'); wrap.className = 'tnode-wrap';
    const row = document.createElement('div'); row.className = 'tnode ' + (isDir ? 'dir' : 'file');
    row.textContent = (isDir ? '▸ ' : '· ') + name;
    row.title = full;
    const kids = document.createElement('div'); kids.className = 'tkids hidden';
    wrap.appendChild(row); wrap.appendChild(kids);
    row.addEventListener('click', async function () {
      if (!isDir) return openFile(full);
      if (kids.classList.contains('hidden')) {
        kids.classList.remove('hidden');
        row.textContent = '▾ ' + name;
        if (!kids.dataset.loaded) { kids.dataset.loaded = '1'; await fillTree(kids, full); }
      } else {
        kids.classList.add('hidden');
        row.textContent = '▸ ' + name;
      }
    });
    return wrap;
  }
  fillTree($('filetree'), '');

  /* ── Éditeur de code ──*/
  let openPath = null;
  const editor = $('editor');
  async function openFile(p) {
    try {
      const j = await (await fetch('/api/file?path=' + encodeURIComponent(p))).json();
      if (j.error) { event('err', 'lecture : ' + j.error); return; }
      openPath = j.path;
      editor.value = j.content;
      $('editor-path').textContent = j.path;
      switchTab('code');
      event('file', 'ouvert : ' + j.path);
    } catch (e) { event('err', String((e && e.message) || e)); }
  }
  $('btn-save').addEventListener('click', async function () {
    if (!openPath) { event('err', 'aucun fichier ouvert'); return; }
    try {
      const r = await (await fetch('/api/file', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: openPath, content: editor.value })
      })).json();
      if (r.ok) event('file', 'enregistré : ' + r.path + ' (' + r.bytes + ' o)');
      else event('err', 'enregistrement : ' + (r.error || '?'));
    } catch (e) { event('err', String((e && e.message) || e)); }
  });
  editor.addEventListener('keydown', function (e) {
    if (e.key === 'Tab') {
      e.preventDefault();
      editor.setRangeText('  ', editor.selectionStart, editor.selectionEnd, 'end');
    }
  });
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); $('btn-save').click(); }
  });

  /* ── Fournisseurs IA (le « truc maître ») ──*/
  async function loadProviders() {
    try {
      const cfg = await (await fetch('/api/plugins')).json();
      const sel = $('provider');
      sel.innerHTML = '';
      (cfg.providers || []).forEach(function (p) {
        const o = document.createElement('option');
        o.value = p.id; o.textContent = p.name;
        if (p.id === cfg.active) o.selected = true;
        sel.appendChild(o);
      });
      sel.onchange = async function () {
        try {
          await fetch('/api/plugins/active', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: sel.value })
          });
          event('sys', 'IA maître → ' + sel.value);
        } catch (e) { event('err', String((e && e.message) || e)); }
      };
    } catch (e) { /* ignore */ }
  }
  loadProviders();

  /* ── Mémoire vivante ──*/
  async function loadMemory() {
    const box = $('memlist');
    box.innerHTML = '';
    try {
      const j = await (await fetch('/api/memory')).json();
      const items = j.items || [];
      if (!items.length) {
        box.innerHTML = '<p class="dim">Mémoire vide — chaque échange IA et chaque fichier enregistré s\u2019y inscrira.</p>';
        return;
      }
      items.slice().reverse().forEach(function (it) {
        const d = document.createElement('div'); d.className = 'mem';
        const t = document.createElement('span'); t.className = 'mem-t';
        t.textContent = (it.ts || '').replace('T', ' ').slice(0, 19) + ' · ' + it.kind;
        const b = document.createElement('div'); b.className = 'mem-b'; b.textContent = it.text;
        d.appendChild(t); d.appendChild(b);
        box.appendChild(d);
      });
    } catch (e) { box.innerHTML = '<p class="dim">⚠ ' + String((e && e.message) || e) + '</p>'; }
  }

  /* ── Aether Grid ──*/
  async function loadGrid() {
    try {
      const g = await (await fetch('/api/grid/status')).json();
      $('grid-node').textContent = g.node + ' · ' + g.platform;
      $('p2p-path').textContent = (g.p2p.exists ? '✓ détecté : ' : '✗ introuvable : ') + g.p2p.path;
      const box = $('phase-list');
      box.innerHTML = '';
      (g.phases || []).forEach(function (ph) {
        const card = document.createElement('div'); card.className = 'phase-card';
        const t = document.createElement('div');
        const b = document.createElement('b'); b.textContent = 'Phase ' + ph.id;
        t.appendChild(b);
        t.appendChild(document.createTextNode(' — ' + ph.name));
        const badge = document.createElement('span'); badge.className = 'badge'; badge.textContent = ph.status;
        card.appendChild(t); card.appendChild(badge);
        box.appendChild(card);
      });
    } catch (e) { /* ignore */ }
  }

  /* ── Mode Deep Work ──*/
  let deep = false, chronoInt = null, t0 = 0;
  function tickChrono() {
    const s = Math.floor((Date.now() - t0) / 1000);
    $('chrono').textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  }
  $('btn-deep').addEventListener('click', function () {
    deep = !deep;
    document.body.classList.toggle('deep', deep);
    $('btn-deep').classList.toggle('on', deep);
    if (deep) {
      t0 = Date.now(); tickChrono();
      $('chrono').classList.remove('hidden');
      chronoInt = setInterval(tickChrono, 1000);
      event('sys', 'Mode Deep Work — nébuleuse ralentie, panneaux escamotés.');
    } else {
      clearInterval(chronoInt);
      $('chrono').classList.add('hidden');
      event('sys', 'Deep Work terminé.');
    }
  });

  /* ── Orbe ──*/
  const input = $('orbinput');
  const thread = [{
    role: 'system',
    content: 'Tu es Aether, l\u2019agent central de l\u2019environnement NEXUS AETHER. Tu réponds en français, de façon directe et utile. Tout tourne en local ou via les API configurées par l\u2019utilisateur.'
  }];
  const history = [];
  let hi = 0, busy = false;

  input.addEventListener('keydown', async function (e) {
    if (e.key === 'ArrowUp' && history.length) {
      if (hi > 0) hi--;
      input.value = history[hi] || '';
      e.preventDefault(); return;
    }
    if (e.key === 'ArrowDown') {
      if (hi < history.length) hi++;
      input.value = history[hi] || '';
      e.preventDefault(); return;
    }
    if (e.key !== 'Enter' || busy) return;
    const text = input.value.trim();
    if (!text) return;
    input.value = '';
    history.push(text); hi = history.length;

    if (text.charAt(0) === '!' || text.indexOf('run ') === 0) {
      const cmd = text.charAt(0) === '!' ? text.slice(1) : text.slice(4);
      switchTab('term');
      if (window.AetherTerm && window.AetherTerm.ready) { window.AetherTerm.run(cmd); event('cmd', cmd); }
      else event('err', 'terminal pas encore prêt — réessaie dans une seconde');
      return;
    }
    if (text.charAt(0) === '/') { localCmd(text); return; }
    await askAi(text);
  });

  async function askAi(text) {
    busy = true;
    document.body.classList.add('thinking');
    event('user', text);
    thread.push({ role: 'user', content: text });
    while (thread.length > 13) thread.splice(1, 1);
    try {
      const r = await fetch('/api/ai', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: thread.slice() })
      });
      const j = await r.json();
      if (j.ok) { thread.push({ role: 'assistant', content: j.text }); event('ai', j.text); }
      else event('err', j.error || 'erreur IA inconnue');
    } catch (e2) { event('err', String((e2 && e2.message) || e2)); }
    busy = false;
    document.body.classList.remove('thinking');
  }

  function localCmd(t) {
    const parts = t.slice(1).trim().split(/\s+/);
    const cmd = (parts[0] || '').toLowerCase();
    const arg = parts.slice(1).join(' ');
    if (cmd === 'help') {
      event('sys', 'Commandes — !cmd : exécute dans le terminal · /help · /ai list · /ai use <id> · /plugins · /deep · /clear · /grid · /memory · texte libre : l\u2019IA maître répond');
      return;
    }
    if (cmd === 'ai') {
      if (arg.indexOf('use') === 0) {
        const id = arg.slice(3).trim();
        fetch('/api/plugins/active', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: id })
        }).then(function (r) { return r.json(); }).then(function (j) {
          event(j.ok ? 'sys' : 'err', j.ok ? 'IA maître → ' + j.active : (j.error || 'fournisseur inconnu'));
          loadProviders();
        }).catch(function (e) { event('err', String((e && e.message) || e)); });
      } else {
        fetch('/api/plugins').then(function (r) { return r.json(); }).then(function (cfg) {
          const lines = (cfg.providers || []).map(function (p) {
            return (p.id === cfg.active ? '▸ ' : '  ') + p.id + ' — ' + p.name;
          }).join('\n');
          event('sys', 'Fournisseurs IA (actif marqué ▸) :\n' + lines + '\n→ /ai use <id>');
        }).catch(function (e) { event('err', String((e && e.message) || e)); });
      }
      return;
    }
    if (cmd === 'plugins') {
      fetch('/api/plugins').then(function (r) { return r.json(); }).then(function (cfg) {
        event('sys', 'Config : ~/.aether/plugins.json — actif : ' + cfg.active);
      });
      return;
    }
    if (cmd === 'deep') { $('btn-deep').click(); return; }
    if (cmd === 'clear') { $('timeline').innerHTML = ''; return; }
    if (cmd === 'grid') { switchTab('grid'); return; }
    if (cmd === 'memory') { switchTab('memory'); return; }
    event('sys', 'Commande inconnue — /help liste tout');
  }

  event('sys', 'NEXUS AETHER en ligne — port ' + PORT + '. L\u2019orbe t\u2019écoute : /help pour les commandes.');
})();
AE_APP
ok "ui/app.js — orbe (intention !cmd // /commandes // IA), graphe, éditeur, agents, Deep Work"

cat > config/plugins.json <<'AE_PLG'
{
  "active": "ollama-local",
  "providers": [
    { "id": "ollama-local", "name": "Ollama (local · souverain)", "type": "port", "url": "http://127.0.0.1:11434", "model": "llama3" },
    { "id": "glm", "name": "GLM · Z.ai (API)", "type": "openai", "url": "https://open.bigmodel.cn/api/paas/v4/chat/completions", "model": "glm-4-flash", "keyEnv": "AETHER_GLM_KEY" },
    { "id": "gemini", "name": "Google Gemini (API)", "type": "gemini", "url": "https://generativelanguage.googleapis.com/v1beta", "model": "gemini-1.5-flash", "keyEnv": "AETHER_GEMINI_KEY" },
    { "id": "openai-compat", "name": "Compatible OpenAI (tout fournisseur)", "type": "openai", "url": "", "model": "", "keyEnv": "AETHER_CUSTOM_KEY" }
  ]
}
AE_PLG
ok "config/plugins.json — Ollama (port) · GLM · Gemini · custom (API)"

cat > assets/aether.svg <<'AE_SVG'
<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128">
  <defs>
    <radialGradient id="g" cx="35%" cy="35%" r="75%">
      <stop offset="0%" stop-color="#a8fbff"/>
      <stop offset="45%" stop-color="#00E5FF"/>
      <stop offset="100%" stop-color="#0a1a8c"/>
    </radialGradient>
  </defs>
  <rect width="128" height="128" rx="28" fill="#050510"/>
  <circle cx="64" cy="64" r="30" fill="url(#g)"/>
  <ellipse cx="64" cy="64" rx="52" ry="18" fill="none" stroke="#FF00C8" stroke-width="3" transform="rotate(-18 64 64)" opacity=".85"/>
  <ellipse cx="64" cy="64" rx="52" ry="18" fill="none" stroke="#00E5FF" stroke-width="2.5" transform="rotate(24 64 64)" opacity=".7"/>
</svg>
AE_SVG
ok "assets/aether.svg — icône orbe + anneaux (identité Aether)"

cat > README.md <<'AE_README'
# NEXUS AETHER — v1.0.0
Environnement de travail immersif, souverain et conscient.

## Lancer
- Menu des applications → **NEXUS AETHER**
- ou double-clic sur l'icône du Bureau
- ou `~/Aether/scripts/aether-launch.sh`

## Port
Le serveur démarre automatiquement à l'ouverture, sur le port **8420**
(s'il est occupé : 8421, 8422…). Pour changer :
`AETHER_PORT=9000 ~/Aether/scripts/aether-launch.sh`

## Brancher n'importe quelle IA (« truc maître »)
Config : `~/.aether/plugins.json`
- Ollama (local, souverain) : lance `ollama serve` → type "port"
- GLM / Z.ai : `export AETHER_GLM_KEY=...` → type "openai"
- Gemini : `export AETHER_GEMINI_KEY=...` → type "gemini"
- Tout autre : type "openai" + url + `AETHER_CUSTOM_KEY`
L'IA maître se choisit dans le panneau AGENTS ou via `/ai use <id>`.

## Orbe (barre du bas)
- `!commande` → exécute dans le vrai terminal
- `/help` → liste des commandes
- texte libre → l'IA maître répond

## Arrêter
`~/Aether/scripts/aether-stop.sh`

## Confidentialité
Serveur lié à 127.0.0.1 uniquement. Rien ne sort sans ta clé API,
rien n'est envoyé à un cloud. Mémoire locale : ~/.aether/
AE_README
ok "README.md — mode d'emploi complet"
