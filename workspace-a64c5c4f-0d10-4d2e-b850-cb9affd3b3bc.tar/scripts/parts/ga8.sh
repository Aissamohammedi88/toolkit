
# ════════════════════════════════════════════════════════════════════
phase 4 "Compilation & introspection (preuves)"
# ════════════════════════════════════════════════════════════════════
for f in nexus_services.py nexus_llm.py service_hub.py; do
  chk "py_compile $f" "python3 -m py_compile '$APP_DIR/$f'"
done
N_SVCS="$(python3 -c "
import sys; sys.path.insert(0, '$APP_DIR')
import nexus_services as NS
print(NS.N_SERVICES)
" 2>/dev/null || echo 0)"
if [ "${N_SVCS:-0}" -ge 90 ]; then
  ok "catalogue : $N_SVCS services réels chargés (exigence ≥90 — OK)"
else
  ko "catalogue incomplet : $N_SVCS services"
fi
N_CATS="$(python3 -c "
import sys; sys.path.insert(0, '$APP_DIR')
import nexus_services as NS
print(len(set(s['cat'] for s in NS.SERVICES)))
" 2>/dev/null || echo 0)"
info "répartis dans $N_CATS catégories"

# ════════════════════════════════════════════════════════════════════
phase 5 "BATTERIE RÉELLE — 16 services testés en direct"
# ════════════════════════════════════════════════════════════════════
if [ "$FAIL" -gt 0 ]; then
  warn "échecs en amont — batterie sautée"
else
  BAT_OUT="$(cd "$APP_DIR" && timeout 120 python3 nexus_services.py --battery 16 2>&1 || true)"
  printf '%s\n' "$BAT_OUT" | sed 's/^/  /'
  if printf '%s' "$BAT_OUT" | grep -q "Synthèse"; then
    ok "batterie exécutée — les états ci-dessus sont des appels RÉELS depuis cette machine"
    warn "certains services limitent les IP de datacenter/VPN : chez toi, sur ton IP, ils seront souvent verts"
  else
    ko "batterie non terminée (timeout réseau ?)"
  fi
fi

# ════════════════════════════════════════════════════════════════════
phase 6 "Raccourcis (menu + Bureau) — GenEdit reste en place"
# ════════════════════════════════════════════════════════════════════
if [ "${NEXUS_NO_DESKTOP:-0}" = "1" ]; then
  warn "raccourcis sautés (NEXUS_NO_DESKTOP=1) — lancement : $APP_DIR/genhub.sh"
else
  ICON=""
  [ -f "$APP_DIR/assets/aether.svg" ] && ICON="$APP_DIR/assets/aether.svg"
  cat > "$APP_DIR/build-nexus-genhub.desktop" <<DESKF
[Desktop Entry]
Type=Application
Version=1.0
Name=NEXUS GEN HUB
GenericName=Éditeur génératif v2
Comment=~140 services de génération réels + IA sans clé · port de GenEdit v1 intact
Exec=$APP_DIR/genhub.sh
Icon=${ICON:-$APP_DIR/genhub.svg}
Path=$APP_DIR
Terminal=false
Categories=Development;Utility;
StartupNotify=true
StartupWMClass=nexus-genhub
DESKF
  if [ -z "$ICON" ]; then
    cat > "$APP_DIR/genhub.svg" <<'ICONS'
<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128">
  <rect width="128" height="128" rx="26" fill="#050510"/>
  <polygon points="64,16 106,40 106,88 64,112 22,88 22,40" fill="none" stroke="#00E5FF" stroke-width="4"/>
  <polygon points="64,34 92,50 92,80 64,96 36,80 36,50" fill="#00E5FF" opacity="0.25"/>
  <circle cx="64" cy="64" r="12" fill="#FF00C8"/>
</svg>
ICONS
    ICON="$APP_DIR/genhub.svg"
  fi
  APPS_DIR="$HOME/.local/share/applications"
  mkdir -p "$APPS_DIR"
  cp "$APP_DIR/build-nexus-genhub.desktop" "$APPS_DIR/nexus-genhub.desktop"
  ok "menu des applications → NEXUS GEN HUB"
  DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Bureau")"
  mkdir -p "$DESKTOP_DIR"
  cp "$APP_DIR/build-nexus-genhub.desktop" "$DESKTOP_DIR/nexus-genhub.desktop"
  chmod +x "$DESKTOP_DIR/nexus-genhub.desktop" 2>/dev/null || true
  gio set "$DESKTOP_DIR/nexus-genhub.desktop" metadata::trusted true 2>/dev/null \
    && ok "icône Bureau installée (marquée fiable)" \
    || ok "icône Bureau : $DESKTOP_DIR/nexus-genhub.desktop (si Mint demande : clic-droit → Autoriser le lancement)"
fi
if command -v desktop-file-validate >/dev/null 2>&1 && [ -f "$HOME/.local/share/applications/nexus-genhub.desktop" ]; then
  chk ".desktop valide" "desktop-file-validate '$HOME/.local/share/applications/nexus-genhub.desktop'"
fi

# ════════════════════════════════════════════════════════════════════
phase 7 "Preuve de NON-DESTRUCTION + rapport"
# ════════════════════════════════════════════════════════════════════
if [ -n "$GENEDIT" ]; then
  SHA_AFTER="$(sha256sum "$GENEDIT" | awk '{print $1}')"
  if [ "$SHA_BEFORE" = "$SHA_AFTER" ]; then
    ok "genedit.py INTOUCHE — SHA-256 identique avant/après : ${SHA_AFTER:0:24}…"
  else
    ko "ALERTE : genedit.py a changé — restaure depuis le backup $BK"
  fi
fi
echo
echo -e "  ${C_CYAN}${C_B}Nouveautés installées dans $APP_DIR${C_RST}"
for f in nexus_services.py nexus_llm.py service_hub.py genhub.sh nexus_hub_hook.py; do
  [ -f "$APP_DIR/$f" ] && info "$f  ($(wc -l < "$APP_DIR/$f") lignes)"
done
info "~/.nexus-hub/config.json · ~/.nexus-hub/plugins/exemple-fox.py (extensions automatiques)"
echo
cat <<RAP

  Pour convaincre l'investisseur en 90 secondes :
    1. Ouvre  NEXUS GEN HUB  (menu ou Bureau)  →  bouton  ⚡ DÉMO INVESTISSEUR
       → graphique réel, QR réel, voix réelle, image IA, puis workflow écrit
       par l'IA SANS aucun template. Zéro clé API utilisée.
    2. Onglet  ⚡ Batterie live  →  TESTER LES ~140 SERVICES
       → les états s'allument un par un : chaque ligne est un appel réseau réel.
    3. Onglet  IA → YAML  →  décris n'importe quel pipeline en français
       → YAML NOUVEAU généré et validé, enregistré directement dans le dossier
       de workflows de GenEdit v1 ($WDIR).

RAP
cat > "$APP_DIR/INTEGRATION-GENHUB.md" <<DOC
# NEXUS GEN HUB — ajouté le $(date '+%d/%m/%Y %H:%M')

## Quoi de neuf (v2)
- ~140 services de génération RÉELS (nexus_services.py) — IA image/texte/voix,
  diagrammes, QR, graphiques, météo, espace, finance, science… majoritairement SANS clé.
- Génération de workflows PAR IA (nexus_llm.py) : Ollama local → Pollinations
  (GPT/Mistral/DeepSeek/Qwen, sans clé) → offres gratuites (Groq, Gemini, OpenRouter…).
- Hub graphique complet (service_hub.py) avec batterie de test live et démo 1 clic.
- Système de plugins : ~/.nexus-hub/plugins/*.py (exemple fourni).

## GenEdit v1
- genedit.py : AUCUNEMENT modifié (SHA-256 vérifié par l'installateur).
- Sauvegarde : backup-v1-<date>/ à côté de l'app.
- Pont optionnel (3 lignes avant mainloop de genedit.py) :
      try:
          import nexus_hub_hook; nexus_hub_hook.register(root)
      except Exception:
          pass
- Les YAML générés par le hub s'enregistrent dans : $WDIR

## Clés optionnelles (toutes gratuites)
export NEXUS_GROQ_KEY=…      # console.groq.com
export NEXUS_GEMINI_KEY=…    # aistudio.google.com
export NEXUS_OPENROUTER_KEY=… # openrouter.ai (modèles :free)
export NEXUS_HF_KEY=…        # huggingface.co (FLUX, SDXL)
DOC
ok "INTEGRATION-GENHUB.md écrit"

# ════════════════════════════════════════════════════════════════════
phase 8 "Lancement & fin"
# ════════════════════════════════════════════════════════════════════
echo
echo -e "  ${C_B}Bilan : ${C_GRN}$PASS réussis${C_RST} / ${C_RED}$FAIL échoués${C_RST}"
if [ "$FAIL" -eq 0 ]; then
  echo -e "  ${C_GRN}${C_B}✦ TOUT EST VERT — GEN HUB v2 est prêt à montrer du RÉEL.${C_RST}"
else
  echo -e "  ${C_YLW}Des échecs — relance ce script (ré-exécutable), la sauvegarde est déjà en place.${C_RST}"
fi
echo
LAUNCH_NOW="n"
if [ "${1:-}" = "--launch" ]; then
  LAUNCH_NOW="o"
elif [ -t 0 ]; then
  read -r -p "  Lancer NEXUS GEN HUB maintenant ? [o/N] " LAUNCH_NOW || LAUNCH_NOW="n"
fi
if [[ "$LAUNCH_NOW" == [oO]* ]]; then
  (cd "$APP_DIR" && nohup python3 service_hub.py >/dev/null 2>&1 & disown 2>/dev/null || true)
  echo -e "  ${C_DIM}la fenêtre du hub s'ouvre…${C_RST}"
fi
echo
if [ -t 0 ]; then
  echo -e "${C_DIM}— Appuie sur ENTRÉE pour fermer ce terminal —${C_RST}"
  read -r _
fi
echo
[ "$FAIL" -eq 0 ] && exit 0 || exit 1
