
# ════════════════════════════════════════════════════════════════════
#  PARTIE C — nexus_services.py (3/3) : images, QR, graphs, data…
# ════════════════════════════════════════════════════════════════════

cat >> "$APP_DIR/nexus_services.py" <<'NS3'

# ─────────────────────────────────────────────────────────────────────
#  IMAGES UTILES (5)
# ─────────────────────────────────────────────────────────────────────
srv(id="ph-picsum", nom="Picsum · photo aléatoire", cat="IMAGES UTILES", acces="sans-clé", genre="image",
    desc="Photos haute qualité aléatoires (Unsplash). Vérifié vivant.",
    params=[("largeur", "800", "largeur"), ("hauteur", "600", "hauteur")],
    run=imgget("https://picsum.photos/{largeur}/{hauteur}.jpg", ext="jpg"),
    ping=lambda: http_req("https://picsum.photos/64/64", timeout=10)[0])
srv(id="ph-picsum-gray", nom="Picsum · noir & blanc", cat="IMAGES UTILES", acces="sans-clé", genre="image",
    desc="Variante grayscale.",
    params=[("largeur", "800", "largeur"), ("hauteur", "600", "hauteur")],
    run=imgget("https://picsum.photos/{largeur}/{hauteur}.jpg?grayscale", ext="jpg"),
    ping=lambda: http_req("https://picsum.photos/64/64?grayscale", timeout=10)[0])
srv(id="ph-picsum-blur", nom="Picsum · flou (fond nébuleuse)", cat="IMAGES UTILES", acces="sans-clé", genre="image",
    desc="Variante floue — idéale pour des fonds de slides.",
    params=[("largeur", "800", "largeur"), ("hauteur", "600", "hauteur")],
    run=imgget("https://picsum.photos/{largeur}/{hauteur}.jpg?blur=4", ext="jpg"),
    ping=lambda: http_req("https://picsum.photos/64/64?blur=2", timeout=10)[0])
srv(id="ph-placehold", nom="placehold.co · placeholder", cat="IMAGES UTILES", acces="sans-clé", genre="image",
    desc="Images placeholder personnalisées (texte, couleurs).",
    params=[("taille", "600x300", "taille"), ("texte", "NEXUS", "texte"), ("couleurs", "050510/00E5FF", "fond/texte hex")],
    run=imgget("https://placehold.co/{taille}/{couleurs}.png?text={texte_quote}"),
    ping=lambda: http_req("https://placehold.co/100x50.png", timeout=10)[0])
srv(id="ph-loremflickr", nom="LoremFlickr · photo par mot-clé", cat="IMAGES UTILES", acces="sans-clé", genre="image",
    desc="Photos réelles Flickr filtrées par mot-clé.",
    params=[("largeur", "640", "largeur"), ("hauteur", "480", "hauteur"), ("motcle", "technology", "mot-clé")],
    run=imgget("https://loremflickr.com/{largeur}/{hauteur}/{motcle}", ext="jpg"),
    ping=lambda: http_req("https://loremflickr.com/64/64/cat", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  QR & CODES-BARRES (3)
# ─────────────────────────────────────────────────────────────────────
srv(id="qr-goqr", nom="QR Code (goqr.me)", cat="QR & CODES-BARRES", acces="sans-clé", genre="image",
    desc="Générateur QR gratuit. Vérifié vivant.",
    params=[("data", "https://github.com/", "contenu"), ("taille", "300x300", "taille")],
    run=imgget("https://api.qrserver.com/v1/create-qr-code/?data={data_quote}&size={taille}"),
    ping=lambda: http_req("https://api.qrserver.com/v1/create-qr-code/?data=ok&size=64x64", timeout=10)[0])
srv(id="qr-quickchart", nom="QR Code (QuickChart)", cat="QR & CODES-BARRES", acces="sans-clé", genre="image",
    desc="Variante QuickChart, marge et couleurs réglables.",
    params=[("data", "NEXUS GEN HUB", "contenu"), ("taille", "300", "taille px")],
    run=imgget("https://quickchart.io/qr?text={data_quote}&size={taille}&dark=050510&light=ffffff"),
    ping=lambda: http_req("https://quickchart.io/qr?text=ok&size=64", timeout=10)[0])
srv(id="bc-tec-it", nom="Code-barres (TEC-IT)", cat="QR & CODES-BARRES", acces="sans-clé", genre="image",
    desc="EAN, UPC, Code128… gratuit depuis 1996.",
    params=[("data", "4006381333931", "données"), ("type", "EAN13", "type (EAN13, Code128, QRCode…)")],
    run=imgget("https://barcode.tec-it.com/barcode.ashx?data={data_quote}&code={type}&translate-esc=on"),
    ping=lambda: http_req("https://barcode.tec-it.com/barcode.ashx?data=123&code=Code128", timeout=10)[0])

# ─────────────────────────────────────────────────────────────────────
#  GRAPHIQUES & DATA (3)
# ─────────────────────────────────────────────────────────────────────
def _quickchart(p):
    cfg = {"type": p.get("type", "bar"),
           "data": {"labels": [x.strip() for x in p.get("labels", "A,B,C").split(",")],
                    "datasets": [{"label": p.get("titre", "Série"), "data": [float(x) for x in p.get("valeurs", "12,29,7").split(",")]}]},
           "options": {"title": {"display": True, "text": p.get("titre", "NEXUS Chart")}, "plugins": {"backgroundColor": "rgba(5,5,16,0.9)"}}}
    st, b, u = http_req("https://quickchart.io/chart?c=" + _q(json.dumps(cfg)) + "&w=700&h=400", timeout=30)
    if st >= 400 or len(b) < 300:
        return R("image", ok=False, info="HTTP %s" % st, status=st)
    return R("image", path=save_out(ts_name() + ".png", b), status=st, info="QuickChart — vérifié vivant", url=u)

srv(id="g-quickchart", nom="QuickChart · graphiques Chart.js", cat="GRAPHIQUES & DATA", acces="sans-clé", genre="image",
    desc="N'importe quel graphique Chart.js en PNG, sans clé. Vérifié vivant.",
    params=[("type", "bar", "type (bar, line, pie, doughnut, radar)"), ("labels", "Jan,Fév,Mar", "labels séparés par ,"),
            ("valeurs", "12,29,7", "valeurs séparées par ,"), ("titre", "Mes données", "titre")],
    run=_quickchart,
    ping=lambda: http_req("https://quickchart.io/chart?c={type:'bar',data:{labels:['a'],datasets:[{data:[1]}]}}", timeout=12)[0])
srv(id="g-imagecharts", nom="Image-Charts", cat="GRAPHIQUES & DATA", acces="sans-clé", genre="image",
    desc="Ancien Google Chart API ressuscité, gratuit avec filigrane.",
    params=[("valeurs", "60,35,90", "valeurs chd=t:"), ("labels", "A|B|C", "labels chl (séparés par |)"), ("type", "bvg", "cht (bvg, lc, p3)")],
    run=imgget("https://image-charts.com/chart?chs=700x400&cht={type}&chd=t:{valeurs}&chl={labels_quote}&chco=00E5FF,FF00C8,00FF88"),
    ping=lambda: http_req("https://image-charts.com/chart?chs=100x60&cht=bvg&chd=t:1,2", timeout=12)[0])
srv(id="g-chartsets", nom="QuickChart · sparklines", cat="GRAPHIQUES & DATA", acces="sans-clé", genre="image",
    desc="Micro-graphiques (sparklines) pour dashboards et emails.",
    params=[("valeurs", "5,9,4,12,8,15", "valeurs")],
    run=imgget("https://quickchart.io/chart?c=%7Btype:'sparkline',data:%7Bdatasets:%5B%7Bdata:%5B{valeurs}%5D%7D%5D%7D%7D"),
    ping=lambda: http_req("https://quickchart.io/chart?c={type:'sparkline',data:{datasets:[{data:[1,2]}]}}", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  DIAGRAMMES (3)
# ─────────────────────────────────────────────────────────────────────
def _mermaid(p):
    code = p.get("code", "graph TD; A[NEXUS] --> B[GEN HUB]; B --> C{142 services}")
    b64 = base64.urlsafe_b64encode(code.encode("utf-8")).decode("ascii")
    st, b, u = http_req("https://mermaid.ink/img/" + b64 + "?type=png&theme=dark", timeout=40)
    if st >= 400 or len(b) < 300:
        return R("image", ok=False, info="HTTP %s" % st, status=st)
    return R("image", path=save_out(ts_name() + ".png", b), status=st, info="mermaid.ink — vérifié vivant", url=u)

srv(id="d-mermaid", nom="Mermaid Ink · diagrammes", cat="DIAGRAMMES", acces="sans-clé", genre="image",
    desc="Graphes, séquences, Gantt… depuis du texte Mermaid. Vérifié vivant.",
    params=[("code", "graph TD; A[NEXUS] --> B[GEN HUB]; B --> C{142 services}", "code Mermaid")],
    run=_mermaid,
    ping=lambda: http_req("https://mermaid.ink/img/" + base64.urlsafe_b64encode(b"graph TD;A-->B").decode(), timeout=15)[0])


def _kroki(p):
    moteur = p.get("moteur", "plantuml")
    st, b, u = http_req("https://kroki.io/%s/png" % moteur, method="POST",
                        headers={"Content-Type": "text/plain"}, data=p.get("code", "digraph{A->B}"), timeout=45)
    if st >= 400 or len(b) < 200:
        return R("image", ok=False, info="HTTP %s — syntaxe %s invalide ?" % (st, moteur), status=st)
    return R("image", path=save_out(ts_name() + ".png", b), status=st, info="kroki.io (" + moteur + ")", url=u)

srv(id="d-kroki", nom="Kroki · 25 moteurs de diagrammes", cat="DIAGRAMMES", acces="sans-clé", genre="image",
    desc="PlantUML, Graphviz, D2, Mermaid, ditaa… un seul endpoint open-source.",
    params=[("moteur", "plantuml", "moteur (plantuml, graphviz, d2, mermaid…)"), ("code", "@startuml\nNEXUS -> Hub\n@enduml", "code source")],
    run=_kroki,
    ping=lambda: http_req("https://kroki.io/graphviz/png", method="POST", data=b"digraph{A->B}", timeout=15)[0])


def _plantuml(p):
    code = p.get("code", "@startuml\nNEXUS -> Investisseur: demo\n@enduml")
    hexcode = code.encode("utf-8").hex()
    st, b, u = http_req("https://www.plantuml.com/plantuml/png/~h" + hexcode, timeout=45)
    if st >= 400 or len(b) < 300:
        return R("image", ok=False, info="HTTP %s" % st, status=st)
    return R("image", path=save_out(ts_name() + ".png", b), status=st, info="plantuml.com (~h hex)", url=u)

srv(id="d-plantuml", nom="PlantUML (serveur officiel)", cat="DIAGRAMMES", acces="sans-clé", genre="image",
    desc="Serveur officiel plantuml.com, encodage hex direct (~h) : zéro dépendance.",
    params=[("code", "@startuml\nNEXUS -> Investisseur: demo reel\n@enduml", "code PlantUML")],
    run=_plantuml,
    ping=lambda: http_req("https://www.plantuml.com/plantuml/png/~h" + b"@startuml\nA->B\n@enduml".hex(), timeout=15)[0])

# ─────────────────────────────────────────────────────────────────────
#  GÉO & CARTES (6)
# ─────────────────────────────────────────────────────────────────────
srv(id="geo-nominatim", nom="Nominatim · géocodage OSM", cat="GÉO & CARTES", acces="sans-clé", genre="json",
    desc="Adresse → coordonnées, OpenStreetMap officiel.",
    params=[("adresse", "Tour Eiffel, Paris", "adresse"), ("limite", "3", "résultats max")],
    run=jget("https://nominatim.openstreetmap.org/search?q={adresse_quote}&format=json&limit={limite}"),
    ping=lambda: http_req("https://nominatim.openstreetmap.org/search?q=paris&format=json&limit=1", timeout=12)[0])
srv(id="geo-photon", nom="Photon · géocodage komoot", cat="GÉO & CARTES", acces="sans-clé", genre="json",
    desc="Géocodage rapide et typographique tolerant.",
    params=[("adresse", "Lyon", "adresse"), ("limite", "3", "résultats")],
    run=jget("https://photon.komoot.io/api/?q={adresse_quote}&limit={limite}"),
    ping=lambda: http_req("https://photon.komoot.io/api/?q=paris&limit=1", timeout=12)[0])
srv(id="geo-osrm", nom="OSRM · itinéraires routiers", cat="GÉO & CARTES", acces="sans-clé", genre="json",
    desc="Distance et durée entre deux points (serveur public OSRM).",
    params=[("de", "2.3522,48.8566", "lon,lat départ"), ("vers", "4.8357,45.7640", "lon,lat arrivée")],
    run=jget("https://router.project-osrm.org/route/v1/driving/{de};{vers}?overview=false", pick="routes.0.duration"),
    ping=lambda: http_req("https://router.project-osrm.org/route/v1/driving/2.3,48.8;2.4,48.9?overview=false", timeout=12)[0])
srv(id="geo-overpass", nom="Overpass · requêtes OpenStreetMap", cat="GÉO & CARTES", acces="sans-clé", genre="json",
    desc="Interroge TOUT OpenStreetMap (cafés autour d'un point…). Lent mais puissant.",
    params=[("requete", 'node["amenity"="cafe"](48.85,2.29,48.87,2.32);', "requête Overpass QL")],
    run=lambda p: _overpass(p),
    ping=lambda: http_req("https://overpass-api.de/api/status", timeout=12)[0])


def _overpass(p):
    q = "[out:json][timeout:25];" + p.get("requete", 'node["amenity"="cafe"](48.85,2.29,48.87,2.32);') + "out body;"
    st, j, _ = http_json("https://overpass-api.de/api/interpreter", method="POST",
                         headers={"Content-Type": "application/x-www-form-urlencoded"},
                         data={"data": q}, timeout=70)
    if st >= 400 or j is None:
        return R("json", ok=False, info="HTTP %s (serveur public en charge — réessaie)" % st, status=st)
    els = (j.get("elements") or [])[:30]
    return R("json", status=st, text=json.dumps(els, ensure_ascii=False, indent=1)[:15000], info="%d éléments OSM" % len(els))

srv(id="geo-elevation", nom="Open-Elevation · altitudes", cat="GÉO & CARTES", acces="sans-clé", genre="json",
    desc="Altitude de n'importe quel point du globe.",
    params=[("points", "48.8584,2.2945", "lat,lon")],
    run=jget("https://api.open-elevation.com/api/v1/lookup?locations={points}"),
    ping=lambda: http_req("https://api.open-elevation.com/api/v1/lookup?locations=48.8,2.3", timeout=15)[0])
srv(id="geo-opentopo", nom="OpenTopoData · altitudes (DEM)", cat="GÉO & CARTES", acces="sans-clé", genre="json",
    desc="Altitudes via 40 jeux de données numériques de terrain.",
    params=[("dataset", "srtm90m", "dataset"), ("points", "48.8584,2.2945", "lat,lon")],
    run=jget("https://api.opentopodata.org/v1/{dataset}?locations={points}"),
    ping=lambda: http_req("https://api.opentopodata.org/v1/srtm90m?locations=48.8,2.3", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  MÉTÉO & ENVIRONNEMENT (6) — famille Open-Meteo, 100% sans-clé
# ─────────────────────────────────────────────────────────────────────
OM_P = [("latitude", "48.8566", "latitude"), ("longitude", "2.3522", "longitude")]
srv(id="wx-forecast", nom="Open-Meteo · prévisions", cat="MÉTÉO & ENVIRONNEMENT", acces="sans-clé", genre="json",
    desc="Prévisions 7 jours, heure par heure. Vérifié vivant.",
    params=OM_P, run=jget("https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&current=temperature_2m,wind_speed_10m&hourly=temperature_2m&forecast_days=3"),
    ping=lambda: http_req("https://api.open-meteo.com/v1/forecast?latitude=48.8&longitude=2.3&current=temperature_2m", timeout=10)[0])
srv(id="wx-historical", nom="Open-Meteo · archives 1940→", cat="MÉTÉO & ENVIRONNEMENT", acces="sans-clé", genre="json",
    desc="Météo historique depuis 1940.",
    params=OM_P, run=jget("https://archive-api.open-meteo.com/v1/archive?latitude={latitude}&longitude={longitude}&start_date=2024-01-01&end_date=2024-01-07&daily=temperature_2m_max"),
    ping=lambda: http_req("https://archive-api.open-meteo.com/v1/archive?latitude=48.8&longitude=2.3&start_date=2024-01-01&end_date=2024-01-02&daily=temperature_2m_max", timeout=12)[0])
srv(id="wx-air", nom="Open-Meteo · qualité de l'air", cat="MÉTÉO & ENVIRONNEMENT", acces="sans-clé", genre="json",
    desc="PM2.5, PM10, ozone, pollen en Europe.",
    params=OM_P, run=jget("https://air-quality-api.open-meteo.com/v1/air-quality?latitude={latitude}&longitude={longitude}&current=european_aqi,pm2_5"),
    ping=lambda: http_req("https://air-quality-api.open-meteo.com/v1/air-quality?latitude=48.8&longitude=2.3&current=european_aqi", timeout=10)[0])
srv(id="wx-marine", nom="Open-Meteo · marine", cat="MÉTÉO & ENVIRONNEMENT", acces="sans-clé", genre="json",
    desc="Vagues, houle, température de l'eau.",
    params=OM_P, run=jget("https://marine-api.open-meteo.com/v1/marine?latitude={latitude}&longitude={longitude}&current=wave_height"),
    ping=lambda: http_req("https://marine-api.open-meteo.com/v1/marine?latitude=48.8&longitude=-5.0&current=wave_height", timeout=12)[0])
srv(id="wx-flood", nom="Open-Meteo · crues (GloFAS)", cat="MÉTÉO & ENVIRONNEMENT", acces="sans-clé", genre="json",
    desc="Prévisions de débordement de rivière.",
    params=OM_P, run=jget("https://flood-api.open-meteo.com/v1/flood?latitude={latitude}&longitude={longitude}&daily=river_discharge"),
    ping=lambda: http_req("https://flood-api.open-meteo.com/v1/flood?latitude=48.8&longitude=2.3&daily=river_discharge", timeout=12)[0])
srv(id="wx-geocoding", nom="Open-Meteo · géocodage villes", cat="MÉTÉO & ENVIRONNEMENT", acces="sans-clé", genre="json",
    desc="Ville → coordonnées pour alimenter les autres services météo.",
    params=[("ville", "Marseille", "nom de ville")],
    run=jget("https://geocoding-api.open-meteo.com/v1/search?name={ville_quote}&count=3&language=fr"),
    ping=lambda: http_req("https://geocoding-api.open-meteo.com/v1/search?name=paris&count=1", timeout=10)[0])

# ─────────────────────────────────────────────────────────────────────
#  ESPACE (8)
# ─────────────────────────────────────────────────────────────────────
srv(id="sp-apod", nom="NASA · photo astronomique du jour", cat="ESPACE", acces="clé-gratuite", genre="json",
    desc="APOD quotidien. DEMO_KEY publique = 30 req/h partagées (clé perso gratuite recommandée).",
    params=[("cle", "DEMO_KEY", "clé API NASA")],
    run=jget("https://api.nasa.gov/planetary/apod?api_key={cle}"),
    ping=lambda: http_req("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY", timeout=12)[0])
srv(id="sp-neo", nom="NASA · astéroïdes proches", cat="ESPACE", acces="clé-gratuite", genre="json",
    desc=" objets géocroiseurs des 7 prochains jours.",
    params=[("cle", "DEMO_KEY", "clé API NASA")],
    run=jget("https://api.nasa.gov/neo/rest/v1/neo/browse?api_key={cle}"),
    ping=lambda: http_req("https://api.nasa.gov/neo/rest/v1/neo/browse?api_key=DEMO_KEY", timeout=12)[0])
srv(id="sp-iss-now", nom="Open Notify · position ISS", cat="ESPACE", acces="sans-clé", genre="json",
    desc="Où est la Station Spatiale Internationale, maintenant. Vérifié vivant.",
    params=[], run=jget("http://api.open-notify.org/iss-now.json"),
    ping=lambda: http_req("http://api.open-notify.org/iss-now.json", timeout=12)[0])
srv(id="sp-iss-crew", nom="Open Notify · astronautes en orbite", cat="ESPACE", acces="sans-clé", genre="json",
    desc="Qui est dans l'espace en ce moment.",
    params=[], run=jget("http://api.open-notify.org/astros.json"),
    ping=lambda: http_req("http://api.open-notify.org/astros.json", timeout=12)[0])
srv(id="sp-iss-where", nom="Where the ISS at?", cat="ESPACE", acces="sans-clé", genre="json",
    desc="Position ISS détaillée (vitesse, visibilité). Vérifié vivant.",
    params=[], run=jget("https://api.wheretheiss.at/v1/satellites/25544"),
    ping=lambda: http_req("https://api.wheretheiss.at/v1/satellites/25544", timeout=12)[0])
srv(id="sp-launches", nom="Launch Library 2 · prochains lancements", cat="ESPACE", acces="sans-clé", genre="json",
    desc="Tous les lancements spatiaux à venir (SpaceX, Ariane…). Vérifié vivant.",
    params=[("limite", "3", "nombre")],
    run=jget("https://ll.thespacedevs.com/2.2.0/launch/upcoming/?limit={limite}"),
    ping=lambda: http_req("https://ll.thespacedevs.com/2.2.0/launch/upcoming/?limit=1", timeout=15)[0])
srv(id="sp-usgs", nom="USGS · séismes du jour", cat="ESPACE", acces="sans-clé", genre="json",
    desc="Tous les séismes des dernières 24h, monde entier. Vérifié vivant.",
    params=[("min_mag", "2.5", "magnitude min (all_day = 0)")],
    run=jget("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/{min_mag}_day.geojson"),
    ping=lambda: http_req("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson", timeout=15)[0])
srv(id="sp-opensky", nom="OpenSky · avions en vol", cat="ESPACE", acces="sans-clé", genre="json",
    desc="ADS-B réel : tous les avions autour de toi (anonyme, limité).",
    params=[("lamin", "48.6", "lat min"), ("lomin", "2.1", "lon min"), ("lamax", "49.0", "lat max"), ("lomax", "2.6", "lon max")],
    run=jget("https://opensky-network.org/api/states/all?lamin={lamin}&lomin={lomin}&lamax={lamax}&lomax={lomax}"),
    ping=lambda: http_req("https://opensky-network.org/api/states/all?lamin=48.6&lomin=2.1&lamax=48.7&lomax=2.2", timeout=15)[0])

# ─────────────────────────────────────────────────────────────────────
#  FINANCE & CRYPTO (6)
# ─────────────────────────────────────────────────────────────────────
srv(id="fi-frankfurter", nom="Frankfurter · devises BCE", cat="FINANCE & CRYPTO", acces="sans-clé", genre="json",
    desc="Taux de change officiels BCE, gratuit.",
    params=[("de", "EUR", "devise source"), ("vers", "USD,CHF", "cibles")],
    run=jget("https://api.frankfurter.app/latest?from={de}&to={vers}"),
    ping=lambda: http_req("https://api.frankfurter.app/latest?from=EUR&to=USD", timeout=10)[0])
srv(id="fi-coingecko", nom="CoinGecko · prix crypto", cat="FINANCE & CRYPTO", acces="sans-clé", genre="json",
    desc="Prix en direct (limité sans clé : 30 req/min).",
    params=[("ids", "bitcoin,ethereum", "ids crypto"), ("vs", "eur", "devise")],
    run=jget("https://api.coingecko.com/api/v3/simple/price?ids={ids_quote}&vs_currencies={vs}"),
    ping=lambda: http_req("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=eur", timeout=12)[0])
srv(id="fi-coinlore", nom="CoinLore · tickers crypto", cat="FINANCE & CRYPTO", acces="sans-clé", genre="json",
    desc="Top 100 cryptos, aucune limite stricte. Vérifié vivant.",
    params=[("debut", "0", "début"), ("limite", "10", "limite")],
    run=jget("https://api.coinlore.net/api/tickers/?start={debut}&limit={limite}"),
    ping=lambda: http_req("https://api.coinlore.net/api/tickers/?start=0&limit=1", timeout=10)[0])
srv(id="fi-coinpaprika", nom="CoinPaprika · marché crypto", cat="FINANCE & CRYPTO", acces="sans-clé", genre="json",
    desc="Données de marché détaillées. Vérifié vivant.",
    params=[("limite", "5", "limite")],
    run=jget("https://api.coinpaprika.com/v1/tickers?limit={limite}"),
    ping=lambda: http_req("https://api.coinpaprika.com/v1/tickers?limit=1", timeout=12)[0])
srv(id="fi-blockstream", nom="Blockstream · blockchain Bitcoin", cat="FINANCE & CRYPTO", acces="sans-clé", genre="json",
    desc="Hauteur de bloc, transactions BTC. Vérifié vivant.",
    params=[("adresse", "bc1q…", "adresse BTC (optionnel)")],
    run=jget("https://blockstream.info/api/blocks/tip/height"),
    ping=lambda: http_req("https://blockstream.info/api/blocks/tip/height", timeout=12)[0])
srv(id="fi-blockchaininfo", nom="Blockchain.info · ticker BTC", cat="FINANCE & CRYPTO", acces="sans-clé", genre="json",
    desc="Cours BTC toutes devises.",
    params=[], run=jget("https://blockchain.info/ticker"),
    ping=lambda: http_req("https://blockchain.info/ticker", timeout=15)[0])
NS3
ok "nexus_services.py — images utiles, QR, graphiques, diagrammes, géo, météo, espace, finance"
