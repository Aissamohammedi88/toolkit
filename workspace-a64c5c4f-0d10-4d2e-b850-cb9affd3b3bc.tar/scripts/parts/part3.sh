
cat > ui/index.html <<'AE_HTML'
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>NEXUS AETHER</title>
<link rel="icon" href="/assets/aether.svg">
<link rel="stylesheet" href="/vendor/xterm.css">
<link rel="stylesheet" href="/ui/style.css">
</head>
<body>
<canvas id="nebula"></canvas>

<header id="topbar">
  <div class="brand"><span class="dot"></span>NEXUS&nbsp;<b>AETHER</b><span class="ver">v1.0.0</span></div>
  <div class="metrics">
    <span class="metric">CPU <b id="m-cpu">—</b></span>
    <span class="metric">RAM <b id="m-ram">—</b></span>
    <span class="metric">PORT <b id="m-port">—</b></span>
    <span class="metric">AGENTS <b id="m-agents">1</b></span>
  </div>
  <span id="chrono" class="hidden">00:00</span>
  <div class="winbtns">
    <button id="btn-deep" title="Mode Deep Work (immersion)">&#9684;</button>
    <button id="btn-min" title="Réduire">&#8722;</button>
    <button id="btn-max" title="Agrandir">&#9633;</button>
    <button id="btn-close" title="Fermer">&#10005;</button>
  </div>
</header>

<main>
  <aside id="left" class="glass">
    <h2>Graphe fichiers</h2>
    <div id="filetree" class="tree"></div>
  </aside>

  <section id="center" class="glass">
    <nav id="tabs">
      <button class="tab" data-tab="code">&#9672; Code</button>
      <button class="tab active" data-tab="term">&#9646; Terminal</button>
      <button class="tab" data-tab="grid">&#10022; Grid</button>
      <button class="tab" data-tab="memory">&#10228; Mémoire</button>
    </nav>
    <div id="panel-code" class="panel hidden">
      <div class="editor-head">
        <span id="editor-path">aucun fichier ouvert — clique le Graphe à gauche</span>
        <button id="btn-save">Enregistrer · Ctrl+S</button>
      </div>
      <textarea id="editor" spellcheck="false" placeholder="…"></textarea>
    </div>
    <div id="panel-term" class="panel"><div id="term"></div></div>
    <div id="panel-grid" class="panel hidden">
      <div class="grid-wrap">
        <h1 class="serif">Aether Grid — réseau P2P de calcul</h1>
        <p class="dim">Le projet Aether complet vit ici : le scaffold Rust (tunnel chiffré → tâches distribuées → calcul hétérogène → ZK/blockchain) reste piloté par ton script du Bureau, et cet onglet en montre l'état en direct.</p>
        <div id="phase-list"></div>
        <p class="dim">Nœud local&nbsp;: <code id="grid-node">…</code></p>
        <p class="dim">Script P2P&nbsp;: <code id="p2p-path">…</code></p>
      </div>
    </div>
    <div id="panel-memory" class="panel hidden"><div id="memlist" class="memlist"></div></div>
  </section>

  <aside id="right" class="glass">
    <h2>Agents</h2>
    <div class="provider-row">
      <label for="provider">IA maître</label>
      <select id="provider"></select>
    </div>
    <div id="timeline"></div>
  </aside>
</main>

<footer id="orbbar">
  <div id="orb" class="orb"></div>
  <input id="orbinput" type="text" autocomplete="off" spellcheck="false"
         placeholder="Orbe — parle à Aether&#8239;: !cmd → terminal · /help · sinon l'IA répond">
</footer>

<script src="/vendor/xterm.js"></script>
<script src="/vendor/addon-fit.js"></script>
<script src="/ui/nebula.js"></script>
<script src="/ui/terminal.js"></script>
<script src="/ui/app.js"></script>
</body>
</html>
AE_HTML
ok "ui/index.html — canvas nébuleuse, graphe, onglets, orbe, panneau agents"

cat > ui/style.css <<'AE_CSS'
/* ═══════════════════════════════════════════════════════════════
   NEXUS AETHER — identité visuelle au-delà des géants
   Nébuleuse WebGL derrière verre dépoli · cyan / magenta / vert néon
   ═══════════════════════════════════════════════════════════════ */
:root{
  --bg:#050510;
  --cyan:#00E5FF;
  --magenta:#FF00C8;
  --green:#00FF88;
  --txt:#E8ECFF;
  --dim:#8A90B8;
  --glass:rgba(12,14,28,.46);
  --glass-brd:rgba(255,255,255,.07);
  --sans:'Inter','Space Grotesk','Ubuntu',system-ui,sans-serif;
  --mono:'JetBrains Mono','Fira Code','DejaVu Sans Mono',monospace;
  --serif:'Playfair Display','Georgia',serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;overflow:hidden}
body{background:var(--bg);color:var(--txt);font-family:var(--sans);font-size:13px}
::selection{background:rgba(0,229,255,.3)}
::-webkit-scrollbar{width:8px;height:8px}
::-webkit-scrollbar-thumb{background:rgba(255,255,255,.12);border-radius:4px}
::-webkit-scrollbar-track{background:transparent}

#nebula{position:fixed;inset:0;z-index:0;transition:opacity 1s}

.glass{
  background:var(--glass);
  -webkit-backdrop-filter:blur(40px) saturate(150%);
  backdrop-filter:blur(40px) saturate(150%);
  border-radius:16px;
  box-shadow:0 24px 60px rgba(0,0,0,.5),inset 0 0 0 1px var(--glass-brd);
}
.hidden{display:none!important}

/* ── Barre de statut : titre + métriques + fenêtre ──*/
#topbar{
  position:fixed;top:0;left:0;right:0;height:38px;z-index:20;
  display:flex;align-items:center;gap:18px;padding:0 10px 0 14px;
  background:rgba(5,5,16,.55);
  -webkit-backdrop-filter:blur(24px);backdrop-filter:blur(24px);
  border-bottom:1px solid rgba(255,255,255,.05);
  -webkit-app-region:drag;user-select:none;
}
#topbar .brand{display:flex;align-items:center;gap:8px;font-size:13px;letter-spacing:2px;color:var(--dim)}
#topbar .brand b{color:var(--txt);font-weight:700}
#topbar .dot{width:9px;height:9px;border-radius:50%;background:var(--cyan);box-shadow:0 0 10px var(--cyan)}
#topbar .ver{font-family:var(--mono);font-size:10px;color:var(--dim);margin-left:2px}
.metrics{display:flex;gap:14px;margin-left:auto}
.metric{font-size:10px;letter-spacing:1.5px;color:var(--dim)}
.metric b{font-family:var(--mono);font-size:11px;color:var(--cyan);margin-left:4px}
#chrono{font-family:var(--mono);font-size:12px;color:var(--green);text-shadow:0 0 8px rgba(0,255,136,.6)}
.winbtns{display:flex;gap:6px;-webkit-app-region:no-drag}
.winbtns button{
  width:26px;height:26px;border:none;border-radius:8px;cursor:pointer;
  background:rgba(255,255,255,.05);color:var(--dim);font-size:12px;line-height:1;
  transition:all .15s;
}
.winbtns button:hover{background:rgba(0,229,255,.15);color:var(--cyan)}
.winbtns #btn-close:hover{background:rgba(255,60,90,.2);color:#FF5C7A}
.winbtns #btn-deep.on{background:rgba(0,255,136,.15);color:var(--green)}

/* ── Zone principale ──*/
main{position:fixed;top:48px;bottom:74px;left:10px;right:10px;display:grid;grid-template-columns:262px 1fr 318px;gap:10px;z-index:5}
#left,#right{padding:12px;overflow:auto}
#left h2,#right h2{font-size:10px;letter-spacing:3px;text-transform:uppercase;color:var(--dim);margin-bottom:10px}

/* ── Graphe fichiers ──*/
.tnode{padding:3px 6px;border-radius:6px;cursor:pointer;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tnode:hover{background:rgba(0,229,255,.08)}
.tnode.dir{color:#9fd8ff}
.tnode.file{color:var(--dim)}
.tkids{margin-left:12px;border-left:1px solid rgba(0,229,255,.12);padding-left:4px}

/* ── Centre : onglets + panneaux ──*/
#center{display:flex;flex-direction:column;overflow:hidden}
#tabs{display:flex;gap:6px;padding:10px 10px 0}
.tab{
  border:1px solid transparent;background:transparent;color:var(--dim);
  padding:6px 14px;border-radius:10px 10px 0 0;cursor:pointer;font-size:12px;letter-spacing:1px;
}
.tab:hover{color:var(--txt)}
.tab.active{
  color:var(--cyan);background:rgba(0,229,255,.07);
  border-color:rgba(0,229,255,.25);border-bottom-color:transparent;
  text-shadow:0 0 12px rgba(0,229,255,.5);
}
.panel{flex:1;min-height:0;display:flex;flex-direction:column;padding:10px}
.panel.hidden{display:none!important}

/* éditeur */
.editor-head{display:flex;align-items:center;gap:10px;margin-bottom:8px}
#editor-path{font-family:var(--mono);font-size:11px;color:var(--dim);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#btn-save{border:1px solid rgba(0,229,255,.35);background:rgba(0,229,255,.08);color:var(--cyan);padding:5px 12px;border-radius:8px;cursor:pointer;font-size:11px}
#btn-save:hover{background:rgba(0,229,255,.18)}
#editor{
  flex:1;min-height:0;resize:none;border:none;outline:none;border-radius:10px;
  background:rgba(0,0,0,.28);color:var(--txt);
  font-family:var(--mono);font-size:12.5px;line-height:1.5;padding:12px;
}

/* terminal */
#term{flex:1;min-height:0}
#term .xterm{height:100%}
.term-miss{padding:14px;color:var(--dim)}

/* grid */
.grid-wrap{overflow:auto;padding:6px 4px}
.serif{font-family:var(--serif);font-size:21px;font-weight:500;margin-bottom:10px;color:#ffffff}
.dim{color:var(--dim);margin-bottom:10px;line-height:1.5}
.dim code{font-family:var(--mono);font-size:11px;color:#9fd8ff;word-break:break-all}
.phase-card{
  display:flex;align-items:center;justify-content:space-between;gap:10px;
  background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.06);
  border-radius:12px;padding:10px 14px;margin-bottom:8px;
}
.phase-card b{color:var(--cyan)}
.badge{font-size:9px;letter-spacing:2px;color:var(--green);border:1px solid rgba(0,255,136,.35);padding:3px 8px;border-radius:20px;text-transform:uppercase}

/* mémoire */
.memlist{overflow:auto}
.mem{margin-bottom:10px;background:rgba(255,255,255,.03);border-radius:10px;padding:8px 10px}
.mem-t{font-family:var(--mono);font-size:9.5px;color:var(--dim);letter-spacing:1px}
.mem-b{font-family:var(--mono);font-size:11.5px;white-space:pre-wrap;word-break:break-word;margin-top:4px;color:#c9cff2}

/* ── Panneau agents ──*/
.provider-row{display:flex;flex-direction:column;gap:4px;margin-bottom:12px}
.provider-row label{font-size:10px;letter-spacing:2px;color:var(--dim);text-transform:uppercase}
#provider{
  background:rgba(0,0,0,.3);color:var(--txt);border:1px solid rgba(0,229,255,.25);
  border-radius:8px;padding:7px 8px;font-size:12px;outline:none;
}
#provider:focus{border-color:var(--cyan)}
#timeline{overflow:auto;flex:1;min-height:0}
.ev{margin-bottom:10px}
.ev-t{display:block;font-family:var(--mono);font-size:9.5px;color:var(--dim);letter-spacing:1px;margin-bottom:3px}
.ev-b{
  white-space:pre-wrap;word-break:break-word;font-size:12px;line-height:1.5;
  background:rgba(255,255,255,.04);border-radius:10px;padding:8px 10px;color:#c9cff2;
}
.ev.user .ev-b{border-left:2px solid var(--cyan)}
.ev.ai .ev-b{border-left:2px solid var(--magenta)}
.ev.cmd .ev-b{border-left:2px solid var(--green);font-family:var(--mono);font-size:11.5px}
.ev.err .ev-b{border-left:2px solid #FF5C7A;color:#ffb3c2}
.ev.sys .ev-b{border-left:2px solid rgba(255,255,255,.2);color:var(--dim)}
.ev.file .ev-b{border-left:2px solid #9fd8ff}

/* ── Orbe ──*/
#orbbar{position:fixed;left:0;right:0;bottom:10px;height:56px;display:flex;align-items:center;justify-content:center;gap:14px;z-index:20}
.orb{
  width:22px;height:22px;border-radius:50%;flex:none;
  background:radial-gradient(circle at 32% 30%,#a8fbff 0%,var(--cyan) 45%,#0039c8 100%);
  box-shadow:0 0 18px rgba(0,229,255,.75),0 0 46px rgba(0,229,255,.3);
}
body.thinking .orb{animation:orbPulse 1s ease-in-out infinite}
@keyframes orbPulse{
  0%,100%{transform:scale(1);box-shadow:0 0 14px rgba(0,229,255,.7),0 0 40px rgba(0,229,255,.25)}
  50%{transform:scale(1.3);box-shadow:0 0 30px rgba(255,0,200,.9),0 0 70px rgba(255,0,200,.4)}
}
#orbinput{
  width:min(660px,72vw);height:42px;border-radius:21px;outline:none;
  border:1px solid rgba(0,229,255,.22);
  background:rgba(8,10,24,.72);
  -webkit-backdrop-filter:blur(30px);backdrop-filter:blur(30px);
  color:var(--txt);font-family:var(--mono);font-size:13px;padding:0 18px;
  transition:border-color .25s,box-shadow .25s;
}
#orbinput::placeholder{color:var(--dim)}
#orbinput:focus{border-color:var(--cyan);box-shadow:0 0 0 1px rgba(0,229,255,.35),0 0 34px rgba(0,229,255,.22)}

/* ── Mode Deep Work ──*/
body.deep #left,body.deep #right{display:none}
body.deep main{grid-template-columns:1fr}
body.deep #nebula{opacity:.25}
AE_CSS
ok "ui/style.css — Glassmorphism 2.0 (blur 40px) · palette #00E5FF/#FF00C8/#00FF88"
