
cat > server/core.js <<'AE_CORE'
'use strict';
// NEXUS AETHER — cœur serveur (HTTP + WebSocket), embarqué dans Electron.
// Démarre AUTOMATIQUEMENT à l'ouverture de l'app, sur le port donné
// (8420 par défaut). Si le port est occupé, il cherche le suivant (8421…).
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');

let WS = null;
try { WS = require('ws'); } catch (e) { WS = null; }

const { chat, loadConfig, saveConfig } = require('../core/router');
const { remember, getMemory } = require('../core/memory');

const ROOT = path.join(__dirname, '..');
const UI_DIR = path.join(ROOT, 'ui');
const HOME = os.homedir();
const APP_VERSION = '1.0.0';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon'
};
const TEXT_EXT = new Set(['js','mjs','cjs','ts','jsx','tsx','json','md','txt','sh','bash','html','htm','css','py','yml','yaml','toml','conf','ini','env','log','svg','xml','csv','sql','desktop','gitignore']);

let srvPort = 0;
let startedAt = Date.now();
let activeAi = 0;
const termSet = new Set();
let cpuLast = null;

// ── CPU % via /proc/stat (delta entre deux lectures) ─────────────────
function cpuUsage() {
  try {
    const parts = fs.readFileSync('/proc/stat', 'utf8').split('\n')[0].trim().split(/\s+/).slice(1).map(Number);
    const idle = parts[3] + (parts[4] || 0);
    const total = parts.reduce(function (a, b) { return a + b; }, 0);
    let pct = 0;
    if (cpuLast) {
      const dTotal = total - cpuLast.total;
      const dIdle = idle - cpuLast.idle;
      pct = dTotal > 0 ? Math.round((1 - dIdle / dTotal) * 100) : 0;
    }
    cpuLast = { idle: idle, total: total };
    return Math.max(0, Math.min(100, pct));
  } catch (e) { return 0; }
}

function metrics() {
  const total = os.totalmem();
  const free = os.freemem();
  return {
    cpu: cpuUsage(),
    ramUsedGb: +(((total - free) / 1073741824).toFixed(1)),
    ramTotalGb: +((total / 1073741824).toFixed(1)),
    uptimeS: Math.round((Date.now() - startedAt) / 1000),
    terminalSessions: termSet.size,
    activeAi: activeAi,
    hostname: os.hostname(),
    platform: os.platform() + '/' + os.arch(),
    node: process.version
  };
}

function json(res, obj, code) {
  res.writeHead(code || 200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}

function sendFile(res, abs) {
  fs.readFile(abs, function (err, data) {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('404'); return; }
    const ext = path.extname(abs).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(data);
  });
}

function safePath(p) {
  const real = path.resolve(String(p || ''));
  if (real === HOME || real.indexOf(HOME + path.sep) === 0) return real;
  return null;
}

// ── API fichiers (graphe + éditeur) — limité au dossier maison ───────
function apiFiles(u, res) {
  const dir = safePath(u.searchParams.get('path') || HOME);
  if (!dir) return json(res, { error: 'chemin hors de ton espace utilisateur' }, 403);
  fs.readdir(dir, { withFileTypes: true }, function (err, entries) {
    if (err) return json(res, { error: err.code || String((err && err.message) || err) }, 400);
    const dirs = []; const files = [];
    entries.forEach(function (e) {
      if (e.name.charAt(0) === '.') return;
      if (e.isDirectory()) dirs.push(e.name);
      else if (e.isFile()) files.push(e.name);
    });
    const cmp = function (a, b) { return a.localeCompare(b); };
    json(res, { path: dir, dirs: dirs.sort(cmp), files: files.sort(cmp) });
  });
}

function apiFileRead(u, res) {
  const file = safePath(u.searchParams.get('path') || '');
  if (!file) return json(res, { error: 'chemin interdit' }, 403);
  fs.stat(file, function (err, st) {
    if (err || !st.isFile()) return json(res, { error: 'fichier introuvable' }, 404);
    if (st.size > 2 * 1024 * 1024) return json(res, { error: 'fichier > 2 Mo' }, 413);
    fs.readFile(file, 'utf8', function (e2, content) {
      if (e2) return json(res, { error: 'lecture impossible (binaire ?)' }, 415);
      json(res, { path: file, ext: path.extname(file).slice(1).toLowerCase(), content: content });
    });
  });
}

function apiFileSave(data, res) {
  const file = safePath(data.path || '');
  if (!file) return json(res, { ok: false, error: 'chemin interdit' }, 403);
  const ext = path.extname(file).slice(1).toLowerCase();
  if (ext && !TEXT_EXT.has(ext)) return json(res, { ok: false, error: 'extension non éditable : .' + ext }, 415);
  const content = String(data.content == null ? '' : data.content);
  if (content.length > 5 * 1024 * 1024) return json(res, { ok: false, error: 'contenu > 5 Mo' }, 413);
  fs.writeFile(file, content, function (e) {
    if (e) return json(res, { ok: false, error: e.code || String((e && e.message) || e) }, 400);
    remember('file', 'enregistré : ' + file);
    json(res, { ok: true, path: file, bytes: Buffer.byteLength(content) });
  });
}

// ── Aether Grid : état du projet P2P ─────────────────────────────────
function apiGrid(res) {
  const p2pPath = path.join(HOME, 'Bureau', 'aether-tout-en-un.sh');
  json(res, {
    node: os.hostname(),
    platform: os.platform() + '/' + os.arch(),
    p2p: { exists: fs.existsSync(p2pPath), path: p2pPath },
    phases: [
      { id: 0, name: 'Tunnel chiffré — 2 nœuds (libp2p)', status: 'planifié' },
      { id: 1, name: 'Tâches distribuées & collecte', status: 'planifié' },
      { id: 2, name: 'Calcul hétérogène — GPU / CPU / Edge', status: 'planifié' },
      { id: 3, name: 'Preuves ZK → blockchain', status: 'planifié' }
    ]
  });
}

// ── Fichiers statiques xterm depuis node_modules ─────────────────────
const VENDOR_MAP = {
  '/vendor/xterm.css': ['@xterm', 'xterm', 'css', 'xterm.css'],
  '/vendor/xterm.js': ['@xterm', 'xterm', 'lib', 'xterm.js'],
  '/vendor/addon-fit.js': ['@xterm', 'addon-fit', 'lib', 'addon-fit.js']
};
function sendVendor(p, res) {
  const rel = VENDOR_MAP[p];
  if (!rel) { res.writeHead(404); res.end(); return; }
  sendFile(res, path.join.apply(path, [ROOT, 'node_modules'].concat(rel)));
}

// ── Routeur HTTP ─────────────────────────────────────────────────────
function handler(req, res) {
  let u;
  try { u = new URL(req.url, 'http://127.0.0.1'); } catch (e) { res.writeHead(400); res.end(); return; }
  const p = u.pathname;
  if (req.method === 'GET' || req.method === 'HEAD') {
    if (p === '/' || p === '/index.html') return sendFile(res, path.join(UI_DIR, 'index.html'));
    if (p === '/api/health') return json(res, { ok: true, app: 'NEXUS AETHER', version: APP_VERSION, port: srvPort, uptimeS: Math.round((Date.now() - startedAt) / 1000) });
    if (p === '/api/metrics') return json(res, metrics());
    if (p === '/api/files') return apiFiles(u, res);
    if (p === '/api/file') return apiFileRead(u, res);
    if (p === '/api/plugins') return json(res, loadConfig());
    if (p === '/api/memory') return json(res, { items: getMemory(100) });
    if (p === '/api/grid/status') return apiGrid(res);
    if (p.indexOf('/vendor/') === 0) return sendVendor(p, res);
    if (p.indexOf('/ui/') === 0) return sendFile(res, path.join(UI_DIR, p.slice(4)));
    if (p.indexOf('/assets/') === 0) return sendFile(res, path.join(ROOT, p.slice(1)));
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('NEXUS AETHER — 404');
    return;
  }
  if (req.method === 'POST') {
    const chunks = [];
    let size = 0;
    req.on('data', function (c) { size += c.length; if (size <= 8 * 1024 * 1024) chunks.push(c); });
    req.on('end', function () {
      handlePost(p, Buffer.concat(chunks).toString('utf8'), res).catch(function (e) {
        json(res, { ok: false, error: String((e && e.message) || e) }, 500);
      });
    });
    return;
  }
  res.writeHead(405); res.end();
}

async function handlePost(p, body, res) {
  let data = {};
  try { data = JSON.parse(body || '{}'); } catch (e) {}
  if (p === '/api/ai') {
    const msgs = (Array.isArray(data.messages) && data.messages.length)
      ? data.messages
      : [{ role: 'user', content: String(data.prompt || '') }];
    let lastUser = '';
    for (let i = msgs.length - 1; i >= 0; i--) { if (msgs[i] && msgs[i].role === 'user') { lastUser = String(msgs[i].content || ''); break; } }
    activeAi += 1;
    try {
      const out = await chat(msgs, data.provider ? { providerId: data.provider } : {});
      remember('ai', 'Q: ' + lastUser.slice(0, 500) + '\nA: ' + String(out.text).slice(0, 800));
      json(res, { ok: true, text: out.text, provider: out.provider });
    } catch (e) {
      json(res, { ok: false, error: String((e && e.message) || e) });
    } finally {
      activeAi -= 1;
    }
    return;
  }
  if (p === '/api/file') return apiFileSave(data, res);
  if (p === '/api/plugins/active') {
    const cfg = loadConfig();
    const id = String(data.id || '');
    const found = (cfg.providers || []).some(function (x) { return x.id === id; });
    if (!found) return json(res, { ok: false, error: 'fournisseur inconnu : ' + id });
    cfg.active = id;
    saveConfig(cfg);
    return json(res, { ok: true, active: id });
  }
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('404');
}

// ── VRAI terminal : pty réel via util-linux « script » ───────────────
// Aucun module natif (node-pty) ⇒ aucune compilation, aucun problème d'ABI.
// Le pty de « script » donne couleurs, Ctrl-C, vim, htop, TAB… tout.
function createTerminal(cols, rows) {
  const shell = (process.env.SHELL && fs.existsSync(process.env.SHELL)) ? process.env.SHELL : 'bash';
  let proc;
  if (fs.existsSync('/usr/bin/script')) {
    proc = spawn('/usr/bin/script', ['-qfc', shell, '/dev/null'], {
      cwd: HOME,
      env: Object.assign({}, process.env, { TERM: 'xterm-256color', COLORTERM: 'truecolor' })
    });
  } else {
    proc = spawn(shell, ['-i'], { cwd: HOME, env: process.env });
  }
  const handle = {
    proc: proc,
    write: function (d) { try { proc.stdin.write(d); } catch (e) {} },
    resize: function (c, r) { try { proc.stdin.write('stty rows ' + r + ' cols ' + c + '; clear\n'); } catch (e) {} },
    kill: function () {
      try { proc.kill('SIGHUP'); } catch (e) {}
      setTimeout(function () { try { proc.kill('SIGKILL'); } catch (e) {} }, 500);
    },
    onData: function (cb) {
      proc.stdout.on('data', function (d) { cb(d.toString()); });
      proc.stderr.on('data', function (d) { cb(d.toString()); });
    },
    onExit: function (cb) { proc.on('exit', function (code) { cb(code); }); }
  };
  setTimeout(function () { handle.resize(cols || 100, rows || 30); }, 300);
  return handle;
}

function attachWs(server) {
  if (!WS) return null;
  const wss = new WS.Server({ noServer: true });
  server.on('upgrade', function (req, socket, head) {
    let pathname = '';
    let sp = new URLSearchParams();
    try {
      const uu = new URL(req.url, 'http://127.0.0.1');
      pathname = uu.pathname; sp = uu.searchParams;
    } catch (e) { socket.destroy(); return; }
    if (pathname !== '/terminal') { socket.destroy(); return; }
    wss.handleUpgrade(req, socket, head, function (ws) {
      const cols = parseInt(sp.get('cols') || '100', 10) || 100;
      const rows = parseInt(sp.get('rows') || '30', 10) || 30;
      const term = createTerminal(cols, rows);
      termSet.add(term);
      ws.on('message', function (raw) {
        const s = raw.toString();
        if (s.length < 48 && s.charCodeAt(0) === 123) { // '{' → message de contrôle JSON
          try {
            const j = JSON.parse(s);
            if (j && Array.isArray(j.resize) && j.resize.length === 2) { term.resize(j.resize[0], j.resize[1]); return; }
          } catch (e) { /* texte normal */ }
        }
        term.write(s);
      });
      term.onData(function (d) { try { if (ws.readyState === 1) ws.send(d); } catch (e) {} });
      term.onExit(function () { try { ws.close(); } catch (e) {} termSet.delete(term); });
      ws.on('close', function () { term.kill(); termSet.delete(term); });
      ws.on('error', function () {});
    });
  });
  return wss;
}

// ── Démarrage (repli automatique sur le port suivant si occupé) ──────
function startServer(preferredPort) {
  return new Promise(function (resolve, reject) {
    let port = preferredPort;
    let tries = 0;
    const attempt = function () {
      const server = http.createServer(handler);
      const wss = attachWs(server);
      server.once('error', function (err) {
        if (err && err.code === 'EADDRINUSE' && tries < 20) {
          tries += 1; port += 1; setTimeout(attempt, 150);
        } else reject(err);
      });
      server.listen(port, '127.0.0.1', function () {
        srvPort = port;
        startedAt = Date.now();
        resolve({ port: port, server: server, wss: wss });
      });
    };
    attempt();
  });
}

module.exports = { startServer };

// Mode autonome / auto-test : node server/core.js [--smoke]
if (require.main === module) {
  const port = parseInt(process.env.AETHER_PORT || '8420', 10);
  if (process.argv.indexOf('--smoke') !== -1) {
    startServer(port).then(function (s) {
      fetch('http://127.0.0.1:' + s.port + '/api/health').then(function (r) { return r.json(); }).then(function (h) {
        if (h && h.ok) { console.log('SMOKE_OK port=' + s.port + ' version=' + h.version); process.exit(0); }
        console.log('SMOKE_FAIL health=' + JSON.stringify(h)); process.exit(1);
      }).catch(function (e) { console.log('SMOKE_FAIL ' + String((e && e.message) || e)); process.exit(1); });
    }).catch(function (e) { console.log('SMOKE_FAIL ' + String((e && e.message) || e)); process.exit(1); });
  } else {
    startServer(port).then(function (s) { console.log('[nexus-aether] cœur serveur prêt sur http://127.0.0.1:' + s.port); });
  }
}
AE_CORE
ok "server/core.js — HTTP+WS, port donné + repli auto, pty réel, API fichiers/IA/mémoire/grid"

cat > core/router.js <<'AE_ROUTER'
'use strict';
// NEXUS AETHER — routeur IA « truc maître » : branche N'IMPORTE QUELLE IA.
//  · type "port"   → service local (Ollama sur 127.0.0.1:11434)
//  · type "openai" → toute API compatible OpenAI (GLM/Z.ai, OpenAI, Mistral…)
//  · type "gemini" → Google Gemini
// Config : ~/.aether/plugins.json (créé au premier réglage) sinon celui de l'app.
const fs = require('fs');
const path = require('path');
const os = require('os');

const CONF_DIR = path.join(os.homedir(), '.aether');
const USER_FILE = path.join(CONF_DIR, 'plugins.json');
const BUNDLED_FILE = path.join(__dirname, '..', 'config', 'plugins.json');

function loadConfig() {
  try { if (fs.existsSync(USER_FILE)) return JSON.parse(fs.readFileSync(USER_FILE, 'utf8')); } catch (e) {}
  try { return JSON.parse(fs.readFileSync(BUNDLED_FILE, 'utf8')); } catch (e) {}
  return { active: '', providers: [] };
}

function saveConfig(cfg) {
  fs.mkdirSync(CONF_DIR, { recursive: true });
  fs.writeFileSync(USER_FILE, JSON.stringify(cfg, null, 2) + '\n');
}

async function readJson(res) {
  const t = await res.text();
  try { return JSON.parse(t); } catch (e) {
    throw new Error('réponse non-JSON (' + res.status + ') : ' + t.slice(0, 200));
  }
}

async function chat(messages, opts) {
  const cfg = loadConfig();
  const providers = cfg.providers || [];
  const id = (opts && opts.providerId) || cfg.active;
  const p = providers.find(function (x) { return x.id === id; }) || providers[0];
  if (!p) throw new Error('aucun fournisseur IA — configure ~/.aether/plugins.json');
  const key = p.key || (p.keyEnv ? (process.env[p.keyEnv] || '') : '');

  if (p.type === 'port') {
    // Service local (Ollama). url ex : http://127.0.0.1:11434
    let res;
    try {
      res = await fetch(p.url.replace(/\/+$/, '') + '/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: p.model, messages: messages, stream: false })
      });
    } catch (e) {
      throw new Error('service local injoignable sur ' + p.url + ' — est-il lancé ? (' + String((e && e.message) || e) + ')');
    }
    const j = await readJson(res);
    if (j.error) throw new Error('port ' + p.url + ' : ' + ((j.error && j.error.message) || j.error));
    return { text: (j.message && j.message.content) || JSON.stringify(j).slice(0, 400), provider: p.id };
  }

  if (p.type === 'gemini') {
    if (!key) throw new Error('clé Gemini absente — export ' + (p.keyEnv || 'AETHER_GEMINI_KEY') + '=…');
    const url = p.url.replace(/\/+$/, '') + '/models/' + p.model + ':generateContent?key=' + encodeURIComponent(key);
    const sys = messages.find(function (m) { return m.role === 'system'; });
    const contents = messages.filter(function (m) { return m.role !== 'system'; }).map(function (m) {
      return { role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: String(m.content) }] };
    });
    const body = { contents: contents };
    if (sys) body.systemInstruction = { parts: [{ text: String(sys.content) }] };
    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await readJson(res);
    if (j.error) throw new Error('Gemini : ' + ((j.error && j.error.message) || JSON.stringify(j.error).slice(0, 200)));
    const parts = (j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || [];
    return { text: parts.map(function (x) { return x.text || ''; }).join('') || '(réponse vide)', provider: p.id };
  }

  // type "openai" (défaut) — GLM, OpenAI, Mistral, LM Studio… toutes compatibles
  if (!p.url) throw new Error('fournisseur « ' + (p.name || p.id) + ' » : url manquante dans ~/.aether/plugins.json');
  if (!key) throw new Error('fournisseur « ' + (p.name || p.id) + ' » : clé absente — export ' + (p.keyEnv || 'AETHER_CUSTOM_KEY') + '=…');
  const res = await fetch(p.url.replace(/\/+$/, ''), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
    body: JSON.stringify({ model: p.model, messages: messages, stream: false, temperature: 0.7 })
  });
  const j = await readJson(res);
  if (j.error) throw new Error('API : ' + ((j.error && j.error.message) || JSON.stringify(j.error).slice(0, 200)));
  const txt = (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '';
  return { text: txt || '(réponse vide)', provider: p.id };
}

module.exports = { chat: chat, loadConfig: loadConfig, saveConfig: saveConfig };
AE_ROUTER
ok "core/router.js — plugin IA universel : port local (Ollama) ou API (GLM/Gemini/custom)"

cat > core/memory.js <<'AE_MEM'
'use strict';
// NEXUS AETHER — mémoire vivante : journal JSONL de tout ce qui compte.
const fs = require('fs');
const path = require('path');
const os = require('os');

const FILE = path.join(os.homedir(), '.aether', 'memory.jsonl');

function remember(kind, text) {
  try {
    fs.mkdirSync(path.dirname(FILE), { recursive: true });
    fs.appendFileSync(FILE, JSON.stringify({
      ts: new Date().toISOString(),
      kind: kind,
      text: String(text).slice(0, 4000)
    }) + '\n');
  } catch (e) { /* mémoire non bloquante */ }
}

function getMemory(n) {
  try {
    const lines = fs.readFileSync(FILE, 'utf8').trim().split('\n').filter(Boolean);
    return lines.slice(-(n || 100)).map(function (l) {
      try { return JSON.parse(l); } catch (e) { return null; }
    }).filter(Boolean);
  } catch (e) { return []; }
}

module.exports = { remember: remember, getMemory: getMemory };
AE_MEM
ok "core/memory.js — mémoire vivante (~/.aether/memory.jsonl)"
