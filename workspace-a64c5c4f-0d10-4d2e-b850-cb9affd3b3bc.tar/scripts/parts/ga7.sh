
# ════════════════════════════════════════════════════════════════════
#  PARTIE G — service_hub.py : l'interface GEN HUB (Tk, thème nébuleuse)
# ════════════════════════════════════════════════════════════════════

cat > "$APP_DIR/service_hub.py" <<'HUBPY'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS GEN HUB v2.0 — 142 services de génération RÉELS + IA cléless.
Usage : python3 service_hub.py [--selftest]
"""
import json
import os
import queue
import subprocess
import sys
import threading
import time
import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import tkinter as tk            # noqa: E402
from tkinter import ttk         # noqa: E402
import nexus_services as NS   # noqa: E402
import nexus_llm as LLM       # noqa: E402

HUB = NS.HUB_DIR
OUT = NS.OUT_DIR
CONF = os.path.join(HUB, "config.json")
os.makedirs(OUT, exist_ok=True)


def load_conf():
    try:
        return json.load(open(CONF, encoding="utf-8"))
    except Exception:
        return {}


def save_conf(c):
    try:
        json.dump(c, open(CONF, "w", encoding="utf-8"), indent=1)
    except Exception:
        pass


C = {"bg": "#050510", "panel": "#0d0e1c", "panel2": "#111328", "line": "#1c2040",
     "txt": "#E8ECFF", "dim": "#8A90B8", "cyan": "#00E5FF", "mag": "#FF00C8",
     "green": "#00FF88", "red": "#FF5C7A", "yel": "#FFD166"}

ETAT_COLORS = {"✓": C["green"], "✓ POST": C["green"], "✓ local": C["green"],
               "clé": C["yel"], "limite": C["yel"], "éteint": C["dim"],
               "réseau": C["red"], "✗ 404": C["red"]}


def etat_color(e):
    for k, v in ETAT_COLORS.items():
        if e.startswith(k):
            return v
    return C["red"]


def open_file(path):
    try:
        subprocess.Popen(["xdg-open", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


class Hub:
    def __init__(self, root):
        self.root = root
        root.title("NEXUS GEN HUB v2.0 — %d services réels + IA cléless" % NS.N_SERVICES)
        root.geometry("1480x900")
        root.configure(bg=C["bg"])
        self.q = queue.Queue()
        self.current = None
        self.entries = {}
        self.status = {}
        self.photo = None
        self.bat_results = []
        self._build()
        self._log("NEXUS GEN HUB — %d services chargés. La vérité, c'est la BATTERIE : chaque service est testé en direct." % NS.N_SERVICES)
        self.root.after(120, self._poll)

    # ── construction UI ─────────────────────────────────────────────
    def _mk(self, parent, kind, **kw):
        kw.setdefault("bg", C["panel"])
        kw.setdefault("fg", C["txt"])
        return kind(parent, **kw)

    def _build(self):
        f = tk.Frame(self.root, bg=C["bg"])
        f.pack(fill="both", expand=True)

        # barre du haut
        top = tk.Frame(f, bg=C["panel"], height=46)
        top.pack(fill="x")
        tk.Label(top, text="  ⬡ NEXUS GEN HUB", bg=C["panel"], fg=C["cyan"],
                 font=("DejaVu Sans", 14, "bold")).pack(side="left")
        acc = NS.battery_summary([]) if False else {}
        counts = {}
        for s in NS.SERVICES:
            counts[s["acces"]] = counts.get(s["acces"], 0) + 1
        tk.Label(top, text="  %d services · %s" % (NS.N_SERVICES,
                 " · ".join("%d %s" % (v, k) for k, v in sorted(counts.items()))),
                 bg=C["panel"], fg=C["dim"], font=("DejaVu Sans", 10)).pack(side="left")
        tk.Button(top, text="⚡ DÉMO INVESTISSEUR (1 clic)", command=self.demo,
                  bg="#1a0f28", fg=C["mag"], activebackground="#2a1840", activeforeground=C["mag"],
                  relief="ridge", bd=1, font=("DejaVu Sans", 10, "bold")).pack(side="right", padx=8, pady=6)
        self.search = tk.Entry(top, bg=C["panel2"], fg=C["txt"], insertbackground=C["cyan"],
                               relief="flat", width=24, font=("DejaVu Sans", 10))
        self.search.pack(side="right", padx=8)
        self.search.insert(0, "filtrer…")
        self.search.bind("<FocusIn>", lambda e: (self.search.delete(0, "end")) if self.search.get() == "filtrer…" else None)
        self.search.bind("<KeyRelease>", lambda e: self.refresh_list())

        corps = tk.Frame(f, bg=C["bg"])
        corps.pack(fill="both", expand=True)

        # gauche : catégories + services
        left = tk.Frame(corps, bg=C["panel"], width=300)
        left.pack(side="left", fill="y", padx=(8, 4), pady=6)
        tk.Label(left, text="CATÉGORIES", bg=C["panel"], fg=C["dim"],
                 font=("DejaVu Sans", 9, "bold")).pack(anchor="w", padx=8, pady=(8, 2))
        self.cats = tk.Listbox(left, bg=C["panel2"], fg=C["txt"], selectbackground=C["cyan"],
                               selectforeground="#050510", relief="flat", height=8,
                               font=("DejaVu Sans", 9), exportselection=False)
        self.cats.pack(fill="x", padx=8)
        self.cats.insert(0, "TOUTES (%d)" % NS.N_SERVICES)
        for c in NS.CATS:
            n = sum(1 for s in NS.SERVICES if s["cat"] == c)
            if n:
                self.cats.insert("end", "%s (%d)" % (c, n))
        self.cats.bind("<<ListboxSelect>>", lambda e: self.refresh_list())
        tk.Label(left, text="SERVICES", bg=C["panel"], fg=C["dim"],
                 font=("DejaVu Sans", 9, "bold")).pack(anchor="w", padx=8, pady=(10, 2))
        self.tree = tk.Listbox(left, bg=C["panel2"], fg=C["txt"], selectbackground=C["cyan"],
                               selectforeground="#050510", relief="flat", font=("DejaVu Sans Mono", 9),
                               exportselection=False)
        self.tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.tree.bind("<<ListboxSelect>>", lambda e: self.pick())

        # droite : onglets
        right = tk.Frame(corps, bg=C["panel"], width=430)
        right.pack(side="right", fill="y", padx=(4, 8), pady=6)
        nb = ttk.Notebook(right)
        nb.pack(fill="both", expand=True, padx=6, pady=6)
        t1 = tk.Frame(nb, bg=C["panel2"]); nb.add(t1, text=" Console ")
        t2 = tk.Frame(nb, bg=C["panel2"]); nb.add(t2, text=" ⚡ Batterie live ")
        t3 = tk.Frame(nb, bg=C["panel2"]); nb.add(t3, text=" IA → YAML ")
        self.console = tk.Text(t1, bg="#07070f", fg=C["txt"], insertbackground=C["cyan"],
                               relief="flat", font=("DejaVu Sans Mono", 9), state="disabled", wrap="word")
        self.console.pack(fill="both", expand=True, padx=6, pady=6)
        self._build_bat(t2)
        self._build_ai(t3)

        # centre
        self.center = tk.Frame(corps, bg=C["panel"])
        self.center.pack(side="left", fill="both", expand=True, padx=4, pady=6)

        bottom = tk.Frame(self.root, bg=C["panel"], height=26)
        bottom.pack(fill="x")
        self.statusbar = tk.Label(bottom, text="prêt", bg=C["panel"], fg=C["dim"], anchor="w",
                                  font=("DejaVu Sans Mono", 9))
        self.statusbar.pack(side="left", padx=10)
        conf = load_conf()
        if conf.get("genedit_path") and os.path.exists(conf["genedit_path"]):
            tk.Button(bottom, text="↩ Ouvrir GenEdit v1", command=self.open_genedit,
                      bg=C["panel"], fg=C["cyan"], relief="flat",
                      activebackground=C["panel2"], activeforeground=C["cyan"],
                      font=("DejaVu Sans", 9)).pack(side="right", padx=8, pady=2)
        self.refresh_list()

    def _build_bat(self, t):
        row = tk.Frame(t, bg=C["panel2"])
        row.pack(fill="x", padx=8, pady=8)
        self.bat_btn = tk.Button(row, text="⚡ TESTER LES %d SERVICES EN DIRECT" % NS.N_SERVICES,
                                 command=self.run_battery, bg="#102020", fg=C["green"],
                                 activebackground="#183828", activeforeground=C["green"],
                                 relief="ridge", bd=1, font=("DejaVu Sans", 10, "bold"))
        self.bat_btn.pack(side="left")
        self.bat_prog = ttk.Progressbar(row, mode="determinate", length=170)
        self.bat_prog.pack(side="left", padx=8)
        self.bat_stat = tk.Label(row, text="", bg=C["panel2"], fg=C["dim"], font=("DejaVu Sans Mono", 9))
        self.bat_stat.pack(side="left")
        cols = ("service", "etat", "ms")
        self.bat_tree = ttk.Treeview(t, columns=cols, show="headings", height=24)
        self.bat_tree.heading("service", text="service")
        self.bat_tree.heading("etat", text="état réel")
        self.bat_tree.heading("ms", text="ms")
        self.bat_tree.column("service", width=250)
        self.bat_tree.column("etat", width=90, anchor="center")
        self.bat_tree.column("ms", width=55, anchor="e")
        self.bat_tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        tk.Button(t, text="💾 Exporter le rapport (.json)", command=self.export_bat,
                  bg=C["panel"], fg=C["dim"], relief="flat",
                  activebackground=C["panel2"], font=("DejaVu Sans", 9)).pack(anchor="e", padx=8, pady=4)

    def _build_ai(self, t):
        row0 = tk.Frame(t, bg=C["panel2"])
        row0.pack(fill="x", padx=8, pady=(8, 4))
        tk.Label(row0, text="Moteur :", bg=C["panel2"], fg=C["dim"]).pack(side="left")
        self.ai_prov = ttk.Combobox(row0, values=["auto"] + [p["id"] for p in LLM.PROVIDERS],
                                    state="readonly", width=24)
        self.ai_prov.set("auto")
        self.ai_prov.pack(side="left", padx=6)
        tk.Label(row0, text="auto = Ollama local → Pollinations (sans clé)", bg=C["panel2"],
                 fg=C["dim"], font=("DejaVu Sans", 8)).pack(side="left")
        tk.Label(t, text="Décris le workflow que tu veux — il est GÉNÉRÉ par IA, aucun template :",
                 bg=C["panel2"], fg=C["txt"], font=("DejaVu Sans", 9)).pack(anchor="w", padx=8)
        self.ai_prompt = tk.Text(t, height=5, bg="#07070f", fg=C["txt"], insertbackground=C["cyan"],
                                 relief="flat", font=("DejaVu Sans Mono", 9))
        self.ai_prompt.pack(fill="x", padx=8, pady=4)
        self.ai_prompt.insert("1.0", "Un workflow qui génère une image d'orbe néon avec Pollinations FLUX, puis l'upload en artefact")
        row1 = tk.Frame(t, bg=C["panel2"])
        row1.pack(fill="x", padx=8)
        tk.Button(row1, text="✦ GÉNÉRER PAR IA", command=self.ai_generate,
                  bg="#1a1030", fg=C["mag"], activebackground="#2a1840", activeforeground=C["mag"],
                  relief="ridge", bd=1, font=("DejaVu Sans", 10, "bold")).pack(side="left")
        tk.Button(row1, text="💾 Enregistrer .yml", command=self.ai_save, bg=C["panel"],
                  fg=C["cyan"], relief="flat", activebackground=C["panel2"],
                  activeforeground=C["cyan"], font=("DejaVu Sans", 9)).pack(side="left", padx=6)
        tk.Button(row1, text="▶ Lancer dans GenEdit", command=self.open_genedit, bg=C["panel"],
                  fg=C["dim"], relief="flat", activebackground=C["panel2"], font=("DejaVu Sans", 9)).pack(side="left")
        self.ai_yaml = tk.Text(t, bg="#07070f", fg=C["green"], insertbackground=C["cyan"],
                               relief="flat", font=("DejaVu Sans Mono", 9), wrap="none")
        self.ai_yaml.pack(fill="both", expand=True, padx=8, pady=8)

    # ── liste / sélection ───────────────────────────────────────────
    def refresh_list(self):
        self.tree.delete(0, "end")
        self.view = []
        sel = self.cats.curselection()
        catf = None
        if sel:
            raw = self.cats.get(sel[0])
            if not raw.startswith("TOUTES"):
                catf = raw.rsplit(" (", 1)[0]
        q = self.search.get().lower().strip()
        if q == "filtrer…":
            q = ""
        for s in NS.SERVICES:
            if catf and s["cat"] != catf:
                continue
            if q and q not in (s["id"] + " " + s["nom"] + " " + s["cat"]).lower():
                continue
            badge = {"sans-clé": "○", "clé-gratuite": "◇", "local": "◆"}.get(s["acces"], "·")
            st = self.status.get(s["id"])
            mark = " " + st["etat"] if st else ""
            self.tree.insert("end", "%s %s — %s%s" % (badge, s["nom"], s["cat"], mark))
            self.view.append(s)

    def pick(self):
        sel = self.tree.curselection()
        if not sel:
            return
        s = self.view[sel[0]]
        self.current = s
        for w in self.center.winfo_children():
            w.destroy()
        head = tk.Frame(self.center, bg=C["panel"])
        head.pack(fill="x", padx=10, pady=(10, 4))
        tk.Label(head, text=s["nom"], bg=C["panel"], fg=C["txt"],
                 font=("DejaVu Sans", 13, "bold")).pack(anchor="w")
        tk.Label(head, text="%s · %s" % (s["cat"], s["acces"].upper()), bg=C["panel"],
                 fg=C["cyan"] if s["acces"] == "sans-clé" else C["yel"] if s["acces"] == "clé-gratuite" else C["dim"],
                 font=("DejaVu Sans", 9)).pack(anchor="w")
        tk.Label(head, text=s["desc"], bg=C["panel"], fg=C["dim"], wraplength=620,
                 justify="left", font=("DejaVu Sans", 9)).pack(anchor="w", pady=2)
        st = self.status.get(s["id"])
        if st:
            tk.Label(head, text="batterie : %s (%d ms)" % (st["etat"], st["ms"]), bg=C["panel"],
                     fg=etat_color(st["etat"]), font=("DejaVu Sans Mono", 9)).pack(anchor="w")
        pf = tk.Frame(self.center, bg=C["panel"])
        pf.pack(fill="x", padx=10)
        self.entries = {}
        for i, (key, default, label) in enumerate(s.get("params", [])):
            tk.Label(pf, text=label, bg=C["panel"], fg=C["dim"], width=22,
                     anchor="e", font=("DejaVu Sans", 9)).grid(row=i, column=0, sticky="e", pady=2, padx=(0, 6))
            e = tk.Entry(pf, bg=C["panel2"], fg=C["txt"], insertbackground=C["cyan"],
                         relief="flat", width=52, font=("DejaVu Sans Mono", 9))
            e.insert(0, default)
            e.grid(row=i, column=1, sticky="w", pady=2)
            self.entries[key] = e
        tk.Button(self.center, text="▶  GÉNÉRER MAINTENANT (appel réel)", command=self.generate,
                  bg="#0a2830", fg=C["cyan"], activebackground="#10384a", activeforeground=C["cyan"],
                  relief="ridge", bd=1, font=("DejaVu Sans", 11, "bold")).pack(anchor="w", padx=10, pady=8)
        mid = tk.Frame(self.center, bg=C["panel"])
        mid.pack(fill="both", expand=True, padx=10, pady=(0, 4))
        self.preview = tk.Label(mid, bg="#07070f", text="  résultat ici  ", fg=C["dim"],
                                font=("DejaVu Sans Mono", 10))
        self.preview.pack(fill="both", expand=True)
        btns = tk.Frame(self.center, bg=C["panel"])
        btns.pack(fill="x", padx=10, pady=(0, 8))
        tk.Button(btns, text="📂 Ouvrir le fichier", command=self.open_last,
                  bg=C["panel"], fg=C["dim"], relief="flat", activebackground=C["panel2"],
                  font=("DejaVu Sans", 9)).pack(side="left")
        tk.Button(btns, text="⧉ Copier le texte", command=self.copy_last,
                  bg=C["panel"], fg=C["dim"], relief="flat", activebackground=C["panel2"],
                  font=("DejaVu Sans", 9)).pack(side="left", padx=6)
        tk.Button(btns, text="⚙ Générer le workflow CI de ce service", command=self.service_ci,
                  bg=C["panel"], fg=C["cyan"], relief="flat", activebackground=C["panel2"],
                  activeforeground=C["cyan"], font=("DejaVu Sans", 9)).pack(side="left")
        self.last_result = None

    # ── génération d'un service ─────────────────────────────────────
    def generate(self):
        s = self.current
        if not s or self._busy("gen"):
            return
        p = {k: e.get() for k, e in self.entries.items()}
        self._set_status("génération via %s…" % s["id"])
        self._log("▶ %s — appel réel en cours…" % s["nom"])
        self.preview.config(image="", text="  génération en cours…  ", fg=C["cyan"])

        def work():
            t0 = time.time()
            try:
                res = s["run"](p)
            except Exception as e:
                res = NS.R("texte", ok=False, info="exception : %s" % str(e)[:200])
            res["_ms"] = int((time.time() - t0) * 1000)
            self.q.put(("gen", s, res))
        threading.Thread(target=work, daemon=True).start()

    def show_result(self, s, res):
        self.last_result = (s, res)
        ms = res.get("_ms", 0)
        if not res.get("ok"):
            self.preview.config(image="", fg=C["red"], font=("DejaVu Sans Mono", 10),
                                text="  ✗ ÉCHEC : %s\n  (les services gratuits tombent parfois — relance, ou choisis-en un autre)" % res.get("info", "?"))
            self._log("✗ %s — %s (%d ms)" % (s["id"], res.get("info", "?"), ms), C["red"])
            self._set_status("échec %s" % s["id"])
            return
        k = res["kind"]
        if k == "image" and res.get("path"):
            self._show_image(res["path"])
            self._log("✓ image générée : %s (%d ms, %s)" % (os.path.basename(res["path"]), ms, res.get("info", "")), C["green"])
        elif k == "audio" and res.get("path"):
            self.preview.config(image="", fg=C["green"], font=("DejaVu Sans Mono", 10),
                                text="  🔊 audio prêt :\n  %s\n  (bouton « Ouvrir le fichier » pour écouter)" % res["path"])
            self._log("✓ audio : %s (%d ms)" % (res["path"], ms), C["green"])
        else:
            txt = res.get("text", "") or json.dumps(res, ensure_ascii=False)[:4000]
            self.preview.config(image="", fg=C["txt"], font=("DejaVu Sans Mono", 9), justify="left",
                                text="  " + txt[:2200].replace("\n", "\n  "))
            self._log("✓ %s — %d ms — %s" % (s["id"], ms, res.get("info", "")), C["green"])
        self._set_status("✓ %s (%d ms)" % (s["id"], ms))

    def _show_image(self, path):
        ok = False
        try:
            from PIL import Image, ImageTk
            img = Image.open(path)
            img.thumbnail((560, 380))
            self.photo = ImageTk.PhotoImage(img)
            self.preview.config(image=self.photo, text="", bg="#07070f")
            ok = True
        except Exception:
            pass
        if not ok:
            try:
                self.photo = tk.PhotoImage(file=path)
                self.preview.config(image=self.photo, text="", bg="#07070f")
                ok = True
            except Exception:
                pass
        if not ok:
            self.preview.config(image="", fg=C["yel"], font=("DejaVu Sans Mono", 10),
                                text="  image enregistrée : %s\n  (aperçu complet : sudo apt install python3-pil)" % path)

    def open_last(self):
        if self.last_result and self.last_result[1].get("path"):
            open_file(self.last_result[1]["path"])

    def copy_last(self):
        if self.last_result and self.last_result[1].get("text"):
            self.root.clipboard_clear()
            self.root.clipboard_append(self.last_result[1]["text"])
            self._set_status("texte copié")

    # ── batterie ────────────────────────────────────────────────────
    def run_battery(self):
        if self._busy("bat"):
            return
        self.bat_btn.config(state="disabled")
        for i in self.bat_tree.get_children():
            self.bat_tree.delete(i)
        self._log("⚡ BATTERIE : test réel des %d services…" % NS.N_SERVICES, C["green"])

        def cb(done, total, item):
            self.q.put(("bat", done, total, item))

        def work():
            res = NS.battery(progress=cb)
            self.q.put(("batdone", res))
        threading.Thread(target=work, daemon=True).start()

    def battery_item(self, done, total, item):
        self.bat_prog["maximum"] = total
        self.bat_prog["value"] = done
        self.status[item["id"]] = item
        tag = item["etat"].split()[0] if item["etat"] else "?"
        self.bat_tree.insert("", "end", values=(item["nom"][:42], item["etat"], item["ms"]),
                             tags=(tag,))
        self.bat_tree.tag_configure("✓", foreground=C["green"])
        self.bat_tree.tag_configure("✗", foreground=C["red"])
        self.bat_tree.tag_configure("clé", foreground=C["yel"])
        self.bat_tree.tag_configure("limite", foreground=C["yel"])
        self.bat_tree.tag_configure("réseau", foreground=C["red"])
        if done % 12 == 0:
            self._set_status("batterie : %d/%d" % (done, total))

    def battery_done(self, res):
        self.bat_btn.config(state="normal")
        self.bat_results = res
        summ = NS.battery_summary(res)
        vifs = summ.get("✓", 0) + summ.get("✓ POST", 0) + summ.get("✓ local", 0)
        self.bat_stat.config(text="  ✓ %d vivants" % vifs, fg=C["green"])
        self._log("⚡ BATTERIE TERMINÉE : %s" % " · ".join("%s=%d" % kv for kv in sorted(summ.items())), C["green"])
        self._set_status("batterie terminée — %d services vivants" % vifs)

    def export_bat(self):
        if not self.bat_results:
            self._set_status("lance d'abord la batterie")
            return
        p = os.path.join(OUT, "rapport-batterie-%s.json" % datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
        json.dump({"date": datetime.datetime.now().isoformat(), "total": NS.N_SERVICES,
                   "resultats": self.bat_results}, open(p, "w", encoding="utf-8"), indent=1, ensure_ascii=False)
        self._log("💾 rapport : " + p, C["cyan"])

    # ── IA → YAML ───────────────────────────────────────────────────
    def ai_generate(self):
        if self._busy("ai"):
            return
        desc = self.ai_prompt.get("1.0", "end").strip()
        if not desc:
            self._log("décris d'abord le workflow voulu", C["yel"])
            return
        prov = self.ai_prov.get()
        self._set_status("l'IA génère le workflow (%s)…" % prov)
        self._log("✦ génération IA (%s) — %s" % (prov, desc[:80]), C["mag"])
        self.ai_yaml.delete("1.0", "end")
        self.ai_yaml.insert("1.0", "// l'IA écrit un workflow NOUVEAU…")

        def work():
            t0 = time.time()
            try:
                r = LLM.generate_yaml(desc, provider=prov)
            except Exception as e:
                r = {"ok": False, "erreur": str(e), "yaml": "", "provider": prov, "essais": []}
            r["_sec"] = round(time.time() - t0, 1)
            self.q.put(("ai", r))
        threading.Thread(target=work, daemon=True).start()

    def ai_done(self, r):
        self.ai_yaml.delete("1.0", "end")
        if r.get("ok"):
            self.ai_yaml.insert("1.0", r["yaml"])
            prov = r.get("provider", "?")
            sans_cle = "SANS CLÉ" if "pollinations" in prov or prov == "ollama" else ""
            self._log("✦ YAML GÉNÉRÉ PAR IA via %s en %ss %s — 0 template utilisé" % (prov, r.get("_sec", "?"), sans_cle), C["mag"])
            self._set_status("workflow généré par IA (%s)" % prov)
            self.last_yaml = r["yaml"]
        else:
            self.ai_yaml.insert("1.0", "// ÉCHEC génération : %s" % r.get("erreur"))
            self._log("✦ échec IA : %s" % r.get("erreur"), C["red"])

    def ai_save(self):
        txt = self.ai_yaml.get("1.0", "end").strip()
        if not txt or txt.startswith("// ÉCHEC"):
            self._set_status("rien à enregistrer")
            return
        wdir = load_conf().get("workflows_dir") or os.path.expanduser("~/Bureau")
        if not os.path.isdir(wdir):
            wdir = os.path.expanduser("~")
        name = "nexus-ia-%s.yml" % datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        p = os.path.join(wdir, name)
        open(p, "w", encoding="utf-8").write(txt + "\n")
        self._log("💾 workflow IA enregistré : %s" % p, C["cyan"])
        self._set_status("enregistré : " + name)

    def service_ci(self):
        s = self.current
        if not s:
            return
        js = s["id"].replace("-", "_")
        y = "# Workflow GÉNÉRÉ par NEXUS GEN HUB pour le service réel : %s\n" % s["nom"]
        y += "# Service gratuit : %s\n" % s["desc"].split("\n")[0]
        y += "name: NEXUS-HUB %s\n" % s["id"]
        y += "on: [push, workflow_dispatch]\njobs:\n  test-%s:\n    runs-on: ubuntu-latest\n    steps:\n" % js
        y += "      - uses: actions/checkout@v4\n"
        y += "      - name: Appel réel du service %s\n" % s["id"]
        y += "        run: |\n"
        y += '          code=$(curl -s -o /tmp/out.bin -w "%%{http_code}" --max-time 30 "%s")\n' % self._ci_url(s)
        y += '          echo "HTTP $code"\n          test "$code" = "200"\n'
        if s["genre"] in ("image", "audio"):
            y += "      - name: Publier l'artefact généré\n        uses: actions/upload-artifact@v4\n        with:\n          name: %s-sortie\n          path: /tmp/out.bin\n" % js
        self.ai_yaml.delete("1.0", "end")
        self.ai_yaml.insert("1.0", y)
        self.last_yaml = y
        self._log("⚙ workflow CI du service %s construit — onglet IA → YAML" % s["id"], C["cyan"])

    def _ci_url(self, s):
        d = {k: v for k, v, _ in s.get("params", [])}
        pf = s.get("ping")
        if callable(pf):
            return "URL réelle du service (voir nexus_services.py : ping)"
        url = pf or ""
        try:
            return NS._fmt(url, d)
        except Exception:
            return url

    # ── démo investisseur ───────────────────────────────────────────
    def demo(self):
        if self._busy("demo"):
            return
        self._log("🎬 DÉMO INVESTISSEUR — 4 preuves de génération réelle, sans aucune clé", C["mag"])

        def work():
            steps = [
                ("1/4 · graphique IA de données", "g-quickchart",
                 {"type": "bar", "labels": "Rust,Go,C,Python", "valeurs": "9.2,8.7,8.1,8.8", "titre": "Langages 2026"}),
                ("2/4 · QR code du pitch", "qr-goqr", {"data": "https://nexus.aether", "taille": "300x300"}),
                ("3/4 · voix de synthèse", "tts-streamelements",
                 {"texte": "Bienvenue. Ce que vous voyez est généré en direct, sans aucune clé API.", "voix": "Brian"}),
                ("4/4 · image IA (flux → repli automatique)", "img-flux",
                 {"prompt": "cyberpunk orb, neon cyan and magenta, dark background, ultra detailed", "largeur": "768", "hauteur": "768"}),
            ]
            for label, sid, params in steps:
                self.q.put(("demo", None, None, label))
                s = next((x for x in NS.SERVICES if x["id"] == sid), None)
                if not s:
                    continue
                t0 = time.time()
                try:
                    res = s["run"](params)
                except Exception as e:
                    res = NS.R(s.get("genre", "texte"), ok=False, info=str(e)[:150])
                res["_ms"] = int((time.time() - t0) * 1000)
                self.q.put(("demo-res", s, res, label))
            self.q.put(("demo-ai",))
        threading.Thread(target=work, daemon=True).start()

    # ── utilitaires ─────────────────────────────────────────────────
    def open_genedit(self):
        conf = load_conf()
        gp = conf.get("genedit_path")
        if gp and os.path.exists(gp):
            subprocess.Popen(["python3", gp], cwd=os.path.dirname(gp),
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self._log("↩ GenEdit v1 lancé (intact — le hub l'accompagne)", C["cyan"])
        else:
            self._log("genedit.py introuvable dans la config", C["yel"])

    def _busy(self, tag):
        if getattr(self, "_busy_tag", None):
            self._set_status("opération en cours (%s)…" % self._busy_tag)
            return True
        self._busy_tag = tag
        return False

    def _free(self):
        self._busy_tag = None

    def _log(self, msg, color=None):
        self.console.config(state="normal")
        t = datetime.datetime.now().strftime("%H:%M:%S")
        self.console.insert("end", "[%s] %s\n" % (t, msg))
        if color:
            self.console.tag_add("last", "end-2l", "end-1l")
        self.console.see("end")
        self.console.config(state="disabled")

    def _set_status(self, msg):
        self.statusbar.config(text=msg)

    def _poll(self):
        try:
            while True:
                item = self.q.get_nowait()
                kind = item[0]
                if kind == "gen":
                    self._free()
                    self.show_result(item[1], item[2])
                elif kind == "bat":
                    self.battery_item(item[1], item[2], item[3])
                elif kind == "batdone":
                    self._free()
                    self.battery_done(item[1])
                elif kind == "ai":
                    self._free()
                    self.ai_done(item[1])
                elif kind == "demo":
                    self._log("🎬 " + item[3], C["mag"])
                    self._set_status(item[3])
                elif kind == "demo-res":
                    self.show_result(item[1], item[2])
                elif kind == "demo-ai":
                    self._free()
                    self._log("🎬 5/5 · génération du workflow par IA (Pollinations, sans clé)…", C["mag"])
                    desc = "Workflow GitHub Actions qui génère une image d'orbe néon via pollinations image API puis l'upload en artefact"
                    try:
                        r = LLM.generate_yaml(desc, provider="auto")
                    except Exception as e:
                        r = {"ok": False, "erreur": str(e)}
                    self.ai_done(r)
                    self._log("🎬 DÉMO TERMINÉE — tout est réel : graphique, QR, voix, image IA, workflow IA.", C["green"])
        except queue.Empty:
            pass
        self.root.after(120, self._poll)


def selftest():
    print("SELFTEST — %d services" % NS.N_SERVICES)
    assert NS.N_SERVICES >= 90, "catalogue < 90 !"
    cats = set(s["cat"] for s in NS.SERVICES)
    ids = set(s["id"] for s in NS.SERVICES)
    assert len(ids) == NS.N_SERVICES, "ids dupliqués !"
    missing_run = [s["id"] for s in NS.SERVICES if "run" not in s or not callable(s["run"])]
    assert not missing_run, "run manquant : %s" % missing_run
    res = NS.battery(NS.SERVICES[:8], workers=8, timeout=10)
    for r in res:
        print("  %-24s %-38s %s (%d ms)" % (r["id"], r["nom"][:36], r["etat"], r["ms"]))
    summ = NS.battery_summary(res)
    print("synthèse 8 premiers :", dict(summ))
    r = LLM.generate_yaml("Un workflow qui ping https://example.com et affiche le code HTTP", provider="pollinations-openai")
    print("IA YAML ok:", r["ok"], "| provider:", r["provider"])
    if r["ok"]:
        print(r["yaml"][:300])
    print("SELFTEST TERMINÉ")
    return 0


def main():
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    root = tk.Tk()
    try:
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook", background=C["panel"], foreground=C["txt"])
        style.configure("TNotebook.Tab", background=C["panel"], foreground=C["dim"], padding=(10, 4))
        style.map("TNotebook.Tab", background=[("selected", C["panel2"])], foreground=[("selected", C["cyan"])])
        style.configure("Treeview", background="#07070f", foreground=C["txt"], fieldbackground="#07070f")
        style.configure("TProgressbar", background=C["cyan"], troughcolor=C["panel2"])
        style.configure("TCombobox", fieldbackground=C["panel2"], background=C["panel2"], foreground=C["txt"])
    except Exception:
        pass
    Hub(root)
    root.mainloop()


if __name__ == "__main__":
    main()
HUBPY
python3 -m py_compile "$APP_DIR/service_hub.py" 2>/dev/null || true
ok "service_hub.py — hub complet : liste, params, génération, batterie, IA→YAML, démo 1-clic"
