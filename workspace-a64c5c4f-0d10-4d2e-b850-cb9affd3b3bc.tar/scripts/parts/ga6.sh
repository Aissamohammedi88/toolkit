
# ════════════════════════════════════════════════════════════════════
#  PARTIE E — nexus_llm.py : GÉNÉRATION IA réelle (cléless d'abord)
# ════════════════════════════════════════════════════════════════════

cat > "$APP_DIR/nexus_llm.py" <<'LLMF'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS GEN HUB — moteur de génération IA.
Priorité aux chaînes SANS CLÉ : Ollama local → Pollinations (GPT/Mistral/DeepSeek/Qwen).
Puis offres gratuites à clé : Groq, Mistral, Gemini, OpenRouter, GitHub Models…
Génère du YAML de workflow GitHub Actions réellement nouveau (aucun template pré-écrit).
"""
import json
import os
import re
import time
import urllib.error
import urllib.request

UA = "NEXUS-GenHub/2.0"


def _http(url, method="GET", headers=None, data=None, timeout=120):
    h = {"User-Agent": UA}
    if headers:
        h.update(headers)
    body = None
    if data is not None:
        body = data.encode("utf-8") if isinstance(data, str) else data
        h.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=body, headers=h, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.getcode(), r.read().decode("utf-8", "replace")


def _openai_chat(url, key, model, messages, timeout, extra=None):
    h = {"Content-Type": "application/json"}
    if key:
        h["Authorization"] = "Bearer " + key
    if extra:
        h.update(extra)
    st, txt = _http(url, method="POST", headers=h,
                    data=json.dumps({"model": model, "messages": messages}), timeout=timeout)
    if st >= 400:
        raise RuntimeError("HTTP %s : %s" % (st, txt[:200]))
    j = json.loads(txt)
    return j["choices"][0]["message"]["content"]


PROVIDERS = [
    {"id": "pollinations-openai", "nom": "Pollinations · GPT (SANS CLÉ)", "url": "https://text.pollinations.ai/openai", "model": "openai", "type": "keyless"},
    {"id": "pollinations-mistral", "nom": "Pollinations · Mistral (SANS CLÉ)", "url": "https://text.pollinations.ai/openai", "model": "mistral", "type": "keyless"},
    {"id": "pollinations-deepseek", "nom": "Pollinations · DeepSeek (SANS CLÉ)", "url": "https://text.pollinations.ai/openai", "model": "deepseek", "type": "keyless"},
    {"id": "pollinations-qwen-coder", "nom": "Pollinations · Qwen-Coder (SANS CLÉ)", "url": "https://text.pollinations.ai/openai", "model": "qwen-coder", "type": "keyless"},
    {"id": "ollama", "nom": "Ollama local", "url": "http://127.0.0.1:11434/api/chat", "model": "llama3", "type": "local"},
    {"id": "lmstudio", "nom": "LM Studio local", "url": "http://127.0.0.1:1234/v1/chat/completions", "model": "local-model", "type": "local"},
    {"id": "llamacpp", "nom": "llama.cpp local", "url": "http://127.0.0.1:8080/v1/chat/completions", "model": "local", "type": "local"},
    {"id": "groq", "nom": "Groq (clé gratuite)", "url": "https://api.groq.com/openai/v1/chat/completions", "model": "llama-3.3-70b-versatile", "type": "key", "env": "NEXUS_GROQ_KEY"},
    {"id": "mistral-api", "nom": "Mistral (clé gratuite)", "url": "https://api.mistral.ai/v1/chat/completions", "model": "mistral-small-latest", "type": "key", "env": "NEXUS_MISTRAL_KEY"},
    {"id": "gemini", "nom": "Gemini (clé gratuite)", "url": "https://generativelanguage.googleapis.com/v1beta", "model": "gemini-1.5-flash", "type": "gemini", "env": "NEXUS_GEMINI_KEY"},
    {"id": "openrouter", "nom": "OpenRouter :free (clé gratuite)", "url": "https://openrouter.ai/api/v1/chat/completions", "model": "meta-llama/llama-3.1-8b-instruct:free", "type": "key", "env": "NEXUS_OPENROUTER_KEY"},
    {"id": "github-models", "nom": "GitHub Models (token)", "url": "https://models.inference.ai.azure.com/chat/completions", "model": "gpt-4o-mini", "type": "key", "env": "NEXUS_GITHUB_TOKEN"},
    {"id": "cerebras", "nom": "Cerebras (clé gratuite)", "url": "https://api.cerebras.ai/v1/chat/completions", "model": "llama-3.3-70b", "type": "key", "env": "NEXUS_CEREBRAS_KEY"},
    {"id": "hf", "nom": "Hugging Face (token gratuit)", "url": "https://router.huggingface.co/v1/chat/completions", "model": "meta-llama/Llama-3.1-8B-Instruct", "type": "key", "env": "NEXUS_HF_KEY"},
]

AUTO_CHAIN = ["ollama", "pollinations-openai", "pollinations-mistral", "pollinations-deepseek", "pollinations-qwen-coder"]


def _by_pid(pid):
    for p in PROVIDERS:
        if p["id"] == pid:
            return p
    return None


def probe_ollama():
    try:
        st, _ = _http("http://127.0.0.1:11434/api/tags", timeout=2)
        return st == 200
    except Exception:
        return False


def chat_via(pid, messages, timeout=120):
    p = _by_pid(pid)
    if not p:
        raise RuntimeError("fournisseur inconnu : " + str(pid))
    if p["type"] in ("key", "keyless"):
        key = os.environ.get(p.get("env", ""), "")
        if p["type"] == "key" and not key:
            raise RuntimeError("clé absente — export %s=…" % p.get("env"))
        return _openai_chat(p["url"], key, p["model"], messages, timeout,
                            {"HTTP-Referer": "https://nexus.local", "X-Title": "NEXUS GenHub"} if pid == "openrouter" else None)
    if p["type"] == "gemini":
        key = os.environ.get(p.get("env", ""), "")
        if not key:
            raise RuntimeError("clé absente — export %s=…" % p.get("env"))
        sys_msgs = [m for m in messages if m["role"] == "system"]
        content_msgs = [m for m in messages if m["role"] != "system"]
        body = {"contents": [{"role": "user" if m["role"] == "user" else "model", "parts": [{"text": m["content"]}]} for m in content_msgs]}
        if sys_msgs:
            body["systemInstruction"] = {"parts": [{"text": sys_msgs[0]["content"]}]}
        st, txt = _http(p["url"] + "/models/" + p["model"] + ":generateContent?key=" + key,
                        method="POST", data=json.dumps(body), timeout=timeout)
        if st >= 400:
            raise RuntimeError("HTTP %s : %s" % (st, txt[:200]))
        j = json.loads(txt)
        return j["candidates"][0]["content"]["parts"][0]["text"]
    # local
    if p["type"] == "local":
        if pid == "ollama":
            st, txt = _http(p["url"], method="POST",
                            data=json.dumps({"model": p["model"], "messages": messages, "stream": False}), timeout=timeout)
            if st >= 400:
                raise RuntimeError("Ollama HTTP %s — lancé ? (ollama serve)" % st)
            return json.loads(txt)["message"]["content"]
        return _openai_chat(p["url"], "", p["model"], messages, timeout)
    raise RuntimeError("type inconnu")


def chat(messages, provider="auto", timeout=120):
    """Retourne (texte, provider_utilisé). Essaie la chaîne auto en cascade."""
    chain = [provider] if provider != "auto" else AUTO_CHAIN
    if provider == "auto" and not probe_ollama():
        chain = [c for c in chain if c != "ollama"]
    erreurs = []
    for pid in chain:
        try:
            t0 = time.time()
            txt = chat_via(pid, messages, timeout=timeout)
            if txt and txt.strip():
                return txt.strip(), pid, round(time.time() - t0, 1)
        except Exception as e:
            erreurs.append("%s: %s" % (pid, str(e)[:120]))
    raise RuntimeError("Aucun fournisseur IA joignable.\n" + "\n".join(" · " + e for e in erreurs))


SYSTEM_YAML = (
    "Tu es NEXUS GenHub, un générateur expert de workflows GitHub Actions.\n"
    "RÈGLES ABSOLUES :\n"
    "1. Réponds UNIQUEMENT avec UN workflow YAML complet. Aucun texte autour, aucun bloc markdown.\n"
    "2. Le YAML doit être NOUVEAU et taillé sur mesure pour la demande (jamais un template générique).\n"
    "3. Utilise actions/checkout@v4, actions/upload-artifact@v4. Trigger: [push, workflow_dispatch].\n"
    "4. Privilégie des services publics gratuits SANS clé (pollinations.ai image/texte, quickchart.io, "
    "api.qrserver.com, api.open-meteo.com, api.dicebear.com) via curl, et remonte les artefacts.\n"
    "5. Commente chaque step en français. YAML 100% valide (pas d'onglets, guillemets propres)."
)


def extract_yaml(text):
    m = re.search(r"```(?:ya?ml)?\s*\n(.*?)```", text, re.S)
    if m:
        text = m.group(1)
    text = text.strip()
    lines = text.splitlines()
    for i, l in enumerate(lines):
        if re.match(r"^(name|on|jobs)\s*:", l.strip()):
            return "\n".join(lines[i:]).strip()
    return text


def validate_yaml(text):
    try:
        import yaml
        j = yaml.safe_load(text)
        if not isinstance(j, dict):
            return "le YAML ne donne pas un dictionnaire"
        if "jobs" not in j:
            return "clé 'jobs:' absente"
        return None
    except ImportError:
        ok = re.search(r"^jobs\s*:", text, re.M) and re.search(r"^(name|on)\s*:", text, re.M)
        return None if ok else "structure de workflow non reconnue"
    except Exception as e:
        return "YAML invalide : %s" % str(e)[:150]


def generate_yaml(description, provider="auto", contexte=""):
    """Génère un workflow NOUVEAU. → dict(ok, yaml, provider, essais, erreur)"""
    user = "Demande : " + description.strip()
    if contexte:
        user += "\nContexte : " + contexte
    messages = [{"role": "system", "content": SYSTEM_YAML}, {"role": "user", "content": user}]
    essais = []
    last_err = None
    for attempt in range(1, 3):
        try:
            txt, pid, sec = chat(messages, provider=provider)
        except Exception as e:
            return {"ok": False, "yaml": "", "provider": provider, "essais": essais, "erreur": str(e)}
        y = extract_yaml(txt)
        err = validate_yaml(y)
        essais.append({"provider": pid, "secondes": sec, "valide": err is None})
        if err is None:
            return {"ok": True, "yaml": y, "provider": pid, "essais": essais, "erreur": None}
        last_err = err
        messages.append({"role": "assistant", "content": txt})
        messages.append({"role": "user", "content": "Ton YAML est invalide : %s\nRenvoie UNIQUEMENT le YAML corrigé complet." % err})
    return {"ok": False, "yaml": "", "provider": provider, "essais": essais, "erreur": last_err}


if __name__ == "__main__":
    import sys
    prov = sys.argv[1] if len(sys.argv) > 1 else "auto"
    desc = sys.argv[2] if len(sys.argv) > 2 else "Un workflow qui génère une image NEXUS via pollinations et l'upload en artefact"
    r = generate_yaml(desc, provider=prov)
    print("OK:", r["ok"], "| provider:", r["provider"], "| essais:", r["essais"])
    print(r["yaml"] or r["erreur"])
LLMF
ok "nexus_llm.py — génération IA : Ollama → Pollinations → 8 offres gratuites, YAML auto-corrigé"

# ════════════════════════════════════════════════════════════════════
#  PARTIE F — lanceurs, hook non-invasif, plugin exemple
# ════════════════════════════════════════════════════════════════════

cat > "$APP_DIR/genhub.sh" <<'HUBSH'
#!/usr/bin/env bash
# NEXUS GEN HUB — lanceur (142 services réels + IA)
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
exec python3 "$DIR/service_hub.py" "$@"
HUBSH
chmod +x "$APP_DIR/genhub.sh"
ok "genhub.sh — lanceur du hub"

cat > "$APP_DIR/nexus_hub_hook.py" <<'HOOKF'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pont NON-INVASIF pour l'éditeur GenEdit v1 existant.
Dans genedit.py, si tu veux un bouton « ⚡ GEN HUB » qui ouvre le hub :
ajoute ces 3 lignes juste avant mainloop() :

    try:
        import nexus_hub_hook; nexus_hub_hook.register(root)
    except Exception:
        pass

Rien n'est modifié automatiquement : ton fichier d'origine reste intact.
"""
import subprocess
import sys
import os

HERE = os.path.dirname(os.path.abspath(__file__))


def register(root):
    import tkinter as tk
    bar = getattr(root, "nexus_hub_btn", None)
    if bar is not None:
        return
    root.nexus_hub_btn = tk.Button(
        root, text="⚡ GEN HUB (142 services + IA)", command=launch_hub,
        bg="#0d0e1c", fg="#00E5FF", activebackground="#12304a",
        activeforeground="#00E5FF", relief="ridge", bd=1, font=("DejaVu Sans", 9, "bold"))
    root.nexus_hub_btn.pack(side="bottom", fill="x")


def launch_hub(event=None):
    subprocess.Popen([sys.executable, os.path.join(HERE, "service_hub.py")],
                     cwd=HERE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
HOOKF
ok "nexus_hub_hook.py — pont optionnel (3 lignes, jamais imposé)"

mkdir -p "$HOME/.nexus-hub/plugins"
cat > "$HOME/.nexus-hub/plugins/exemple-fox.py" <<'PLGF'
# PLUGIN NEXUS GEN HUB — exemple officiel d'extension.
# Tout fichier .py ici est chargé automatiquement : srv(...) l'ajoute au catalogue.
srv(id="plg-fox", nom="Random Fox · photos de renards", cat="AVATARS & ILLUSTRATIONS",
    acces="sans-clé", genre="image",
    desc="Plugin exemple : images de renards aléatoires (randomfox.ca).",
    params=[],
    run=lambda p: __import__("nexus_services").imgget("https://randomfox.ca/images/{n}.jpg")({"n": str(__import__("random").randint(1, 123))}),
    ping=lambda: __import__("nexus_services").http_req("https://randomfox.ca/floof/?image=1", timeout=10)[0])
PLGF
ok "~/.nexus-hub/plugins/exemple-fox.py — montre comment AJOUTER des services sans toucher au code"
