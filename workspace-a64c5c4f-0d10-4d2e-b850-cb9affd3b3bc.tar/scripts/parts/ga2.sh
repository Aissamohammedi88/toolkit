
# ════════════════════════════════════════════════════════════════════
#  PARTIE A — nexus_services.py (1/2) : moteur + IMAGE IA + TEXTE IA
# ════════════════════════════════════════════════════════════════════

cat > "$APP_DIR/nexus_services.py" <<'NS1'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS GEN HUB — catalogue de services de génération RÉELS (v2.0).
Chaque service est un vrai endpoint HTTP vivant : génération IA, TTS,
diagrammes, QR, graphiques, données… Priorité SANS-CLÉ, extensions par
plugins dans ~/.nexus-hub/plugins/*.py
"""
import base64
import glob
import json
import os
import random
import re
import shutil
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

HUB_DIR = os.path.expanduser("~/.nexus-hub")
OUT_DIR = os.path.join(HUB_DIR, "out")
os.makedirs(OUT_DIR, exist_ok=True)

UA = "NEXUS-GenHub/2.0 (editeur generatif local)"
BASE_HDRS = {"User-Agent": UA}
STREAM_HDRS = dict(BASE_HDRS, Origin="https://nexus-genhub.local", Referer="https://nexus-genhub.local/")

CATS = ["IMAGE IA", "TEXTE IA (sans-clé)", "TEXTE IA (local)", "TEXTE IA (clé gratuite)",
        "VOIX & AUDIO", "OCR & VISION", "TRADUCTION", "AVATARS & ILLUSTRATIONS",
        "IMAGES UTILES", "QR & CODES-BARRES", "GRAPHIQUES & DATA", "DIAGRAMMES",
        "GÉO & CARTES", "MÉTÉO & ENVIRONNEMENT", "ESPACE", "FINANCE & CRYPTO",
        "CONNAISSANCE & SCIENCE", "DÉV & PAQUETS", "MUSIQUE", "CONTENU & FUN",
        "DÉMOGRAPHIE", "COULEURS IA", "OUTILS WEB & PARTAGE"]

# ─────────────────────────────────────────────────────────────────────
#  Moteur HTTP
# ─────────────────────────────────────────────────────────────────────
def http_req(url, method="GET", headers=None, data=None, timeout=20):
    """→ (status:int, bytes, url_finale). data: dict(form) | str | bytes."""
    h = dict(BASE_HDRS)
    if headers:
        h.update(headers)
    body = None
    if data is not None:
        if isinstance(data, dict):
            body = urllib.parse.urlencode(data).encode("utf-8")
            h.setdefault("Content-Type", "application/x-www-form-urlencoded")
        elif isinstance(data, str):
            body = data.encode("utf-8")
        else:
            body = data
    req = urllib.request.Request(url, data=body, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.getcode(), r.read(), r.geturl()
    except urllib.error.HTTPError as e:
        try:
            return e.code, e.read(), url
        except Exception:
            return e.code, b"", url
    except Exception as e:
        return 0, str(e).encode("utf-8"), url


def http_json(url, method="GET", headers=None, data=None, timeout=20):
    st, b, u = http_req(url, method, headers, data, timeout)
    try:
        return st, json.loads(b.decode("utf-8", "replace")), u
    except Exception:
        return st, None, u


def _pick_str(j, path):
    cur = j
    for part in path.split("."):
        try:
            cur = cur[part]
        except Exception:
            try:
                cur = cur[int(part)]
            except Exception:
                return json.dumps(j, ensure_ascii=False, indent=1)
    if isinstance(cur, (dict, list)):
        return json.dumps(cur, ensure_ascii=False, indent=1)
    return str(cur)


def ts_name():
    return "gen-%d-%04d" % (int(time.time() * 1000), random.randint(0, 9999))


def save_out(name, data):
    path = os.path.join(OUT_DIR, name)
    with open(path, "wb") as f:
        f.write(data)
    return path


def R(kind, ok=True, **kw):
    d = {"ok": ok, "kind": kind}
    d.update(kw)
    return d


def _mp(fields, files):
    """multipart/form-data → (body bytes, headers dict)"""
    b = "----NEXUS%d" % random.randint(10 ** 9, 10 ** 10)
    parts = []
    for k, v in fields.items():
        parts.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n" % (b, k, v)).encode("utf-8"))
    for name, fn, blob in files:
        parts.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"; filename=\"%s\"\r\nContent-Type: application/octet-stream\r\n\r\n" % (b, name, fn)).encode("utf-8") + blob + b"\r\n")
    parts.append(("--%s--\r\n" % b).encode("utf-8"))
    return b"".join(parts), {"Content-Type": "multipart/form-data; boundary=" + b}


# ─────────────────────────────────────────────────────────────────────
#  Constructeurs d'exécution réutilisables
# ─────────────────────────────────────────────────────────────────────
def _fmt(urlf, p):
    """Remplit {xxx} et {xxx_quote} (version encodée URL de xxx)."""
    p = dict(p)
    for k in re.findall(r"\{(\w+_quote)\}", urlf):
        base = k[:-6]
        p[k] = urllib.parse.quote(str(p.get(base, "")), safe="")
    return urlf.format(**p)


def jget(urlf, pick=None, headers=None, timeout=18):
    """GET JSON. urlf formaté avec les params. pick: chemin pointé du résultat."""
    def _run(p):
        st, j, u = http_json(_fmt(urlf, p), headers=headers, timeout=timeout)
        if st == 0:
            return R("json", ok=False, info="réseau injoignable / service éteint", status=0)
        if st >= 400:
            return R("json", ok=False, info="HTTP %s" % st, status=st)
        txt = _pick_str(j, pick) if pick else json.dumps(j, ensure_ascii=False, indent=1)
        return R("json", status=st, text=txt[:20000], url=u)
    return _run


def imgget(urlf, ext="png", headers=None, timeout=60):
    """GET image binaire → fichier + aperçu."""
    def _run(p):
        st, b, u = http_req(_fmt(urlf, p), headers=headers, timeout=timeout)
        if st == 0:
            return R("image", ok=False, info="réseau injoignable", status=0)
        if st >= 400:
            return R("image", ok=False, info="HTTP %s — service gratuit saturé ou limité, réessaie" % st, status=st)
        if len(b) < 200:
            return R("image", ok=False, info="réponse vide", status=st)
        path = save_out(ts_name() + "." + ext, b)
        return R("image", path=path, status=st, info="%d o" % len(b), url=u)
    return _run


def aget(urlf, headers=None, timeout=40):
    """GET audio (mp3) → fichier jouable."""
    def _run(p):
        st, b, u = http_req(_fmt(urlf, p), headers=headers or STREAM_HDRS, timeout=timeout)
        if st == 0:
            return R("audio", ok=False, info="réseau injoignable", status=0)
        if st >= 400:
            return R("audio", ok=False, info="HTTP %s" % st, status=st)
        if len(b) < 500:
            return R("audio", ok=False, info="audio vide", status=st)
        path = save_out(ts_name() + ".mp3", b)
        return R("audio", path=path, status=st, info="%d o" % len(b), url=u)
    return _run


def tget(urlf, headers=None, timeout=18):
    """GET texte brut."""
    def _run(p):
        st, b, u = http_req(_fmt(urlf, p), headers=headers, timeout=timeout)
        if st == 0:
            return R("texte", ok=False, info="réseau injoignable", status=0)
        if st >= 400:
            return R("texte", ok=False, info="HTTP %s" % st, status=st)
        return R("texte", status=st, text=b.decode("utf-8", "replace")[:20000], url=u)
    return _run


def port_ping(port, timeout=0.6):
    def _p():
        try:
            s = socket.create_connection(("127.0.0.1", port), timeout=timeout)
            s.close()
            return 200
        except Exception:
            return 0
    return _p


def local_openai(port, path="/v1/chat/completions", model=None):
    def _run(p):
        body = {"messages": [{"role": "user", "content": p.get("prompt", "Bonjour")}], "max_tokens": 600}
        if model:
            body["model"] = model
        st, j, _ = http_json("http://127.0.0.1:%s%s" % (port, path), method="POST",
                             headers={"Content-Type": "application/json"},
                             data=json.dumps(body), timeout=120)
        if st == 0:
            return R("texte", ok=False, info="serveur local éteint sur le port %s" % port, status=0)
        if st >= 400 or not j:
            return R("texte", ok=False, info="HTTP %s — modèle chargé ?" % st, status=st)
        try:
            txt = j["choices"][0]["message"]["content"]
        except Exception:
            txt = json.dumps(j, ensure_ascii=False)[:2000]
        return R("texte", status=st, text=txt, info="modèle local")
    return _run


SERVICES = []


def srv(**kw):
    SERVICES.append(kw)
    return kw


def _q(t):
    return urllib.parse.quote(str(t), safe="")


# ─────────────────────────────────────────────────────────────────────
#  IMAGE IA (9)
# ─────────────────────────────────────────────────────────────────────
def _polli_img(model):
    def _run(p):
        url = ("https://image.pollinations.ai/prompt/" + _q(p.get("prompt", "orb néon"))
               + "?width=%s&height=%s&model=%s&nologo=true&seed=%s"
               % (p.get("largeur", "1024"), p.get("hauteur", "1024"), model, p.get("graine") or random.randint(1, 999999)))
        st, b, u = http_req(url, timeout=90)
        if st == 0:
            return R("image", ok=False, info="réseau injoignable", status=0)
        if st >= 400:
            return R("image", ok=False, info="HTTP %s — générateur gratuit saturé, réessaie ou passe par AI Horde" % st, status=st)
        if len(b) < 500:
            return R("image", ok=False, info="image vide", status=st)
        path = save_out(ts_name() + ".jpg", b)
        return R("image", path=path, status=st, info="%s — %d o (sans clé)" % (model, len(b)), url=u)
    return _run

IMG_PARAMS = [("prompt", "un orbe néon cyan et magenta sur fond noir, style NEXUS", "prompt"),
              ("largeur", "1024", "largeur"), ("hauteur", "1024", "hauteur"), ("graine", "", "graine (vide = aléatoire)")]

srv(id="img-flux", nom="Pollinations · FLUX.1", cat="IMAGE IA", acces="sans-clé", genre="image",
    desc="FLUX.1 (Black Forest Labs) servi gratuitement par Pollinations. Zéro clé, zéro compte.",
    params=IMG_PARAMS, run=_polli_img("flux"),
    ping=lambda: http_req("https://image.pollinations.ai/prompt/test?width=64&height=64&model=flux&nologo=true", timeout=12)[0])

srv(id="img-turbo", nom="Pollinations · Turbo (SDXL)", cat="IMAGE IA", acces="sans-clé", genre="image",
    desc="Turbo SDXL rapide via Pollinations. Peut passer en offre limitée aux heures de pointe.",
    params=IMG_PARAMS, run=_polli_img("turbo"),
    ping=lambda: http_req("https://image.pollinations.ai/prompt/test?width=64&height=64&model=turbo&nologo=true", timeout=12)[0])

srv(id="img-gptimage", nom="Pollinations · GPT-Image", cat="IMAGE IA", acces="sans-clé", genre="image",
    desc="GPT-Image via Pollinations (génération style GPT). Sans clé.",
    params=IMG_PARAMS, run=_polli_img("gptimage"),
    ping=lambda: http_req("https://image.pollinations.ai/prompt/test?width=64&height=64&model=gptimage&nologo=true", timeout=15)[0])

srv(id="img-kontext", nom="Pollinations · Kontext", cat="IMAGE IA", acces="sans-clé", genre="image",
    desc="Kontext : génération contextuelle via Pollinations. Sans clé.",
    params=IMG_PARAMS, run=_polli_img("kontext"),
    ping=lambda: http_req("https://image.pollinations.ai/prompt/test?width=64&height=64&model=kontext&nologo=true", timeout=15)[0])


def _horde_img(p):
    payload = {"prompt": p.get("prompt", "neon orb"), "params": {"n": 1, "width": 512, "height": 512, "steps": 20},
               "nsfw": False, "shared": False, "r2": True}
    st, b, _ = http_req("https://aihorde.net/api/v2/generate/async", method="POST",
                        headers={"apikey": "0000000000", "Content-Type": "application/json", "Client-Agent": UA},
                        data=json.dumps(payload), timeout=25)
    if st >= 400:
        return R("image", ok=False, info="HTTP %s (horde en charge ?)" % st, status=st)
    try:
        gid = json.loads(b.decode("utf-8")).get("id")
    except Exception:
        gid = None
    if not gid:
        return R("image", ok=False, info="pas d'id de tâche")
    done = False
    for _ in range(50):
        time.sleep(4)
        st2, b2, _ = http_req("https://aihorde.net/api/v2/generate/check/" + gid, headers={"Client-Agent": UA}, timeout=10)
        if st2 != 200:
            continue
        try:
            j2 = json.loads(b2.decode("utf-8"))
        except Exception:
            continue
        if j2.get("faulted"):
            return R("image", ok=False, info="tâche échouée sur la horde")
        if j2.get("done"):
            done = True
            break
    if not done:
        return R("image", ok=False, info="file d'attente > 3 min — réessaie plus tard")
    st3, b3, _ = http_req("https://aihorde.net/api/v2/generate/status/" + gid, headers={"Client-Agent": UA}, timeout=15)
    try:
        gens = json.loads(b3.decode("utf-8")).get("generations") or []
    except Exception:
        gens = []
    if not gens or not gens[0].get("img"):
        return R("image", ok=False, info="pas d'image renvoyée")
    st4, b4, _ = http_req(gens[0]["img"], timeout=60)
    if st4 >= 400 or len(b4) < 500:
        return R("image", ok=False, info="téléchargement de l'image échoué")
    return R("image", path=save_out(ts_name() + ".webp", b4), status=200, info="généré par la communauté AI Horde (gratuit, sans clé)")

srv(id="img-horde", nom="AI Horde · Stable Diffusion communautaire", cat="IMAGE IA", acces="sans-clé", genre="image",
    desc="Rendu par des GPU de volontaires. 100% gratuit, anonyme. File d'attente 1-3 min.",
    params=[("prompt", "a neon cyberpunk city, cinematic", "prompt")], run=_horde_img,
    ping=lambda: http_req("https://aihorde.net/api/v2/status/heartbeat", timeout=10)[0])

def _deepai_run(p):
    key = os.environ.get("NEXUS_DEEPAI_KEY", "")
    if not key:
        return R("image", ok=False, info="clé absente — export NEXUS_DEEPAI_KEY=… (compte gratuit deepai.org)")
    st, j, _ = http_json("https://api.deepai.org/api/text2img", method="POST",
                         headers={"api-key": key}, data={"text": p.get("prompt", "orb")}, timeout=60)
    if st >= 400 or not j or not j.get("output_url"):
        return R("image", ok=False, info="HTTP %s — %s" % (st, json.dumps(j)[:120] if j else "?"), status=st)
    st2, b2, _ = http_req(j["output_url"], timeout=60)
    return R("image", path=save_out(ts_name() + ".jpg", b2), status=st2, info="DeepAI")

srv(id="img-deepai", nom="DeepAI · Text2Image", cat="IMAGE IA", acces="clé-gratuite", genre="image",
    desc="Compte gratuit sur deepai.org puis export NEXUS_DEEPAI_KEY=…",
    params=IMG_PARAMS, run=_deepai_run,
    ping=lambda: http_req("https://api.deepai.org/", timeout=10)[0])

srv(id="img-hf-flux", nom="Hugging Face · FLUX.1-schnell", cat="IMAGE IA", acces="clé-gratuite", genre="image",
    desc="Token gratuit huggingface.co → export NEXUS_HF_KEY=… FLUX schnell (4 étapes, rapide).",
    params=IMG_PARAMS,
    run=lambda p: _hf_img("black-forest-labs/FLUX.1-schnell", p),
    ping=lambda: http_req("https://huggingface.co/api/models/black-forest-labs/FLUX.1-schnell", timeout=10)[0])


def _hf_img(model, p):
    key = os.environ.get("NEXUS_HF_KEY", "")
    if not key:
        return R("image", ok=False, info="clé absente — export NEXUS_HF_KEY=… (gratuit huggingface.co)")
    st, b, _ = http_req("https://api-inference.huggingface.co/models/" + model, method="POST",
                        headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"},
                        data=json.dumps({"inputs": p.get("prompt", "orb")}), timeout=90)
    if st >= 400:
        return R("image", ok=False, info="HTTP %s — %s" % (st, b[:120].decode("utf-8", "replace")), status=st)
    return R("image", path=save_out(ts_name() + ".png", b), status=st, info=model)

srv(id="img-hf-sdxl", nom="Hugging Face · SDXL 1.0", cat="IMAGE IA", acces="clé-gratuite", genre="image",
    desc="Stable Diffusion XL base via HF (token gratuit).",
    params=IMG_PARAMS,
    run=lambda p: _hf_img("stabilityai/stable-diffusion-xl-base-1.0", p),
    ping=lambda: http_req("https://huggingface.co/api/models/stabilityai/stable-diffusion-xl-base-1.0", timeout=10)[0])


def _fusion(p):
    k = os.environ.get("NEXUS_FUSION_KEY", "")
    s = os.environ.get("NEXUS_FUSION_SECRET", "")
    if not k or not s:
        return R("image", ok=False, info="clés absentes — exports NEXUS_FUSION_KEY / NEXUS_FUSION_SECRET (gratuit fusionbrain.ai)")
    st, b, _ = http_req("https://api-key.fusionbrain.ai/key/api/v1/text2image/run", method="POST",
                        headers={"X-Key": "Key " + k, "X-Secret": "Secret " + s, "Content-Type": "application/json"},
                        data=json.dumps({"params": {"type": "GENERATE", "width": 512, "height": 512, "generateParams": {},
                                                    "numImages": 1, "style": "DEFAULT"},
                                         "model_id": "4213791309", "query": p.get("prompt", "orb")}), timeout=60)
    if st >= 400:
        return R("image", ok=False, info="HTTP %s" % st, status=st)
    try:
        uid = json.loads(b.decode()).get("uuid")
    except Exception:
        uid = None
    if not uid:
        return R("image", ok=False, info="pas d'uuid")
    for _ in range(30):
        time.sleep(3)
        st2, b2, _ = http_req("https://api-key.fusionbrain.ai/key/api/v1/text2image/status/" + uid,
                              headers={"X-Key": "Key " + k, "X-Secret": "Secret " + s}, timeout=15)
        try:
            j2 = json.loads(b2.decode())
        except Exception:
            continue
        if j2.get("status") == "DONE":
            files = j2.get("images") or []
            if files:
                import base64 as b64
                return R("image", path=save_out(ts_name() + ".jpg", b64.b64decode(files[0])), status=200, info="Kandinsky (FusionBrain)")
            return R("image", ok=False, info="terminé sans image")
        if j2.get("status") == "FAIL":
            return R("image", ok=False, info="génération échouée côté serveur")
    return R("image", ok=False, info="délai dépassé")

srv(id="img-kandinsky", nom="FusionBrain · Kandinsky 3.1", cat="IMAGE IA", acces="clé-gratuite", genre="image",
    desc="Kandinsky (Sber). Clés gratuites sur fusionbrain.ai → NEXUS_FUSION_KEY / NEXUS_FUSION_SECRET.",
    params=IMG_PARAMS, run=_fusion,
    ping=lambda: http_req("https://fusionbrain.ai/", timeout=10)[0])
NS1
ok "nexus_services.py — moteur + IMAGE IA (9 services réels)"
