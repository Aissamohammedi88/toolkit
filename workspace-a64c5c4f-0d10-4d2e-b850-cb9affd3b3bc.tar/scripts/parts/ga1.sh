#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════
#  NEXUS GEN HUB v2.0 — UPGRADE TOUT-EN-UN
#  ──────────────────────────────────────────────────────────────────────
#  CE QUE ÇA FAIT :
#    · Ajoute à ton installation GenEdit EXISTANTE le GEN HUB :
#      ~140 services de génération RÉELS (IA image/texte/voix, diagrammes,
#      QR, graphiques, data…) + génération IA de workflows SANS template.
#  CE QUE ÇA NE FAIT PAS :
#    · Ça ne MODIFIE PAS et ne SUPPRIME JAMAIS genedit.py.
#      Preuve : empreinte SHA-256 avant / après, identique, affichée.
#      Sauvegarde complète dans backup-v1-<date>/ avant toute chose.
#  Ré-exécutable sans risque. Cible : Linux Mint · python3 + tkinter.
# ══════════════════════════════════════════════════════════════════════
set -euo pipefail

APP_TITLE="NEXUS GEN HUB"
APP_VERSION="2.0.0"
APP_DIR="${NEXUS_GENEDIT_DIR:-}"
HUB_FALLBACK="${HOME}/nexus-genhub"
SKIP_NET="${NEXUS_SKIP_NET:-0}"

C_CYAN="\033[1;36m"; C_MAG="\033[1;95m"; C_GRN="\033[1;32m"; C_YLW="\033[1;33m"
C_RED="\033[1;31m"; C_DIM="\033[2m"; C_B="\033[1m"; C_RST="\033[0m"
PASS=0; FAIL=0

ok()   { echo -e "  ${C_GRN}✓${C_RST} $1"; PASS=$((PASS+1)); }
ko()   { echo -e "  ${C_RED}✗${C_RST} $1"; FAIL=$((FAIL+1)); }
info() { echo -e "  ${C_DIM}·${C_RST} $1"; }
warn() { echo -e "  ${C_YLW}!${C_RST} $1"; }
phase(){ echo; echo -e "${C_MAG}━━━ PHASE $1/8 ━━━ ${C_CYAN}${C_B}$2${C_RST}"; }
chk()  { if eval "$2" >/dev/null 2>&1; then ok "$1"; else ko "$1"; fi }

echo
echo -e "${C_MAG}${C_B}"
cat <<'BANIERE'
   ╔══════════════════════════════════════════════════════════════╗
   ║   N E X U S   G E N   H U B   v 2 . 0   —   U P G R A D E    ║
   ║   Génération RÉELLE : IA sans clé + ~140 services vivants    ║
   ║   Optimise ton éditeur. Ne détruit RIEN. Preuves incluses.   ║
   ╚══════════════════════════════════════════════════════════════╝
BANIERE
echo -e "${C_RST}"

# ════════════════════════════════════════════════════════════════════
phase 1 "Environnement"
# ════════════════════════════════════════════════════════════════════
chk "python3" "command -v python3"
PYV="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null || echo 0)"
info "python $PYV"
chk "tkinter (interface graphique)" "python3 -c 'import tkinter'"
chk "curl" "command -v curl"
chk "PyYAML (validation IA renforcée)" "python3 -c 'import yaml'"
if [ "$SKIP_NET" = "1" ]; then
  warn "NEXUS_SKIP_NET=1 → vérification réseau sautée"
elif curl -sI --max-time 10 https://text.pollinations.ai/ >/dev/null 2>&1; then
  ok "Internet + Pollinations joignables (IA sans clé prête)"
else
  warn "Pollinations injoignable depuis CETTE sandbox/VPN — chez toi ça marchera (la batterie confirmera)"
fi

# ════════════════════════════════════════════════════════════════════
phase 2 "Localisation de GenEdit + SAUVEGARDE (non-destructif)"
# ════════════════════════════════════════════════════════════════════
GENEDIT=""
if [ -n "$APP_DIR" ] && [ -f "$APP_DIR/genedit.py" ]; then
  GENEDIT="$APP_DIR/genedit.py"
else
  for cand in "$HOME/Bureau/nexus-genedit" "$HOME/nexus-genedit" "$HOME/Desktop/nexus-genedit"; do
    if [ -f "$cand/genedit.py" ]; then GENEDIT="$cand/genedit.py"; break; fi
  done
fi
if [ -z "$GENEDIT" ]; then
  GENEDIT="$(find "$HOME" -maxdepth 4 -name genedit.py -not -path '*/.*' 2>/dev/null | head -1)"
fi
if [ -n "$GENEDIT" ]; then
  APP_DIR="$(cd "$(dirname "$GENEDIT")" && pwd)"
  ok "GenEdit v1 trouvé : $GENEDIT"
  SHA_BEFORE="$(sha256sum "$GENEDIT" | awk '{print $1}')"
  ok "empreinte SHA-256 AVANT : ${SHA_BEFORE:0:24}…"
  BK="$APP_DIR/backup-v1-$(date +%Y%m%d-%H%M%S)"
  mkdir -p "$BK"
  cp -a "$APP_DIR"/. "$BK"/ 2>/dev/null || true
  rm -rf "$BK/backup-v1-"* 2>/dev/null || true
  ok "sauvegarde complète : $BK"
else
  warn "genedit.py introuvable — le HUB sera installé en mode autonome dans $HUB_FALLBACK"
  APP_DIR="$HUB_FALLBACK"
  SHA_BEFORE=""
fi
mkdir -p "$APP_DIR"

# dossier des workflows (là où vivent les nexus-*.yml de GenEdit)
WDIR=""
for cand in "$APP_DIR" "$APP_DIR/workflows" "$HOME/Bureau" "$HOME/Bureau/workflows" "$HOME/Bureau/nexus-genedit/workflows"; do
  n="$( (ls "$cand"/nexus-*.yml 2>/dev/null || true) | wc -l )"
  if [ "${n:-0}" -ge 3 ]; then WDIR="$cand"; break; fi
done
[ -z "$WDIR" ] && WDIR="$(dirname "$GENEDIT" 2>/dev/null || echo "$HOME/Bureau")"
info "dossier workflows détecté : $WDIR"
mkdir -p "$HOME/.nexus-hub"
cat > "$HOME/.nexus-hub/config.json" <<CONFJ
{ "genedit_path": "${GENEDIT:-}", "app_dir": "$APP_DIR", "workflows_dir": "$WDIR", "version": "$APP_VERSION" }
CONFJ
ok "config : ~/.nexus-hub/config.json"
# ════════════════════════════════════════════════════════════════════
phase 3 "Écriture des modules (services · IA · hub)"
# ════════════════════════════════════════════════════════════════════
