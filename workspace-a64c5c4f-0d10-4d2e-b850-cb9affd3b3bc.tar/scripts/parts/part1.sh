#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════
#  NEXUS AETHER — TOUT-EN-UN BUREAU · v1.0.0
#  ──────────────────────────────────────────────────────────────────────
#  Crée, compile, installe et teste l'application desktop NEXUS AETHER :
#    · Interface nébuleuse WebGL + Glassmorphism 2.0 (identité exclusive)
#    · VRAI terminal fluide (pty réel via util-linux « script » + xterm.js)
#    · Serveur qui démarre AUTOMATIQUEMENT à l'ouverture (port 8420 donné)
#    · Plugins IA « truc maître » : Ollama (port), GLM (API), Gemini (API),
#      ou tout fournisseur compatible OpenAI
#    · Orbe de commande · Mode Deep Work · Mémoire vivante · Aether Grid (P2P)
#  Cible : Linux Mint · bash ≥ 5 · node ≥ 18 · npm ≥ 9
#  Ré-exécutable sans risque (fichiers régénérés, node_modules conservé).
#  Souverain : serveur lié à 127.0.0.1 uniquement, rien ne sort sans ta clé.
# ══════════════════════════════════════════════════════════════════════
set -euo pipefail

# ── Configuration ────────────────────────────────────────────────────
APP_TITLE="NEXUS AETHER"
APP_ID="nexus-aether"
APP_VERSION="1.0.0"
APP_DIR="${AETHER_DIR:-$HOME/Aether}"
PORT="${AETHER_PORT:-8420}"
SKIP_INSTALL="${AETHER_SKIP_INSTALL:-0}"
NO_DESKTOP="${AETHER_NO_DESKTOP:-0}"
P2P_SCRIPT="$HOME/Bureau/aether-tout-en-un.sh"
CONF_DIR="$HOME/.aether"

C_CYAN="\033[1;36m"; C_MAG="\033[1;95m"; C_GRN="\033[1;32m"; C_YLW="\033[1;33m"
C_RED="\033[1;31m"; C_DIM="\033[2m"; C_B="\033[1m"; C_RST="\033[0m"
PASS=0; FAIL=0

ok()   { echo -e "  ${C_GRN}✓${C_RST} $1"; PASS=$((PASS+1)); }
ko()   { echo -e "  ${C_RED}✗${C_RST} $1"; FAIL=$((FAIL+1)); }
info() { echo -e "  ${C_DIM}·${C_RST} $1"; }
warn() { echo -e "  ${C_YLW}!${C_RST} $1"; }
phase(){ echo; echo -e "${C_MAG}━━━ PHASE $1/8 ━━━ ${C_CYAN}${C_B}$2${C_RST}"; }
chk()  { if eval "$2" >/dev/null 2>&1; then ok "$1"; else ko "$1"; fi }

echo
echo -e "${C_MAG}${C_B}"
cat <<'BANIERE'
   ╔══════════════════════════════════════════════════════╗
   ║    N E X U S   A E T H E R   ·   B U R E A U         ║
   ║    Environnement immersif, souverain et conscient    ║
   ╚══════════════════════════════════════════════════════╝
BANIERE
echo -e "${C_RST}${C_DIM}   v$APP_VERSION · destination : $APP_DIR · port : $PORT${C_RST}"

# ════════════════════════════════════════════════════════════════════
phase 1 "Environnement"
# ════════════════════════════════════════════════════════════════════
if command -v node >/dev/null 2>&1; then ok "node $(node -v)"; else ko "node absent — installe Node 18+ puis relance"; fi
NODE_MAJOR="$(node -p 'parseInt(process.versions.node,10)' 2>/dev/null || echo 0)"
if [ "${NODE_MAJOR:-0}" -ge 18 ] 2>/dev/null; then ok "node ≥ 18 — OK"; else ko "node ≥ 18 requis (trouvé : ${NODE_MAJOR:-aucun}) — arrêt"; echo; exit 1; fi
if command -v npm >/dev/null 2>&1; then ok "npm $(npm -v)"; else ko "npm absent — installe npm puis relance"; fi
chk "git" "command -v git"
chk "curl" "command -v curl"
if [ -x /usr/bin/script ]; then ok "util-linux « script » — pty réel du terminal (aucun module natif à compiler)"
else warn "« script » absent — le terminal passera en mode dégradé (installe util-linux)"; fi
if [ "$SKIP_INSTALL" = "1" ]; then
  warn "AETHER_SKIP_INSTALL=1 → l'installation npm sera ignorée (mode test)"
elif curl -sI --max-time 10 https://registry.npmjs.org/ >/dev/null 2>&1; then
  ok "Internet joignable (registry.npmjs.org)"
else
  warn "Internet injoignable — l'étape Electron (~100 Mo) échouera si ça persiste"
fi
DISK_MB="$(df -Pm "$HOME" 2>/dev/null | tail -1 | awk '{print $4}')"
if [ "${DISK_MB:-0}" -ge 2048 ] 2>/dev/null; then ok "espace disque suffisant (${DISK_MB} Mo libres)"
else warn "espace disque faible (${DISK_MB:-?} Mo libres) — Electron + dépendances ≈ 600 Mo"; fi
if [ -f "$P2P_SCRIPT" ]; then
  ok "scaffold P2P détecté : $P2P_SCRIPT (affiché dans l'onglet Grid, JAMAIS modifié)"
else
  info "scaffold P2P absent du Bureau (l'onglet Grid le sondera en direct)"
fi

# ════════════════════════════════════════════════════════════════════
phase 2 "Génération de l'application (scaffold)"
# ════════════════════════════════════════════════════════════════════
mkdir -p "$APP_DIR"/{server,core,ui,config,assets,scripts,build}
cd "$APP_DIR"

cat > package.json <<'AE_PKG'
{
  "name": "nexus-aether",
  "productName": "NEXUS AETHER",
  "version": "1.0.0",
  "description": "Environnement de travail immersif, souverain et conscient",
  "main": "main.js",
  "private": true,
  "engines": { "node": ">=18" },
  "scripts": { "start": "electron ." },
  "dependencies": {
    "@xterm/addon-fit": "^0.10.0",
    "@xterm/xterm": "^5.5.0",
    "ws": "^8.17.1"
  },
  "devDependencies": {
    "electron": "^28.3.3"
  }
}
AE_PKG
ok "package.json — electron 28 · ws · xterm (PAS de module natif à compiler)"

cat > main.js <<'AE_MAIN'
'use strict';
// NEXUS AETHER — processus principal Electron.
// Ouvrir l'app ⇒ le serveur démarre AUTOMATIQUEMENT (port donné) PUIS la fenêtre.
const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const fs = require('fs');
const path = require('path');
const os = require('os');

app.setName('nexus-aether');

const CONF_DIR = path.join(os.homedir(), '.aether');
const PID_FILE = path.join(CONF_DIR, 'aether.pid');
const PORT = parseInt(process.env.AETHER_PORT || '8420', 10);
let win = null;

if (!app.requestSingleInstanceLock()) { app.quit(); }

app.on('second-instance', function () {
  if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); }
});

function createWindow(port) {
  win = new BrowserWindow({
    width: 1600,
    height: 940,
    minWidth: 1080,
    minHeight: 680,
    backgroundColor: '#050510',
    frame: false,
    title: 'NEXUS AETHER',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      backgroundThrottling: false
    }
  });
  win.setMenuBarVisibility(false);
  win.loadURL('http://127.0.0.1:' + port + '/?port=' + port);
  win.once('ready-to-show', function () { win.show(); });
  win.on('closed', function () { win = null; });
}

app.whenReady().then(async function () {
  const { startServer } = require('./server/core');
  try {
    const srv = await startServer(PORT);
    try {
      fs.mkdirSync(CONF_DIR, { recursive: true });
      fs.writeFileSync(PID_FILE, String(process.pid));
    } catch (e) { /* pidfile non bloquant */ }
    createWindow(srv.port);
    console.log('[nexus-aether] serveur prêt sur 127.0.0.1:' + srv.port);
  } catch (err) {
    dialog.showErrorBox('NEXUS AETHER', 'Le serveur n\u2019a pas pu démarrer :\n' + String((err && err.message) || err));
    app.quit();
  }
});

app.on('window-all-closed', function () { app.quit(); });
app.on('before-quit', function () { try { fs.unlinkSync(PID_FILE); } catch (e) {} });

ipcMain.on('win:minimize', function () { if (win) win.minimize(); });
ipcMain.on('win:maximize', function () { if (!win) return; if (win.isMaximized()) win.unmaximize(); else win.maximize(); });
ipcMain.on('win:close', function () { app.quit(); });
AE_MAIN
ok "main.js — fenêtre frameless + démarrage auto du serveur"

cat > preload.js <<'AE_PRE'
'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('aether', {
  isElectron: true,
  minimize: function () { ipcRenderer.send('win:minimize'); },
  maximize: function () { ipcRenderer.send('win:maximize'); },
  close: function () { ipcRenderer.send('win:close'); }
});
AE_PRE
ok "preload.js — pont sécurisé (contextIsolation)"
