
cat > scripts/aether-launch.sh <<'AE_LCH'
#!/usr/bin/env bash
# NEXUS AETHER — lanceur (utilisé par le raccourci Bureau et le menu)
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ELECTRON_BIN="$DIR/node_modules/.bin/electron"
if [ ! -x "$ELECTRON_BIN" ]; then
  echo "Electron absent — relance l'installateur ou fais : cd $DIR && npm install" >&2
  exit 1
fi
cd "$DIR"
export AETHER_PORT="${AETHER_PORT:-8420}"
mkdir -p "$HOME/.aether"
nohup "$ELECTRON_BIN" . >> "$DIR/aether.log" 2>&1 &
disown 2>/dev/null || true
echo "◉ NEXUS AETHER démarre — port $AETHER_PORT — log : $DIR/aether.log"
AE_LCH
chmod +x scripts/aether-launch.sh

cat > scripts/aether-stop.sh <<'AE_STP'
#!/usr/bin/env bash
# NEXUS AETHER — arrêt propre (fenêtre + serveur + sessions terminal)
PIDF="$HOME/.aether/aether.pid"
if [ -f "$PIDF" ]; then
  PID="$(cat "$PIDF" 2>/dev/null || true)"
  if [ -n "${PID:-}" ] && kill -0 "$PID" 2>/dev/null; then
    pkill -P "$PID" 2>/dev/null || true
    kill "$PID" 2>/dev/null || true
    echo "◉ NEXUS AETHER arrêté (pid $PID)"
  else
    echo "· pid $PID introuvable — nettoyage"
  fi
  rm -f "$PIDF"
else
  if pkill -f "$HOME/Aether/node_modules/electron" 2>/dev/null; then
    echo "◉ NEXUS AETHER arrêté (recherche par chemin)"
  else
    echo "· NEXUS AETHER ne semble pas tourner"
  fi
fi
AE_STP
chmod +x scripts/aether-stop.sh
ok "scripts/aether-launch.sh + aether-stop.sh"

cat > build/nexus-aether.desktop <<AE_DSK
[Desktop Entry]
Type=Application
Version=1.0
Name=NEXUS AETHER
GenericName=Environnement souverain
Comment=Terminal réel · nébuleuse vivante · IA locale ou API · port ${PORT}
Exec=${APP_DIR}/scripts/aether-launch.sh
Icon=${APP_DIR}/assets/aether.svg
Path=${APP_DIR}
Terminal=false
Categories=Development;Utility;
StartupNotify=true
StartupWMClass=nexus-aether
AE_DSK
ok "build/nexus-aether.desktop — entrée de menu prête"

info "scaffold complet : $(find "$APP_DIR" -type f -not -path '*/node_modules/*' -not -path '*/.git/*' | wc -l) fichiers générés dans $APP_DIR"

# ════════════════════════════════════════════════════════════════════
phase 3 "Compilation & dépendances (npm / Electron)"
# ════════════════════════════════════════════════════════════════════
cd "$APP_DIR"
if [ "$SKIP_INSTALL" = "1" ]; then
  warn "AETHER_SKIP_INSTALL=1 → npm ignoré (mode test — l'app ne se lancera pas encore)"
else
  info "npm install — Electron ≈ 100 Mo à télécharger, puis installation… patience"
  if npm install --no-audit --no-fund --loglevel=error; then
    ok "dépendances installées"
    chk "binaire Electron" "[ -x node_modules/.bin/electron ]"
    chk "xterm.js (terminal)" "[ -s node_modules/@xterm/xterm/lib/xterm.js ]"
    chk "addon-fit" "[ -s node_modules/@xterm/addon-fit/lib/addon-fit.js ]"
    chk "module ws (WebSocket)" "[ -d node_modules/ws ]"
  else
    ko "npm install — vérifie Internet puis relance ce script (il est ré-exécutable)"
  fi
fi

# ════════════════════════════════════════════════════════════════════
phase 4 "Validation de la syntaxe"
# ════════════════════════════════════════════════════════════════════
for f in main.js preload.js server/core.js core/router.js core/memory.js ui/nebula.js ui/terminal.js ui/app.js; do
  chk "node --check $f" "node --check '$APP_DIR/$f'"
done
chk "package.json (JSON valide)" "node -e \"JSON.parse(require('fs').readFileSync('$APP_DIR/package.json','utf8'))\""
chk "config/plugins.json (JSON valide)" "node -e \"JSON.parse(require('fs').readFileSync('$APP_DIR/config/plugins.json','utf8'))\""
chk "interface : orbe présente" "grep -q orbinput '$APP_DIR/ui/index.html'"
chk "style : palette nébuleuse" "grep -q -- '--cyan' '$APP_DIR/ui/style.css'"
chk "bash -n aether-launch.sh" "bash -n '$APP_DIR/scripts/aether-launch.sh'"
chk "bash -n aether-stop.sh" "bash -n '$APP_DIR/scripts/aether-stop.sh'"
chk "icône SVG non vide" "[ -s '$APP_DIR/assets/aether.svg' ]"

# ════════════════════════════════════════════════════════════════════
phase 5 "Test serveur réel (démarrage automatique sur le port donné)"
# ════════════════════════════════════════════════════════════════════
if [ "$FAIL" -gt 0 ]; then
  warn "échecs en amont — test serveur sauté"
else
  SMOKE_OUT="$(cd "$APP_DIR" && AETHER_PORT="$PORT" timeout 25 node server/core.js --smoke 2>&1 || true)"
  if printf '%s' "$SMOKE_OUT" | grep -q "SMOKE_OK"; then
    SMOKE_PORT="$(printf '%s' "$SMOKE_OUT" | sed -n 's/.*port=\([0-9]*\).*/\1/p')"
    ok "serveur démarré + /api/health OK (port réel : ${SMOKE_PORT:-?})"
    info "$SMOKE_OUT"
  else
    ko "test serveur — sortie : ${SMOKE_OUT:-<vide>}"
  fi
fi

# ════════════════════════════════════════════════════════════════════
phase 6 "Installation Bureau (icône + menu + git)"
# ════════════════════════════════════════════════════════════════════
chmod +x scripts/aether-launch.sh scripts/aether-stop.sh 2>/dev/null || true
if [ "$NO_DESKTOP" = "1" ]; then
  warn "AETHER_NO_DESKTOP=1 → raccourcis non installés (lancement : scripts/aether-launch.sh)"
else
  APPS_DIR="$HOME/.local/share/applications"
  mkdir -p "$APPS_DIR"
  cp build/nexus-aether.desktop "$APPS_DIR/nexus-aether.desktop"
  ok "menu des applications → NEXUS AETHER"
  DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Bureau")"
  mkdir -p "$DESKTOP_DIR"
  cp build/nexus-aether.desktop "$DESKTOP_DIR/nexus-aether.desktop"
  chmod +x "$DESKTOP_DIR/nexus-aether.desktop" 2>/dev/null || true
  if gio set "$DESKTOP_DIR/nexus-aether.desktop" metadata::trusted true 2>/dev/null; then
    ok "icône Bureau installée et marquée fiable : $DESKTOP_DIR/nexus-aether.desktop"
  else
    ok "icône Bureau créée : $DESKTOP_DIR/nexus-aether.desktop (si Mint demande : clic-droit → « Autoriser le lancement »)"
  fi
  if command -v desktop-file-validate >/dev/null 2>&1; then
    chk ".desktop valide" "desktop-file-validate '$APPS_DIR/nexus-aether.desktop'"
  else
    info "desktop-file-validate absent — validation ignorée (non bloquant)"
  fi
fi
if command -v git >/dev/null 2>&1; then
  if [ ! -d .git ]; then
    if git init -q -b main 2>/dev/null; then
      ok "dépôt git initialisé (dans $APP_DIR — pas dans le home)"
      git add -A 2>/dev/null || true
      if git config user.email >/dev/null 2>&1; then
        if git commit -q -m "NEXUS AETHER v1.0.0 — app bureau (nébuleuse + terminal réel + serveur auto + plugins IA)" 2>/dev/null; then
          ok "commit initial créé"
        else
          info "commit sauté (rien à valider)"
        fi
      else
        warn "git user.email non configuré — commit à faire plus tard : git -C $APP_DIR commit"
      fi
    else
      warn "git init a échoué (non bloquant)"
    fi
  else
    info "dépôt git déjà présent — fichiers mis à jour"
  fi
fi

# ════════════════════════════════════════════════════════════════════
phase 7 "Auto-test final"
# ════════════════════════════════════════════════════════════════════
echo
echo -e "  ${C_B}Bilan : ${C_GRN}$PASS réussis${C_RST} / ${C_RED}$FAIL échoués${C_RST}"
if [ "$FAIL" -eq 0 ]; then
  echo -e "  ${C_GRN}${C_B}✦ TOUT EST VERT — NEXUS AETHER est prêt.${C_RST}"
else
  echo -e "  ${C_YLW}Des échecs subsistent — corrige puis relance ce script (ré-exécutable sans risque).${C_RST}"
fi
echo
echo -e "  ${C_CYAN}${C_B}Fichiers clés${C_RST}"
echo -e "    ${C_DIM}·${C_RST} application     : $APP_DIR/main.js"
echo -e "    ${C_DIM}·${C_RST} serveur         : $APP_DIR/server/core.js"
echo -e "    ${C_DIM}·${C_RST} interface       : $APP_DIR/ui/index.html"
echo -e "    ${C_DIM}·${C_RST} plugins IA      : $CONF_DIR/plugins.json"
echo -e "    ${C_DIM}·${C_RST} mémoire vivante : $CONF_DIR/memory.jsonl"
echo -e "    ${C_DIM}·${C_RST} lanceur         : $APP_DIR/scripts/aether-launch.sh"
echo -e "    ${C_DIM}·${C_RST} arrêt           : $APP_DIR/scripts/aether-stop.sh"

# ════════════════════════════════════════════════════════════════════
phase 8 "Rapport & lancement"
# ════════════════════════════════════════════════════════════════════
cat <<AE_RPT

  Comment lancer :
    1. Menu des applications  →  NEXUS AETHER
    2. Icône sur le Bureau    →  double-clic
    3. Terminal               →  ~/Aether/scripts/aether-launch.sh
       (port personnalisé :   AETHER_PORT=9000 ~/Aether/scripts/aether-launch.sh)
    Arrêt : ~/Aether/scripts/aether-stop.sh

  À l'ouverture de l'app :
    · le serveur démarre AUTOMATIQUEMENT (port ${PORT}, repli 8421+ si occupé)
    · un VRAI terminal s'ouvre (pty réel : couleurs, vim, htop, Ctrl-C, TAB)
    · l'orbe en bas parle à l'IA maître (Ollama / GLM / Gemini / plugin)
    · !commande → terminal   ·   /help → commandes

  Brancher les IA (config ~/.aether/plugins.json) :
    · Ollama (local)  : lance « ollama serve »        → type "port"
    · GLM (Z.ai)      : export AETHER_GLM_KEY=…       → type "openai"
    · Gemini          : export AETHER_GEMINI_KEY=…    → type "gemini"
    · Autre / custom  : type "openai" + url + AETHER_CUSTOM_KEY
AE_RPT
if [ -f "$P2P_SCRIPT" ]; then
  echo -e "  ${C_DIM}·${C_RST} Scaffold P2P détecté : $P2P_SCRIPT — visible dans l'onglet ✦ Grid (aucune modification)."
fi
echo

LAUNCH_NOW="n"
if [ "${1:-}" = "--launch" ]; then
  LAUNCH_NOW="o"
elif [ -t 0 ]; then
  read -r -p "  Lancer NEXUS AETHER maintenant ? [o/N] " LAUNCH_NOW || LAUNCH_NOW="n"
fi
if [[ "$LAUNCH_NOW" == [oO]* ]]; then
  "$APP_DIR/scripts/aether-launch.sh" || true
  echo -e "  ${C_DIM}la fenêtre apparaît dans quelques secondes…${C_RST}"
fi

echo
if [ -t 0 ]; then
  echo -e "${C_DIM}— Appuie sur ENTRÉE pour fermer ce terminal —${C_RST}"
  read -r _
fi
echo

[ "$FAIL" -eq 0 ] && exit 0 || exit 1
