#!/usr/bin/env bash
# Assemble le paquet NEXUS GEN HUB · Plasma :
#  1. download/NEXUS-GENHUB-PLASMA.tar.gz          (source propre)
#  2. download/nexus-genhub-plasma-install.sh      (installateur autonome, payload embarqué)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STAGE="$(mktemp -d)"
PKG="nexus-genhub-plasma"

mkdir -p "$STAGE/$PKG"
cd "$ROOT"
cp -r src prisma public "$STAGE/$PKG/"
cp package.json tsconfig.json next.config.ts postcss.config.mjs components.json eslint.config.mjs README-NEXUS.md "$STAGE/$PKG/"
mkdir -p "$STAGE/$PKG/db/media"
touch "$STAGE/$PKG/db/media/.gitkeep"
# retire les artefacts éventuels
rm -rf "$STAGE/$PKG/src/app/api/route.ts" 2>/dev/null || true

tar czf "$ROOT/download/NEXUS-GENHUB-PLASMA.tar.gz" -C "$STAGE" "$PKG"
echo "tar.gz : $(du -h "$ROOT/download/NEXUS-GENHUB-PLASMA.tar.gz" | cut -f1)"

B64=$(base64 -w0 "$ROOT/download/NEXUS-GENHUB-PLASMA.tar.gz")
python3 - "$B64" <<'PY'
import sys
b64 = sys.argv[1]
tpl = open('/home/z/my-project/scripts/installer-template.sh').read()
# Le marqueur __NEXUS_PAYLOAD__ reste en place, le payload est ajouté APRÈS.
out = tpl.replace('__NEXUS_PAYLOAD__', '__NEXUS_PAYLOAD__\n' + b64)
open('/home/z/my-project/download/nexus-genhub-plasma-install.sh', 'w').write(out)
PY
chmod +x "$ROOT/download/nexus-genhub-plasma-install.sh"
echo "installateur : $(du -h "$ROOT/download/nexus-genhub-plasma-install.sh" | cut -f1)"

bash -n "$ROOT/download/nexus-genhub-plasma-install.sh" && echo "bash -n : OK (script avant payload)"
rm -rf "$STAGE"
