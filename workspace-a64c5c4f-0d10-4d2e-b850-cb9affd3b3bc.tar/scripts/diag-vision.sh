#!/usr/bin/env bash
set -u
export GENT_HOME=/tmp/gent-e2e
cd /tmp
PORT=43112 "$GENT_HOME/runtime/current/bin/node" --max-semi-space-size=64 "$GENT_HOME/app/gent-server.js" > /tmp/e2e.log 2>&1 &
for i in $(seq 1 40); do curl -fsS http://127.0.0.1:43112/api/health >/dev/null 2>&1 && break; sleep 0.3; done
echo "serveur : $(curl -s http://127.0.0.1:43112/api/health | head -c 60)"
agent-browser open http://127.0.0.1:43112/vision >/dev/null 2>&1
sleep 2
echo "=== errors ==="
agent-browser errors
echo "=== console ==="
agent-browser console
echo "=== fetch health depuis la page ==="
agent-browser eval 'fetch("/api/health").then(function(r){return r.status})'
echo "=== window.onerror capté ? ==="
agent-browser eval 'window.__e || "aucune capture"'
agent-browser close >/dev/null 2>&1
pkill -f gent-server.js 2>/dev/null
true
