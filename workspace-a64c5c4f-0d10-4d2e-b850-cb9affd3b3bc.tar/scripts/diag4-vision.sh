#!/usr/bin/env bash
set -u
export GENT_HOME=/tmp/gent-e2e
cd /tmp
PORT=43112 "$GENT_HOME/runtime/current/bin/node" --max-semi-space-size=64 "$GENT_HOME/app/gent-server.js" > /tmp/e2e.log 2>&1 &
for i in $(seq 1 40); do curl -fsS http://127.0.0.1:43112/api/health >/dev/null 2>&1 && break; sleep 0.3; done
agent-browser open http://127.0.0.1:43112/vision >/dev/null 2>&1
sleep 2
echo "== avant : $(agent-browser eval 'document.getElementById("tree").children.length') enfants"
agent-browser eval 'window.addEventListener("unhandledrejection",function(e){window.__rej=String(e.reason)}); tree(); "tree relancé"'
sleep 1.5
echo "== après tree() manuel : $(agent-browser eval 'document.getElementById("tree").children.length') enfants · rejet: $(agent-browser eval 'window.__rej || "aucun"')"
agent-browser eval 'load(); "load relancé"'
sleep 1
echo "== éditeur après load() manuel : $(agent-browser eval 'document.getElementById("editor").value.length') caractères"
echo "== uncaught ? $(agent-browser eval 'window.__errflag || "non"')"
agent-browser errors
agent-browser close >/dev/null 2>&1
pkill -f gent-server.js 2>/dev/null
true
