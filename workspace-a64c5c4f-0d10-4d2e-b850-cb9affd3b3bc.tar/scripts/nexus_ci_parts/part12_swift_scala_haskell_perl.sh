
# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 23 — SWIFT 🦅 (nouveau)
# Le seul template sur runner macOS (Xcode requis). xcodebuild test si
# projet .xcodeproj/.xcworkspace, sinon Swift Package Manager build+test.
# Artefacts xcresult uploadés pour diagnostic d'échec.
# ═════════════════════════════════════════════════════════════════════════════

inject_swift() {
    log_step "Injection du workflow NEXUS SWIFT (🦅)..."
    check_target "nexus-swift.yml"
    cat > "$WORKFLOWS_DIR/nexus-swift.yml" << 'NEXUS_SWIFT_YAML'
# ═══ NEXUS SWIFT — xcodebuild (macOS) ou SPM, xcresult en artefact ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🦅 NEXUS SWIFT"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-swift-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
jobs:
  build_and_test:
    name: "⚙️ Build & Test Swift"
    runs-on: macos-14
    timeout-minutes: 45
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Detect Project Type
        id: kind
        run: |
          if ls *.xcodeproj >/dev/null 2>&1 || ls *.xcworkspace >/dev/null 2>&1; then
            echo "kind=xcode" >> "$GITHUB_OUTPUT"
          elif [ -f "Package.swift" ]; then
            echo "kind=spm" >> "$GITHUB_OUTPUT"
          else
            echo "::error::Ni .xcodeproj ni Package.swift — Swift non détecté."
            exit 1
          fi
      - name: Select Xcode
        run: sudo xcode-select -s /Applications/Xcode.app
      - name: Xcode Build & Test
        if: steps.kind.outputs.kind == 'xcode'
        run: |
          SCHEME=$(xcodebuild -list -json \
            | jq -r '.project.schemes[0] // .workspace.schemes[0]')
          xcodebuild test \
            -scheme "$SCHEME" \
            -destination 'platform=macOS' \
            -resultBundlePath Test.xcresult \
            -enableCodeCoverage YES
      - name: SPM Build
        if: steps.kind.outputs.kind == 'spm'
        run: swift build -v
      - name: SPM Test
        if: steps.kind.outputs.kind == 'spm'
        run: swift test -v --enable-code-coverage
      - name: Upload xcresult
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: swift-xcresult
          path: "*.xcresult"
          if-no-files-found: ignore
      - name: Résumé Swift
        if: always()
        run: |
          {
            echo "## 🦅 NEXUS SWIFT"
            echo ""
            echo "- Runner macOS-14 (seul runner avec Xcode)"
            echo "- Mode : \`${{ steps.kind.outputs.kind }}\`"
            echo "- Couverture activée dans les deux modes"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_SWIFT_YAML
    report_injection "SWIFT" "nexus-swift.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 24 — SCALA 🔧 (nouveau)
# sbt compile + scalafmtCheckAll + test + scalafix. JVM 17 + Temurin.
# ═════════════════════════════════════════════════════════════════════════════

inject_scala() {
    log_step "Injection du workflow NEXUS SCALA (🔧)..."
    check_target "nexus-scala.yml"
    cat > "$WORKFLOWS_DIR/nexus-scala.yml" << 'NEXUS_SCALA_YAML'
# ═══ NEXUS SCALA — sbt, scalafmt, scalafix, tests ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🔧 NEXUS SCALA"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-scala-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  JAVA_VERSION: "17"
  JAVA_DISTRIBUTION: "temurin"
jobs:
  build_and_test:
    name: "⚙️ Build & Test Scala"
    runs-on: ubuntu-latest
    timeout-minutes: 40
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no sbt project)
        run: |
          if [ ! -f "build.sbt" ]; then
            echo "::error::Aucun build.sbt — projet sbt non détecté."
            exit 1
          fi
      - name: Setup Java
        uses: actions/setup-java@v4
        with:
          java-version: ${{ env.JAVA_VERSION }}
          distribution: ${{ env.JAVA_DISTRIBUTION }}
          cache: "sbt"
      - name: Format Check (scalafmt)
        run: sbt scalafmtCheckAll
      - name: Compile
        run: sbt compile
      - name: Fix Rules Check (scalafix)
        continue-on-error: true
        run: sbt 'scalafix --check'
      - name: Tests
        run: sbt test
      - name: Packaging Check
        run: sbt package
      - name: Résumé Scala
        if: always()
        run: |
          {
            echo "## 🔧 NEXUS SCALA"
            echo ""
            echo "- JVM \${{ env.JAVA_VERSION }} (\${{ env.JAVA_DISTRIBUTION }}) + cache sbt"
            echo "- scalafmtCheckAll : bloquant"
            echo "- scalafix --check : continue-on-error (signal)"
            echo "- sbt test + package"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_SCALA_YAML
    report_injection "SCALA" "nexus-scala.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 25 — HASKELL 🧠 (nouveau)
# stack build + hlint (lint idiomatique) + cabal check (santé du paquet)
# + tests. GHC figé par stack.yaml resolver.
# ═════════════════════════════════════════════════════════════════════════════

inject_haskell() {
    log_step "Injection du workflow NEXUS HASKELL (🧠)..."
    check_target "nexus-haskell.yml"
    cat > "$WORKFLOWS_DIR/nexus-haskell.yml" << 'NEXUS_HASKELL_YAML'
# ═══ NEXUS HASKELL — stack build, hlint, cabal check, tests ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🧠 NEXUS HASKELL"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-haskell-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
jobs:
  build_and_test:
    name: "⚙️ Build & Test Haskell"
    runs-on: ubuntu-latest
    timeout-minutes: 40
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no Haskell project)
        run: |
          if [ ! -f "stack.yaml" ] && [ ! -f "*.cabal" ] && ! ls *.cabal >/dev/null 2>&1; then
            echo "::error::Ni stack.yaml ni .cabal — Haskell non détecté."
            exit 1
          fi
      - name: Setup Stack
        uses: freckle/stack-action@v5
        continue-on-error: false
      - name: Build
        run: stack build --fast --pedantic
      - name: HLint
        continue-on-error: true
        run: |
          curl -fsSL https://raw.githubusercontent.com/ndmitchell/hlint/master/misc/travis-ci/Run.hs \
            >/dev/null 2>&1 || true
          stack install hlint >/dev/null 2>&1 && hlint . || {
            echo "::warning::hlint indisponible ou avertissements émis";
          }
      - name: Cabal Check
        if: hashFiles('*.cabal') != ''
        run: stack exec -- cabal check || true
      - name: Tests
        run: stack test --fast
      - name: Résumé Haskell
        if: always()
        run: |
          {
            echo "## 🧠 NEXUS HASKELL"
            echo ""
            echo "- stack build --pedantic (linter du compilateur activé)"
            echo "- hlint : continue-on-error (idiomatique, signal)"
            echo "- stack test"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_HASKELL_YAML
    report_injection "HASKELL" "nexus-haskell.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 26 — PERL 🐪 (nouveau)
# perlcritic (sévérité 4 = stern), installation carton/cpan minus, prove
# avec harness TAP + rapport JUnit uploadé.
# ═════════════════════════════════════════════════════════════════════════════

inject_perl() {
    log_step "Injection du workflow NEXUS PERL (🐪)..."
    check_target "nexus-perl.yml"
    cat > "$WORKFLOWS_DIR/nexus-perl.yml" << 'NEXUS_PERL_YAML'
# ═══ NEXUS PERL — perlcritic, carton, prove, rapport TAP ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🐪 NEXUS PERL"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-perl-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
jobs:
  quality_and_test:
    name: "🔍 Quality & Test Perl"
    runs-on: ubuntu-latest
    timeout-minutes: 25
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no Perl project)
        run: |
          FOUND=$(find . -maxdepth 2 -name '*.pl' -o -name '*.pm' -o -name '*.t' | head -n 1)
          if [ -z "$FOUND" ]; then
            echo "::error::Aucun fichier .pl/.pm/.t — Perl non détecté."
            exit 1
          fi
      - name: Setup Perl
        uses: shogo82148/actions-setup-perl@v1
        with:
          perl-version: "5.38"
      - name: Install Dependencies
        run: |
          if [ -f "cpanfile" ]; then
            cpanm --notest Carton
            carton install
          else
            echo "Pas de cpanfile — dépendances CPAN ignorées."
          fi
      - name: Install QA Tools
        run: cpanm --notest Perl::Critic TAP::Harness::JUnit
      - name: Perl::Critic (stern)
        run: |
          CRITIC_FILES=$(find . -maxdepth 3 -name '*.pl' -o -name '*.pm' | grep -v '^./local' | head -50)
          if [ -n "$CRITIC_FILES" ]; then
            perlcritic -4 --verbose "%f:%l:%c:%s:%m (%p)\n" $CRITIC_FILES \
              || { echo "::warning::perlcritic a signalé des violations"; }
          else
            echo "Aucun fichier à critiquer."
          fi
      - name: Tests (prove)
        run: |
          if compgen -G 't/*.t' > /dev/null || compgen -G '**/*.t' > /dev/null; then
            if [ -f "cpanfile" ]; then
              carton exec -- prove -lrv -j2 t/ 2>/dev/null \
                || carton exec -- prove -lrv $(find . -name '*.t' | head -20)
            else
              prove -lrv t/ 2>/dev/null \
                || prove -lrv $(find . -name '*.t' | head -20)
            fi
          else
            echo "Aucun test .t trouvé."
          fi
      - name: Résumé Perl
        if: always()
        run: |
          {
            echo "## 🐪 NEXUS PERL"
            echo ""
            echo "- Perl 5.38 + carton si cpanfile"
            echo "- perlcritic sévérité 4 (stern) : signal"
            echo "- prove -lrv : verbes TAP complets"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_PERL_YAML
    report_injection "PERL" "nexus-perl.yml" "1"
}
