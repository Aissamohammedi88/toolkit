
# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 12 — SECURITY 🏰 (nouveau — le garde du corps permanent)
# 5 couches : Gitleaks (secrets), Trivy fs+SARIF, CodeQL (SAST), Semgrep,
# dependency-review. Toutes les couches SARIF sont uploadées vers l'onglet
# Security. Les couches non-bloquantes sont en continue-on-error ASSUMÉ.
# ═════════════════════════════════════════════════════════════════════════════

inject_security() {
    log_step "Injection du workflow NEXUS SECURITY (🏰)..."
    check_target "nexus-security.yml"
    cat > "$WORKFLOWS_DIR/nexus-security.yml" << 'NEXUS_SECURITY_YAML'
# ═══ NEXUS SECURITY — forteresse permanente à 5 couches ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🏰 NEXUS SECURITY"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
  schedule:
    - cron: "0 3 * * 1"
  workflow_dispatch:
concurrency:
  group: nexus-security-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
  security-events: write
jobs:
  secrets_scan:
    name: "🔑 Secrets (Gitleaks)"
    runs-on: ubuntu-latest
    timeout-minutes: 10
    steps:
      - name: Checkout
        uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - name: Gitleaks
        uses: gitleaks/gitleaks-action@v2
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
        continue-on-error: true
      - name: Résumé secrets
        if: always()
        run: |
          echo "## 🏰 SECURITY — Secrets" >> "$GITHUB_STEP_SUMMARY"
          echo "Gitleaks : historique complet scanné (continue-on-error assumé)." \
            >> "$GITHUB_STEP_SUMMARY"
  filesystem_scan:
    name: "📦 Filesystem (Trivy)"
    runs-on: ubuntu-latest
    timeout-minutes: 15
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Trivy FS
        uses: aquasecurity/trivy-action@0.28.0
        with:
          scan-type: 'fs'
          scan-ref: '.'
          format: 'sarif'
          output: 'trivy-fs.sarif'
          severity: 'CRITICAL,HIGH'
          ignore-unfixed: true
        continue-on-error: true
      - name: Upload SARIF
        if: always()
        uses: github/codeql-action/upload-sarif@v3
        with:
          sarif_file: 'trivy-fs.sarif'
      - name: Résumé fs
        if: always()
        run: |
          echo "## 🏰 SECURITY — Filesystem" >> "$GITHUB_STEP_SUMMARY"
          echo "Trivy fs : CRITICAL/HIGH → SARIF onglet Security." \
            >> "$GITHUB_STEP_SUMMARY"
  codeql:
    name: "🧠 CodeQL (${{ matrix.language }})"
    runs-on: ubuntu-latest
    timeout-minutes: 30
    strategy:
      fail-fast: false
      matrix:
        language: [ python, javascript ]
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Initialize CodeQL
        uses: github/codeql-action/init@v3
        with:
          languages: ${{ matrix.language }}
      - name: Autobuild
        uses: github/codeql-action/autobuild@v3
        continue-on-error: true
      - name: Analyze
        uses: github/codeql-action/analyze@v3
        with:
          category: "/language:${{ matrix.language }}"
      - name: Résumé CodeQL
        if: always()
        run: |
          echo "## 🏰 SECURITY — CodeQL \`${{ matrix.language }}\`" \
            >> "$GITHUB_STEP_SUMMARY"
  semgrep:
    name: "🔎 Semgrep"
    runs-on: ubuntu-latest
    timeout-minutes: 15
    container:
      image: semgrep/semgrep
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Semgrep Scan
        run: semgrep scan --config auto --error --gitignore
        continue-on-error: true
      - name: Résumé Semgrep
        if: always()
        run: |
          echo "## 🏰 SECURITY — Semgrep" >> "$GITHUB_STEP_SUMMARY"
          echo "Règles auto + --error ; continue-on-error assumé." \
            >> "$GITHUB_STEP_SUMMARY"
  dependency_review:
    name: "🧾 Dependency Review"
    runs-on: ubuntu-latest
    timeout-minutes: 10
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Dependency Review
        uses: actions/dependency-review-action@v4
        continue-on-error: true
      - name: Résumé DepReview
        if: always()
        run: |
          {
            echo "## 🏰 SECURITY — Dependency Review"
            echo "Vulnérabilités connues + licences suspectées entre base et PR."
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_SECURITY_YAML
    report_injection "SECURITY" "nexus-security.yml" "5"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 13 — RELEASE 🚀 (nouveau)
# Déclenché par tags vX.Y.Z. Génère les checksums SHA-256, construit les
# artefacts (build hook générique), crée la GitHub Release avec notes auto,
# atteste la provenance SLSA de chaque artefact.
# ═════════════════════════════════════════════════════════════════════════════

inject_release() {
    log_step "Injection du workflow NEXUS RELEASE (🚀)..."
    check_target "nexus-release.yml"
    cat > "$WORKFLOWS_DIR/nexus-release.yml" << 'NEXUS_RELEASE_YAML'
# ═══ NEXUS RELEASE — tags vX.Y.Z → artefacts + checksums + SLSA ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🚀 NEXUS RELEASE"
on:
  push:
    tags:
      - "v[0-9]+.[0-9]+.[0-9]+"
      - "v[0-9]+.[0-9]+.[0-9]+-*"
  workflow_dispatch:
concurrency:
  group: nexus-release-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
jobs:
  build:
    name: "📦 Build Release Artifacts"
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup Build Hooks
        id: hooks
        run: |
          {
            echo "## 🚀 NEXUS RELEASE — Build"
            echo ""
            echo "Adapte le step « Build Artifacts » à ton produit."
          } >> "$GITHUB_STEP_SUMMARY"
      - name: Build Artifacts
        run: |
          mkdir -p release/
          echo "Artifact de ${GITHUB_REF_NAME} — $(date -u +%Y-%m-%dT%H:%M:%SZ)" \
            > "release/nexus-${GITHUB_REF_NAME}.txt"
      - name: Generate Checksums (SHA-256)
        run: |
          cd release/
          sha256sum * > "checksums-${GITHUB_REF_NAME}.txt"
          cat "checksums-${GITHUB_REF_NAME}.txt"
      - name: Upload Build Artifact
        uses: actions/upload-artifact@v4
        with:
          name: release-${{ github.ref_name }}
          path: release/
      - name: Attest SLSA Provenance
        uses: actions/attest-build-provenance@v1
        with:
          subject-path: 'release/*'
  github_release:
    name: "🏷️ GitHub Release"
    needs: build
    runs-on: ubuntu-latest
    timeout-minutes: 10
    permissions:
      contents: write
      id-token: write
      attestations: write
    steps:
      - name: Download Artifacts
        uses: actions/download-artifact@v4
        with:
          name: release-${{ github.ref_name }}
          path: release/
      - name: Changelog Auto (git log)
        run: |
          PREV_TAG=$(git describe --tags --abbrev=0 "${GITHUB_REF_NAME}^" 2>/dev/null || echo "")
          if [ -n "$PREV_TAG" ]; then
            git log --pretty="- %s (%h)" "$PREV_TAG..${GITHUB_REF_NAME}" > changelog.txt
          else
            git log --pretty="- %s (%h)" > changelog.txt
          fi
          {
            echo "RELEASE_NOTES<<EOF"
            cat changelog.txt
            echo "EOF"
          } >> "$GITHUB_ENV"
      - name: Create GitHub Release
        uses: softprops/action-gh-release@v2
        with:
          name: "NEXUS ${{ github.ref_name }}"
          body: "${{ env.RELEASE_NOTES }}"
          files: |
            release/*
            release/checksums-*
          generate_release_notes: true
      - name: Résumé release
        if: always()
        run: |
          {
            echo "## 🚀 NEXUS RELEASE — \`${GITHUB_REF_NAME}\`"
            echo ""
            echo "- Checksums SHA-256 attachés"
            echo "- SLSA provenance générée (attest-build-provenance)"
            echo "- Notes de release : git log entre tags + auto-generate"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_RELEASE_YAML
    report_injection "RELEASE" "nexus-release.yml" "2"
}
