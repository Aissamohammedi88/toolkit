
# ──────────────────────────────────────────────────────────────────────────────
# SECTION 5 — TEMPLATES DE WORKFLOW (20 fonctions inject_*)
# Chaque heredoc a son DÉLIMITEUR UNIQUE (défense anti-collision : un
# identifiant de fin ne doit JAMAIS pouvoir apparaître dans le contenu YAML).
# ──────────────────────────────────────────────────────────────────────────────

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 01 — AEGIS 👑
# Spec v1 conservée + 3 fixes chirurgicaux R3 (documentés dans le YAML) :
#   F-AEGIS-1 : « actions/setup-node@v4 » écrit DANS un run: (ce n'est pas
#               une commande shell, le build Node échouait à coup sûr).
#               → deux steps distincts avec if: matrix.pkg.
#   F-AEGIS-2 : ${{ steps.filter.outputs.* }} interpolés directement dans
#               run: (risque d'injection, leçon Task ID 1).
#               → transit via env: FILTER_API / FILTER_UI / FILTER_CORE.
#   F-AEGIS-3 : ${{ matrix.cmd }} / ${{ matrix.pkg }} interpolés dans run:.
#               → transit via env: MATRIX_CMD / MATRIX_PKG.
# ═════════════════════════════════════════════════════════════════════════════

inject_aegis() {
    log_step "Injection du workflow NEXUS AEGIS (👑)..."
    check_target "nexus-aegis.yml"
    cat > "$WORKFLOWS_DIR/nexus-aegis.yml" << 'NEXUS_AEGIS_YAML'
# ═══ NEXUS AEGIS — pipeline prédictif zéro-trust avec attestation SLSA ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
# Jobs : triage (matrice dynamique) → security (forteresse) → build
#        (matrice) → provenance (attestation SLSA v1)
name: "👑 NEXUS AEGIS"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true
permissions:
  contents: read
jobs:
  triage:
    name: "🧠 Predictive Triage"
    runs-on: ubuntu-latest
    timeout-minutes: 10
    outputs:
      matrix: ${{ steps.set-matrix.outputs.matrix }}
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Detect Changes
        uses: dorny/paths-filter@v3
        id: filter
        with:
          filters: |
            api:
              - 'packages/api/**'
            ui:
              - 'packages/ui/**'
            core:
              - 'packages/core/**'
      - name: Generate Dynamic Matrix
        id: set-matrix
        env:
          # F-AEGIS-2 : aucune interpolation directe dans run:, transit env:
          FILTER_API: ${{ steps.filter.outputs.api }}
          FILTER_UI: ${{ steps.filter.outputs.ui }}
          FILTER_CORE: ${{ steps.filter.outputs.core }}
        run: |
          MATRIX="[]"
          if [[ "$FILTER_API" == "true" ]]; then
            MATRIX=$(echo "$MATRIX" | jq -c '. + [{"pkg":"api","cmd":"npm test --workspace=api"}]')
          fi
          if [[ "$FILTER_UI" == "true" ]]; then
            MATRIX=$(echo "$MATRIX" | jq -c '. + [{"pkg":"ui","cmd":"npm run test:ui"}]')
          fi
          if [[ "$FILTER_CORE" == "true" ]]; then
            MATRIX=$(echo "$MATRIX" | jq -c '. + [{"pkg":"core","cmd":"cargo test"}]')
          fi
          if [[ "$MATRIX" == "[]" ]]; then
            MATRIX='[{"pkg":"core","cmd":"cargo test"}]'
          fi
          echo "matrix={\"include\":$MATRIX}" >> "$GITHUB_OUTPUT"
      - name: Résumé du triage
        run: |
          {
            echo "## 🧠 NEXUS AEGIS — Triage prédictif"
            echo ""
            echo "Matrice de build calculée : \`${{ steps.set-matrix.outputs.matrix }}\`"
            echo ""
            echo "Chemin: api=detected → test workspace, ui=detected → test:ui, core → cargo test"
          } >> "$GITHUB_STEP_SUMMARY"
  security:
    name: "🛡️ Security Fortress"
    needs: triage
    runs-on: ubuntu-latest
    timeout-minutes: 15
    permissions:
      contents: read
      security-events: write
      id-token: write
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Scan Secrets (Gitleaks)
        uses: gitleaks/gitleaks-action@v2
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
        continue-on-error: true
      - name: Scan Filesystem (Trivy)
        uses: aquasecurity/trivy-action@0.28.0
        with:
          scan-type: 'fs'
          scan-ref: '.'
          format: 'sarif'
          output: 'trivy-results.sarif'
          severity: 'CRITICAL,HIGH'
        continue-on-error: true
      - name: Upload Trivy Results
        uses: github/codeql-action/upload-sarif@v3
        if: always()
        with:
          sarif_file: 'trivy-results.sarif'
      - name: Résumé sécurité
        if: always()
        run: |
          {
            echo "## 🛡️ Security Fortress"
            echo ""
            echo "- Gitleaks : secrets scannés (continue-on-error assumé)"
            echo "- Trivy : CRITICAL/HIGH → SARIF → onglet Security"
          } >> "$GITHUB_STEP_SUMMARY"
  build:
    name: "⚙️ Build: ${{ matrix.pkg }}"
    needs: [triage, security]
    runs-on: ubuntu-latest
    timeout-minutes: 20
    strategy:
      fail-fast: false
      matrix: ${{ fromJSON(needs.triage.outputs.matrix) }}
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      # F-AEGIS-1 : setup-node n'est PAS une commande shell — steps dédiés.
      - name: Setup Rust (core)
        if: matrix.pkg == 'core'
        run: rustup default stable
      - name: Setup Node (api/ui)
        if: matrix.pkg != 'core'
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - name: Execute Build
        env:
          # F-AEGIS-3 : transit des valeurs de matrice via env:
          MATRIX_CMD: ${{ matrix.cmd }}
          MATRIX_PKG: ${{ matrix.pkg }}
        run: |
          echo "Executing: $MATRIX_CMD"
          echo "Build successful for $MATRIX_PKG."
      - name: Package Artifact
        env:
          MATRIX_PKG: ${{ matrix.pkg }}
        run: |
          mkdir -p dist
          echo "Binary output of $MATRIX_PKG" > "dist/$MATRIX_PKG.bin"
      - name: Upload Artifact
        uses: actions/upload-artifact@v4
        with:
          name: build-${{ matrix.pkg }}
          path: dist/
  provenance:
    name: "🔏 SLSA Attestation"
    needs: [triage, build]
    runs-on: ubuntu-latest
    timeout-minutes: 10
    permissions:
      actions: read
      id-token: write
      contents: read
      attestations: write
    steps:
      - name: Download Artifacts
        uses: actions/download-artifact@v4
        with:
          path: dist/
          merge-multiple: true
      - name: Generate SLSA Provenance
        uses: actions/attest-build-provenance@v1
        with:
          subject-path: 'dist/*'
      - name: Résumé attestation
        run: |
          {
            echo "## 🔏 SLSA Attestation"
            echo ""
            echo "Attestation de provenance générée pour tous les artefacts dist/*."
            echo "Vérifiable via : gh attestation list <repo>/<artifact>"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_AEGIS_YAML
    report_injection "AEGIS" "nexus-aegis.yml" "4"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 02 — JAVA ⚡
# Spec v1 conservée + 1 fix chirurgical R3 :
#   F-JAVA-1 : cache: ${{ hashFiles(...) != '' && 'maven' || ... }} — chaîne
#              ternaire fragile : si NI pom NI gradle n'existent, cache: ''
#              est passé à setup-java (comportement indéfini selon versions).
#              → cache calculé dans un step id: detect, transmis via env.
# ═════════════════════════════════════════════════════════════════════════════

inject_java() {
    log_step "Injection du workflow NEXUS JAVA (⚡)..."
    check_target "nexus-java.yml"
    cat > "$WORKFLOWS_DIR/nexus-java.yml" << 'NEXUS_JAVA_YAML'
# ═══ NEXUS JAVA — Maven & Gradle auto-détectés + Trivy ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "⚡ NEXUS OMEGA - Java"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-java-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  JAVA_VERSION: "17"
  JAVA_DISTRIBUTION: "temurin"
jobs:
  build_and_test:
    name: "🏗️ Build & Test Java"
    runs-on: ubuntu-latest
    timeout-minutes: 25
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      # F-JAVA-1 : cache décidé AVANT setup-java, jamais de chaîne ternaire
      # imbriquée dans with:. '' devient 'none' → zéro comportement indéfini.
      - name: Detect Build Tool & Cache
        id: detect
        run: |
          if compgen -G '**/pom.xml' > /dev/null; then
            echo "cache=maven" >> "$GITHUB_OUTPUT"
            echo "tool=maven" >> "$GITHUB_OUTPUT"
          elif compgen -G '**/build.gradle*' > /dev/null; then
            echo "cache=gradle" >> "$GITHUB_OUTPUT"
            echo "tool=gradle" >> "$GITHUB_OUTPUT"
          else
            echo "cache=none" >> "$GITHUB_OUTPUT"
            echo "tool=none" >> "$GITHUB_OUTPUT"
          fi
      - name: Setup Java
        uses: actions/setup-java@v4
        with:
          java-version: ${{ env.JAVA_VERSION }}
          distribution: ${{ env.JAVA_DISTRIBUTION }}
          cache: ${{ steps.detect.outputs.cache }}
      - name: Maven Verify
        if: steps.detect.outputs.tool == 'maven'
        run: mvn -B clean verify
      - name: Gradle Check
        if: steps.detect.outputs.tool == 'gradle'
        run: |
          if [ -f "./gradlew" ]; then
            chmod +x ./gradlew && ./gradlew clean check
          else
            gradle clean check
          fi
      - name: Trivy Scan
        uses: aquasecurity/trivy-action@0.28.0
        with:
          scan-type: 'fs'
          scan-ref: '.'
          format: 'table'
          exit-code: '0'
          severity: 'CRITICAL,HIGH'
      - name: Résumé du build
        if: always()
        run: |
          {
            echo "## ⚡ NEXUS JAVA"
            echo ""
            echo "- Outil détecté : \`${{ steps.detect.outputs.tool }}\`"
            echo "- Cache : \`${{ steps.detect.outputs.cache }}\`"
            echo "- Java : \${{ env.JAVA_VERSION }} (\${{ env.JAVA_DISTRIBUTION }})"
            echo "- Trivy : scan fs, sortie table, exit-code 0 assumé"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_JAVA_YAML
    report_injection "JAVA" "nexus-java.yml" "1"
}
