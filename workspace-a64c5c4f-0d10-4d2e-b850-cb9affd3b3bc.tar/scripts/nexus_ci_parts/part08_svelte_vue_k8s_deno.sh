
# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 17 — SVELTE 🧡 (nouveau)
# svelte-check typage, build Vite, smoke Playwright (continue-on-error car
# navigateur = environnement fragile), artefact build.
# ═════════════════════════════════════════════════════════════════════════════

inject_svelte() {
    log_step "Injection du workflow NEXUS SVELTE (🧡)..."
    check_target "nexus-svelte.yml"
    cat > "$WORKFLOWS_DIR/nexus-svelte.yml" << 'NEXUS_SVELTE_YAML'
# ═══ NEXUS SVELTE — svelte-check, build Vite, smoke Playwright ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🧡 NEXUS SVELTE"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-svelte-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
jobs:
  build_and_test:
    name: "⚙️ Build & Check Svelte"
    runs-on: ubuntu-latest
    timeout-minutes: 25
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no SvelteKit)
        run: |
          if [ ! -f "svelte.config.js" ] && [ ! -f "svelte.config.ts" ]; then
            echo "::error::Aucun svelte.config.* — projet Svelte non détecté."
            exit 1
          fi
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - name: Install Dependencies
        run: npm ci || npm install
      - name: Type Check (svelte-check)
        run: npx svelte-check --fail-on-warnings
      - name: Build
        run: npm run --if-present build
      - name: Smoke Test (Playwright)
        continue-on-error: true
        run: |
          if npm run | grep -q "test:e2e"; then
            npx playwright install --with-deps
            npm run test:e2e
          else
            echo "Pas de script test:e2e — smoke ignoré."
          fi
      - name: Upload Build Artifact
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: svelte-build
          path: build/
          if-no-files-found: ignore
      - name: Résumé Svelte
        if: always()
        run: |
          {
            echo "## 🧡 NEXUS SVELTE"
            echo ""
            echo "- svelte-check : --fail-on-warnings (strict)"
            echo "- build Vite + artefact"
            echo "- Playwright : continue-on-error (smoke, pas blocage)"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_SVELTE_YAML
    report_injection "SVELTE" "nexus-svelte.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 18 — VUE 💚 (nouveau)
# vue-tsc --noEmit (typage), build Vite, Vitest run, artefact dist.
# ═════════════════════════════════════════════════════════════════════════════

inject_vue() {
    log_step "Injection du workflow NEXUS VUE (💚)..."
    check_target "nexus-vue.yml"
    cat > "$WORKFLOWS_DIR/nexus-vue.yml" << 'NEXUS_VUE_YAML'
# ═══ NEXUS VUE — vue-tsc, build Vite, Vitest ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "💚 NEXUS VUE"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-vue-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
jobs:
  build_and_test:
    name: "⚙️ Build & Test Vue"
    runs-on: ubuntu-latest
    timeout-minutes: 25
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no Vue project)
        run: |
          if [ ! -f "vite.config.ts" ] && [ ! -f "vite.config.js" ]; then
            echo "::warning::Pas de vite.config.* à la racine — build tenté quand même."
          fi
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - name: Install Dependencies
        run: npm ci || npm install
      - name: Type Check (vue-tsc)
        run: npm run --if-present type-check
      - name: Unit Tests (Vitest)
        run: npm run --if-present test:unit
      - name: Build
        run: npm run --if-present build
      - name: Upload Build Artifact
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: vue-dist
          path: dist/
          if-no-files-found: ignore
      - name: Résumé Vue
        if: always()
        run: |
          {
            echo "## 💚 NEXUS VUE"
            echo ""
            echo "- vue-tsc via script type-check (--if-present)"
            echo "- Vitest via script test:unit (--if-present)"
            echo "- build Vite + artefact dist"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_VUE_YAML
    report_injection "VUE" "nexus-vue.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 19 — KUBERNETES ☸️ (nouveau)
# Kubeconform sur les manifests (validation de schémas réels), helm template
# si Chart.yaml, Trivy config scan, dry-run kind (continue-on-error assumé).
# ═════════════════════════════════════════════════════════════════════════════

inject_kubernetes() {
    log_step "Injection du workflow NEXUS KUBERNETES (☸️)..."
    check_target "nexus-kubernetes.yml"
    cat > "$WORKFLOWS_DIR/nexus-kubernetes.yml" << 'NEXUS_K8S_YAML'
# ═══ NEXUS KUBERNETES — kubeconform, helm template, Trivy config ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "☸️ NEXUS KUBERNETES"
on:
  push:
    branches: [ "main", "master" ]
    paths:
      - "k8s/**"
      - "kubernetes/**"
      - "charts/**"
      - "Chart.yaml"
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-k8s-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
jobs:
  validate_manifests:
    name: "🔎 Validate Manifests"
    runs-on: ubuntu-latest
    timeout-minutes: 20
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no manifests)
        run: |
          FOUND=$(find k8s kubernetes charts -type f \
            \( -name '*.yaml' -o -name '*.yml' \) 2>/dev/null | head -n 1)
          if [ -z "$FOUND" ]; then
            echo "::error::Aucun manifest dans k8s/, kubernetes/ ou charts/."
            exit 1
          fi
      - name: Setup Kubeconform
        run: |
          go install github.com/yannh/kubeconform/cmd/kubeconform@v0.6.7
          echo "$(go env GOPATH)/bin" >> "$GITHUB_PATH"
      - name: Kubeconform (strict, latest schemas)
        run: |
          find k8s kubernetes -type f \( -name '*.yaml' -o -name '*.yml' \) \
            -print0 2>/dev/null | xargs -0 -r kubeconform \
            -strict -summary -ignore-missing-schemas
      - name: Helm Template (si chart)
        if: hashFiles('Chart.yaml') != '' || hashFiles('charts/**/Chart.yaml') != ''
        run: |
          curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 \
            | bash
          helm template release ./ 2>/dev/null \
            | kubeconform -strict -summary -ignore-missing-schemas \
            || helm template release ./charts/*/ | kubeconform -strict -summary \
            -ignore-missing-schemas
      - name: Trivy Config Scan
        uses: aquasecurity/trivy-action@0.28.0
        with:
          scan-type: 'config'
          scan-ref: '.'
          severity: 'CRITICAL,HIGH'
          exit-code: '0'
        continue-on-error: true
      - name: Kind Smoke (apply --dry-run)
        continue-on-error: true
        run: |
          if command -v kind > /dev/null 2>&1; then
            kind create cluster --name nexus-smoke --wait 60s
            kubectl apply -f k8s/ --dry-run=client || true
            kind delete cluster --name nexus-smoke
          else
            echo "kind non disponible — smoke ignoré."
          fi
      - name: Résumé Kubernetes
        if: always()
        run: |
          {
            echo "## ☸️ NEXUS KUBERNETES"
            echo ""
            echo "- Kubeconform : -strict -summary -ignore-missing-schemas"
            echo "- Helm template : rendu validé si Chart.yaml"
            echo "- Trivy config + kind smoke : continue-on-error (signal)"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_K8S_YAML
    report_injection "KUBERNETES" "nexus-kubernetes.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 20 — DENO 🦕 (nouveau)
# fmt --check, lint, test --allow-all, compile en smoke test exécutable.
# ═════════════════════════════════════════════════════════════════════════════

inject_deno() {
    log_step "Injection du workflow NEXUS DENO (🦕)..."
    check_target "nexus-deno.yml"
    cat > "$WORKFLOWS_DIR/nexus-deno.yml" << 'NEXUS_DENO_YAML'
# ═══ NEXUS DENO — fmt, lint, test, compile smoke ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🦕 NEXUS DENO"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-deno-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
jobs:
  quality_and_test:
    name: "🔍 Quality & Test Deno"
    runs-on: ubuntu-latest
    timeout-minutes: 20
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no Deno project)
        run: |
          if [ ! -f "deno.json" ] && [ ! -f "deno.jsonc" ] \
            && [ ! -f "mod.ts" ] && [ ! -f "main.ts" ]; then
            echo "::error::Projet Deno non détecté (deno.json / mod.ts / main.ts)."
            exit 1
          fi
      - name: Setup Deno
        uses: denoland/setup-deno@v2
        with:
          deno-version: v2.x
      - name: Format Check
        run: deno fmt --check
      - name: Lint
        run: deno lint
      - name: Cache Dependencies
        run: deno cache --lock --lock-write mod.ts main.ts 2>/dev/null || deno cache mod.ts 2>/dev/null || true
      - name: Tests
        run: deno test --allow-all --coverage=cov_profile
      - name: Coverage Report
        if: always()
        run: deno coverage cov_profile --lcov > coverage.lcov || true
      - name: Upload Coverage
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: deno-coverage
          path: coverage.lcov
          if-no-files-found: ignore
      - name: Compile Smoke Test
        run: |
          ENTRY=""
          for f in main.ts mod.ts; do
            [ -f "$f" ] && ENTRY="$f" && break
          done
          if [ -n "$ENTRY" ]; then
            deno compile --allow-all --output nexus-smoke "$ENTRY"
            ./nexus-smoke || {
              echo "::warning::L'exécutable compilé a retourné un code non nul";
            }
          else
            echo "Pas de point d'entrée main.ts/mod.ts — compile ignoré."
          fi
      - name: Résumé Deno
        if: always()
        run: |
          {
            echo "## 🦕 NEXUS DENO"
            echo ""
            echo "- deno fmt --check + deno lint : bloquants"
            echo "- deno test --allow-all + coverage lcov"
            echo "- deno compile : smoke test de l'exécutable produit"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_DENO_YAML
    report_injection "DENO" "nexus-deno.yml" "1"
}
