
# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 21 — FLUTTER 💙 (nouveau)
# flutter analyze (fatal-infos), tests unitaires, build APK debug, golden
# tests (continue-on-error assumé : rendu dépendant de l'environnement).
# ═════════════════════════════════════════════════════════════════════════════

inject_flutter() {
    log_step "Injection du workflow NEXUS FLUTTER (💙)..."
    check_target "nexus-flutter.yml"
    cat > "$WORKFLOWS_DIR/nexus-flutter.yml" << 'NEXUS_FLUTTER_YAML'
# ═══ NEXUS FLUTTER — analyze, test, build APK, golden tests ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "💙 NEXUS FLUTTER"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-flutter-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  FLUTTER_VERSION: "3.24.0"
  JAVA_VERSION: "17"
jobs:
  analyze_and_test:
    name: "🔍 Analyze & Test Flutter"
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no pubspec)
        run: |
          if [ ! -f "pubspec.yaml" ]; then
            echo "::error::Aucun pubspec.yaml — projet Flutter non détecté."
            exit 1
          fi
      - name: Setup Java
        uses: actions/setup-java@v4
        with:
          java-version: ${{ env.JAVA_VERSION }}
          distribution: "temurin"
      - name: Setup Flutter
        uses: subosito/flutter-action@v2
        with:
          flutter-version: ${{ env.FLUTTER_VERSION }}
          cache: true
      - name: Doctor (environnement)
        run: flutter doctor -v
      - name: Pub Get
        run: flutter pub get
      - name: Analyze (strict)
        run: flutter analyze --fatal-infos --fatal-warnings
      - name: Unit Tests
        run: flutter test --coverage
      - name: Upload Coverage
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: flutter-coverage
          path: coverage/lcov.info
          if-no-files-found: ignore
      - name: Golden Tests
        continue-on-error: true
        run: flutter test --update-goldens --tags golden
      - name: Résumé Flutter
        if: always()
        run: |
          {
            echo "## 💙 NEXUS FLUTTER"
            echo ""
            echo "- analyze --fatal-infos --fatal-warnings (strict maximum)"
            echo "- flutter test --coverage → lcov.info"
            echo "- golden tests : continue-on-error (rendu = fragile)"
          } >> "$GITHUB_STEP_SUMMARY"
  build_apk:
    name: "📦 Build APK Debug"
    needs: analyze_and_test
    runs-on: ubuntu-latest
    timeout-minutes: 40
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup Java
        uses: actions/setup-java@v4
        with:
          java-version: ${{ env.JAVA_VERSION }}
          distribution: "temurin"
      - name: Setup Flutter
        uses: subosito/flutter-action@v2
        with:
          flutter-version: ${{ env.FLUTTER_VERSION }}
          cache: true
      - name: Pub Get
        run: flutter pub get
      - name: Build APK (debug)
        run: flutter build apk --debug
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: flutter-debug-apk
          path: build/app/outputs/flutter-apk/app-debug.apk
          if-no-files-found: ignore
      - name: Résumé build
        if: always()
        run: |
          {
            echo "## 💙 NEXUS FLUTTER — Build"
            echo ""
            echo "- APK debug uploadé en artefact (signé debug, pas release)."
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_FLUTTER_YAML
    report_injection "FLUTTER" "nexus-flutter.yml" "2"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 22 — ELIXIR 💧 (nouveau)
# deps.get avec cache, compile --warnings-as-errors (zéro tolérance), credo
# (lint idiomatique), ex_unit avec coverage, dialyzer (continue-on-error :
# analyse lente, signal seulement).
# ═════════════════════════════════════════════════════════════════════════════

inject_elixir() {
    log_step "Injection du workflow NEXUS ELIXIR (💧)..."
    check_target "nexus-elixir.yml"
    cat > "$WORKFLOWS_DIR/nexus-elixir.yml" << 'NEXUS_ELIXIR_YAML'
# ═══ NEXUS ELIXIR — compile strict, credo, ex_unit, dialyzer ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "💧 NEXUS ELIXIR"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-elixir-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  ELIXIR_VERSION: "1.17.3"
  OTP_VERSION: "27"
  MIX_ENV: "test"
jobs:
  quality_and_test:
    name: "🔍 Quality & Test Elixir"
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no mix.exs)
        run: |
          if [ ! -f "mix.exs" ]; then
            echo "::error::Aucun mix.exs — projet Elixir non détecté."
            exit 1
          fi
      - name: Setup Elixir
        uses: erlef/setup-beam@v1
        with:
          elixir-version: ${{ env.ELIXIR_VERSION }}
          otp-version: ${{ env.OTP_VERSION }}
      - name: Restore Deps Cache
        uses: actions/cache@v4
        with:
          path: |
            deps
            _build
          key: mix-${{ runner.os }}-${{ env.ELIXIR_VERSION }}-${{ hashFiles('mix.lock') }}
          restore-keys: mix-${{ runner.os }}-${{ env.ELIXIR_VERSION }}-
      - name: Install Dependencies
        run: |
          mix local.rebar --force
          mix local.hex --force
          mix deps.get
      - name: Compile (warnings = errors)
        run: mix compile --warnings-as-errors
      - name: Lint (Credo)
        run: |
          if mix help | grep -q credo; then
            mix credo --strict
          else
            echo "Credo absent des deps — lint ignoré."
          fi
      - name: Tests (ExUnit)
        run: mix test --cover
      - name: Upload Coverage
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: elixir-coverage
          path: cover/
          if-no-files-found: ignore
      - name: Static Analysis (Dialyzer)
        continue-on-error: true
        run: |
          if mix help | grep -q dialyzer; then
            mix dialyzer --no-check
          else
            echo "Dialyzer absent des deps — analyse ignorée."
          fi
      - name: Résumé Elixir
        if: always()
        run: |
          {
            echo "## 💧 NEXUS ELIXIR"
            echo ""
            echo "- compile --warnings-as-errors : zéro tolérance"
            echo "- credo --strict si présent"
            echo "- mix test --cover → cover/ uploadé"
            echo "- dialyzer : continue-on-error (lourd, signal)"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_ELIXIR_YAML
    report_injection "ELIXIR" "nexus-elixir.yml" "1"
}
