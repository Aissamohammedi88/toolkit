
# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 03 — PYTHON 🐍
# Spec v1 conservée (ruff/mypy/pytest, cache conditionnel) + enrichissements
# R3 : Bandit (SAST), pip-audit (SCA), coverage XML uploadé, résumé step.
# ═════════════════════════════════════════════════════════════════════════════

inject_python() {
    log_step "Injection du workflow NEXUS PYTHON (🐍)..."
    check_target "nexus-python.yml"
    cat > "$WORKFLOWS_DIR/nexus-python.yml" << 'NEXUS_PYTHON_YAML'
# ═══ NEXUS PYTHON — Ruff + Mypy + Pytest + Bandit + pip-audit ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🐍 NEXUS PYTHON"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-python-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
jobs:
  quality_and_test:
    name: "🔍 Quality & Test"
    runs-on: ubuntu-latest
    timeout-minutes: 20
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'
          cache: ${{ hashFiles('requirements.txt', 'pyproject.toml') != '' && 'pip' || '' }}
      - name: Install Dependencies
        run: |
          python -m pip install --upgrade pip
          if [ -f "requirements.txt" ]; then pip install -r requirements.txt; fi
          if [ -f "pyproject.toml" ]; then pip install .; fi
          pip install ruff mypy pytest pytest-cov bandit pip-audit
      - name: Lint (Ruff)
        run: ruff check .
      - name: Format Check (Ruff)
        run: ruff format --check . || {
          echo "::warning::ruff format --check a détecté du non-formaté";
          exit 1;
        }
      - name: Type Check (Mypy)
        run: mypy . --ignore-missing-imports
      - name: Security Lint (Bandit)
        run: bandit -r . -x './.git/*','./node_modules/*' -f json -o bandit.json || true
      - name: Dependency Audit (pip-audit)
        run: pip-audit --strict || {
          echo "::warning::pip-audit a trouvé des vulnérabilités";
          exit 1;
        }
      - name: Run Tests
        run: |
          if [ -d "tests" ]; then
            pytest tests/ -v --tb=short --cov=. --cov-report=xml:coverage.xml
          else
            echo "No tests found."
          fi
      - name: Upload Coverage
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: coverage-report
          path: coverage.xml
          if-no-files-found: ignore
      - name: Résumé qualité
        if: always()
        run: |
          {
            echo "## 🐍 NEXUS PYTHON"
            echo ""
            echo "- Ruff : check + format --check"
            echo "- Mypy : --ignore-missing-imports"
            echo "- Bandit : SAST en JSON (bandit.json)"
            echo "- pip-audit : --strict"
            echo "- Pytest : --cov → coverage.xml uploadé"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_PYTHON_YAML
    report_injection "PYTHON" "nexus-python.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 04 — NODE 🟢
# Spec v1 conservée + 1 fix chirurgical R3 :
#   F-NODE-1 : « npm run lint || echo "No lint script." » avalait les VRAIES
#              erreurs de lint — un échec de lint s'affichait comme « pas de
#              script » et passait vert (même classe de bug que « pytest ||
#              true », leçon Task ID 1). → npm run --if-present, qui n'exécute
#              que si le script existe et propage l'échec réel.
# ═════════════════════════════════════════════════════════════════════════════

inject_node() {
    log_step "Injection du workflow NEXUS NODE (🟢)..."
    check_target "nexus-node.yml"
    cat > "$WORKFLOWS_DIR/nexus-node.yml" << 'NEXUS_NODE_YAML'
# ═══ NEXUS NODE — build & test Next.js/Node avec --if-present ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🟢 NEXUS NODE"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-node-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
jobs:
  build_and_test:
    name: "⚙️ Build & Test Node"
    runs-on: ubuntu-latest
    timeout-minutes: 20
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - name: Install Dependencies
        run: npm ci || npm install
      # F-NODE-1 : --if-present n'exécute que si le script existe ;
      # un échec RÉEL de lint/build/test échoue le job, un script absent
      # est simplement ignoré. Fini les fausses réussites.
      - name: Lint
        run: npm run --if-present lint
      - name: Build
        run: npm run --if-present build
      - name: Test
        run: npm run --if-present test
      - name: Package dist
        run: |
          if [ -d "dist" ]; then
            echo "dist/ présent — upload de l'artefact."
          elif [ -d "build" ]; then
            echo "build/ présent — upload de l'artefact."
          else
            echo "Pas de dossier dist/ ou build/ — pas d'artefact."
          fi
      - name: Upload Build Artifact
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: node-dist
          path: |
            dist/
            build/
          if-no-files-found: ignore
      - name: Résumé du build
        if: always()
        run: |
          {
            echo "## 🟢 NEXUS NODE"
            echo ""
            echo "- Node 20, cache npm"
            echo "- lint/build/test via \`--if-present\` (F-NODE-1 : plus de faux verts)"
            echo "- Artefact dist/build si présent"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_NODE_YAML
    report_injection "NODE" "nexus-node.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 05 — RUST 🦀 (nouveau)
# Chainage standard : fmt → clippy -D warnings → test → tarpaulin (couverture,
# continue-on-error documenté) → audit RustSec. Cache Swatinem/rust-cache.
# ═════════════════════════════════════════════════════════════════════════════

inject_rust() {
    log_step "Injection du workflow NEXUS RUST (🦀)..."
    check_target "nexus-rust.yml"
    cat > "$WORKFLOWS_DIR/nexus-rust.yml" << 'NEXUS_RUST_YAML'
# ═══ NEXUS RUST — fmt, clippy, test, coverage, audit RustSec ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🦀 NEXUS RUST"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-rust-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  CARGO_TERM_COLOR: always
jobs:
  quality:
    name: "🧹 Format & Clippy"
    runs-on: ubuntu-latest
    timeout-minutes: 20
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup Rust
        uses: dtolnay/rust-toolchain@stable
        with:
          components: rustfmt, clippy
      - name: Cache Cargo
        uses: Swatinem/rust-cache@v2
      - name: Format Check
        run: cargo fmt --all --check
      - name: Clippy
        run: cargo clippy --all-targets -- -D warnings
      - name: Résumé qualité
        if: always()
        run: |
          {
            echo "## 🦀 NEXUS RUST — Qualité"
            echo ""
            echo "- cargo fmt --check : échec si non formaté"
            echo "- clippy -- -D warnings : zéro tolérance"
          } >> "$GITHUB_STEP_SUMMARY"
  tests:
    name: "🧪 Tests & Coverage"
    needs: quality
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup Rust
        uses: dtolnay/rust-toolchain@stable
      - name: Cache Cargo
        uses: Swatinem/rust-cache@v2
      - name: Run Tests
        run: cargo test --all-features --verbose
      - name: Coverage (tarpaulin)
        continue-on-error: true
        run: |
          cargo install cargo-tarpaulin
          cargo tarpaulin --out Xml --output-dir coverage/
      - name: Upload Coverage
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: rust-coverage
          path: coverage/
          if-no-files-found: ignore
      - name: Résumé tests
        if: always()
        run: |
          {
            echo "## 🦀 NEXUS RUST — Tests"
            echo ""
            echo "- cargo test --all-features"
            echo "- tarpaulin : continue-on-error (outil tiers, ne bloque pas)"
          } >> "$GITHUB_STEP_SUMMARY"
  audit:
    name: "🔒 RustSec Audit"
    needs: quality
    runs-on: ubuntu-latest
    timeout-minutes: 15
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Cargo Audit
        uses: rustsec/audit-check@v2
        continue-on-error: true
      - name: Résumé audit
        if: always()
        run: |
          {
            echo "## 🦀 NEXUS RUST — Audit"
            echo ""
            echo "- rustsec/audit-check : CVEs RustSec (continue-on-error assumé)"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_RUST_YAML
    report_injection "RUST" "nexus-rust.yml" "3"
}
