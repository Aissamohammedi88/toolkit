
# ──────────────────────────────────────────────────────────────────────────────
# SECTION 6 — COMMANDES : LIST / DOCTOR / VALIDATE
# ──────────────────────────────────────────────────────────────────────────────

# list_templates : inventaire détaillé avec état d'installation local.
list_templates() {
    echo -e "${M}╔══════════════════════════════════════════════════════════════════════╗${N}"
    echo -e "${M}║   NEXUS CI GENERATOR — Inventaire des ${TEMPLATE_COUNT} templates            ║${N}"
    echo -e "${M}╚══════════════════════════════════════════════════════════════════════╝${N}"
    echo
    local i type emoji file desc state total_installed=0
    for i in "${!TEMPLATE_REGISTRY[@]}"; do
        type="$(registry_field "$i" 1)"
        emoji="$(registry_field "$i" 2)"
        file="$(registry_field "$i" 3)"
        desc="$(registry_field "$i" 4)"
        if [ -f ".github/workflows/$file" ]; then
            state="${G}[installé]${N}"
            total_installed=$((total_installed + 1))
        else
            state="${D}[—]${N}"
        fi
        printf '  %s %-12s %-26s %-34s %b\n' "$emoji" "$type" "$file" "$desc" "$state"
    done
    echo
    log_info "Total : ${B}${total_installed}/${TEMPLATE_COUNT}${N} installés dans .github/workflows/"
    echo
    echo -e "${C}Pour injecter :${N} $0 <type>   (ex: $0 aegis | $0 all)"
    echo
}

# doctor : état des vérificateurs (NEXUS OMEGA R4 — déclarer, jamais prétendre).
doctor() {
    echo -e "${M}╔══════════════════════════════════════════════════════════════════════╗${N}"
    echo -e "${M}║   NEXUS CI GENERATOR — Doctor (vérificateurs)                       ║${N}"
    echo -e "${M}╚══════════════════════════════════════════════════════════════════════╝${N}"
    echo
    local all_ok=1

    if command -v git >/dev/null 2>&1; then
        log_ok "git $(git --version | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -n1) — requis pour l'injection"
    else
        log_err "git ABSENT — l'injection exige un dépôt Git"
        all_ok=0
    fi

    if command -v python3 >/dev/null 2>&1; then
        log_ok "python3 $(python3 --version | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?') — moteur de validation"
    else
        log_err "python3 ABSENT — validate/selftest inutilisables"
        all_ok=0
    fi

    if python3 -c "import yaml" >/dev/null 2>&1; then
        log_ok "PyYAML $(python3 -c 'import yaml; print(yaml.__version__)') — validation YAML complète"
    else
        log_warn "PyYAML ABSENT — R4 : fallback STRUCTUREL seulement (grep), déclaré"
        all_ok=0
    fi

    if command -v jq >/dev/null 2>&1; then
        log_ok "jq présent — utilisé par le template aegis sur le runner"
    else
        log_warn "jq absent localement — inutile en local (requis seulement sur le runner)"
    fi

    if command -v yamllint >/dev/null 2>&1; then
        log_ok "yamllint présent — bonus de lint YAML"
    else
        log_dim "yamllint absent — remplacé par PyYAML safe_load (déclaré R4)"
    fi

    if command -v actionlint >/dev/null 2>&1; then
        log_ok "actionlint présent — bonus de vérification Actions"
    else
        log_dim "actionlint absent — remplacé par PyYAML + clés requises (déclaré R4)"
    fi

    if command -v shellcheck >/dev/null 2>&1; then
        log_ok "shellcheck présent — bonus de lint bash"
    else
        log_dim "shellcheck absent — remplacé par bash -n (déclaré R4)"
    fi

    # ── Readiness outillage : présences LOCALES (informatif — les templates
    # s'exécutent sur les runners GitHub, pas ici ; ce bloc renseigne juste
    # ce que tu peux prévisualiser en local avant de pousser).
    echo
    log_info "Readiness local (les workflows tournent sur les runners GitHub) :"

    if command -v node >/dev/null 2>&1; then
        log_ok "node $(node --version) — tests locaux node/deno/monorepo possibles"
    else
        log_dim "node absent — templates node/monorepo : preview locale impossible"
    fi

    if command -v cargo >/dev/null 2>&1; then
        log_ok "cargo présent ($(cargo --version | grep -oE '[0-9]+\.[0-9]+.*' | head -n1)) — template rust testable en local"
    else
        log_dim "cargo absent — template rust : runner uniquement"
    fi

    if command -v go >/dev/null 2>&1; then
        log_ok "go $(go version | grep -oE 'go[0-9.]+' | head -n1) — template go testable en local"
    else
        log_dim "go absent — template go : runner uniquement"
    fi

    if command -v java >/dev/null 2>&1; then
        log_ok "java $(java --version 2>&1 | head -n1 | grep -oE '[0-9]+\.[0-9]+' | head -n1) — java/scala/android en local"
    else
        log_dim "java absent — templates java/scala/android : runner uniquement"
    fi

    if command -v deno >/dev/null 2>&1; then
        log_ok "deno $(deno --version | head -n1) — template deno testable en local"
    else
        log_dim "deno absent — template deno : runner uniquement"
    fi

    if command -v flutter >/dev/null 2>&1; then
        log_ok "flutter $(flutter --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1) — flutter en local"
    else
        log_dim "flutter absent — template flutter : runner uniquement"
    fi

    if command -v mix >/dev/null 2>&1; then
        log_ok "mix présent — template elixir testable en local"
    else
        log_dim "mix absent — template elixir : runner uniquement"
    fi

    if command -v curl >/dev/null 2>&1; then
        if curl -sI --max-time 6 https://api.github.com -o /dev/null 2>/dev/null; then
            log_ok "réseau OK — api.github.com joignable (actions/checkout fonctionnera)"
        else
            log_warn "api.github.com NON joignable — vérifie ta connexion (les runners GitHub en ont besoin)"
        fi
    else
        log_dim "curl absent — test réseau impossible"
    fi

    echo
    if [ "$all_ok" -eq 1 ]; then
        log_ok "Doctor : environnement COMPLET — validate et selftest pleinement fonctionnels"
    else
        log_warn "Doctor : environnement PARTIEL — fonctionnalités dégradées déclarées ci-dessus"
    fi
    echo
}

# validate_workflows : valide chaque .yml passé en argument.
# Prioritaire : PyYAML safe_load + clés requises + interdiction CRLF.
# Fallback déclaré (R4) : grep structurel si PyYAML absent.
validate_workflows() {
    local files=("$@")
    [ "${#files[@]}" -eq 0 ] && {
        log_warn "Aucun fichier .yml à valider dans $WORKFLOWS_DIR"
        return 0
    }
    log_step "Validation de ${#files[@]} workflow(s)..."
    if python3 -c "import yaml" >/dev/null 2>&1; then
        python3 - "$@" << 'NEXUS_VALIDATE_PY'
import sys
import yaml

ok = True
for path in sys.argv[1:]:
    try:
        with open(path, "rb") as f:
            raw = f.read()
        if b"\r" in raw:
            raise AssertionError("CRLF interdit — GitHub Actions exige LF")
        with open(path, encoding="utf-8") as f:
            doc = yaml.safe_load(f)
        if not isinstance(doc, dict):
            raise AssertionError("le document n'est pas un mapping")
        if "name" not in doc:
            raise AssertionError("clé 'name' absente")
        # PyYAML (YAML 1.1) lit « on: » comme clé booléenne True
        if "on" not in doc and True not in doc:
            raise AssertionError("clé 'on' absente")
        if "jobs" not in doc:
            raise AssertionError("clé 'jobs' absente")
        jobs = doc["jobs"]
        if not isinstance(jobs, dict) or not jobs:
            raise AssertionError("aucun job défini")
        n_jobs = len(jobs)
        n_steps = 0
        for job in jobs.values():
            if isinstance(job, dict) and isinstance(job.get("steps"), list):
                n_steps += len(job["steps"])
        print(f"VALID   {path}  ({n_jobs} jobs, {n_steps} steps)")
    except Exception as exc:
        ok = False
        print(f"INVALID {path}  : {exc}")
sys.exit(0 if ok else 1)
NEXUS_VALIDATE_PY
        if [ $? -eq 0 ]; then
            log_ok "Tous les workflows sont valides (PyYAML strict)"
        else
            log_err "Des workflows sont INVALIDES — corrige avant de committer"
            return 1
        fi
    else
        log_warn "PyYAML absent — R4 : fallback structurel grep (dégradé, déclaré)"
        local f bad=0
        for f in "${files[@]}"; do
            if grep -q '^name:' "$f" \
               && grep -q '^jobs:' "$f" \
               && grep -qE '^on:|^true:' "$f" \
               && ! grep -q $'\r' "$f"; then
                log_ok "STRUCT-OK $f"
            else
                log_err "STRUCT-KO $f"
                bad=1
            fi
        done
        [ "$bad" -eq 0 ] || return 1
    fi
    return 0
}

# inject_readme_ci : génère .github/README-CI.md documentant tous les workflows
# installés — la documentation fait partie de la livraison, pas un bonus.
inject_readme_ci() {
    local target=".github/README-CI.md"
    if [ "$DRYRUN" -eq 1 ]; then
        target="$WORKFLOWS_DIR/../README-CI.md"
    fi
    mkdir -p "$(dirname "$target")"
    {
        echo "# Pipelines CI/CD NEXUS — documentation générée"
        echo
        echo "Généré par NEXUS CI GENERATOR v${VERSION} (${AUTHOR})."
        echo "Chaque workflow est indépendant : supprime celui que tu n'utilises pas."
        echo
        echo "| Template | Workflow | Description | Jobs |"
        echo "|----------|----------|-------------|------|"
        local i type file desc jobs found
        for i in "${!TEMPLATE_REGISTRY[@]}"; do
            type="$(registry_field "$i" 1)"
            file="$(registry_field "$i" 3)"
            desc="$(registry_field "$i" 4)"
            jobs="$(registry_field "$i" 1)"
            if [ -f ".github/workflows/$file" ]; then
                echo "| ${type} | [\`.github/workflows/${file}\`](${file}) | ${desc} | installé |"
            fi
        done
        echo
        echo "## Commandes de maintenance"
        echo
        echo '```bash'
        echo './nexus-ci-generator.sh --list      # état d\'installation'
        echo './nexus-ci-generator.sh --validate  # valider les YAML'
        echo './nexus-ci-generator.sh --doctor    # vérifier les outils'
        echo './nexus-ci-generator.sh --selftest  # banc complet'
        echo '```'
        echo
        echo "## Conventions NEXUS"
        echo
        echo "- \`concurrency\` par workflow : les runs s'alignent, jamais ne s'entretuent."
        echo "- \`permissions\` minimales par job : le moindre privilège par défaut."
        echo "- Les scans non-bloquants sont en \`continue-on-error\` **assumé et documenté**."
        echo "- Aucune interpolation \`\${{ }}\` directe dans \`run:\` : transit \`env:\`."
        echo "- Chaque workflow écrit un résumé dans \`\\$GITHUB_STEP_SUMMARY\`."
    } > "$target"
    log_ok "Documentation CI générée : $target"
}

# write_manifest : matricule de session PROTON — trace CE que le générateur a
# écrit, quand, et l'empreinte sha256 de chaque fichier. Posé à côté des
# workflows (.github/nexus-ci-manifest.txt), il donne au dépôt une mémoire
# vérifiable de ses injections (utile pour audits type sovereign-audit).
write_manifest() {
    [ "${#INJECTED_FILES[@]}" -eq 0 ] && return 0
    local target=".github/nexus-ci-manifest.txt"
    if [ "$DRYRUN" -eq 1 ]; then
        log_dim "DRY-RUN : manifeste écrit dans le bac à sable"
        target="${WORKFLOWS_DIR%/workflows}/nexus-ci-manifest.txt"
    fi
    mkdir -p "$(dirname "$target")"
    {
        echo "═══ NEXUS CI GENERATOR — manifeste d'injection ═══"
        echo "date      : $(date -u +%Y-%m-%dT%H:%M:%SZ)"
        echo "version   : ${VERSION}"
        echo "auteur    : ${AUTHOR}"
        echo "dépôt     : $(git rev-parse --show-toplevel 2>/dev/null || echo 'hors-git (dry-run)')"
        echo "contrat   : ${NEXUS_LINE_TARGET} lignes vérifiées par selftest S02"
        echo
        echo "type;fichier;sha256"
        local f
        for f in "${INJECTED_FILES[@]}"; do
            if [ -f "$WORKFLOWS_DIR/$f" ]; then
                printf '%s;%s;%s\n' \
                    "$(printf '%s' "$f" | cut -d- -f2 | tr 'a-z' 'A-Z' | sed 's/\.YML//')" \
                    "$f" \
                    "$(sha256sum "$WORKFLOWS_DIR/$f" | cut -d' ' -f1)"
            fi
        done
    } > "$target"
    log_ok "Manifeste de traçabilité : $target"
}
