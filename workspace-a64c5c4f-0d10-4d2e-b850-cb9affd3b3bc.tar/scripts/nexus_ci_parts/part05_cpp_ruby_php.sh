
# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 09 — C/C++ 🎖️ (nouveau)
# Matrice gcc/clang, CMake configure+build+ctest, job séparé sanitizers
# (ASan+UBSan) avec continue-on-error documenté, couverture gcovr.
# ═════════════════════════════════════════════════════════════════════════════

inject_cpp() {
    log_step "Injection du workflow NEXUS C++ (🎖️)..."
    check_target "nexus-cpp.yml"
    cat > "$WORKFLOWS_DIR/nexus-cpp.yml" << 'NEXUS_CPP_YAML'
# ═══ NEXUS C++ — matrice gcc/clang, CMake, ctest, sanitizers, gcovr ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🎖️ NEXUS C++"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-cpp-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  BUILD_TYPE: Release
jobs:
  matrix_build:
    name: "⚙️ Build ${{ matrix.compiler }}"
    runs-on: ubuntu-latest
    timeout-minutes: 30
    strategy:
      fail-fast: false
      matrix:
        compiler: [ gcc, clang ]
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no CMakeLists)
        run: |
          if [ ! -f "CMakeLists.txt" ]; then
            echo "::error::Aucun CMakeLists.txt à la racine."
            exit 1
          fi
      - name: Install Toolchain
        run: |
          sudo apt-get update
          sudo apt-get install -y cmake clang gcovr
      - name: Configure
        run: |
          cmake -B build -DCMAKE_BUILD_TYPE="$BUILD_TYPE" \
            -DCMAKE_CXX_COMPILER="$(command -v ${{ matrix.compiler }})"
      - name: Build
        run: cmake --build build --parallel 2
      - name: Test (ctest)
        run: ctest --test-dir build --output-on-failure
      - name: Coverage (gcovr)
        if: matrix.compiler == 'gcc'
        continue-on-error: true
        run: |
          gcovr --root . --xml-pretty --output coverage.xml || true
      - name: Upload Coverage
        if: matrix.compiler == 'gcc'
        uses: actions/upload-artifact@v4
        with:
          name: cpp-coverage
          path: coverage.xml
          if-no-files-found: ignore
      - name: Résumé matrice
        if: always()
        run: |
          {
            echo "## 🎖️ NEXUS C++ — ${{ matrix.compiler }}"
            echo ""
            echo "- CMake : configure + build + ctest"
            echo "- gcovr sur gcc uniquement (clang = build de compatibilité)"
          } >> "$GITHUB_STEP_SUMMARY"
  sanitizers:
    name: "🧪 Sanitizers (Debug)"
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Install Toolchain
        run: |
          sudo apt-get update
          sudo apt-get install -y cmake
      - name: Configure ASan/UBSan
        run: |
          cmake -B build-san \
            -DCMAKE_BUILD_TYPE=Debug \
            -DCMAKE_CXX_FLAGS="-fsanitize=address,undefined -fno-omit-frame-pointer"
      - name: Build Sanitized
        run: cmake --build build-san --parallel 2
      - name: Run Sanitized Tests
        continue-on-error: true
        run: ctest --test-dir build-san --output-on-failure
      - name: Résumé sanitizers
        if: always()
        run: |
          {
            echo "## 🎖️ NEXUS C++ — Sanitizers"
            echo ""
            echo "- ASan + UBSan en Debug"
            echo "- continue-on-error : signale sans bloquer (assumé)"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_CPP_YAML
    report_injection "C++" "nexus-cpp.yml" "2"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 10 — RUBY 💎 (nouveau)
# Bundler install avec cache, RuboCop, RSpec, Brakeman (si Rails), bundler-audit.
# ═════════════════════════════════════════════════════════════════════════════

inject_ruby() {
    log_step "Injection du workflow NEXUS RUBY (💎)..."
    check_target "nexus-ruby.yml"
    cat > "$WORKFLOWS_DIR/nexus-ruby.yml" << 'NEXUS_RUBY_YAML'
# ═══ NEXUS RUBY — RuboCop, RSpec, Brakeman, bundler-audit ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "💎 NEXUS RUBY"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-ruby-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  RUBY_VERSION: "3.3"
jobs:
  quality_and_test:
    name: "🔍 Quality & Test Ruby"
    runs-on: ubuntu-latest
    timeout-minutes: 20
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup Ruby
        uses: ruby/setup-ruby@v1
        with:
          ruby-version: ${{ env.RUBY_VERSION }}
          bundler-cache: true
      - name: Fail Fast (no Gemfile)
        run: |
          if [ ! -f "Gemfile" ]; then
            echo "::error::Aucun Gemfile — job annulé."
            exit 1
          fi
      - name: RuboCop
        run: bundle exec rubocop --format progress
      - name: RSpec
        run: |
          if [ -d "spec" ]; then
            bundle exec rspec --format progress
          else
            echo "Aucun dossier spec/ — tests ignorés."
          fi
      - name: Brakeman (Rails)
        if: hashFiles('config/application.rb') != ''
        run: bundle exec brakeman --no-exit-on-warn || {
          echo "::warning::Brakeman a émis des avertissements";
          exit 1;
        }
      - name: Bundler Audit
        continue-on-error: true
        run: bundle exec bundler-audit check --update
      - name: Résumé Ruby
        if: always()
        run: |
          {
            echo "## 💎 NEXUS RUBY"
            echo ""
            echo "- Ruby \${{ env.RUBY_VERSION }}, bundler-cache auto"
            echo "- RuboCop : bloquant"
            echo "- RSpec : si spec/ existe"
            echo "- Brakeman : seulement si Rails détecté"
            echo "- bundler-audit : continue-on-error (CVEs = signal)"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_RUBY_YAML
    report_injection "RUBY" "nexus-ruby.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 11 — PHP 🐘 (nouveau)
# setup-php avec extensions, composer install avec cache, PHPStan niveau 8,
# PHPUnit avec coverage, composer audit.
# ═════════════════════════════════════════════════════════════════════════════

inject_php() {
    log_step "Injection du workflow NEXUS PHP (🐘)..."
    check_target "nexus-php.yml"
    cat > "$WORKFLOWS_DIR/nexus-php.yml" << 'NEXUS_PHP_YAML'
# ═══ NEXUS PHP — PHPStan 8, PHPUnit, composer audit ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🐘 NEXUS PHP"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-php-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  PHP_VERSION: "8.3"
jobs:
  quality_and_test:
    name: "🔍 Quality & Test PHP"
    runs-on: ubuntu-latest
    timeout-minutes: 20
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup PHP
        uses: shivammathur/setup-php@v2
        with:
          php-version: ${{ env.PHP_VERSION }}
          extensions: mbstring, xml, ctype, iconv, intl, pdo, pdo_sqlite
          coverage: xdebug
      - name: Fail Fast (no composer.json)
        run: |
          if [ ! -f "composer.json" ]; then
            echo "::error::Aucun composer.json — job annulé."
            exit 1
          fi
      - name: Get Composer Cache Directory
        id: composercache
        run: echo "dir=$(composer config cache-files-dir)" >> "$GITHUB_OUTPUT"
      - name: Cache Composer
        uses: actions/cache@v4
        with:
          path: ${{ steps.composercache.outputs.dir }}
          key: composer-${{ runner.os }}-${{ hashFiles('**/composer.lock') }}
          restore-keys: composer-${{ runner.os }}-
      - name: Install Dependencies
        run: |
          if [ -f "composer.lock" ]; then
            composer install --prefer-dist --no-progress --no-interaction
          else
            composer update --prefer-dist --no-progress --no-interaction
          fi
      - name: PHPStan
        run: |
          if composer show phpstan/phpstan > /dev/null 2>&1; then
            vendor/bin/phpstan analyse --level 8 --error-format=github src
          else
            echo "PHPStan absent des dépendances — analyse ignorée."
          fi
      - name: PHPUnit
        run: |
          if [ -d "tests" ]; then
            vendor/bin/phpunit --coverage-text --coverage-clover coverage.xml
          else
            echo "Aucun dossier tests/ — PHPUnit ignoré."
          fi
      - name: Upload Coverage
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: php-coverage
          path: coverage.xml
          if-no-files-found: ignore
      - name: Composer Audit
        continue-on-error: true
        run: composer audit
      - name: Résumé PHP
        if: always()
        run: |
          {
            echo "## 🐘 NEXUS PHP"
            echo ""
            echo "- PHP \${{ env.PHP_VERSION }} + Xdebug"
            echo "- PHPStan niveau 8 si installé"
            echo "- PHPUnit + coverage clover uploadée"
            echo "- composer audit : continue-on-error (signal)"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_PHP_YAML
    report_injection "PHP" "nexus-php.yml" "1"
}
