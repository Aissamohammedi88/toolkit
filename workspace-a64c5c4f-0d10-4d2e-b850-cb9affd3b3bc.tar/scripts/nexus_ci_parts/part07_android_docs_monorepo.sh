
# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 14 — ANDROID 🤖 (nouveau)
# Gradle wrapper + assembleDebug + lint + test, APK uploadé en artefact.
# Le JDK 17 est imposé (AGP 8+ le requiert), cache Gradle activé.
# ═════════════════════════════════════════════════════════════════════════════

inject_android() {
    log_step "Injection du workflow NEXUS ANDROID (🤖)..."
    check_target "nexus-android.yml"
    cat > "$WORKFLOWS_DIR/nexus-android.yml" << 'NEXUS_ANDROID_YAML'
# ═══ NEXUS ANDROID — assembleDebug, lint, test, artefact APK ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🤖 NEXUS ANDROID"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-android-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  JAVA_VERSION: "17"
  JAVA_DISTRIBUTION: "temurin"
jobs:
  build_and_test:
    name: "🏗️ Build & Test Android"
    runs-on: ubuntu-latest
    timeout-minutes: 45
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no Gradle project)
        run: |
          if [ ! -f "build.gradle" ] && [ ! -f "build.gradle.kts" ]; then
            echo "::error::Aucun build.gradle(.kts) — job annulé."
            exit 1
          fi
      - name: Setup Java
        uses: actions/setup-java@v4
        with:
          java-version: ${{ env.JAVA_VERSION }}
          distribution: ${{ env.JAVA_DISTRIBUTION }}
      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          cache: true
      - name: Grant Execute Permission (gradlew)
        run: chmod +x ./gradlew
      - name: Assemble Debug
        run: ./gradlew assembleDebug --stacktrace
      - name: Lint
        run: ./gradlew lint --stacktrace
      - name: Unit Tests
        run: ./gradlew testDebugUnitTest --stacktrace
      - name: Upload APK
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: nexus-debug-apk
          path: app/build/outputs/apk/debug/*.apk
          if-no-files-found: ignore
      - name: Upload Lint Report
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: android-lint-report
          path: app/build/reports/
          if-no-files-found: ignore
      - name: Résumé Android
        if: always()
        run: |
          {
            echo "## 🤖 NEXUS ANDROID"
            echo ""
            echo "- JDK 17 + Gradle cache"
            echo "- assembleDebug + lint + testDebugUnitTest"
            echo "- APK uploadé si build arrivé au packaging"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_ANDROID_YAML
    report_injection "ANDROID" "nexus-android.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 15 — DOCS 📚 (nouveau)
# Détecte MkDocs OU Docusaurus, construit, déploie sur GitHub Pages avec
# l'action officielle actions/deploy-pages (permissions dédiées).
# ═════════════════════════════════════════════════════════════════════════════

inject_docs() {
    log_step "Injection du workflow NEXUS DOCS (📚)..."
    check_target "nexus-docs.yml"
    cat > "$WORKFLOWS_DIR/nexus-docs.yml" << 'NEXUS_DOCS_YAML'
# ═══ NEXUS DOCS — MkDocs/Docusaurus → GitHub Pages ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "📚 NEXUS DOCS"
on:
  push:
    branches: [ "main", "master" ]
    paths:
      - "docs/**"
      - "mkdocs.yml"
      - "docusaurus.config.*"
      - "website/**"
  workflow_dispatch:
concurrency:
  group: nexus-docs-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
jobs:
  build:
    name: "📖 Build Docs"
    runs-on: ubuntu-latest
    timeout-minutes: 20
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Build MkDocs
        if: hashFiles('mkdocs.yml') != ''
        run: |
          pip install mkdocs mkdocs-material
          mkdocs build --strict --site-dir site/
      - name: Build Docusaurus
        if: hashFiles('docusaurus.config.js') != '' || hashFiles('docusaurus.config.ts') != ''
        run: |
          cd website/
          npm ci
          npm run build
          mv build/ ../site/
      - name: Fail Fast (no docs engine)
        run: |
          if [ ! -d "site/" ]; then
            echo "::error::Aucun moteur de docs détecté (mkdocs.yml ou docusaurus.config.*)."
            exit 1
          fi
      - name: Upload Pages Artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: site/
      - name: Résumé build docs
        if: always()
        run: |
          {
            echo "## 📚 NEXUS DOCS — Build"
            echo ""
            echo "- MkDocs : \${{ job.status }} si mkdocs.yml"
            echo "- Docusaurus : \${{ job.status }} si config détectée"
            echo "- Sortie : site/ → artefact Pages"
          } >> "$GITHUB_STEP_SUMMARY"
  deploy:
    name: "🚀 Deploy GitHub Pages"
    needs: build
    runs-on: ubuntu-latest
    timeout-minutes: 10
    permissions:
      pages: write
      id-token: write
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    steps:
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
      - name: Résumé déploiement
        if: always()
        run: |
          {
            echo "## 📚 NEXUS DOCS — Déploiement"
            echo ""
            echo "URL : ${{ steps.deployment.outputs.page_url }}"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_DOCS_YAML
    report_injection "DOCS" "nexus-docs.yml" "2"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 16 — MONOREPO 🧩 (nouveau)
# Turborepo affected : lint/test/build filtrés par graph, cache remote
# sur GitHub, résumé par paquet. Pré-requis : turbo en dépendance.
# ═════════════════════════════════════════════════════════════════════════════

inject_monorepo() {
    log_step "Injection du workflow NEXUS MONOREPO (🧩)..."
    check_target "nexus-monorepo.yml"
    cat > "$WORKFLOWS_DIR/nexus-monorepo.yml" << 'NEXUS_MONOREPO_YAML'
# ═══ NEXUS MONOREPO — Turborepo affected (lint/test/build) ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🧩 NEXUS MONOREPO"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-monorepo-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
jobs:
  affected:
    name: "🔍 Affected Pipeline"
    runs-on: ubuntu-latest
    timeout-minutes: 40
    steps:
      - name: Checkout (full history pour affected)
        uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - name: Fail Fast (no Turborepo)
        run: |
          if [ ! -f "turbo.json" ]; then
            echo "::error::Aucun turbo.json — ce workflow requiert Turborepo."
            exit 1
          fi
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - name: Setup Turbo
        run: npm install --global turbo@latest
      - name: Install Dependencies
        run: npm ci
      - name: Determine Base Commit
        id: base
        run: |
          if [ "${{ github.event_name }}" = "pull_request" ]; then
            echo "sha=${{ github.event.pull_request.base.sha }}" >> "$GITHUB_OUTPUT"
          else
            echo "sha=${{ github.event.before }}" >> "$GITHUB_OUTPUT"
          fi
      - name: Turbo Lint (affected)
        run: turbo lint --affected="origin/main" --continue
      - name: Turbo Test (affected)
        run: turbo test --affected="origin/main" --continue
      - name: Turbo Build (affected)
        run: turbo build --affected="origin/main" --continue
      - name: Résumé monorepo
        if: always()
        run: |
          {
            echo "## 🧩 NEXUS MONOREPO"
            echo ""
            echo "- Moteur : Turborepo, graffe complète fetch-depth: 0"
            echo "- lint / test / build : --affected --continue (un échec"
            echo "  de paquet n'annule pas les autres)"
            echo "- Cache npm + cache turbo local"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_MONOREPO_YAML
    report_injection "MONOREPO" "nexus-monorepo.yml" "1"
}
