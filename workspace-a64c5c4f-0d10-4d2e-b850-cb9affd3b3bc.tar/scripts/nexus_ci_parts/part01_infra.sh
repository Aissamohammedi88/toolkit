#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
# NEXUS CI GENERATOR v2.0.0 — Ultimate Workflow Injector
# Génère et installe des pipelines CI/CD de niveau production.
# Auteur : Aissa Mohammedi (DGK)
# ═══════════════════════════════════════════════════════════════════════════════
#
# PROTOCOLE PROTON (règles de la famille DGK) :
#   P1  Aucun calcul mental : wc -l vérifie le contrat 3999 lignes.
#   P2  Pas de livraison sans banc : commande --selftest (S01-S10).
#   P3  Chaque écart a sa preuve : audit R3 documenté dans nexus_ia/docs/.
#   P4  Fixes chirurgicales : les bugs de la spec v1 sont corrigés 1 par 1,
#       numérotés (F-AEGIS-1, F-JAVA-1, F-NODE-1...) et commentés sur place.
#   P5  Spec originale conservée VERBATIM : nexus_ia/docs/nexus_ci_spec_dgk_v1.sh
#
# PROTOCOLE NEXUS OMEGA v1.1 (R1-R10) :
#   R4  Vérification forcée : bash -n + selftest PyYAML. yamllint/actionlint/
#       shellcheck ABSENTS de l'environnement de build → déclaré ici, remplacés
#       par la validation PyYAML (yaml.safe_load) + clés requises + CRLF check.
#   R7  Lecture par blocs : ce fichier fait 3999 lignes, relecture offset/limit.
#   R10 Recherche exhaustive avant renommage : cf. validate_workflows.
#
# CONTRAT EXPLICITE (« pas de fainéantise ») :
#   - Ce fichier fait EXACTEMENT 3999 lignes. Vérifiable : wc -l <ce fichier>
#   - Le selftest S02 échoue si le nombre ne tombe pas juste.
#   - AUCUN remplissage : 30 templates de workflow réels, tous distincts,
#     chacun avec ses actions, sa matrice, ses sécurités et son résumé.
#
# Usage rapide :
#   ./nexus-ci-generator.sh --list           # inventorier les 30 templates
#   ./nexus-ci-generator.sh python           # injecter un workflow
#   ./nexus-ci-generator.sh all --force      # tout injecter
#   ./nexus-ci-generator.sh --selftest       # banc complet S01-S10
#   ./nexus-ci-generator.sh --doctor        # état des vérificateurs
#   ./nexus-ci-generator.sh --validate      # valider les .yml existants
# ═══════════════════════════════════════════════════════════════════════════════

set -euo pipefail

# ──────────────────────────────────────────────────────────────────────────────
# SECTION 0 — COULEURS & JOURNALISATION
# ──────────────────────────────────────────────────────────────────────────────

G='\033[1;32m'   # vert    — succès
R='\033[1;31m'   # rouge   — erreur
Y='\033[1;33m'   # jaune   — avertissement
C='\033[1;36m'   # cyan    — information
M='\033[1;35m'   # magenta — bannières
B='\033[1;37m'   # blanc   — titres
D='\033[2m'      # dim     — détails
N='\033[0m'     # reset

log_info()  { echo -e "${C}[INFO]${N} $*"; }
log_ok()    { echo -e "${G}[OK]${N} $*"; }
log_warn()  { echo -e "${Y}[WARN]${N} $*"; }
log_err()   { echo -e "${R}[ERR]${N} $*"; }
log_step()  { echo -e "${C}▶${N} $*"; }
log_dim()   { echo -e "${D}$*${N}"; }

# ──────────────────────────────────────────────────────────────────────────────
# SECTION 1 — CONSTANTES & REGISTRE DES TEMPLATES
# ──────────────────────────────────────────────────────────────────────────────

VERSION="2.0.0"
CODENAME="NEXUS CI GENERATOR — ÉDITION OMEGA x7 100"
AUTHOR="Aissa Mohammedi (DGK)"
NEXUS_LINE_TARGET=3999        # contrat « pas de fainéantise » — vérifié par S02
TEMPLATE_COUNT=30             # vérifié par S03
WORKFLOWS_DIR=".github/workflows"

# Registre canonique : TYPE|EMOJI|FICHIER|DESCRIPTION
# Chaque entrée correspond à une fonction inject_<type> réelle ci-dessous.
# Le selftest S03 vérifie que chaque entrée a sa fonction, et réciproquement.
TEMPLATE_REGISTRY=(
    "aegis|👑|nexus-aegis.yml|Pipeline prédictif, zéro-trust, SLSA (le plus avancé)"
    "java|⚡|nexus-java.yml|Build Maven/Gradle, Trivy, résumé de build"
    "python|🐍|nexus-python.yml|Ruff, Mypy, Pytest, Bandit, pip-audit"
    "node|🟢|nexus-node.yml|Next.js/Node.js build, lint --if-present, artefact"
    "rust|🦀|nexus-rust.yml|Fmt, Clippy, test, audit RustSec, cache"
    "go|🐹|nexus-go.yml|Gofmt, vet, golangci-lint, test -race, govulncheck"
    "docker|🐳|nexus-docker.yml|Buildx multi-arch, Trivy image, SBOM Syft"
    "dotnet|🔷|nexus-dotnet.yml|Restore, build, test, format, artefact"
    "cpp|🎖️|nexus-cpp.yml|Matrice gcc/clang, CMake, ctest, gcovr"
    "ruby|💎|nexus-ruby.yml|RuboCop, RSpec, Brakeman, bundler-audit"
    "php|🐘|nexus-php.yml|PHPStan, PHPUnit, composer audit"
    "security|🏰|nexus-security.yml|Gitleaks, Trivy, CodeQL, Semgrep, DepReview"
    "release|🚀|nexus-release.yml|Tags vX.Y.Z, checksums, GH Release, SLSA"
    "android|🤖|nexus-android.yml|Gradle assembleDebug, lint, test, APK artefact"
    "docs|📚|nexus-docs.yml|MkDocs/Docusaurus, déploiement GitHub Pages"
    "monorepo|🧩|nexus-monorepo.yml|Paths-filter + Turborepo affected"
    "svelte|🧡|nexus-svelte.yml|svelte-check, build Vite, Playwright smoke"
    "vue|💚|nexus-vue.yml|vue-tsc, build Vite, Vitest"
    "kubernetes|☸️|nexus-kubernetes.yml|Kubeconform, Helm template, Trivy config"
    "deno|🦕|nexus-deno.yml|fmt, lint, test --allow-all, compile smoke"
    "flutter|💙|nexus-flutter.yml|Analyze, test, build APK debug, golden"
    "elixir|💧|nexus-elixir.yml|Compile --warnings-as-errors, credo, ex_unit"
    "swift|🦅|nexus-swift.yml|xcodebuild test (macOS), spm build, artefacts"
    "scala|🔧|nexus-scala.yml|sbt compile, scalafmt, test, scalafix"
    "haskell|🧠|nexus-haskell.yml|stack build, hlint, cabal check"
    "perl|🐪|nexus-perl.yml|perlcritic, carton, prove"
    "r|📊|nexus-r.yml|rcmdcheck, lintr, couverture covr"
    "julia|⚙️|nexus-julia.yml|Pkg.test, JET, Aqua, stale check"
    "zig|⚡|nexus-zig.yml|fmt --check, build -Doptimize, tests"
    "aws-cdk|☁️|nexus-aws-cdk.yml|cdk synth, cfn-lint, cdk diff"
)

# Extraction d'un champ du registre : registry_field <index> <champ>
registry_field() {
    printf '%s' "${TEMPLATE_REGISTRY[$1]}" | cut -d'|' -f"$2"
}

# Tous les types, dans l'ordre du registre
all_types() {
    local i
    for i in "${!TEMPLATE_REGISTRY[@]}"; do
        printf '%s\n' "$(registry_field "$i" 1)"
    done
}

# Vérifie qu'un type demandé existe dans le registre
is_known_type() {
    local t
    for t in $(all_types); do
        [ "$t" = "$1" ] && return 0
    done
    return 1
}

# ──────────────────────────────────────────────────────────────────────────────
# SECTION 2 — AIDE (usage)
# ──────────────────────────────────────────────────────────────────────────────

usage() {
    echo -e "${M}╔══════════════════════════════════════════════════════════════════════╗${N}"
    echo -e "${M}║   NEXUS CI GENERATOR v${VERSION} — Workflow Injector x30               ║${N}"
    echo -e "${M}╚══════════════════════════════════════════════════════════════════════╝${N}"
    echo -e "\n${C}Usage:${N} $0 <type|commande> [drapeaux]"
    echo -e "\n${C}Types disponibles (${TEMPLATE_COUNT}):${N}"
    local i emoji type file desc
    for i in "${!TEMPLATE_REGISTRY[@]}"; do
        type="$(registry_field "$i" 1)"
        emoji="$(registry_field "$i" 2)"
        desc="$(registry_field "$i" 4)"
        printf '  %s %-12s : %s\n' "${emoji}${N}" "${Y}${type}${N}" "${desc}"
    done
    echo -e "\n${C}Commandes:${N}"
    echo -e "  ${Y}list${N}      : lister les templates avec descriptions détaillées"
    echo -e "  ${Y}doctor${N}    : vérifier les outils de validation disponibles (R4)"
    echo -e "  ${Y}validate${N}  : valider les .yml présents dans .github/workflows/"
    echo -e "  ${Y}selftest${N}  : banc PROTON complet S01-S10 (banc avant livraison)"
    echo -e "\n${C}Drapeaux:${N}"
    echo -e "  ${Y}--force${N}    : écraser un workflow déjà présent"
    echo -e "  ${Y}--dry-run${N}  : générer dans un répertoire temporaire jetable"
    echo -e "  ${Y}--quiet${N}    : sortie minimale (machine-friendly)"
    echo -e "\n${C}Exemples:${N}"
    echo -e "  $0 aegis            # le pipeline le plus avancé (SLSA, triage)"
    echo -e "  $0 python rust      # plusieurs types d'un coup"
    echo -e "  $0 all              # les ${TEMPLATE_COUNT} templates"
    echo -e "  $0 node --force     # réécrire nexus-node.yml"
    echo -e "  $0 --selftest       # prouver le banc avant de committer"
    echo -e "  $0 --list           # voir les ${TEMPLATE_COUNT} + état local"
    echo -e "  $0 --doctor         # vérificateurs + readiness outillage"
    echo -e "  $0 --validate       # valider les .yml déjà committés (PyYAML)"
    echo -e "  $0 security --dry-run  # prévisualiser sans écrire dans le dépôt"
    echo -e "  $0 all --quiet      # un chemin de fichier par ligne (scripts)"
    echo -e "  $0 docker release    # image + chaîne de livraison en une commande"
    echo -e "  $0 rust python node  # la stack trident de la famille NEXUS"
    echo -e "  $0 kubernetes        # valider les manifests avant tout déploiement"
    echo -e "  $0 --selftest --quiet  # banc silencieux (exit code suffit)\n"
    exit 1
}

# ──────────────────────────────────────────────────────────────────────────────
# SECTION 3 — PARSING DES ARGUMENTS
# ──────────────────────────────────────────────────────────────────────────────

FORCE=0
DRYRUN=0
QUIET=0
REQUESTED_TYPES=()
INJECTED_FILES=()

parse_args() {
    local a
    for a in "$@"; do
        case "$a" in
            --force)   FORCE=1 ;;
            --dry-run) DRYRUN=1 ;;
            --quiet)   QUIET=1 ;;
            --list)    REQUESTED_TYPES+=("list") ;;
            --doctor)  REQUESTED_TYPES+=("doctor") ;;
            --validate) REQUESTED_TYPES+=("validate") ;;
            --selftest) REQUESTED_TYPES+=("selftest") ;;
            --help|-h) usage ;;
            --*)       log_err "Drapeau inconnu : $a"; usage ;;
            *)         REQUESTED_TYPES+=("$a") ;;
        esac
    done
    [ "${#REQUESTED_TYPES[@]}" -eq 0 ] && usage
    return 0
}

# ──────────────────────────────────────────────────────────────────────────────
# SECTION 4 — GARDES D'ENVIRONNEMENT
# ──────────────────────────────────────────────────────────────────────────────

# check_env : refuser hors dépôt git (règle de la spec v1, conservée)
check_env() {
    if [ ! -d ".git" ]; then
        echo -e "${R}[ERREUR]${N} Ce dossier n'est pas un dépôt Git."
        exit 1
    fi
    mkdir -p "$WORKFLOWS_DIR"
}

# setup_workflows_dir : en dry-run, redirige vers un bac à sable jetable pour
# ne RIEN écrire dans le dépôt réel. Le workflow injecté reste identique au
# mode normal — c'est la destination qui change, pas le contenu.
setup_workflows_dir() {
    if [ "$DRYRUN" -eq 1 ]; then
        local sandbox
        sandbox="$(mktemp -d /tmp/nexus-dryrun.XXXXXX)"
        WORKFLOWS_DIR="$sandbox/.github/workflows"
        mkdir -p "$WORKFLOWS_DIR"
        log_warn "DRY-RUN : écriture dans $WORKFLOWS_DIR (jetable)"
    fi
}

# check_target : refuse d'écraser un workflow existant sans --force
# (PROTON P4 : aucune destruction silencieuse)
check_target() {
    local target="$WORKFLOWS_DIR/$1"
    if [ -e "$target" ] && [ "$FORCE" -eq 0 ]; then
        log_err "Le fichier $target existe déjà."
        log_info "Utilise --force pour l'écraser, ou supprime-le d'abord."
        exit 1
    fi
}

# report_injection : compte-rendu uniforme après chaque injection.
# Chaque fichier injecté est aussi inscrit au manifeste de session
# (INJECTED_FILES) — write_manifest() le matriculera avec son sha256.
report_injection() {
    local type="$1" file="$2" jobs="$3"
    INJECTED_FILES+=("$file")
    if [ "$QUIET" -eq 1 ]; then
        printf '%s\n' "$file"
    else
        log_ok "Workflow ${type} généré : $WORKFLOWS_DIR/${file} (${jobs} jobs)"
    fi
}

# banner_fin : pied de page commun aux injections (spec v1, enrichi)
banner_fin() {
    if [ "$QUIET" -eq 1 ]; then return 0; fi
    echo -e "\n${M}═══════════════════════════════════════════════════════════════════════${N}"
    echo -e "  ${G}✓ GÉNÉRATION TERMINÉE${N} — ${B}${AUTHOR}${N}"
    echo -e "  Prochaine étape : ${Y}git add .github/workflows/ && git commit -m \"ci: inject nexus workflow\" && git push${N}"
    if [ "$DRYRUN" -eq 1 ]; then
        echo -e "  ${Y}Rappel${N} : mode DRY-RUN — rien n'a été écrit dans ton dépôt."
    fi
    echo -e "${M}═══════════════════════════════════════════════════════════════════════${N}"
}
