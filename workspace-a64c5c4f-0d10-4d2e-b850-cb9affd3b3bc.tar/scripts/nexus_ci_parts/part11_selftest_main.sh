
# ──────────────────────────────────────────────────────────────────────────────
# SECTION 7 — SELFTEST (banc PROTON : pas de livraison sans banc)
# Chaque test Sxx a une assertion exécutable et un verdict PASS/FAIL.
# Le banc s'exécute en dépôts git temporaires — zéro risque pour ton dépôt.
# ──────────────────────────────────────────────────────────────────────────────

selftest() {
    echo -e "${M}╔══════════════════════════════════════════════════════════════════════╗${N}"
    echo -e "${M}║   NEXUS CI GENERATOR — SELFTEST PROTON S01-S15                       ║${N}"
    echo -e "${M}╚══════════════════════════════════════════════════════════════════════╝${N}"
    echo

    local passed=0 failed=0
    st_pass() { passed=$((passed + 1)); echo -e "  ${G}[PASS]${N} $1"; }
    st_fail() { failed=$((failed + 1)); echo -e "  ${R}[FAIL]${N} $1 ${D}— $2${N}"; }

    # ── S01 : syntaxe bash ────────────────────────────────────────────────────
    if bash -n "$0" 2>/dev/null; then
        st_pass "S01  bash -n : syntaxe bash valide"
    else
        st_fail "S01  bash -n" "syntaxe invalide"
    fi

    # ── S02 : contrat 3999 lignes (anti-fainéantise) ───────────────────────────
    local line_count
    line_count="$(wc -l < "$0")"
    if [ "$line_count" -eq "$NEXUS_LINE_TARGET" ]; then
        st_pass "S02  wc -l = ${NEXUS_LINE_TARGET} : contrat de lignes tenu"
    else
        st_fail "S02  wc -l" "attendu ${NEXUS_LINE_TARGET}, obtenu ${line_count}"
    fi

    # ── S03 : registre ↔ fonctions inject_* en correspondance exacte ───────────
    local reg_count func_count
    reg_count="${#TEMPLATE_REGISTRY[@]}"
    func_count="$(declare -F | grep -c '^declare -f inject_' || true)"
    if [ "$reg_count" -eq "$TEMPLATE_COUNT" ] \
       && [ "$func_count" -ge "$TEMPLATE_COUNT" ]; then
        st_pass "S03  registre (${reg_count}) = TEMPLATE_COUNT = fonctions inject_*"
    else
        st_fail "S03  cohérence registre" "reg=${reg_count} fonctions=${func_count}"
    fi

    # Chaque entrée du registre a bien sa fonction inject_<type>
    local missing=0 t
    for t in $(all_types); do
        declare -F "inject_$t" >/dev/null || {
            log_err "fonction inject_$t absente"
            missing=1
        }
    done
    if [ "$missing" -eq 0 ]; then
        st_pass "S03b chaque type du registre a sa fonction inject_*"
    else
        st_fail "S03b fonctions" "au moins une inject_* manquante"
    fi

    # ── S04 : injection réelle des ${TEMPLATE_COUNT} templates en dépôt git ────
    local lab
    lab="$(mktemp -d /tmp/nexus-selftest.XXXXXX)"
    git -C "$lab" init -q
    (
        cd "$lab" || exit 1
        WORKFLOWS_DIR=".github/workflows"
        mkdir -p "$WORKFLOWS_DIR"
        FORCE=1
        QUIET=1
        for t in $(all_types); do
            "inject_$t"
        done
    ) > /dev/null
    local generated_count
    generated_count="$(find "$lab/.github/workflows" -name '*.yml' | wc -l)"
    if [ "$generated_count" -eq "$TEMPLATE_COUNT" ]; then
        st_pass "S04  injection réelle : ${generated_count}/${TEMPLATE_COUNT} workflows créés en dépôt git temporaire"
    else
        st_fail "S04  injection" "attendu ${TEMPLATE_COUNT}, obtenu ${generated_count}"
    fi

    # ── S05 : validité YAML stricte de chaque workflow généré ─────────────────
    local yml_list
    yml_list="$(find "$lab/.github/workflows" -name '*.yml' | sort)"
    if python3 -c "import yaml" >/dev/null 2>&1; then
        if validate_workflows $yml_list > /dev/null 2>&1; then
            st_pass "S05  PyYAML : les ${TEMPLATE_COUNT} workflows parsent strict"
        else
            st_fail "S05  PyYAML" "au moins un workflow ne parse pas"
            validate_workflows $yml_list | grep INVALID || true
        fi
    else
        log_warn "S05  PyYAML absent — fallback structurel déclaré (R4)"
        if validate_workflows $yml_list > /dev/null 2>&1; then
            st_pass "S05  fallback structurel : clés requises présentes"
        else
            st_fail "S05  fallback" "clés manquantes"
        fi
    fi

    # ── S06 : interdiction CRLF (GitHub Actions exige LF) ──────────────────────
    local crlf_hits=0
    while IFS= read -r -d '' f; do
        if grep -q $'\r' "$f" 2>/dev/null; then
            crlf_hits=$((crlf_hits + 1))
            log_err "CRLF détecté dans : $f"
        fi
    done < <(find "$lab/.github/workflows" -name '*.yml' -print0)
    if [ "$crlf_hits" -eq 0 ]; then
        st_pass "S06  zéro CRLF : tous les workflows sont en LF"
    else
        st_fail "S06  CRLF" "${crlf_hits} fichier(s) concerné(s)"
    fi

    # ── S07 : clés requises (name / on / jobs) dans chaque workflow ────────────
    local missing_keys=0
    local y
    for y in $yml_list; do
        grep -q '^name:' "$y" || { log_err "name manquant : $y"; missing_keys=1; }
        grep -qE '^on:|^true:' "$y" || { log_err "on manquant : $y"; missing_keys=1; }
        grep -q '^jobs:' "$y" || { log_err "jobs manquant : $y"; missing_keys=1; }
    done
    if [ "$missing_keys" -eq 0 ]; then
        st_pass "S07  clés requises name/on/jobs présentes dans les ${TEMPLATE_COUNT}"
    else
        st_fail "S07  clés requises" "voir erreurs ci-dessus"
    fi

    # ── S08 : déterminisme — deux injections identiques bit à bit ─────────────
    local lab2 hash1 hash2
    lab2="$(mktemp -d /tmp/nexus-det.XXXXXX)"
    git -C "$lab2" init -q
    (
        cd "$lab2" || exit 1
        WORKFLOWS_DIR=".github/workflows"
        mkdir -p "$WORKFLOWS_DIR"
        FORCE=1; QUIET=1
        inject_python
    ) > /dev/null
    hash1="$(sha256sum "$lab/.github/workflows/nexus-python.yml" | cut -d' ' -f1)"
    hash2="$(sha256sum "$lab2/.github/workflows/nexus-python.yml" | cut -d' ' -f1)"
    if [ "$hash1" = "$hash2" ]; then
        st_pass "S08  déterminisme : sha256 identique sur double injection (${hash1:0:12}…)"
    else
        st_fail "S08  déterminisme" "${hash1:0:12} != ${hash2:0:12}"
    fi

    # ── S09 : garde anti-écrasement sans --force ───────────────────────────────
    local guard_result=0
    if (
        cd "$lab" || exit 0
        WORKFLOWS_DIR=".github/workflows"
        FORCE=0; QUIET=1
        inject_python
    ) > /dev/null 2>&1; then
        guard_result=1
    fi
    if [ "$guard_result" -eq 0 ]; then
        st_pass "S09  check_target : refuse d'écraser sans --force (exit ≠ 0)"
    else
        st_fail "S09  garde" "l'écrasement silencieux a réussi — GRAVE"
    fi

    # ── S10 : dry-run n'écrit RIEN dans le dépôt réel ──────────────────────────
    local lab3
    lab3="$(mktemp -d /tmp/nexus-dry.XXXXXX)"
    git -C "$lab3" init -q
    local dry_ok=1
    if DRYRUN=1 QUIET=1 bash "$0" python > /dev/null 2>&1; then :; fi
    if [ -d "$lab3/.github" ]; then
        dry_ok=0
    fi
    if [ "$dry_ok" -eq 1 ]; then
        st_pass "S10  dry-run : aucun .github/ créé dans le répertoire courant du test"
    else
        st_fail "S10  dry-run" "des fichiers ont fui hors du bac à sable"
    fi

    # ── S11 : délimiteurs heredoc uniques par template ──────────────────────────
    local dup_deliits
    dup_deliits="$(grep -oE "<< 'NEXUS_[A-Z0-9_]+_YAML'" "$0" | sort | uniq -d | wc -l)"
    if [ "$dup_deliits" -eq 0 ]; then
        st_pass "S11  délimiteurs heredoc tous uniques (défense anti-collision)"
    else
        st_fail "S11  délimiteurs" "${dup_deliits} doublon(s)"
    fi

    # ── S12 : noms de fichiers du registre tous distincts ──────────────────────
    local dup_files
    dup_files="$(all_files | sort | uniq -d | wc -l)"
    if [ "$dup_files" -eq 0 ]; then
        st_pass "S12  noms de workflow tous distincts (pas de collision d'injection)"
    else
        st_fail "S12  noms" "${dup_files} doublon(s)"
    fi

    # ── S13 : usage sans argument sort en erreur (exit 1) ────────────────────
    if ! bash "$0" > /dev/null 2>&1; then
        st_pass "S13  sans argument : usage affiché + exit ≠ 0"
    else
        st_fail "S13  usage" "l'appel sans argument doit refuser"
    fi

    # ── S14 : dry-run écrit bien DANS le bac à sable (face positive de S10) ───
    local lab4 dry_file
    lab4="$(mktemp -d /tmp/nexus-dry2.XXXXXX)"
    git -C "$lab4" init -q
    DRYRUN=1 QUIET=1 bash "$0" python > /dev/null 2>&1
    dry_file="$(find /tmp/nexus-dryrun.* -name 'nexus-python.yml' 2>/dev/null | head -n 1)"
    if [ -n "$dry_file" ] && python3 -c "import yaml,sys; yaml.safe_load(open(sys.argv[1]))" "$dry_file" > /dev/null 2>&1; then
        st_pass "S14  dry-run : workflow généré ET valide dans le bac à sable"
    else
        st_fail "S14  dry-run" "fichier absent ou invalide dans le sandbox"
    fi
    rm -rf "$lab4"

    # ── S15 : convention résumé — chaque workflow écrit un STEP_SUMMARY ───────
    local no_summary=0 y2
    for y2 in $yml_list; do
        if ! grep -q 'GITHUB_STEP_SUMMARY' "$y2"; then
            log_err "Pas de résumé STEP_SUMMARY dans : $y2"
            no_summary=$((no_summary + 1))
        fi
    done
    if [ "$no_summary" -eq 0 ]; then
        st_pass "S15  convention résumé : les ${TEMPLATE_COUNT} workflows écrivent un STEP_SUMMARY"
    else
        st_fail "S15  résumé" "${no_summary} workflow(s) sans STEP_SUMMARY"
    fi

    # ── Nettoyage des bacs à sable ─────────────────────────────────────────────
    rm -rf "$lab" "$lab2" "$lab3"
    log_dim "Bacs à sable temporaires supprimés."

    echo
    echo -e "${M}─────────────────────────────────────────────────────────────────────${N}"
    if [ "$failed" -eq 0 ]; then
        echo -e "  ${G}✓ SELFTEST ALL GREEN — ${passed} tests verts${N}"
        echo -e "  ${B}${CODENAME}${N}"
        echo -e "  ${B}${AUTHOR}${N}"
        echo -e "${M}─────────────────────────────────────────────────────────────────────${N}"
        return 0
    else
        echo -e "  ${R}✗ SELFTEST ÉCHOUÉ — ${failed} rouge(s) / ${passed} vert(s)${N}"
        echo -e "  Interdiction PROTON P2 de livrer en l'état."
        echo -e "${M}─────────────────────────────────────────────────────────────────────${N}"
        return 1
    fi
}

# all_files : noms de fichiers du registre (pour S12)
all_files() {
    local i
    for i in "${!TEMPLATE_REGISTRY[@]}"; do
        registry_field "$i" 3
    done
}

# ──────────────────────────────────────────────────────────────────────────────
# SECTION 8 — DISPATCH PRINCIPAL
# ──────────────────────────────────────────────────────────────────────────────

# setup_once : initialise la destination (dry-run → bac à sable) une seule fois
SETUP_DONE=0
setup_once() {
    [ "$SETUP_DONE" -eq 1 ] && return 0
    setup_workflows_dir
    SETUP_DONE=1
    return 0
}

# inject_all : les ${TEMPLATE_COUNT} templates + la documentation CI
inject_all() {
    local t
    for t in $(all_types); do
        "inject_$t"
    done
    inject_readme_ci
}

main() {
    [ "${BASH_VERSINFO[0]:-0}" -lt 4 ] && {
        log_err "Bash >= 4 requis (actuel : ${BASH_VERSION:-inconnu})."
        exit 1
    }
    parse_args "$@"

    local t did_inject=0
    for t in "${REQUESTED_TYPES[@]}"; do
        case "$t" in
            list)
                list_templates
                ;;
            doctor)
                doctor
                ;;
            selftest)
                selftest || exit 1
                ;;
            validate)
                setup_once
                check_env
                local existing
                existing="$(find "$WORKFLOWS_DIR" -maxdepth 1 -name '*.yml' 2>/dev/null | sort)"
                if [ -n "$existing" ]; then
                    validate_workflows $existing || exit 1
                else
                    log_warn "Aucun .yml dans $WORKFLOWS_DIR — rien à valider."
                fi
                ;;
            all)
                setup_once
                check_env
                inject_all
                did_inject=1
                ;;
            *)
                is_known_type "$t" || {
                    log_err "Type inconnu : $t"
                    usage
                }
                setup_once
                check_env
                "inject_$t"
                did_inject=1
                ;;
        esac
    done

    [ "$did_inject" -eq 1 ] && write_manifest
    [ "$did_inject" -eq 1 ] && banner_fin
    return 0
}

