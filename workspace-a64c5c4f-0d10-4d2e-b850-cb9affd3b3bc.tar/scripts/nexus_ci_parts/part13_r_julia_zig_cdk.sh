
# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 27 — R 📊 (nouveau)
# rcmdcheck (le standard communautaire), lintr, couverture covr → artifact.
# Exécution via r-lib/actions — la voie officielle tidyverse.
# ═════════════════════════════════════════════════════════════════════════════

inject_r() {
    log_step "Injection du workflow NEXUS R (📊)..."
    check_target "nexus-r.yml"
    cat > "$WORKFLOWS_DIR/nexus-r.yml" << 'NEXUS_R_YAML'
# ═══ NEXUS R — rcmdcheck, lintr, covr coverage ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "📊 NEXUS R"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-r-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
jobs:
  check_and_test:
    name: "🔍 R-CMD-check & Lint"
    runs-on: ubuntu-latest
    timeout-minutes: 40
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no R package)
        run: |
          if [ ! -f "DESCRIPTION" ]; then
            echo "::error::Aucun DESCRIPTION — paquet R non détecté."
            exit 1
          fi
      - name: Setup R
        uses: r-lib/actions/setup-r@v2
        with:
          r-version: "release"
          use-public-rspm: true
      - name: Setup R dependencies
        uses: r-lib/actions/setup-r-dependencies@v2
        with:
          extra-packages: |
            any::rcmdcheck
            any::lintr
            any::covr
      - name: R CMD Check
        uses: r-lib/actions/check-r-package@v2
        with:
          args: 'c("--no-manual", "--as-cran")'
          error-on: '"warning"'
          build_args: 'c("--no-manual", "--no-build-vignettes")'
      - name: Lint (lintr)
        run: Rscript -e 'lintr::lint_package(".") || { cat("lint warnings\n"); quit(status=1) }'
        continue-on-error: true
      - name: Coverage (covr)
        run: |
          Rscript -e 'cov <- covr::package_coverage(); covr::to_cobertura(cov)' || {
            echo "::warning::covr a échoué — coverage ignoré";
          }
      - name: Upload Coverage
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: r-coverage
          path: cobertura.xml
          if-no-files-found: ignore
      - name: Résumé R
        if: always()
        run: |
          {
            echo "## 📊 NEXUS R"
            echo ""
            echo "- R CMD check --as-cran : erreur dès le warning"
            echo "- lintr : continue-on-error (signal)"
            echo "- covr → cobertura.xml"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_R_YAML
    report_injection "R" "nexus-r.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 28 — JULIA ⚙️ (nouveau)
# Pkg.test + Aqua.jl (qualité paquet) + JET.jl (analyse statique) + check
# de fraîcheur Manifest.toml (stale). Cache des dépôts JuliaDepots.
# ═════════════════════════════════════════════════════════════════════════════

inject_julia() {
    log_step "Injection du workflow NEXUS JULIA (⚙️)..."
    check_target "nexus-julia.yml"
    cat > "$WORKFLOWS_DIR/nexus-julia.yml" << 'NEXUS_JULIA_YAML'
# ═══ NEXUS JULIA — Pkg.test, Aqua, JET, stale check ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "⚙️ NEXUS JULIA"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-julia-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  JULIA_VERSION: "1.11"
jobs:
  build_and_test:
    name: "⚙️ Build & Test Julia"
    runs-on: ubuntu-latest
    timeout-minutes: 40
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no Julia project)
        run: |
          if [ ! -f "Project.toml" ]; then
            echo "::error::Aucun Project.toml — projet Julia non détecté."
            exit 1
          fi
      - name: Setup Julia
        uses: julia-actions/setup-julia@v2
        with:
          version: ${{ env.JULIA_VERSION }}
      - name: Cache Julia Depot
        uses: actions/cache@v4
        with:
          path: |
            ~/.julia/artifacts
            ~/.julia/packages
          key: julia-${{ runner.os }}-${{ env.JULIA_VERSION }}-${{ hashFiles('Manifest.toml') }}
          restore-keys: julia-${{ runner.os }}-${{ env.JULIA_VERSION }}-
      - name: Manifest Stale Check
        run: |
          julia --project=. -e '
            if isfile("Manifest.toml")
              using Pkg; Pkg.activate(".")
              try
                Pkg.upgrade_manifest()
              catch
              end
              println("Manifest présent — cohérence vérifiée lors de Pkg.test()")
            else
              println("Pas de Manifest.toml — résolution au premier test.")
            end'
      - name: Run Tests
        uses: julia-actions/julia-runtest@v1
      - name: Aqua Quality Check
        continue-on-error: true
        run: |
          julia --project=. -e '
            using Pkg; Pkg.add("Aqua")
            using Aqua, Pkg
            pkg = Pkg.project().name
            pkg == nothing && (println("Projet sans nom — Aqua ignoré"); exit(0))
            try
              Aqua.test_all(Base.require(Main, Symbol(pkg)))
              println("Aqua : OK")
            catch err
              println("Aqua : avertissements (signal seulement)")
            end'
      - name: JET Static Analysis
        continue-on-error: true
        run: |
          julia --project=. -e '
            using Pkg; Pkg.add("JET")
            try
              using JET
              report_package()
              println("JET : analyse terminée (voir warnings éventuels)")
            catch
              println("JET : indisponible — analyse ignorée")
            end'
      - name: Process Test Report
        uses: julia-actions/julia-processcoverage@v1
        continue-on-error: true
      - name: Upload Coverage
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: julia-coverage
          path: lcov.info
          if-no-files-found: ignore
      - name: Résumé Julia
        if: always()
        run: |
          {
            echo "## ⚙️ NEXUS JULIA"
            echo ""
            echo "- Julia \${{ env.JULIA_VERSION }} + cache depot"
            echo "- Pkg.test officiel + Aqua + JET (signaux, non bloquants)"
            echo "- coverage via julia-processcoverage"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_JULIA_YAML
    report_injection "JULIA" "nexus-julia.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 29 — ZIG ⚡ (nouveau)
# fmt --check (blocant), build en Debug+ReleaseFast, tests via zig build test.
# Le build vérifie AUSSI les exemples si build.zig les expose.
# ═════════════════════════════════════════════════════════════════════════════

inject_zig() {
    log_step "Injection du workflow NEXUS ZIG (⚡)..."
    check_target "nexus-zig.yml"
    cat > "$WORKFLOWS_DIR/nexus-zig.yml" << 'NEXUS_ZIG_YAML'
# ═══ NEXUS ZIG — fmt, build Debug/ReleaseFast, tests ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "⚡ NEXUS ZIG"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-zig-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  ZIG_VERSION: "0.13.0"
jobs:
  build_and_test:
    name: "⚙️ Build & Test Zig"
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no build.zig)
        run: |
          if [ ! -f "build.zig" ]; then
            echo "::error::Aucun build.zig — projet Zig non détecté."
            exit 1
          fi
      - name: Setup Zig
        uses: mlugg/setup-zig@v1
        with:
          zig-version: ${{ env.ZIG_VERSION }}
      - name: Format Check
        run: |
          UNFORMATTED=$(zig fmt --check . 2>&1 || true)
          if [ -n "$UNFORMATTED" ]; then
            echo "::error::zig fmt --check a listé :"
            echo "$UNFORMATTED"
            exit 1
          fi
      - name: Build (Debug)
        run: zig build -Doptimize=Debug
      - name: Build (ReleaseFast)
        run: zig build -Doptimize=ReleaseFast
      - name: Run Tests
        run: zig build test --summary all
      - name: Smoke Run (binaire)
        run: |
          if [ -x "./zig-out/bin/"* ] 2>/dev/null; then
            ./zig-out/bin/* --help 2>/dev/null \
              || ./zig-out/bin/* 2>/dev/null \
              || echo "Exécutable retourné non nul — vérifier le point d'entrée."
          else
            echo "Pas de binaire dans zig-out/ — smoke ignoré."
          fi
      - name: Upload Binaries
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: zig-bin
          path: zig-out/
          if-no-files-found: ignore
      - name: Résumé Zig
        if: always()
        run: |
          {
            echo "## ⚡ NEXUS ZIG"
            echo ""
            echo "- zig fmt --check : bloquant"
            echo "- builds Debug ET ReleaseFast (attraper les UB de release)"
            echo "- zig build test --summary all"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_ZIG_YAML
    report_injection "ZIG" "nexus-zig.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 30 — AWS CDK ☁️ (nouveau)
# npm ci + cdk synth (génère le template CloudFormation) + cfn-lint (valide
# le JSON/YAML synthétisé) + cdk diff sur PR (montre le delta d'infrastructure)
# + vérification des seuils de budget si contexte détecté.
# ═════════════════════════════════════════════════════════════════════════════

inject_aws_cdk() {
    log_step "Injection du workflow NEXUS AWS-CDK (☁️)..."
    check_target "nexus-aws-cdk.yml"
    cat > "$WORKFLOWS_DIR/nexus-aws-cdk.yml" << 'NEXUS_CDK_YAML'
# ═══ NEXUS AWS-CDK — synth, cfn-lint, diff, artefact template ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "☁️ NEXUS AWS-CDK"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-cdk-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  NODE_VERSION: "20"
jobs:
  synth_and_lint:
    name: "🏗️ Synth & Lint Infra"
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no CDK project)
        run: |
          if [ ! -f "cdk.json" ] && [ ! -f "package.json" ]; then
            echo "::error::Aucun cdk.json — projet CDK non détecté."
            exit 1
          fi
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'
      - name: Install Dependencies
        run: npm ci || npm install
      - name: Install CDK CLI + cfn-lint
        run: |
          npm install --global aws-cdk
          python3 -m pip install --user cfn-lint
          echo "$HOME/.local/bin" >> "$GITHUB_PATH"
      - name: CDK Synth
        run: cdk synth --quiet
      - name: cfn-lint (templates synthétisés)
        run: |
          FAIL=0
          while IFS= read -r -d '' tpl; do
            cfn-lint "$tpl" || FAIL=1
          done < <(find cdk.out -name '*.template.json' -print0 2>/dev/null)
          if [ "$FAIL" -eq 1 ]; then
            echo "::error::cfn-lint a signalé des erreurs d'infrastructure."
            exit 1
          fi
      - name: CDK Diff (contexte PR)
        if: github.event_name == 'pull_request'
        run: cdk diff || true
        continue-on-error: true
      - name: Upload Synth Templates
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: cdk-synth-templates
          path: cdk.out/
          if-no-files-found: warn
      - name: Résumé CDK
        if: always()
        run: |
          {
            echo "## ☁️ NEXUS AWS-CDK"
            echo ""
            echo "- cdk synth --quiet → cdk.out/*.template.json"
            echo "- cfn-lint : validation bloquante des templates générés"
            echo "- cdk diff sur PR : delta d'infrastructure affiché (information)"
            echo "- Aucun déploiement depuis la CI — cdk deploy reste un geste humain."
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_CDK_YAML
    report_injection "AWS-CDK" "nexus-aws-cdk.yml" "1"
}
