
# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 06 — GO 🐹 (nouveau)
# gofmt --check, go vet, golangci-lint, test -race avec profil de coverage,
# govulncheck (vulnérabilités module), upload coverage.
# ═════════════════════════════════════════════════════════════════════════════

inject_go() {
    log_step "Injection du workflow NEXUS GO (🐹)..."
    check_target "nexus-go.yml"
    cat > "$WORKFLOWS_DIR/nexus-go.yml" << 'NEXUS_GO_YAML'
# ═══ NEXUS GO — vet, golangci-lint, test -race, govulncheck ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🐹 NEXUS GO"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-go-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  GO_VERSION: "1.24"
jobs:
  quality_and_test:
    name: "🔍 Quality, Race & Vulns"
    runs-on: ubuntu-latest
    timeout-minutes: 25
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup Go
        uses: actions/setup-go@v5
        with:
          go-version: ${{ env.GO_VERSION }}
          cache: true
      - name: Verify Modules
        run: go mod verify
      - name: Format Check
        run: |
          UNFORMATTED=$(gofmt -l .)
          if [ -n "$UNFORMATTED" ]; then
            echo "::error::Fichiers non formatés :"
            echo "$UNFORMATTED"
            exit 1
          fi
      - name: Vet
        run: go vet ./...
      - name: Golangci-Lint
        uses: golangci/golangci-lint-action@v6
        with:
          version: latest
      - name: Run Tests (race)
        run: go test -v -race -coverprofile=coverage.out -covermode=atomic ./...
      - name: Upload Coverage
        uses: actions/upload-artifact@v4
        with:
          name: go-coverage
          path: coverage.out
          if-no-files-found: ignore
      - name: Vulnerability Scan (govulncheck)
        continue-on-error: true
        run: |
          go install golang.org/x/vuln/cmd/govulncheck@latest
          govulncheck ./...
      - name: Résumé du build
        if: always()
        run: |
          {
            echo "## 🐹 NEXUS GO"
            echo ""
            echo "- gofmt --check : échec si non formaté"
            echo "- go vet + golangci-lint"
            echo "- go test -race → coverage.out uploadé"
            echo "- govulncheck : continue-on-error (signal, pas blocage)"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_GO_YAML
    report_injection "GO" "nexus-go.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 07 — DOCKER 🐳 (nouveau)
# Buildx multi-arch (amd64+arm64), cache GHA, scan image Trivy AVANT push,
# SBOM Syft, push réservé à main (pas les PR — sécurité), digest épinglé.
# ═════════════════════════════════════════════════════════════════════════════

inject_docker() {
    log_step "Injection du workflow NEXUS DOCKER (🐳)..."
    check_target "nexus-docker.yml"
    cat > "$WORKFLOWS_DIR/nexus-docker.yml" << 'NEXUS_DOCKER_YAML'
# ═══ NEXUS DOCKER — multi-arch, scan avant push, SBOM, digest ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🐳 NEXUS DOCKER"
on:
  push:
    branches: [ "main", "master" ]
    tags: [ "v*" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-docker-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  IMAGE_NAME: nexus-app
  REGISTRY: ghcr.io
jobs:
  build_scan_push:
    name: "🏗️ Build → Scan → SBOM → Push"
    runs-on: ubuntu-latest
    timeout-minutes: 30
    permissions:
      contents: read
      packages: write
      id-token: write
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Fail Fast (no Dockerfile)
        run: |
          if [ ! -f "Dockerfile" ]; then
            echo "::error::Aucun Dockerfile à la racine — job annulé."
            exit 1
          fi
      - name: Setup QEMU
        uses: docker/setup-qemu-action@v3
      - name: Setup Buildx
        uses: docker/setup-buildx-action@v3
      - name: Login GHCR
        if: github.event_name == 'push'
        uses: docker/login-action@v3
        with:
          registry: ${{ env.REGISTRY }}
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}
      - name: Metadata (tags auto)
        id: meta
        uses: docker/metadata-action@v5
        with:
          images: ${{ env.REGISTRY }}/${{ github.repository }}/${{ env.IMAGE_NAME }}
          tags: |
            type=ref,event=branch
            type=semver,pattern={{version}}
            type=sha
      - name: Build (no push)
        uses: docker/build-push-action@v6
        with:
          context: .
          platforms: linux/amd64,linux/arm64
          push: false
          load: true
          tags: ${{ steps.meta.outputs.tags }}
          cache-from: type=gha
          cache-to: type=gha,mode=max
      - name: Trivy Scan (image locale)
        uses: aquasecurity/trivy-action@0.28.0
        with:
          image-ref: '${{ fromJSON(steps.meta.outputs.json).tags[0] }}'
          format: 'table'
          exit-code: '1'
          severity: 'CRITICAL,HIGH'
          ignore-unfixed: true
      - name: SBOM (Syft)
        uses: anchore/sbom-action@v0
        with:
          image: '${{ fromJSON(steps.meta.outputs.json).tags[0] }}'
          format: 'spdx-json'
          artifact-name: sbom.spdx.json
      - name: Push (main/tags uniquement)
        if: github.event_name == 'push'
        uses: docker/build-push-action@v6
        with:
          context: .
          platforms: linux/amd64,linux/arm64
          push: true
          tags: ${{ steps.meta.outputs.tags }}
          labels: ${{ steps.meta.outputs.labels }}
          cache-from: type=gha
          cache-to: type=gha,mode=max
      - name: Résumé image
        if: always()
        run: |
          {
            echo "## 🐳 NEXUS DOCKER"
            echo ""
            echo "- Multi-arch : linux/amd64 + linux/arm64 (QEMU)"
            echo "- Trivy : CRITICAL/HIGH bloquants (exit 1) AVANT push"
            echo "- SBOM SPDX uploadé"
            echo "- Push : uniquement push (pas les PR)"
            echo "- Digest épinglé par buildx : \`${{ steps.meta.outputs.version }}\`"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_DOCKER_YAML
    report_injection "DOCKER" "nexus-docker.yml" "1"
}

# ═════════════════════════════════════════════════════════════════════════════
# TEMPLATE 08 — DOTNET 🔷 (nouveau)
# Restore → build → test (TRX collecté) → format --check → artefact publish.
# ═════════════════════════════════════════════════════════════════════════════

inject_dotnet() {
    log_step "Injection du workflow NEXUS DOTNET (🔷)..."
    check_target "nexus-dotnet.yml"
    cat > "$WORKFLOWS_DIR/nexus-dotnet.yml" << 'NEXUS_DOTNET_YAML'
# ═══ NEXUS DOTNET — restore, build, test, format, publish ═══
# Auteur : Aissa Mohammedi (DGK) — généré par NEXUS CI GENERATOR v2
name: "🔷 NEXUS DOTNET"
on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
concurrency:
  group: nexus-dotnet-${{ github.ref }}
  cancel-in-progress: false
permissions:
  contents: read
env:
  DOTNET_VERSION: "8.0.x"
  DOTNET_CONFIGURATION: Release
jobs:
  build_and_test:
    name: "🏗️ Build & Test .NET"
    runs-on: ubuntu-latest
    timeout-minutes: 25
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup .NET
        uses: actions/setup-dotnet@v4
        with:
          dotnet-version: ${{ env.DOTNET_VERSION }}
      - name: Fail Fast (no project)
        run: |
          if ! compgen -G '**/*.csproj' > /dev/null; then
            echo "::error::Aucun .csproj trouvé — job annulé."
            exit 1
          fi
      - name: Restore
        run: dotnet restore
      - name: Build
        run: dotnet build --no-restore --configuration "$DOTNET_CONFIGURATION"
      - name: Format Check
        run: dotnet format --verify-no-changes --no-restore || {
          echo "::warning::dotnet format a détecté du non-formaté";
          exit 1;
        }
      - name: Test
        run: |
          if compgen -G '**/*Tests.csproj' > /dev/null; then
            dotnet test --no-build --configuration "$DOTNET_CONFIGURATION" \
              --logger "trx;LogFileName=test-results.trx" \
              --results-directory ./test-results
          else
            echo "Aucun projet *Tests.csproj — tests ignorés."
          fi
      - name: Upload Test Results
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: dotnet-trx
          path: test-results/
          if-no-files-found: ignore
      - name: Publish
        run: |
          dotnet publish --no-restore --configuration "$DOTNET_CONFIGURATION" \
            --output ./publish
      - name: Upload Publish Artifact
        uses: actions/upload-artifact@v4
        with:
          name: dotnet-publish
          path: publish/
          if-no-files-found: ignore
      - name: Résumé du build
        if: always()
        run: |
          {
            echo "## 🔷 NEXUS DOTNET"
            echo ""
            echo "- .NET \${{ env.DOTNET_VERSION }} — $DOTNET_CONFIGURATION"
            echo "- restore → build → format --verify → test (TRX) → publish"
            echo "- Artefacts : dotnet-trx + dotnet-publish"
          } >> "$GITHUB_STEP_SUMMARY"
NEXUS_DOTNET_YAML
    report_injection "DOTNET" "nexus-dotnet.yml" "1"
}
