#!/usr/bin/env bash
set -u
export GENT_HOME=/tmp/gent-e2e
cd /tmp
PORT=43112 "$GENT_HOME/runtime/current/bin/node" --max-semi-space-size=64 "$GENT_HOME/app/gent-server.js" > /tmp/e2e.log 2>&1 &
for i in $(seq 1 40); do curl -fsS http://127.0.0.1:43112/api/health >/dev/null 2>&1 && break; sleep 0.3; done
agent-browser open http://127.0.0.1:43112/vision >/dev/null 2>&1
sleep 2.5
echo "== api() direct =="
agent-browser eval 'api("GET","/api/files?p=").then(function(x){return JSON.stringify({ok:x.ok,keys:Object.keys(x.j),n:(x.j.entries||[]).length})})'
echo "== fetch brut + json =="
agent-browser eval 'fetch("/api/files?p=",{headers:{"X-Gent-Token":T}}).then(function(r){return r.clone().json().then(function(j){return r.status+" keys="+Object.keys(j).join(",")})})'
echo "== typeof api, tree, load =="
agent-browser eval 'typeof api + "/" + typeof tree + "/" + typeof load'
echo "== EventSource state =="
agent-browser eval 'typeof es + " readyState=" + (typeof es !== "undefined" ? es.readyState : "-")'
agent-browser close >/dev/null 2>&1
pkill -f gent-server.js 2>/dev/null
true
