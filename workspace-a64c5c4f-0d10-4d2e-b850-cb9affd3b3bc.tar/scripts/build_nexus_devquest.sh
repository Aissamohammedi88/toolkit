#!/usr/bin/env bash
# ═════════════════════════════════════════════════════════════════════════════
# build_nexus_devquest.sh — assemble le YAML final avec moteur Python embarqué
# ═════════════════════════════════════════════════════════════════════════════
set -euo pipefail

SRC="/home/z/my-project/scripts/devquest_engine.py"
OUT="/home/z/my-project/download/nexus-devquest.yml"

[[ -f "$SRC" ]] || { echo "Missing $SRC"; exit 1; }

# Detect python for injection
PYBIN=""
for cmd in python3 python; do
  if command -v "$cmd" &>/dev/null; then
    PYBIN="$cmd"; break
  fi
done
[[ -n "$PYBIN" ]] || { echo "python3 required"; exit 1; }

# Write YAML header + run block opening
cat > "$OUT" <<'YAML_HEADER'
# ═════════════════════════════════════════════════════════════════════════════
# ██╗  ██╗██████╗  ███████╗ ██████╗ ███████╗██╗███████╗██╗   ██╗███████╗██████╗
# ██║ ██╔╝██╔══██╗██╔════╝██╔═══██╗██╔════╝██║██╔════╝██║   ██║██╔════╝██╔══██╗
# █████╔╝ ██████╔╝███████╗██║   ██║█████╗  ██║█████╗  ██║   ██║█████╗  ██████╔╝
# ██╔═██╗ ██╔══██╗╚════██║██║   ██║██╔══╝  ██║██╔══╝  ╚██╗ ██╔╝██╔══╝  ██╔══██╗
# ██║  ██╗██████╔╝███████║╚██████╔╝██║     ██║███████╗ ╚████╔╝ ███████╗██║  ██║
# ╚═╝  ╚═╝╚═════╝ ╚══════╝ ╚═════╝ ╚═╝     ╚═╝╚══════╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝
# ═════════════════════════════════════════════════════════════════════════════
# NEXUS DEVQUEST — workflow GitHub Actions
# ═════════════════════════════════════════════════════════════════════════════
# Transforme ton repo en RPG. À chaque push :
#   1. Calcule XP (lignes + fichiers + commits)
#   2. Met à jour niveau + titre (Novice → Légende)
#   3. Génère 3 badges SVG animés (level, title, xp)
#   4. Génère un avatar ASCII basé sur les langages du repo
#   5. Génère 3 "quêtes" adaptées à l'état du repo
#   6. Écrit README-devquest.md (fiche de personnage)
#   7. Archive chaque niveau dans .devquest/history.jsonl
#   8. Commit + push automatique (via GITHUB_TOKEN, [skip ci])
#
# Stack : YAML pur + Python 3 stdlib (zéro dépendance, zéro pip).
# Auteur : Aissa Mohammedi (DGK)
# License: NEXUS-OPEN-3.0
# ═════════════════════════════════════════════════════════════════════════════

name: Nexus DevQuest

on:
  push:
    branches: [main, master]
  workflow_dispatch:

permissions:
  contents: write   # pour commit/push les badges + README
  actions: read

concurrency:
  group: nexus-devquest-${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: false

jobs:
  level-up:
    runs-on: ubuntu-latest
    timeout-minutes: 5
    steps:
      - name: Checkout (full history for XP calc)
        uses: actions/checkout@v4
        with:
          fetch-depth: 0
          token: ${{ secrets.GITHUB_TOKEN }}

      - name: Setup Python 3.11
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'

      - name: DevQuest Engine — XP + badges + quêtes + README
        env:
          BEFORE: ${{ github.event.before }}
          AFTER: ${{ github.event.after }}
          ACTOR: ${{ github.actor }}
          REPOSITORY: ${{ github.repository }}
          GITHUB_WORKSPACE: ${{ github.workspace }}
        run: |
          python3 - <<'PYEOF'
YAML_HEADER

# Inject engine source with 10-space indent (matches the `run: |` block)
"$PYBIN" - "$SRC" "$OUT" <<'PYINJ'
import sys
src_path, out_path = sys.argv[1:3]
with open(src_path, "r", encoding="utf-8") as f:
    src = f.read()

# Indent every line by 10 spaces (to fit inside the YAML `run: |` block)
# Empty lines get just the indent (10 spaces).
indented = "\n".join("          " + line if line else "          " for line in src.splitlines())

with open(out_path, "a", encoding="utf-8") as f:
    f.write(indented + "\n")

print(f"✓ injected {len(src.splitlines())} lines of engine source")
PYINJ

# Write YAML footer (closing PYEOF + commit step + summary step)
cat >> "$OUT" <<'YAML_FOOTER'
          PYEOF

      - name: Commit & push artifacts (GITHUB_TOKEN, no re-trigger)
        run: |
          git config user.name "Nexus DevQuest"
          git config user.email "devquest@nexus.local"
          git add .devquest/ badges/ README-devquest.md 2>/dev/null || true
          if git diff --cached --quiet; then
            echo "ℹ No DevQuest changes to commit."
            exit 0
          fi
          git commit -m "⚛ devquest: level up [skip ci]"
          git push

      - name: Step Summary (visible dans l'onglet Summary)
        if: always()
        run: |
          if [ -f .devquest/state.json ]; then
            python3 - <<'PYEOF'
          import json
          with open(".devquest/state.json") as f:
              s = json.load(f)
          print(f"### ⚛ Nexus DevQuest — Niveau {s['level']} ({s['title']})")
          print("")
          print(f"**XP** : {s['xp']:,}")
          print(f"**Achievements débloqués** : {len(s['achievements'])}")
          print(f"**Commits cumulés** : {s['total_commits']}")
          print(f"**Langages détectés** : {len(s['languages'])}")
          print(f"**Fiche de personnage** : \`README-devquest.md\`")
          PYEOF
          else
            echo "⚠ .devquest/state.json absent"
          fi
YAML_FOOTER

echo ""
echo "✓ Livrable : $OUT"
echo "  Taille : $(wc -c < "$OUT") octets, $(wc -l < "$OUT") lignes"
