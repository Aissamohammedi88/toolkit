#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Banc d'essai PROTON-CALC (DGK) — prouve par exécution.
Usage : python3 proton_edge_tests.py <chemin_module> <label>
"""
import importlib.util
import subprocess
import sys


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def run_gen_code(code):
    """Exécute pour de vrai le code généré et retourne la sortie (ou la dernière ligne d'erreur)."""
    try:
        p = subprocess.run([sys.executable, "-c", code],
                           capture_output=True, text=True, timeout=5)
        out = p.stdout.strip()
        if out:
            return out
        if p.stderr.strip():
            return "ERREUR -> " + p.stderr.strip().splitlines()[-1]
        return "(sortie vide)"
    except Exception as e:
        return f"EXC: {e}"


path, label = sys.argv[1], sys.argv[2]
m = load(path, label)
E = m.SafeMathEvaluator.evaluate
G = m.MathCodeGenerator.generate_from_expression

print(f"===== {label} =====")

# Le cœur — calculs purs
print(f"[T01] evaluate('sin(pi/2)')                  -> {E('sin(pi/2)')}")
print(f"[T02] evaluate('sqrt(16)+sin(pi/2)+log(100,10)') -> {E('sqrt(16) + sin(pi/2) + log(100, 10)')}")
print(f"[T03] evaluate(\"__import__('os')\")           -> {E('__import__(\"os\")')}")

# Piège n°1 : ^ = xor ou puissance ?
print(f"[T04] evaluate('2^10')                       -> {E('2^10')}")
print(f"[T05] evaluate('2**10')                       -> {E('2**10')}")

# Piège n°2 : le générateur corrompt-il les expressions ?
c3 = G("exp(2)")
print(f"[T06] gen('exp(2)') dernière ligne           -> {c3.strip().splitlines()[-1]!r}")
print(f"[T07] exec du code T06                        -> {run_gen_code(c3)}")

c5 = G("sqrt(1e-9)")
print(f"[T08] gen('sqrt(1e-9)') dernière ligne        -> {c5.strip().splitlines()[-1]!r}")
print(f"[T09] exec du code T08                        -> {run_gen_code(c5)}")

c7 = G("mean([10, 20, 30])")
print(f"[T10] gen('mean([10,20,30])') dernière ligne  -> {c7.strip().splitlines()[-1]!r}")
print(f"[T11] exec du code T10                        -> {run_gen_code(c7)}")

# Piège n°3 : verify_python_code vérifie-t-il VRAIMENT la sortie attendue ?
r = m.MathVerifier.verify_python_code("print(42)", "", "999")
print(f"[T12] verify_code(print(42), attendu=999)     -> valid={r.get('valid')}  (999 est FAUX : doit être False)")
r = m.MathVerifier.verify_python_code("print(42)", "", "42")
print(f"[T13] verify_code(print(42), attendu=42)      -> valid={r.get('valid')}  (doit être True)")
print()
