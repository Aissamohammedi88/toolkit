#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
# verify_nci_proton.sh — BANC DE VÉRIFICATION PROTON (re-run complet)
# Toute la preuve en UNE SEULE invocation (règle mortalité sandbox).
# Sortie compacte volontaire (OMEGA R8 : pas de sortie > 50000).
# ═══════════════════════════════════════════════════════════════════════════
set -uo pipefail   # pas de -e : on capture les codes retour nous-mêmes

GEN="/home/z/my-project/scripts/nexus-ci-generator.sh"
AL="/home/z/my-project/scripts/actionlint"
PASS=0; FAIL=0
ck() {  # ck <ok:0/1> <label>
    if [ "$1" -eq 0 ]; then PASS=$((PASS+1)); printf '  [PASS] %s\n' "$2"
    else FAIL=$((FAIL+1)); printf '  [FAIL] %s\n' "$2"; fi
}

echo "══ [P0] PREUVES FICHIER ══"
LINES="$(wc -l <"$GEN")"
[ "$LINES" -eq 3999 ]; ck $? "wc -l = 3999 (lu: $LINES)"
bash -n "$GEN" 2>/dev/null; ck $? "bash -n syntaxe"
SHA_S="$(sha256sum "$GEN" | cut -c1-16)"
SHA_D="$(sha256sum /home/z/my-project/download/nexus-ci-generator.sh | cut -c1-16)"
[ "$SHA_S" = "$SHA_D" ]; ck $? "sha256 identique scripts/↔download/ ($SHA_S)"
[ -x "$GEN" ]; ck $? "bit exécutable"

echo "══ [P1] SELFTEST INTÉGRÉ (banc 18 tests / 20 assertions) ══"
OUT="$(bash "$GEN" selftest 2>&1)"; RC=$?
printf '%s\n' "$OUT" | grep -E 'PASS|FAIL|OK' | tail -6
ck $RC "selftest code retour (rc=$RC)"
printf '%s\n' "$OUT" | grep -Eq 'FAIL=0'; ck $? "selftest rapporte FAIL=0"

echo "══ [P2] E2E INDÉPENDANT — dépôt git temporaire, 13 types ══"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cd "$TMP" && git init -q . && git config user.email t@t && git config user.name t
TYPES="aegis java python node docker go rust release nightly php dotnet cpp android"
GENOK=0
for T in $TYPES; do
    if bash "$GEN" "$T" --dir "$TMP" >/dev/null 2>&1; then GENOK=$((GENOK+1)); fi
done
[ "$GENOK" -eq 13 ]; ck $? "13/13 types générés (ok=$GENOK)"
NFILES="$(ls .github/workflows/*.yml 2>/dev/null | wc -l)"
[ "$NFILES" -eq 13 ]; ck $? "13 fichiers .github/workflows/*.yml (trouvés=$NFILES)"

echo "══ [P3] VALIDATION PyYAML EXTERNE (indépendante du générateur) ══"
python3 - "$TMP" <<'PY'
import sys, glob, yaml
d = sys.argv[1]; files = sorted(glob.glob(d + "/.github/workflows/*.yml"))
errs = []
for f in files:
    try:
        doc = yaml.safe_load(open(f))
        # quirk PyYAML : clé 'on' non quotée → booléen True → caster en str
        keys = set(str(k).lower() for k in doc.keys())
        if "true" in keys:  # quirk PyYAML 1.1 : 'on' non quoté → True
            keys.add("on")
        if not {"on", "jobs"} <= keys: errs.append(f + ": clés on/jobs absentes")
        for jid, job in doc["jobs"].items():
            if "runs-on" not in job: errs.append(f"{f}: job {jid} sans runs-on")
        txt = open(f).read()
        if "run: actions/setup-node" in txt or "run: actions/checkout" in txt:
            errs.append(f + ": bug skeleton 'run: actions/...' présent")
    except yaml.YAMLError as e: errs.append(f + ": " + str(e).split("\n")[0])
print(f"  PyYAML: {len(files)} fichiers, {len(errs)} erreurs")
for e in errs[:10]: print("  ERR:", e)
sys.exit(1 if errs else 0)
PY
ck $? "PyYAML 13 fichiers : syntaxe + on/jobs/runs-on + bug skeleton absent"

echo "══ [P4] FIX SKELETON PRUVÉ (aegis : uses: et non run:) ══"
AE="$TMP/.github/workflows/nexus-aegis.yml"
grep -q 'uses: actions/setup-node@' "$AE"; ck $? "aegis contient 'uses: actions/setup-node@v…' (fix du skeleton)"
BAD="$(grep -c 'run: *actions/' "$AE" || true)"
[ "$BAD" -eq 0 ]; ck $? "aegis : zéro 'run: actions/' (lu=$BAD)"

echo "══ [P5] ACTIONLINT 1.7.7 (validation GitHub Actions niveau schema) ══"
ALOK=0; ALKO=0
for F in .github/workflows/*.yml; do
    if "$AL" "$F" >/dev/null 2>&1; then ALOK=$((ALOK+1))
    else ALKO=$((ALKO+1)); echo "  AL_KO: $(basename "$F")"; "$AL" "$F" 2>&1 | head -3; fi
done
echo "  actionlint: $ALOK OK / $ALKO KO sur 13 workflows"
[ "$ALKO" -eq 0 ]; ck $? "actionlint passe sur les 13 workflows"

echo "══ [P6] IDEMPOTENCE + UNINSTALL (marqueur anti-effacement manuel) ══"
bash "$GEN" aegis --dir "$TMP" >/dev/null 2>&1; RC=$?
[ "$RC" -ne 0 ]; ck $? "re-générer sans --force échoue proprement (rc=$RC)"
bash "$GEN" aegis --dir "$TMP" --force >/dev/null 2>&1; ck $? "re-générer avec --force OK"
bash "$GEN" uninstall aegis --dir "$TMP" --force >/dev/null 2>&1; RC=$?
[ "$RC" -eq 0 ] && [ ! -e "$TMP/.github/workflows/nexus-aegis.yml" ] && [ -e "$TMP/.github/workflows/nexus-java.yml" ]
ck $? "uninstall aegis retire SEUL aegis (les autres intacts)"

echo "══ [P7] COMMANDES SECONDAIRES ══"
bash "$GEN" list >/dev/null 2>&1; ck $? "sous-commande list"
bash "$GEN" doctor >/dev/null 2>&1; ck $? "sous-commande doctor"
bash "$GEN" manuel >/dev/null 2>&1 || bash "$GEN" manual >/dev/null 2>&1 || bash "$GEN" help >/dev/null 2>&1
ck $? "aide/manuel"
bash "$GEN" type_inexistant --dir "$TMP" >/dev/null 2>&1; BADTYPE=$?
[ "$BADTYPE" -ne 0 ]; ck $? "type inconnu rejeté (rc=$BADTYPE)"

echo "════════════════════════════════════════════════════════════════"
echo "BILAN: $PASS PASS / $FAIL FAIL"
[ "$FAIL" -eq 0 ] && echo "TOUT VERT — générateur re-certifié par banc externe" || echo "ÉCHEC — investigation requise"
exit "$FAIL"
