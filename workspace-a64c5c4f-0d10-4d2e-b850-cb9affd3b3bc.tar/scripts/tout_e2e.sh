#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
# tout_e2e.sh — BANC D'ESSAI PROTON de nexus-tout-en-un.sh
# TOUT en UNE invocation (règle mortalité sandbox). Scénarios :
#   A. dossier simulé "téléchargé" + package.json sans lockfile → full run
#   A2. avec lockfile → doit choisir npm ci
#   B. sans package.json → npm déclaré manquant, 13 workflows quand même
#   C. SOURCÉ → le parent doit rester VIVANT (garde n°1)
#   D. ANCIEN générateur (tamponné) → warning version + run quand même
#   E. --only aegis node → exactement 2 workflows
#   F. COLLAGE simulé (bash -i + pipe) → PASTE_SURVIVED doit s'afficher (garde n°2)
#   G. option inconnue → rc=1 | H. générateur introuvable → rc=2
# ═══════════════════════════════════════════════════════════════════════════
set -uo pipefail
TOUT=/home/z/my-project/scripts/nexus-tout-en-un.sh
PASS=0; FAIL=0
ck() { if [ "$1" -eq 0 ]; then PASS=$((PASS+1)); printf '  [PASS] %s\n' "$2"
       else FAIL=$((FAIL+1)); printf '  [FAIL] %s\n' "$2"; fi; }

BASE="$(mktemp -d)"
trap 'rm -rf "$BASE"' EXIT
DOSSIER="$BASE/telecharge"; REPOA="$BASE/repoA"; REPOA2="$BASE/repoA2"
REPOB="$BASE/repoB"; REPOC="$BASE/repoC"
mkdir -p "$DOSSIER" "$REPOA" "$REPOA2" "$REPOB" "$REPOC"
cp /home/z/my-project/scripts/nexus-ci-generator.sh "$DOSSIER/"
cp "$TOUT" "$DOSSIER/"
chmod +x "$DOSSIER"/*.sh

echo "══ [0] SYNTAXE ══"
bash -n "$TOUT" 2>/dev/null; ck $? "bash -n nexus-tout-en-un.sh"
printf '  lignes: %s\n' "$(wc -l <"$TOUT")"

echo "══ [A] RUN COMPLET — repoA (package.json, sans lockfile) ══"
printf '{\n  "name": "dgk-lab",\n  "version": "1.0.0",\n  "scripts": {\n    "build": "echo BUILD_OK_MARKER",\n    "test": "echo TEST_OK_MARKER"\n  }\n}\n' > "$REPOA/package.json"
cp "$REPOA/package.json" "$REPOA2/package.json"
OUTA="$(cd "$DOSSIER" && bash nexus-tout-en-un.sh --repo "$REPOA" 2>&1)"; RCA=$?
printf '%s\n' "$OUTA" | grep -E '\[OK\]|\[WARN\]|\[ERR\]|selftest|BILAN' | head -20
ck $RCA "A: code retour (rc=$RCA)"
printf '%s\n' "$OUTA" | grep -q 'selftest TOUT VERT'; ck $? "A: selftest vert"
NA="$(find "$REPOA/.github/workflows" -name '*.yml' 2>/dev/null | wc -l)"
[ "$NA" -eq 13 ]; ck $? "A: 13 workflows (trouvés=$NA)"
printf '%s\n' "$OUTA" | grep -q 'npm install terminé'; ck $? "A: npm install"
printf '%s\n' "$OUTA" | grep -q 'npm run build terminé'; ck $? "A: npm run build"
printf '%s\n' "$OUTA" | grep -q 'npm test terminé'; ck $? "A: npm test"

echo "══ [A2] LOCKFILE → npm ci ══"
(cd "$REPOA2" && npm install --package-lock-only --no-audit --no-fund >/dev/null 2>&1)
OUTA2="$(cd "$DOSSIER" && bash nexus-tout-en-un.sh --repo "$REPOA2" --skip-selftest 2>&1)"; RCA2=$?
[ "$RCA2" -eq 0 ]; ck $? "A2: code retour (rc=$RCA2)"
printf '%s\n' "$OUTA2" | grep -q 'npm ci terminé'; ck $? "A2: npm ci choisi (pas npm install)"
[ ! -f "$REPOA2/node_modules/.package-lock.json" ] || printf '  (info: node_modules présent après ci)\n'

echo "══ [B] SANS package.json — npm déclaré manquant ══"
OUTB="$(cd "$DOSSIER" && bash nexus-tout-en-un.sh --repo "$REPOB" --skip-selftest 2>&1)"; RCB=$?
[ "$RCB" -eq 0 ]; ck $? "B: code retour (rc=$RCB)"
NB="$(find "$REPOB/.github/workflows" -name '*.yml' 2>/dev/null | wc -l)"
[ "$NB" -eq 13 ]; ck $? "B: 13 workflows quand même (trouvés=$NB)"
printf '%s\n' "$OUTB" | grep -q 'pas de package.json'; ck $? "B: npm déclaré manquant (PROTON ③)"

echo "══ [C] SOURCÉ — le parent doit survivre (garde n°1) ══"
OUTC="$(bash -c "source '$TOUT' --repo '$REPOC' --skip-selftest --skip-npm >/dev/null 2>&1; echo PARENT_VIVANT_rc=\$?" 2>&1)"
printf '  %s\n' "$OUTC"
printf '%s\n' "$OUTC" | grep -q 'PARENT_VIVANT_rc=0'; ck $? "C: source → parent vivant + rc=0"
NC="$(find "$REPOC/.github/workflows" -name '*.yml' 2>/dev/null | wc -l)"
[ "$NC" -eq 13 ]; ck $? "C: re-exécution enfant a bien généré 13 workflows (trouvés=$NC)"

echo "══ [D] ANCIEN générateur → warning + run quand même ══"
sed 's/__NODE_MATRIX__/ANCIEN/g' /home/z/my-project/scripts/nexus-ci-generator.sh > "$BASE/gen_vieux.sh"
chmod +x "$BASE/gen_vieux.sh"
mkdir -p "$BASE/dossier_vieux"; cp "$TOUT" "$BASE/dossier_vieux/"
OUTD="$(cd "$BASE/dossier_vieux" && bash nexus-tout-en-un.sh --generator "$BASE/gen_vieux.sh" --repo "$REPOB" --skip-selftest --skip-npm 2>&1)"; RCD=$?
[ "$RCD" -eq 0 ]; ck $? "D: code retour (rc=$RCD)"
printf '%s\n' "$OUTD" | grep -q 'ANCIENNE VERSION'; ck $? "D: warning ANCIENNE VERSION affiché"

echo "══ [E] --only aegis node ══"
rm -rf "$REPOC/.github"; cd "$BASE/dossier_vieux" 2>/dev/null
OUTE="$(cd "$DOSSIER" && bash nexus-tout-en-un.sh --repo "$REPOC" --skip-selftest --skip-npm --only aegis node 2>&1)"; RCE=$?
[ "$RCE" -eq 0 ]; ck $? "E: code retour (rc=$RCE)"
NE="$(find "$REPOC/.github/workflows" -name '*.yml' 2>/dev/null | wc -l)"
[ "$NE" -eq 2 ]; ck $? "E: exactement 2 workflows (trouvés=$NE)"

echo "══ [F] COLLAGE SIMULÉ (bash -i, entrée fichier) — PASTE_SURVIVED (garde n°2) ══"
# cwd = le dossier téléchargé (comme DGK qui colle dans son dossier)
PASTE="$BASE/paste_test.sh"
cat "$TOUT" > "$PASTE"
printf '\necho PASTE_SURVIVED\n' >> "$PASTE"
FOUT="$( cd "$DOSSIER" && bash -i < "$PASTE" 2>/dev/null | grep -c 'PASTE_SURVIVED' )"
if [ "${FOUT:-0}" -ge 1 ]; then ck 0 "F: terminal interactif a survécu au collage brut"
else ck 1 "F: collage — PASTE_SURVIVED absent"; fi
FD="$(find "$DOSSIER/.github/workflows" -name '*.yml' 2>/dev/null | wc -l)"
[ "$FD" -eq 13 ]; ck $? "F: le collé a TOUT fait lui-même dans le dossier (trouvés=$FD)"
[ -d "$DOSSIER/.git" ]; ck $? "F: git init fait par le collé"

echo "══ [G] option inconnue → rc=1 ══"
bash "$TOUT" --option-inexistante >/dev/null 2>&1; RCG=$?
[ "$RCG" -eq 1 ]; ck $? "G: rc=1 (lu=$RCG)"

echo "══ [H] générateur introuvable → rc=2 ══"
mkdir -p "$BASE/vide_dir"
(cd "$BASE/vide_dir" && bash "$TOUT" --repo "$BASE/vide_dir" --generator "$BASE/inexistant.sh" >/dev/null 2>&1); RCH=$?
[ "$RCH" -eq 2 ]; ck $? "H: rc=2 (lu=$RCH)"

echo "════════════════════════════════════════════════════════════════"
echo "BILAN: $PASS PASS / $FAIL FAIL"
[ "$FAIL" -eq 0 ] && echo "TOUT VERT — orchestrateur certifié" || echo "ÉCHEC — investigation requise"
exit "$FAIL"
