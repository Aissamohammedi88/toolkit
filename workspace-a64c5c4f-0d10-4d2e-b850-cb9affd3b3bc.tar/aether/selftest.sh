#!/usr/bin/env bash
# Selftest Aether — suite complète de vérification du réseau.
#   1. tests unitaires (cargo test)
#   2. build du binaire
#   3. réseau local réel : routeur + 2 nœuds calculants + client
#   4. contre-vérification Python indépendante du résultat
# Usage : bash selftest.sh   (depuis la racine du dépôt)
set -uo pipefail
cd "$(dirname "$0")"

VERT=$'\033[32m'; ROUGE=$'\033[31m'; JAUNE=$'\033[33m'; BLEU=$'\033[34m'; NEUTRE=$'\033[0m'
PASS=0; FAIL=0
ok() { printf '%s✓ %s — %s%s\n' "$VERT" "$1" "$2" "$NEUTRE"; PASS=$((PASS + 1)); }
ko() { printf '%s✗ %s — %s%s\n' "$ROUGE" "$1" "$2" "$NEUTRE"; FAIL=$((FAIL + 1)); }

CARGO=${CARGO:-cargo}
NODE=target/debug/aether-node
PORT=$((41000 + $$ % 1000))
DIR=$(mktemp -d)
trap 'pkill -f "target/debug/aether-node (bootstrap|worker)" 2>/dev/null; rm -rf "$DIR"' EXIT

attendre() { # attendre <fichier> <motif> <essais>
    local fichier=$1 motif=$2 essais=${3:-100} i
    for i in $(seq 1 "$essais"); do
        grep -q "$motif" "$fichier" 2>/dev/null && return 0
        sleep 0.3
    done
    return 1
}

printf '%s═══ Selftest Aether (port de test : %s) ═══%s\n' "$BLEU" "$PORT" "$NEUTRE"

# T1 — tests unitaires
printf '%s[T1] tests unitaires…%s\n' "$BLEU" "$NEUTRE"
if $CARGO test --workspace --quiet >"$DIR/tests.log" 2>&1 && grep -q "test result: ok" "$DIR/tests.log"; then
    NB=$(grep -o 'test result: ok\. [0-9]* passed' "$DIR/tests.log" | awk '{s += $4} END {print s + 0}')
    ok "T1" "tests unitaires : $NB passés, 0 échec"
else
    ko "T1" "tests unitaires en échec"
    tail -20 "$DIR/tests.log"
fi

# T2 — build
printf '%s[T2] build du binaire…%s\n' "$BLEU" "$NEUTRE"
if $CARGO build --quiet >"$DIR/build.log" 2>&1; then
    ok "T2" "build debug : $NODE"
else
    ko "T2" "build en échec"
    tail -20 "$DIR/build.log"
fi

# T3 — réseau local complet
if [ -x "$NODE" ]; then
    printf '%s[T3] réseau local réel : routeur + 2 workers + client…%s\n' "$BLEU" "$NEUTRE"
    "$NODE" bootstrap --port "$PORT" >"$DIR/bootstrap.out" 2>"$DIR/bootstrap.log" &
    if attendre "$DIR/bootstrap.log" "écoute :"; then
        ok "T3a" "routeur en écoute"
    else
        ko "T3a" "routeur sans écoute"; cat "$DIR/bootstrap.log"
    fi
    "$NODE" worker --bootstrap "/ip4/127.0.0.1/tcp/$PORT" >"$DIR/w1.out" 2>"$DIR/w1.log" &
    "$NODE" worker --bootstrap "/ip4/127.0.0.1/tcp/$PORT" >"$DIR/w2.out" 2>"$DIR/w2.log" &
    if attendre "$DIR/bootstrap.log" "enregistré" && [ "$(grep -c enregistré "$DIR/bootstrap.log")" -ge 2 ]; then
        ok "T3b" "2 nœuds calculants enregistrés (battements OK)"
    else
        ko "T3b" "workers non enregistrés"; tail -5 "$DIR/bootstrap.log"
    fi
    "$NODE" submit --bootstrap "/ip4/127.0.0.1/tcp/$PORT" --from 2 --to 200000 --chunks 8 --timeout 60 \
        >"$DIR/result.json" 2>"$DIR/client.log"
    if [ -s "$DIR/result.json" ]; then
        ok "T3c" "tâche distribuée calculée et agrégée"
        cat "$DIR/result.json"
    else
        ko "T3c" "le client n'a pas obtenu de résultat"; cat "$DIR/client.log"
    fi
    if grep -q "tunnel chiffré établi" "$DIR/bootstrap.log"; then
        ok "T3d" "tunnels chiffrés (Noise) attestés dans les journaux"
    else
        ko "T3d" "aucun tunnel chiffré constaté"
    fi
    N1=$(grep -c "calcul…" "$DIR/w1.log" || true)
    N2=$(grep -c "calcul…" "$DIR/w2.log" || true)
    if [ "$N1" -gt 0 ] && [ "$N2" -gt 0 ]; then
        ok "T3e" "répartition de charge : worker1=$N1 morceau(x), worker2=$N2 morceau(x)"
    else
        ko "T3e" "répartition de charge anormale : worker1=$N1, worker2=$N2"
    fi
    # T4 — contre-vérification indépendante
    if [ -s "$DIR/result.json" ]; then
        printf '%s[T4] contre-vérification Python indépendante…%s\n' "$BLEU" "$NEUTRE"
        ATTENDU=$(python3 -c "
n=200000
s=bytearray([1])*(n+1); s[0]=s[1]=0
for i in range(2,int(n**0.5)+1):
    if s[i]: s[i*i::i]=bytearray(len(s[i*i::i]))
print(sum(s[2:]))")
        RECU=$(python3 -c "import json;print(json.load(open('$DIR/result.json'))['primes_found'])" 2>/dev/null || echo "?")
        if [ "$ATTENDU" = "$RECU" ]; then
            ok "T4" "exactitude : $RECU premiers (identique au crible Python)"
        else
            ko "T4" "écart : attendu $ATTENDU, reçu $RECU"
        fi
    fi
else
    ko "T3" "binaire absent — build d'abord (cargo build)"
fi

printf '%s═══ Bilan : %d verts, %d rouges ═══%s\n' "$BLEU" "$PASS" "$FAIL" "$NEUTRE"
[ "$FAIL" -eq 0 ]
