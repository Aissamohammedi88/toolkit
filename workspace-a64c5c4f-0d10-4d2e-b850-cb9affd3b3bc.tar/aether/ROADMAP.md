# Feuille de route Aether

Chaque phase a un **critère de sortie mesurable** — pas de « améliorations
diverses ».

## Phase 1 — MVP réseau (✅ livrée, vérifiée)

- Workspace 5 crates, tunnel chiffré Noise+Yamux, protocole req/rep JSON ;
- `bootstrap` / `worker` / `submit`, battements, TTL, reprise sur échec ;
- Selftest réseau automatisé avec contre-vérification Python.

**Critère de sortie** : un réseau local de 2+ workers calcule une tâche
découpée et le résultat agrégé est exact. ✅ (17984/17984 premiers,
charge 4+4 morceaux, tunnels chiffrés attestés dans les journaux.)

## Phase 2 — Résilience et hétérogénéité

- **Validation par redondance** : chaque morceau exécuté sur 2 nœuds
  distincts, désaccord ⇒ élection ; coût : ×2 calcul, gain : détection des
  nœuds menteurs ;
- **Découverte décentralisée** : Kademlia DHT + annonces gossipsub des
  capacités (le routeur n'est plus un point de rendez-vous unique) ;
- **Traversée NAT** : relais libp2p + hole punching (dcutr), transport QUIC ;
- **Planification consciente** : choix du worker par capacités annoncées et
  charge observée ;
- Nouvel exécuteur : recherche de collisions par lots (SHA-256) — charge
  réellement inégale entre nœuds.

**Critère de sortie** : 3 machines physiques différentes sur 2 réseaux
différents, sans routeur central sur LAN, tâche complète validée.

## Phase 3 — Preuves à divulgation nulle

- Sélection du moteur (candidats : **RISC Zero** zkVM — preuve d'un
  binaire Rust ; **SP1** — intégration Ethereum directe ; **arkworks** —
  circuits Groth16 sur mesure) ;
- Énoncé prouvé : « le résultat agrégé B découle des morceaux signés
  {m_i} par les PeerId {p_i} pour la tâche T » ;
- `aether-zk` : implémentation réelle du trait `Prover` + banc de vérification.

**Critère de sortie** : une preuve vérifiable en < 5 s hors ligne, taille
< 100 ko, générée sur du matériel grand public.

## Phase 4 — Ancrage blockchain et économie

- Contrat de vérification on-chain (L2 à frais réduits) : dépôt de
  preuve + énoncé haché ;
- Paiement des nœuds calculants, dépôt de garantie (staking), slashing sur
  preuve de mensonge ;
- Marché de la capacité : enchères de morceaux par lots.

**Critère de sortie** : un cycle complet tâche → preuve → paiement
exécuté sur un testnet, sans intervention manuelle.

## Phase 5 — Calcul hétérogène réel

- Exécuteur GPU via `wgpu` (CUDA/Vulkan/Metal) — cible explicite :
  PC gamer (GPU), serveur (CPU), Mac M3 (Metal via wgpu) ;
- Chiffrement applicatif de bout en bout des tâches sensibles (le routeur
  devient aveugle) ;
- Interface utilisateur (hors navigateur — ligne de conduite du projet).

**Critère de sortie** : une tâche GPU exécutée sur 2 GPU hétérogènes avec
le même résultat bit-à-bit et preuve ZK associée.
