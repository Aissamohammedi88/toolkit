# Aether — réseau de calcul distribué P2P (Rust)

Aether est un réseau pair-à-pair de **calcul distribué chiffré** : des tâches
sont découpées par un routeur, distribuées à des nœuds calculants hétérogènes
via des tunnels chiffrés, puis les résultats sont agrégés et renvoyés au
client. À terme : preuves à divulgation nulle et ancrage blockchain.

**État actuel : MVP Phase 1 — vérifié.** Tunnel chiffré libp2p (Noise +
Yamux), protocole requête/réponse, distribution multi-nœuds, reprise sur
échec, contre-vérification d'exactitude automatisée.

```text
   client (submit)                routeur (bootstrap)              workers
        │  soumission                 │                             │
        ├────────────────────────────▶│  découpe en morceaux        │
        │                             ├──Hello/battements──────────▶│
        │                             ├──morceau (chiffré)─────────▶│
        │                             │◀──résultat du morceau───────┤
        │                             │   … un morceau par worker … │
        │◀──résultat agrégé───────────┤                             │
        │  (JSON : count, workers,    │                             │
        │   temps CPU, temps mur)     │                             │
```

## Démarrage rapide (3 terminaux)

```bash
cargo build                                # ~5-15 min la première fois

# Terminal 1 — le routeur
./target/debug/aether-node bootstrap --port 4001

# Terminal 2 et 3 — deux nœuds calculants
./target/debug/aether-node worker --bootstrap /ip4/127.0.0.1/tcp/4001
./target/debug/aether-node worker --bootstrap /ip4/127.0.0.1/tcp/4001

# N'importe où — soumettre une tâche (premiers dans [2, 200000])
./target/debug/aether-node submit --to 200000 --chunks 8
```

Sortie du client (JSON, consommable par `jq`) :

```json
{
  "primes_found": 17984,
  "workers": ["12D3KooW…d9PR", "12D3KooW…5Fyi"],
  "cpu_ms": 29.5,
  "mur_ms": 89.5
}
```

## Structure du dépôt

| Crate            | Rôle                                                       |
| ---------------- | ---------------------------------------------------------- |
| `aether-core`    | Contrat partagé : tâches, morceaux, résultats, protocole   |
| `aether-net`     | Tunnels chiffrés libp2p : TCP → Noise → Yamux → req/resp   |
| `aether-compute` | Routeur cognitif MVP : découpage, exécution, agrégation    |
| `aether-zk`      | Preuves ZK — contrat figé, implémentation en Phase 3       |
| `aether-node`    | Le binaire : `bootstrap` / `worker` / `submit`             |

## Tests

```bash
cargo test --workspace        # 17 tests unitaires
bash selftest.sh              # suite complète : unitaires + réseau 3 nœuds
```

Le test d'intégration (`selftest.sh`) lance un vrai réseau local (routeur +
2 workers + client), vérifie le chiffrement des tunnels dans les journaux et
contre-vérifie le résultat avec un crible Python indépendant.

## Documentation

- [`ARCHITECTURE.md`](ARCHITECTURE.md) — chaîne complète, protocole, modèle de menace
- [`ROADMAP.md`](ROADMAP.md) — de la Phase 1 (actuelle) à la Phase 5 (GPU, blockchain)

## Avertissement honnête

C'est un MVP de recherche : la validation des résultats repose uniquement
sur l'exactitude déterministe de l'exécuteur (et la contre-vérification du
selftest) — **pas** encore sur des preuves cryptographiques. La
décentralisation réelle (DHT, traversée NAT) arrive en Phase 2. Voir
[`ROADMAP.md`](ROADMAP.md).
