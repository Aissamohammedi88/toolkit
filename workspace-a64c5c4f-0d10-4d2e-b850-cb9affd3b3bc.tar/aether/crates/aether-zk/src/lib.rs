//! Aether — preuves à divulgation nulle (STUB, Phase 3).
//!
//! Ce crate **ne prouve rien pour l'instant** : il fige le contrat entre le
//! calcul distribué et la future couche blockchain, afin que les phases 1-2
//! puissent être construites sans bloquer sur le choix du moteur ZK.
//!
//! Candidats évalués pour la Phase 3 (voir `ROADMAP.md`) :
//! - **RISC Zero** — zkVM, preuve d'un programme Rust complet ;
//! - **SP1** — zkVM alternative, bon support du tooling Ethereum ;
//! - **arkworks** — bibliothèque Gnark-like en Rust, circuits Groth16
//!   sur mesure (plus de contrôle, plus de travail).
//!
//! Le principe retenu : l'agrégateur produira une preuve que le résultat
//! envoyé au client découle bien des morceaux signés par les nœuds
//! calculants ; la preuve sera vérifiable on-chain à moindre coût.

/// Un moteur de preuve Aether.
///
/// `statement` est la sérialisation canonique de l'énoncé à prouver
/// (par exemple : la tâche + les résultats des morceaux + les PeerId).
pub trait Prover: Send + Sync {
    /// Produit une preuve que `statement` a été évalué correctement.
    fn prove(&self, statement: &[u8]) -> Result<Vec<u8>, String>;
    /// Vérifie une preuve pour `statement`.
    fn verify(&self, statement: &[u8], proof: &[u8]) -> Result<bool, String>;
}

/// Implémentation vide des phases 1-2 : échoue **honnêtement** plutôt que
/// de prétendre prouver quoi que ce soit.
pub struct NoopProver;

impl Prover for NoopProver {
    fn prove(&self, statement: &[u8]) -> Result<Vec<u8>, String> {
        Err(format!(
            "ZK non implémenté (Phase 3) — énoncé de {} octets ignoré",
            statement.len()
        ))
    }

    fn verify(&self, _statement: &[u8], _proof: &[u8]) -> Result<bool, String> {
        Err("ZK non implémenté (Phase 3)".to_string())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Le stub doit refuser de prouver : mieux vaut un échec explicite
    /// qu'une fausse preuve silencieuse.
    #[test]
    fn le_stub_echoue_honnetement() {
        let p = NoopProver;
        assert!(p.prove(b"statement").is_err());
        assert!(p.verify(b"statement", b"proof").is_err());
    }
}
