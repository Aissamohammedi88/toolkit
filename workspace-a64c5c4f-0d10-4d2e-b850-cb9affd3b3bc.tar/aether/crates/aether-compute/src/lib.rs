//! Aether — planification, exécution et agrégation des morceaux de calcul.

use std::time::Instant;

use aether_core::{math, ChunkResult, ChunkSpec, ComputeTask, TaskKind, TaskResult};

/// Le « routeur cognitif » MVP : découpe une tâche en morceaux prêts à
/// envoyer. La découpe est aujourd'hui naïve (plages équilibrées) ; les
/// phases futures introduiront un découpage conscient des capacités
/// annoncées (GPU / CPU / edge) et de la charge des nœuds.
pub fn plan_chunks(task: &ComputeTask) -> Vec<ChunkSpec> {
    let (from, to) = match &task.kind {
        TaskKind::Primes { from, to } => (*from, *to),
    };
    aether_core::split::split_range(from, to, task.chunks)
        .into_iter()
        .enumerate()
        .map(|(index, (a, b))| ChunkSpec {
            task_id: task.id.clone(),
            index: index as u32,
            from: a,
            to: b,
        })
        .collect()
}

/// Exécute un morceau localement (ici : crible d'Ératosthène).
///
/// `worker` est le `PeerId` du nœud exécutant : il est joint au résultat
/// pour que le client sache qui a calculé quoi.
pub fn execute_chunk(spec: &ChunkSpec, worker: &str) -> Result<ChunkResult, String> {
    let started = Instant::now();
    let primes = math::primes_in_range(spec.from, spec.to).map_err(|e| e.to_string())?;
    Ok(ChunkResult {
        task_id: spec.task_id.clone(),
        index: spec.index,
        primes,
        worker: worker.to_string(),
        elapsed_ms: started.elapsed().as_secs_f64() * 1000.0,
    })
}

/// Fusionne les résultats des morceaux en un résultat final ordonné.
///
/// `wall_ms` est le temps mur mesuré par le routeur entre la soumission de
/// la tâche et la complétion du dernier morceau.
pub fn aggregate(task_id: &str, mut results: Vec<ChunkResult>, wall_ms: f64) -> TaskResult {
    results.sort_by_key(|r| r.index);
    let cpu_ms: f64 = results.iter().map(|r| r.elapsed_ms).sum();
    let mut primes: Vec<u64> = Vec::new();
    let mut workers: Vec<String> = Vec::new();
    for r in results {
        if !workers.contains(&r.worker) {
            workers.push(r.worker);
        }
        primes.extend(r.primes);
    }
    TaskResult {
        task_id: task_id.to_string(),
        primes,
        workers,
        cpu_ms,
        wall_ms,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tache(from: u64, to: u64, chunks: u32) -> ComputeTask {
        ComputeTask {
            id: "t-test".into(),
            kind: TaskKind::Primes { from, to },
            chunks,
        }
    }

    #[test]
    fn plan_couvre_la_tache() {
        let task = tache(1, 10, 3);
        let chunks = plan_chunks(&task);
        assert_eq!(chunks.len(), 3);
        assert_eq!(chunks[0], ChunkSpec { task_id: "t-test".into(), index: 0, from: 1, to: 4 });
        assert_eq!(chunks[2], ChunkSpec { task_id: "t-test".into(), index: 2, from: 8, to: 10 });
    }

    #[test]
    fn execution_d_un_morceau() {
        let spec = ChunkSpec { task_id: "t".into(), index: 0, from: 2, to: 30 };
        let res = execute_chunk(&spec, "peer-w").unwrap();
        assert_eq!(
            res.primes,
            vec![2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
        );
        assert_eq!(res.worker, "peer-w");
        assert!(res.elapsed_ms >= 0.0);
    }

    #[test]
    fn execution_invalide_renvoie_erreur() {
        let spec = ChunkSpec { task_id: "t".into(), index: 0, from: 100, to: 10 };
        assert!(execute_chunk(&spec, "peer-w").is_err());
    }

    #[test]
    fn agregation_reordonne_et_fusionne() {
        // Chaque morceau renvoie ses premiers en ordre croissant (contrat du
        // ChunkResult) ; on fournit ici les MORCEAUX dans le désordre (index 1
        // avant index 0) : l'agrégation doit réordonner par index.
        let r0 = ChunkResult {
            task_id: "t".into(),
            index: 0,
            primes: vec![2, 3, 5, 7, 11],
            worker: "peer-a".into(),
            elapsed_ms: 1.0,
        };
        let r1 = ChunkResult {
            task_id: "t".into(),
            index: 1,
            primes: vec![13, 17, 19, 23, 29],
            worker: "peer-b".into(),
            elapsed_ms: 2.0,
        };
        let agg = aggregate("t", vec![r1, r0], 42.0);
        assert_eq!(agg.primes, vec![2, 3, 5, 7, 11, 13, 17, 19, 23, 29]);
        assert_eq!(agg.workers, vec!["peer-a".to_string(), "peer-b".to_string()]);
        assert_eq!(agg.cpu_ms, 3.0);
        assert_eq!(agg.wall_ms, 42.0);
    }
}
