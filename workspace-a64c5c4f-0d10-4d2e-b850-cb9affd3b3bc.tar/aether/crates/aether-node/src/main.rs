//! aether-node — un nœud du réseau de calcul distribué Aether (MVP Phase 1).
//!
//! Trois rôles dans le même binaire :
//! - **bootstrap** : routeur de rendez-vous — reçoit les soumissions,
//!   découpe les tâches, distribue les morceaux, agrège les résultats ;
//! - **worker** : nœud calculant — s'enregistre, exécute les morceaux ;
//! - **submit** : client — soumet une tâche et attend le résultat agrégé.
//!
//! Toutes les communications passent par des tunnels chiffrés libp2p
//! (Noise + Yamux), voir `aether-net`.

use std::collections::HashMap;
use std::error::Error;
use std::str::FromStr;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use clap::{Parser, Subcommand};
use futures::StreamExt;
use libp2p::swarm::Swarm;
use libp2p::{identity, Multiaddr, PeerId};
use tokio::time::{interval, MissedTickBehavior};

use aether_compute::{aggregate, execute_chunk, plan_chunks};
use aether_core::{
    AetherRequest, AetherResponse, ChunkResult, ComputeTask, NodeCapabilities, TaskKind,
    TaskResult,
};
use aether_net::{build_swarm, AetherChannel, AetherEvent, AetherRequestId, AetherRR};

/// Battement de cœur d'un worker (ré-envoi du Hello).
const HEARTBEAT: Duration = Duration::from_secs(60);
/// Un worker sans battement depuis ce délai est retiré du pool.
const WORKER_TTL: Duration = Duration::from_secs(150);
/// Nombre maximal de redistributions d'un morceau en échec.
const MAX_RETRIES: u8 = 2;

// ---------------------------------------------------------------------------
// Interface en ligne de commande
// ---------------------------------------------------------------------------

#[derive(Parser)]
#[command(
    name = "aether-node",
    version,
    about = "Nœud du réseau de calcul distribué Aether (MVP Phase 1)",
    after_help = "Exemples :\n  aether-node bootstrap --port 4001\n  aether-node worker --bootstrap /ip4/127.0.0.1/tcp/4001\n  aether-node submit --to 200000 --chunks 8"
)]
struct Cli {
    #[command(subcommand)]
    command: Command,
}

#[derive(Subcommand)]
enum Command {
    /// Démarre un nœud routeur (rendez-vous + distribution des tâches).
    Bootstrap {
        /// Port TCP d'écoute.
        #[arg(long, default_value_t = 4001)]
        port: u16,
    },
    /// Démarre un nœud calculant, enregistré auprès du routeur.
    Worker {
        /// Multiadresse du routeur.
        #[arg(long, default_value = "/ip4/127.0.0.1/tcp/4001")]
        bootstrap: String,
        /// Port TCP local (0 = choisi par le système).
        #[arg(long, default_value_t = 0)]
        port: u16,
    },
    /// Soumet une tâche au réseau et attend le résultat agrégé.
    Submit {
        /// Multiadresse du routeur.
        #[arg(long, default_value = "/ip4/127.0.0.1/tcp/4001")]
        bootstrap: String,
        /// Borne inférieure de la recherche de premiers (inclusive).
        #[arg(long, default_value_t = 2)]
        from: u64,
        /// Borne supérieure de la recherche de premiers (inclusive).
        #[arg(long, default_value_t = 100_000)]
        to: u64,
        /// Nombre de morceaux demandé.
        #[arg(long, default_value_t = 8)]
        chunks: u32,
        /// Délai maximal d'attente du résultat, en secondes.
        #[arg(long, default_value_t = 60)]
        timeout: u64,
    },
}

// ---------------------------------------------------------------------------
// Point d'entrée
// ---------------------------------------------------------------------------

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    let cli = Cli::parse();
    let keypair = identity::Keypair::generate_ed25519();
    let peer_id = PeerId::from(keypair.public());
    let mut swarm = build_swarm(&keypair)?;

    match cli.command {
        Command::Bootstrap { port } => run_bootstrap(&mut swarm, peer_id, port).await,
        Command::Worker { bootstrap, port } => {
            let bootstrap = Multiaddr::from_str(&bootstrap)?;
            run_worker(&mut swarm, peer_id, bootstrap, port).await
        }
        Command::Submit { bootstrap, from, to, chunks, timeout } => {
            let bootstrap = Multiaddr::from_str(&bootstrap)?;
            let task = ComputeTask {
                id: format!(
                    "primes-{from}-{to}-{chunks}-{}-{}",
                    std::process::id(),
                    SystemTime::now().duration_since(UNIX_EPOCH)?.as_nanos()
                ),
                kind: TaskKind::Primes { from, to },
                chunks,
            };
            run_client(&mut swarm, bootstrap, task, Duration::from_secs(timeout)).await
        }
    }
}

// ---------------------------------------------------------------------------
// Rôle : bootstrap (routeur de rendez-vous)
// ---------------------------------------------------------------------------

struct WorkerInfo {
    capabilities: NodeCapabilities,
    last_seen: Instant,
}

struct Outstanding {
    task_id: String,
    index: u32,
    retries: u8,
}

struct PendingTask {
    chunks: Vec<ChunkSpecOwned>,
    results: Vec<Option<ChunkResult>>,
    channel: AetherChannel,
    started: Instant,
    failures: u8,
}

/// `ChunkSpec` importé localement pour alléger les signatures.
type ChunkSpecOwned = aether_core::ChunkSpec;

async fn run_bootstrap(
    swarm: &mut Swarm<AetherRR>,
    me: PeerId,
    port: u16,
) -> Result<(), Box<dyn Error>> {
    swarm.listen_on(Multiaddr::from_str(&format!("/ip4/0.0.0.0/tcp/{port}"))?)?;

    let mut workers: HashMap<PeerId, WorkerInfo> = HashMap::new();
    let mut pending: HashMap<String, PendingTask> = HashMap::new();
    let mut outstanding: HashMap<AetherRequestId, Outstanding> = HashMap::new();
    let mut nettoyage = interval(Duration::from_secs(10));

    eprintln!("[bootstrap] nœud routeur {me} en écoute sur 0.0.0.0:{port}");
    eprintln!("[bootstrap] pile réseau : TCP → Noise (chiffrement) → Yamux (multiplexage)");

    loop {
        tokio::select! {
            event = swarm.select_next_some() => match event {
                libp2p::swarm::SwarmEvent::NewListenAddr { address, .. } => {
                    eprintln!("[bootstrap] écoute : {address}");
                }
                libp2p::swarm::SwarmEvent::ConnectionEstablished { peer_id, .. } => {
                    eprintln!("[bootstrap] tunnel chiffré établi avec {peer_id}");
                }
                libp2p::swarm::SwarmEvent::ConnectionClosed { peer_id, num_established, .. } => {
                    if num_established == 0 {
                        eprintln!("[bootstrap] {peer_id} déconnecté");
                        workers.remove(&peer_id);
                    }
                }
                libp2p::swarm::SwarmEvent::Behaviour(AetherEvent::Message { peer, message, .. }) => match message {
                    libp2p::request_response::Message::Request { request, channel, .. } => match request {
                        AetherRequest::Hello { capabilities } => {
                            eprintln!(
                                "[bootstrap] nœud calculant enregistré : {peer} ({}, exécuteurs : {})",
                                capabilities.hardware,
                                capabilities.executor.join(",")
                            );
                            workers.insert(peer, WorkerInfo { capabilities, last_seen: Instant::now() });
                            let _ = swarm.behaviour_mut().send_response(
                                channel,
                                AetherResponse::Welcome { node: me.to_string() },
                            );
                        }
                        AetherRequest::SubmitTask(task) => {
                            handle_submit(swarm, &mut pending, &mut outstanding, &workers, task, channel);
                        }
                        AetherRequest::ComputeChunk(_) => {
                            let _ = swarm.behaviour_mut().send_response(
                                channel,
                                AetherResponse::Error {
                                    message: "les morceaux vont du routeur vers les nœuds calculants".into(),
                                },
                            );
                        }
                    },
                    libp2p::request_response::Message::Response { response, request_id, .. } => {
                        handle_worker_response(swarm, &mut pending, &mut outstanding, &workers, response, request_id);
                    }
                },
                libp2p::swarm::SwarmEvent::Behaviour(AetherEvent::OutboundFailure { request_id, error, .. }) => {
                    eprintln!("[bootstrap] échec d'envoi ({request_id:?}) : {error}");
                    if let Some(out) = outstanding.remove(&request_id) {
                        retry_or_abort(swarm, &mut pending, &mut outstanding, &workers, out);
                    }
                }
                _ => {}
            },
            _ = nettoyage.tick() => {
                workers.retain(|peer, info| {
                    let vivant = info.last_seen.elapsed() < WORKER_TTL;
                    if !vivant {
                        eprintln!("[bootstrap] expiration du nœud calculant {peer} (aucun battement depuis {:.0} s)", WORKER_TTL.as_secs_f64());
                    }
                    vivant
                });
            }
        }
    }
}

fn handle_submit(
    swarm: &mut Swarm<AetherRR>,
    pending: &mut HashMap<String, PendingTask>,
    outstanding: &mut HashMap<AetherRequestId, Outstanding>,
    workers: &HashMap<PeerId, WorkerInfo>,
    task: ComputeTask,
    channel: AetherChannel,
) {
    if pending.contains_key(&task.id) {
        let _ = swarm.behaviour_mut().send_response(
            channel,
            AetherResponse::Error { message: format!("tâche {} déjà en cours", task.id) },
        );
        return;
    }
    if workers.is_empty() {
        let _ = swarm.behaviour_mut().send_response(
            channel,
            AetherResponse::Error { message: "aucun nœud calculant enregistré".into() },
        );
        return;
    }
    let chunks = plan_chunks(&task);
    if chunks.is_empty() {
        let _ = swarm.behaviour_mut().send_response(
            channel,
            AetherResponse::Error { message: "tâche vide ou invalide".into() },
        );
        return;
    }

    let n = chunks.len();
    let cibles: Vec<PeerId> = workers.keys().copied().collect();
    eprintln!(
        "[bootstrap] tâche {} acceptée : {} morceaux sur {} nœud(s) calculant(s)",
        task.id, n, cibles.len()
    );

    let mut results: Vec<Option<ChunkResult>> = (0..n).map(|_| None).collect();
    for chunk in &chunks {
        let cible = cibles[chunk.index as usize % cibles.len()];
        let rid = swarm
            .behaviour_mut()
            .send_request(&cible, AetherRequest::ComputeChunk(chunk.clone()));
        outstanding.insert(rid, Outstanding { task_id: task.id.clone(), index: chunk.index, retries: 0 });
    }
    results.truncate(n);
    pending.insert(
        task.id.clone(),
        PendingTask { chunks, results, channel, started: Instant::now(), failures: 0 },
    );
}

fn handle_worker_response(
    swarm: &mut Swarm<AetherRR>,
    pending: &mut HashMap<String, PendingTask>,
    outstanding: &mut HashMap<AetherRequestId, Outstanding>,
    workers: &HashMap<PeerId, WorkerInfo>,
    response: AetherResponse,
    request_id: AetherRequestId,
) {
    let Some(out) = outstanding.remove(&request_id) else { return };
    let mut echec = false;
    if let Some(p) = pending.get_mut(&out.task_id) {
        match response {
            AetherResponse::ChunkDone(result) => {
                let i = result.index as usize;
                if i < p.results.len() {
                    eprintln!(
                        "[bootstrap] morceau {} de {} reçu de {} ({} premiers, {:.0} ms)",
                        result.index,
                        result.task_id,
                        short(&result.worker),
                        result.primes.len(),
                        result.elapsed_ms
                    );
                    p.results[i] = Some(result);
                }
            }
            AetherResponse::Error { message } => {
                eprintln!("[bootstrap] morceau {} de {} en échec : {}", out.index, out.task_id, message);
                echec = true;
            }
            _ => {}
        }
    }
    if echec {
        retry_or_abort(swarm, pending, outstanding, workers, out);
    } else {
        try_complete(swarm, pending, &out.task_id);
    }
}

fn retry_or_abort(
    swarm: &mut Swarm<AetherRR>,
    pending: &mut HashMap<String, PendingTask>,
    outstanding: &mut HashMap<AetherRequestId, Outstanding>,
    workers: &HashMap<PeerId, WorkerInfo>,
    out: Outstanding,
) {
    let decision: Result<PeerId, String> = {
        let Some(p) = pending.get_mut(&out.task_id) else { return };
        p.failures += 1;
        if p.failures > MAX_RETRIES {
            Err("trop d'échecs de morceaux pour cette tâche".into())
        } else if workers.is_empty() {
            Err("plus aucun nœud calculant disponible".into())
        } else {
            let cibles: Vec<PeerId> = workers.keys().copied().collect();
            Ok(cibles[(out.retries as usize + 1) % cibles.len()])
        }
    };

    match decision {
        Ok(cible) => {
            let Some(p) = pending.get(&out.task_id) else { return };
            let Some(chunk) = p.chunks.get(out.index as usize).cloned() else { return };
            let rid = swarm
                .behaviour_mut()
                .send_request(&cible, AetherRequest::ComputeChunk(chunk));
            outstanding.insert(rid, Outstanding { task_id: out.task_id.clone(), index: out.index, retries: out.retries + 1 });
            eprintln!(
                "[bootstrap] nouvelle tentative : morceau {} de {} vers {} (essai {})",
                out.index, out.task_id, short(&cible.to_string()), out.retries + 2
            );
        }
        Err(message) => abort_task(swarm, pending, outstanding, &out.task_id, &message),
    }
}

fn abort_task(
    swarm: &mut Swarm<AetherRR>,
    pending: &mut HashMap<String, PendingTask>,
    outstanding: &mut HashMap<AetherRequestId, Outstanding>,
    task_id: &str,
    message: &str,
) {
    if let Some(p) = pending.remove(task_id) {
        let _ = swarm.behaviour_mut().send_response(
            p.channel,
            AetherResponse::Error { message: format!("tâche {task_id} abandonnée : {message}") },
        );
    }
    outstanding.retain(|_, o| o.task_id != task_id);
}

fn try_complete(swarm: &mut Swarm<AetherRR>, pending: &mut HashMap<String, PendingTask>, task_id: &str) {
    let pret = pending
        .get(task_id)
        .map(|p| p.results.iter().all(|r| r.is_some()))
        .unwrap_or(false);
    if !pret {
        return;
    }
    let Some(p) = pending.remove(task_id) else { return };
    let results: Vec<ChunkResult> = p.results.into_iter().flatten().collect();
    let wall_ms = p.started.elapsed().as_secs_f64() * 1000.0;
    let agg = aggregate(task_id, results, wall_ms);
    eprintln!(
        "[bootstrap] tâche {} terminée : {} premiers en {:.0} ms (mur) — nœuds : {}",
        task_id,
        agg.primes.len(),
        agg.wall_ms,
        agg.workers.iter().map(|w| short(w)).collect::<Vec<_>>().join(", ")
    );
    let _ = swarm
        .behaviour_mut()
        .send_response(p.channel, AetherResponse::TaskDone(agg));
}

// ---------------------------------------------------------------------------
// Rôle : worker (nœud calculant)
// ---------------------------------------------------------------------------

async fn run_worker(
    swarm: &mut Swarm<AetherRR>,
    me: PeerId,
    bootstrap: Multiaddr,
    port: u16,
) -> Result<(), Box<dyn Error>> {
    if port != 0 {
        swarm.listen_on(Multiaddr::from_str(&format!("/ip4/0.0.0.0/tcp/{port}"))?)?;
    }
    swarm.dial(bootstrap.clone())?;

    let capabilities = NodeCapabilities {
        role: "worker".into(),
        hardware: hardware_tag(),
        executor: vec!["primes".into()],
    };

    let mut hello = interval(HEARTBEAT);
    hello.set_missed_tick_behavior(MissedTickBehavior::Delay);
    let mut routeur: Option<PeerId> = None;

    eprintln!(
        "[worker] nœud calculant {me} — exécuteur local ({})",
        capabilities.hardware
    );
    eprintln!("[worker] routeur visé : {bootstrap}");

    loop {
        tokio::select! {
            event = swarm.select_next_some() => match event {
                libp2p::swarm::SwarmEvent::ConnectionEstablished { peer_id, .. } => {
                    eprintln!("[worker] tunnel chiffré établi avec {peer_id}");
                    routeur = Some(peer_id);
                    let _ = swarm.behaviour_mut().send_request(
                        &peer_id,
                        AetherRequest::Hello { capabilities: capabilities.clone() },
                    );
                }
                libp2p::swarm::SwarmEvent::ConnectionClosed { peer_id, num_established, .. } => {
                    if num_established == 0 && routeur == Some(peer_id) {
                        eprintln!("[worker] routeur perdu — reconnexion au prochain battement");
                        routeur = None;
                    }
                }
                libp2p::swarm::SwarmEvent::OutgoingConnectionError { error, .. } => {
                    eprintln!("[worker] connexion au routeur impossible : {error} — nouvel essai au prochain battement");
                }
                libp2p::swarm::SwarmEvent::Behaviour(AetherEvent::Message { message, .. }) => {
                    if let libp2p::request_response::Message::Request { request, channel, .. } = message {
                        match request {
                            AetherRequest::ComputeChunk(spec) => {
                                eprintln!(
                                    "[worker] morceau {} de {} reçu : premiers dans [{}, {}] — calcul…",
                                    spec.index, spec.task_id, spec.from, spec.to
                                );
                                let reponse = match execute_chunk(&spec, &me.to_string()) {
                                    Ok(r) => {
                                        eprintln!(
                                            "[worker] morceau {} : {} premiers en {:.0} ms",
                                            spec.index, r.primes.len(), r.elapsed_ms
                                        );
                                        AetherResponse::ChunkDone(r)
                                    }
                                    Err(e) => {
                                        eprintln!("[worker] morceau {} : erreur — {e}", spec.index);
                                        AetherResponse::Error { message: e }
                                    }
                                };
                                let _ = swarm.behaviour_mut().send_response(channel, reponse);
                            }
                            autre => {
                                let _ = swarm.behaviour_mut().send_response(
                                    channel,
                                    AetherResponse::Error {
                                        message: format!("requête inattendue pour un worker : {autre:?}"),
                                    },
                                );
                            }
                        }
                    }
                }
                _ => {}
            },
            _ = hello.tick() => {
                match routeur {
                    Some(r) => {
                        let _ = swarm.behaviour_mut().send_request(
                            &r,
                            AetherRequest::Hello { capabilities: capabilities.clone() },
                        );
                    }
                    None => {
                        let _ = swarm.dial(bootstrap.clone());
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Rôle : client (soumission de tâche)
// ---------------------------------------------------------------------------

async fn run_client(
    swarm: &mut Swarm<AetherRR>,
    bootstrap: Multiaddr,
    task: ComputeTask,
    timeout: Duration,
) -> Result<(), Box<dyn Error>> {
    swarm.dial(bootstrap.clone())?;
    eprintln!(
        "[client] soumission de {} : premiers dans [{}, {}], {} morceaux",
        task.id,
        match task.kind { TaskKind::Primes { from, .. } => from },
        match task.kind { TaskKind::Primes { to, .. } => to },
        task.chunks
    );

    let delai = tokio::time::sleep(timeout);
    tokio::pin!(delai);

    loop {
        tokio::select! {
            event = swarm.select_next_some() => match event {
                libp2p::swarm::SwarmEvent::ConnectionEstablished { peer_id, .. } => {
                    eprintln!("[client] tunnel chiffré établi avec {peer_id}");
                    let _ = swarm.behaviour_mut().send_request(&peer_id, AetherRequest::SubmitTask(task.clone()));
                }
                libp2p::swarm::SwarmEvent::OutgoingConnectionError { error, .. } => {
                    return Err(format!("connexion au routeur impossible : {error}").into());
                }
                libp2p::swarm::SwarmEvent::Behaviour(AetherEvent::Message { message, .. }) => {
                    if let libp2p::request_response::Message::Response { response, .. } = message {
                        match response {
                            AetherResponse::TaskDone(result) => {
                                affiche_resultat(&result)?;
                                return Ok(());
                            }
                            AetherResponse::Error { message } => {
                                return Err(format!("le réseau a refusé la tâche : {message}").into());
                            }
                            _ => {}
                        }
                    }
                }
                _ => {}
            },
            _ = &mut delai => {
                return Err("délai dépassé sans résultat du réseau".into());
            }
        }
    }
}

/// Affiche le résultat final en JSON sur la sortie standard (consommable
/// par des scripts : `aether-node submit ... | jq .primes_found`).
fn affiche_resultat(result: &TaskResult) -> Result<(), Box<dyn Error>> {
    let rapport = serde_json::json!({
        "task_id": result.task_id,
        "primes_found": result.primes.len(),
        "premier": result.primes.first(),
        "dernier": result.primes.last(),
        "premiers": if result.primes.len() <= 20 { serde_json::json!(result.primes) } else { serde_json::Value::Null },
        "workers": result.workers.iter().map(|w| short(w)).collect::<Vec<_>>(),
        "cpu_ms": (result.cpu_ms * 10.0).round() / 10.0,
        "mur_ms": (result.wall_ms * 10.0).round() / 10.0,
    });
    println!("{}", serde_json::to_string_pretty(&rapport)?);
    Ok(())
}

// ---------------------------------------------------------------------------
// Utilitaires
// ---------------------------------------------------------------------------

/// Raccourcit un PeerId pour les journaux : `12D3KooM…9fQ`.
fn short(peer: &str) -> String {
    if peer.len() > 12 {
        format!("{}…{}", &peer[..8], &peer[peer.len() - 4..])
    } else {
        peer.to_string()
    }
}

/// Étiquette matérielle annoncée au réseau.
fn hardware_tag() -> String {
    format!("{}-{}-cpu", std::env::consts::OS, std::env::consts::ARCH)
}
