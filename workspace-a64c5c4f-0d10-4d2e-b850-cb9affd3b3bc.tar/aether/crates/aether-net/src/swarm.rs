//! Construction du `Swarm` libp2p d'un nœud Aether.

use std::error::Error;
use std::time::Duration;

use libp2p::request_response::ProtocolSupport;
use libp2p::swarm::{StreamProtocol, Swarm};

use crate::{AetherRR, AETHER_PROTOCOL};

/// Construit le moteur réseau complet d'un nœud Aether.
///
/// Pile assemblée :
/// 1. **TCP** — transport ;
/// 2. **Noise** — négociation de clé et chiffrement authentifié de chaque
///    connexion (clé Ed25519 du nœud, `PeerId` dérivé de sa partie publique) ;
/// 3. **Yamux** — multiplexage des sous-flux sur une seule connexion chiffrée ;
/// 4. **requête/réponse Aether** — protocole applicatif JSON.
///
/// Les connexions inactives sont maintenues 10 minutes pour éviter des
/// renégociations chiffrées répétées.
pub fn build_swarm(
    keypair: &libp2p::identity::Keypair,
) -> Result<Swarm<AetherRR>, Box<dyn Error>> {
    let comportement = AetherRR::new(
        [(
            StreamProtocol::new(AETHER_PROTOCOL),
            ProtocolSupport::Full,
        )],
        libp2p::request_response::Config::default(),
    );

    let swarm = libp2p::SwarmBuilder::with_existing_identity(keypair.clone())
        .with_tokio()
        .with_tcp(
            libp2p::tcp::Config::default(),
            libp2p::noise::Config::new,
            libp2p::yamux::Config::default,
        )?
        .with_behaviour(|_| comportement)?
        .with_swarm_config(|c| c.with_idle_connection_timeout(Duration::from_secs(600)))
        .build();

    Ok(swarm)
}
