//! Aether — couche réseau : tunnels chiffrés libp2p.
//!
//! Chaque connexion d'un nœud Aether traverse la pile :
//!
//! ```text
//! TCP → Noise (chiffrement authentifié, clés Ed25519) → Yamux (multiplexage)
//!     → protocole applicatif requête/réponse Aether (JSON)
//! ```
//!
//! Aucune donnée ne circule en clair : la négociation Noise a lieu avant
//! tout échange applicatif, et chaque nœud est identifié par son `PeerId`
//! dérivé de sa clé publique.

pub mod swarm;

pub use swarm::build_swarm;

use aether_core::{AetherRequest, AetherResponse};

/// Nom du protocole applicatif Aether, négocié sur chaque sous-flux.
pub const AETHER_PROTOCOL: &str = "/aether/task/1.0.0";

/// Comportement réseau d'un nœud Aether : requête/réponse JSON sur tunnel
/// chiffré (le codec JSON gère lui-même le préfixe de longueur).
pub type AetherRR = libp2p::request_response::json::Behaviour<AetherRequest, AetherResponse>;

/// Événement émis par le comportement réseau Aether.
pub type AetherEvent = libp2p::request_response::Event<AetherRequest, AetherResponse>;

/// Message requête/réponse du protocole Aether.
pub type AetherMessage = libp2p::request_response::Message<AetherRequest, AetherResponse>;

/// Canal de réponse vers un pair (consommé au moment de répondre).
pub type AetherChannel = libp2p::request_response::ResponseChannel<AetherResponse>;

/// Identifiant d'une requête sortante (vers un autre nœud).
pub type AetherRequestId = libp2p::request_response::OutboundRequestId;
