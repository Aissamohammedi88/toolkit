//! Découpage équilibré d'une plage en morceaux — le « routeur cognitif » MVP.

/// Découpe `[from, to]` (bornes incluses) en **au plus** `chunks` plages
/// contiguës et quasi égales. Les morceaux vides ne sont pas émis (si la
/// plage est plus petite que le nombre de morceaux demandé, on renvoie
/// simplement moins de morceaux).
///
/// Propriétés garanties (testées) :
/// - pas de trou, pas de chevauchement ;
/// - l'union des morceaux est exactement `[from, to]` ;
/// - chaque morceau est non vide.
pub fn split_range(from: u64, to: u64, chunks: u32) -> Vec<(u64, u64)> {
    if chunks == 0 || from > to {
        return Vec::new();
    }
    let total = to - from + 1;
    let n = (chunks as u64).min(total);
    let base = total / n;
    let reste = total % n;
    let mut out = Vec::with_capacity(n as usize);
    let mut cur = from;
    for i in 0..n {
        let len = base + u64::from(i < reste);
        out.push((cur, cur + len - 1));
        cur += len;
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn exemple_simple() {
        assert_eq!(split_range(1, 10, 3), vec![(1, 4), (5, 7), (8, 10)]);
    }

    #[test]
    fn un_seul_morceau() {
        assert_eq!(split_range(2, 100, 1), vec![(2, 100)]);
    }

    #[test]
    fn plus_de_chunks_que_dentiers() {
        // 3 entiers, 5 morceaux demandés -> seulement 3 morceaux non vides.
        assert_eq!(split_range(7, 9, 5), vec![(7, 7), (8, 8), (9, 9)]);
    }

    #[test]
    fn zero_chunks_ou_plage_vide() {
        assert!(split_range(1, 10, 0).is_empty());
        assert!(split_range(10, 1, 4).is_empty());
    }

    #[test]
    fn couverture_exacte_sans_trou_ni_chevauchement() {
        for &(from, to, n) in &[(2u64, 1000u64, 7u32), (1, 999_999, 13), (5, 5, 3), (0, 100, 4)] {
            let parts = split_range(from, to, n);
            assert!(!parts.is_empty(), "aucun morceau pour {from}..={to}");
            let mut attendu = from;
            for &(a, b) in &parts {
                assert_eq!(a, attendu, "trou ou désalignement à {a}");
                assert!(a <= b, "morceau vide interdit : ({a}, {b})");
                attendu = b + 1;
            }
            assert_eq!(attendu, to + 1, "la plage n'est pas couverte jusqu'à {to}");
        }
    }
}
