//! Aether — types partagés entre tous les crates du réseau.
//!
//! Ce crate est volontairement sans dépendance réseau : il définit le
//! « contrat » (tâches, morceaux, résultats, messages du protocole) utilisé
//! par `aether-net`, `aether-compute` et `aether-node`.
//!
//! Sérialiser ces types en JSON les rend extensibles sans casser le réseau :
//! les champs inconnus sont ignorés à la désérialisation.

pub mod math;
pub mod split;
pub mod types;

pub use types::{
    AetherRequest, AetherResponse, ChunkResult, ChunkSpec, ComputeTask, NodeCapabilities,
    TaskKind, TaskResult,
};
