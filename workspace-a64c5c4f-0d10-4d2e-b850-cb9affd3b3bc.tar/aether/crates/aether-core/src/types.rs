//! Contrat de données du réseau Aether.

use serde::{Deserialize, Serialize};

/// Genre de tâche que le réseau sait calculer.
///
/// MVP (Phase 1) : recherche de nombres premiers par crible.
/// Les phases futures ajouteront des variantes (GPU, edge, IA).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum TaskKind {
    /// Trouver tous les nombres premiers dans `[from, to]` (bornes incluses).
    Primes { from: u64, to: u64 },
}

/// Une tâche soumise par un client, découpée en `chunks` morceaux.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ComputeTask {
    /// Identifiant unique de la tâche (généré par le client).
    pub id: String,
    /// Ce qu'il faut calculer.
    pub kind: TaskKind,
    /// Nombre de morceaux demandé (découpe équilibrée).
    pub chunks: u32,
}

/// Un morceau de travail, envoyé par le routeur à un nœud calculant.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ChunkSpec {
    /// Tâche d'origine.
    pub task_id: String,
    /// Position du morceau dans la tâche (0..n), sert à la fusion finale.
    pub index: u32,
    /// Borne inférieure (inclusive).
    pub from: u64,
    /// Borne supérieure (inclusive).
    pub to: u64,
}

/// Le résultat d'un morceau, renvoyé par le nœud qui l'a calculé.
/// (`Eq` est omis volontairement : `elapsed_ms` est un `f64`.)
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ChunkResult {
    /// Tâche d'origine.
    pub task_id: String,
    /// Position du morceau dans la tâche.
    pub index: u32,
    /// Les nombres premiers trouvés dans le morceau, en ordre croissant.
    pub primes: Vec<u64>,
    /// `PeerId` (sérialisé) du nœud qui a calculé ce morceau.
    pub worker: String,
    /// Temps d'exécution local du morceau, en millisecondes.
    pub elapsed_ms: f64,
}

/// Résultat final agrégé, renvoyé au client par le routeur.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TaskResult {
    /// Identifiant de la tâche.
    pub task_id: String,
    /// Tous les premiers trouvés, en ordre croissant (fusion des morceaux).
    pub primes: Vec<u64>,
    /// Les nœuds qui ont participé (uniques, dans l'ordre de participation).
    pub workers: Vec<String>,
    /// Somme des temps d'exécution des morceaux (ms) — temps CPU cumulé.
    pub cpu_ms: f64,
    /// Temps mur total vu par le routeur, de la soumission au résultat (ms).
    pub wall_ms: f64,
}

/// Capacités annoncées par un nœud lors de son « Hello ».
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NodeCapabilities {
    /// Rôle annoncé (ex. `worker`).
    pub role: String,
    /// Étiquette matérielle (ex. `linux-x86_64-cpu`).
    pub hardware: String,
    /// Exécuteurs disponibles (ex. `["primes"]`).
    pub executor: Vec<String>,
}

/// Requêtes du protocole Aether (ce qu'un nœud peut demander à un autre).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum AetherRequest {
    /// Enregistrement / battement de cœur d'un nœud calculant.
    Hello { capabilities: NodeCapabilities },
    /// Soumission d'une tâche par un client au routeur.
    SubmitTask(ComputeTask),
    /// Morceau de travail à exécuter (routeur → nœud calculant).
    ComputeChunk(ChunkSpec),
}

/// Réponses du protocole Aether.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum AetherResponse {
    /// Accusé de réception d'un `Hello`.
    Welcome { node: String },
    /// Un morceau a été calculé (nœud calculant → routeur).
    ChunkDone(ChunkResult),
    /// Résultat final agrégé (routeur → client).
    TaskDone(TaskResult),
    /// Erreur applicative (borne invalide, aucun nœud disponible, abandon…).
    Error { message: String },
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Le contrat doit rester sérialisable en JSON dans les deux sens :
    /// c'est ce qui transite réellement sur le tunnel chiffré.
    #[test]
    fn protocole_fait_un_tour_en_json() {
        let req = AetherRequest::SubmitTask(ComputeTask {
            id: "t1".into(),
            kind: TaskKind::Primes { from: 2, to: 100 },
            chunks: 4,
        });
        let json = serde_json::to_string(&req).unwrap();
        let back: AetherRequest = serde_json::from_str(&json).unwrap();
        assert_eq!(req, back);

        let resp = AetherResponse::TaskDone(TaskResult {
            task_id: "t1".into(),
            primes: vec![2, 3, 5],
            workers: vec!["peer-a".into()],
            cpu_ms: 12.5,
            wall_ms: 40.0,
        });
        let json = serde_json::to_string(&resp).unwrap();
        let back: AetherResponse = serde_json::from_str(&json).unwrap();
        assert_eq!(resp, back);
    }

    /// Les champs inconnus sont ignorés : le protocole peut évoluer sans
    /// casser les nœuds déjà déployés.
    #[test]
    fn champs_inconnus_ignores() {
        let json = r#"{"Hello":{"capabilities":{"role":"worker","hardware":"linux-x86_64-cpu","executor":["primes"],"futur":true}}}"#;
        let req: AetherRequest = serde_json::from_str(json).unwrap();
        match req {
            AetherRequest::Hello { capabilities } => {
                assert_eq!(capabilities.executor, vec!["primes".to_string()]);
            }
            _ => panic!("variant inattendu"),
        }
    }
}
