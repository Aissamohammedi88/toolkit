//! Exécuteur MVP du réseau Aether : crible d'Ératosthène.

/// Borne haute maximale acceptée par l'exécuteur MVP (limite mémoire :
/// le crible alloue ~1 octet par entier).
pub const MAX_BOUND: u64 = 20_000_000;

/// Erreur d'exécution d'un morceau.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ExecError {
    /// La borne dépasse [`MAX_BOUND`].
    BoundTooLarge { bound: u64, max: u64 },
    /// Plage invalide (`from > to`).
    InvalidRange { from: u64, to: u64 },
}

impl std::fmt::Display for ExecError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ExecError::BoundTooLarge { bound, max } => {
                write!(f, "borne {bound} trop élevée (max {max})")
            }
            ExecError::InvalidRange { from, to } => {
                write!(f, "plage invalide : {from} > {to}")
            }
        }
    }
}

impl std::error::Error for ExecError {}

/// Tous les nombres premiers dans `[from, to]`, bornes incluses.
///
/// Crible d'Ératosthène complet jusqu'à `to`, puis filtre des bornes.
/// Déterministe : deux nœuds différents obtiennent le même résultat pour
/// le même morceau — c'est ce qui permettra la vérification par
/// redondance dans les phases suivantes.
pub fn primes_in_range(from: u64, to: u64) -> Result<Vec<u64>, ExecError> {
    if to > MAX_BOUND {
        return Err(ExecError::BoundTooLarge {
            bound: to,
            max: MAX_BOUND,
        });
    }
    if from > to {
        return Err(ExecError::InvalidRange { from, to });
    }
    if to < 2 {
        return Ok(Vec::new());
    }
    let start = from.max(2);
    let mut is_prime = vec![true; (to + 1) as usize];
    is_prime[0] = false;
    is_prime[1] = false;
    let mut i = 2u64;
    while i * i <= to {
        if is_prime[i as usize] {
            let mut m = i * i;
            while m <= to {
                is_prime[m as usize] = false;
                m += i;
            }
        }
        i += 1;
    }
    Ok((start..=to).filter(|&n| is_prime[n as usize]).collect())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn premiers_de_2_a_30() {
        let attendu: Vec<u64> = vec![2, 3, 5, 7, 11, 13, 17, 19, 23, 29];
        assert_eq!(primes_in_range(2, 30).unwrap(), attendu);
    }

    #[test]
    fn bornes_partielles() {
        // [24, 29] ne contient que 29.
        assert_eq!(primes_in_range(24, 29).unwrap(), vec![29]);
        // [90, 96] est vide.
        assert!(primes_in_range(90, 96).unwrap().is_empty());
        // [0, 1] est vide.
        assert!(primes_in_range(0, 1).unwrap().is_empty());
        // from = 0 est ramené à 2.
        assert_eq!(primes_in_range(0, 10).unwrap(), vec![2, 3, 5, 7]);
    }

    #[test]
    fn plage_invalide_rejetee() {
        assert_eq!(
            primes_in_range(50, 10),
            Err(ExecError::InvalidRange { from: 50, to: 10 })
        );
    }

    #[test]
    fn borne_trop_grande_rejetee() {
        assert_eq!(
            primes_in_range(2, MAX_BOUND + 1),
            Err(ExecError::BoundTooLarge {
                bound: MAX_BOUND + 1,
                max: MAX_BOUND
            })
        );
    }

    #[test]
    fn deterministe_sur_repartition() {
        // Découper puis fusionner donne le même résultat que d'un coup :
        // propriété indispensable à l'agrégation par le routeur.
        let direct = primes_in_range(2, 1000).unwrap();
        let mut fusion: Vec<u64> = Vec::new();
        for (a, b) in crate::split::split_range(2, 1000, 7) {
            fusion.extend(primes_in_range(a, b).unwrap());
        }
        assert_eq!(direct, fusion);
    }
}
