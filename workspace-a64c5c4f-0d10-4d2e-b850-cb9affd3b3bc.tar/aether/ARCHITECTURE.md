# Architecture Aether

## La chaîne visée (et où on en est)

La vision d'Aether :

```text
UI ──▶ routeur cognitif ──▶ P2P mesh chiffré ──▶ nœuds hétérogènes
                                       │              (PC gamer GPU,
                                       │               serveur CPU,
                                       │               Mac M3 edge)
                                       ▼
UI ◀── réponse ◀── blockchain ◀── preuve ZK ◀── agrégateur
```

État des maillons :

| Maillon                    | État Phase 1                          |
| -------------------------- | ------------------------------------- |
| UI / client                | ✅ CLI `submit` (JSON en sortie)      |
| Routeur cognitif           | ✅ MVP : découpage équilibré          |
| P2P mesh chiffré           | ✅ libp2p : TCP + Noise + Yamux       |
| Nœuds hétérogènes          | ✅ CPU (exécuteur `primes`)           |
| Agrégateur                 | ✅ fusion ordonnée + métriques        |
| Preuve ZK                  | ⏳ contrat figé (`aether-zk`)         |
| Blockchain                 | ⏳ Phase 4                            |

## Pile réseau (implémentée)

Chaque connexion entre nœuds Aether :

```text
┌───────────────────────────────────────────────────┐
│ protocole applicatif Aether (requête/réponse JSON)│
├───────────────────────────────────────────────────┤
│ Yamux — multiplexage des sous-flux                │
├───────────────────────────────────────────────────┤
│ Noise — chiffrement authentifié (clés Ed25519)    │
├───────────────────────────────────────────────────┤
│ TCP                                               │
└───────────────────────────────────────────────────┘
```

- **Identité** : chaque nœud génère une paire Ed25519 ; son `PeerId` est
  dérivé de la clé publique. Pas d'identité = pas de connexion.
- **Chiffrement** : négociation Noise *avant tout* échange applicatif —
  rien ne circule en clair, y compris les métadonnées de tâches.
- **Multiplexage** : Yamux permet plusieurs requêtes concurrentes sur une
  seule connexion chiffrée (une seule négociation coûteuse).
- **Codage** : JSON préfixé par sa longueur (max 1 Mo requête / 10 Mo
  réponse, bornes du codec libp2p).

## Protocole applicatif

Défini dans `aether-core/src/types.rs` :

```rust
enum AetherRequest  { Hello { capabilities }, SubmitTask(ComputeTask), ComputeChunk(ChunkSpec) }
enum AetherResponse { Welcome { node }, ChunkDone(ChunkResult), TaskDone(TaskResult), Error { message } }
```

Flux nominal d'une tâche :

```text
worker                     bootstrap                       client
  │── Hello(capabilités)──────▶│                              │
  │◀── Welcome─────────────────│                              │
  │                            │◀── SubmitTask(tâche)─────────│
  │◀── ComputeChunk(morceau i)─│   (round-robin sur workers)  │
  │── ChunkDone(résultat i)───▶│                              │
  │       … tous les morceaux …│                              │
  │                            │── TaskDone(résultat agrégé)─▶│
```

Les messages sont sérialisés en JSON avec **ignorance des champs
inconnus** : le protocole peut évoluer sans casser les nœuds déployés.

## Routeur cognitif (MVP)

`aether-compute` :

- **plan_chunks** — découpe la plage en morceaux contigus équilibrés
  (garantie : ni trou ni chevauchement, testée par propriété) ;
- **execute_chunk** — exécution locale déterministe (crible) ;
- **aggregate** — fusion ordonnée par index, temps CPU cumulé, liste des
  participants.

La distribution est aujourd'hui un **round-robin naïf** sur les workers
enregistrés. La Phase 2 introduira un choix conscient des capacités
annoncées (`NodeCapabilities.hardware`, `.executor`).

## Tolérance aux pannes

- **Battement de cœur** : chaque worker renvoie `Hello` toutes les 60 s ;
  un worker silencieux pendant 150 s est retiré du pool.
- **Reconnexion** : un worker qui perd le routeur re-dial au battement
  suivant.
- **Reprise sur échec** : un morceau en échec (erreur applicative ou échec
  d'envoi) est redistribué à un autre worker, jusqu'à 2 redistributions ;
  au-delà la tâche est abandonnée et le client reçoit une `Error`
  explicite.
- **File d'attente** : une requête vers un pair pas encore connecté est
  mise en attente et envoyée dès l'établissement du tunnel (libp2p).

## Modèle de menace — ce qui est protégé, ce qui ne l'est pas

Protégé aujourd'hui :

- ✅ **Confidentialité et intégrité du transport** — Noise authentifie les
  deux extrémités et chiffre tout le trafic ;
- ✅ **Authenticité des pairs** — PeerId dérivé de la clé publique ;
- ✅ **Disponibilité partielle** — battements, TTL, redistributions.

PAS encore protégé (assumé, planifié) :

- ❌ **Exactitude des résultats malveillants** — un worker compromis peut
  mentir sur son morceau. Phase 2 : double calcul sur nœuds distincts et
  vote ; Phase 3 : preuve ZK d'exécution ;
- ❌ **Sybil / éclipsage** — pas encore de DHT ni de réputation ;
- ❌ **Confidentialité de la tâche elle-même** — le routeur voit tout en
  clair (chiffrement de bout en bout application : Phase 5).

## Choix techniques (et pourquoi)

- **Rust** : sûreté mémoire + performance proche du C++ (des milliers de
  connexions sans GC ni fuite), `tokio` pour la concurrence.
- **libp2p** : pile P2P modulaire éprouvée (IPFS) — Noise, Yamux, et plus
  tard Kademlia/gossipsub/quic sans réécrire le réseau.
- **JSON** : débogable à la main sur le tunnel ; passage bincode/protobuf
  possible sans changer le contrat (serde).
- **libp2p = 0.53.2 épinglé exactement** : la crate évolue vite, la
  recompilation d'un autre poste doit être bit-identique.
