'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Upload, Sparkles, Trash2, Film, ImageIcon } from 'lucide-react';
import type { MediaRow } from './types';

export default function MediaGallery() {
  const [media, setMedia] = useState<MediaRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [genOpen, setGenOpen] = useState(false);
  const [genPrompt, setGenPrompt] = useState('');
  const [generating, setGenerating] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/media');
      const data = (await res.json()) as { media?: MediaRow[] };
      setMedia(data.media || []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function upload(files: FileList | null) {
    if (!files || files.length === 0) return;
    setUploading(true);
    try {
      for (const file of Array.from(files)) {
        const fd = new FormData();
        fd.append('file', file);
        const res = await fetch('/api/media', { method: 'POST', body: fd });
        const data = (await res.json()) as { error?: string };
        if (!res.ok) {
          toast({ title: 'Upload refusé', description: data.error, variant: 'destructive' });
        }
      }
      toast({ title: 'Média ajouté', description: 'Votre bibliothèque est à jour.' });
      await load();
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  }

  async function generateVisual() {
    if (!genPrompt.trim()) return;
    setGenerating(true);
    try {
      const res = await fetch('/api/media', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ visualPrompt: genPrompt }),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) {
        toast({ title: 'Génération impossible', description: data.error, variant: 'destructive' });
        return;
      }
      toast({ title: 'Visuel plasma créé', description: 'Ajouté à la bibliothèque (moteur local).' });
      setGenOpen(false);
      setGenPrompt('');
      await load();
    } finally {
      setGenerating(false);
    }
  }

  async function remove(id: string) {
    await fetch('/api/media', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    });
    setMedia((m) => m.filter((x) => x.id !== id));
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <input ref={fileRef} type="file" accept="video/*,image/*" multiple hidden onChange={(e) => upload(e.target.files)} />
        <Button onClick={() => fileRef.current?.click()} disabled={uploading} className="bg-violet-600 text-white hover:bg-violet-500">
          {uploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
          Importer vidéo / image
        </Button>
        <Dialog open={genOpen} onOpenChange={setGenOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" className="border-zinc-700 hover:bg-zinc-800">
              <Sparkles className="mr-2 h-4 w-4" /> Générer un visuel
            </Button>
          </DialogTrigger>
          <DialogContent className="border-zinc-800 bg-zinc-950">
            <DialogHeader>
              <DialogTitle>Créer un visuel plasma</DialogTitle>
            </DialogHeader>
            <div className="space-y-2">
              <Label htmlFor="vp">Décrivez le visuel</Label>
              <Input
                id="vp"
                value={genPrompt}
                onChange={(e) => setGenPrompt(e.target.value)}
                placeholder="ex. vagues violettes et néons fuchsia pour ma landing"
                onKeyDown={(e) => e.key === 'Enter' && generateVisual()}
              />
              <p className="text-xs text-zinc-500">Fonctionne même sans API : art plasma vectoriel généré localement.</p>
            </div>
            <DialogFooter>
              <Button onClick={generateVisual} disabled={generating || !genPrompt.trim()} className="bg-violet-600 text-white hover:bg-violet-500">
                {generating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null} Générer
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        <p className="ml-auto text-xs text-zinc-500">Vidéos jusqu&apos;à 60 Mo · images 4 Mo</p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-16 text-zinc-500">
          <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Chargement de la bibliothèque…
        </div>
      ) : media.length === 0 ? (
        <div className="rounded-xl border border-dashed border-zinc-800 py-16 text-center text-sm text-zinc-500">
          Bibliothèque vide — importez une vidéo ou générez un visuel plasma.
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {media.map((m) => (
            <div key={m.id} className="group overflow-hidden rounded-xl border border-zinc-800 bg-zinc-900/40">
              <div className="relative aspect-video bg-black">
                {m.kind === 'video' ? (
                  <video src={`/api/media/${m.id}/raw`} controls preload="metadata" className="h-full w-full object-contain" aria-label={m.name} />
                ) : (
                  <img src={`/api/media/${m.id}/raw`} alt={m.prompt || m.name} className="h-full w-full object-cover" loading="lazy" />
                )}
              </div>
              <div className="flex items-start justify-between gap-2 p-3">
                <div className="min-w-0">
                  <p className="flex items-center gap-1.5 truncate text-sm font-medium">
                    {m.kind === 'video' ? <Film className="h-3.5 w-3.5 text-fuchsia-400" /> : <ImageIcon className="h-3.5 w-3.5 text-violet-400" />}
                    {m.name}
                  </p>
                  <p className="mt-0.5 truncate text-xs text-zinc-500">{m.prompt || '—'}</p>
                  <Badge variant="outline" className="mt-1.5 border-zinc-700 text-[10px] text-zinc-400">
                    {m.provider === 'upload' ? 'importé' : m.provider}
                  </Badge>
                </div>
                <Button size="icon" variant="ghost" onClick={() => remove(m.id)} aria-label={`Supprimer ${m.name}`} className="h-8 w-8 shrink-0 text-zinc-500 hover:text-red-400">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
