'use client';

import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Code2, Sparkles, MonitorPlay, Package, Users, Link2, Zap, ShieldCheck, ArrowRight,
} from 'lucide-react';

interface Props {
  onSignup: () => void;
  onLogin: () => void;
}

const FEATURES = [
  {
    icon: Link2,
    title: 'Éditeur unifié GenHub + GenEdit',
    desc: 'Vos projets GenHub et votre dossier nexus-genedit (genedit.py, genhub.sh) dans le même éditeur. Un clic lance le vrai genedit.py, la sortie apparaît dans le terminal intégré.',
  },
  {
    icon: Zap,
    title: 'Génération même sans API',
    desc: 'Chaîne automatique : APIs gratuites sans clé (Pollinations) puis moteur local NEXUS. Zéro configuration, zéro clé, ça génère toujours.',
  },
  {
    icon: Code2,
    title: 'Code de production',
    desc: 'Apps Node.js zéro dépendance, API REST avec persistance, composants React typés. Le code généré compile et s\'exécute dans l\'éditeur.',
  },
  {
    icon: MonitorPlay,
    title: 'Vidéos & visuels',
    desc: 'Importez vos vidéos, générez des visuels plasma, intégrez-les à vos README et landing pages. Bibliothèque média intégrée.',
  },
  {
    icon: Package,
    title: 'Compile & extrait en ZIP',
    desc: 'Un clic : le projet complet est compilé dans un bac à sable, exécuté, puis extrait en archive ZIP prête à livrer à vos clients.',
  },
  {
    icon: Users,
    title: 'Vos clients s\'inscrivent',
    desc: 'Pages d\'inscription intégrées, comptes gratuits, plan Gratuit prêt pour votre futur service public. Présentez, inscrivez, livrez.',
  },
];

const STEPS = [
  { n: '01', title: 'Décrivez', desc: '« un serveur API pour mes clients », « un README pour mon studio », « un visuel plasma violet ».' },
  { n: '02', title: 'Générez & exécutez', desc: 'Le code arrive complet. Vous l\'exécutez dans le terminal intégré et voyez la sortie réelle.' },
  { n: '03', title: 'Livrez', desc: 'Export ZIP compilé + README pro. Vos clients s\'inscrivent sur la page intégrée.' },
];

export default function Landing({ onSignup, onLogin }: Props) {
  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-50 flex flex-col">
      {/* NAV */}
      <header className="sticky top-0 z-40 border-b border-zinc-800/60 bg-[#09090b]/80 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 text-sm font-black text-white shadow-lg shadow-violet-500/30">N</div>
            <span className="text-sm font-semibold tracking-tight">NEXUS GEN HUB</span>
            <Badge variant="outline" className="hidden border-violet-500/40 bg-violet-500/10 text-violet-300 sm:inline-flex">Plasma</Badge>
          </div>
          <nav className="hidden items-center gap-6 text-sm text-zinc-400 md:flex" aria-label="Navigation principale">
            <a href="#features" className="transition-colors hover:text-zinc-50">Fonctions</a>
            <a href="#pipeline" className="transition-colors hover:text-zinc-50">Pipeline</a>
            <a href="#pricing" className="transition-colors hover:text-zinc-50">Tarifs</a>
          </nav>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={onLogin}>Connexion</Button>
            <Button size="sm" onClick={onSignup} className="bg-violet-600 text-white hover:bg-violet-500">
              Créer un compte
            </Button>
          </div>
        </div>
      </header>

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="plasma-grid absolute inset-0" aria-hidden />
        <div className="plasma-glow absolute inset-0" aria-hidden />
        <div className="relative mx-auto max-w-6xl px-4 pb-20 pt-24 text-center sm:px-6 sm:pt-32">
          <Badge variant="outline" className="mb-6 border-violet-500/30 bg-violet-500/10 px-3 py-1 text-violet-300">
            <Sparkles className="mr-1.5 h-3.5 w-3.5" /> Génère même sans aucune API
          </Badge>
          <h1 className="mx-auto max-w-3xl text-4xl font-bold leading-tight tracking-tighter sm:text-6xl">
            Créez. Générez.{' '}
            <span className="plasma-gradient-text">Livrez.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-zinc-400 sm:text-lg">
            Le studio tout-en-un pour votre activité : <strong className="text-zinc-200">code Node.js &amp; React</strong>,
            {' '}<strong className="text-zinc-200">README</strong>, <strong className="text-zinc-200">visuels</strong> et{' '}
            <strong className="text-zinc-200">vidéos</strong> — dans un éditeur unifié qui réunit GenHub et GenEdit.
            Compilez, exécutez, extrayez en ZIP. Présentez à vos clients, ils s&apos;inscrivent gratuitement.
          </p>
          <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button size="lg" onClick={onSignup} className="h-12 bg-violet-600 px-8 text-base text-white shadow-xl shadow-violet-600/25 hover:bg-violet-500">
              Démarrer gratuitement <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" onClick={onLogin} className="h-12 border-zinc-700 bg-zinc-900/60 px-8 text-base hover:bg-zinc-800">
              J&apos;ai déjà un compte
            </Button>
          </div>

          {/* MOCKUP ÉDITEUR */}
          <div className="relative mx-auto mt-16 max-w-4xl">
            <div className="absolute -inset-x-8 -top-8 h-40 bg-gradient-to-b from-violet-500/20 to-transparent blur-2xl" aria-hidden />
            <div className="relative overflow-hidden rounded-xl border border-zinc-800 bg-zinc-950 text-left shadow-2xl">
              <div className="flex h-9 items-center gap-1.5 border-b border-zinc-800 bg-zinc-900/80 px-4">
                <span className="h-3 w-3 rounded-full bg-red-500/80" />
                <span className="h-3 w-3 rounded-full bg-yellow-500/80" />
                <span className="h-3 w-3 rounded-full bg-green-500/80" />
                <span className="ml-3 text-xs text-zinc-500">nexus-genhub — éditeur unifié</span>
              </div>
              <div className="grid gap-0 p-4 font-mono text-[11px] leading-5 sm:grid-cols-[1fr_1.4fr] sm:text-xs">
                <div className="space-y-3 sm:border-r sm:border-zinc-800 sm:pr-4">
                  <p className="text-zinc-500">EXPLORATEUR</p>
                  <p className="text-violet-300">▸ mon-studio/</p>
                  <p className="pl-4 text-zinc-300">package.json</p>
                  <p className="pl-4 text-zinc-300">src/index.js</p>
                  <p className="pl-4 text-zinc-300">README.md</p>
                  <p className="text-fuchsia-300">▸ GenEdit lié</p>
                  <p className="pl-4 text-zinc-400">genedit.py</p>
                  <p className="pl-4 text-zinc-400">genhub.sh</p>
                  <div className="mt-4 rounded-lg border border-violet-500/30 bg-violet-500/10 p-2.5">
                    <p className="text-[10px] text-violet-300">$ python3 genedit.py serve</p>
                    <p className="text-[10px] text-emerald-400">✔ groupe GenHub démarré</p>
                  </div>
                </div>
                <div className="sm:pl-4">
                  <p className="text-zinc-500">src/index.js — node 22</p>
                  <pre className="mt-2 whitespace-pre-wrap text-zinc-300">
                    <span className="tok-key">const</span> {'{ createServer }'} = <span className="tok-fn">require</span>(<span className="tok-str">&apos;./server&apos;</span>);{'\n'}
                    <span className="tok-key">const</span> server = <span className="tok-fn">createServer</span>({'{'} port: <span className="tok-num">3000</span> {'}'});{'\n'}
                    server.<span className="tok-fn">start</span>(); <span className="tok-com">{'// ✅ en ligne — 0 dépendance'}</span>
                  </pre>
                  <div className="mt-4 rounded-lg border border-zinc-800 bg-black/60 p-2.5">
                    <p className="text-[10px] text-zinc-500">$ npm run dev</p>
                    <p className="text-[10px] text-emerald-400">✅ mon-studio → http://localhost:3000</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="border-t border-zinc-800/60 py-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <h2 className="text-center text-2xl font-bold tracking-tight sm:text-3xl">
            Tout ce qu&apos;il faut pour <span className="plasma-gradient-text">impressionner vos clients</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-center text-sm text-zinc-400">
            Conçu pour être montré : interface façon Vercel, résultats réels, zéro promesse en l&apos;air.
          </p>
          <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <div key={f.title} className="group rounded-xl border border-zinc-800 bg-zinc-900/40 p-6 transition-all hover:border-violet-500/40 hover:bg-zinc-900/70">
                <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-lg border border-violet-500/30 bg-violet-500/10 text-violet-300 transition-colors group-hover:bg-violet-500/20">
                  <f.icon className="h-5 w-5" aria-hidden />
                </div>
                <h3 className="mb-2 font-semibold tracking-tight">{f.title}</h3>
                <p className="text-sm leading-relaxed text-zinc-400">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PIPELINE */}
      <section id="pipeline" className="border-t border-zinc-800/60 py-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <h2 className="text-center text-2xl font-bold tracking-tight sm:text-3xl">Le pipeline, de l&apos;idée au livrable</h2>
          <div className="mt-14 grid gap-4 md:grid-cols-3">
            {STEPS.map((s) => (
              <div key={s.n} className="relative rounded-xl border border-zinc-800 bg-zinc-900/40 p-6">
                <span className="plasma-gradient-text text-4xl font-black opacity-80">{s.n}</span>
                <h3 className="mt-4 font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="border-t border-zinc-800/60 py-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <h2 className="text-center text-2xl font-bold tracking-tight sm:text-3xl">Un plan simple pour démarrer</h2>
          <div className="mx-auto mt-12 max-w-md">
            <div className="relative rounded-2xl border border-violet-500/40 bg-gradient-to-b from-violet-500/10 to-zinc-900/60 p-8 shadow-2xl shadow-violet-500/10">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <Badge className="bg-violet-600 text-white">Disponible maintenant</Badge>
              </div>
              <h3 className="text-center text-lg font-semibold">Gratuit</h3>
              <p className="mt-3 text-center text-5xl font-black tracking-tight">
                0 €<span className="text-base font-normal text-zinc-500"> / mois</span>
              </p>
              <ul className="mt-8 space-y-3 text-sm text-zinc-300">
                <li className="flex items-start gap-2"><ShieldCheck className="mt-0.5 h-4 w-4 text-violet-400" /> Projets illimités, export ZIP illimité</li>
                <li className="flex items-start gap-2"><Zap className="mt-0.5 h-4 w-4 text-violet-400" /> Génération code + README + visuels, même hors ligne</li>
                <li className="flex items-start gap-2"><MonitorPlay className="mt-0.5 h-4 w-4 text-violet-400" /> Vidéos jusqu&apos;à 60 Mo, bibliothèque média</li>
                <li className="flex items-start gap-2"><Link2 className="mt-0.5 h-4 w-4 text-violet-400" /> Bridge GenEdit : genedit.py &amp; genhub.sh dans l&apos;éditeur</li>
              </ul>
              <Button size="lg" onClick={onSignup} className="mt-8 w-full h-12 bg-violet-600 text-white hover:bg-violet-500">
                Créer mon compte gratuit
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER — collé en bas (mt-auto) */}
      <footer className="mt-auto border-t border-zinc-800/60 py-8 pb-[max(2rem,env(safe-area-inset-bottom))]">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 text-sm text-zinc-500 sm:flex-row sm:px-6">
          <div className="flex items-center gap-2">
            <div className="flex h-6 w-6 items-center justify-center rounded-md bg-gradient-to-br from-violet-500 to-fuchsia-500 text-[10px] font-black text-white">N</div>
            <span>NEXUS GEN HUB · Plasma</span>
          </div>
          <p>© {new Date().getFullYear()} NEXUS — Studio de génération. Produit indépendant, distinct d&apos;Aether.</p>
        </div>
      </footer>
    </div>
  );
}
