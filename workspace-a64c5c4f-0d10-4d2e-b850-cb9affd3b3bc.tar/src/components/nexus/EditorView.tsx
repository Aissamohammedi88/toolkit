'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import {
  ArrowLeft, Save, Play, Download, FilePlus2, Trash2, Sparkles, TerminalSquare,
  FolderTree, X, Loader2, Copy, RefreshCw, Braces,
} from 'lucide-react';
import CodeArea, { langOf } from './CodeArea';
import type { GenResult, GeneditInfo, ProjectFile, SessionUser } from './types';

interface Props {
  user: SessionUser;
  projectId: string; // '__genedit__' → ouvre le volet GenEdit seul
  onBack: () => void;
}

interface Tab {
  path: string;
  isGenEdit: boolean;
  dirty: boolean;
}

interface TermLine {
  kind: 'in' | 'out' | 'err' | 'ok';
  text: string;
}

type AiMode = 'code' | 'readme' | 'image' | 'chat';

const AI_MODES: { id: AiMode; label: string; hint: string }[] = [
  { id: 'code', label: 'Code', hint: 'ex. un serveur API avec 2 routes, un script de renommage…' },
  { id: 'readme', label: 'README', hint: 'ex. README pour mon studio de création vidéo' },
  { id: 'image', label: 'Visuel', hint: 'ex. vagues plasma violettes, néons fuchsia' },
  { id: 'chat', label: 'Chat', hint: 'posez votre question…' },
];

export default function EditorView({ user, projectId, onBack }: Props) {
  const isGeneditOnly = projectId === '__genedit__';
  const [projectName, setProjectName] = useState(isGeneditOnly ? 'GenEdit lié' : 'Projet');
  const [projectFiles, setProjectFiles] = useState<ProjectFile[]>([]);
  const [genedit, setGenedit] = useState<GeneditInfo | null>(null);
  const [tabs, setTabs] = useState<Tab[]>([]);
  const [activePath, setActivePath] = useState<string | null>(null);
  const [contents, setContents] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [running, setRunning] = useState(false);
  const [termLines, setTermLines] = useState<TermLine[]>([
    { kind: 'ok', text: '◆ Terminal NEXUS Plasma — prêt. Exécutez un fichier ou lancez genedit.py / genhub.sh.' },
  ]);
  const [newFileOpen, setNewFileOpen] = useState(false);
  const [newFilePath, setNewFilePath] = useState('');
  const [aiMode, setAiMode] = useState<AiMode>('code');
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<GenResult | null>(null);
  const termRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const pushTerm = useCallback((lines: TermLine[]) => {
    setTermLines((prev) => [...prev, ...lines].slice(-400));
  }, []);

  // ── Chargement : projet + bridge GenEdit ──────────────────────────────
  useEffect(() => {
    (async () => {
      try {
        const g = await fetch('/api/genedit').then((r) => r.json());
        setGenedit(g as GeneditInfo);
      } catch {
        /* bridge indisponible */
      }
      if (isGeneditOnly) return;
      try {
        const res = await fetch(`/api/projects/${projectId}`);
        if (!res.ok) return;
        const data = (await res.json()) as { project: { name: string }; files: ProjectFile[] };
        setProjectName(data.project.name);
        setProjectFiles(data.files);
        const map: Record<string, string> = {};
        for (const f of data.files) map[f.path] = f.content;
        setContents(map);
        // Ouvre par défaut le fichier principal
        const first = data.files.find((f) => /^(src\/)?(index|server|main|App)\.(js|jsx|ts|tsx)$/.test(f.path)) || data.files[0];
        if (first) {
          setTabs([{ path: first.path, isGenEdit: false, dirty: false }]);
          setActivePath(first.path);
        }
      } catch {
        toast({ title: 'Projet introuvable', variant: 'destructive' });
      }
    })();
  }, [projectId]);

  useEffect(() => {
    if (termRef.current) termRef.current.scrollTop = termRef.current.scrollHeight;
  }, [termLines]);

  // ── Onglets / fichiers ────────────────────────────────────────────────
  function openTab(path: string, isGenEdit: boolean, content: string) {
    const key = isGenEdit ? `genedit::${path}` : path;
    setContents((c) => ({ ...c, [key]: content }));
    setTabs((t) => (t.some((x) => x.path === key) ? t : [...t, { path: key, isGenEdit, dirty: false }]));
    setActivePath(key);
  }

  function closeTab(path: string) {
    setTabs((t) => {
      const next = t.filter((x) => x.path !== path);
      if (activePath === path) setActivePath(next.length ? next[next.length - 1].path : null);
      return next;
    });
  }

  function setValue(v: string) {
    if (!activePath) return;
    setContents((c) => ({ ...c, [activePath]: v }));
    setTabs((t) => t.map((x) => (x.path === activePath ? { ...x, dirty: true } : x)));
  }

  const activeContent = activePath ? contents[activePath] ?? '' : '';
  const activeIsGenEdit = activePath?.startsWith('genedit::') ?? false;
  const activeFileLabel = activePath ? activePath.replace('genedit::', '') : '—';

  // ── Sauvegarde ────────────────────────────────────────────────────────
  const saveActive = useCallback(async () => {
    if (!activePath || saving) return;
    setSaving(true);
    try {
      if (activeIsGenEdit) {
        const rel = activePath.replace('genedit::', '');
        const res = await fetch('/api/genedit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'write', path: rel, content: contents[activePath] }),
        });
        const data = (await res.json()) as { ok?: boolean; error?: string };
        if (!res.ok || !data.ok) {
          toast({ title: 'Écriture GenEdit refusée', description: data.error, variant: 'destructive' });
          return;
        }
        pushTerm([{ kind: 'ok', text: `✔ écrit : nexus-genedit/${rel}` }]);
      } else {
        const res = await fetch(`/api/projects/${projectId}/files`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ path: activePath, content: contents[activePath] }),
        });
        if (!res.ok) {
          toast({ title: 'Sauvegarde impossible', variant: 'destructive' });
          return;
        }
        setProjectFiles((fs) => {
          const exists = fs.some((f) => f.path === activePath);
          return exists ? fs.map((f) => (f.path === activePath ? { ...f, content: contents[activePath] } : f)) : [...fs, { path: activePath, content: contents[activePath] }];
        });
      }
      setTabs((t) => t.map((x) => (x.path === activePath ? { ...x, dirty: false } : x)));
      toast({ title: 'Sauvegardé', description: activeFileLabel });
    } finally {
      setSaving(false);
    }
  }, [activePath, activeIsGenEdit, activeFileLabel, contents, projectId, saving, pushTerm, toast]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        saveActive();
      }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [saveActive]);

  // ── Exécution (compile & run) ─────────────────────────────────────────
  async function runCurrent() {
    if (running) return;
    if (!activePath) {
      toast({ title: 'Ouvrez un fichier à exécuter.' });
      return;
    }
    setRunning(true);
    pushTerm([{ kind: 'in', text: `$ exécuter ${activeFileLabel}` }]);
    try {
      if (activeIsGenEdit) {
        const rel = activePath.replace('genedit::', '');
        const action = rel === 'genhub.sh' ? 'genhub' : rel === 'genedit.py' ? 'run' : 'run';
        const args = rel === 'genedit.py' ? ['serve'] : [];
        const res = await fetch('/api/genedit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action, path: rel, args }),
        });
        const data = (await res.json()) as { ok?: boolean; command?: string; output?: string; durationMs?: number; error?: string };
        if (data.command) pushTerm([{ kind: 'in', text: `$ ${data.command}` }]);
        pushTerm(
          (data.output || data.error || '(vide)')
            .split('\n')
            .map((l) => ({ kind: data.ok ? ('out' as const) : ('err' as const), text: l }))
        );
      } else {
        const res = await fetch('/api/run', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ projectId, path: activePath }),
        });
        const data = (await res.json()) as { ok?: boolean; command?: string; output?: string; status?: string; durationMs?: number; error?: string };
        if (data.error && !data.output) {
          pushTerm([{ kind: 'err', text: data.error }]);
          return;
        }
        pushTerm([{ kind: 'in', text: `$ ${data.command || activeFileLabel}  (${data.durationMs ?? 0} ms — ${data.status})` }]);
        pushTerm(
          (data.output || '')
            .split('\n')
            .map((l) => ({ kind: data.ok ? ('out' as const) : ('err' as const), text: l }))
        );
      }
    } catch {
      pushTerm([{ kind: 'err', text: 'Exécution impossible — serveur injoignable.' }]);
    } finally {
      setRunning(false);
    }
  }

  async function runGeneditCmd(action: 'run' | 'genhub') {
    setRunning(true);
    pushTerm([{ kind: 'in', text: action === 'run' ? '$ python3 genedit.py serve' : '$ bash genhub.sh' }]);
    try {
      const res = await fetch('/api/genedit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, args: ['serve'] }),
      });
      const data = (await res.json()) as { ok?: boolean; output?: string; error?: string; durationMs?: number };
      pushTerm(
        (data.output || data.error || '(vide)').split('\n').map((l) => ({ kind: data.ok ? 'out' : 'err', text: l }))
      );
    } finally {
      setRunning(false);
    }
  }

  // ── Nouveau / supprimer fichier projet ────────────────────────────────
  async function createFile() {
    const p = newFilePath.trim();
    if (!p || p.includes('..') || p.startsWith('/')) return;
    const res = await fetch(`/api/projects/${projectId}/files`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: p, content: `// ${p}\n// Créé dans NEXUS GEN HUB · Plasma\n` }),
    });
    if (res.ok) {
      openTab(p, false, `// ${p}\n// Créé dans NEXUS GEN HUB · Plasma\n`);
      setProjectFiles((fs) => [...fs, { path: p, content: '' }]);
    }
    setNewFileOpen(false);
    setNewFilePath('');
  }

  async function deleteProjectFile(path: string) {
    if (!confirm(`Supprimer « ${path} » ?`)) return;
    await fetch(`/api/projects/${projectId}/files`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path }),
    });
    setProjectFiles((fs) => fs.filter((f) => f.path !== path));
    closeTab(path);
  }

  async function exportZip() {
    const res = await fetch('/api/export', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId }),
    });
    if (!res.ok) {
      toast({ title: 'Export impossible', description: 'Projet vide ?' , variant: 'destructive' });
      return;
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${projectName}.zip`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: 'ZIP extrait et téléchargé' });
  }

  // ── IA ────────────────────────────────────────────────────────────────
  async function runAi() {
    if (!aiPrompt.trim() && aiMode !== 'chat') return;
    setAiLoading(true);
    setAiResult(null);
    try {
      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: aiMode, prompt: aiPrompt }),
      });
      const data = (await res.json()) as GenResult & { error?: string };
      if (data.error) {
        toast({ title: 'Génération impossible', description: data.error, variant: 'destructive' });
        return;
      }
      setAiResult(data);
    } catch {
      toast({ title: 'Moteur IA injoignable', variant: 'destructive' });
    } finally {
      setAiLoading(false);
    }
  }

  function insertAiResult(replaceCurrent: boolean) {
    if (!aiResult) return;
    if (aiResult.mode === 'image' && aiResult.svg) {
      const p = `assets/visuel-${Date.now()}.svg`;
      openTab(p, false, aiResult.svg);
      toast({ title: 'Visuel inséré', description: p });
      return;
    }
    const text = aiResult.text || '';
    if (replaceCurrent && activePath) {
      setValue(text);
      toast({ title: 'Fichier remplacé', description: activeFileLabel });
    } else {
      const name = aiResult.filename || (aiResult.mode === 'readme' ? 'README.md' : `genere-${Date.now()}.${langOfExt(aiResult.language)}`);
      openTab(name, false, text);
      toast({ title: 'Code inséré dans un nouveau fichier', description: name });
    }
  }

  function langOfExt(lang?: string): string {
    switch (lang) {
      case 'typescript': return 'ts';
      case 'python': return 'py';
      case 'markdown': return 'md';
      case 'json': return 'json';
      default: return 'js';
    }
  }

  // ── Rendu ─────────────────────────────────────────────────────────────
  const dirtyCount = tabs.filter((t) => t.dirty).length;

  return (
    <div className="flex h-screen flex-col bg-[#0a0a0d] text-zinc-100">
      {/* Barre supérieure */}
      <header className="flex h-12 shrink-0 items-center gap-2 border-b border-zinc-800/80 px-3">
        <Button size="sm" variant="ghost" onClick={onBack} className="-ml-1 text-zinc-400 hover:text-zinc-50">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <span className="text-sm font-semibold">{projectName}</span>
        <Badge variant="outline" className="hidden border-violet-500/40 bg-violet-500/10 text-[10px] text-violet-300 sm:inline-flex">
          éditeur unifié · GenHub + GenEdit
        </Badge>
        {dirtyCount > 0 && <span className="text-xs text-amber-400">{dirtyCount} non sauvegardé{dirtyCount > 1 ? 's' : ''}</span>}
        <div className="ml-auto flex items-center gap-1.5">
          <Button size="sm" variant="outline" className="h-8 border-zinc-700 hover:bg-zinc-800" onClick={saveActive} disabled={saving || !activePath}>
            {saving ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <Save className="mr-1.5 h-3.5 w-3.5" />} Sauver
          </Button>
          <Button size="sm" className="h-8 bg-violet-600 text-white hover:bg-violet-500" onClick={runCurrent} disabled={running || !activePath}>
            {running ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <Play className="mr-1.5 h-3.5 w-3.5" />} Exécuter
          </Button>
          {!isGeneditOnly && (
            <Button size="sm" variant="outline" className="h-8 border-zinc-700 hover:bg-zinc-800" onClick={exportZip}>
              <Download className="mr-1.5 h-3.5 w-3.5" /> ZIP
            </Button>
          )}
        </div>
      </header>

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        {/* EXPLORATEUR */}
        <aside className="nexus-scroll w-full shrink-0 overflow-y-auto border-b border-zinc-800/80 bg-[#0c0c0f] p-3 lg:w-64 lg:border-b-0 lg:border-r" aria-label="Explorateur de fichiers">
          {!isGeneditOnly && (
            <section className="mb-5">
              <div className="mb-2 flex items-center justify-between">
                <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-zinc-500">
                  <Braces className="h-3.5 w-3.5" /> {projectName}
                </p>
                <Button size="icon" variant="ghost" className="h-6 w-6 text-zinc-500 hover:text-violet-300" onClick={() => setNewFileOpen(true)} aria-label="Nouveau fichier">
                  <FilePlus2 className="h-3.5 w-3.5" />
                </Button>
              </div>
              {projectFiles.length === 0 ? (
                <p className="px-1 py-2 text-xs text-zinc-600">Aucun fichier — créez-en un ou demandez à l&apos;IA.</p>
              ) : (
                <ul className="space-y-0.5">
                  {[...projectFiles].sort((a, b) => a.path.localeCompare(b.path)).map((f) => (
                    <li key={f.path} className={`group flex items-center rounded-md px-2 py-1 text-xs ${activePath === f.path ? 'bg-violet-500/15 text-violet-200' : 'text-zinc-400 hover:bg-zinc-800/60'}`}>
                      <button className="min-w-0 flex-1 truncate text-left" onClick={() => openTab(f.path, false, contents[f.path] ?? f.content)}>
                        {f.path}
                      </button>
                      <button className="ml-1 hidden text-zinc-600 hover:text-red-400 group-hover:block" onClick={() => deleteProjectFile(f.path)} aria-label={`Supprimer ${f.path}`}>
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          )}

          {/* GenEdit lié */}
          <section>
            <div className="mb-2 flex items-center justify-between">
              <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-fuchsia-400/90">
                <FolderTree className="h-3.5 w-3.5" /> GenEdit lié
              </p>
              <Badge variant="outline" className={`border text-[9px] ${genedit?.mode === 'live' ? 'border-emerald-500/40 text-emerald-400' : 'border-amber-500/40 text-amber-400'}`}>
                {genedit?.mode === 'live' ? 'live' : 'démo'}
              </Badge>
            </div>
            <p className="mb-2 truncate px-1 text-[10px] text-zinc-600">{genedit?.home || '…'}</p>
            <ul className="space-y-0.5">
              {(genedit?.files || []).map((f) => (
                <li key={f.path} className={`group flex items-center rounded-md px-2 py-1 text-xs ${activePath === `genedit::${f.path}` ? 'bg-fuchsia-500/15 text-fuchsia-200' : 'text-zinc-400 hover:bg-zinc-800/60'}`}>
                  <button
                    className="min-w-0 flex-1 truncate text-left"
                    onClick={async () => {
                      if (f.isDir) return;
                      const res = await fetch('/api/genedit', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ action: 'read', path: f.path }),
                      });
                      const data = (await res.json()) as { ok?: boolean; content?: string; error?: string };
                      if (data.ok) openTab(f.path, true, data.content || '');
                      else toast({ title: 'Lecture GenEdit', description: data.error, variant: 'destructive' });
                    }}
                  >
                    {f.path}
                  </button>
                </li>
              ))}
            </ul>
            <div className="mt-3 space-y-1.5 border-t border-zinc-800 pt-3">
              <Button size="sm" variant="outline" className="h-7 w-full justify-start border-fuchsia-500/30 text-xs hover:bg-fuchsia-500/10" onClick={() => runGeneditCmd('run')} disabled={running}>
                <Play className="mr-1.5 h-3 w-3" /> python3 genedit.py
              </Button>
              <Button size="sm" variant="outline" className="h-7 w-full justify-start border-violet-500/30 text-xs hover:bg-violet-500/10" onClick={() => runGeneditCmd('genhub')} disabled={running}>
                <Play className="mr-1.5 h-3 w-3" /> bash genhub.sh
              </Button>
            </div>
          </section>
        </aside>

        {/* CENTRE : onglets + éditeur + terminal */}
        <main className="flex min-h-0 min-w-0 flex-1 flex-col">
          {/* Onglets */}
          <div className="nexus-scroll flex h-9 shrink-0 items-stretch overflow-x-auto border-b border-zinc-800/80 bg-[#0e0e12]">
            {tabs.map((t) => (
              <div
                key={t.path}
                className={`flex items-center gap-1.5 border-r border-zinc-800/80 px-3 text-xs ${activePath === t.path ? 'bg-[#0c0c0f] text-zinc-100' : 'text-zinc-500 hover:text-zinc-300'}`}
              >
                <button className="max-w-[180px] truncate" onClick={() => setActivePath(t.path)}>
                  {t.path.replace('genedit::', '')}
                  {t.dirty ? ' •' : ''}
                </button>
                <button onClick={() => closeTab(t.path)} aria-label={`Fermer ${t.path}`} className="text-zinc-600 hover:text-zinc-200">
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
            {tabs.length === 0 && <div className="flex items-center px-4 text-xs text-zinc-600">Ouvrez un fichier dans l&apos;explorateur</div>}
          </div>

          {/* Éditeur */}
          <div className="min-h-0 flex-1">
            {activePath ? (
              <CodeArea value={activeContent} path={activeFileLabel} onChange={setValue} readOnly={false} />
            ) : (
              <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
                <Sparkles className="h-8 w-8 text-violet-500/50" aria-hidden />
                <p className="max-w-sm text-sm text-zinc-500">
                  Sélectionnez un fichier <span className="text-zinc-300">GenHub</span> ou <span className="text-fuchsia-300">GenEdit</span> — tout est dans le même éditeur.
                </p>
              </div>
            )}
          </div>

          {/* TERMINAL */}
          <section className="h-52 shrink-0 border-t border-zinc-800/80 bg-[#08080b]" aria-label="Terminal intégré">
            <div className="flex h-8 items-center gap-2 border-b border-zinc-800/80 px-3">
              <TerminalSquare className="h-3.5 w-3.5 text-violet-400" />
              <span className="text-xs font-medium text-zinc-400">Terminal</span>
              <div className="ml-auto flex gap-1">
                <Button size="sm" variant="ghost" className="h-6 px-2 text-[11px] text-zinc-400 hover:text-zinc-100" onClick={runCurrent} disabled={running}>
                  <Play className="mr-1 h-3 w-3" /> Exécuter
                </Button>
                <Button size="sm" variant="ghost" className="h-6 px-2 text-[11px] text-zinc-400 hover:text-zinc-100" onClick={() => setTermLines(termLines.slice(0, 1))}>
                  <RefreshCw className="mr-1 h-3 w-3" /> Vider
                </Button>
              </div>
            </div>
            <div ref={termRef} className="nexus-scroll h-[calc(100%-2rem)] overflow-y-auto px-3 py-2 font-mono text-[11px] leading-5">
              {termLines.map((l, i) => (
                <p key={i} className={`whitespace-pre-wrap ${l.kind === 'in' ? 'text-violet-300' : l.kind === 'err' ? 'text-red-400' : l.kind === 'ok' ? 'text-emerald-400' : 'text-zinc-400'}`}>
                  {l.text}
                </p>
              ))}
            </div>
          </section>
        </main>

        {/* PANNEAU IA */}
        <aside className="nexus-scroll w-full shrink-0 overflow-y-auto border-t border-zinc-800/80 bg-[#0c0c0f] p-4 lg:w-80 lg:border-l lg:border-t-0" aria-label="Panneau de génération IA">
          <p className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-zinc-500">
            <Sparkles className="h-3.5 w-3.5 text-violet-400" /> Générer
          </p>
          <div className="mb-3 grid grid-cols-4 gap-1 rounded-lg border border-zinc-800 p-1">
            {AI_MODES.map((m) => (
              <button
                key={m.id}
                onClick={() => setAiMode(m.id)}
                className={`rounded-md px-2 py-1.5 text-xs transition-colors ${aiMode === m.id ? 'bg-violet-500/20 font-medium text-violet-200' : 'text-zinc-500 hover:text-zinc-300'}`}
              >
                {m.label}
              </button>
            ))}
          </div>
          <textarea
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
            placeholder={AI_MODES.find((m) => m.id === aiMode)?.hint}
            rows={3}
            aria-label="Décrire ce qu'il faut générer"
            className="nexus-scroll w-full resize-none rounded-lg border border-zinc-800 bg-[#101014] px-3 py-2 text-xs text-zinc-200 placeholder:text-zinc-600 focus:border-violet-500/50 focus:outline-none"
          />
          <Button onClick={runAi} disabled={aiLoading} className="mt-2 w-full h-9 bg-violet-600 text-sm text-white hover:bg-violet-500">
            {aiLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
            {aiLoading ? 'Génération…' : 'Générer'}
          </Button>

          {aiResult && (
            <div className="mt-4 rounded-lg border border-zinc-800 bg-[#101014]">
              <div className="flex items-center justify-between border-b border-zinc-800 px-3 py-2">
                <Badge variant="outline" className={`text-[10px] ${aiResult.provider.startsWith('moteur') ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-400' : 'border-violet-500/40 bg-violet-500/10 text-violet-300'}`}>
                  {aiResult.provider}
                </Badge>
                <span className="text-[10px] text-zinc-600">{aiResult.fallbackChain.join(' → ')}</span>
              </div>
              {aiResult.mode === 'image' && aiResult.svg ? (
                <div className="p-3">
                  <div className="overflow-hidden rounded-md border border-zinc-800" dangerouslySetInnerHTML={{ __html: aiResult.svg.replace('<svg ', '<svg style="width:100%;height:auto;display:block" ') }} />
                </div>
              ) : (
                <pre className="nexus-scroll max-h-64 overflow-auto whitespace-pre-wrap px-3 py-2 text-[11px] leading-5 text-zinc-300">
                  {(aiResult.text || '').slice(0, 3000)}
                </pre>
              )}
              <div className="flex gap-1.5 border-t border-zinc-800 p-2">
                {aiResult.mode !== 'chat' && (
                  <>
                    <Button size="sm" className="h-7 flex-1 bg-violet-600 text-xs text-white hover:bg-violet-500" onClick={() => insertAiResult(false)}>
                      Insérer
                    </Button>
                    {activePath && !activeIsGenEdit && (
                      <Button size="sm" variant="outline" className="h-7 border-zinc-700 text-xs hover:bg-zinc-800" onClick={() => insertAiResult(true)}>
                        Remplacer
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 w-7 p-0 text-zinc-500 hover:text-zinc-200"
                      aria-label="Copier"
                      onClick={() => {
                        navigator.clipboard?.writeText(aiResult.text || aiResult.svg || '');
                        toast({ title: 'Copié' });
                      }}
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </Button>
                  </>
                )}
              </div>
              <p className="border-t border-zinc-800 px-3 py-1.5 text-[10px] text-zinc-600">{aiResult.note}</p>
            </div>
          )}

          <div className="mt-6 rounded-lg border border-zinc-800/70 bg-zinc-900/30 p-3">
            <p className="text-[11px] font-medium text-zinc-400">Chaîne de génération</p>
            <p className="mt-1 text-[10px] leading-4 text-zinc-600">
              1. Pollinations — API gratuite, sans clé<br />
              2. Moteur local NEXUS — marche même sans internet
            </p>
          </div>
          <p className="mt-4 text-[10px] text-zinc-700">
            Connecté : {user.name} · plan {user.plan}
          </p>
        </aside>
      </div>

      {/* Dialog nouveau fichier */}
      <Dialog open={newFileOpen} onOpenChange={setNewFileOpen}>
        <DialogContent className="border-zinc-800 bg-zinc-950">
          <DialogHeader><DialogTitle>Nouveau fichier</DialogTitle></DialogHeader>
          <Input value={newFilePath} onChange={(e) => setNewFilePath(e.target.value)} placeholder="ex. src/routes/clients.js" onKeyDown={(e) => e.key === 'Enter' && createFile()} />
          <DialogFooter>
            <Button onClick={createFile} disabled={!newFilePath.trim()} className="bg-violet-600 text-white hover:bg-violet-500">Créer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
