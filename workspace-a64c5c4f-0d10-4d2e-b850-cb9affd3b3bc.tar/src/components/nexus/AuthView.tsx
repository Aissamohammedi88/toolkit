'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, ArrowLeft } from 'lucide-react';
import type { SessionUser } from './types';

interface Props {
  onAuthenticated: (user: SessionUser) => void;
  onBack: () => void;
}

export default function AuthView({ onAuthenticated, onBack }: Props) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(action: 'signup' | 'login', form: FormData) {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          name: String(form.get('name') || ''),
          email: String(form.get('email') || ''),
          password: String(form.get('password') || ''),
        }),
      });
      const data = (await res.json()) as { user?: SessionUser; error?: string };
      if (!res.ok) {
        setError(data.error || 'Échec de la connexion.');
        return;
      }
      if (data.user) onAuthenticated(data.user);
    } catch {
      setError('Serveur injoignable.');
    } finally {
      setLoading(false);
    }
  }

  function Field({ id, label, type, placeholder, required }: { id: string; label: string; type: string; placeholder: string; required?: boolean }) {
    return (
      <div className="space-y-2">
        <Label htmlFor={id}>{label}</Label>
        <Input id={id} name={id} type={type} placeholder={placeholder} required={required} autoComplete={type === 'password' ? 'current-password' : 'on'} />
      </div>
    );
  }

  function Form({ action, submitLabel }: { action: 'signup' | 'login'; submitLabel: string }) {
    return (
      <form
        className="space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          submit(action, new FormData(e.currentTarget));
        }}
      >
        {action === 'signup' && <Field id="name" label="Nom / Studio" type="text" placeholder="ex. Studio Nexus" />}
        <Field id="email" label="E-mail" type="email" placeholder="vous@exemple.fr" required />
        <Field id="password" label="Mot de passe" type="password" placeholder="6 caractères minimum" required />
        <Button type="submit" disabled={loading} className="w-full h-11 bg-violet-600 text-white hover:bg-violet-500">
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          {submitLabel}
        </Button>
      </form>
    );
  }

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center bg-[#09090b] px-4 py-12">
      <div className="plasma-glow absolute inset-0" aria-hidden />
      <div className="relative w-full max-w-md">
        <Button variant="ghost" size="sm" onClick={onBack} className="mb-6 -ml-2 text-zinc-400 hover:text-zinc-50">
          <ArrowLeft className="mr-1 h-4 w-4" /> Retour
        </Button>
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-8 shadow-2xl backdrop-blur">
          <div className="mb-8 text-center">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 text-lg font-black text-white shadow-lg shadow-violet-500/30">N</div>
            <h1 className="text-xl font-bold tracking-tight">NEXUS GEN HUB</h1>
            <p className="mt-1 text-sm text-zinc-400">Studio de génération · éditeur unifié</p>
            <Badge variant="outline" className="mt-3 border-violet-500/40 bg-violet-500/10 text-violet-300">Plan Gratuit — 0 €</Badge>
          </div>

          <Tabs defaultValue="signup">
            <TabsList className="mb-6 grid w-full grid-cols-2">
              <TabsTrigger value="signup">Créer un compte</TabsTrigger>
              <TabsTrigger value="login">Connexion</TabsTrigger>
            </TabsList>
            <TabsContent value="signup"><Form action="signup" submitLabel="Créer mon compte gratuit" /></TabsContent>
            <TabsContent value="login"><Form action="login" submitLabel="Se connecter" /></TabsContent>
          </Tabs>

          {error && (
            <p role="alert" className="mt-4 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">
              {error}
            </p>
          )}
        </div>
        <p className="mt-6 text-center text-xs text-zinc-600">
          Vos clients peuvent s&apos;inscrire ici — chaque compte démarre sur le plan Gratuit.
        </p>
      </div>
    </div>
  );
}
