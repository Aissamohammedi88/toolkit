'use client';

import { useEffect, useMemo, useRef } from 'react';

/**
 * CodeArea — éditeur de code intégré (textarea + coloration + numéros de ligne).
 * Zéro dépendance externe : fiable, léger, hors-ligne.
 */

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

const KEYWORDS =
  'const|let|var|function|return|if|else|for|while|class|new|import|from|export|default|async|await|require|module|exports|typeof|instanceof|interface|type|extends|implements|try|catch|finally|throw|switch|case|break|continue|of|in|def|self|None|True|False|elif|lambda|pass|with|as|not|and|or|print|this|super|static|public|private|void|null|undefined|true|false';

const TOKEN_RE = new RegExp(
  [
    '(\\/\\/[^\\n]*|#[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/|<!--[^\\n]*-->)', // 1 commentaire
    '("(?:[^"\\\\\\n]|\\\\.)*"|\'(?:[^\'\\\\\\n]|\\\\.)*\'|`(?:[^`\\\\]|\\\\.)*`)', // 2 chaîne
    `\\b(${KEYWORDS})\\b`, // 3 mot-clé
    '\\b(\\d+(?:\\.\\d+)?)\\b', // 4 nombre
    '([A-Za-z_$][\\w$]*)(?=\\s*\\()', // 5 fonction
  ].join('|'),
  'g'
);

function highlightJS(code: string): string {
  let out = '';
  let last = 0;
  TOKEN_RE.lastIndex = 0;
  let m: RegExpExecArray | null;
  while ((m = TOKEN_RE.exec(code)) !== null) {
    out += esc(code.slice(last, m.index));
    const cls = m[1] ? 'tok-com' : m[2] ? 'tok-str' : m[3] ? 'tok-key' : m[4] ? 'tok-num' : 'tok-fn';
    out += `<span class="${cls}">${esc(m[0])}</span>`;
    last = m.index + m[0].length;
  }
  out += esc(code.slice(last));
  return out;
}

function highlightMD(code: string): string {
  return code
    .split('\n')
    .map((line) => {
      if (/^#{1,6}\s/.test(line)) return `<span class="tok-md-h">${esc(line)}</span>`;
      if (/^\s*[-*|]/.test(line) || /^\s*\d+\./.test(line)) return `<span class="tok-md-b">${esc(line)}</span>`;
      if (line.includes('```')) return `<span class="tok-com">${esc(line)}</span>`;
      return esc(line).replace(/\*\*([^*]+)\*\*/g, '<span class="tok-md-b">**$1**</span>');
    })
    .join('\n');
}

function highlight(code: string, lang: string): string {
  if (lang === 'markdown') return highlightMD(code);
  if (lang === 'html' || lang === 'css' || lang === 'svg') return highlightJS(code);
  return highlightJS(code);
}

function langOf(path: string): string {
  if (path.endsWith('.md')) return 'markdown';
  if (/\.(json|lock)$/.test(path)) return 'json';
  if (path.endsWith('.html')) return 'html';
  if (path.endsWith('.css')) return 'css';
  if (path.endsWith('.svg')) return 'svg';
  if (path.endsWith('.py')) return 'python';
  if (/\.(jsx?|tsx?|mjs|cjs)$/.test(path)) return 'javascript';
  if (path.endsWith('.sh')) return 'bash';
  if (path.endsWith('.yml') || path.endsWith('.yaml')) return 'yaml';
  return 'text';
}

interface Props {
  value: string;
  path: string;
  onChange: (v: string) => void;
  readOnly?: boolean;
}

export default function CodeArea({ value, path, onChange, readOnly }: Props) {
  const taRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);
  const gutterRef = useRef<HTMLDivElement>(null);

  const lang = langOf(path);
  const html = useMemo(() => highlight(value, lang), [value, lang]);
  const lines = useMemo(() => value.split('\n').length, [value]);

  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.scrollTop = 0;
  }, [path]);

  function syncScroll() {
    const ta = taRef.current;
    if (!ta) return;
    if (preRef.current) {
      preRef.current.scrollTop = ta.scrollTop;
      preRef.current.scrollLeft = ta.scrollLeft;
    }
    if (gutterRef.current) gutterRef.current.scrollTop = ta.scrollTop;
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Tab') {
      e.preventDefault();
      const ta = e.currentTarget;
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const next = value.slice(0, start) + '  ' + value.slice(end);
      onChange(next);
      requestAnimationFrame(() => {
        ta.selectionStart = ta.selectionEnd = start + 2;
      });
    }
  }

  return (
    <div className="relative flex h-full overflow-hidden bg-[#0c0c0f] font-mono text-[13px] leading-6">
      {/* Numéros de ligne */}
      <div
        ref={gutterRef}
        aria-hidden
        className="nexus-scroll select-none overflow-hidden border-r border-zinc-800/80 bg-[#0a0a0d] px-3 py-3 text-right text-zinc-600"
        style={{ minWidth: '3.2rem' }}
      >
        {Array.from({ length: lines }, (_, i) => (
          <div key={i}>{i + 1}</div>
        ))}
      </div>

      {/* Code + superposition */}
      <div className="relative flex-1">
        <pre
          ref={preRef}
          aria-hidden
          className="nexus-scroll pointer-events-none absolute inset-0 overflow-auto whitespace-pre px-4 py-3 text-zinc-200"
          dangerouslySetInnerHTML={{ __html: html + '\n' }}
        />
        <textarea
          ref={taRef}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onScroll={syncScroll}
          onKeyDown={onKeyDown}
          readOnly={readOnly}
          spellCheck={false}
          aria-label={`Éditeur — ${path}`}
          className="nexus-scroll absolute inset-0 resize-none overflow-auto whitespace-pre bg-transparent px-4 py-3 text-transparent caret-violet-400 outline-none selection:bg-violet-500/30"
        />
      </div>
    </div>
  );
}

export { langOf };
