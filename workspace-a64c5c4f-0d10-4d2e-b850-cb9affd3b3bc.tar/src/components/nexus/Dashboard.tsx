'use client';

import { useCallback, useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import {
  FolderGit2, Plus, Trash2, Download, Pencil, Users, FolderTree, Loader2, Play, ExternalLink,
} from 'lucide-react';
import MediaGallery from './MediaGallery';
import { kindLabel, ProjectRow, SessionUser, Stats } from './types';

interface Props {
  user: SessionUser;
  onOpenEditor: (projectId: string) => void;
  onLogout: () => void;
}

interface ClientRow {
  id: string;
  name: string;
  email: string;
  plan: string;
  role: string;
  createdAt: string;
}

export default function Dashboard({ user, onOpenEditor, onLogout }: Props) {
  const [stats, setStats] = useState<Stats | null>(null);
  const [projects, setProjects] = useState<ProjectRow[]>([]);
  const [clients, setClients] = useState<ClientRow[]>([]);
  const [createOpen, setCreateOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newKind, setNewKind] = useState('node-app');
  const [creating, setCreating] = useState(false);
  const [runningGen, setRunningGen] = useState<string | null>(null);
  const { toast } = useToast();

  const load = useCallback(async () => {
    const [s, p, c] = await Promise.all([
      fetch('/api/stats').then((r) => r.json()),
      fetch('/api/projects').then((r) => r.json()),
      fetch('/api/clients').then((r) => r.json()),
    ]);
    if (s.projects !== undefined) setStats(s as Stats);
    if (Array.isArray(p.projects)) setProjects(p.projects);
    if (Array.isArray(c.clients)) setClients(c.clients);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function createProject() {
    if (!newName.trim()) return;
    setCreating(true);
    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newName, kind: newKind }),
      });
      const data = (await res.json()) as { id?: string; filesCreated?: number; error?: string };
      if (!res.ok) {
        toast({ title: 'Création impossible', description: data.error, variant: 'destructive' });
        return;
      }
      toast({ title: 'Projet créé', description: `${data.filesCreated ?? 0} fichiers de production générés.` });
      setCreateOpen(false);
      setNewName('');
      await load();
      if (data.id) onOpenEditor(data.id);
    } finally {
      setCreating(false);
    }
  }

  async function deleteProject(id: string, name: string) {
    if (!confirm(`Supprimer définitivement « ${name} » ?`)) return;
    await fetch(`/api/projects/${id}`, { method: 'DELETE' });
    setProjects((p) => p.filter((x) => x.id !== id));
    toast({ title: 'Projet supprimé' });
  }

  async function exportZip(projectId: string, name: string) {
    const res = await fetch('/api/export', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId }),
    });
    if (!res.ok) {
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      toast({ title: 'Export impossible', description: data.error, variant: 'destructive' });
      return;
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${name}.zip`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: 'ZIP extrait et téléchargé', description: `${name}.zip prêt à livrer.` });
  }

  async function runGenedit(action: 'run' | 'genhub') {
    setRunningGen(action);
    try {
      const res = await fetch('/api/genedit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, args: ['serve'] }),
      });
      const data = (await res.json()) as { ok?: boolean; output?: string; error?: string };
      toast({
        title: action === 'run' ? 'genedit.py exécuté' : 'genhub.sh exécuté',
        description: data.ok ? 'Sortie visible dans le journal.' : data.error || 'Erreur.',
        variant: data.ok ? 'default' : 'destructive',
      });
    } finally {
      setRunningGen(null);
    }
  }

  const kpis = [
    { label: 'Projets', value: stats?.projects ?? '—', icon: FolderGit2 },
    { label: 'Fichiers générés', value: stats?.files ?? '—', icon: FolderTree },
    { label: 'Médias', value: stats?.media ?? '—', icon: Play },
    { label: 'Clients inscrits', value: stats?.clients ?? '—', icon: Users },
  ];

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-50">
      {/* HEADER */}
      <header className="sticky top-0 z-40 border-b border-zinc-800/60 bg-[#09090b]/80 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 text-sm font-black text-white">N</div>
            <span className="hidden text-sm font-semibold sm:inline">NEXUS GEN HUB</span>
            <Badge variant="outline" className="hidden border-violet-500/40 bg-violet-500/10 text-violet-300 sm:inline-flex">Plasma</Badge>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-sm font-medium leading-4">{user.name}</p>
              <p className="text-xs text-zinc-500">{user.role === 'owner' ? 'Compte fondateur' : 'Client'} · plan {user.plan}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={onLogout} className="text-zinc-400 hover:text-zinc-50">Déconnexion</Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        {/* KPIs */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {kpis.map((k) => (
            <div key={k.label} className="rounded-xl border border-zinc-800 bg-zinc-900/40 p-5">
              <div className="flex items-center justify-between">
                <p className="text-sm text-zinc-400">{k.label}</p>
                <k.icon className="h-4 w-4 text-violet-400" aria-hidden />
              </div>
              <p className="mt-2 text-3xl font-bold tracking-tight">{k.value}</p>
            </div>
          ))}
        </div>

        {/* GenEdit bridge */}
        <div className="mt-6 rounded-xl border border-fuchsia-500/25 bg-gradient-to-r from-fuchsia-500/10 to-violet-500/5 p-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="min-w-0">
              <p className="flex items-center gap-2 font-semibold">
                <FolderTree className="h-4 w-4 text-fuchsia-400" /> GenEdit lié — même éditeur, même studio
              </p>
              <p className="mt-1 truncate text-sm text-zinc-400">
                {stats?.genedit.mode === 'live' ? stats.genedit.home : 'nexus-genedit (bridge actif — mode live sur votre machine via l\u2019installateur)'}
                {' · '}{stats?.genedit.files ?? 0} entrées
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="outline" className="border-fuchsia-500/40 bg-fuchsia-500/10 hover:bg-fuchsia-500/20" onClick={() => runGenedit('run')} disabled={runningGen !== null}>
                {runningGen === 'run' ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : <Play className="mr-2 h-3.5 w-3.5" />} python3 genedit.py
              </Button>
              <Button size="sm" variant="outline" className="border-violet-500/40 bg-violet-500/10 hover:bg-violet-500/20" onClick={() => runGenedit('genhub')} disabled={runningGen !== null}>
                {runningGen === 'genhub' ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : <Play className="mr-2 h-3.5 w-3.5" />} bash genhub.sh
              </Button>
              <Button size="sm" onClick={() => onOpenEditor('__genedit__')} className="bg-violet-600 text-white hover:bg-violet-500">
                <ExternalLink className="mr-2 h-3.5 w-3.5" /> Ouvrir dans l&apos;éditeur
              </Button>
            </div>
          </div>
        </div>

        {/* TABS */}
        <div className="mt-10">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-lg font-semibold tracking-tight">Vos projets</h2>
            <Dialog open={createOpen} onOpenChange={setCreateOpen}>
              <DialogTrigger asChild>
                <Button className="bg-violet-600 text-white hover:bg-violet-500"><Plus className="mr-2 h-4 w-4" /> Nouveau projet</Button>
              </DialogTrigger>
              <DialogContent className="border-zinc-800 bg-zinc-950">
                <DialogHeader><DialogTitle>Créer un projet — code de production immédiat</DialogTitle></DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="pname">Nom du projet</Label>
                    <Input id="pname" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="ex. Studio Client Alpha" />
                  </div>
                  <div className="space-y-2">
                    <Label>Modèle (généré complet, pas de squelette vide)</Label>
                    <Select value={newKind} onValueChange={setNewKind}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent className="border-zinc-800 bg-zinc-950">
                        <SelectItem value="node-app">App Node.js — serveur zéro dépendance + API + tests</SelectItem>
                        <SelectItem value="api-service">API REST — CRUD complet avec persistance JSON</SelectItem>
                        <SelectItem value="react-app">App React — React 18 + Vite, build prêt</SelectItem>
                        <SelectItem value="vide">Projet vide — partir de zéro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={createProject} disabled={creating || !newName.trim()} className="bg-violet-600 text-white hover:bg-violet-500">
                    {creating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Pencil className="mr-2 h-4 w-4" />} Créer &amp; ouvrir
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          {projects.length === 0 ? (
            <div className="mt-4 rounded-xl border border-dashed border-zinc-800 py-14 text-center">
              <FolderGit2 className="mx-auto h-8 w-8 text-zinc-700" aria-hidden />
              <p className="mt-3 text-sm text-zinc-500">Aucun projet — cliquez sur « Nouveau projet », le code complet est généré en 1 seconde.</p>
            </div>
          ) : (
            <div className="mt-4 overflow-hidden rounded-xl border border-zinc-800">
              {projects.map((p, i) => (
                <div key={p.id} className={`flex flex-wrap items-center gap-3 p-4 ${i > 0 ? 'border-t border-zinc-800' : ''} bg-zinc-900/40 transition-colors hover:bg-zinc-900/70`}>
                  <div className="min-w-0 flex-1">
                    <button onClick={() => onOpenEditor(p.id)} className="truncate text-left text-sm font-medium hover:text-violet-300">
                      {p.name}
                    </button>
                    <p className="mt-0.5 text-xs text-zinc-500">
                      {kindLabel[p.kind] || p.kind} · {p.files} fichiers · maj {new Date(p.updatedAt).toLocaleDateString('fr-FR')}
                    </p>
                  </div>
                  <div className="flex gap-1.5">
                    <Button size="sm" variant="outline" className="h-8 border-zinc-700 hover:bg-zinc-800" onClick={() => onOpenEditor(p.id)}>Ouvrir</Button>
                    <Button size="sm" variant="outline" className="h-8 border-zinc-700 hover:bg-zinc-800" onClick={() => exportZip(p.id, p.name)} aria-label={`Exporter ${p.name}`}>
                      <Download className="h-3.5 w-3.5" />
                    </Button>
                    <Button size="sm" variant="ghost" className="h-8 text-zinc-500 hover:text-red-400" onClick={() => deleteProject(p.id, p.name)} aria-label={`Supprimer ${p.name}`}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Media + Clients */}
        <div className="mt-12 grid gap-8 lg:grid-cols-[1.6fr_1fr]">
          <section aria-label="Bibliothèque média">
            <h2 className="mb-4 text-lg font-semibold tracking-tight">Bibliothèque — vidéos &amp; visuels</h2>
            <MediaGallery />
          </section>

          <section aria-label="Clients inscrits">
            <h2 className="mb-4 text-lg font-semibold tracking-tight">Clients inscrits</h2>
            <div className="rounded-xl border border-zinc-800 bg-zinc-900/40 p-4">
              {clients.length === 0 ? (
                <p className="py-8 text-center text-sm text-zinc-500">Aucun inscrit pour l&apos;instant.</p>
              ) : (
                <ul className="divide-y divide-zinc-800">
                  {clients.slice(0, 8).map((c) => (
                    <li key={c.id} className="flex items-center justify-between gap-3 py-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium">{c.name}{c.id === user.id ? ' (vous)' : ''}</p>
                        <p className="truncate text-xs text-zinc-500">{c.email}</p>
                      </div>
                      <Badge variant="outline" className="shrink-0 border-violet-500/40 bg-violet-500/10 text-[10px] text-violet-300">
                        {c.role === 'owner' ? 'fondateur' : c.plan}
                      </Badge>
                    </li>
                  ))}
                </ul>
              )}
              <p className="mt-3 text-xs text-zinc-600">
                Chaque visiteur de votre page d&apos;accueil peut créer un compte gratuit — préparez votre futur service.
              </p>
            </div>
          </section>
        </div>
      </main>

      <footer className="mt-auto border-t border-zinc-800/60 py-6 text-center text-xs text-zinc-600 pb-[max(1.5rem,env(safe-area-inset-bottom))]">
        NEXUS GEN HUB · Plasma — studio indépendant (distinct d&apos;Aether et de GenEdit, qui y est simplement relié).
      </footer>
    </div>
  );
}
