/** Types partagés client — NEXUS GEN HUB · Plasma */

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  plan: string;
  role: string;
  createdAt: string;
}

export interface ProjectRow {
  id: string;
  name: string;
  kind: string;
  description: string;
  framework: string;
  files: number;
  createdAt: string;
  updatedAt: string;
}

export interface ProjectFile {
  path: string;
  content: string;
  updatedAt?: string;
}

export interface MediaRow {
  id: string;
  kind: 'image' | 'video';
  name: string;
  mimeType: string;
  size: number;
  prompt: string;
  provider: string;
  filePath: string;
  createdAt: string;
}

export interface GeneditFileRow {
  path: string;
  size: number;
  isDir: boolean;
}

export interface GeneditInfo {
  mode: 'live' | 'demo';
  home: string;
  entryPy: string | null;
  launcherSh: string | null;
  files: GeneditFileRow[];
}

export interface GenResult {
  mode: string;
  prompt: string;
  provider: string;
  fallbackChain: string[];
  text?: string;
  svg?: string;
  language?: string;
  filename?: string;
  note: string;
}

export interface RunResult {
  ok: boolean;
  command: string;
  output: string;
  status: 'ok' | 'error' | 'timeout';
  durationMs: number;
}

export interface Stats {
  projects: number;
  media: number;
  runs: number;
  clients: number;
  files: number;
  genedit: { mode: 'live' | 'demo'; home: string; files: number };
  user: { name: string; plan: string; role: string };
}

export type View = 'landing' | 'auth' | 'dashboard' | 'editor' | 'media';

export const kindLabel: Record<string, string> = {
  'node-app': 'App Node.js',
  'react-app': 'App React',
  'api-service': 'API REST',
  vide: 'Projet vide',
};
