/**
 * Bridge GenEdit — NEXUS GEN HUB · Plasma
 *
 * Colle le projet GenEdit/GenHub (python3 /home/nexus/Bureau/nexus-genedit/genedit.py
 * + genhub.sh) DANS le même éditeur que GenHub. Aucun fichier n'est déplacé ni
 * modifié chez lui : on lit, on édite à la demande, on exécute à la demande.
 *
 * Résolution du dossier :
 *   1. env GENEDIT_HOME
 *   2. /home/nexus/Bureau/nexus-genedit
 *   3. ~/Bureau/nexus-genedit
 *   4. sinon → mode démo (sandbox), arborescence virtuelle réaliste
 */

import fs from 'fs';
import path from 'path';
import os from 'os';
import { execFile } from 'child_process';

const CANDIDATES = [
  process.env.GENEDIT_HOME,
  '/home/nexus/Bureau/nexus-genedit',
  path.join(os.homedir(), 'Bureau', 'nexus-genedit'),
  path.join(os.homedir(), 'Desktop', 'nexus-genedit'),
].filter(Boolean) as string[];

export interface GeneditStatus {
  mode: 'live' | 'demo';
  home: string;
  entryPy: string | null; // genedit.py
  launcherSh: string | null; // genhub.sh
  files: { path: string; size: number; isDir: boolean }[];
}

const DEMO_FILES: { path: string; size: number; isDir: boolean }[] = [
  { path: 'genedit.py', size: 4821, isDir: false },
  { path: 'genhub.sh', size: 512, isDir: false },
  { path: 'core/', size: 0, isDir: true },
  { path: 'core/engine.py', size: 2140, isDir: false },
  { path: 'core/templates.py', size: 1833, isDir: false },
  { path: 'outputs/', size: 0, isDir: true },
  { path: 'README.md', size: 980, isDir: false },
];

export function geneditHome(): string | null {
  for (const c of CANDIDATES) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isDirectory()) return c;
    } catch {
      /* ignore */
    }
  }
  return null;
}

function listDirSafe(root: string, depth = 0, prefix = '', out: { path: string; size: number; isDir: boolean }[] = []) {
  if (depth > 2 || out.length > 200) return out;
  let entries: fs.Dirent[] = [];
  try {
    entries = fs.readdirSync(root, { withFileTypes: true });
  } catch {
    return out;
  }
  for (const e of entries) {
    if (e.name.startsWith('.') || e.name === 'node_modules' || e.name === '__pycache__') continue;
    const rel = prefix ? `${prefix}/${e.name}` : e.name;
    if (e.isDirectory()) {
      out.push({ path: rel + '/', size: 0, isDir: true });
      listDirSafe(path.join(root, e.name), depth + 1, rel, out);
    } else {
      try {
        out.push({ path: rel, size: fs.statSync(path.join(root, e.name)).size, isDir: false });
      } catch {
        out.push({ path: rel, size: 0, isDir: false });
      }
    }
  }
  return out;
}

export function geneditStatus(): GeneditStatus {
  const home = geneditHome();
  if (!home) {
    return {
      mode: 'demo',
      home: '/home/nexus/Bureau/nexus-genedit (démonstration)',
      entryPy: 'genedit.py',
      launcherSh: 'genhub.sh',
      files: DEMO_FILES,
    };
  }
  const files = listDirSafe(home);
  const has = (n: string) => files.some((f) => f.path === n);
  return {
    mode: 'live',
    home,
    entryPy: has('genedit.py') ? path.join(home, 'genedit.py') : null,
    launcherSh: has('genhub.sh') ? path.join(home, 'genhub.sh') : null,
    files,
  };
}

/** Lecture sûre (anti path-traversal) d'un fichier du dossier GenEdit. */
export function geneditRead(relPath: string): { ok: boolean; content?: string; error?: string } {
  const home = geneditHome();
  if (!home) {
    const demo = DEMO_CONTENT[relPath];
    if (demo !== undefined) return { ok: true, content: demo };
    return { ok: false, error: `Fichier « ${relPath} » introuvable (mode démo).` };
  }
  const abs = path.resolve(home, relPath);
  if (!abs.startsWith(path.resolve(home))) return { ok: false, error: 'Chemin interdit' };
  try {
    if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) return { ok: false, error: 'Fichier introuvable' };
    const stat = fs.statSync(abs);
    if (stat.size > 2_000_000) return { ok: false, error: 'Fichier trop volumineux (>2 Mo)' };
    return { ok: true, content: fs.readFileSync(abs, 'utf8') };
  } catch (e) {
    return { ok: false, error: (e as Error).message };
  }
}

/** Écriture sûre dans le dossier GenEdit (uniquement fichiers texte < 2 Mo). */
export function geneditWrite(relPath: string, content: string): { ok: boolean; error?: string } {
  const home = geneditHome();
  if (!home) return { ok: false, error: "Mode démo : écriture désactivée (le bridge sera actif sur votre machine via l'installateur)." };
  const abs = path.resolve(home, relPath);
  if (!abs.startsWith(path.resolve(home))) return { ok: false, error: 'Chemin interdit' };
  if (content.length > 2_000_000) return { ok: false, error: 'Contenu trop volumineux (>2 Mo)' };
  try {
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, content, 'utf8');
    return { ok: true };
  } catch (e) {
    return { ok: false, error: (e as Error).message };
  }
}

export interface RunResult {
  ok: boolean;
  command: string;
  output: string;
  status: 'ok' | 'error' | 'timeout';
  durationMs: number;
}

function runCmd(cmd: string, args: string[], cwd: string, timeoutMs = 30000): Promise<RunResult> {
  return new Promise((resolve) => {
    const t0 = Date.now();
    execFile(
      cmd,
      args,
      { cwd, timeout: timeoutMs, maxBuffer: 4_000_000, env: { ...process.env, TERM: 'dumb' } },
      (err, stdout, stderr) => {
        const durationMs = Date.now() - t0;
        const timedOut = (err as NodeJS.ErrnoException | null)?.killed === true;
        const output = [stdout?.toString(), stderr?.toString()].filter(Boolean).join('\n').slice(-20000);
        if (timedOut) resolve({ ok: false, command: `${cmd} ${args.join(' ')}`, output: output + '\n⏱ timeout', status: 'timeout', durationMs });
        else resolve({ ok: !err, command: `${cmd} ${args.join(' ')}`, output: output || '(aucune sortie)', status: err ? 'error' : 'ok', durationMs });
      }
    );
  });
}

/** python3 genedit.py [args...] — exécution réelle sur la machine. */
export async function geneditRun(args: string[] = []): Promise<RunResult> {
  const home = geneditHome();
  if (!home) {
    return {
      ok: true,
      command: `python3 genedit.py ${args.join(' ')}`.trim() + '  (démonstration)',
      output: [
        '◆ NEXUS GenEdit — moteur de génération (mode démo sandbox)',
        '',
        `> python3 genedit.py ${args.join(' ')}`.trim(),
        '',
        '[genedit] Initialisation du moteur…',
        '[genedit] Templates chargés : 12',
        `[genedit] Tâche reçue : ${args.join(' ') || '(aucune)'} `,
        '[genedit] ✔ Génération terminée en 0.42s — sortie : outputs/',
        '',
        "→ Sur votre machine (installateur NEXUS), cette commande exécute le VRAI genedit.py",
        '  de /home/nexus/Bureau/nexus-genedit et affiche sa sortie réelle ici.',
      ].join('\n'),
      status: 'ok',
      durationMs: 420,
    };
  }
  const py = path.join(home, 'genedit.py');
  if (!fs.existsSync(py)) {
    return { ok: false, command: `python3 genedit.py`, output: `genedit.py introuvable dans ${home}`, status: 'error', durationMs: 0 };
  }
  return runCmd('python3', ['genedit.py', ...args], home);
}

/** bash genhub.sh — lance le groupe GenHub. */
export async function genhubRun(): Promise<RunResult> {
  const home = geneditHome();
  if (!home) {
    return {
      ok: true,
      command: 'bash genhub.sh  (démonstration)',
      output: [
        '◆ GenHub — groupe de services (mode démo sandbox)',
        '',
        '[genhub] 1/2 python3 genedit.py  → prêt',
        '[genhub] 2/2 genhub.sh           → prêt',
        '[genhub] ✔ Groupe GenHub démarré',
        '',
        "→ Sur votre machine, genhub.sh est exécuté réellement (bash) et sa sortie s'affiche ici.",
      ].join('\n'),
      status: 'ok',
      durationMs: 300,
    };
  }
  const sh = path.join(home, 'genhub.sh');
  if (!fs.existsSync(sh)) {
    return { ok: false, command: 'bash genhub.sh', output: `genhub.sh introuvable dans ${home}`, status: 'error', durationMs: 0 };
  }
  return runCmd('bash', ['genhub.sh'], home, 15000);
}

/** Contenu de démonstration (sandbox) — reflète la structure réelle attendue. */
const DEMO_CONTENT: Record<string, string> = {
  'genedit.py': `#!/usr/bin/env python3
"""NEXUS GenEdit — moteur de génération (aperçu en mode démo)."""
import sys
from core.engine import Engine

def main():
    task = " ".join(sys.argv[1:]) or "default"
    engine = Engine()
    result = engine.generate(task)
    print(f"[genedit] ✔ {result}")

if __name__ == "__main__":
    main()
`,
  'genhub.sh': `#!/usr/bin/env bash
# GenHub — lance le groupe GenEdit + services
set -euo pipefail
cd "$(dirname "$0")"
echo "[genhub] démarrage du groupe…"
python3 genedit.py serve &
echo "[genhub] ✔ groupe prêt"
`,
  'README.md': `# NEXUS GenEdit / GenHub

Moteur de génération Python, relié à **NEXUS GEN HUB · Plasma**
via le bridge intégré (même éditeur, exécution directe).
`,
};
