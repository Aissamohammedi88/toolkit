/**
 * NEXUS GEN HUB · Plasma — Moteur de génération LOCAL (offline).
 *
 * Garantie produit : l'application génère du code / README / visuels
 * même quand AUCUNE API externe n'est disponible (pas d'internet,
 * pas de clé). Ce moteur est 100% local, déterministe et produit du
 * code de production réel (Node.js, React, API REST, README pro).
 */

export type GenMode = 'code' | 'readme' | 'chat' | 'image';
export interface LocalResult {
  text?: string;
  language?: string;
  filename?: string;
  svg?: string;
  provider: string;
  note: string;
}

function slug(s: string): string {
  return (
    s
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 40) || 'projet'
  );
}

function pascal(s: string): string {
  const parts = slug(s).split('-').filter(Boolean);
  return parts.map((p) => p[0].toUpperCase() + p.slice(1)).join('') || 'Module';
}

// ---------------------------------------------------------------- README ---

export function localReadme(topic: string, author = 'NEXUS'): LocalResult {
  const name = slug(topic);
  const Title = topic.trim().slice(0, 60) || 'Projet NEXUS';
  const text = `# ${Title}

![status](https://img.shields.io/badge/status-production-brightgreen) ![license](https://img.shields.io/badge/license-MIT-blue) ![node](https://img.shields.io/badge/node-%E2%89%A518.x-brightgreen)

> ${Title} — généré par **NEXUS GEN HUB · Plasma**, le studio de création
> code + visuels + vidéo. Auteur : ${author}.

## 🚀 Démarrage rapide

\`\`\`bash
# 1. Installer les dépendances
npm install

# 2. Lancer en développement
npm run dev

# 3. Compiler pour la production
npm run build && npm start
\`\`\`

## 📁 Structure du projet

\`\`\`
${name}/
├── package.json        # Dépendances et scripts
├── README.md           # Ce fichier
├── src/
│   ├── index.js        # Point d'entrée
│   ├── server.js       # Serveur HTTP
│   └── routes/         # Routes API
├── public/             # Assets statiques
└── tests/              # Tests automatisés
\`\`\`

## ✨ Fonctionnalités

- **Production-ready** : gestion d'erreurs, logs structurés, arrêt propre (SIGTERM/SIGINT).
- **Zéro dépendance lourde** : cœur en \`node:http\`, fonctionne sans \`npm install\`.
- **API REST JSON** : endpoints \`/api/health\`, \`/api/stats\`.
- **Extensible** : ajoutez une route en 5 lignes dans \`src/routes/\`.

## 🔌 API

| Méthode | Endpoint      | Description                     |
| ------- | ------------- | ------------------------------- |
| GET     | \`/api/health\` | État du service (uptime, version) |
| GET     | \`/api/stats\`  | Statistiques mémoire + requêtes  |
| GET     | \`/*\`          | Fichiers statiques de \`public/\`  |

### Exemple

\`\`\`bash
curl http://localhost:3000/api/health
# {"status":"ok","uptime":12.4,"version":"1.0.0"}
\`\`\`

## 🧪 Tests

\`\`\`bash
npm test
\`\`\`

## 📄 Licence

MIT — ${new Date().getFullYear()} © ${author}
`;
  return {
    text,
    language: 'markdown',
    filename: 'README.md',
    provider: 'moteur-local-nexus',
    note: 'README complet généré en local (aucune API nécessaire).',
  };
}

// ------------------------------------------------------------------ CODE ---

export function localCode(prompt: string): LocalResult {
  const p = prompt.toLowerCase();
  const Name = pascal(prompt);

  // --- Détection d'intention : serveur / API ---
  if (/\b(serveur|server|api|apis|backend|rest|endpoint|endpoints|route|routes)\b/.test(p)) {
    const text = `/**
 * ${Name} — Serveur API REST (Node.js, zéro dépendance).
 * Généré par NEXUS GEN HUB · Plasma (moteur local).
 * Lancer : node ${slug(prompt)}.js   puis   curl localhost:3000/api/health
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const PORT = process.env.PORT || 3000;
const startedAt = Date.now();
let requests = 0;

const routes = {
  'GET /api/health': () => ({
    status: 'ok',
    uptime: ((Date.now() - startedAt) / 1000).toFixed(1) + 's',
    requests,
    version: '1.0.0',
  }),
  'GET /api/stats': () => ({
    requests,
    memoryMB: (process.memoryUsage().rss / 1048576).toFixed(1),
    pid: process.pid,
    node: process.version,
  }),
};

function send(res, code, data) {
  const body = JSON.stringify(data, null, 2);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(body);
}

const server = http.createServer((req, res) => {
  requests++;
  const key = \`\${req.method} \${req.url.split('?')[0]}\`;
  try {
    if (routes[key]) return send(res, 200, routes[key]());

    // Fichiers statiques depuis ./public
    const file = path.join(__dirname, 'public', req.url === '/' ? 'index.html' : req.url);
    if (file.startsWith(path.join(__dirname, 'public')) && fs.existsSync(file)) {
      const ext = path.extname(file);
      const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml' };
      res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' });
      return fs.createReadStream(file).pipe(res);
    }
    return send(res, 404, { error: 'Route inconnue', tried: key });
  } catch (err) {
    return send(res, 500, { error: err.message });
  }
});

// Arrêt propre (Docker / systemd)
for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => server.close(() => process.exit(0)));
}

server.listen(PORT, () => console.log(\`✅ ${Name} en ligne sur http://localhost:\${PORT}\`));
`;
    return {
      text,
      language: 'javascript',
      filename: `${slug(prompt)}.js`,
      provider: 'moteur-local-nexus',
      note: 'Serveur API complet, exécutable immédiatement (node).',
    };
  }

  // --- Détection d'intention : composant React ---
  if (/\b(react|composant|component|bouton|button|card|carte|formulaire|form|hero|interface|ui)\b/.test(p)) {
    const text = `/**
 * ${Name} — Composant React (TSX, production).
 * Généré par NEXUS GEN HUB · Plasma (moteur local).
 */
import { useState } from 'react';

interface ${Name}Props {
  title: string;
  items?: string[];
  onSelect?: (item: string) => void;
}

export function ${Name}({ title, items = [], onSelect }: ${Name}Props) {
  const [active, setActive] = useState<string | null>(null);

  return (
    <section
      aria-label={title}
      className="w-full max-w-xl rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm dark:border-zinc-800 dark:bg-zinc-950"
    >
      <h2 className="text-xl font-semibold tracking-tight text-zinc-900 dark:text-zinc-50">
        {title}
      </h2>

      {items.length === 0 ? (
        <p className="mt-3 text-sm text-zinc-500">Aucun élément pour le moment.</p>
      ) : (
        <ul className="mt-4 divide-y divide-zinc-100 dark:divide-zinc-800">
          {items.map((item) => (
            <li key={item}>
              <button
                type="button"
                onClick={() => {
                  setActive(item);
                  onSelect?.(item);
                }}
                className={
                  'flex w-full items-center justify-between py-3 text-left text-sm transition-colors ' +
                  (active === item
                    ? 'font-semibold text-violet-600 dark:text-violet-400'
                    : 'text-zinc-700 hover:text-zinc-900 dark:text-zinc-300')
                }
              >
                {item}
                <span aria-hidden>→</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

export default ${Name};
`;
    return {
      text,
      language: 'typescript',
      filename: `${Name}.tsx`,
      provider: 'moteur-local-nexus',
      note: 'Composant React typé, accessible et responsive.',
    };
  }

  // --- Détection d'intention : script / scraping / fichier ---
  if (/\b(script|automatisation|automatise|batch|fichier|fichiers|file|files|json|csv|convertir|conversion|renomme|renommage|liste|lister|scan|scanner|dossier)\b/.test(p)) {
    const text = `#!/usr/bin/env node
/**
 * ${Name} — Script CLI (Node.js).
 * Généré par NEXUS GEN HUB · Plasma (moteur local).
 * Usage : node ${slug(prompt)}.js <dossier>
 */
const fs = require('node:fs');
const path = require('node:path');

const target = process.argv[2] || '.';
const DRY = process.argv.includes('--dry');

function walk(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, out);
    else out.push(full);
  }
  return out;
}

const files = walk(target);
const report = { scanned: files.length, totalBytes: 0, byExt: {} };

for (const f of files) {
  const size = fs.statSync(f).size;
  const ext = path.extname(f) || '(sans extension)';
  report.totalBytes += size;
  report.byExt[ext] = (report.byExt[ext] || 0) + 1;
}

console.log('── Rapport ${Name} ' + '─'.repeat(30));
console.log(\`Dossier   : \${path.resolve(target)}\`);
console.log(\`Fichiers  : \${report.scanned}\`);
console.log(\`Taille    : \${(report.totalBytes / 1048576).toFixed(2)} Mo\`);
console.log('Par type  :', report.byExt);

if (DRY) console.log('(mode --dry : aucune modification écrite)');
`;
    return {
      text,
      language: 'javascript',
      filename: `${slug(prompt)}.js`,
      provider: 'moteur-local-nexus',
      note: 'Script CLI réel avec rapport et mode --dry.',
    };
  }

  // --- Par défaut : module utilitaire ---
  const text = `/**
 * ${Name} — Module utilitaire (Node.js, production).
 * Généré par NEXUS GEN HUB · Plasma (moteur local).
 */
class ${Name} {
  constructor(options = {}) {
    this.options = { retries: 3, timeoutMs: 5000, verbose: false, ...options };
    this.startedAt = Date.now();
  }

  /** Valide une entrée et lève une erreur claire. */
  validate(input) {
    if (input === null || input === undefined) {
      throw new Error('[${Name}] entrée requise');
    }
    return input;
  }

  /** Exécute une tâche avec retries exponentiels. */
  async run(task) {
    let lastError;
    for (let attempt = 1; attempt <= this.options.retries; attempt++) {
      try {
        const result = await Promise.race([
          Promise.resolve(task()),
          new Promise((_, rej) =>
            setTimeout(() => rej(new Error('timeout')), this.options.timeoutMs)
          ),
        ]);
        if (this.options.verbose) {
          console.log(\`[${Name}] OK en \${attempt} tentative(s)\`);
        }
        return result;
      } catch (err) {
        lastError = err;
        await new Promise((r) => setTimeout(r, 2 ** attempt * 100));
      }
    }
    throw new Error(\`[${Name}] échec après \${this.options.retries} tentatives: \${lastError.message}\`);
  }

  uptime() {
    return ((Date.now() - this.startedAt) / 1000).toFixed(1) + 's';
  }
}

module.exports = { ${Name} };

// Auto-test : node ${slug(prompt)}.js
if (require.main === module) {
  const inst = new ${Name}({ verbose: true });
  inst
    .run(() => ({ ok: true, at: new Date().toISOString() }))
    .then((r) => console.log('✅', r, '— uptime', inst.uptime()))
    .catch((e) => { console.error('❌', e.message); process.exit(1); });
}
`;
  return {
    text,
    language: 'javascript',
    filename: `${slug(prompt)}.js`,
    provider: 'moteur-local-nexus',
    note: 'Module utilitaire avec retries, timeout et auto-test.',
  };
}

// ------------------------------------------------------------------ CHAT ---

export function localChat(messages: { role: string; content: string }[]): LocalResult {
  const last = (messages[messages.length - 1]?.content || '').toLowerCase();
  let text: string;
  if (/(bonjour|salut|hello|hey)/.test(last)) {
    text = `Bonjour 👋 Je suis **NEXUS Plasma**, l'assistant intégré de GenHub.\n\nJe fonctionne actuellement via le **moteur local** (aucune API externe nécessaire). Je peux :\n\n1. **Générer du code** — serveurs Node.js, composants React, scripts CLI ;\n2. **Rédiger un README** professionnel pour votre projet ;\n3. **Créer des visuels** (art plasma procédural) ;\n4. **Générer une app complète** prête à exporter en ZIP.\n\nDites simplement par exemple : « génère un serveur API pour clients » ou « écris un README pour mon studio ».`;
  } else if (/(comment|aide|help|fonctionne|peux)/.test(last)) {
    text = `Voici comment tirer le meilleur de **NEXUS GEN HUB · Plasma** :\n\n- **Éditeur unifié** : vos fichiers GenHub **et** votre dossier \`nexus-genedit\` dans le même éditeur, avec lancement de \`genedit.py\` intégré.\n- **Génération** : panneau IA à droite → mode *Code*, *README*, *Visuel* ou *Chat*. La chaîne de fournisseurs essaie les APIs gratuites (Pollinations) puis bascule automatiquement sur le **moteur local** si le réseau est absent.\n- **Exécution** : bouton *Exécuter* pour compiler/lancer votre code et voir la sortie dans le terminal intégré.\n- **Export** : bouton *Exporter ZIP* pour récupérer tout le projet compilé, prêt à livrer.\n\nConseil pro : décrivez le résultat voulu (« une API avec 2 routes », « une landing sombre style Vercel »), pas le code à écrire.`;
  } else {
    text = `**Moteur local actif** — je génère sans aucune API externe.\n\nPour votre demande « ${messages[messages.length - 1]?.content.slice(0, 80) || '…'} » :\n\n1. Ouvrez le panneau **Générer** (à droite de l'éditeur) et choisissez le mode *Code* ;\n2. Je produis un fichier complet, testé, prêt à exécuter ;\n3. Cliquez **Insérer** pour l'ajouter au projet, puis **Exécuter**.\n\nSi les APIs gratuites sont joignables, le badge fournisseur passera de « moteur-local-nexus » à « pollinations » automatiquement — aucune configuration nécessaire.`;
  }
  return { text, provider: 'moteur-local-nexus', note: 'Réponse du moteur local.' };
}

// ----------------------------------------------------------------- IMAGE ---

let svgSeed = 42;
function rnd(): number {
  svgSeed = (svgSeed * 1103515245 + 12345) % 2147483648;
  return svgSeed / 2147483648;
}

export function localImage(prompt: string): LocalResult {
  svgSeed = [...prompt].reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 2147483647, 7) + 11;
  const W = 960;
  const H = 540;
  const hues = [265, 285, 315, 200, 340];
  const base = hues[Math.floor(rnd() * hues.length)];
  const layers: string[] = [];
  const N = 7;
  for (let i = 0; i < N; i++) {
    const y = 90 + i * 60 + rnd() * 40;
    const amp = 30 + rnd() * 70;
    const freq = 1.2 + rnd() * 2.5;
    const phase = rnd() * Math.PI * 2;
    const hue = (base + i * 9) % 360;
    const op = 0.16 + rnd() * 0.3;
    let d = `M0 ${H}`;
    for (let x = 0; x <= W; x += 16) {
      const yy = y + Math.sin((x / W) * Math.PI * 2 * freq + phase) * amp;
      d += ` L${x} ${yy.toFixed(1)}`;
    }
    d += ` L${W} ${H} Z`;
    layers.push(`<path d="${d}" fill="hsl(${hue} 90% ${45 + i * 4}%)" opacity="${op.toFixed(2)}"/>`);
  }
  const orbs: string[] = [];
  for (let i = 0; i < 5; i++) {
    const cx = rnd() * W;
    const cy = rnd() * H * 0.7;
    const r = 40 + rnd() * 120;
    const hue = (base + 60 + i * 25) % 360;
    orbs.push(`<circle cx="${cx.toFixed(0)}" cy="${cy.toFixed(0)}" r="${r.toFixed(0)}" fill="url(#g${i % 2})" opacity="0.5"/>`);
  }
  const label = prompt.trim().slice(0, 58).replace(/[<>&]/g, '');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-label="${label}">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="hsl(${base} 60% 8%)"/>
      <stop offset="1" stop-color="hsl(${(base + 40) % 360} 70% 14%)"/>
    </linearGradient>
    <radialGradient id="g0"><stop offset="0" stop-color="hsl(${base} 95% 60%)" stop-opacity="0.9"/><stop offset="1" stop-color="hsl(${base} 95% 60%)" stop-opacity="0"/></radialGradient>
    <radialGradient id="g1"><stop offset="0" stop-color="hsl(${(base + 80) % 360} 95% 62%)" stop-opacity="0.85"/><stop offset="1" stop-color="hsl(${(base + 80) % 360} 95% 62%)" stop-opacity="0"/></radialGradient>
    <filter id="blur"><feGaussianBlur stdDeviation="2"/></filter>
  </defs>
  <rect width="${W}" height="${H}" fill="url(#bg)"/>
  <g filter="url(#blur)">${orbs.join('\n  ')}
  ${layers.join('\n  ')}</g>
  <rect width="${W}" height="${H}" fill="none" stroke="hsl(${base} 80% 55%)" stroke-opacity="0.35"/>
  <text x="32" y="${H - 28}" font-family="ui-monospace, monospace" font-size="15" fill="hsl(${base} 90% 80%)" opacity="0.85">◆ NEXUS PLASMA · ${label}</text>
</svg>`;
  return {
    svg,
    provider: 'moteur-local-nexus',
    note: 'Visuel plasma généré en local (SVG vectoriel, aucune API).',
  };
}

export function localGenerate(mode: GenMode, prompt: string, messages?: { role: string; content: string }[]): LocalResult {
  switch (mode) {
    case 'readme':
      return localReadme(prompt);
    case 'image':
      return localImage(prompt);
    case 'chat':
      return localChat(messages || [{ role: 'user', content: prompt }]);
    case 'code':
    default:
      return localCode(prompt);
  }
}
