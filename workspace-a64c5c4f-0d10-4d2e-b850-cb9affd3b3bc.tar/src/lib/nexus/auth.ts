import { scryptSync, randomBytes, timingSafeEqual, createHash } from 'crypto';
import { db } from '@/lib/db';
import { cookies } from 'next/headers';

const SESSION_COOKIE = 'nexus_session';
const SESSION_DAYS = 30;

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [salt, hash] = stored.split(':');
    if (!salt || !hash) return false;
    const candidate = scryptSync(password, salt, 64);
    const expected = Buffer.from(hash, 'hex');
    return candidate.length === expected.length && timingSafeEqual(candidate, expected);
  } catch {
    return false;
  }
}

export function newSessionId(): string {
  return createHash('sha256')
    .update(randomBytes(32))
    .update(Date.now().toString())
    .digest('hex');
}

export async function createSession(userId: string): Promise<string> {
  const id = newSessionId();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 3600 * 1000);
  await db.session.create({ data: { id, userId, expiresAt } });
  const jar = await cookies();
  jar.set(SESSION_COOKIE, id, {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    expires: expiresAt,
  });
  return id;
}

export async function destroySession(): Promise<void> {
  const jar = await cookies();
  const id = jar.get(SESSION_COOKIE)?.value;
  if (id) {
    await db.session.deleteMany({ where: { id } });
    jar.delete(SESSION_COOKIE);
  }
}

export async function currentUser() {
  try {
    const jar = await cookies();
    const id = jar.get(SESSION_COOKIE)?.value;
    if (!id) return null;
    const session = await db.session.findUnique({
      where: { id },
      include: { user: true },
    });
    if (!session) return null;
    if (session.expiresAt.getTime() < Date.now()) {
      await db.session.deleteMany({ where: { id } });
      return null;
    }
    const { passwordHash: _ignored, ...user } = session.user;
    void _ignored;
    return user;
  } catch {
    return null;
  }
}

export function publicUser(u: { id: string; email: string; name: string; plan: string; role: string; createdAt: Date }) {
  return {
    id: u.id,
    email: u.email,
    name: u.name,
    plan: u.plan,
    role: u.role,
    createdAt: u.createdAt,
  };
}
