/**
 * Chaîne de fournisseurs génératifs — NEXUS GEN HUB · Plasma
 *
 * Ordre de bascule automatique ("fallback chain") :
 *   1. pollinations-text  — API gratuite SANS clé (https://text.pollinations.ai)
 *   2. moteur-local-nexus — moteur 100% local, TOUJOURS disponible
 *
 * → L'app génère donc même sans internet et sans clé API.
 */

import { localGenerate, GenMode, LocalResult } from './localEngine';

const POLL_TEXT_ENDPOINT = 'https://text.pollinations.ai/openai';
const TIMEOUT_MS = 20000;

export interface GenResponse {
  mode: GenMode;
  prompt: string;
  provider: string;      // 'pollinations-text' | 'moteur-local-nexus'
  fallbackChain: string[]; // fournisseurs essayés
  text?: string;
  svg?: string;
  language?: string;
  filename?: string;
  note: string;
}

async function fetchWithTimeout(url: string, init: RequestInit, ms: number): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

/** Appel Pollinations (OpenAI-compatible, sans clé). Retourne null si indisponible. */
async function pollinationsText(
  mode: GenMode,
  prompt: string,
  messages: { role: string; content: string }[]
): Promise<LocalResult | null> {
  const systemByMode: Record<GenMode, string> = {
    code: "Tu es un ingénieur logiciel senior. Réponds UNIQUEMENT avec le code complet final, dans un bloc markdown ```langage. Code de production : typé, commenté, gestion d'erreurs, prêt à exécuter. Pas de placeholders TODO.",
    readme:
      'Tu es un rédacteur technique senior. Produis un README.md complet et professionnel en français (badges, démarrage rapide, structure, API, licence) en markdown brut.',
    chat: 'Tu es NEXUS Plasma, assistant produit concis et expert, tu réponds en français, en markdown court et actionnable.',
    image: '',
  };
  if (mode === 'image') return null; // les images passent par un endpoint dédié

  try {
    const res = await fetchWithTimeout(
      POLL_TEXT_ENDPOINT,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'openai',
          messages: [{ role: 'system', content: systemByMode[mode] }, ...messages],
          temperature: mode === 'code' ? 0.3 : 0.7,
        }),
      },
      TIMEOUT_MS
    );
    if (!res.ok) return null;
    const raw = (await res.text()).trim();
    if (!raw || raw.length < 8) return null;
    // L'endpoint peut renvoyer du JSON OpenAI ou directement du texte.
    let text = raw;
    try {
      const j = JSON.parse(raw);
      text = j?.choices?.[0]?.message?.content || raw;
    } catch {
      /* texte brut */
    }
    if (!text || text.length < 8) return null;

    let language: string | undefined;
    let filename: string | undefined;
    if (mode === 'code') {
      const m = text.match(/```(\w+)?/);
      language = m?.[1] || 'javascript';
      filename = undefined;
    }
    return { text, language, provider: 'pollinations-text', note: 'Généré via API gratuite Pollinations (sans clé).' };
  } catch {
    return null;
  }
}

export async function generate(
  mode: GenMode,
  prompt: string,
  messages?: { role: string; content: string }[]
): Promise<GenResponse> {
  const chain: string[] = [];

  // 1) Fournisseur gratuit sans clé
  if (mode !== 'image') {
    chain.push('pollinations-text');
    const remote = await pollinationsText(mode, prompt, messages?.length ? messages : [{ role: 'user', content: prompt }]);
    if (remote) {
      return { mode, prompt, provider: remote.provider, fallbackChain: chain, text: remote.text, language: remote.language, filename: remote.filename, note: remote.note };
    }
  }

  // 2) Moteur local — toujours disponible
  chain.push('moteur-local-nexus');
  const local = localGenerate(mode, prompt, messages);
  return {
    mode,
    prompt,
    provider: local.provider,
    fallbackChain: chain,
    text: local.text,
    svg: local.svg,
    language: local.language,
    filename: local.filename,
    note: local.note,
  };
}

/** Image : URL Pollinations (gratuite, sans clé) ou SVG local. */
export function imageUrlFor(prompt: string): string {
  return `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=960&height=540&nologo=true&seed=${Math.floor(Math.random() * 99999)}`;
}
