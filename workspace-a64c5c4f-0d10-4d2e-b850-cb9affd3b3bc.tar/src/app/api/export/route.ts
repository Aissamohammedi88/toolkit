import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { currentUser } from '@/lib/nexus/auth';
import JSZip from 'jszip';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/export { projectId } — compile le projet en archive ZIP
 * prête à livrer (code extrait, structuré, avec README).
 */
export async function POST(req: NextRequest) {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

  const body = (await req.json().catch(() => null)) as { projectId?: string } | null;
  const projectId = body?.projectId || '';
  const project = await db.project.findUnique({ where: { id: projectId } });
  if (!project || project.userId !== user.id) return NextResponse.json({ error: 'Projet introuvable.' }, { status: 404 });

  const files = await db.fileEntry.findMany({ where: { projectId } });
  if (files.length === 0) return NextResponse.json({ error: 'Projet vide — rien à exporter.' }, { status: 400 });

  const zip = new JSZip();
  const root = zip.folder(project.name.replace(/[^a-zA-Z0-9._-]/g, '_')) || zip;
  for (const f of files) {
    root.file(f.path, f.content);
  }
  root.file(
    'NEXUS-EXPORT.txt',
    [
      `Projet   : ${project.name}`,
      `Type     : ${project.kind}`,
      `Fichiers : ${files.length}`,
      `Export   : ${new Date().toISOString()}`,
      `Studio   : NEXUS GEN HUB · Plasma`,
      '',
      'Ce code est extrait et prêt pour : npm install && npm run dev',
    ].join('\n')
  );

  const buf = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
  return new NextResponse(new Uint8Array(buf), {
    headers: {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="${project.name.replace(/[^a-zA-Z0-9._-]/g, '_')}.zip"`,
      'Content-Length': String(buf.length),
    },
  });
}
