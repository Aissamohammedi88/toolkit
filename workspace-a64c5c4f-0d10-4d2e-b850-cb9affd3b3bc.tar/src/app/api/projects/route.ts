import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { currentUser } from '@/lib/nexus/auth';
import { scaffold } from '@/lib/nexus/scaffolds';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/projects → projets de l'utilisateur */
export async function GET() {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
  const projects = await db.project.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: 'desc' },
    include: { _count: { select: { files: true } } },
  });
  return NextResponse.json({
    projects: projects.map((p) => ({
      id: p.id,
      name: p.name,
      kind: p.kind,
      description: p.description,
      framework: p.framework,
      files: p._count.files,
      createdAt: p.createdAt,
      updatedAt: p.updatedAt,
    })),
  });
}

/** POST /api/projects { name, kind } → crée le projet + scaffold complet */
export async function POST(req: NextRequest) {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

  let body: { name?: string; kind?: string; description?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'JSON invalide' }, { status: 400 });
  }

  const name = (body.name || '').trim().slice(0, 60) || 'Nouveau projet';
  const kind = (['node-app', 'react-app', 'api-service', 'vide'].includes(body.kind || '') ? body.kind : 'node-app') as string;

  try {
    const files = kind === 'vide' ? [] : scaffold(kind as 'node-app' | 'react-app' | 'api-service', name);
    const project = await db.project.create({
      data: {
        userId: user.id,
        name,
        kind,
        description: body.description?.slice(0, 200) || '',
        framework: kind === 'react-app' ? 'react' : 'node',
        files: { create: files.map((f) => ({ path: f.path, content: f.content })) },
      },
    });
    return NextResponse.json({ ok: true, id: project.id, filesCreated: files.length }, { status: 201 });
  } catch (e) {
    console.error('[projects:POST]', e);
    return NextResponse.json({ error: 'Création impossible.' }, { status: 500 });
  }
}
