import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { currentUser } from '@/lib/nexus/auth';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

async function ownProject(projectId: string) {
  const user = await currentUser();
  if (!user) return { error: 'Non authentifié' as const, status: 401 as const };
  const project = await db.project.findUnique({ where: { id: projectId } });
  if (!project || project.userId !== user.id) return { error: 'Projet introuvable' as const, status: 404 as const };
  return { project, user };
}

/** GET /api/projects/:id → projet + fichiers */
export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const own = await ownProject(id);
  if ('error' in own) return NextResponse.json({ error: own.error }, { status: own.status });
  const files = await db.fileEntry.findMany({
    where: { projectId: id },
    orderBy: { path: 'asc' },
    select: { path: true, content: true, updatedAt: true },
  });
  return NextResponse.json({ project: own.project, files });
}

/** PUT /api/projects/:id → maj métadonnées (nom, description) */
export async function PUT(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const own = await ownProject(id);
  if ('error' in own) return NextResponse.json({ error: own.error }, { status: own.status });
  const body = (await req.json().catch(() => ({}))) as { name?: string; description?: string };
  const project = await db.project.update({
    where: { id },
    data: {
      name: body.name?.trim().slice(0, 60) || own.project.name,
      description: body.description?.slice(0, 200) ?? own.project.description,
    },
  });
  return NextResponse.json({ ok: true, project });
}

/** DELETE /api/projects/:id */
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const own = await ownProject(id);
  if ('error' in own) return NextResponse.json({ error: own.error }, { status: own.status });
  await db.project.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
