import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { currentUser } from '@/lib/nexus/auth';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

async function ownProject(projectId: string) {
  const user = await currentUser();
  if (!user) return { error: 'Non authentifié' as const, status: 401 as const };
  const project = await db.project.findUnique({ where: { id: projectId } });
  if (!project || project.userId !== user.id) return { error: 'Projet introuvable' as const, status: 404 as const };
  return { project };
}

/** POST /api/projects/:id/files { path, content } → upsert d'un fichier */
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const own = await ownProject(id);
  if ('error' in own) return NextResponse.json({ error: own.error }, { status: own.status });

  const body = (await req.json().catch(() => null)) as { path?: string; content?: string } | null;
  const path = (body?.path || '').trim();
  if (!path || path.includes('..') || path.startsWith('/') || path.length > 200) {
    return NextResponse.json({ error: 'Chemin de fichier invalide.' }, { status: 400 });
  }
  const content = (body?.content ?? '').slice(0, 500_000);

  try {
    await db.fileEntry.upsert({
      where: { projectId_path: { projectId: id, path } },
      create: { projectId: id, path, content },
      update: { content, updatedAt: new Date() },
    });
    await db.project.update({ where: { id }, data: { updatedAt: new Date() } });
    return NextResponse.json({ ok: true, path });
  } catch (e) {
    console.error('[files:POST]', e);
    return NextResponse.json({ error: 'Sauvegarde impossible.' }, { status: 500 });
  }
}

/** DELETE /api/projects/:id/files { path } */
export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const own = await ownProject(id);
  if ('error' in own) return NextResponse.json({ error: own.error }, { status: own.status });

  const body = (await req.json().catch(() => null)) as { path?: string } | null;
  const path = (body?.path || '').trim();
  if (!path) return NextResponse.json({ error: 'Chemin requis.' }, { status: 400 });

  await db.fileEntry.deleteMany({ where: { projectId: id, path } });
  return NextResponse.json({ ok: true });
}
