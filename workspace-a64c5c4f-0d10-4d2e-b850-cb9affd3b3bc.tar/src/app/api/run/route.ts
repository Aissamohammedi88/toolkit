import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { currentUser } from '@/lib/nexus/auth';
import { spawn } from 'child_process';
import fs from 'fs';
import net from 'net';
import os from 'os';
import path from 'path';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const BOOT_CHECK_MS = 4000; // un serveur qui tourne encore après 4 s = démarrage réussi

function freePort(): Promise<number> {
  return new Promise((resolve) => {
    const srv = net.createServer();
    srv.listen(0, '127.0.0.1', () => {
      const p = (srv.address() as net.AddressInfo).port;
      srv.close(() => resolve(p));
    });
  });
}

/**
 * POST /api/run { projectId, path } — "compile & exécute" le fichier
 * (node pour .js/.mjs/.cjs, python3 pour .py) dans un bac à sable temporaire.
 * Un PORT libre est injecté (process.env.PORT). Si le programme démarre un
 * serveur qui tourne encore après 4 s, il est arrêté proprement et le test
 * est déclaré RÉUSSI (smoke test de démarrage, sortie visible dans le terminal).
 */
export async function POST(req: NextRequest) {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

  const body = (await req.json().catch(() => null)) as { projectId?: string; path?: string } | null;
  const projectId = body?.projectId || '';
  const target = (body?.path || '').trim();
  if (!projectId || !target) return NextResponse.json({ error: 'projectId et path requis.' }, { status: 400 });

  const project = await db.project.findUnique({ where: { id: projectId } });
  if (!project || project.userId !== user.id) return NextResponse.json({ error: 'Projet introuvable' }, { status: 404 });

  const entry = await db.fileEntry.findUnique({ where: { projectId_path: { projectId, path: target } } });
  if (!entry) return NextResponse.json({ error: `Fichier « ${target} » introuvable.` }, { status: 404 });

  const isPy = target.endsWith('.py');
  const isJs = /\.(m?js|cjs|mts)$/.test(target);
  if (!isPy && !isJs) {
    return NextResponse.json({
      ok: false,
      status: 'error',
      command: target,
      output: `Impossible d'exécuter « ${target} » : seuls .js/.mjs/.cjs (node) et .py (python3) sont exécutables.\nAstuce : exécutez le point d'entrée (ex. src/index.js).`,
    });
  }

  // Bac à sable : matérialise tous les fichiers du projet dans /tmp
  const files = await db.fileEntry.findMany({ where: { projectId } });
  const sandboxDir = fs.mkdtempSync(path.join(os.tmpdir(), 'nexus-run-'));
  try {
    for (const f of files) {
      const abs = path.join(sandboxDir, f.path);
      if (!abs.startsWith(sandboxDir)) continue;
      fs.mkdirSync(path.dirname(abs), { recursive: true });
      fs.writeFileSync(abs, f.content, 'utf8');
    }

    const runPath = path.join(sandboxDir, target);
    if (!fs.existsSync(runPath)) {
      return NextResponse.json({ error: `Fichier « ${target} » introuvable après extraction.` }, { status: 404 });
    }

    const cmd = isPy ? 'python3' : 'node';
    const port = await freePort();

    const result = await new Promise<{ status: string; output: string; durationMs: number; command: string }>((resolve) => {
      const t0 = Date.now();
      const child = spawn(cmd, [runPath], {
        cwd: sandboxDir,
        env: { ...process.env, PORT: String(port), NODE_NO_WARNINGS: '1' },
        stdio: ['ignore', 'pipe', 'pipe'],
      });
      let out = '';
      child.stdout.on('data', (d) => (out += d.toString()));
      child.stderr.on('data', (d) => (out += d.toString()));
      let settled = false;

      const finish = (status: string, note?: string) => {
        if (settled) return;
        settled = true;
        clearTimeout(bootTimer);
        try {
          child.kill('SIGKILL');
        } catch {
          /* déjà mort */
        }
        const tail = (out || '(aucune sortie)').split('\n').slice(-120).join('\n').slice(-12000);
        resolve({
          status,
          output: note ? `${tail}\n${note}` : tail,
          durationMs: Date.now() - t0,
          command: `PORT=${port} ${cmd} ${target}`,
        });
      };

      // Serveur encore vivant après 4 s → démarrage réussi, on arrête le test.
      const bootTimer = setTimeout(() => {
        if (!settled) finish('ok', `✔ Smoke test réussi : le programme tourne (arrêté après ${BOOT_CHECK_MS / 1000} s de vérification).`);
      }, BOOT_CHECK_MS);

      child.on('error', (err) => finish('error', `Erreur de lancement : ${err.message}`));
      child.on('exit', (code) => {
        if (code === 0) finish('ok');
        else finish('error', `✖ Processus terminé avec le code ${code}.`);
      });
    });

    await db.genRun.create({
      data: {
        userId: user.id,
        label: project.name,
        command: result.command,
        output: result.output.slice(0, 12000),
        status: result.status,
        duration: result.durationMs,
        provider: 'node-python',
      },
    });

    return NextResponse.json({ ok: result.status === 'ok', ...result });
  } catch (e) {
    console.error('[run]', e);
    return NextResponse.json({ error: 'Exécution impossible.' }, { status: 500 });
  } finally {
    fs.rmSync(sandboxDir, { recursive: true, force: true });
  }
}
