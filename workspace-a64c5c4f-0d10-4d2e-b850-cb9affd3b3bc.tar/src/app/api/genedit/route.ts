import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { currentUser } from '@/lib/nexus/auth';
import { geneditStatus, geneditRead, geneditWrite, geneditRun, genhubRun } from '@/lib/nexus/genedit';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/genedit → état du bridge + arborescence nexus-genedit */
export async function GET() {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
  const status = geneditStatus();
  return NextResponse.json(status);
}

/**
 * POST /api/genedit
 * { action: 'read' | 'write' | 'run' | 'genhub', path?, content?, args? }
 */
export async function POST(req: NextRequest) {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

  const body = (await req.json().catch(() => null)) as
    | { action?: string; path?: string; content?: string; args?: string[] }
    | null;
  const action = body?.action || '';

  try {
    switch (action) {
      case 'read': {
        const r = geneditRead((body?.path || '').trim());
        if (!r.ok) return NextResponse.json({ error: r.error }, { status: 404 });
        return NextResponse.json({ ok: true, path: body?.path, content: r.content });
      }
      case 'write': {
        const r = geneditWrite((body?.path || '').trim(), (body?.content || '').slice(0, 500_000));
        if (!r.ok) return NextResponse.json({ error: r.error }, { status: 400 });
        return NextResponse.json({ ok: true });
      }
      case 'run': {
        const args = (body?.args || []).map((a) => String(a).slice(0, 200)).filter((a) => !a.startsWith('-')).slice(0, 6);
        const r = await geneditRun(args);
        await db.genRun.create({
          data: {
            userId: user.id,
            label: 'genedit.py',
            command: r.command,
            output: r.output.slice(0, 12000),
            status: r.status,
            duration: r.durationMs,
            provider: 'genedit-bridge',
          },
        });
        return NextResponse.json(r);
      }
      case 'genhub': {
        const r = await genhubRun();
        await db.genRun.create({
          data: {
            userId: user.id,
            label: 'genhub.sh',
            command: r.command,
            output: r.output.slice(0, 12000),
            status: r.status,
            duration: r.durationMs,
            provider: 'genedit-bridge',
          },
        });
        return NextResponse.json(r);
      }
      default:
        return NextResponse.json({ error: 'Action inconnue (read|write|run|genhub).' }, { status: 400 });
    }
  } catch (e) {
    console.error('[genedit]', e);
    return NextResponse.json({ error: 'Bridge GenEdit indisponible.' }, { status: 500 });
  }
}
