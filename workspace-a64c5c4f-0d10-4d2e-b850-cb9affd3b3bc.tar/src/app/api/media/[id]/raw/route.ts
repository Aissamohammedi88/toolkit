import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { currentUser } from '@/lib/nexus/auth';
import fs from 'fs';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/media/:id/raw → flux du média (image ou vidéo) */
export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await currentUser();
  if (!user) return new NextResponse('Non authentifié', { status: 401 });

  const { id } = await ctx.params;
  const media = await db.media.findUnique({ where: { id } });
  if (!media || media.userId !== user.id) return new NextResponse('Introuvable', { status: 404 });

  if (media.filePath) {
    try {
      const buf = fs.readFileSync(media.filePath);
      return new NextResponse(new Uint8Array(buf), {
        headers: {
          'Content-Type': media.mimeType,
          'Content-Length': String(buf.length),
          'Cache-Control': 'private, max-age=3600',
          'Accept-Ranges': 'bytes',
        },
      });
    } catch {
      return new NextResponse('Fichier absent', { status: 404 });
    }
  }

  if (media.data) {
    const buf = Buffer.from(media.data, 'base64');
    return new NextResponse(new Uint8Array(buf), {
      headers: {
        'Content-Type': media.mimeType,
        'Content-Length': String(buf.length),
        'Cache-Control': 'private, max-age=86400',
      },
    });
  }

  return new NextResponse('Vide', { status: 404 });
}
