import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { currentUser } from '@/lib/nexus/auth';
import { imageUrlFor } from '@/lib/nexus/providers';
import { localImage } from '@/lib/nexus/localEngine';
import path from 'path';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const MAX_VIDEO = 60 * 1024 * 1024; // 60 Mo
const MAX_IMAGE = 4 * 1024 * 1024; // 4 Mo

/** GET /api/media → bibliothèque de médias */
export async function GET() {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
  const media = await db.media.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    select: { id: true, kind: true, name: true, mimeType: true, size: true, prompt: true, provider: true, filePath: true, createdAt: true },
  });
  return NextResponse.json({ media });
}

/**
 * POST /api/media — 2 usages :
 *  1. multipart (file) → upload vidéo/image réelle
 *  2. JSON { visualPrompt } → génère un visuel (SVG plasma local) et le stocke
 */
export async function POST(req: NextRequest) {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

  const contentType = req.headers.get('content-type') || '';

  // ---- Visuel généré (JSON) ----
  if (contentType.includes('application/json')) {
    const body = (await req.json().catch(() => ({}))) as { visualPrompt?: string };
    const prompt = (body.visualPrompt || '').trim().slice(0, 300);
    if (!prompt) return NextResponse.json({ error: 'Décrivez le visuel à créer.' }, { status: 400 });
    const svg = localImage(prompt).svg || '';
    const media = await db.media.create({
      data: {
        userId: user.id,
        kind: 'image',
        name: `plasma-${Date.now()}.svg`,
        mimeType: 'image/svg+xml',
        size: Buffer.byteLength(svg),
        prompt,
        provider: 'moteur-local-nexus',
        data: Buffer.from(svg).toString('base64'),
      },
    });
    return NextResponse.json({
      ok: true,
      media: { id: media.id, kind: 'image', name: media.name, provider: media.provider },
      remoteUrl: imageUrlFor(prompt),
    }, { status: 201 });
  }

  // ---- Upload fichier (multipart) ----
  try {
    const form = await req.formData();
    const file = form.get('file') as File | null;
    const prompt = ((form.get('prompt') as string) || '').slice(0, 300);
    if (!file || typeof file === 'string') return NextResponse.json({ error: 'Aucun fichier reçu.' }, { status: 400 });

    const isVideo = file.type.startsWith('video/');
    const isImage = file.type.startsWith('image/');
    if (!isVideo && !isImage) return NextResponse.json({ error: 'Formats acceptés : vidéo ou image.' }, { status: 415 });
    const limit = isVideo ? MAX_VIDEO : MAX_IMAGE;
    if (file.size > limit) {
      return NextResponse.json({ error: `Fichier trop lourd (max ${Math.round(limit / 1048576)} Mo).` }, { status: 413 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const safeName = (file.name || 'media').replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 80);

    if (isVideo) {
      // Dossier données : relatif au processus (marche en dev ET en standalone)
      const dir = process.env.NEXUS_DATA_DIR || path.join(process.cwd(), 'db', 'media');
      await import('fs').then((fs) => fs.promises.mkdir(dir, { recursive: true }));
      const id = `v${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      const ext = (safeName.match(/\.[a-z0-9]+$/i)?.[0] || '.mp4').toLowerCase();
      const filePath = `${dir}/${id}${ext}`;
      await import('fs').then((fs) => fs.promises.writeFile(filePath, buffer));
      const media = await db.media.create({
        data: { userId: user.id, kind: 'video', name: safeName, mimeType: file.type, size: buffer.length, prompt, provider: 'upload', filePath },
      });
      return NextResponse.json({ ok: true, media: { id: media.id, kind: 'video', name: media.name } }, { status: 201 });
    }

    const media = await db.media.create({
      data: {
        userId: user.id,
        kind: 'image',
        name: safeName,
        mimeType: file.type,
        size: buffer.length,
        prompt,
        provider: 'upload',
        data: buffer.toString('base64'),
      },
    });
    return NextResponse.json({ ok: true, media: { id: media.id, kind: 'image', name: media.name } }, { status: 201 });
  } catch (e) {
    console.error('[media:POST]', e);
    return NextResponse.json({ error: 'Upload impossible.' }, { status: 500 });
  }
}

/** DELETE /api/media { id } */
export async function DELETE(req: NextRequest) {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
  const body = (await req.json().catch(() => ({}))) as { id?: string };
  if (!body.id) return NextResponse.json({ error: 'id requis.' }, { status: 400 });
  const media = await db.media.findUnique({ where: { id: body.id } });
  if (!media || media.userId !== user.id) return NextResponse.json({ error: 'Média introuvable.' }, { status: 404 });
  if (media.filePath) {
    await import('fs').then((fs) => fs.promises.unlink(media.filePath).catch(() => {}));
  }
  await db.media.delete({ where: { id: media.id } });
  return NextResponse.json({ ok: true });
}
