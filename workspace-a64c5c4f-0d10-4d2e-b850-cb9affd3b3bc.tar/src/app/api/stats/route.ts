import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { currentUser } from '@/lib/nexus/auth';
import { geneditStatus } from '@/lib/nexus/genedit';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/stats → tableau de bord (projet Vercel-like) */
export async function GET() {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });

  const [projects, media, runs, clients, files] = await Promise.all([
    db.project.count({ where: { userId: user.id } }),
    db.media.count({ where: { userId: user.id } }),
    db.genRun.count({ where: { userId: user.id } }),
    db.user.count(),
    db.fileEntry.count({ where: { project: { userId: user.id } } }),
  ]);

  const genedit = geneditStatus();

  return NextResponse.json({
    projects,
    media,
    runs,
    clients,
    files,
    genedit: { mode: genedit.mode, home: genedit.home, files: genedit.files.length },
    user: { name: user.name, plan: user.plan, role: user.role },
  });
}
