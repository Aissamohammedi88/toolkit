import { NextRequest, NextResponse } from 'next/server';
import { generate, GenMode } from '@/lib/nexus/providers';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const MODES: GenMode[] = ['code', 'readme', 'chat', 'image'];

/**
 * POST /api/ai/generate
 * { mode: 'code'|'readme'|'chat'|'image', prompt, messages? }
 * Chaîne automatique : Pollinations (gratuit, sans clé) → moteur local NEXUS.
 */
export async function POST(req: NextRequest) {
  let body: { mode?: string; prompt?: string; messages?: { role: string; content: string }[] };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'JSON invalide' }, { status: 400 });
  }

  const mode = (MODES.includes(body.mode as GenMode) ? body.mode : 'code') as GenMode;
  const prompt = (body.prompt || '').slice(0, 4000).trim();
  const messages = (body.messages || [])
    .filter((m) => m && typeof m.content === 'string')
    .slice(-12)
    .map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content.slice(0, 4000) }));

  if (mode !== 'chat' && !prompt) {
    return NextResponse.json({ error: 'Décrivez ce que vous voulez générer.' }, { status: 400 });
  }

  try {
    const result = await generate(mode, prompt || 'présentation', messages);
    return NextResponse.json(result);
  } catch (e) {
    console.error('[ai/generate]', e);
    return NextResponse.json({ error: 'Génération impossible.' }, { status: 500 });
  }
}
