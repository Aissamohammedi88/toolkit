import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { currentUser } from '@/lib/nexus/auth';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/clients → liste des inscrits (page Clients du dashboard) */
export async function GET() {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: 'Non authentifié' }, { status: 401 });
  const users = await db.user.findMany({
    orderBy: { createdAt: 'desc' },
    select: { id: true, name: true, email: true, plan: true, role: true, createdAt: true },
  });
  return NextResponse.json({ clients: users });
}
