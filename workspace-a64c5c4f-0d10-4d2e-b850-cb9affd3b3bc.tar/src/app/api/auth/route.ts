import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword, verifyPassword, createSession, destroySession, currentUser, publicUser } from '@/lib/nexus/auth';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/auth → session courante */
export async function GET() {
  const user = await currentUser();
  return NextResponse.json({ user: user ? publicUser(user) : null });
}

/** POST /api/auth { action: signup|login|logout, ... } */
export async function POST(req: NextRequest) {
  let body: { action?: string; email?: string; password?: string; name?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'JSON invalide' }, { status: 400 });
  }
  const action = body.action;

  try {
    if (action === 'logout') {
      await destroySession();
      return NextResponse.json({ ok: true });
    }

    const email = (body.email || '').trim().toLowerCase();
    const password = body.password || '';

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'Adresse e-mail invalide.' }, { status: 400 });
    }
    if (password.length < 6) {
      return NextResponse.json({ error: 'Mot de passe : 6 caractères minimum.' }, { status: 400 });
    }

    if (action === 'signup') {
      const name = (body.name || '').trim().slice(0, 60) || email.split('@')[0];
      const exists = await db.user.findUnique({ where: { email } });
      if (exists) {
        return NextResponse.json({ error: 'Ce compte existe déjà — connectez-vous.' }, { status: 409 });
      }
      const totalUsers = await db.user.count();
      const user = await db.user.create({
        data: {
          email,
          name,
          passwordHash: hashPassword(password),
          role: totalUsers === 0 ? 'owner' : 'client',
        },
      });
      await createSession(user.id);
      return NextResponse.json({ ok: true, user: publicUser(user) }, { status: 201 });
    }

    if (action === 'login') {
      const user = await db.user.findUnique({ where: { email } });
      if (!user || !verifyPassword(password, user.passwordHash)) {
        return NextResponse.json({ error: 'E-mail ou mot de passe incorrect.' }, { status: 401 });
      }
      await createSession(user.id);
      return NextResponse.json({ ok: true, user: publicUser(user) });
    }

    return NextResponse.json({ error: 'Action inconnue.' }, { status: 400 });
  } catch (e) {
    console.error('[auth]', e);
    return NextResponse.json({ error: 'Erreur serveur.' }, { status: 500 });
  }
}
