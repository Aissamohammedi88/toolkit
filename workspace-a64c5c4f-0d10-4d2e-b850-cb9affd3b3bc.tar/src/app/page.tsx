'use client';

import { useCallback, useEffect, useState } from 'react';
import Landing from '@/components/nexus/Landing';
import AuthView from '@/components/nexus/AuthView';
import Dashboard from '@/components/nexus/Dashboard';
import EditorView from '@/components/nexus/EditorView';
import type { SessionUser } from '@/components/nexus/types';

type Screen = 'landing' | 'auth' | 'dashboard' | 'editor';

export default function Home() {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [booting, setBooting] = useState(true);
  const [screen, setScreen] = useState<Screen>('landing');
  const [editorProjectId, setEditorProjectId] = useState<string>('__genedit__');

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch('/api/auth');
        const data = (await res.json()) as { user: SessionUser | null };
        if (data.user) {
          setUser(data.user);
          setScreen('dashboard');
        }
      } catch {
        /* serveur non prêt — landing */
      } finally {
        setBooting(false);
      }
    })();
  }, []);

  const logout = useCallback(async () => {
    await fetch('/api/auth', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'logout' }),
    });
    setUser(null);
    setScreen('landing');
  }, []);

  if (booting) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#09090b]">
        <div className="flex h-10 w-10 animate-pulse items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 text-sm font-black text-white">N</div>
      </div>
    );
  }

  if (screen === 'auth') {
    return (
      <AuthView
        onBack={() => setScreen('landing')}
        onAuthenticated={(u) => {
          setUser(u);
          setScreen('dashboard');
        }}
      />
    );
  }

  if (screen === 'dashboard' && user) {
    return (
      <Dashboard
        user={user}
        onOpenEditor={(id) => {
          setEditorProjectId(id);
          setScreen('editor');
        }}
        onLogout={logout}
      />
    );
  }

  if (screen === 'editor' && user) {
    return <EditorView user={user} projectId={editorProjectId} onBack={() => setScreen('dashboard')} />;
  }

  return <Landing onSignup={() => setScreen('auth')} onLogin={() => setScreen('auth')} />;
}
