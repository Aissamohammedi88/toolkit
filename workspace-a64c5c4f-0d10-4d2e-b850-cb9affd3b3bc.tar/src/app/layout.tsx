import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "NEXUS GEN HUB · Plasma — Studio de génération code, visuels & vidéo",
  description:
    "L'éditeur unifié qui réunit GenHub et GenEdit : générez du code, des README, des visuels et des vidéos, compilez et livrez — même sans API externe.",
  keywords: ["NEXUS", "GenHub", "GenEdit", "Plasma", "génération de code", "IA gratuite", "studio"],
  authors: [{ name: "NEXUS" }],
  openGraph: {
    title: "NEXUS GEN HUB · Plasma",
    description: "Studio de génération code + visuels + vidéo. Même sans API.",
    siteName: "NEXUS GEN HUB",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
