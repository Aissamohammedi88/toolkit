# NEXUS GEN HUB · Plasma

Studio de génération **code + visuels + vidéo** — éditeur unifié qui réunit
GenHub et GenEdit (genedit.py / genhub.sh) dans le même éditeur.

## Démarrage (après installation)

```bash
./genhub-plasma.sh        # démarre le serveur + ouvre le navigateur
```

App : http://localhost:4310

## Ce que fait l'application

1. **Éditeur unifié** — vos projets GenHub ET votre dossier `nexus-genedit`
   dans le même explorateur. `genedit.py` et `genhub.sh` se lancent d'un clic,
   la sortie réelle s'affiche dans le terminal intégré.
2. **Génération même sans API** — chaîne automatique :
   Pollinations (API gratuite sans clé) → **moteur local NEXUS** (100 % hors ligne).
3. **Code de production** — apps Node.js, API REST, composants React générés
   complets, exécutables dans l'éditeur (bouton « Exécuter »).
4. **Vidéos & visuels** — importez vos vidéos (60 Mo max), générez des visuels plasma.
5. **Compile & extrait** — export ZIP prêt à livrer.
6. **Comptes clients** — page d'inscription intégrée, plan Gratuit, premier
   inscrit = compte fondateur.

## Service automatique (optionnel)

```bash
./nexus-genhub-install.sh --autostart    # redémarre tout seul à chaque ouverture
systemctl --user status nexus-genhub     # état du service
systemctl --user stop nexus-genhub       # arrêt
```

## Emplacements

| Élément            | Chemin                                   |
| ------------------ | ---------------------------------------- |
| Application        | `~/Bureau/nexus-genhub-plasma/`          |
| Lanceur            | `~/Bureau/genhub-plasma.sh`              |
| Base de données    | `~/Bureau/nexus-genhub-plasma/db/`       |
| GenEdit (lecture)  | `~/Bureau/nexus-genedit/` (relié, non modifié) |
| Aether             | **NON touché** — projet séparé           |

## Port

Par défaut **4310** (indépendant d'Aether : 8420/8421).
Changez-le : `NEXUS_PORT=5000 ./genhub-plasma.sh`
