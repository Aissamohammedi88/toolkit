#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════
#  NEXUS GEN HUB v2.0 — UPGRADE TOUT-EN-UN
#  ──────────────────────────────────────────────────────────────────────
#  CE QUE ÇA FAIT :
#    · Ajoute à ton installation GenEdit EXISTANTE le GEN HUB :
#      ~140 services de génération RÉELS (IA image/texte/voix, diagrammes,
#      QR, graphiques, data…) + génération IA de workflows SANS template.
#  CE QUE ÇA NE FAIT PAS :
#    · Ça ne MODIFIE PAS et ne SUPPRIME JAMAIS genedit.py.
#      Preuve : empreinte SHA-256 avant / après, identique, affichée.
#      Sauvegarde complète dans backup-v1-<date>/ avant toute chose.
#  Ré-exécutable sans risque. Cible : Linux Mint · python3 + tkinter.
# ══════════════════════════════════════════════════════════════════════
set -euo pipefail

APP_TITLE="NEXUS GEN HUB"
APP_VERSION="2.0.0"
APP_DIR="${NEXUS_GENEDIT_DIR:-}"
HUB_FALLBACK="${HOME}/nexus-genhub"
SKIP_NET="${NEXUS_SKIP_NET:-0}"

C_CYAN="\033[1;36m"; C_MAG="\033[1;95m"; C_GRN="\033[1;32m"; C_YLW="\033[1;33m"
C_RED="\033[1;31m"; C_DIM="\033[2m"; C_B="\033[1m"; C_RST="\033[0m"
PASS=0; FAIL=0

ok()   { echo -e "  ${C_GRN}✓${C_RST} $1"; PASS=$((PASS+1)); }
ko()   { echo -e "  ${C_RED}✗${C_RST} $1"; FAIL=$((FAIL+1)); }
info() { echo -e "  ${C_DIM}·${C_RST} $1"; }
warn() { echo -e "  ${C_YLW}!${C_RST} $1"; }
phase(){ echo; echo -e "${C_MAG}━━━ PHASE $1/8 ━━━ ${C_CYAN}${C_B}$2${C_RST}"; }
chk()  { if eval "$2" >/dev/null 2>&1; then ok "$1"; else ko "$1"; fi }

echo
echo -e "${C_MAG}${C_B}"
cat <<'BANIERE'
   ╔══════════════════════════════════════════════════════════════╗
   ║   N E X U S   G E N   H U B   v 2 . 0   —   U P G R A D E    ║
   ║   Génération RÉELLE : IA sans clé + ~140 services vivants    ║
   ║   Optimise ton éditeur. Ne détruit RIEN. Preuves incluses.   ║
   ╚══════════════════════════════════════════════════════════════╝
BANIERE
echo -e "${C_RST}"

# ════════════════════════════════════════════════════════════════════
phase 1 "Environnement"
# ════════════════════════════════════════════════════════════════════
chk "python3" "command -v python3"
PYV="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null || echo 0)"
info "python $PYV"
chk "tkinter (interface graphique)" "python3 -c 'import tkinter'"
chk "curl" "command -v curl"
chk "PyYAML (validation IA renforcée)" "python3 -c 'import yaml'"
if [ "$SKIP_NET" = "1" ]; then
  warn "NEXUS_SKIP_NET=1 → vérification réseau sautée"
elif curl -sI --max-time 10 https://text.pollinations.ai/ >/dev/null 2>&1; then
  ok "Internet + Pollinations joignables (IA sans clé prête)"
else
  warn "Pollinations injoignable depuis CETTE sandbox/VPN — chez toi ça marchera (la batterie confirmera)"
fi

# ════════════════════════════════════════════════════════════════════
phase 2 "Localisation de GenEdit + SAUVEGARDE (non-destructif)"
# ════════════════════════════════════════════════════════════════════
GENEDIT=""
if [ -n "$APP_DIR" ] && [ -f "$APP_DIR/genedit.py" ]; then
  GENEDIT="$APP_DIR/genedit.py"
else
  for cand in "$HOME/Bureau/nexus-genedit" "$HOME/nexus-genedit" "$HOME/Desktop/nexus-genedit"; do
    if [ -f "$cand/genedit.py" ]; then GENEDIT="$cand/genedit.py"; break; fi
  done
fi
if [ -z "$GENEDIT" ]; then
  GENEDIT="$(find "$HOME" -maxdepth 4 -name genedit.py -not -path '*/.*' 2>/dev/null | head -1)"
fi
if [ -n "$GENEDIT" ]; then
  APP_DIR="$(cd "$(dirname "$GENEDIT")" && pwd)"
  ok "GenEdit v1 trouvé : $GENEDIT"
  SHA_BEFORE="$(sha256sum "$GENEDIT" | awk '{print $1}')"
  ok "empreinte SHA-256 AVANT : ${SHA_BEFORE:0:24}…"
  BK="$APP_DIR/backup-v1-$(date +%Y%m%d-%H%M%S)"
  mkdir -p "$BK"
  cp -a "$APP_DIR"/. "$BK"/ 2>/dev/null || true
  rm -rf "$BK/backup-v1-"* 2>/dev/null || true
  ok "sauvegarde complète : $BK"
else
  warn "genedit.py introuvable — le HUB sera installé en mode autonome dans $HUB_FALLBACK"
  APP_DIR="$HUB_FALLBACK"
  SHA_BEFORE=""
fi
mkdir -p "$APP_DIR"

# dossier des workflows (là où vivent les nexus-*.yml de GenEdit)
WDIR=""
for cand in "$APP_DIR" "$APP_DIR/workflows" "$HOME/Bureau" "$HOME/Bureau/workflows" "$HOME/Bureau/nexus-genedit/workflows"; do
  n="$( (ls "$cand"/nexus-*.yml 2>/dev/null || true) | wc -l )"
  if [ "${n:-0}" -ge 3 ]; then WDIR="$cand"; break; fi
done
[ -z "$WDIR" ] && WDIR="$(dirname "$GENEDIT" 2>/dev/null || echo "$HOME/Bureau")"
info "dossier workflows détecté : $WDIR"
mkdir -p "$HOME/.nexus-hub"
cat > "$HOME/.nexus-hub/config.json" <<CONFJ
{ "genedit_path": "${GENEDIT:-}", "app_dir": "$APP_DIR", "workflows_dir": "$WDIR", "version": "$APP_VERSION" }
CONFJ
ok "config : ~/.nexus-hub/config.json"
# ════════════════════════════════════════════════════════════════════
phase 3 "Écriture des modules (services · IA · hub)"
# ════════════════════════════════════════════════════════════════════

# ════════════════════════════════════════════════════════════════════
#  PARTIE A — nexus_services.py (1/2) : moteur + IMAGE IA + TEXTE IA
# ════════════════════════════════════════════════════════════════════

cat > "$APP_DIR/nexus_services.py" <<'NS1'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS GEN HUB — catalogue de services de génération RÉELS (v2.0).
Chaque service est un vrai endpoint HTTP vivant : génération IA, TTS,
diagrammes, QR, graphiques, données… Priorité SANS-CLÉ, extensions par
plugins dans ~/.nexus-hub/plugins/*.py
"""
import base64
import glob
import json
import os
import random
import re
import shutil
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

HUB_DIR = os.path.expanduser("~/.nexus-hub")
OUT_DIR = os.path.join(HUB_DIR, "out")
os.makedirs(OUT_DIR, exist_ok=True)

UA = "NEXUS-GenHub/2.0 (editeur generatif local)"
BASE_HDRS = {"User-Agent": UA}
STREAM_HDRS = dict(BASE_HDRS, Origin="https://nexus-genhub.local", Referer="https://nexus-genhub.local/")

CATS = ["IMAGE IA", "TEXTE IA (sans-clé)", "TEXTE IA (local)", "TEXTE IA (clé gratuite)",
        "VOIX & AUDIO", "OCR & VISION", "TRADUCTION", "AVATARS & ILLUSTRATIONS",
        "IMAGES UTILES", "QR & CODES-BARRES", "GRAPHIQUES & DATA", "DIAGRAMMES",
        "GÉO & CARTES", "MÉTÉO & ENVIRONNEMENT", "ESPACE", "FINANCE & CRYPTO",
        "CONNAISSANCE & SCIENCE", "DÉV & PAQUETS", "MUSIQUE", "CONTENU & FUN",
        "DÉMOGRAPHIE", "COULEURS IA", "OUTILS WEB & PARTAGE"]

# ─────────────────────────────────────────────────────────────────────
#  Moteur HTTP
# ─────────────────────────────────────────────────────────────────────
def http_req(url, method="GET", headers=None, data=None, timeout=20):
    """→ (status:int, bytes, url_finale). data: dict(form) | str | bytes."""
    h = dict(BASE_HDRS)
    if headers:
        h.update(headers)
    body = None
    if data is not None:
        if isinstance(data, dict):
            body = urllib.parse.urlencode(data).encode("utf-8")
            h.setdefault("Content-Type", "application/x-www-form-urlencoded")
        elif isinstance(data, str):
            body = data.encode("utf-8")
        else:
            body = data
    req = urllib.request.Request(url, data=body, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.getcode(), r.read(), r.geturl()
    except urllib.error.HTTPError as e:
        try:
            return e.code, e.read(), url
        except Exception:
            return e.code, b"", url
    except Exception as e:
        return 0, str(e).encode("utf-8"), url


def http_json(url, method="GET", headers=None, data=None, timeout=20):
    st, b, u = http_req(url, method, headers, data, timeout)
    try:
        return st, json.loads(b.decode("utf-8", "replace")), u
    except Exception:
        return st, None, u


def _pick_str(j, path):
    cur = j
    for part in path.split("."):
        try:
            cur = cur[part]
        except Exception:
            try:
                cur = cur[int(part)]
            except Exception:
                return json.dumps(j, ensure_ascii=False, indent=1)
    if isinstance(cur, (dict, list)):
        return json.dumps(cur, ensure_ascii=False, indent=1)
    return str(cur)


def ts_name():
    return "gen-%d-%04d" % (int(time.time() * 1000), random.randint(0, 9999))


def save_out(name, data):
    path = os.path.join(OUT_DIR, name)
    with open(path, "wb") as f:
        f.write(data)
    return path


def R(kind, ok=True, **kw):
    d = {"ok": ok, "kind": kind}
    d.update(kw)
    return d


def _mp(fields, files):
    """multipart/form-data → (body bytes, headers dict)"""
    b = "----NEXUS%d" % random.randint(10 ** 9, 10 ** 10)
    parts = []
    for k, v in fields.items():
        parts.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n" % (b, k, v)).encode("utf-8"))
    for name, fn, blob in files:
        parts.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"; filename=\"%s\"\r\nContent-Type: application/octet-stream\r\n\r\n" % (b, name, fn)).encode("utf-8") + blob + b"\r\n")
    parts.append(("--%s--\r\n" % b).encode("utf-8"))
    return b"".join(parts), {"Content-Type": "multipart/form-data; boundary=" + b}


# ─────────────────────────────────────────────────────────────────────
#  Constructeurs d'exécution réutilisables
# ─────────────────────────────────────────────────────────────────────
def _fmt(urlf, p):
    """Remplit {xxx} et {xxx_quote} (version encodée URL de xxx)."""
    p = dict(p)
    for k in re.findall(r"\{(\w+_quote)\}", urlf):
        base = k[:-6]
        p[k] = urllib.parse.quote(str(p.get(base, "")), safe="")
    return urlf.format(**p)


def jget(urlf, pick=None, headers=None, timeout=18):
    """GET JSON. urlf formaté avec les params. pick: chemin pointé du résultat."""
    def _run(p):
        st, j, u = http_json(_fmt(urlf, p), headers=headers, timeout=timeout)
        if st == 0:
            return R("json", ok=False, info="réseau injoignable / service éteint", status=0)
        if st >= 400:
            return R("json", ok=False, info="HTTP %s" % st, status=st)
        txt = _pick_str(j, pick) if pick else json.dumps(j, ensure_ascii=False, indent=1)
        return R("json", status=st, text=txt[:20000], url=u)
    return _run


def imgget(urlf, ext="png", headers=None, timeout=60):
    """GET image binaire → fichier + aperçu."""
    def _run(p):
        st, b, u = http_req(_fmt(urlf, p), headers=headers, timeout=timeout)
        if st == 0:
            return R("image", ok=False, info="réseau injoignable", status=0)
        if st >= 400:
            return R("image", ok=False, info="HTTP %s — service gratuit saturé ou limité, réessaie" % st, status=st)
        if len(b) < 200:
            return R("image", ok=False, info="réponse vide", status=st)
        path = save_out(ts_name() + "." + ext, b)
        return R("image", path=path, status=st, info="%d o" % len(b), url=u)
    return _run


def aget(urlf, headers=None, timeout=40):
    """GET audio (mp3) → fichier jouable."""
    def _run(p):
        st, b, u = http_req(_fmt(urlf, p), headers=headers or STREAM_HDRS, timeout=timeout)
        if st == 0:
            return R("audio", ok=False, info="réseau injoignable", status=0)
        if st >= 400:
            return R("audio", ok=False, info="HTTP %s" % st, status=st)
        if len(b) < 500:
            return R("audio", ok=False, info="audio vide", status=st)
        path = save_out(ts_name() + ".mp3", b)
        return R("audio", path=path, status=st, info="%d o" % len(b), url=u)
    return _run


def tget(urlf, headers=None, timeout=18):
    """GET texte brut."""
    def _run(p):
        st, b, u = http_req(_fmt(urlf, p), headers=headers, timeout=timeout)
        if st == 0:
            return R("texte", ok=False, info="réseau injoignable", status=0)
        if st >= 400:
            return R("texte", ok=False, info="HTTP %s" % st, status=st)
        return R("texte", status=st, text=b.decode("utf-8", "replace")[:20000], url=u)
    return _run


def port_ping(port, timeout=0.6):
    def _p():
        try:
            s = socket.create_connection(("127.0.0.1", port), timeout=timeout)
            s.close()
            return 200
        except Exception:
            return 0
    return _p


def local_openai(port, path="/v1/chat/completions", model=None):
    def _run(p):
        body = {"messages": [{"role": "user", "content": p.get("prompt", "Bonjour")}], "max_tokens": 600}
        if model:
            body["model"] = model
        st, j, _ = http_json("http://127.0.0.1:%s%s" % (port, path), method="POST",
                             headers={"Content-Type": "application/json"},
                             data=json.dumps(body), timeout=120)
        if st == 0:
            return R("texte", ok=False, info="serveur local éteint sur le port %s" % port, status=0)
        if st >= 400 or not j:
            return R("texte", ok=False, info="HTTP %s — modèle chargé ?" % st, status=st)
        try:
            txt = j["choices"][0]["message"]["content"]
        except Exception:
            txt = json.dumps(j, ensure_ascii=False)[:2000]
        return R("texte", status=st, text=txt, info="modèle local")
    return _run


SERVICES = []


def srv(**kw):
    SERVICES.append(kw)
    return kw


def _q(t):
    return urllib.parse.quote(str(t), safe="")


# ─────────────────────────────────────────────────────────────────────
#  IMAGE IA (9)
# ─────────────────────────────────────────────────────────────────────
def _polli_img(model):
    def _run(p):
        url = ("https://image.pollinations.ai/prompt/" + _q(p.get("prompt", "orb néon"))
               + "?width=%s&height=%s&model=%s&nologo=true&seed=%s"
               % (p.get("largeur", "1024"), p.get("hauteur", "1024"), model, p.get("graine") or random.randint(1, 999999)))
        st, b, u = http_req(url, timeout=90)
        if st == 0:
            return R("image", ok=False, info="réseau injoignable", status=0)
        if st >= 400:
            return R("image", ok=False, info="HTTP %s — générateur gratuit saturé, réessaie ou passe par AI Horde" % st, status=st)
        if len(b) < 500:
            return R("image", ok=False, info="image vide", status=st)
        path = save_out(ts_name() + ".jpg", b)
        return R("image", path=path, status=st, info="%s — %d o (sans clé)" % (model, len(b)), url=u)
    return _run

IMG_PARAMS = [("prompt", "un orbe néon cyan et magenta sur fond noir, style NEXUS", "prompt"),
              ("largeur", "1024", "largeur"), ("hauteur", "1024", "hauteur"), ("graine", "", "graine (vide = aléatoire)")]

srv(id="img-flux", nom="Pollinations · FLUX.1", cat="IMAGE IA", acces="sans-clé", genre="image",
    desc="FLUX.1 (Black Forest Labs) servi gratuitement par Pollinations. Zéro clé, zéro compte.",
    params=IMG_PARAMS, run=_polli_img("flux"),
    ping=lambda: http_req("https://image.pollinations.ai/prompt/test?width=64&height=64&model=flux&nologo=true", timeout=12)[0])

srv(id="img-turbo", nom="Pollinations · Turbo (SDXL)", cat="IMAGE IA", acces="sans-clé", genre="image",
    desc="Turbo SDXL rapide via Pollinations. Peut passer en offre limitée aux heures de pointe.",
    params=IMG_PARAMS, run=_polli_img("turbo"),
    ping=lambda: http_req("https://image.pollinations.ai/prompt/test?width=64&height=64&model=turbo&nologo=true", timeout=12)[0])

srv(id="img-gptimage", nom="Pollinations · GPT-Image", cat="IMAGE IA", acces="sans-clé", genre="image",
    desc="GPT-Image via Pollinations (génération style GPT). Sans clé.",
    params=IMG_PARAMS, run=_polli_img("gptimage"),
    ping=lambda: http_req("https://image.pollinations.ai/prompt/test?width=64&height=64&model=gptimage&nologo=true", timeout=15)[0])

srv(id="img-kontext", nom="Pollinations · Kontext", cat="IMAGE IA", acces="sans-clé", genre="image",
    desc="Kontext : génération contextuelle via Pollinations. Sans clé.",
    params=IMG_PARAMS, run=_polli_img("kontext"),
    ping=lambda: http_req("https://image.pollinations.ai/prompt/test?width=64&height=64&model=kontext&nologo=true", timeout=15)[0])


def _horde_img(p):
    payload = {"prompt": p.get("prompt", "neon orb"), "params": {"n": 1, "width": 512, "height": 512, "steps": 20},
               "nsfw": False, "shared": False, "r2": True}
    st, b, _ = http_req("https://aihorde.net/api/v2/generate/async", method="POST",
                        headers={"apikey": "0000000000", "Content-Type": "application/json", "Client-Agent": UA},
                        data=json.dumps(payload), timeout=25)
    if st >= 400:
        return R("image", ok=False, info="HTTP %s (horde en charge ?)" % st, status=st)
    try:
        gid = json.loads(b.decode("utf-8")).get("id")
    except Exception:
        gid = None
    if not gid:
        return R("image", ok=False, info="pas d'id de tâche")
    done = False
    for _ in range(50):
        time.sleep(4)
        st2, b2, _ = http_req("https://aihorde.net/api/v2/generate/check/" + gid, headers={"Client-Agent": UA}, timeout=10)
        if st2 != 200:
            continue
        try:
            j2 = json.loads(b2.decode("utf-8"))
        except Exception:
            continue
        if j2.get("faulted"):
            return R("image", ok=False, info="tâche échouée sur la horde")
        if j2.get("done"):
            done = True
            break
    if not done:
        return R("image", ok=False, info="file d'attente > 3 min — réessaie plus tard")
    st3, b3, _ = http_req("https://aihorde.net/api/v2/generate/status/" + gid, headers={"Client-Agent": UA}, timeout=15)
    try:
        gens = json.loads(b3.decode("utf-8")).get("generations") or []
    except Exception:
        gens = []
    if not gens or not gens[0].get("img"):
        return R("image", ok=False, info="pas d'image renvoyée")
    st4, b4, _ = http_req(gens[0]["img"], timeout=60)
    if st4 >= 400 or len(b4) < 500:
        return R("image", ok=False, info="téléchargement de l'image échoué")
    return R("image", path=save_out(ts_name() + ".webp", b4), status=200, info="généré par la communauté AI Horde (gratuit, sans clé)")

srv(id="img-horde", nom="AI Horde · Stable Diffusion communautaire", cat="IMAGE IA", acces="sans-clé", genre="image",
    desc="Rendu par des GPU de volontaires. 100% gratuit, anonyme. File d'attente 1-3 min.",
    params=[("prompt", "a neon cyberpunk city, cinematic", "prompt")], run=_horde_img,
    ping=lambda: http_req("https://aihorde.net/api/v2/status/heartbeat", timeout=10)[0])

def _deepai_run(p):
    key = os.environ.get("NEXUS_DEEPAI_KEY", "")
    if not key:
        return R("image", ok=False, info="clé absente — export NEXUS_DEEPAI_KEY=… (compte gratuit deepai.org)")
    st, j, _ = http_json("https://api.deepai.org/api/text2img", method="POST",
                         headers={"api-key": key}, data={"text": p.get("prompt", "orb")}, timeout=60)
    if st >= 400 or not j or not j.get("output_url"):
        return R("image", ok=False, info="HTTP %s — %s" % (st, json.dumps(j)[:120] if j else "?"), status=st)
    st2, b2, _ = http_req(j["output_url"], timeout=60)
    return R("image", path=save_out(ts_name() + ".jpg", b2), status=st2, info="DeepAI")

srv(id="img-deepai", nom="DeepAI · Text2Image", cat="IMAGE IA", acces="clé-gratuite", genre="image",
    desc="Compte gratuit sur deepai.org puis export NEXUS_DEEPAI_KEY=…",
    params=IMG_PARAMS, run=_deepai_run,
    ping=lambda: http_req("https://api.deepai.org/", timeout=10)[0])

srv(id="img-hf-flux", nom="Hugging Face · FLUX.1-schnell", cat="IMAGE IA", acces="clé-gratuite", genre="image",
    desc="Token gratuit huggingface.co → export NEXUS_HF_KEY=… FLUX schnell (4 étapes, rapide).",
    params=IMG_PARAMS,
    run=lambda p: _hf_img("black-forest-labs/FLUX.1-schnell", p),
    ping=lambda: http_req("https://huggingface.co/api/models/black-forest-labs/FLUX.1-schnell", timeout=10)[0])


def _hf_img(model, p):
    key = os.environ.get("NEXUS_HF_KEY", "")
    if not key:
        return R("image", ok=False, info="clé absente — export NEXUS_HF_KEY=… (gratuit huggingface.co)")
    st, b, _ = http_req("https://api-inference.huggingface.co/models/" + model, method="POST",
                        headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"},
                        data=json.dumps({"inputs": p.get("prompt", "orb")}), timeout=90)
    if st >= 400:
        return R("image", ok=False, info="HTTP %s — %s" % (st, b[:120].decode("utf-8", "replace")), status=st)
    return R("image", path=save_out(ts_name() + ".png", b), status=st, info=model)

srv(id="img-hf-sdxl", nom="Hugging Face · SDXL 1.0", cat="IMAGE IA", acces="clé-gratuite", genre="image",
    desc="Stable Diffusion XL base via HF (token gratuit).",
    params=IMG_PARAMS,
    run=lambda p: _hf_img("stabilityai/stable-diffusion-xl-base-1.0", p),
    ping=lambda: http_req("https://huggingface.co/api/models/stabilityai/stable-diffusion-xl-base-1.0", timeout=10)[0])


def _fusion(p):
    k = os.environ.get("NEXUS_FUSION_KEY", "")
    s = os.environ.get("NEXUS_FUSION_SECRET", "")
    if not k or not s:
        return R("image", ok=False, info="clés absentes — exports NEXUS_FUSION_KEY / NEXUS_FUSION_SECRET (gratuit fusionbrain.ai)")
    st, b, _ = http_req("https://api-key.fusionbrain.ai/key/api/v1/text2image/run", method="POST",
                        headers={"X-Key": "Key " + k, "X-Secret": "Secret " + s, "Content-Type": "application/json"},
                        data=json.dumps({"params": {"type": "GENERATE", "width": 512, "height": 512, "generateParams": {},
                                                    "numImages": 1, "style": "DEFAULT"},
                                         "model_id": "4213791309", "query": p.get("prompt", "orb")}), timeout=60)
    if st >= 400:
        return R("image", ok=False, info="HTTP %s" % st, status=st)
    try:
        uid = json.loads(b.decode()).get("uuid")
    except Exception:
        uid = None
    if not uid:
        return R("image", ok=False, info="pas d'uuid")
    for _ in range(30):
        time.sleep(3)
        st2, b2, _ = http_req("https://api-key.fusionbrain.ai/key/api/v1/text2image/status/" + uid,
                              headers={"X-Key": "Key " + k, "X-Secret": "Secret " + s}, timeout=15)
        try:
            j2 = json.loads(b2.decode())
        except Exception:
            continue
        if j2.get("status") == "DONE":
            files = j2.get("images") or []
            if files:
                import base64 as b64
                return R("image", path=save_out(ts_name() + ".jpg", b64.b64decode(files[0])), status=200, info="Kandinsky (FusionBrain)")
            return R("image", ok=False, info="terminé sans image")
        if j2.get("status") == "FAIL":
            return R("image", ok=False, info="génération échouée côté serveur")
    return R("image", ok=False, info="délai dépassé")

srv(id="img-kandinsky", nom="FusionBrain · Kandinsky 3.1", cat="IMAGE IA", acces="clé-gratuite", genre="image",
    desc="Kandinsky (Sber). Clés gratuites sur fusionbrain.ai → NEXUS_FUSION_KEY / NEXUS_FUSION_SECRET.",
    params=IMG_PARAMS, run=_fusion,
    ping=lambda: http_req("https://fusionbrain.ai/", timeout=10)[0])
NS1
ok "nexus_services.py — moteur + IMAGE IA (9 services réels)"

# ════════════════════════════════════════════════════════════════════
#  PARTIE B — nexus_services.py (2/2) : LLM, voix, traduction, data…
# ════════════════════════════════════════════════════════════════════

cat >> "$APP_DIR/nexus_services.py" <<'NS2'

# ─────────────────────────────────────────────────────────────────────
#  TEXTE IA sans-clé (5)
# ─────────────────────────────────────────────────────────────────────
def _polli_txt(model):
    def _run(p):
        st, b, u = http_req("https://text.pollinations.ai/" + _q(p.get("prompt", "Dis bonjour en une phrase.")),
                            headers={"Accept": "text/plain"}, timeout=90)
        if st == 0:
            return R("texte", ok=False, info="réseau injoignable", status=0)
        if st >= 400:
            return R("texte", ok=False, info="HTTP %s — modèle %s en charge, essaye un autre" % (st, model), status=st)
        return R("texte", status=st, text=b.decode("utf-8", "replace")[:20000], info="Pollinations · " + model, url=u)
    return _run

TXT_PARAMS = [("prompt", "Explique en 3 phrases ce qu'est un workflow GitHub Actions.", "prompt")]

srv(id="txt-polli-openai", nom="Pollinations · GPT-4o-mini (sans clé)", cat="TEXTE IA (sans-clé)", acces="sans-clé", genre="texte",
    desc="LLM OpenAI servi gratuitement par Pollinations. Vérifié vivant sans aucune clé.",
    params=TXT_PARAMS, run=_polli_txt("openai"),
    ping=lambda: http_req("https://text.pollinations.ai/hello", timeout=12)[0])
srv(id="txt-polli-mistral", nom="Pollinations · Mistral (sans clé)", cat="TEXTE IA (sans-clé)", acces="sans-clé", genre="texte",
    desc="Mistral gratuit via Pollinations.",
    params=TXT_PARAMS, run=_polli_txt("mistral"),
    ping=lambda: http_req("https://text.pollinations.ai/hello?model=mistral", timeout=12)[0])
srv(id="txt-polli-llama", nom="Pollinations · Llama (sans clé)", cat="TEXTE IA (sans-clé)", acces="sans-clé", genre="texte",
    desc="Llama gratuit via Pollinations.",
    params=TXT_PARAMS, run=_polli_txt("llama"),
    ping=lambda: http_req("https://text.pollinations.ai/hello?model=llama", timeout=12)[0])
srv(id="txt-polli-deepseek", nom="Pollinations · DeepSeek (sans clé)", cat="TEXTE IA (sans-clé)", acces="sans-clé", genre="texte",
    desc="DeepSeek gratuit via Pollinations (bon en raisonnement).",
    params=TXT_PARAMS, run=_polli_txt("deepseek"),
    ping=lambda: http_req("https://text.pollinations.ai/hello?model=deepseek", timeout=12)[0])
srv(id="txt-polli-qwen", nom="Pollinations · Qwen-Coder (sans clé)", cat="TEXTE IA (sans-clé)", acces="sans-clé", genre="texte",
    desc="Qwen Coder gratuit : spécialiste du code et du YAML.",
    params=TXT_PARAMS, run=_polli_txt("qwen-coder"),
    ping=lambda: http_req("https://text.pollinations.ai/hello?model=qwen-coder", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  TEXTE IA local (9)
# ─────────────────────────────────────────────────────────────────────
srv(id="llm-ollama", nom="Ollama (local :11434)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="Ton IA 100% locale. Lance « ollama serve » puis « ollama run llama3 ».",
    params=TXT_PARAMS, run=local_openai(11434, "/api/chat"), ping=port_ping(11434))
srv(id="llm-lmstudio", nom="LM Studio (local :1234)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="Serveur local OpenAI-compatible de LM Studio.",
    params=TXT_PARAMS, run=local_openai(1234), ping=port_ping(1234))
srv(id="llm-llamacpp", nom="llama.cpp server (local :8080)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="Serveur llama.cpp en mode OpenAI-compatible.",
    params=TXT_PARAMS, run=local_openai(8080), ping=port_ping(8080))
srv(id="llm-jan", nom="Jan (local :1337)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="Application Jan, serveur local.",
    params=TXT_PARAMS, run=local_openai(1337), ping=port_ping(1337))
srv(id="llm-gpt4all", nom="GPT4All (local :4891)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="Serveur GPT4All.",
    params=TXT_PARAMS, run=local_openai(4891), ping=port_ping(4891))
srv(id="llm-kobold", nom="KoboldCpp (local :5001)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="KoboldCpp, API native.",
    params=TXT_PARAMS,
    run=lambda p: _kobold(p), ping=port_ping(5001))


def _kobold(p):
    st, j, _ = http_json("http://127.0.0.1:5001/api/v1/generate", method="POST",
                         headers={"Content-Type": "application/json"},
                         data=json.dumps({"prompt": p.get("prompt", "Bonjour"), "max_length": 400}), timeout=90)
    if st == 0:
        return R("texte", ok=False, info="KoboldCpp éteint (port 5001)", status=0)
    if st >= 400 or not j:
        return R("texte", ok=False, info="HTTP %s" % st, status=st)
    return R("texte", status=st, text=(j.get("results") or [{}])[0].get("text", ""))

srv(id="llm-tgwui", nom="text-generation-webui (local :5000)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="oobabooga, extension OpenAI activée.",
    params=TXT_PARAMS, run=local_openai(5000), ping=port_ping(5000))
srv(id="llm-vllm", nom="vLLM (local :8000)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="Serveur vLLM haute performance.",
    params=TXT_PARAMS, run=local_openai(8000), ping=port_ping(8000))
srv(id="llm-localai", nom="LocalAI (local :8081)", cat="TEXTE IA (local)", acces="local", genre="texte",
    desc="LocalAI, alternative open-source à l'API OpenAI.",
    params=TXT_PARAMS, run=local_openai(8081), ping=port_ping(8081))

# ─────────────────────────────────────────────────────────────────────
#  TEXTE IA clé-gratuite (9)
# ─────────────────────────────────────────────────────────────────────
def _openai_cloud(base, model, envk, extra_headers=None):
    def _run(p):
        key = os.environ.get(envk, "")
        if not key:
            return R("texte", ok=False, info="clé absente — export %s=… (offre gratuite chez le fournisseur)" % envk)
        h = {"Content-Type": "application/json", "Authorization": "Bearer " + key}
        if extra_headers:
            h.update(extra_headers)
        st, j, _ = http_json(base, method="POST", headers=h,
                             data=json.dumps({"model": model, "messages": [{"role": "user", "content": p.get("prompt", "Bonjour")}]}),
                             timeout=90)
        if st >= 400 or not j:
            return R("texte", ok=False, info="HTTP %s — %s" % (st, json.dumps(j)[:150] if j else "?"), status=st)
        try:
            txt = j["choices"][0]["message"]["content"]
        except Exception:
            txt = json.dumps(j, ensure_ascii=False)[:2000]
        return R("texte", status=st, text=txt, info=model)
    return _run

srv(id="llm-groq", nom="Groq · Llama 3.3 70B", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="Le plus rapide du monde, offre gratuite généreuse. console.groq.com → NEXUS_GROQ_KEY.",
    params=TXT_PARAMS, run=_openai_cloud("https://api.groq.com/openai/v1/chat/completions", "llama-3.3-70b-versatile", "NEXUS_GROQ_KEY"),
    ping=lambda: http_req("https://api.groq.com/openai/v1/models", timeout=10)[0])
srv(id="llm-mistral-api", nom="Mistral · Small", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="Offre gratuite « experiment ». console.mistral.ai → NEXUS_MISTRAL_KEY.",
    params=TXT_PARAMS, run=_openai_cloud("https://api.mistral.ai/v1/chat/completions", "mistral-small-latest", "NEXUS_MISTRAL_KEY"),
    ping=lambda: http_req("https://api.mistral.ai/v1/models", timeout=10)[0])
def _gemini_run(p):
    key = os.environ.get("NEXUS_GEMINI_KEY", "")
    if not key:
        return R("texte", ok=False, info="clé absente — export NEXUS_GEMINI_KEY=… (gratuit aistudio.google.com)")
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + _q(key)
    st, j, _ = http_json(url, method="POST", headers={"Content-Type": "application/json"},
                         data=json.dumps({"contents": [{"parts": [{"text": p.get("prompt", "Bonjour")}]}]}), timeout=90)
    if st >= 400 or not j:
        return R("texte", ok=False, info="HTTP %s — %s" % (st, json.dumps(j)[:150] if j else "?"), status=st)
    try:
        txt = j["candidates"][0]["content"]["parts"][0]["text"]
    except Exception:
        txt = json.dumps(j, ensure_ascii=False)[:2000]
    return R("texte", status=st, text=txt, info="gemini-1.5-flash")

srv(id="llm-gemini", nom="Google Gemini 1.5 Flash", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="15 requêtes/min gratuites. aistudio.google.com → NEXUS_GEMINI_KEY.",
    params=TXT_PARAMS, run=_gemini_run,
    ping=lambda: http_req("https://generativelanguage.googleapis.com/v1beta/models", timeout=10)[0])

srv(id="llm-openrouter", nom="OpenRouter · modèles :free", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="Des dizaines de modèles gratuits (suffixe :free). openrouter.ai → NEXUS_OPENROUTER_KEY.",
    params=[("prompt", "Bonjour !", "prompt"), ("modele", "meta-llama/llama-3.1-8b-instruct:free", "modèle")],
    run=lambda p: _openai_cloud("https://openrouter.ai/api/v1/chat/completions", p.get("modele", "meta-llama/llama-3.1-8b-instruct:free"), "NEXUS_OPENROUTER_KEY", {"HTTP-Referer": "https://nexus.local", "X-Title": "NEXUS GenHub"})(p),
    ping=lambda: http_req("https://openrouter.ai/api/v1/models", timeout=10)[0])
srv(id="llm-github", nom="GitHub Models (token GitHub)", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="GPT-4o-mini gratuit avec ton token GitHub (settings → tokens).",
    params=TXT_PARAMS, run=_openai_cloud("https://models.inference.ai.azure.com/chat/completions", "gpt-4o-mini", "NEXUS_GITHUB_TOKEN"),
    ping=lambda: http_req("https://api.github.com/rate_limit", timeout=10)[0])
srv(id="llm-cerebras", nom="Cerebras · Llama 70B", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="1M tokens/jour gratuits. cloud.cerebras.ai → NEXUS_CEREBRAS_KEY.",
    params=TXT_PARAMS, run=_openai_cloud("https://api.cerebras.ai/v1/chat/completions", "llama-3.3-70b", "NEXUS_CEREBRAS_KEY"),
    ping=lambda: http_req("https://api.cerebras.ai/v1/models", timeout=10)[0])
srv(id="llm-sambanova", nom="SambaNova · Llama 3.3 70B", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="Offre développeur gratuite. cloud.sambanova.ai → NEXUS_SAMBANOVA_KEY.",
    params=TXT_PARAMS, run=_openai_cloud("https://api.sambanova.ai/v1/chat/completions", "Meta-Llama-3.3-70B-Instruct", "NEXUS_SAMBANOVA_KEY"),
    ping=lambda: http_req("https://api.sambanova.ai/", timeout=10)[0])
srv(id="llm-hf", nom="Hugging Face · Router LLM", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="Routeur HF unifié (token gratuit).",
    params=TXT_PARAMS, run=_openai_cloud("https://router.huggingface.co/v1/chat/completions", "meta-llama/Llama-3.1-8B-Instruct", "NEXUS_HF_KEY"),
    ping=lambda: http_req("https://huggingface.co/api/whoami-v2", timeout=10)[0])
srv(id="llm-cloudflare", nom="Cloudflare Workers AI", cat="TEXTE IA (clé gratuite)", acces="clé-gratuite", genre="texte",
    desc="10k neurones/jour gratuits. Paramètre « compte » = ton account ID Cloudflare.",
    params=[("prompt", "Bonjour !", "prompt"), ("compte", "", "account ID Cloudflare")],
    run=lambda p: _cf_run(p),
    ping=lambda: http_req("https://api.cloudflare.com/client/v4/user", timeout=10)[0])


def _cf_run(p):
    tok = os.environ.get("NEXUS_CF_TOKEN", "")
    acc = p.get("compte", "")
    if not tok or not acc:
        return R("texte", ok=False, info="il faut NEXUS_CF_TOKEN=… et ton account ID dans le champ « compte »")
    st, j, _ = http_json("https://api.cloudflare.com/client/v4/accounts/%s/ai/run/@cf/meta/llama-3.1-8b-instruct" % _q(acc),
                         method="POST", headers={"Authorization": "Bearer " + tok, "Content-Type": "application/json"},
                         data=json.dumps({"messages": [{"role": "user", "content": p.get("prompt", "Bonjour")}]}), timeout=90)
    if st >= 400 or not j:
        return R("texte", ok=False, info="HTTP %s" % st, status=st)
    return R("texte", status=st, text=j.get("result", {}).get("response", json.dumps(j)[:1500]), info="llama-3.1-8b (workers AI)")

# ─────────────────────────────────────────────────────────────────────
#  VOIX & AUDIO (4)
# ─────────────────────────────────────────────────────────────────────
srv(id="tts-streamelements", nom="StreamElements · TTS (voix Polly)", cat="VOIX & AUDIO", acces="sans-clé", genre="audio",
    desc="Voix Amazon Polly gratuites (Brian, Amy, Celine, Mathieu…). Vérifié vivant.",
    params=[("texte", "Bonjour, je suis la voix de NEXUS AETHER.", "texte"), ("voix", "Brian", "voix (Brian, Amy, Emma, Celine, Mathieu, Joanna…)")],
    run=aget("https://api.streamelements.com/kappa/v2/speech?voice={voix}&text={texte_quote}"),
    ping=lambda: http_req("https://api.streamelements.com/kappa/v2/speech?voice=Brian&text=ok", headers=STREAM_HDRS, timeout=10)[0])
srv(id="tts-google", nom="Google Translate · TTS", cat="VOIX & AUDIO", acces="sans-clé", genre="audio",
    desc="Synthèse vocale Google (200 caractères max). Vérifié vivant.",
    params=[("texte", "Bienvenue dans NEXUS GEN HUB.", "texte (≤200 car.)"), ("langue", "fr", "langue (fr, en, es…)")],
    run=aget("https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&q={texte_quote}&tl={langue}"),
    ping=lambda: http_req("https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&q=ok&tl=fr", timeout=10)[0])
srv(id="tts-piper", nom="Piper (TTS local)", cat="VOIX & AUDIO", acces="local", genre="audio",
    desc="TTS neuronal local ultra-rapide si installé (sudo apt install piper).",
    params=[("texte", "Test de Piper.", "texte")],
    run=lambda p: _piper_run(p), ping=port_ping(0))


def _piper_run(p):
    if not shutil.which("piper"):
        return R("audio", ok=False, info="piper non installé — sudo apt install piper")
    wav = os.path.join(OUT_DIR, ts_name() + ".wav")
    try:
        r = subprocess.run(["piper", "--output_file", wav], input=p.get("texte", "test").encode(),
                           capture_output=True, timeout=60)
    except Exception as e:
        return R("audio", ok=False, info=str(e))
    if r.returncode != 0 or not os.path.exists(wav):
        return R("audio", ok=False, info="piper a échoué (voix installée ?)")
    return R("audio", path=wav, info="wav local généré")

srv(id="stt-groq", nom="Groq · Whisper (transcription)", cat="VOIX & AUDIO", acces="clé-gratuite", genre="texte",
    desc="Transcrit un fichier audio (wav/mp3) via Whisper sur Groq. NEXUS_GROQ_KEY.",
    params=[("audio", "/chemin/vers/audio.mp3", "chemin du fichier audio")],
    run=lambda p: _groq_stt(p),
    ping=lambda: http_req("https://api.groq.com/openai/v1/models", timeout=10)[0])


def _groq_stt(p):
    key = os.environ.get("NEXUS_GROQ_KEY", "")
    if not key:
        return R("texte", ok=False, info="clé absente — export NEXUS_GROQ_KEY=…")
    f = os.path.expanduser(p.get("audio", ""))
    if not os.path.isfile(f):
        return R("texte", ok=False, info="fichier introuvable : " + f)
    body, hdrs = _mp({"model": "whisper-large-v3", "language": "fr"}, [("file", os.path.basename(f), open(f, "rb").read())])
    st, j, _ = http_json("https://api.groq.com/openai/v1/audio/transcriptions", method="POST",
                         headers=dict(hdrs, Authorization="Bearer " + key), data=body, timeout=120)
    if st >= 400 or not j:
        return R("texte", ok=False, info="HTTP %s" % st, status=st)
    return R("texte", status=st, text=j.get("text", ""))

# ─────────────────────────────────────────────────────────────────────
#  OCR & VISION (2)
# ─────────────────────────────────────────────────────────────────────
srv(id="ocr-space", nom="OCR.space · lecture de texte", cat="OCR & VISION", acces="sans-clé", genre="texte",
    desc="OCR gratuit (clé de test publique « helloworld », 25k/mois). URL d'image en entrée.",
    params=[("url_image", "https://i.imgur.com/…", "URL de l'image"), ("langue", "fre", "langue (fre, eng)")],
    run=lambda p: _ocrspace(p),
    ping=lambda: http_req("https://api.ocr.space/parse/image", method="POST", data={"apikey": "helloworld"}, timeout=12)[0])


def _ocrspace(p):
    st, j, _ = http_json("https://api.ocr.space/parse/image", method="POST",
                         data={"apikey": "helloworld", "url": p.get("url_image", ""), "language": p.get("langue", "fre"), "OCREngine": "2"},
                         timeout=45)
    if st >= 400:
        return R("texte", ok=False, info="HTTP %s" % st, status=st)
    if not j:
        return R("texte", ok=False, info="réponse vide")
    if j.get("IsErroredOnProcessing"):
        return R("texte", ok=False, info="OCR : " + str(j.get("ErrorMessage"))[:150])
    res = (j.get("ParsedResults") or [{}])[0].get("ParsedText", "")
    return R("texte", status=st, text=res or "(aucun texte détecté)")

srv(id="ocr-tesseract", nom="Tesseract (OCR local)", cat="OCR & VISION", acces="local", genre="texte",
    desc="OCR 100% local (sudo apt install tesseract-ocr).",
    params=[("image", "/chemin/image.png", "chemin image"), ("langue", "fra", "langue")],
    run=lambda p: _tess(p), ping=port_ping(0))


def _tess(p):
    if not shutil.which("tesseract"):
        return R("texte", ok=False, info="tesseract non installé — sudo apt install tesseract-ocr")
    img = os.path.expanduser(p.get("image", ""))
    if not os.path.isfile(img):
        return R("texte", ok=False, info="image introuvable : " + img)
    out = os.path.join(OUT_DIR, "ocr-" + ts_name())
    try:
        subprocess.run(["tesseract", img, out, "-l", p.get("langue", "fra")], capture_output=True, timeout=120)
    except Exception as e:
        return R("texte", ok=False, info=str(e))
    if not os.path.exists(out + ".txt"):
        return R("texte", ok=False, info="tesseract n'a pas produit de sortie")
    return R("texte", text=open(out + ".txt", encoding="utf-8", errors="replace").read(), info="OCR local")

# ─────────────────────────────────────────────────────────────────────
#  TRADUCTION (5)
# ─────────────────────────────────────────────────────────────────────
srv(id="tr-google", nom="Google Traduction (endpoint public)", cat="TRADUCTION", acces="sans-clé", genre="texte",
    desc="Le endpoint public de Google Translate, sans clé. Détection auto de langue.",
    params=[("texte", "Hello world, this is NEXUS.", "texte"), ("cible", "fr", "langue cible")],
    run=lambda p: _gtr(p),
    ping=lambda: http_req("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=fr&dt=t&q=hi", timeout=10)[0])


def _gtr(p):
    url = ("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=%s&dt=t&q=%s"
           % (_q(p.get("cible", "fr")), _q(p.get("texte", ""))))
    st, j, _ = http_json(url, timeout=20)
    if st >= 400 or not j:
        return R("texte", ok=False, info="HTTP %s (limite IP datacenter possible — chez toi ça passera)" % st, status=st)
    try:
        txt = "".join(seg[0] for seg in j[0] if seg and seg[0])
    except Exception:
        txt = json.dumps(j, ensure_ascii=False)[:1500]
    return R("texte", status=st, text=txt)

srv(id="tr-lingva", nom="Lingva (miroir open-source)", cat="TRADUCTION", acces="sans-clé", genre="texte",
    desc="Frontend open-source de traduction, sans pub ni clé.",
    params=[("texte", "Hello!", "texte"), ("source", "en", "source"), ("cible", "fr", "cible")],
    run=jget("https://lingva.garudalinux.org/api/v1/{source}/{cible}/{texte_quote}", pick="translation"),
    ping=lambda: http_req("https://lingva.garudalinux.org/api/v1/en/fr/hi", timeout=10)[0])
srv(id="tr-mymemory", nom="MyMemory (mémoires de traduction)", cat="TRADUCTION", acces="sans-clé", genre="texte",
    desc="Mémoires de traduction EU, 5000 caractères/jour sans clé.",
    params=[("texte", "Bonjour le monde.", "texte"), ("paire", "fr|en", "paire (fr|en)")],
    run=jget("https://api.mymemory.translated.net/get?q={texte_quote}&langpair={paire}", pick="responseData.translatedText"),
    ping=lambda: http_req("https://api.mymemory.translated.net/get?q=hi&langpair=en|fr", timeout=10)[0])
srv(id="tr-apertium", nom="Apertium APy (open-source)", cat="TRADUCTION", acces="sans-clé", genre="texte",
    desc="Moteur de traduction libre Apertium (instance publique officielle).",
    params=[("texte", "Hello world", "texte"), ("paire", "en|fr", "paire")],
    run=jget("https://www.apertium.org/apy/translate?q={texte_quote}&langpair={paire}", pick="responseData.translatedText"),
    ping=lambda: http_req("https://www.apertium.org/apy/list?q=pairs", timeout=10)[0])
srv(id="tr-deepl", nom="DeepL API Free", cat="TRADUCTION", acces="clé-gratuite", genre="texte",
    desc="La meilleure traduction. 500k caractères/mois gratuits → NEXUS_DEEPL_KEY.",
    params=[("texte", "Bonjour.", "texte"), ("cible", "EN", "cible (EN, FR, DE…)")],
    run=lambda p: _deepl(p),
    ping=lambda: http_req("https://api-free.deepl.com/v2/usage", timeout=10)[0])


def _deepl(p):
    key = os.environ.get("NEXUS_DEEPL_KEY", "")
    if not key:
        return R("texte", ok=False, info="clé absente — export NEXUS_DEEPL_KEY=… (gratuit deepl.com/pro-api)")
    st, j, _ = http_json("https://api-free.deepl.com/v2/translate", method="POST",
                         headers={"Authorization": "DeepL-Auth-Key " + key, "Content-Type": "application/json"},
                         data=json.dumps({"text": [p.get("texte", "")], "target_lang": p.get("cible", "EN")}), timeout=30)
    if st >= 400 or not j:
        return R("texte", ok=False, info="HTTP %s" % st, status=st)
    return R("texte", status=st, text=(j.get("translations") or [{}])[0].get("text", ""))

# ─────────────────────────────────────────────────────────────────────
#  AVATARS & ILLUSTRATIONS génératives (7)
# ─────────────────────────────────────────────────────────────────────
srv(id="av-dicebear-bottts", nom="DiceBear · Bottts (robots PNG)", cat="AVATARS & ILLUSTRATIONS", acces="sans-clé", genre="image",
    desc="Avatars robots génératifs, 40+ collections disponibles. Vérifié vivant.",
    params=[("graine", "nexus-1", "graine"), ("taille", "256", "taille px")],
    run=imgget("https://api.dicebear.com/9.x/bottts/png?seed={graine}&size={taille}"),
    ping=lambda: http_req("https://api.dicebear.com/9.x/bottts/png?seed=x&size=64", timeout=10)[0])
srv(id="av-dicebear-adventurer", nom="DiceBear · Adventurer", cat="AVATARS & ILLUSTRATIONS", acces="sans-clé", genre="image",
    desc="Avatars personnages illustrés.",
    params=[("graine", "nexus-2", "graine"), ("taille", "256", "taille px")],
    run=imgget("https://api.dicebear.com/9.x/adventurer/png?seed={graine}&size={taille}"),
    ping=lambda: http_req("https://api.dicebear.com/9.x/adventurer/png?seed=x&size=64", timeout=10)[0])
srv(id="av-dicebear-shapes", nom="DiceBear · Shapes (abstrait)", cat="AVATARS & ILLUSTRATIONS", acces="sans-clé", genre="image",
    desc="Compositions abstraites génératives — parfait pour des pochettes.",
    params=[("graine", "nexus-3", "graine"), ("taille", "512", "taille px")],
    run=imgget("https://api.dicebear.com/9.x/shapes/png?seed={graine}&size={taille}"),
    ping=lambda: http_req("https://api.dicebear.com/9.x/shapes/png?seed=x&size=64", timeout=10)[0])
srv(id="av-robohash", nom="Robohash · Robots", cat="AVATARS & ILLUSTRATIONS", acces="sans-clé", genre="image",
    desc="Robots pixel/génératifs depuis n'importe quelle chaîne. Vérifié vivant.",
    params=[("graine", "nexus", "graine"), ("taille", "256x256", "taille WxH")],
    run=imgget("https://robohash.org/{graine}.png?size={taille}&set=set1"),
    ping=lambda: http_req("https://robohash.org/x.png?size=64x64", timeout=10)[0])
srv(id="av-robohash-monsters", nom="Robohash · Monstres", cat="AVATARS & ILLUSTRATIONS", acces="sans-clé", genre="image",
    desc="Variante monstres de Robohash.",
    params=[("graine", "nexus", "graine"), ("taille", "256x256", "taille WxH")],
    run=imgget("https://robohash.org/{graine}.png?size={taille}&set=set2"),
    ping=lambda: http_req("https://robohash.org/x.png?size=64x64&set=set2", timeout=10)[0])
srv(id="av-multavatar", nom="Multavatar", cat="AVATARS & ILLUSTRATIONS", acces="sans-clé", genre="image",
    desc="12 styles d'avatars combinatoires depuis une graine.",
    params=[("graine", "nexus", "graine")],
    run=imgget("https://api.multavatar.com/{graine}.png"),
    ping=lambda: http_req("https://api.multavatar.com/x.png", timeout=10)[0])
srv(id="av-boringavatars", nom="Boring Avatars (Beam)", cat="AVATARS & ILLUSTRATIONS", acces="sans-clé", genre="image",
    desc="Avatars géométriques élégants style Beam (SVG).",
    params=[("graine", "nexus", "graine")],
    run=imgget("https://source.boringavatars.com/beam/256/{graine}?colors=00E5FF,FF00C8,00FF88", ext="svg"),
    ping=lambda: http_req("https://source.boringavatars.com/beam/64/x", timeout=10)[0])
NS2
ok "nexus_services.py — LLM (23), voix, OCR, traduction, avatars"

# ════════════════════════════════════════════════════════════════════
#  PARTIE C — nexus_services.py (3/3) : images, QR, graphs, data…
# ════════════════════════════════════════════════════════════════════

cat >> "$APP_DIR/nexus_services.py" <<'NS3'

# ─────────────────────────────────────────────────────────────────────
#  IMAGES UTILES (5)
# ─────────────────────────────────────────────────────────────────────
srv(id="ph-picsum", nom="Picsum · photo aléatoire", cat="IMAGES UTILES", acces="sans-clé", genre="image",
    desc="Photos haute qualité aléatoires (Unsplash). Vérifié vivant.",
    params=[("largeur", "800", "largeur"), ("hauteur", "600", "hauteur")],
    run=imgget("https://picsum.photos/{largeur}/{hauteur}.jpg", ext="jpg"),
    ping=lambda: http_req("https://picsum.photos/64/64", timeout=10)[0])
srv(id="ph-picsum-gray", nom="Picsum · noir & blanc", cat="IMAGES UTILES", acces="sans-clé", genre="image",
    desc="Variante grayscale.",
    params=[("largeur", "800", "largeur"), ("hauteur", "600", "hauteur")],
    run=imgget("https://picsum.photos/{largeur}/{hauteur}.jpg?grayscale", ext="jpg"),
    ping=lambda: http_req("https://picsum.photos/64/64?grayscale", timeout=10)[0])
srv(id="ph-picsum-blur", nom="Picsum · flou (fond nébuleuse)", cat="IMAGES UTILES", acces="sans-clé", genre="image",
    desc="Variante floue — idéale pour des fonds de slides.",
    params=[("largeur", "800", "largeur"), ("hauteur", "600", "hauteur")],
    run=imgget("https://picsum.photos/{largeur}/{hauteur}.jpg?blur=4", ext="jpg"),
    ping=lambda: http_req("https://picsum.photos/64/64?blur=2", timeout=10)[0])
srv(id="ph-placehold", nom="placehold.co · placeholder", cat="IMAGES UTILES", acces="sans-clé", genre="image",
    desc="Images placeholder personnalisées (texte, couleurs).",
    params=[("taille", "600x300", "taille"), ("texte", "NEXUS", "texte"), ("couleurs", "050510/00E5FF", "fond/texte hex")],
    run=imgget("https://placehold.co/{taille}/{couleurs}.png?text={texte_quote}"),
    ping=lambda: http_req("https://placehold.co/100x50.png", timeout=10)[0])
srv(id="ph-loremflickr", nom="LoremFlickr · photo par mot-clé", cat="IMAGES UTILES", acces="sans-clé", genre="image",
    desc="Photos réelles Flickr filtrées par mot-clé.",
    params=[("largeur", "640", "largeur"), ("hauteur", "480", "hauteur"), ("motcle", "technology", "mot-clé")],
    run=imgget("https://loremflickr.com/{largeur}/{hauteur}/{motcle}", ext="jpg"),
    ping=lambda: http_req("https://loremflickr.com/64/64/cat", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  QR & CODES-BARRES (3)
# ─────────────────────────────────────────────────────────────────────
srv(id="qr-goqr", nom="QR Code (goqr.me)", cat="QR & CODES-BARRES", acces="sans-clé", genre="image",
    desc="Générateur QR gratuit. Vérifié vivant.",
    params=[("data", "https://github.com/", "contenu"), ("taille", "300x300", "taille")],
    run=imgget("https://api.qrserver.com/v1/create-qr-code/?data={data_quote}&size={taille}"),
    ping=lambda: http_req("https://api.qrserver.com/v1/create-qr-code/?data=ok&size=64x64", timeout=10)[0])
srv(id="qr-quickchart", nom="QR Code (QuickChart)", cat="QR & CODES-BARRES", acces="sans-clé", genre="image",
    desc="Variante QuickChart, marge et couleurs réglables.",
    params=[("data", "NEXUS GEN HUB", "contenu"), ("taille", "300", "taille px")],
    run=imgget("https://quickchart.io/qr?text={data_quote}&size={taille}&dark=050510&light=ffffff"),
    ping=lambda: http_req("https://quickchart.io/qr?text=ok&size=64", timeout=10)[0])
srv(id="bc-tec-it", nom="Code-barres (TEC-IT)", cat="QR & CODES-BARRES", acces="sans-clé", genre="image",
    desc="EAN, UPC, Code128… gratuit depuis 1996.",
    params=[("data", "4006381333931", "données"), ("type", "EAN13", "type (EAN13, Code128, QRCode…)")],
    run=imgget("https://barcode.tec-it.com/barcode.ashx?data={data_quote}&code={type}&translate-esc=on"),
    ping=lambda: http_req("https://barcode.tec-it.com/barcode.ashx?data=123&code=Code128", timeout=10)[0])

# ─────────────────────────────────────────────────────────────────────
#  GRAPHIQUES & DATA (3)
# ─────────────────────────────────────────────────────────────────────
def _quickchart(p):
    cfg = {"type": p.get("type", "bar"),
           "data": {"labels": [x.strip() for x in p.get("labels", "A,B,C").split(",")],
                    "datasets": [{"label": p.get("titre", "Série"), "data": [float(x) for x in p.get("valeurs", "12,29,7").split(",")]}]},
           "options": {"title": {"display": True, "text": p.get("titre", "NEXUS Chart")}, "plugins": {"backgroundColor": "rgba(5,5,16,0.9)"}}}
    st, b, u = http_req("https://quickchart.io/chart?c=" + _q(json.dumps(cfg)) + "&w=700&h=400", timeout=30)
    if st >= 400 or len(b) < 300:
        return R("image", ok=False, info="HTTP %s" % st, status=st)
    return R("image", path=save_out(ts_name() + ".png", b), status=st, info="QuickChart — vérifié vivant", url=u)

srv(id="g-quickchart", nom="QuickChart · graphiques Chart.js", cat="GRAPHIQUES & DATA", acces="sans-clé", genre="image",
    desc="N'importe quel graphique Chart.js en PNG, sans clé. Vérifié vivant.",
    params=[("type", "bar", "type (bar, line, pie, doughnut, radar)"), ("labels", "Jan,Fév,Mar", "labels séparés par ,"),
            ("valeurs", "12,29,7", "valeurs séparées par ,"), ("titre", "Mes données", "titre")],
    run=_quickchart,
    ping=lambda: http_req("https://quickchart.io/chart?c={type:'bar',data:{labels:['a'],datasets:[{data:[1]}]}}", timeout=12)[0])
srv(id="g-imagecharts", nom="Image-Charts", cat="GRAPHIQUES & DATA", acces="sans-clé", genre="image",
    desc="Ancien Google Chart API ressuscité, gratuit avec filigrane.",
    params=[("valeurs", "60,35,90", "valeurs chd=t:"), ("labels", "A|B|C", "labels chl (séparés par |)"), ("type", "bvg", "cht (bvg, lc, p3)")],
    run=imgget("https://image-charts.com/chart?chs=700x400&cht={type}&chd=t:{valeurs}&chl={labels_quote}&chco=00E5FF,FF00C8,00FF88"),
    ping=lambda: http_req("https://image-charts.com/chart?chs=100x60&cht=bvg&chd=t:1,2", timeout=12)[0])
srv(id="g-chartsets", nom="QuickChart · sparklines", cat="GRAPHIQUES & DATA", acces="sans-clé", genre="image",
    desc="Micro-graphiques (sparklines) pour dashboards et emails.",
    params=[("valeurs", "5,9,4,12,8,15", "valeurs")],
    run=imgget("https://quickchart.io/chart?c=%7Btype:'sparkline',data:%7Bdatasets:%5B%7Bdata:%5B{valeurs}%5D%7D%5D%7D%7D"),
    ping=lambda: http_req("https://quickchart.io/chart?c={type:'sparkline',data:{datasets:[{data:[1,2]}]}}", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  DIAGRAMMES (3)
# ─────────────────────────────────────────────────────────────────────
def _mermaid(p):
    code = p.get("code", "graph TD; A[NEXUS] --> B[GEN HUB]; B --> C{142 services}")
    b64 = base64.urlsafe_b64encode(code.encode("utf-8")).decode("ascii")
    st, b, u = http_req("https://mermaid.ink/img/" + b64 + "?type=png&theme=dark", timeout=40)
    if st >= 400 or len(b) < 300:
        return R("image", ok=False, info="HTTP %s" % st, status=st)
    return R("image", path=save_out(ts_name() + ".png", b), status=st, info="mermaid.ink — vérifié vivant", url=u)

srv(id="d-mermaid", nom="Mermaid Ink · diagrammes", cat="DIAGRAMMES", acces="sans-clé", genre="image",
    desc="Graphes, séquences, Gantt… depuis du texte Mermaid. Vérifié vivant.",
    params=[("code", "graph TD; A[NEXUS] --> B[GEN HUB]; B --> C{142 services}", "code Mermaid")],
    run=_mermaid,
    ping=lambda: http_req("https://mermaid.ink/img/" + base64.urlsafe_b64encode(b"graph TD;A-->B").decode(), timeout=15)[0])


def _kroki(p):
    moteur = p.get("moteur", "plantuml")
    st, b, u = http_req("https://kroki.io/%s/png" % moteur, method="POST",
                        headers={"Content-Type": "text/plain"}, data=p.get("code", "digraph{A->B}"), timeout=45)
    if st >= 400 or len(b) < 200:
        return R("image", ok=False, info="HTTP %s — syntaxe %s invalide ?" % (st, moteur), status=st)
    return R("image", path=save_out(ts_name() + ".png", b), status=st, info="kroki.io (" + moteur + ")", url=u)

srv(id="d-kroki", nom="Kroki · 25 moteurs de diagrammes", cat="DIAGRAMMES", acces="sans-clé", genre="image",
    desc="PlantUML, Graphviz, D2, Mermaid, ditaa… un seul endpoint open-source.",
    params=[("moteur", "plantuml", "moteur (plantuml, graphviz, d2, mermaid…)"), ("code", "@startuml\nNEXUS -> Hub\n@enduml", "code source")],
    run=_kroki,
    ping=lambda: http_req("https://kroki.io/graphviz/png", method="POST", data=b"digraph{A->B}", timeout=15)[0])


def _plantuml(p):
    code = p.get("code", "@startuml\nNEXUS -> Investisseur: demo\n@enduml")
    hexcode = code.encode("utf-8").hex()
    st, b, u = http_req("https://www.plantuml.com/plantuml/png/~h" + hexcode, timeout=45)
    if st >= 400 or len(b) < 300:
        return R("image", ok=False, info="HTTP %s" % st, status=st)
    return R("image", path=save_out(ts_name() + ".png", b), status=st, info="plantuml.com (~h hex)", url=u)

srv(id="d-plantuml", nom="PlantUML (serveur officiel)", cat="DIAGRAMMES", acces="sans-clé", genre="image",
    desc="Serveur officiel plantuml.com, encodage hex direct (~h) : zéro dépendance.",
    params=[("code", "@startuml\nNEXUS -> Investisseur: demo reel\n@enduml", "code PlantUML")],
    run=_plantuml,
    ping=lambda: http_req("https://www.plantuml.com/plantuml/png/~h" + b"@startuml\nA->B\n@enduml".hex(), timeout=15)[0])

# ─────────────────────────────────────────────────────────────────────
#  GÉO & CARTES (6)
# ─────────────────────────────────────────────────────────────────────
srv(id="geo-nominatim", nom="Nominatim · géocodage OSM", cat="GÉO & CARTES", acces="sans-clé", genre="json",
    desc="Adresse → coordonnées, OpenStreetMap officiel.",
    params=[("adresse", "Tour Eiffel, Paris", "adresse"), ("limite", "3", "résultats max")],
    run=jget("https://nominatim.openstreetmap.org/search?q={adresse_quote}&format=json&limit={limite}"),
    ping=lambda: http_req("https://nominatim.openstreetmap.org/search?q=paris&format=json&limit=1", timeout=12)[0])
srv(id="geo-photon", nom="Photon · géocodage komoot", cat="GÉO & CARTES", acces="sans-clé", genre="json",
    desc="Géocodage rapide et typographique tolerant.",
    params=[("adresse", "Lyon", "adresse"), ("limite", "3", "résultats")],
    run=jget("https://photon.komoot.io/api/?q={adresse_quote}&limit={limite}"),
    ping=lambda: http_req("https://photon.komoot.io/api/?q=paris&limit=1", timeout=12)[0])
srv(id="geo-osrm", nom="OSRM · itinéraires routiers", cat="GÉO & CARTES", acces="sans-clé", genre="json",
    desc="Distance et durée entre deux points (serveur public OSRM).",
    params=[("de", "2.3522,48.8566", "lon,lat départ"), ("vers", "4.8357,45.7640", "lon,lat arrivée")],
    run=jget("https://router.project-osrm.org/route/v1/driving/{de};{vers}?overview=false", pick="routes.0.duration"),
    ping=lambda: http_req("https://router.project-osrm.org/route/v1/driving/2.3,48.8;2.4,48.9?overview=false", timeout=12)[0])
srv(id="geo-overpass", nom="Overpass · requêtes OpenStreetMap", cat="GÉO & CARTES", acces="sans-clé", genre="json",
    desc="Interroge TOUT OpenStreetMap (cafés autour d'un point…). Lent mais puissant.",
    params=[("requete", 'node["amenity"="cafe"](48.85,2.29,48.87,2.32);', "requête Overpass QL")],
    run=lambda p: _overpass(p),
    ping=lambda: http_req("https://overpass-api.de/api/status", timeout=12)[0])


def _overpass(p):
    q = "[out:json][timeout:25];" + p.get("requete", 'node["amenity"="cafe"](48.85,2.29,48.87,2.32);') + "out body;"
    st, j, _ = http_json("https://overpass-api.de/api/interpreter", method="POST",
                         headers={"Content-Type": "application/x-www-form-urlencoded"},
                         data={"data": q}, timeout=70)
    if st >= 400 or j is None:
        return R("json", ok=False, info="HTTP %s (serveur public en charge — réessaie)" % st, status=st)
    els = (j.get("elements") or [])[:30]
    return R("json", status=st, text=json.dumps(els, ensure_ascii=False, indent=1)[:15000], info="%d éléments OSM" % len(els))

srv(id="geo-elevation", nom="Open-Elevation · altitudes", cat="GÉO & CARTES", acces="sans-clé", genre="json",
    desc="Altitude de n'importe quel point du globe.",
    params=[("points", "48.8584,2.2945", "lat,lon")],
    run=jget("https://api.open-elevation.com/api/v1/lookup?locations={points}"),
    ping=lambda: http_req("https://api.open-elevation.com/api/v1/lookup?locations=48.8,2.3", timeout=15)[0])
srv(id="geo-opentopo", nom="OpenTopoData · altitudes (DEM)", cat="GÉO & CARTES", acces="sans-clé", genre="json",
    desc="Altitudes via 40 jeux de données numériques de terrain.",
    params=[("dataset", "srtm90m", "dataset"), ("points", "48.8584,2.2945", "lat,lon")],
    run=jget("https://api.opentopodata.org/v1/{dataset}?locations={points}"),
    ping=lambda: http_req("https://api.opentopodata.org/v1/srtm90m?locations=48.8,2.3", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  MÉTÉO & ENVIRONNEMENT (6) — famille Open-Meteo, 100% sans-clé
# ─────────────────────────────────────────────────────────────────────
OM_P = [("latitude", "48.8566", "latitude"), ("longitude", "2.3522", "longitude")]
srv(id="wx-forecast", nom="Open-Meteo · prévisions", cat="MÉTÉO & ENVIRONNEMENT", acces="sans-clé", genre="json",
    desc="Prévisions 7 jours, heure par heure. Vérifié vivant.",
    params=OM_P, run=jget("https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&current=temperature_2m,wind_speed_10m&hourly=temperature_2m&forecast_days=3"),
    ping=lambda: http_req("https://api.open-meteo.com/v1/forecast?latitude=48.8&longitude=2.3&current=temperature_2m", timeout=10)[0])
srv(id="wx-historical", nom="Open-Meteo · archives 1940→", cat="MÉTÉO & ENVIRONNEMENT", acces="sans-clé", genre="json",
    desc="Météo historique depuis 1940.",
    params=OM_P, run=jget("https://archive-api.open-meteo.com/v1/archive?latitude={latitude}&longitude={longitude}&start_date=2024-01-01&end_date=2024-01-07&daily=temperature_2m_max"),
    ping=lambda: http_req("https://archive-api.open-meteo.com/v1/archive?latitude=48.8&longitude=2.3&start_date=2024-01-01&end_date=2024-01-02&daily=temperature_2m_max", timeout=12)[0])
srv(id="wx-air", nom="Open-Meteo · qualité de l'air", cat="MÉTÉO & ENVIRONNEMENT", acces="sans-clé", genre="json",
    desc="PM2.5, PM10, ozone, pollen en Europe.",
    params=OM_P, run=jget("https://air-quality-api.open-meteo.com/v1/air-quality?latitude={latitude}&longitude={longitude}&current=european_aqi,pm2_5"),
    ping=lambda: http_req("https://air-quality-api.open-meteo.com/v1/air-quality?latitude=48.8&longitude=2.3&current=european_aqi", timeout=10)[0])
srv(id="wx-marine", nom="Open-Meteo · marine", cat="MÉTÉO & ENVIRONNEMENT", acces="sans-clé", genre="json",
    desc="Vagues, houle, température de l'eau.",
    params=OM_P, run=jget("https://marine-api.open-meteo.com/v1/marine?latitude={latitude}&longitude={longitude}&current=wave_height"),
    ping=lambda: http_req("https://marine-api.open-meteo.com/v1/marine?latitude=48.8&longitude=-5.0&current=wave_height", timeout=12)[0])
srv(id="wx-flood", nom="Open-Meteo · crues (GloFAS)", cat="MÉTÉO & ENVIRONNEMENT", acces="sans-clé", genre="json",
    desc="Prévisions de débordement de rivière.",
    params=OM_P, run=jget("https://flood-api.open-meteo.com/v1/flood?latitude={latitude}&longitude={longitude}&daily=river_discharge"),
    ping=lambda: http_req("https://flood-api.open-meteo.com/v1/flood?latitude=48.8&longitude=2.3&daily=river_discharge", timeout=12)[0])
srv(id="wx-geocoding", nom="Open-Meteo · géocodage villes", cat="MÉTÉO & ENVIRONNEMENT", acces="sans-clé", genre="json",
    desc="Ville → coordonnées pour alimenter les autres services météo.",
    params=[("ville", "Marseille", "nom de ville")],
    run=jget("https://geocoding-api.open-meteo.com/v1/search?name={ville_quote}&count=3&language=fr"),
    ping=lambda: http_req("https://geocoding-api.open-meteo.com/v1/search?name=paris&count=1", timeout=10)[0])

# ─────────────────────────────────────────────────────────────────────
#  ESPACE (8)
# ─────────────────────────────────────────────────────────────────────
srv(id="sp-apod", nom="NASA · photo astronomique du jour", cat="ESPACE", acces="clé-gratuite", genre="json",
    desc="APOD quotidien. DEMO_KEY publique = 30 req/h partagées (clé perso gratuite recommandée).",
    params=[("cle", "DEMO_KEY", "clé API NASA")],
    run=jget("https://api.nasa.gov/planetary/apod?api_key={cle}"),
    ping=lambda: http_req("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY", timeout=12)[0])
srv(id="sp-neo", nom="NASA · astéroïdes proches", cat="ESPACE", acces="clé-gratuite", genre="json",
    desc=" objets géocroiseurs des 7 prochains jours.",
    params=[("cle", "DEMO_KEY", "clé API NASA")],
    run=jget("https://api.nasa.gov/neo/rest/v1/neo/browse?api_key={cle}"),
    ping=lambda: http_req("https://api.nasa.gov/neo/rest/v1/neo/browse?api_key=DEMO_KEY", timeout=12)[0])
srv(id="sp-iss-now", nom="Open Notify · position ISS", cat="ESPACE", acces="sans-clé", genre="json",
    desc="Où est la Station Spatiale Internationale, maintenant. Vérifié vivant.",
    params=[], run=jget("http://api.open-notify.org/iss-now.json"),
    ping=lambda: http_req("http://api.open-notify.org/iss-now.json", timeout=12)[0])
srv(id="sp-iss-crew", nom="Open Notify · astronautes en orbite", cat="ESPACE", acces="sans-clé", genre="json",
    desc="Qui est dans l'espace en ce moment.",
    params=[], run=jget("http://api.open-notify.org/astros.json"),
    ping=lambda: http_req("http://api.open-notify.org/astros.json", timeout=12)[0])
srv(id="sp-iss-where", nom="Where the ISS at?", cat="ESPACE", acces="sans-clé", genre="json",
    desc="Position ISS détaillée (vitesse, visibilité). Vérifié vivant.",
    params=[], run=jget("https://api.wheretheiss.at/v1/satellites/25544"),
    ping=lambda: http_req("https://api.wheretheiss.at/v1/satellites/25544", timeout=12)[0])
srv(id="sp-launches", nom="Launch Library 2 · prochains lancements", cat="ESPACE", acces="sans-clé", genre="json",
    desc="Tous les lancements spatiaux à venir (SpaceX, Ariane…). Vérifié vivant.",
    params=[("limite", "3", "nombre")],
    run=jget("https://ll.thespacedevs.com/2.2.0/launch/upcoming/?limit={limite}"),
    ping=lambda: http_req("https://ll.thespacedevs.com/2.2.0/launch/upcoming/?limit=1", timeout=15)[0])
srv(id="sp-usgs", nom="USGS · séismes du jour", cat="ESPACE", acces="sans-clé", genre="json",
    desc="Tous les séismes des dernières 24h, monde entier. Vérifié vivant.",
    params=[("min_mag", "2.5", "magnitude min (all_day = 0)")],
    run=jget("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/{min_mag}_day.geojson"),
    ping=lambda: http_req("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson", timeout=15)[0])
srv(id="sp-opensky", nom="OpenSky · avions en vol", cat="ESPACE", acces="sans-clé", genre="json",
    desc="ADS-B réel : tous les avions autour de toi (anonyme, limité).",
    params=[("lamin", "48.6", "lat min"), ("lomin", "2.1", "lon min"), ("lamax", "49.0", "lat max"), ("lomax", "2.6", "lon max")],
    run=jget("https://opensky-network.org/api/states/all?lamin={lamin}&lomin={lomin}&lamax={lamax}&lomax={lomax}"),
    ping=lambda: http_req("https://opensky-network.org/api/states/all?lamin=48.6&lomin=2.1&lamax=48.7&lomax=2.2", timeout=15)[0])

# ─────────────────────────────────────────────────────────────────────
#  FINANCE & CRYPTO (6)
# ─────────────────────────────────────────────────────────────────────
srv(id="fi-frankfurter", nom="Frankfurter · devises BCE", cat="FINANCE & CRYPTO", acces="sans-clé", genre="json",
    desc="Taux de change officiels BCE, gratuit.",
    params=[("de", "EUR", "devise source"), ("vers", "USD,CHF", "cibles")],
    run=jget("https://api.frankfurter.app/latest?from={de}&to={vers}"),
    ping=lambda: http_req("https://api.frankfurter.app/latest?from=EUR&to=USD", timeout=10)[0])
srv(id="fi-coingecko", nom="CoinGecko · prix crypto", cat="FINANCE & CRYPTO", acces="sans-clé", genre="json",
    desc="Prix en direct (limité sans clé : 30 req/min).",
    params=[("ids", "bitcoin,ethereum", "ids crypto"), ("vs", "eur", "devise")],
    run=jget("https://api.coingecko.com/api/v3/simple/price?ids={ids_quote}&vs_currencies={vs}"),
    ping=lambda: http_req("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=eur", timeout=12)[0])
srv(id="fi-coinlore", nom="CoinLore · tickers crypto", cat="FINANCE & CRYPTO", acces="sans-clé", genre="json",
    desc="Top 100 cryptos, aucune limite stricte. Vérifié vivant.",
    params=[("debut", "0", "début"), ("limite", "10", "limite")],
    run=jget("https://api.coinlore.net/api/tickers/?start={debut}&limit={limite}"),
    ping=lambda: http_req("https://api.coinlore.net/api/tickers/?start=0&limit=1", timeout=10)[0])
srv(id="fi-coinpaprika", nom="CoinPaprika · marché crypto", cat="FINANCE & CRYPTO", acces="sans-clé", genre="json",
    desc="Données de marché détaillées. Vérifié vivant.",
    params=[("limite", "5", "limite")],
    run=jget("https://api.coinpaprika.com/v1/tickers?limit={limite}"),
    ping=lambda: http_req("https://api.coinpaprika.com/v1/tickers?limit=1", timeout=12)[0])
srv(id="fi-blockstream", nom="Blockstream · blockchain Bitcoin", cat="FINANCE & CRYPTO", acces="sans-clé", genre="json",
    desc="Hauteur de bloc, transactions BTC. Vérifié vivant.",
    params=[("adresse", "bc1q…", "adresse BTC (optionnel)")],
    run=jget("https://blockstream.info/api/blocks/tip/height"),
    ping=lambda: http_req("https://blockstream.info/api/blocks/tip/height", timeout=12)[0])
srv(id="fi-blockchaininfo", nom="Blockchain.info · ticker BTC", cat="FINANCE & CRYPTO", acces="sans-clé", genre="json",
    desc="Cours BTC toutes devises.",
    params=[], run=jget("https://blockchain.info/ticker"),
    ping=lambda: http_req("https://blockchain.info/ticker", timeout=15)[0])
NS3
ok "nexus_services.py — images utiles, QR, graphiques, diagrammes, géo, météo, espace, finance"

# ════════════════════════════════════════════════════════════════════
#  PARTIE D — nexus_services.py (4/4) : connaissance, musique, outils…
# ════════════════════════════════════════════════════════════════════

cat >> "$APP_DIR/nexus_services.py" <<'NS4'

# ─────────────────────────────────────────────────────────────────────
#  CONNAISSANCE & SCIENCE (12)
# ─────────────────────────────────────────────────────────────────────
srv(id="kn-wiki-search", nom="Wikipédia · recherche", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="Recherche plein texte Wikipédia FR.",
    params=[("q", "intelligence artificielle", "recherche"), ("limite", "5", "résultats")],
    run=jget("https://fr.wikipedia.org/w/api.php?action=query&list=search&srsearch={q_quote}&srlimit={limite}&format=json"),
    ping=lambda: http_req("https://fr.wikipedia.org/w/api.php?action=query&list=search&srsearch=test&srlimit=1&format=json", timeout=12)[0])
srv(id="kn-wiki-summary", nom="Wikipédia · résumé REST", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="Résumé propre d'une page (REST v1).",
    params=[("page", "France", "titre de page")],
    run=jget("https://fr.wikipedia.org/api/rest_v1/page/summary/{page_quote}"),
    ping=lambda: http_req("https://fr.wikipedia.org/api/rest_v1/page/summary/France", timeout=12)[0])
srv(id="kn-ddg", nom="DuckDuckGo · Instant Answers", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="Réponses instantanées DuckDuckGo, sans clé.",
    params=[("q", "github", "question")],
    run=jget("https://api.duckduckgo.com/?q={q_quote}&format=json&no_html=1"),
    ping=lambda: http_req("https://api.duckduckgo.com/?q=test&format=json", timeout=12)[0])
srv(id="kn-openalex", nom="OpenAlex · 250M travaux scientifiques", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="Le catalogue scientifique ouvert (successeur de Microsoft Academic).",
    params=[("q", "fusion nucléaire", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://api.openalex.org/works?search={q_quote}&per-page={limite}&mailto=nexus@local"),
    ping=lambda: http_req("https://api.openalex.org/works?search=test&per-page=1", timeout=12)[0])
srv(id="kn-crossref", nom="Crossref · 150M DOI", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="Métadonnées de publications académiques. Vérifié vivant.",
    params=[("q", "quantum", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://api.crossref.org/works?query={q_quote}&rows={limite}"),
    ping=lambda: http_req("https://api.crossref.org/works?query=test&rows=1", timeout=12)[0])
srv(id="kn-arxiv", nom="arXiv · preprints", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="texte",
    desc="Papiers scientifiques bruts (XML Atom).",
    params=[("q", "all:electron", "recherche"), ("limite", "3", "résultats")],
    run=tget("http://export.arxiv.org/api/query?search_query=all:{q_quote}&max_results={limite}"),
    ping=lambda: http_req("http://export.arxiv.org/api/query?search_query=all:test&max_results=1", timeout=15)[0])
srv(id="kn-semantic", nom="Semantic Scholar", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="200M+ papiers avec citations (limite anonyme).",
    params=[("q", "transformer model", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://api.semanticscholar.org/graph/v1/paper/search?query={q_quote}&limit={limite}&fields=title,year,authors,citationCount"),
    ping=lambda: http_req("https://api.semanticscholar.org/graph/v1/paper/search?query=test&limit=1", timeout=12)[0])
srv(id="kn-pubmed", nom="PubMed · médecine", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="35M références biomédicales. Vérifié vivant.",
    params=[("q", "crispr", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term={q_quote}&retmax={limite}&retmode=json"),
    ping=lambda: http_req("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=test&retmode=json", timeout=12)[0])
srv(id="kn-europepmc", nom="Europe PMC · biomedical open", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="Texte intégral de publications biosciences.",
    params=[("q", "protein folding", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://www.ebi.ac.uk/europepmc/webservices/rest/search?query={q_quote}&format=json&pageSize={limite}"),
    ping=lambda: http_req("https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=test&format=json&pageSize=1", timeout=12)[0])
srv(id="kn-openlibrary", nom="Open Library · livres", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="20M+ livres (Internet Archive).",
    params=[("q", "dune", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://openlibrary.org/search.json?q={q_quote}&limit={limite}"),
    ping=lambda: http_req("https://openlibrary.org/search.json?q=dune&limit=1", timeout=15)[0])
srv(id="kn-gbooks", nom="Google Books", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="40M+ livres numérisés.",
    params=[("q", "verne", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://www.googleapis.com/books/v1/volumes?q={q_quote}&maxResults={limite}"),
    ping=lambda: http_req("https://www.googleapis.com/books/v1/volumes?q=test", timeout=12)[0])
srv(id="kn-archive", nom="Internet Archive", cat="CONNAISSANCE & SCIENCE", acces="sans-clé", genre="json",
    desc="Tout le fonds d'archive.org (vidéo, audio, textes).",
    params=[("q", "moon landing", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://archive.org/advancedsearch.php?q={q_quote}&rows={limite}&output=json"),
    ping=lambda: http_req("https://archive.org/advancedsearch.php?q=test&rows=1&output=json", timeout=15)[0])

# ─────────────────────────────────────────────────────────────────────
#  DÉV & PAQUETS (10)
# ─────────────────────────────────────────────────────────────────────
srv(id="dv-github", nom="GitHub · recherche repos", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="API GitHub anonyme (60 req/h). Chez toi : OK.",
    params=[("q", "libp2p", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://api.github.com/search/repositories?q={q_quote}&per_page={limite}"),
    ping=lambda: http_req("https://api.github.com/rate_limit", timeout=10)[0])
srv(id="dv-npm", nom="npm registry", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Métadonnées de tout package npm. Vérifié vivant.",
    params=[("paquet", "react", "nom du package")],
    run=jget("https://registry.npmjs.org/{paquet}"),
    ping=lambda: http_req("https://registry.npmjs.org/react", timeout=12)[0])
srv(id="dv-pypi", nom="PyPI", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Packages Python. Vérifié vivant.",
    params=[("paquet", "requests", "nom du package")],
    run=jget("https://pypi.org/pypi/{paquet}/json"),
    ping=lambda: http_req("https://pypi.org/pypi/requests/json", timeout=12)[0])
srv(id="dv-crates", nom="crates.io · Rust", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Écosystème Rust. Vérifié vivant.",
    params=[("paquet", "tokio", "nom du crate")],
    run=jget("https://crates.io/api/v1/crates/{paquet}"),
    ping=lambda: http_req("https://crates.io/api/v1/crates/serde", timeout=12)[0])
srv(id="dv-maven", nom="Maven Central · Java", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Recherche de jars. Vérifié vivant.",
    params=[("q", "guice", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://search.maven.org/solrsearch/select?q={q_quote}&rows={limite}&wt=json"),
    ping=lambda: http_req("https://search.maven.org/solrsearch/select?q=guice&rows=1&wt=json", timeout=12)[0])
srv(id="dv-packagist", nom="Packagist · PHP", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="L'écosystème Composer.",
    params=[("paquet", "symfony/console", "vendor/package")],
    run=jget("https://repo.packagist.org/p2/{paquet}.json"),
    ping=lambda: http_req("https://repo.packagist.org/p2/symfony/console.json", timeout=12)[0])
srv(id="dv-rubygems", nom="RubyGems", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Gems Ruby. Vérifié vivant.",
    params=[("paquet", "rails", "nom de la gem")],
    run=jget("https://rubygems.org/api/v1/gems/{paquet}.json"),
    ping=lambda: http_req("https://rubygems.org/api/v1/gems/rails.json", timeout=12)[0])
srv(id="dv-nuget", nom="NuGet · .NET", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Recherche de packages C#. Vérifié vivant.",
    params=[("q", "newtonsoft", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://azuresearch-usnc.nuget.org/query?q={q_quote}&take={limite}"),
    ping=lambda: http_req("https://azuresearch-usnc.nuget.org/query?q=x&take=1", timeout=12)[0])
srv(id="dv-dockerhub", nom="Docker Hub", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Stats et tags d'images officielles. Vérifié vivant.",
    params=[("image", "alpine", "image library/")],
    run=jget("https://hub.docker.com/v2/repositories/library/{image}/"),
    ping=lambda: http_req("https://hub.docker.com/v2/repositories/library/alpine/", timeout=12)[0])
srv(id="dv-jsdelivr", nom="jsDelivr · packages CDN", cat="DÉV & PAQUETS", acces="sans-clé", genre="json",
    desc="Versions et fichiers CDN d'un package. Vérifié vivant.",
    params=[("paquet", "react", "package npm")],
    run=jget("https://data.jsdelivr.com/v1/packages/npm/{paquet}"),
    ping=lambda: http_req("https://data.jsdelivr.com/v1/packages/npm/react", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  MUSIQUE (6)
# ─────────────────────────────────────────────────────────────────────
srv(id="mu-itunes", nom="iTunes Search", cat="MUSIQUE", acces="sans-clé", genre="json",
    desc="Musique, films, podcasts + extraits 30s jouables. Vérifié vivant.",
    params=[("q", "daft punk", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://itunes.apple.com/search?term={q_quote}&limit={limite}"),
    ping=lambda: http_req("https://itunes.apple.com/search?term=test&limit=1", timeout=12)[0])
srv(id="mu-musicbrainz", nom="MusicBrainz", cat="MUSIQUE", acces="sans-clé", genre="json",
    desc="L'encyclopédie musicale ouverte (Whosampled, Spotify l'utilisent).",
    params=[("q", "one more time", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://musicbrainz.org/ws/2/recording/?query={q_quote}&fmt=json&limit={limite}"),
    ping=lambda: http_req("https://musicbrainz.org/ws/2/recording/?query=test&fmt=json&limit=1", timeout=12)[0])
srv(id="mu-deezer", nom="Deezer", cat="MUSIQUE", acces="sans-clé", genre="json",
    desc="Recherche + extraits 30s (API publique Deezer).",
    params=[("q", "harder better", "recherche"), ("limite", "3", "résultats")],
    run=jget("https://api.deezer.com/search?q={q_quote}&limit={limite}"),
    ping=lambda: http_req("https://api.deezer.com/search?q=test&limit=1", timeout=12)[0])
srv(id="mu-radio", nom="Radio Browser", cat="MUSIQUE", acces="sans-clé", genre="json",
    desc="50 000 radios du monde entier. Vérifié vivant.",
    params=[("q", "jazz", "nom de station"), ("limite", "5", "résultats")],
    run=jget("https://de1.api.radio-browser.info/json/stations/search?name={q_quote}&limit={limite}"),
    ping=lambda: http_req("https://de1.api.radio-browser.info/json/stations/search?name=jazz&limit=1", timeout=12)[0])
srv(id="mu-lrclib", nom="LRCLIB · paroles synchronisées", cat="MUSIQUE", acces="sans-clé", genre="json",
    desc="Paroles + LRC synchronisé, open-source. Vérifié vivant.",
    params=[("q", "creep radiohead", "recherche")],
    run=jget("https://lrclib.net/api/search?q={q_quote}&limit=3"),
    ping=lambda: http_req("https://lrclib.net/api/search?q=test&limit=1", timeout=12)[0])
srv(id="mu-coverart", nom="Cover Art Archive", cat="MUSIQUE", acces="sans-clé", genre="json",
    desc="Pochettes d'albums liées à MusicBrainz (paramètre = un MBID).",
    params=[("mbid", "9d7ec4fc-e542-4d1e-b0a5-2b2f4e5a4f5a", "MusicBrainz ID de release-group")],
    run=jget("https://coverartarchive.org/release-group/{mbid}"),
    ping=lambda: http_req("https://coverartarchive.org/", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  CONTENU & FUN (10)
# ─────────────────────────────────────────────────────────────────────
srv(id="fn-jokeapi", nom="JokeAPI v2", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Blagues en EN/FR filtrables (safe-mode inclus).",
    params=[("langue", "fr", "langue (fr, en)")],
    run=jget("https://v2.jokeapi.dev/joke/Any?safe-mode&lang={langue}"),
    ping=lambda: http_req("https://v2.jokeapi.dev/joke/Any?safe-mode", timeout=12)[0])
srv(id="fn-dadjoke", nom="icanhazdadjoke", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="La référence mondiale des blagues de papa.",
    params=[], run=jget("https://icanhazdadjoke.com/", headers={"Accept": "application/json"}),
    ping=lambda: http_req("https://icanhazdadjoke.com/", headers={"Accept": "application/json"}, timeout=12)[0])
srv(id="fn-chuck", nom="Chuck Norris API", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Fact aléatoire. Vérifié vivant.",
    params=[], run=jget("https://api.chucknorris.io/jokes/random"),
    ping=lambda: http_req("https://api.chucknorris.io/jokes/random", timeout=12)[0])
srv(id="fn-zenquotes", nom="ZenQuotes", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Citation inspirante du jour.",
    params=[], run=jget("https://zenquotes.io/api/random"),
    ping=lambda: http_req("https://zenquotes.io/api/random", timeout=12)[0])
srv(id="fn-quotable", nom="Quotable", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Citations filtrables par auteur/tags.",
    params=[("auteur", "einstein", "auteur (slug)")],
    run=jget("https://api.quotable.io/random?author={auteur}"),
    ping=lambda: http_req("https://api.quotable.io/random", timeout=12)[0])
srv(id="fn-advice", nom="Advice Slip", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Un conseil aléatoire (ou par id).",
    params=[], run=jget("https://api.adviceslip.com/advice"),
    ping=lambda: http_req("https://api.adviceslip.com/advice", timeout=12)[0])
srv(id="fn-catfacts", nom="Cat Facts", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Facts sur les chats, pour les démos qui marquent.",
    params=[], run=jget("https://catfact.ninja/fact"),
    ping=lambda: http_req("https://catfact.ninja/fact", timeout=12)[0])
srv(id="fn-dogceo", nom="Dog CEO · photos de chiens", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Photos de chiens aléatoires (image + URL).",
    params=[], run=jget("https://dog.ceo/api/breeds/image/random"),
    ping=lambda: http_req("https://dog.ceo/api/breeds/image/random", timeout=12)[0])
srv(id="fn-randomuser", nom="RandomUser · identités factices", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Profils factices complets (tests, seed data). Vérifié vivant.",
    params=[("nombre", "3", "nombre de profils")],
    run=jget("https://randomuser.me/api/?results={nombre}"),
    ping=lambda: http_req("https://randomuser.me/api/", timeout=12)[0])
srv(id="fn-dummyjson", nom="DummyJSON · données factices", cat="CONTENU & FUN", acces="sans-clé", genre="json",
    desc="Produits, paniers, utilisateurs, quotes… pour maquettes. Vérifié vivant.",
    params=[("ressource", "products/1", "ressource (products, users, carts…)")],
    run=jget("https://dummyjson.com/{ressource}"),
    ping=lambda: http_req("https://dummyjson.com/products/1", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  DÉMOGRAPHIE (4)
# ─────────────────────────────────────────────────────────────────────
srv(id="nm-genderize", nom="Genderize · genre d'un prénom", cat="DÉMOGRAPHIE", acces="sans-clé", genre="json",
    desc="Probabilité de genre par prénom. Vérifié vivant.",
    params=[("prenom", "camille", "prénom")],
    run=jget("https://api.genderize.io?name={prenom}"),
    ping=lambda: http_req("https://api.genderize.io?name=alex", timeout=12)[0])
srv(id="nm-agify", nom="Agify · âge estimé", cat="DÉMOGRAPHIE", acces="sans-clé", genre="json",
    desc="Âge moyen estimé d'un prénom.",
    params=[("prenom", "emma", "prénom")],
    run=jget("https://api.agify.io?name={prenom}"),
    ping=lambda: http_req("https://api.agify.io?name=alex", timeout=12)[0])
srv(id="nm-nationalize", nom="Nationalize · nationalité estimée", cat="DÉMOGRAPHIE", acces="sans-clé", genre="json",
    desc="Probabilités de nationalité d'un prénom.",
    params=[("prenom", "lucas", "prénom")],
    run=jget("https://api.nationalize.io?name={prenom}"),
    ping=lambda: http_req("https://api.nationalize.io?name=alex", timeout=12)[0])
srv(id="nm-universities", nom="Universités du monde", cat="DÉMOGRAPHIE", acces="sans-clé", genre="json",
    desc="Base mondiale des universités (Hipolabs).",
    params=[("nom", "lyon", "nom (partiel)")],
    run=jget("http://universities.hipolabs.com/search?name={nom}"),
    ping=lambda: http_req("http://universities.hipolabs.com/search?name=paris", timeout=15)[0])

# ─────────────────────────────────────────────────────────────────────
#  COULEURS IA (2)
# ─────────────────────────────────────────────────────────────────────
def _colormind(p):
    model = p.get("modele", "default")
    st, j, _ = http_json("https://colormind.io/api/", method="POST",
                         headers={"Content-Type": "application/json"},
                         data=json.dumps({"model": model, "input": []}), timeout=25)
    if st >= 400 or not j or "result" not in j:
        return R("json", ok=False, info="HTTP %s" % st, status=st)
    lines = ["#%02X%02X%02X" % tuple(c) for c in j["result"]]
    return R("json", status=st, text="Palette IA (%s) :\n%s" % (model, "\n".join(lines)), info="colormind.io")

srv(id="cl-colormind", nom="Colormind · palettes par IA", cat="COULEURS IA", acces="sans-clé", genre="json",
    desc="Réseau neuronal qui invente des palettes harmonieuses.",
    params=[("modele", "default", "modèle (default, n, n_e, ui)")],
    run=_colormind,
    ping=lambda: http_req("https://colormind.io/list", timeout=12)[0])
srv(id="cl-thecolorapi", nom="The Color API · info couleur", cat="COULEURS IA", acces="sans-clé", genre="json",
    desc="Nom, conversion, schéma harmonique d'une couleur. Vérifié vivant.",
    params=[("hex", "00E5FF", "hex sans #")],
    run=jget("https://www.thecolorapi.com/id?hex={hex}"),
    ping=lambda: http_req("https://www.thecolorapi.com/id?hex=00E5FF", timeout=12)[0])

# ─────────────────────────────────────────────────────────────────────
#  OUTILS WEB & PARTAGE (6)
# ─────────────────────────────────────────────────────────────────────
srv(id="ow-thumio", nom="thum.io · capture de site", cat="OUTILS WEB & PARTAGE", acces="sans-clé", genre="image",
    desc="Screenshot de n'importe quelle URL, gratuit, sans clé.",
    params=[("url", "https://github.com", "URL du site"), ("largeur", "1024", "largeur")],
    run=imgget("https://image.thum.io/get/width/{largeur}/{url}", timeout=45),
    ping=lambda: http_req("https://image.thum.io/get/width/300/https://example.com", timeout=20)[0])
srv(id="ow-mshots", nom="WordPress mShots · capture", cat="OUTILS WEB & PARTAGE", acces="sans-clé", genre="image",
    desc="Seconde source de screenshots (infrastructure WordPress.com).",
    params=[("url", "https://example.com", "URL encodée"), ("largeur", "600", "largeur")],
    run=imgget("https://s0.wp.com/mshots/v1/{url_quote}?w={largeur}", timeout=45),
    ping=lambda: http_req("https://s0.wp.com/mshots/v1/https%3A%2F%2Fexample.com?w=100", timeout=20)[0])
srv(id="ow-0x0", nom="0x0.st · hébergement de fichiers", cat="OUTILS WEB & PARTAGE", acces="sans-clé", genre="texte",
    desc="Upload anonyme (jusqu'à 512 Mo) → URL publique. Respecte leurs règles.",
    params=[("texte", "Contenu à héberger depuis NEXUS GEN HUB", "contenu texte")],
    run=lambda p: _upload_0x0(p),
    ping=lambda: http_req("https://0x0.st/", timeout=12)[0])


def _upload_0x0(p):
    body, hdrs = _mp({}, [("file", ts_name() + ".txt", p.get("texte", "").encode("utf-8"))])
    st, b, _ = http_req("https://0x0.st", method="POST", headers=hdrs, data=body, timeout=40)
    if st >= 400:
        return R("texte", ok=False, info="HTTP %s (0x0.st bloque parfois les datacenters — chez toi OK)" % st, status=st)
    return R("texte", status=st, text=b.decode("utf-8", "replace").strip(), info="URL publique 0x0.st")

srv(id="ow-tmpfiles", nom="tmpfiles.org · partage temporaire", cat="OUTILS WEB & PARTAGE", acces="sans-clé", genre="json",
    desc="Fichier en ligne 60 min → lien direct /dl/.",
    params=[("texte", "{\"nexus\": \"genhub\", \"v\": 2}", "contenu JSON/texte")],
    run=lambda p: _upload_tmpfiles(p),
    ping=lambda: http_req("https://tmpfiles.org/", timeout=12)[0])


def _upload_tmpfiles(p):
    body, hdrs = _mp({}, [("file", ts_name() + ".json", p.get("texte", "").encode("utf-8"))])
    st, j, _ = http_json("https://tmpfiles.org/api/v1/upload", method="POST", headers=hdrs, data=body, timeout=40)
    if st >= 400 or not j or not j.get("data"):
        return R("json", ok=False, info="HTTP %s" % st, status=st)
    url = j["data"].get("url", "").replace("tmpfiles.org/", "tmpfiles.org/dl/")
    return R("json", status=st, text="Lien direct (60 min) : " + url)

srv(id="ow-dpaste", nom="dpaste.org · pastebin", cat="OUTILS WEB & PARTAGE", acces="sans-clé", genre="texte",
    desc="Colle du code en ligne, expiration réglable.",
    params=[("contenu", "print('hello from NEXUS GEN HUB')", "contenu"), ("jours", "7", "expiration (jours)")],
    run=lambda p: _dpaste(p),
    ping=lambda: http_req("https://dpaste.org/api/", method="POST", data={"raw": "test", "format": "url", "expiry_days": 1}, timeout=15)[0])


def _dpaste(p):
    st, b, u = http_req("https://dpaste.org/api/", method="POST",
                        data={"raw": p.get("contenu", ""), "format": "url", "expiry_days": p.get("jours", "7")}, timeout=30)
    if st >= 400:
        return R("texte", ok=False, info="HTTP %s" % st, status=st)
    return R("texte", status=st, text=(b.decode("utf-8", "replace").strip() or u).strip(), info="lien dpaste.org")

srv(id="ow-fileio", nom="file.io · lien éphémère", cat="OUTILS WEB & PARTAGE", acces="sans-clé", genre="json",
    desc="Lien qui s'auto-détruit après 1 téléchargement (privacy maximale).",
    params=[("texte", "Secret NEXUS — à lire une seule fois", "contenu")],
    run=lambda p: _fileio(p),
    ping=lambda: http_req("https://file.io/", timeout=12)[0])


def _fileio(p):
    body, hdrs = _mp({}, [("file", ts_name() + ".txt", p.get("texte", "").encode("utf-8"))])
    st, j, _ = http_json("https://file.io/?expires=1w", method="POST", headers=hdrs, data=body, timeout=40)
    if st >= 400 or not j or not j.get("link"):
        return R("json", ok=False, info="HTTP %s" % st, status=st)
    return R("json", status=st, text="Lien éphémère : " + j["link"])

# ─────────────────────────────────────────────────────────────────────
#  Plugins (extensions .py dans ~/.nexus-hub/plugins/)
# ─────────────────────────────────────────────────────────────────────
def load_plugins():
    d = os.path.join(HUB_DIR, "plugins")
    if not os.path.isdir(d):
        return []
    loaded = []
    for f in sorted(glob.glob(os.path.join(d, "*.py"))):
        try:
            ns = {"srv": srv, "SERVICES": SERVICES, "http_req": http_req, "http_json": http_json,
                  "imgget": imgget, "jget": jget, "tget": tget, "aget": aget, "R": R,
                  "save_out": save_out, "_q": _q, "_mp": _mp, "_fmt": _fmt,
                  "local_openai": local_openai, "port_ping": port_ping,
                  "__name__": "nexus_plugin_" + os.path.basename(f)[:-3]}
            exec(compile(open(f, encoding="utf-8").read(), f, "exec"), ns)
            loaded.append(os.path.basename(f))
        except Exception as e:
            print("[plugin] %s ignoré : %s" % (os.path.basename(f), e))
    return loaded

load_plugins()
N_SERVICES = len(SERVICES)
if N_SERVICES < 90:
    raise RuntimeError("Catalogue incomplet : %d services (≥90 requis)" % N_SERVICES)

# ─────────────────────────────────────────────────────────────────────
#  Batterie de test réelle
# ─────────────────────────────────────────────────────────────────────
def classify(st, url=""):
    if st == 0:
        return "réseau"
    if st in (200, 201, 202, 204, 206, 301, 302, 303):
        return "✓"
    if st == 405:
        return "✓ POST"
    if st in (401, 402, 403):
        return "clé"
    if st == 429:
        return "limite"
    if st == 404:
        return "✗ 404"
    return "HS %s" % st


def battery(services=None, workers=12, timeout=10, progress=None):
    svcs = list(services or SERVICES)
    results = []
    lock = threading.Lock()
    done = [0]
    total = len(svcs)

    def one(s):
        t0 = time.time()
        st = 0
        try:
            pf = s.get("ping")
            if callable(pf):
                st = pf()
            elif pf:
                try:
                    st, _, _ = http_req(_fmt(pf, {k: v for k, v, _ in s.get("params", [])}), timeout=timeout)
                except Exception:
                    st = 0
        except Exception:
            st = 0
        ms = int((time.time() - t0) * 1000)
        if s.get("acces") == "local":
            etat = "✓ local" if st == 200 else "éteint"
        else:
            etat = classify(st)
        item = {"id": s["id"], "nom": s["nom"], "cat": s["cat"], "acces": s["acces"], "etat": etat, "ms": ms}
        with lock:
            done[0] += 1
            if progress:
                try:
                    progress(done[0], total, item)
                except Exception:
                    pass
        return item

    with ThreadPoolExecutor(max_workers=workers) as ex:
        results = list(ex.map(one, svcs))
    return results


def battery_summary(results):
    from collections import Counter
    c = Counter(r["etat"] for r in results)
    return dict(c)


if __name__ == "__main__":
    import sys
    print("NEXUS GEN HUB — %d services réels chargés" % N_SERVICES)
    from collections import Counter
    c = Counter(s["acces"] for s in SERVICES)
    print("Répartition :", dict(c))
    if "--battery" in sys.argv:
        n = int(sys.argv[sys.argv.index("--battery") + 1]) if "--battery" in sys.argv and len(sys.argv) > sys.argv.index("--battery") + 1 else 12
        res = battery(SERVICES[:n] if n else None)
        print("\n%-26s %-34s %-12s %s" % ("ID", "SERVICE", "ACCÈS", "ÉTAT"))
        for r in res:
            print("%-26s %-34s %-12s %s (%d ms)" % (r["id"], r["nom"][:32], r["acces"], r["etat"], r["ms"]))
        print("\nSynthèse :", battery_summary(res))
NS4
ok "nexus_services.py — connaissance, dév, musique, fun, outils + batterie + plugins"

# ════════════════════════════════════════════════════════════════════
#  PARTIE E — nexus_llm.py : GÉNÉRATION IA réelle (cléless d'abord)
# ════════════════════════════════════════════════════════════════════

cat > "$APP_DIR/nexus_llm.py" <<'LLMF'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS GEN HUB — moteur de génération IA.
Priorité aux chaînes SANS CLÉ : Ollama local → Pollinations (GPT/Mistral/DeepSeek/Qwen).
Puis offres gratuites à clé : Groq, Mistral, Gemini, OpenRouter, GitHub Models…
Génère du YAML de workflow GitHub Actions réellement nouveau (aucun template pré-écrit).
"""
import json
import os
import re
import time
import urllib.error
import urllib.request

UA = "NEXUS-GenHub/2.0"


def _http(url, method="GET", headers=None, data=None, timeout=120):
    h = {"User-Agent": UA}
    if headers:
        h.update(headers)
    body = None
    if data is not None:
        body = data.encode("utf-8") if isinstance(data, str) else data
        h.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=body, headers=h, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.getcode(), r.read().decode("utf-8", "replace")


def _openai_chat(url, key, model, messages, timeout, extra=None):
    h = {"Content-Type": "application/json"}
    if key:
        h["Authorization"] = "Bearer " + key
    if extra:
        h.update(extra)
    st, txt = _http(url, method="POST", headers=h,
                    data=json.dumps({"model": model, "messages": messages}), timeout=timeout)
    if st >= 400:
        raise RuntimeError("HTTP %s : %s" % (st, txt[:200]))
    j = json.loads(txt)
    return j["choices"][0]["message"]["content"]


PROVIDERS = [
    {"id": "pollinations-openai", "nom": "Pollinations · GPT (SANS CLÉ)", "url": "https://text.pollinations.ai/openai", "model": "openai", "type": "keyless"},
    {"id": "pollinations-mistral", "nom": "Pollinations · Mistral (SANS CLÉ)", "url": "https://text.pollinations.ai/openai", "model": "mistral", "type": "keyless"},
    {"id": "pollinations-deepseek", "nom": "Pollinations · DeepSeek (SANS CLÉ)", "url": "https://text.pollinations.ai/openai", "model": "deepseek", "type": "keyless"},
    {"id": "pollinations-qwen-coder", "nom": "Pollinations · Qwen-Coder (SANS CLÉ)", "url": "https://text.pollinations.ai/openai", "model": "qwen-coder", "type": "keyless"},
    {"id": "ollama", "nom": "Ollama local", "url": "http://127.0.0.1:11434/api/chat", "model": "llama3", "type": "local"},
    {"id": "lmstudio", "nom": "LM Studio local", "url": "http://127.0.0.1:1234/v1/chat/completions", "model": "local-model", "type": "local"},
    {"id": "llamacpp", "nom": "llama.cpp local", "url": "http://127.0.0.1:8080/v1/chat/completions", "model": "local", "type": "local"},
    {"id": "groq", "nom": "Groq (clé gratuite)", "url": "https://api.groq.com/openai/v1/chat/completions", "model": "llama-3.3-70b-versatile", "type": "key", "env": "NEXUS_GROQ_KEY"},
    {"id": "mistral-api", "nom": "Mistral (clé gratuite)", "url": "https://api.mistral.ai/v1/chat/completions", "model": "mistral-small-latest", "type": "key", "env": "NEXUS_MISTRAL_KEY"},
    {"id": "gemini", "nom": "Gemini (clé gratuite)", "url": "https://generativelanguage.googleapis.com/v1beta", "model": "gemini-1.5-flash", "type": "gemini", "env": "NEXUS_GEMINI_KEY"},
    {"id": "openrouter", "nom": "OpenRouter :free (clé gratuite)", "url": "https://openrouter.ai/api/v1/chat/completions", "model": "meta-llama/llama-3.1-8b-instruct:free", "type": "key", "env": "NEXUS_OPENROUTER_KEY"},
    {"id": "github-models", "nom": "GitHub Models (token)", "url": "https://models.inference.ai.azure.com/chat/completions", "model": "gpt-4o-mini", "type": "key", "env": "NEXUS_GITHUB_TOKEN"},
    {"id": "cerebras", "nom": "Cerebras (clé gratuite)", "url": "https://api.cerebras.ai/v1/chat/completions", "model": "llama-3.3-70b", "type": "key", "env": "NEXUS_CEREBRAS_KEY"},
    {"id": "hf", "nom": "Hugging Face (token gratuit)", "url": "https://router.huggingface.co/v1/chat/completions", "model": "meta-llama/Llama-3.1-8B-Instruct", "type": "key", "env": "NEXUS_HF_KEY"},
]

AUTO_CHAIN = ["ollama", "pollinations-openai", "pollinations-mistral", "pollinations-deepseek", "pollinations-qwen-coder"]


def _by_pid(pid):
    for p in PROVIDERS:
        if p["id"] == pid:
            return p
    return None


def probe_ollama():
    try:
        st, _ = _http("http://127.0.0.1:11434/api/tags", timeout=2)
        return st == 200
    except Exception:
        return False


def chat_via(pid, messages, timeout=120):
    p = _by_pid(pid)
    if not p:
        raise RuntimeError("fournisseur inconnu : " + str(pid))
    if p["type"] in ("key", "keyless"):
        key = os.environ.get(p.get("env", ""), "")
        if p["type"] == "key" and not key:
            raise RuntimeError("clé absente — export %s=…" % p.get("env"))
        return _openai_chat(p["url"], key, p["model"], messages, timeout,
                            {"HTTP-Referer": "https://nexus.local", "X-Title": "NEXUS GenHub"} if pid == "openrouter" else None)
    if p["type"] == "gemini":
        key = os.environ.get(p.get("env", ""), "")
        if not key:
            raise RuntimeError("clé absente — export %s=…" % p.get("env"))
        sys_msgs = [m for m in messages if m["role"] == "system"]
        content_msgs = [m for m in messages if m["role"] != "system"]
        body = {"contents": [{"role": "user" if m["role"] == "user" else "model", "parts": [{"text": m["content"]}]} for m in content_msgs]}
        if sys_msgs:
            body["systemInstruction"] = {"parts": [{"text": sys_msgs[0]["content"]}]}
        st, txt = _http(p["url"] + "/models/" + p["model"] + ":generateContent?key=" + key,
                        method="POST", data=json.dumps(body), timeout=timeout)
        if st >= 400:
            raise RuntimeError("HTTP %s : %s" % (st, txt[:200]))
        j = json.loads(txt)
        return j["candidates"][0]["content"]["parts"][0]["text"]
    # local
    if p["type"] == "local":
        if pid == "ollama":
            st, txt = _http(p["url"], method="POST",
                            data=json.dumps({"model": p["model"], "messages": messages, "stream": False}), timeout=timeout)
            if st >= 400:
                raise RuntimeError("Ollama HTTP %s — lancé ? (ollama serve)" % st)
            return json.loads(txt)["message"]["content"]
        return _openai_chat(p["url"], "", p["model"], messages, timeout)
    raise RuntimeError("type inconnu")


def chat(messages, provider="auto", timeout=120):
    """Retourne (texte, provider_utilisé). Essaie la chaîne auto en cascade."""
    chain = [provider] if provider != "auto" else AUTO_CHAIN
    if provider == "auto" and not probe_ollama():
        chain = [c for c in chain if c != "ollama"]
    erreurs = []
    for pid in chain:
        try:
            t0 = time.time()
            txt = chat_via(pid, messages, timeout=timeout)
            if txt and txt.strip():
                return txt.strip(), pid, round(time.time() - t0, 1)
        except Exception as e:
            erreurs.append("%s: %s" % (pid, str(e)[:120]))
    raise RuntimeError("Aucun fournisseur IA joignable.\n" + "\n".join(" · " + e for e in erreurs))


SYSTEM_YAML = (
    "Tu es NEXUS GenHub, un générateur expert de workflows GitHub Actions.\n"
    "RÈGLES ABSOLUES :\n"
    "1. Réponds UNIQUEMENT avec UN workflow YAML complet. Aucun texte autour, aucun bloc markdown.\n"
    "2. Le YAML doit être NOUVEAU et taillé sur mesure pour la demande (jamais un template générique).\n"
    "3. Utilise actions/checkout@v4, actions/upload-artifact@v4. Trigger: [push, workflow_dispatch].\n"
    "4. Privilégie des services publics gratuits SANS clé (pollinations.ai image/texte, quickchart.io, "
    "api.qrserver.com, api.open-meteo.com, api.dicebear.com) via curl, et remonte les artefacts.\n"
    "5. Commente chaque step en français. YAML 100% valide (pas d'onglets, guillemets propres)."
)


def extract_yaml(text):
    m = re.search(r"```(?:ya?ml)?\s*\n(.*?)```", text, re.S)
    if m:
        text = m.group(1)
    text = text.strip()
    lines = text.splitlines()
    for i, l in enumerate(lines):
        if re.match(r"^(name|on|jobs)\s*:", l.strip()):
            return "\n".join(lines[i:]).strip()
    return text


def validate_yaml(text):
    try:
        import yaml
        j = yaml.safe_load(text)
        if not isinstance(j, dict):
            return "le YAML ne donne pas un dictionnaire"
        if "jobs" not in j:
            return "clé 'jobs:' absente"
        return None
    except ImportError:
        ok = re.search(r"^jobs\s*:", text, re.M) and re.search(r"^(name|on)\s*:", text, re.M)
        return None if ok else "structure de workflow non reconnue"
    except Exception as e:
        return "YAML invalide : %s" % str(e)[:150]


def generate_yaml(description, provider="auto", contexte=""):
    """Génère un workflow NOUVEAU. → dict(ok, yaml, provider, essais, erreur)"""
    user = "Demande : " + description.strip()
    if contexte:
        user += "\nContexte : " + contexte
    messages = [{"role": "system", "content": SYSTEM_YAML}, {"role": "user", "content": user}]
    essais = []
    last_err = None
    for attempt in range(1, 3):
        try:
            txt, pid, sec = chat(messages, provider=provider)
        except Exception as e:
            return {"ok": False, "yaml": "", "provider": provider, "essais": essais, "erreur": str(e)}
        y = extract_yaml(txt)
        err = validate_yaml(y)
        essais.append({"provider": pid, "secondes": sec, "valide": err is None})
        if err is None:
            return {"ok": True, "yaml": y, "provider": pid, "essais": essais, "erreur": None}
        last_err = err
        messages.append({"role": "assistant", "content": txt})
        messages.append({"role": "user", "content": "Ton YAML est invalide : %s\nRenvoie UNIQUEMENT le YAML corrigé complet." % err})
    return {"ok": False, "yaml": "", "provider": provider, "essais": essais, "erreur": last_err}


if __name__ == "__main__":
    import sys
    prov = sys.argv[1] if len(sys.argv) > 1 else "auto"
    desc = sys.argv[2] if len(sys.argv) > 2 else "Un workflow qui génère une image NEXUS via pollinations et l'upload en artefact"
    r = generate_yaml(desc, provider=prov)
    print("OK:", r["ok"], "| provider:", r["provider"], "| essais:", r["essais"])
    print(r["yaml"] or r["erreur"])
LLMF
ok "nexus_llm.py — génération IA : Ollama → Pollinations → 8 offres gratuites, YAML auto-corrigé"

# ════════════════════════════════════════════════════════════════════
#  PARTIE F — lanceurs, hook non-invasif, plugin exemple
# ════════════════════════════════════════════════════════════════════

cat > "$APP_DIR/genhub.sh" <<'HUBSH'
#!/usr/bin/env bash
# NEXUS GEN HUB — lanceur (142 services réels + IA)
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
exec python3 "$DIR/service_hub.py" "$@"
HUBSH
chmod +x "$APP_DIR/genhub.sh"
ok "genhub.sh — lanceur du hub"

cat > "$APP_DIR/nexus_hub_hook.py" <<'HOOKF'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pont NON-INVASIF pour l'éditeur GenEdit v1 existant.
Dans genedit.py, si tu veux un bouton « ⚡ GEN HUB » qui ouvre le hub :
ajoute ces 3 lignes juste avant mainloop() :

    try:
        import nexus_hub_hook; nexus_hub_hook.register(root)
    except Exception:
        pass

Rien n'est modifié automatiquement : ton fichier d'origine reste intact.
"""
import subprocess
import sys
import os

HERE = os.path.dirname(os.path.abspath(__file__))


def register(root):
    import tkinter as tk
    bar = getattr(root, "nexus_hub_btn", None)
    if bar is not None:
        return
    root.nexus_hub_btn = tk.Button(
        root, text="⚡ GEN HUB (142 services + IA)", command=launch_hub,
        bg="#0d0e1c", fg="#00E5FF", activebackground="#12304a",
        activeforeground="#00E5FF", relief="ridge", bd=1, font=("DejaVu Sans", 9, "bold"))
    root.nexus_hub_btn.pack(side="bottom", fill="x")


def launch_hub(event=None):
    subprocess.Popen([sys.executable, os.path.join(HERE, "service_hub.py")],
                     cwd=HERE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
HOOKF
ok "nexus_hub_hook.py — pont optionnel (3 lignes, jamais imposé)"

mkdir -p "$HOME/.nexus-hub/plugins"
cat > "$HOME/.nexus-hub/plugins/exemple-fox.py" <<'PLGF'
# PLUGIN NEXUS GEN HUB — exemple officiel d'extension.
# Tout fichier .py ici est chargé automatiquement : srv(...) l'ajoute au catalogue.
srv(id="plg-fox", nom="Random Fox · photos de renards", cat="AVATARS & ILLUSTRATIONS",
    acces="sans-clé", genre="image",
    desc="Plugin exemple : images de renards aléatoires (randomfox.ca).",
    params=[],
    run=lambda p: __import__("nexus_services").imgget("https://randomfox.ca/images/{n}.jpg")({"n": str(__import__("random").randint(1, 123))}),
    ping=lambda: __import__("nexus_services").http_req("https://randomfox.ca/floof/?image=1", timeout=10)[0])
PLGF
ok "~/.nexus-hub/plugins/exemple-fox.py — montre comment AJOUTER des services sans toucher au code"

# ════════════════════════════════════════════════════════════════════
#  PARTIE G — service_hub.py : l'interface GEN HUB (Tk, thème nébuleuse)
# ════════════════════════════════════════════════════════════════════

cat > "$APP_DIR/service_hub.py" <<'HUBPY'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS GEN HUB v2.0 — 142 services de génération RÉELS + IA cléless.
Usage : python3 service_hub.py [--selftest]
"""
import json
import os
import queue
import subprocess
import sys
import threading
import time
import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import tkinter as tk            # noqa: E402
from tkinter import ttk         # noqa: E402
import nexus_services as NS   # noqa: E402
import nexus_llm as LLM       # noqa: E402

HUB = NS.HUB_DIR
OUT = NS.OUT_DIR
CONF = os.path.join(HUB, "config.json")
os.makedirs(OUT, exist_ok=True)


def load_conf():
    try:
        return json.load(open(CONF, encoding="utf-8"))
    except Exception:
        return {}


def save_conf(c):
    try:
        json.dump(c, open(CONF, "w", encoding="utf-8"), indent=1)
    except Exception:
        pass


C = {"bg": "#050510", "panel": "#0d0e1c", "panel2": "#111328", "line": "#1c2040",
     "txt": "#E8ECFF", "dim": "#8A90B8", "cyan": "#00E5FF", "mag": "#FF00C8",
     "green": "#00FF88", "red": "#FF5C7A", "yel": "#FFD166"}

ETAT_COLORS = {"✓": C["green"], "✓ POST": C["green"], "✓ local": C["green"],
               "clé": C["yel"], "limite": C["yel"], "éteint": C["dim"],
               "réseau": C["red"], "✗ 404": C["red"]}


def etat_color(e):
    for k, v in ETAT_COLORS.items():
        if e.startswith(k):
            return v
    return C["red"]


def open_file(path):
    try:
        subprocess.Popen(["xdg-open", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


class Hub:
    def __init__(self, root):
        self.root = root
        root.title("NEXUS GEN HUB v2.0 — %d services réels + IA cléless" % NS.N_SERVICES)
        root.geometry("1480x900")
        root.configure(bg=C["bg"])
        self.q = queue.Queue()
        self.current = None
        self.entries = {}
        self.status = {}
        self.photo = None
        self.bat_results = []
        self._build()
        self._log("NEXUS GEN HUB — %d services chargés. La vérité, c'est la BATTERIE : chaque service est testé en direct." % NS.N_SERVICES)
        self.root.after(120, self._poll)

    # ── construction UI ─────────────────────────────────────────────
    def _mk(self, parent, kind, **kw):
        kw.setdefault("bg", C["panel"])
        kw.setdefault("fg", C["txt"])
        return kind(parent, **kw)

    def _build(self):
        f = tk.Frame(self.root, bg=C["bg"])
        f.pack(fill="both", expand=True)

        # barre du haut
        top = tk.Frame(f, bg=C["panel"], height=46)
        top.pack(fill="x")
        tk.Label(top, text="  ⬡ NEXUS GEN HUB", bg=C["panel"], fg=C["cyan"],
                 font=("DejaVu Sans", 14, "bold")).pack(side="left")
        acc = NS.battery_summary([]) if False else {}
        counts = {}
        for s in NS.SERVICES:
            counts[s["acces"]] = counts.get(s["acces"], 0) + 1
        tk.Label(top, text="  %d services · %s" % (NS.N_SERVICES,
                 " · ".join("%d %s" % (v, k) for k, v in sorted(counts.items()))),
                 bg=C["panel"], fg=C["dim"], font=("DejaVu Sans", 10)).pack(side="left")
        tk.Button(top, text="⚡ DÉMO INVESTISSEUR (1 clic)", command=self.demo,
                  bg="#1a0f28", fg=C["mag"], activebackground="#2a1840", activeforeground=C["mag"],
                  relief="ridge", bd=1, font=("DejaVu Sans", 10, "bold")).pack(side="right", padx=8, pady=6)
        self.search = tk.Entry(top, bg=C["panel2"], fg=C["txt"], insertbackground=C["cyan"],
                               relief="flat", width=24, font=("DejaVu Sans", 10))
        self.search.pack(side="right", padx=8)
        self.search.insert(0, "filtrer…")
        self.search.bind("<FocusIn>", lambda e: (self.search.delete(0, "end")) if self.search.get() == "filtrer…" else None)
        self.search.bind("<KeyRelease>", lambda e: self.refresh_list())

        corps = tk.Frame(f, bg=C["bg"])
        corps.pack(fill="both", expand=True)

        # gauche : catégories + services
        left = tk.Frame(corps, bg=C["panel"], width=300)
        left.pack(side="left", fill="y", padx=(8, 4), pady=6)
        tk.Label(left, text="CATÉGORIES", bg=C["panel"], fg=C["dim"],
                 font=("DejaVu Sans", 9, "bold")).pack(anchor="w", padx=8, pady=(8, 2))
        self.cats = tk.Listbox(left, bg=C["panel2"], fg=C["txt"], selectbackground=C["cyan"],
                               selectforeground="#050510", relief="flat", height=8,
                               font=("DejaVu Sans", 9), exportselection=False)
        self.cats.pack(fill="x", padx=8)
        self.cats.insert(0, "TOUTES (%d)" % NS.N_SERVICES)
        for c in NS.CATS:
            n = sum(1 for s in NS.SERVICES if s["cat"] == c)
            if n:
                self.cats.insert("end", "%s (%d)" % (c, n))
        self.cats.bind("<<ListboxSelect>>", lambda e: self.refresh_list())
        tk.Label(left, text="SERVICES", bg=C["panel"], fg=C["dim"],
                 font=("DejaVu Sans", 9, "bold")).pack(anchor="w", padx=8, pady=(10, 2))
        self.tree = tk.Listbox(left, bg=C["panel2"], fg=C["txt"], selectbackground=C["cyan"],
                               selectforeground="#050510", relief="flat", font=("DejaVu Sans Mono", 9),
                               exportselection=False)
        self.tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.tree.bind("<<ListboxSelect>>", lambda e: self.pick())

        # droite : onglets
        right = tk.Frame(corps, bg=C["panel"], width=430)
        right.pack(side="right", fill="y", padx=(4, 8), pady=6)
        nb = ttk.Notebook(right)
        nb.pack(fill="both", expand=True, padx=6, pady=6)
        t1 = tk.Frame(nb, bg=C["panel2"]); nb.add(t1, text=" Console ")
        t2 = tk.Frame(nb, bg=C["panel2"]); nb.add(t2, text=" ⚡ Batterie live ")
        t3 = tk.Frame(nb, bg=C["panel2"]); nb.add(t3, text=" IA → YAML ")
        self.console = tk.Text(t1, bg="#07070f", fg=C["txt"], insertbackground=C["cyan"],
                               relief="flat", font=("DejaVu Sans Mono", 9), state="disabled", wrap="word")
        self.console.pack(fill="both", expand=True, padx=6, pady=6)
        self._build_bat(t2)
        self._build_ai(t3)

        # centre
        self.center = tk.Frame(corps, bg=C["panel"])
        self.center.pack(side="left", fill="both", expand=True, padx=4, pady=6)

        bottom = tk.Frame(self.root, bg=C["panel"], height=26)
        bottom.pack(fill="x")
        self.statusbar = tk.Label(bottom, text="prêt", bg=C["panel"], fg=C["dim"], anchor="w",
                                  font=("DejaVu Sans Mono", 9))
        self.statusbar.pack(side="left", padx=10)
        conf = load_conf()
        if conf.get("genedit_path") and os.path.exists(conf["genedit_path"]):
            tk.Button(bottom, text="↩ Ouvrir GenEdit v1", command=self.open_genedit,
                      bg=C["panel"], fg=C["cyan"], relief="flat",
                      activebackground=C["panel2"], activeforeground=C["cyan"],
                      font=("DejaVu Sans", 9)).pack(side="right", padx=8, pady=2)
        self.refresh_list()

    def _build_bat(self, t):
        row = tk.Frame(t, bg=C["panel2"])
        row.pack(fill="x", padx=8, pady=8)
        self.bat_btn = tk.Button(row, text="⚡ TESTER LES %d SERVICES EN DIRECT" % NS.N_SERVICES,
                                 command=self.run_battery, bg="#102020", fg=C["green"],
                                 activebackground="#183828", activeforeground=C["green"],
                                 relief="ridge", bd=1, font=("DejaVu Sans", 10, "bold"))
        self.bat_btn.pack(side="left")
        self.bat_prog = ttk.Progressbar(row, mode="determinate", length=170)
        self.bat_prog.pack(side="left", padx=8)
        self.bat_stat = tk.Label(row, text="", bg=C["panel2"], fg=C["dim"], font=("DejaVu Sans Mono", 9))
        self.bat_stat.pack(side="left")
        cols = ("service", "etat", "ms")
        self.bat_tree = ttk.Treeview(t, columns=cols, show="headings", height=24)
        self.bat_tree.heading("service", text="service")
        self.bat_tree.heading("etat", text="état réel")
        self.bat_tree.heading("ms", text="ms")
        self.bat_tree.column("service", width=250)
        self.bat_tree.column("etat", width=90, anchor="center")
        self.bat_tree.column("ms", width=55, anchor="e")
        self.bat_tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        tk.Button(t, text="💾 Exporter le rapport (.json)", command=self.export_bat,
                  bg=C["panel"], fg=C["dim"], relief="flat",
                  activebackground=C["panel2"], font=("DejaVu Sans", 9)).pack(anchor="e", padx=8, pady=4)

    def _build_ai(self, t):
        row0 = tk.Frame(t, bg=C["panel2"])
        row0.pack(fill="x", padx=8, pady=(8, 4))
        tk.Label(row0, text="Moteur :", bg=C["panel2"], fg=C["dim"]).pack(side="left")
        self.ai_prov = ttk.Combobox(row0, values=["auto"] + [p["id"] for p in LLM.PROVIDERS],
                                    state="readonly", width=24)
        self.ai_prov.set("auto")
        self.ai_prov.pack(side="left", padx=6)
        tk.Label(row0, text="auto = Ollama local → Pollinations (sans clé)", bg=C["panel2"],
                 fg=C["dim"], font=("DejaVu Sans", 8)).pack(side="left")
        tk.Label(t, text="Décris le workflow que tu veux — il est GÉNÉRÉ par IA, aucun template :",
                 bg=C["panel2"], fg=C["txt"], font=("DejaVu Sans", 9)).pack(anchor="w", padx=8)
        self.ai_prompt = tk.Text(t, height=5, bg="#07070f", fg=C["txt"], insertbackground=C["cyan"],
                                 relief="flat", font=("DejaVu Sans Mono", 9))
        self.ai_prompt.pack(fill="x", padx=8, pady=4)
        self.ai_prompt.insert("1.0", "Un workflow qui génère une image d'orbe néon avec Pollinations FLUX, puis l'upload en artefact")
        row1 = tk.Frame(t, bg=C["panel2"])
        row1.pack(fill="x", padx=8)
        tk.Button(row1, text="✦ GÉNÉRER PAR IA", command=self.ai_generate,
                  bg="#1a1030", fg=C["mag"], activebackground="#2a1840", activeforeground=C["mag"],
                  relief="ridge", bd=1, font=("DejaVu Sans", 10, "bold")).pack(side="left")
        tk.Button(row1, text="💾 Enregistrer .yml", command=self.ai_save, bg=C["panel"],
                  fg=C["cyan"], relief="flat", activebackground=C["panel2"],
                  activeforeground=C["cyan"], font=("DejaVu Sans", 9)).pack(side="left", padx=6)
        tk.Button(row1, text="▶ Lancer dans GenEdit", command=self.open_genedit, bg=C["panel"],
                  fg=C["dim"], relief="flat", activebackground=C["panel2"], font=("DejaVu Sans", 9)).pack(side="left")
        self.ai_yaml = tk.Text(t, bg="#07070f", fg=C["green"], insertbackground=C["cyan"],
                               relief="flat", font=("DejaVu Sans Mono", 9), wrap="none")
        self.ai_yaml.pack(fill="both", expand=True, padx=8, pady=8)

    # ── liste / sélection ───────────────────────────────────────────
    def refresh_list(self):
        self.tree.delete(0, "end")
        self.view = []
        sel = self.cats.curselection()
        catf = None
        if sel:
            raw = self.cats.get(sel[0])
            if not raw.startswith("TOUTES"):
                catf = raw.rsplit(" (", 1)[0]
        q = self.search.get().lower().strip()
        if q == "filtrer…":
            q = ""
        for s in NS.SERVICES:
            if catf and s["cat"] != catf:
                continue
            if q and q not in (s["id"] + " " + s["nom"] + " " + s["cat"]).lower():
                continue
            badge = {"sans-clé": "○", "clé-gratuite": "◇", "local": "◆"}.get(s["acces"], "·")
            st = self.status.get(s["id"])
            mark = " " + st["etat"] if st else ""
            self.tree.insert("end", "%s %s — %s%s" % (badge, s["nom"], s["cat"], mark))
            self.view.append(s)

    def pick(self):
        sel = self.tree.curselection()
        if not sel:
            return
        s = self.view[sel[0]]
        self.current = s
        for w in self.center.winfo_children():
            w.destroy()
        head = tk.Frame(self.center, bg=C["panel"])
        head.pack(fill="x", padx=10, pady=(10, 4))
        tk.Label(head, text=s["nom"], bg=C["panel"], fg=C["txt"],
                 font=("DejaVu Sans", 13, "bold")).pack(anchor="w")
        tk.Label(head, text="%s · %s" % (s["cat"], s["acces"].upper()), bg=C["panel"],
                 fg=C["cyan"] if s["acces"] == "sans-clé" else C["yel"] if s["acces"] == "clé-gratuite" else C["dim"],
                 font=("DejaVu Sans", 9)).pack(anchor="w")
        tk.Label(head, text=s["desc"], bg=C["panel"], fg=C["dim"], wraplength=620,
                 justify="left", font=("DejaVu Sans", 9)).pack(anchor="w", pady=2)
        st = self.status.get(s["id"])
        if st:
            tk.Label(head, text="batterie : %s (%d ms)" % (st["etat"], st["ms"]), bg=C["panel"],
                     fg=etat_color(st["etat"]), font=("DejaVu Sans Mono", 9)).pack(anchor="w")
        pf = tk.Frame(self.center, bg=C["panel"])
        pf.pack(fill="x", padx=10)
        self.entries = {}
        for i, (key, default, label) in enumerate(s.get("params", [])):
            tk.Label(pf, text=label, bg=C["panel"], fg=C["dim"], width=22,
                     anchor="e", font=("DejaVu Sans", 9)).grid(row=i, column=0, sticky="e", pady=2, padx=(0, 6))
            e = tk.Entry(pf, bg=C["panel2"], fg=C["txt"], insertbackground=C["cyan"],
                         relief="flat", width=52, font=("DejaVu Sans Mono", 9))
            e.insert(0, default)
            e.grid(row=i, column=1, sticky="w", pady=2)
            self.entries[key] = e
        tk.Button(self.center, text="▶  GÉNÉRER MAINTENANT (appel réel)", command=self.generate,
                  bg="#0a2830", fg=C["cyan"], activebackground="#10384a", activeforeground=C["cyan"],
                  relief="ridge", bd=1, font=("DejaVu Sans", 11, "bold")).pack(anchor="w", padx=10, pady=8)
        mid = tk.Frame(self.center, bg=C["panel"])
        mid.pack(fill="both", expand=True, padx=10, pady=(0, 4))
        self.preview = tk.Label(mid, bg="#07070f", text="  résultat ici  ", fg=C["dim"],
                                font=("DejaVu Sans Mono", 10))
        self.preview.pack(fill="both", expand=True)
        btns = tk.Frame(self.center, bg=C["panel"])
        btns.pack(fill="x", padx=10, pady=(0, 8))
        tk.Button(btns, text="📂 Ouvrir le fichier", command=self.open_last,
                  bg=C["panel"], fg=C["dim"], relief="flat", activebackground=C["panel2"],
                  font=("DejaVu Sans", 9)).pack(side="left")
        tk.Button(btns, text="⧉ Copier le texte", command=self.copy_last,
                  bg=C["panel"], fg=C["dim"], relief="flat", activebackground=C["panel2"],
                  font=("DejaVu Sans", 9)).pack(side="left", padx=6)
        tk.Button(btns, text="⚙ Générer le workflow CI de ce service", command=self.service_ci,
                  bg=C["panel"], fg=C["cyan"], relief="flat", activebackground=C["panel2"],
                  activeforeground=C["cyan"], font=("DejaVu Sans", 9)).pack(side="left")
        self.last_result = None

    # ── génération d'un service ─────────────────────────────────────
    def generate(self):
        s = self.current
        if not s or self._busy("gen"):
            return
        p = {k: e.get() for k, e in self.entries.items()}
        self._set_status("génération via %s…" % s["id"])
        self._log("▶ %s — appel réel en cours…" % s["nom"])
        self.preview.config(image="", text="  génération en cours…  ", fg=C["cyan"])

        def work():
            t0 = time.time()
            try:
                res = s["run"](p)
            except Exception as e:
                res = NS.R("texte", ok=False, info="exception : %s" % str(e)[:200])
            res["_ms"] = int((time.time() - t0) * 1000)
            self.q.put(("gen", s, res))
        threading.Thread(target=work, daemon=True).start()

    def show_result(self, s, res):
        self.last_result = (s, res)
        ms = res.get("_ms", 0)
        if not res.get("ok"):
            self.preview.config(image="", fg=C["red"], font=("DejaVu Sans Mono", 10),
                                text="  ✗ ÉCHEC : %s\n  (les services gratuits tombent parfois — relance, ou choisis-en un autre)" % res.get("info", "?"))
            self._log("✗ %s — %s (%d ms)" % (s["id"], res.get("info", "?"), ms), C["red"])
            self._set_status("échec %s" % s["id"])
            return
        k = res["kind"]
        if k == "image" and res.get("path"):
            self._show_image(res["path"])
            self._log("✓ image générée : %s (%d ms, %s)" % (os.path.basename(res["path"]), ms, res.get("info", "")), C["green"])
        elif k == "audio" and res.get("path"):
            self.preview.config(image="", fg=C["green"], font=("DejaVu Sans Mono", 10),
                                text="  🔊 audio prêt :\n  %s\n  (bouton « Ouvrir le fichier » pour écouter)" % res["path"])
            self._log("✓ audio : %s (%d ms)" % (res["path"], ms), C["green"])
        else:
            txt = res.get("text", "") or json.dumps(res, ensure_ascii=False)[:4000]
            self.preview.config(image="", fg=C["txt"], font=("DejaVu Sans Mono", 9), justify="left",
                                text="  " + txt[:2200].replace("\n", "\n  "))
            self._log("✓ %s — %d ms — %s" % (s["id"], ms, res.get("info", "")), C["green"])
        self._set_status("✓ %s (%d ms)" % (s["id"], ms))

    def _show_image(self, path):
        ok = False
        try:
            from PIL import Image, ImageTk
            img = Image.open(path)
            img.thumbnail((560, 380))
            self.photo = ImageTk.PhotoImage(img)
            self.preview.config(image=self.photo, text="", bg="#07070f")
            ok = True
        except Exception:
            pass
        if not ok:
            try:
                self.photo = tk.PhotoImage(file=path)
                self.preview.config(image=self.photo, text="", bg="#07070f")
                ok = True
            except Exception:
                pass
        if not ok:
            self.preview.config(image="", fg=C["yel"], font=("DejaVu Sans Mono", 10),
                                text="  image enregistrée : %s\n  (aperçu complet : sudo apt install python3-pil)" % path)

    def open_last(self):
        if self.last_result and self.last_result[1].get("path"):
            open_file(self.last_result[1]["path"])

    def copy_last(self):
        if self.last_result and self.last_result[1].get("text"):
            self.root.clipboard_clear()
            self.root.clipboard_append(self.last_result[1]["text"])
            self._set_status("texte copié")

    # ── batterie ────────────────────────────────────────────────────
    def run_battery(self):
        if self._busy("bat"):
            return
        self.bat_btn.config(state="disabled")
        for i in self.bat_tree.get_children():
            self.bat_tree.delete(i)
        self._log("⚡ BATTERIE : test réel des %d services…" % NS.N_SERVICES, C["green"])

        def cb(done, total, item):
            self.q.put(("bat", done, total, item))

        def work():
            res = NS.battery(progress=cb)
            self.q.put(("batdone", res))
        threading.Thread(target=work, daemon=True).start()

    def battery_item(self, done, total, item):
        self.bat_prog["maximum"] = total
        self.bat_prog["value"] = done
        self.status[item["id"]] = item
        tag = item["etat"].split()[0] if item["etat"] else "?"
        self.bat_tree.insert("", "end", values=(item["nom"][:42], item["etat"], item["ms"]),
                             tags=(tag,))
        self.bat_tree.tag_configure("✓", foreground=C["green"])
        self.bat_tree.tag_configure("✗", foreground=C["red"])
        self.bat_tree.tag_configure("clé", foreground=C["yel"])
        self.bat_tree.tag_configure("limite", foreground=C["yel"])
        self.bat_tree.tag_configure("réseau", foreground=C["red"])
        if done % 12 == 0:
            self._set_status("batterie : %d/%d" % (done, total))

    def battery_done(self, res):
        self.bat_btn.config(state="normal")
        self.bat_results = res
        summ = NS.battery_summary(res)
        vifs = summ.get("✓", 0) + summ.get("✓ POST", 0) + summ.get("✓ local", 0)
        self.bat_stat.config(text="  ✓ %d vivants" % vifs, fg=C["green"])
        self._log("⚡ BATTERIE TERMINÉE : %s" % " · ".join("%s=%d" % kv for kv in sorted(summ.items())), C["green"])
        self._set_status("batterie terminée — %d services vivants" % vifs)

    def export_bat(self):
        if not self.bat_results:
            self._set_status("lance d'abord la batterie")
            return
        p = os.path.join(OUT, "rapport-batterie-%s.json" % datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
        json.dump({"date": datetime.datetime.now().isoformat(), "total": NS.N_SERVICES,
                   "resultats": self.bat_results}, open(p, "w", encoding="utf-8"), indent=1, ensure_ascii=False)
        self._log("💾 rapport : " + p, C["cyan"])

    # ── IA → YAML ───────────────────────────────────────────────────
    def ai_generate(self):
        if self._busy("ai"):
            return
        desc = self.ai_prompt.get("1.0", "end").strip()
        if not desc:
            self._log("décris d'abord le workflow voulu", C["yel"])
            return
        prov = self.ai_prov.get()
        self._set_status("l'IA génère le workflow (%s)…" % prov)
        self._log("✦ génération IA (%s) — %s" % (prov, desc[:80]), C["mag"])
        self.ai_yaml.delete("1.0", "end")
        self.ai_yaml.insert("1.0", "// l'IA écrit un workflow NOUVEAU…")

        def work():
            t0 = time.time()
            try:
                r = LLM.generate_yaml(desc, provider=prov)
            except Exception as e:
                r = {"ok": False, "erreur": str(e), "yaml": "", "provider": prov, "essais": []}
            r["_sec"] = round(time.time() - t0, 1)
            self.q.put(("ai", r))
        threading.Thread(target=work, daemon=True).start()

    def ai_done(self, r):
        self.ai_yaml.delete("1.0", "end")
        if r.get("ok"):
            self.ai_yaml.insert("1.0", r["yaml"])
            prov = r.get("provider", "?")
            sans_cle = "SANS CLÉ" if "pollinations" in prov or prov == "ollama" else ""
            self._log("✦ YAML GÉNÉRÉ PAR IA via %s en %ss %s — 0 template utilisé" % (prov, r.get("_sec", "?"), sans_cle), C["mag"])
            self._set_status("workflow généré par IA (%s)" % prov)
            self.last_yaml = r["yaml"]
        else:
            self.ai_yaml.insert("1.0", "// ÉCHEC génération : %s" % r.get("erreur"))
            self._log("✦ échec IA : %s" % r.get("erreur"), C["red"])

    def ai_save(self):
        txt = self.ai_yaml.get("1.0", "end").strip()
        if not txt or txt.startswith("// ÉCHEC"):
            self._set_status("rien à enregistrer")
            return
        wdir = load_conf().get("workflows_dir") or os.path.expanduser("~/Bureau")
        if not os.path.isdir(wdir):
            wdir = os.path.expanduser("~")
        name = "nexus-ia-%s.yml" % datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        p = os.path.join(wdir, name)
        open(p, "w", encoding="utf-8").write(txt + "\n")
        self._log("💾 workflow IA enregistré : %s" % p, C["cyan"])
        self._set_status("enregistré : " + name)

    def service_ci(self):
        s = self.current
        if not s:
            return
        js = s["id"].replace("-", "_")
        y = "# Workflow GÉNÉRÉ par NEXUS GEN HUB pour le service réel : %s\n" % s["nom"]
        y += "# Service gratuit : %s\n" % s["desc"].split("\n")[0]
        y += "name: NEXUS-HUB %s\n" % s["id"]
        y += "on: [push, workflow_dispatch]\njobs:\n  test-%s:\n    runs-on: ubuntu-latest\n    steps:\n" % js
        y += "      - uses: actions/checkout@v4\n"
        y += "      - name: Appel réel du service %s\n" % s["id"]
        y += "        run: |\n"
        y += '          code=$(curl -s -o /tmp/out.bin -w "%%{http_code}" --max-time 30 "%s")\n' % self._ci_url(s)
        y += '          echo "HTTP $code"\n          test "$code" = "200"\n'
        if s["genre"] in ("image", "audio"):
            y += "      - name: Publier l'artefact généré\n        uses: actions/upload-artifact@v4\n        with:\n          name: %s-sortie\n          path: /tmp/out.bin\n" % js
        self.ai_yaml.delete("1.0", "end")
        self.ai_yaml.insert("1.0", y)
        self.last_yaml = y
        self._log("⚙ workflow CI du service %s construit — onglet IA → YAML" % s["id"], C["cyan"])

    def _ci_url(self, s):
        d = {k: v for k, v, _ in s.get("params", [])}
        pf = s.get("ping")
        if callable(pf):
            return "URL réelle du service (voir nexus_services.py : ping)"
        url = pf or ""
        try:
            return NS._fmt(url, d)
        except Exception:
            return url

    # ── démo investisseur ───────────────────────────────────────────
    def demo(self):
        if self._busy("demo"):
            return
        self._log("🎬 DÉMO INVESTISSEUR — 4 preuves de génération réelle, sans aucune clé", C["mag"])

        def work():
            steps = [
                ("1/4 · graphique IA de données", "g-quickchart",
                 {"type": "bar", "labels": "Rust,Go,C,Python", "valeurs": "9.2,8.7,8.1,8.8", "titre": "Langages 2026"}),
                ("2/4 · QR code du pitch", "qr-goqr", {"data": "https://nexus.aether", "taille": "300x300"}),
                ("3/4 · voix de synthèse", "tts-streamelements",
                 {"texte": "Bienvenue. Ce que vous voyez est généré en direct, sans aucune clé API.", "voix": "Brian"}),
                ("4/4 · image IA (flux → repli automatique)", "img-flux",
                 {"prompt": "cyberpunk orb, neon cyan and magenta, dark background, ultra detailed", "largeur": "768", "hauteur": "768"}),
            ]
            for label, sid, params in steps:
                self.q.put(("demo", None, None, label))
                s = next((x for x in NS.SERVICES if x["id"] == sid), None)
                if not s:
                    continue
                t0 = time.time()
                try:
                    res = s["run"](params)
                except Exception as e:
                    res = NS.R(s.get("genre", "texte"), ok=False, info=str(e)[:150])
                res["_ms"] = int((time.time() - t0) * 1000)
                self.q.put(("demo-res", s, res, label))
            self.q.put(("demo-ai",))
        threading.Thread(target=work, daemon=True).start()

    # ── utilitaires ─────────────────────────────────────────────────
    def open_genedit(self):
        conf = load_conf()
        gp = conf.get("genedit_path")
        if gp and os.path.exists(gp):
            subprocess.Popen(["python3", gp], cwd=os.path.dirname(gp),
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self._log("↩ GenEdit v1 lancé (intact — le hub l'accompagne)", C["cyan"])
        else:
            self._log("genedit.py introuvable dans la config", C["yel"])

    def _busy(self, tag):
        if getattr(self, "_busy_tag", None):
            self._set_status("opération en cours (%s)…" % self._busy_tag)
            return True
        self._busy_tag = tag
        return False

    def _free(self):
        self._busy_tag = None

    def _log(self, msg, color=None):
        self.console.config(state="normal")
        t = datetime.datetime.now().strftime("%H:%M:%S")
        self.console.insert("end", "[%s] %s\n" % (t, msg))
        if color:
            self.console.tag_add("last", "end-2l", "end-1l")
        self.console.see("end")
        self.console.config(state="disabled")

    def _set_status(self, msg):
        self.statusbar.config(text=msg)

    def _poll(self):
        try:
            while True:
                item = self.q.get_nowait()
                kind = item[0]
                if kind == "gen":
                    self._free()
                    self.show_result(item[1], item[2])
                elif kind == "bat":
                    self.battery_item(item[1], item[2], item[3])
                elif kind == "batdone":
                    self._free()
                    self.battery_done(item[1])
                elif kind == "ai":
                    self._free()
                    self.ai_done(item[1])
                elif kind == "demo":
                    self._log("🎬 " + item[3], C["mag"])
                    self._set_status(item[3])
                elif kind == "demo-res":
                    self.show_result(item[1], item[2])
                elif kind == "demo-ai":
                    self._free()
                    self._log("🎬 5/5 · génération du workflow par IA (Pollinations, sans clé)…", C["mag"])
                    desc = "Workflow GitHub Actions qui génère une image d'orbe néon via pollinations image API puis l'upload en artefact"
                    try:
                        r = LLM.generate_yaml(desc, provider="auto")
                    except Exception as e:
                        r = {"ok": False, "erreur": str(e)}
                    self.ai_done(r)
                    self._log("🎬 DÉMO TERMINÉE — tout est réel : graphique, QR, voix, image IA, workflow IA.", C["green"])
        except queue.Empty:
            pass
        self.root.after(120, self._poll)


def selftest():
    print("SELFTEST — %d services" % NS.N_SERVICES)
    assert NS.N_SERVICES >= 90, "catalogue < 90 !"
    cats = set(s["cat"] for s in NS.SERVICES)
    ids = set(s["id"] for s in NS.SERVICES)
    assert len(ids) == NS.N_SERVICES, "ids dupliqués !"
    missing_run = [s["id"] for s in NS.SERVICES if "run" not in s or not callable(s["run"])]
    assert not missing_run, "run manquant : %s" % missing_run
    res = NS.battery(NS.SERVICES[:8], workers=8, timeout=10)
    for r in res:
        print("  %-24s %-38s %s (%d ms)" % (r["id"], r["nom"][:36], r["etat"], r["ms"]))
    summ = NS.battery_summary(res)
    print("synthèse 8 premiers :", dict(summ))
    r = LLM.generate_yaml("Un workflow qui ping https://example.com et affiche le code HTTP", provider="pollinations-openai")
    print("IA YAML ok:", r["ok"], "| provider:", r["provider"])
    if r["ok"]:
        print(r["yaml"][:300])
    print("SELFTEST TERMINÉ")
    return 0


def main():
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    root = tk.Tk()
    try:
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook", background=C["panel"], foreground=C["txt"])
        style.configure("TNotebook.Tab", background=C["panel"], foreground=C["dim"], padding=(10, 4))
        style.map("TNotebook.Tab", background=[("selected", C["panel2"])], foreground=[("selected", C["cyan"])])
        style.configure("Treeview", background="#07070f", foreground=C["txt"], fieldbackground="#07070f")
        style.configure("TProgressbar", background=C["cyan"], troughcolor=C["panel2"])
        style.configure("TCombobox", fieldbackground=C["panel2"], background=C["panel2"], foreground=C["txt"])
    except Exception:
        pass
    Hub(root)
    root.mainloop()


if __name__ == "__main__":
    main()
HUBPY
python3 -m py_compile "$APP_DIR/service_hub.py" 2>/dev/null || true
ok "service_hub.py — hub complet : liste, params, génération, batterie, IA→YAML, démo 1-clic"

# ════════════════════════════════════════════════════════════════════
phase 4 "Compilation & introspection (preuves)"
# ════════════════════════════════════════════════════════════════════
for f in nexus_services.py nexus_llm.py service_hub.py; do
  chk "py_compile $f" "python3 -m py_compile '$APP_DIR/$f'"
done
N_SVCS="$(python3 -c "
import sys; sys.path.insert(0, '$APP_DIR')
import nexus_services as NS
print(NS.N_SERVICES)
" 2>/dev/null || echo 0)"
if [ "${N_SVCS:-0}" -ge 90 ]; then
  ok "catalogue : $N_SVCS services réels chargés (exigence ≥90 — OK)"
else
  ko "catalogue incomplet : $N_SVCS services"
fi
N_CATS="$(python3 -c "
import sys; sys.path.insert(0, '$APP_DIR')
import nexus_services as NS
print(len(set(s['cat'] for s in NS.SERVICES)))
" 2>/dev/null || echo 0)"
info "répartis dans $N_CATS catégories"

# ════════════════════════════════════════════════════════════════════
phase 5 "BATTERIE RÉELLE — 16 services testés en direct"
# ════════════════════════════════════════════════════════════════════
if [ "$FAIL" -gt 0 ]; then
  warn "échecs en amont — batterie sautée"
else
  BAT_OUT="$(cd "$APP_DIR" && timeout 120 python3 nexus_services.py --battery 16 2>&1 || true)"
  printf '%s\n' "$BAT_OUT" | sed 's/^/  /'
  if printf '%s' "$BAT_OUT" | grep -q "Synthèse"; then
    ok "batterie exécutée — les états ci-dessus sont des appels RÉELS depuis cette machine"
    warn "certains services limitent les IP de datacenter/VPN : chez toi, sur ton IP, ils seront souvent verts"
  else
    ko "batterie non terminée (timeout réseau ?)"
  fi
fi

# ════════════════════════════════════════════════════════════════════
phase 6 "Raccourcis (menu + Bureau) — GenEdit reste en place"
# ════════════════════════════════════════════════════════════════════
if [ "${NEXUS_NO_DESKTOP:-0}" = "1" ]; then
  warn "raccourcis sautés (NEXUS_NO_DESKTOP=1) — lancement : $APP_DIR/genhub.sh"
else
  ICON=""
  [ -f "$APP_DIR/assets/aether.svg" ] && ICON="$APP_DIR/assets/aether.svg"
  cat > "$APP_DIR/build-nexus-genhub.desktop" <<DESKF
[Desktop Entry]
Type=Application
Version=1.0
Name=NEXUS GEN HUB
GenericName=Éditeur génératif v2
Comment=~140 services de génération réels + IA sans clé · port de GenEdit v1 intact
Exec=$APP_DIR/genhub.sh
Icon=${ICON:-$APP_DIR/genhub.svg}
Path=$APP_DIR
Terminal=false
Categories=Development;Utility;
StartupNotify=true
StartupWMClass=nexus-genhub
DESKF
  if [ -z "$ICON" ]; then
    cat > "$APP_DIR/genhub.svg" <<'ICONS'
<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128">
  <rect width="128" height="128" rx="26" fill="#050510"/>
  <polygon points="64,16 106,40 106,88 64,112 22,88 22,40" fill="none" stroke="#00E5FF" stroke-width="4"/>
  <polygon points="64,34 92,50 92,80 64,96 36,80 36,50" fill="#00E5FF" opacity="0.25"/>
  <circle cx="64" cy="64" r="12" fill="#FF00C8"/>
</svg>
ICONS
    ICON="$APP_DIR/genhub.svg"
  fi
  APPS_DIR="$HOME/.local/share/applications"
  mkdir -p "$APPS_DIR"
  cp "$APP_DIR/build-nexus-genhub.desktop" "$APPS_DIR/nexus-genhub.desktop"
  ok "menu des applications → NEXUS GEN HUB"
  DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Bureau")"
  mkdir -p "$DESKTOP_DIR"
  cp "$APP_DIR/build-nexus-genhub.desktop" "$DESKTOP_DIR/nexus-genhub.desktop"
  chmod +x "$DESKTOP_DIR/nexus-genhub.desktop" 2>/dev/null || true
  gio set "$DESKTOP_DIR/nexus-genhub.desktop" metadata::trusted true 2>/dev/null \
    && ok "icône Bureau installée (marquée fiable)" \
    || ok "icône Bureau : $DESKTOP_DIR/nexus-genhub.desktop (si Mint demande : clic-droit → Autoriser le lancement)"
fi
if command -v desktop-file-validate >/dev/null 2>&1 && [ -f "$HOME/.local/share/applications/nexus-genhub.desktop" ]; then
  chk ".desktop valide" "desktop-file-validate '$HOME/.local/share/applications/nexus-genhub.desktop'"
fi

# ════════════════════════════════════════════════════════════════════
phase 7 "Preuve de NON-DESTRUCTION + rapport"
# ════════════════════════════════════════════════════════════════════
if [ -n "$GENEDIT" ]; then
  SHA_AFTER="$(sha256sum "$GENEDIT" | awk '{print $1}')"
  if [ "$SHA_BEFORE" = "$SHA_AFTER" ]; then
    ok "genedit.py INTOUCHE — SHA-256 identique avant/après : ${SHA_AFTER:0:24}…"
  else
    ko "ALERTE : genedit.py a changé — restaure depuis le backup $BK"
  fi
fi
echo
echo -e "  ${C_CYAN}${C_B}Nouveautés installées dans $APP_DIR${C_RST}"
for f in nexus_services.py nexus_llm.py service_hub.py genhub.sh nexus_hub_hook.py; do
  [ -f "$APP_DIR/$f" ] && info "$f  ($(wc -l < "$APP_DIR/$f") lignes)"
done
info "~/.nexus-hub/config.json · ~/.nexus-hub/plugins/exemple-fox.py (extensions automatiques)"
echo
cat <<RAP

  Pour convaincre l'investisseur en 90 secondes :
    1. Ouvre  NEXUS GEN HUB  (menu ou Bureau)  →  bouton  ⚡ DÉMO INVESTISSEUR
       → graphique réel, QR réel, voix réelle, image IA, puis workflow écrit
       par l'IA SANS aucun template. Zéro clé API utilisée.
    2. Onglet  ⚡ Batterie live  →  TESTER LES ~140 SERVICES
       → les états s'allument un par un : chaque ligne est un appel réseau réel.
    3. Onglet  IA → YAML  →  décris n'importe quel pipeline en français
       → YAML NOUVEAU généré et validé, enregistré directement dans le dossier
       de workflows de GenEdit v1 ($WDIR).

RAP
cat > "$APP_DIR/INTEGRATION-GENHUB.md" <<DOC
# NEXUS GEN HUB — ajouté le $(date '+%d/%m/%Y %H:%M')

## Quoi de neuf (v2)
- ~140 services de génération RÉELS (nexus_services.py) — IA image/texte/voix,
  diagrammes, QR, graphiques, météo, espace, finance, science… majoritairement SANS clé.
- Génération de workflows PAR IA (nexus_llm.py) : Ollama local → Pollinations
  (GPT/Mistral/DeepSeek/Qwen, sans clé) → offres gratuites (Groq, Gemini, OpenRouter…).
- Hub graphique complet (service_hub.py) avec batterie de test live et démo 1 clic.
- Système de plugins : ~/.nexus-hub/plugins/*.py (exemple fourni).

## GenEdit v1
- genedit.py : AUCUNEMENT modifié (SHA-256 vérifié par l'installateur).
- Sauvegarde : backup-v1-<date>/ à côté de l'app.
- Pont optionnel (3 lignes avant mainloop de genedit.py) :
      try:
          import nexus_hub_hook; nexus_hub_hook.register(root)
      except Exception:
          pass
- Les YAML générés par le hub s'enregistrent dans : $WDIR

## Clés optionnelles (toutes gratuites)
export NEXUS_GROQ_KEY=…      # console.groq.com
export NEXUS_GEMINI_KEY=…    # aistudio.google.com
export NEXUS_OPENROUTER_KEY=… # openrouter.ai (modèles :free)
export NEXUS_HF_KEY=…        # huggingface.co (FLUX, SDXL)
DOC
ok "INTEGRATION-GENHUB.md écrit"

# ════════════════════════════════════════════════════════════════════
phase 8 "Lancement & fin"
# ════════════════════════════════════════════════════════════════════
echo
echo -e "  ${C_B}Bilan : ${C_GRN}$PASS réussis${C_RST} / ${C_RED}$FAIL échoués${C_RST}"
if [ "$FAIL" -eq 0 ]; then
  echo -e "  ${C_GRN}${C_B}✦ TOUT EST VERT — GEN HUB v2 est prêt à montrer du RÉEL.${C_RST}"
else
  echo -e "  ${C_YLW}Des échecs — relance ce script (ré-exécutable), la sauvegarde est déjà en place.${C_RST}"
fi
echo
LAUNCH_NOW="n"
if [ "${1:-}" = "--launch" ]; then
  LAUNCH_NOW="o"
elif [ -t 0 ]; then
  read -r -p "  Lancer NEXUS GEN HUB maintenant ? [o/N] " LAUNCH_NOW || LAUNCH_NOW="n"
fi
if [[ "$LAUNCH_NOW" == [oO]* ]]; then
  (cd "$APP_DIR" && nohup python3 service_hub.py >/dev/null 2>&1 & disown 2>/dev/null || true)
  echo -e "  ${C_DIM}la fenêtre du hub s'ouvre…${C_RST}"
fi
echo
if [ -t 0 ]; then
  echo -e "${C_DIM}— Appuie sur ENTRÉE pour fermer ce terminal —${C_RST}"
  read -r _
fi
echo
[ "$FAIL" -eq 0 ] && exit 0 || exit 1
