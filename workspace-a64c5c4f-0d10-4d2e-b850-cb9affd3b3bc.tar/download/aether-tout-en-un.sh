#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════════════
#  AETHER TOUT-EN-UN  v1.0.0
#  Réseau de calcul distribué P2P chiffré — Rust + libp2p (Noise + Yamux)
#  ─────────────────────────────────────────────────────────────────────
#  Ce script fait TOUT, de bout en bout :
#    1. vérifie l'environnement (et installe Rust via rustup si absent) ;
#    2. génère le dépôt Aether complet (21 fichiers, code vérifié) ;
#    3. compile et teste (unitaires) ;
#    4. lance un VRAI réseau local (routeur + 2 nœuds calculants + client)
#       sur tunnels chiffrés, et contre-vérifie le résultat avec un crible
#       Python indépendant ;
#    5. initialise le dépôt git et fait le premier commit ;
#    6. affiche un bilan honnête (ce qui est fait, ce qui ne l'est pas) ;
#    7. se met en pause à la fin (la fenêtre ne se referme pas toute seule).
#
#  Usage :        bash aether-tout-en-un.sh [répertoire_cible] [--force]
#  Sans sudo.     Cible : Linux Mint / Debian / Ubuntu, bash >= 4.
#  Pause finale : contournable avec AETHER_NO_PAUSE=1 (tests automatisés).
#  Généré le 2026-10-30 — le code embarqué est le code même qui a passé les
#  selftests dans l'environnement de génération.
# ════════════════════════════════════════════════════════════════════════
set -uo pipefail

VERT=$'\033[32m'; ROUGE=$'\033[31m'; JAUNE=$'\033[33m'; BLEU=$'\033[34m'; GRIS=$'\033[90m'; NEUTRE=$'\033[0m'
PASS=0; FAIL=0; WARN=0
ok()    { printf '%s  ✓ %s%s\n' "$VERT" "$*" "$NEUTRE"; PASS=$((PASS + 1)); }
ko()    { printf '%s  ✗ %s%s\n' "$ROUGE" "$*" "$NEUTRE"; FAIL=$((FAIL + 1)); }
avert() { printf '%s  ⚠ %s%s\n' "$JAUNE" "$*" "$NEUTRE"; WARN=$((WARN + 1)); }
etape() { printf '\n%s┌─ ÉTAPE %s ──────────────────────────────────────────┐%s\n%s│  %s%s\n%s└───────────────────────────────────────────────┘%s\n' \
              "$BLEU" "$1" "$NEUTRE" "$BLEU" "$2" "$NEUTRE" "$BLEU" "$NEUTRE"; }
info()  { printf '%s  %s%s\n' "$GRIS" "$*" "$NEUTRE"; }

# Pause finale anti-fermeture (le point qui faisait fermer le terminal
# juste après la fin des scripts précédents).
PAUSE_FAITE=0
pause_finale() {
    [ "$PAUSE_FAITE" = "1" ] && return 0
    PAUSE_FAITE=1
    if [ "${AETHER_NO_PAUSE:-0}" = "1" ]; then
        info "(pause finale désactivée : AETHER_NO_PAUSE=1)"
    else
        printf '%s' "$NEUTRE"
        read -r -p "═══ Appuyez sur Entrée pour refermer cette fenêtre ═══" _
        printf '\n'
    fi
}
fin() { # fin <code> — pause finale puis sortie avec le code
    pause_finale
    exit "$1"
}
trap 'pause_finale' EXIT

printf '%s' "$BLEU"
cat <<'BANNIERE'
   ╔═══════════════════════════════════════════════════════════════╗
   ║       AETHER — réseau de calcul distribué P2P chiffré         ║
   ║       Rust · libp2p · Noise · Yamux · tokio                   ║
   ║       MVP Phase 1 : tunnels + distribution + agrégation       ║
   ╚═══════════════════════════════════════════════════════════════╝
BANNIERE
printf '%s' "$NEUTRE"

# ═══════════════════════ ÉTAPE 1/7 · ENVIRONNEMENT ═══════════════════════
etape "1/7" "Vérification de l'environnement"

if [ "${BASH_VERSINFO[0]}" -lt 4 ]; then
    ko "bash >= 4 requis (trouvé : $BASH_VERSION)"
    fin 1
fi
ok "bash $BASH_VERSION"

command -v git >/dev/null 2>&1 && ok "git $(git --version | awk '{print $3}')" || avert "git absent — l'étape git sera ignorée"
if command -v python3 >/dev/null 2>&1; then
    ok "python3 $(python3 --version | awk '{print $2}') — pour la contre-vérification"
else
    avert "python3 absent — la contre-vérification indépendante sera sautée"
fi

CARGO_BIN=""
if command -v cargo >/dev/null 2>&1; then
    CARGO_BIN=$(command -v cargo)
    ok "cargo déjà présent : $CARGO_BIN"
elif [ -x "$HOME/.cargo/bin/cargo" ]; then
    CARGO_BIN="$HOME/.cargo/bin/cargo"
    ok "cargo trouvé dans ~/.cargo/bin (pas encore sur le PATH de ce shell)"
else
    avert "Rust n'est pas installé"
fi

# ═══════════════════════ ÉTAPE 2/7 · RUST ════════════════════════════════
if [ -z "$CARGO_BIN" ]; then
    etape "2/7" "Installation de Rust (rustup — sans sudo)"
    printf '  L'\''installation officielle place tout dans %s/.cargo et %s/.rustup.\n  Aucun sudo, aucune modification du système.\n\n' "$HOME" "$HOME"
    read -r -p "  Installer Rust maintenant ? [O/n] " reponse
    case "${reponse:-O}" in
        [nN]*)
            avert "installation refusée — rien n'a été modifié sur ce système"
            printf '  Pour installer plus tard :\n    curl --proto '\''=https'\'' --tlsv1.2 -sSf https://sh.rustup.rs | sh\n'
            fin 1
            ;;
    esac
    if curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal --default-toolchain stable; then
        # shellcheck disable=SC1091
        [ -f "$HOME/.cargo/env" ] && . "$HOME/.cargo/env"
        if command -v cargo >/dev/null 2>&1; then
            CARGO_BIN=$(command -v cargo)
        elif [ -x "$HOME/.cargo/bin/cargo" ]; then
            CARGO_BIN="$HOME/.cargo/bin/cargo"
        fi
        if [ -n "$CARGO_BIN" ]; then
            ok "Rust installé : $($CARGO_BIN --version)"
        else
            ko "rustup terminé mais cargo introuvable — installation manuelle puis relancer"
            fin 1
        fi
    else
        ko "échec de l'installation rustup (connexion ?) — réessayer plus tard"
        fin 1
    fi
else
    info "étape 2 sautée : Rust est déjà installé ($($CARGO_BIN --version))"
fi

# ═══════════════════════ ÉTAPE 3/7 · RÉPERTOIRE ══════════════════════════
etape "3/7" "Choix du répertoire cible"
FORCE=""
CIBLE=""
for a in ${@+"$@"}; do
    if [ "$a" = "--force" ]; then
        FORCE="--force"
    else
        CIBLE=$a
    fi
done
if [ -z "$CIBLE" ]; then
    read -r -p "  Où créer le projet ? [$HOME/aether] : " CIBLE
    CIBLE=${CIBLE:-$HOME/aether}
fi
mkdir -p "$CIBLE" 2>/dev/null || { ko "impossible de créer $CIBLE"; fin 1; }
if [ -n "$(ls -A "$CIBLE" 2>/dev/null)" ] && [ "$FORCE" != "--force" ]; then
    ko "$CIBLE n'est pas vide — relancer avec :  bash $0 $CIBLE --force"
    fin 1
fi
CIBLE=$(cd "$CIBLE" && pwd)
ok "répertoire cible : $CIBLE"

# ═══════════════════════ ÉTAPE 4/7 · GÉNÉRATION ══════════════════════════
etape "4/7" "Génération du dépôt Aether (21 fichiers)"

FICHIERS_CREE=0
generer() { # generer <chemin relatif> — le contenu du fichier arrive sur stdin
    local rel=$1 abs="$CIBLE/$1"
    mkdir -p "$(dirname "$abs")"
    cat > "$abs"
    FICHIERS_CREE=$((FICHIERS_CREE + 1))
    printf '%s  · %s\n' "$GRIS" "$rel$NEUTRE"
}

generer "Cargo.toml" <<'AETHER_EOF_1'
[workspace]
resolver = "2"
members = [
    "crates/aether-core",
    "crates/aether-net",
    "crates/aether-compute",
    "crates/aether-zk",
    "crates/aether-node",
]

[workspace.package]
version = "0.1.0"
edition = "2021"
rust-version = "1.75"
license = "MIT OR Apache-2.0"

[workspace.dependencies]
tokio = { version = "1", features = ["full"] }
serde = { version = "1", features = ["derive"] }
serde_json = "1"
futures = "0.3"
clap = { version = "4", features = ["derive"] }
libp2p = { version = "=0.53.2", default-features = false, features = [
    "tokio",
    "tcp",
    "noise",
    "yamux",
    "request-response",
    "json",
] }
aether-core = { path = "crates/aether-core" }
aether-net = { path = "crates/aether-net" }
aether-compute = { path = "crates/aether-compute" }
aether-zk = { path = "crates/aether-zk" }

[profile.release]
lto = "thin"
AETHER_EOF_1
generer "Cargo.lock" <<'AETHER_EOF_2'
# This file is automatically @generated by Cargo.
# It is not intended for manual editing.
version = 3

[[package]]
name = "aead"
version = "0.5.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d122413f284cf2d62fb1b7db97e02edb8cda96d769b16e443a4f6195e35662b0"
dependencies = [
 "crypto-common",
 "generic-array",
]

[[package]]
name = "aes"
version = "0.8.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b169f7a6d4742236a0a00c541b845991d0ac43e546831af1249753ab4c3aa3a0"
dependencies = [
 "cfg-if",
 "cipher",
 "cpufeatures 0.2.17",
]

[[package]]
name = "aes-gcm"
version = "0.10.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "831010a0f742e1209b3bcea8fab6a8e149051ba6099432c8cb2cc117dec3ead1"
dependencies = [
 "aead",
 "aes",
 "cipher",
 "ctr",
 "ghash",
 "subtle",
]

[[package]]
name = "aether-compute"
version = "0.1.0"
dependencies = [
 "aether-core",
]

[[package]]
name = "aether-core"
version = "0.1.0"
dependencies = [
 "serde",
 "serde_json",
]

[[package]]
name = "aether-net"
version = "0.1.0"
dependencies = [
 "aether-core",
 "libp2p",
]

[[package]]
name = "aether-node"
version = "0.1.0"
dependencies = [
 "aether-compute",
 "aether-core",
 "aether-net",
 "clap",
 "futures",
 "libp2p",
 "serde_json",
 "tokio",
]

[[package]]
name = "aether-zk"
version = "0.1.0"

[[package]]
name = "allocator-api2"
version = "0.2.21"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "683d7910e743518b0e34f1186f92494becacb047c7b6bf616c96772180fef923"

[[package]]
name = "anstream"
version = "1.0.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "824a212faf96e9acacdbd09febd34438f8f711fb84e09a8916013cd7815ca28d"
dependencies = [
 "anstyle",
 "anstyle-parse",
 "anstyle-query",
 "anstyle-wincon",
 "colorchoice",
 "is_terminal_polyfill",
 "utf8parse",
]

[[package]]
name = "anstyle"
version = "1.0.14"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "940b3a0ca603d1eade50a4846a2afffd5ef57a9feac2c0e2ec2e14f9ead76000"

[[package]]
name = "anstyle-parse"
version = "1.0.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "52ce7f38b242319f7cabaa6813055467063ecdc9d355bbb4ce0c68908cd8130e"
dependencies = [
 "utf8parse",
]

[[package]]
name = "anstyle-query"
version = "1.1.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "40c48f72fd53cd289104fc64099abca73db4166ad86ea0b4341abe65af83dadc"
dependencies = [
 "windows-sys 0.61.2",
]

[[package]]
name = "anstyle-wincon"
version = "3.0.11"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "291e6a250ff86cd4a820112fb8898808a366d8f9f58ce16d1f538353ad55747d"
dependencies = [
 "anstyle",
 "once_cell_polyfill",
 "windows-sys 0.61.2",
]

[[package]]
name = "anyhow"
version = "1.0.104"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "330a5ed07fa54e4702c9d6c4174f74427fc0ef6e214bbd677ae50a5099946470"

[[package]]
name = "arrayref"
version = "0.3.9"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "76a2e8124351fda1ef8aaaa3bbd7ebbcb486bbcd4225aca0aa0d84bb2db8fecb"

[[package]]
name = "asn1-rs"
version = "0.6.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "5493c3bedbacf7fd7382c6346bbd66687d12bbaad3a89a2d2c303ee6cf20b048"
dependencies = [
 "asn1-rs-derive",
 "asn1-rs-impl",
 "displaydoc",
 "nom",
 "num-traits",
 "rusticata-macros",
 "thiserror 1.0.69",
 "time",
]

[[package]]
name = "asn1-rs-derive"
version = "0.5.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "965c2d33e53cb6b267e148a4cb0760bc01f4904c1cd4bb4002a085bb016d1490"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 2.0.119",
 "synstructure 0.13.2",
]

[[package]]
name = "asn1-rs-impl"
version = "0.2.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "7b18050c2cd6fe86c3a76584ef5e0baf286d038cda203eb6223df2cc413565f7"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 2.0.119",
]

[[package]]
name = "async-io"
version = "2.6.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "456b8a8feb6f42d237746d4b3e9a178494627745c3c56c6ea55d92ba50d026fc"
dependencies = [
 "autocfg",
 "cfg-if",
 "concurrent-queue",
 "futures-io",
 "futures-lite",
 "parking",
 "polling",
 "rustix",
 "slab",
 "windows-sys 0.61.2",
]

[[package]]
name = "async-trait"
version = "0.1.92"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "82f6aeea286b8eb4dd3431a1be1b59d290ace00f5bfd8e2a159bc2a05e2c1667"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 3.0.9",
]

[[package]]
name = "asynchronous-codec"
version = "0.7.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a860072022177f903e59730004fb5dc13db9275b79bb2aef7ba8ce831956c233"
dependencies = [
 "bytes",
 "futures-sink",
 "futures-util",
 "memchr",
 "pin-project-lite",
]

[[package]]
name = "attohttpc"
version = "0.24.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "8d9a9bf8b79a749ee0b911b91b671cc2b6c670bdbc7e3dfd537576ddc94bb2a2"
dependencies = [
 "http",
 "log",
 "url",
]

[[package]]
name = "autocfg"
version = "1.5.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f2032f911046de80f0a198e0901378627c33f59ea0ac00e363d481118bd70a53"

[[package]]
name = "base-x"
version = "0.2.11"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4cbbc9d0964165b47557570cce6c952866c2678457aca742aafc9fb771d30270"

[[package]]
name = "base256emoji"
version = "1.0.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b5e9430d9a245a77c92176e649af6e275f20839a48389859d1661e9a128d077c"
dependencies = [
 "const-str",
 "match-lookup",
]

[[package]]
name = "base45"
version = "3.2.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "240e56f4d3c453c36faacb695c535a4d5f8c7d23dac175014f32eb0a71012a03"

[[package]]
name = "base64"
version = "0.22.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "72b3254f16251a8381aa12e40e3c4d2f0199f8c6508fbecb9d91f575e0fbb8c6"

[[package]]
name = "base64ct"
version = "1.8.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2af50177e190e07a26ab74f8b1efbfe2ef87da2116221318cb1c2e82baf7de06"

[[package]]
name = "bitflags"
version = "2.13.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "3ded4057c258ba199e2d26386d3af3780957ecaee6c4ef4041c6b4b8b97c0b06"

[[package]]
name = "blake2"
version = "0.10.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "46502ad458c9a52b69d4d4d32775c788b7a1b85e8bc9d482d92250fc0e3f8efe"
dependencies = [
 "digest",
]

[[package]]
name = "block-buffer"
version = "0.10.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "3078c7629b62d3f0439517fa394996acacc5cbc91c5a20d8c658e77abd503a71"
dependencies = [
 "generic-array",
]

[[package]]
name = "bs58"
version = "0.5.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "bf88ba1141d185c399bee5288d850d63b8369520c1eafc32a0430b5b6c287bf4"
dependencies = [
 "tinyvec",
]

[[package]]
name = "bumpalo"
version = "3.20.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "72f5acc6cb2ba439de613abc23857ec3d78374d8ed5ac84e9d11336e87da8649"

[[package]]
name = "byteorder"
version = "1.5.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1fd0f2584146f6f2ef48085050886acf353beff7305ebd1ae69500e27c67f64b"

[[package]]
name = "bytes"
version = "1.12.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "fc652a48c352aef3ea3aed32080501cf3ef6ed5da78602a020c991775b0aff04"

[[package]]
name = "cc"
version = "1.10.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "86e055fa6e3e40ad6187ba25b6855eeb635d5271f8e0f0e1e9a5826b8d75bea0"
dependencies = [
 "find-msvc-tools",
 "shlex",
]

[[package]]
name = "cfg-if"
version = "1.0.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4e7648175b45a9a48536d676f68d918270699102aa8dab5496df06904c914600"

[[package]]
name = "cfg_aliases"
version = "0.2.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f079e83a288787bcd14a6aea84cee5c87a67c5a3e660c30f557a3d24761b3527"

[[package]]
name = "chacha20"
version = "0.9.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c3613f74bd2eac03dad61bd53dbe620703d4371614fe0bc3b9f04dd36fe4e818"
dependencies = [
 "cfg-if",
 "cipher",
 "cpufeatures 0.2.17",
]

[[package]]
name = "chacha20"
version = "0.10.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "65c35e4b699c7e15ccbe7ee35c005e4fc0a278d22238a2857e6ce2dadeda1b06"
dependencies = [
 "cfg-if",
 "cpufeatures 0.3.1",
 "rand_core 0.10.1",
]

[[package]]
name = "chacha20poly1305"
version = "0.10.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "10cd79432192d1c0f4e1a0fef9527696cc039165d729fb41b3f4f4f354c2dc35"
dependencies = [
 "aead",
 "chacha20 0.9.1",
 "cipher",
 "poly1305",
 "zeroize",
]

[[package]]
name = "cipher"
version = "0.4.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "773f3b9af64447d2ce9850330c473515014aa235e6a783b02db81ff39e4a3dad"
dependencies = [
 "crypto-common",
 "inout",
 "zeroize",
]

[[package]]
name = "clap"
version = "4.6.7"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "aa8876b300ab35ba921adea3dfd70157a46249b33f95c9084ae5709785478946"
dependencies = [
 "clap_builder",
 "clap_derive",
]

[[package]]
name = "clap_builder"
version = "4.6.7"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ec0797fb7aeb1406c84efac526901f7ec3ead2124f946b494e72879d4b54704d"
dependencies = [
 "anstream",
 "anstyle",
 "clap_lex",
 "strsim",
]

[[package]]
name = "clap_derive"
version = "4.6.7"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f9c751b79415d4e559e3d1fcf128e09e720eb673a06d26cf6f392d37d75b66e0"
dependencies = [
 "heck",
 "proc-macro2",
 "quote",
 "syn 3.0.9",
]

[[package]]
name = "clap_lex"
version = "1.1.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1c133bc6a41be0d194c306b5506d15e6feeea7b1d6604bd3f8310dfb2ca96486"

[[package]]
name = "colorchoice"
version = "1.0.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1d07550c9036bf2ae0c684c4297d503f838287c83c53686d05370d0e139ae570"

[[package]]
name = "concurrent-queue"
version = "2.5.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4ca0197aee26d1ae37445ee532fefce43251d24cc7c166799f4d46817f1d3973"
dependencies = [
 "crossbeam-utils",
]

[[package]]
name = "const-oid"
version = "0.9.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c2459377285ad874054d797f3ccebf984978aa39129f6eafde5cdc8315b612f8"

[[package]]
name = "const-str"
version = "0.4.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2f421161cb492475f1661ddc9815a745a1c894592070661180fdec3d4872e9c3"

[[package]]
name = "core-foundation"
version = "0.9.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "91e195e091a93c46f7102ec7818a2aa394e1e1771c3ab4825963fa03e45afb8f"
dependencies = [
 "core-foundation-sys",
 "libc",
]

[[package]]
name = "core-foundation-sys"
version = "0.8.7"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "773648b94d0e5d620f64f280777445740e61fe701025087ec8b57f45c791888b"

[[package]]
name = "cpufeatures"
version = "0.2.17"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "59ed5838eebb26a2bb2e58f6d5b5316989ae9d08bab10e0e6d103e656d1b0280"
dependencies = [
 "libc",
]

[[package]]
name = "cpufeatures"
version = "0.3.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "5ca28b0ae3115b884660db4118d803791fd6756b6e88f39c0f3f7859060d7566"
dependencies = [
 "libc",
]

[[package]]
name = "crossbeam-utils"
version = "0.8.23"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a31eee39dddec8330830986fcd7625edb5a24ec90ea038215273bbc3adb08ac6"

[[package]]
name = "crypto-common"
version = "0.1.7"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "78c8292055d1c1df0cce5d180393dc8cce0abec0a7102adb6c7b1eef6016d60a"
dependencies = [
 "generic-array",
 "rand_core 0.6.4",
 "typenum",
]

[[package]]
name = "ctr"
version = "0.9.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0369ee1ad671834580515889b80f2ea915f23b8be8d0daa4bbaf2ac5c7590835"
dependencies = [
 "cipher",
]

[[package]]
name = "curve25519-dalek"
version = "4.1.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "97fb8b7c4503de7d6ae7b42ab72a5a59857b4c937ec27a3d4539dba95b5ab2be"
dependencies = [
 "cfg-if",
 "cpufeatures 0.2.17",
 "curve25519-dalek-derive",
 "digest",
 "fiat-crypto",
 "rustc_version",
 "subtle",
 "zeroize",
]

[[package]]
name = "curve25519-dalek-derive"
version = "0.1.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f46882e17999c6cc590af592290432be3bce0428cb0d5f8b6715e4dc7b383eb3"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 2.0.119",
]

[[package]]
name = "data-encoding"
version = "2.11.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4583a4551df46e2792f82ceeac45e850d2e2d5debba0b91f102385cda5b11f06"

[[package]]
name = "data-encoding-macro"
version = "0.1.21"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c6a127ecbb3c4632e1525380e04c0c3fcf8dcb44d32a79ea290d8a36906edcd8"
dependencies = [
 "data-encoding",
 "data-encoding-macro-internal",
]

[[package]]
name = "data-encoding-macro-internal"
version = "0.1.19"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c54e03a951783e8b327515db3f2a2fd0e3bed362a96b066f341ce66ed49b4ead"
dependencies = [
 "data-encoding",
 "syn 3.0.9",
]

[[package]]
name = "der"
version = "0.7.10"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e7c1832837b905bbfb5101e07cc24c8deddf52f93225eee6ead5f4d63d53ddcb"
dependencies = [
 "const-oid",
 "zeroize",
]

[[package]]
name = "der-parser"
version = "9.0.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "5cd0a5c643689626bec213c4d8bd4d96acc8ffdb4ad4bb6bc16abf27d5f4b553"
dependencies = [
 "asn1-rs",
 "displaydoc",
 "nom",
 "num-bigint",
 "num-traits",
 "rusticata-macros",
]

[[package]]
name = "deranged"
version = "0.5.9"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9e9de72ce2ad1f90dc62fa25f0f430ef85eb4b0d8fa0be4f30373bc40a21d28e"

[[package]]
name = "digest"
version = "0.10.7"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9ed9a281f7bc9b7576e61468ba615a66a5c8cfdff42420a70aa82701a3b1e292"
dependencies = [
 "block-buffer",
 "crypto-common",
 "subtle",
]

[[package]]
name = "displaydoc"
version = "0.2.7"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c6232dd377dcc64799954cbd3a9bb882e9cdc1308ccd87b1c098f1fb2eaf82a8"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 3.0.9",
]

[[package]]
name = "ed25519"
version = "2.2.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "115531babc129696a58c64a4fef0a8bf9e9698629fb97e9e40767d235cfbcd53"
dependencies = [
 "pkcs8",
 "signature",
]

[[package]]
name = "ed25519-dalek"
version = "2.2.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "70e796c081cee67dc755e1a36a0a172b897fab85fc3f6bc48307991f64e4eca9"
dependencies = [
 "curve25519-dalek",
 "ed25519",
 "serde",
 "sha2",
 "subtle",
 "zeroize",
]

[[package]]
name = "either"
version = "1.19.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0e9c71c2167ca323c882b99918929403426e2373ea17242ff5653e0d5e1058be"

[[package]]
name = "enum-as-inner"
version = "0.6.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a1e6a265c649f3f5979b601d26f1d05ada116434c87741c9493cb56218f76cbc"
dependencies = [
 "heck",
 "proc-macro2",
 "quote",
 "syn 2.0.119",
]

[[package]]
name = "equivalent"
version = "1.0.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "00d174d5400e5e8fd687ad1049e2f578285fa914201b1af7e8b112a4546bd826"

[[package]]
name = "errno"
version = "0.3.14"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "39cab71617ae0d63f51a36d69f866391735b51691dbda63cf6f96d042b63efeb"
dependencies = [
 "libc",
 "windows-sys 0.61.2",
]

[[package]]
name = "fiat-crypto"
version = "0.2.9"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "28dea519a9695b9977216879a3ebfddf92f1c08c05d984f8996aecd6ecdc811d"

[[package]]
name = "find-msvc-tools"
version = "0.1.15"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1c66915cc5391097de7a2b0b972e8505aa33c0df401fd3a6811dbdb32881ba48"

[[package]]
name = "fnv"
version = "1.0.7"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "3f9eec918d3f24069decb9af1554cad7c880e2da24a9afd88aca000531ab82c1"

[[package]]
name = "foldhash"
version = "0.1.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d9c4f5dac5e15c24eb999c26181a6ca40b39fe946cbe4c263c7209467bc83af2"

[[package]]
name = "form_urlencoded"
version = "1.2.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "cb4cb245038516f5f85277875cdaa4f7d2c9a0fa0468de06ed190163b1581fcf"
dependencies = [
 "percent-encoding",
]

[[package]]
name = "futures"
version = "0.3.34"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9a31d2a3fbaaeb2af2368bbdd904aa8e812d3c04a1ee10d3171f52d556e5d0a3"
dependencies = [
 "futures-channel",
 "futures-core",
 "futures-executor",
 "futures-io",
 "futures-sink",
 "futures-task",
 "futures-util",
]

[[package]]
name = "futures-bounded"
version = "0.2.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "91f328e7fb845fc832912fb6a34f40cf6d1888c92f974d1893a54e97b5ff542e"
dependencies = [
 "futures-timer",
 "futures-util",
]

[[package]]
name = "futures-channel"
version = "0.3.34"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b1f9e3d69d39e4862ffed03ed071a76f9a13ba1d9109d355b0f0aa6b15e393c4"
dependencies = [
 "futures-core",
 "futures-sink",
]

[[package]]
name = "futures-core"
version = "0.3.34"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "92d699e522242e69e3003b94ecc1f960f3a5e015aa7c5d7486e65ad01dd94f5e"

[[package]]
name = "futures-executor"
version = "0.3.34"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "031b47cf1a3c6cc8bc2fc76cd437f521619387907d469316e7c0bc278f1f5432"
dependencies = [
 "futures-core",
 "futures-task",
 "futures-util",
]

[[package]]
name = "futures-io"
version = "0.3.34"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "53c0fa8157de1303bfffdaa1cc2a673bfffb60102f76b0ef4441659124373fed"

[[package]]
name = "futures-lite"
version = "2.6.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f78e10609fe0e0b3f4157ffab1876319b5b0db102a2c60dc4626306dc46b44ad"
dependencies = [
 "futures-core",
 "pin-project-lite",
]

[[package]]
name = "futures-macro"
version = "0.3.34"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9fb9654ba8355388abeb8dcb4fc62f511300867002afc858860463bdd9fe0c44"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 3.0.9",
]

[[package]]
name = "futures-rustls"
version = "0.26.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a8f2f12607f92c69b12ed746fabf9ca4f5c482cba46679c1a75b874ed7c26adb"
dependencies = [
 "futures-io",
 "rustls",
 "rustls-pki-types",
]

[[package]]
name = "futures-sink"
version = "0.3.34"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1944426bf7d03f1d14f708785e4b33efd750b36d48a157b836b3efc15ede8e1d"

[[package]]
name = "futures-task"
version = "0.3.34"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "cd417de3d1d015fc3bfd2b1ea46dfc7bab72ef86f1cc7cc9c78e728b34a6d1fd"

[[package]]
name = "futures-timer"
version = "3.0.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "af43fadb8a98512d547e37b4e92e0ced13e205c061b87b4623eff01d918d6968"

[[package]]
name = "futures-util"
version = "0.3.34"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0d50a92467f8ba5dd6e3ee5d4bd04d73ab2e4e1c44474a0674821dfce14b79bc"
dependencies = [
 "futures-channel",
 "futures-core",
 "futures-io",
 "futures-macro",
 "futures-sink",
 "futures-task",
 "memchr",
 "pin-project-lite",
 "slab",
]

[[package]]
name = "generic-array"
version = "0.14.7"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "85649ca51fd72272d7821adaf274ad91c288277713d9c18820d8499a7ff69e9a"
dependencies = [
 "typenum",
 "version_check",
]

[[package]]
name = "getrandom"
version = "0.2.17"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ff2abc00be7fca6ebc474524697ae276ad847ad0a6b3faa4bcb027e9a4614ad0"
dependencies = [
 "cfg-if",
 "js-sys",
 "libc",
 "wasi",
 "wasm-bindgen",
]

[[package]]
name = "getrandom"
version = "0.3.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "899def5c37c4fd7b2664648c28120ecec138e4d395b459e5ca34f9cce2dd77fd"
dependencies = [
 "cfg-if",
 "libc",
 "r-efi 5.3.0",
 "wasip2",
]

[[package]]
name = "getrandom"
version = "0.4.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "300e883d756b2e4ec94e02791f39b04b522276138852cfc41d9fb7e904106099"
dependencies = [
 "cfg-if",
 "js-sys",
 "libc",
 "r-efi 6.0.0",
 "rand_core 0.10.1",
 "wasm-bindgen",
]

[[package]]
name = "ghash"
version = "0.5.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f0d8a4362ccb29cb0b265253fb0a2728f592895ee6854fd9bc13f2ffda266ff1"
dependencies = [
 "opaque-debug",
 "polyval",
]

[[package]]
name = "h2"
version = "0.3.27"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0beca50380b1fc32983fc1cb4587bfa4bb9e78fc259aad4a0032d2080309222d"
dependencies = [
 "bytes",
 "fnv",
 "futures-core",
 "futures-sink",
 "futures-util",
 "http",
 "indexmap",
 "slab",
 "tokio",
 "tokio-util",
 "tracing",
]

[[package]]
name = "hashbrown"
version = "0.15.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9229cfe53dfd69f0609a49f65461bd93001ea1ef889cd5529dd176593f5338a1"
dependencies = [
 "allocator-api2",
 "equivalent",
 "foldhash",
]

[[package]]
name = "hashbrown"
version = "0.17.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ed5909b6e89a2db4456e54cd5f673791d7eca6732202bbf2a9cc504fe2f9b84a"

[[package]]
name = "heck"
version = "0.5.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2304e00983f87ffb38b55b444b5e3b60a884b5d30c0fca7d82fe33449bbe55ea"

[[package]]
name = "hermit-abi"
version = "0.5.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e17592d60ebacc7d5e169f4663c5f84f9161cc90328abcfe8456f41e4dfcb284"

[[package]]
name = "hickory-proto"
version = "0.24.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "92652067c9ce6f66ce53cc38d1169daa36e6e7eb7dd3b63b5103bd9d97117248"
dependencies = [
 "async-trait",
 "cfg-if",
 "data-encoding",
 "enum-as-inner",
 "futures-channel",
 "futures-io",
 "futures-util",
 "idna",
 "ipnet",
 "once_cell",
 "rand 0.8.8",
 "socket2 0.5.10",
 "thiserror 1.0.69",
 "tinyvec",
 "tokio",
 "tracing",
 "url",
]

[[package]]
name = "hickory-resolver"
version = "0.24.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "cbb117a1ca520e111743ab2f6688eddee69db4e0ea242545a604dce8a66fd22e"
dependencies = [
 "cfg-if",
 "futures-util",
 "hickory-proto",
 "ipconfig",
 "lru-cache",
 "once_cell",
 "parking_lot",
 "rand 0.8.8",
 "resolv-conf",
 "smallvec",
 "thiserror 1.0.69",
 "tokio",
 "tracing",
]

[[package]]
name = "hkdf"
version = "0.12.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "7b5f8eb2ad728638ea2c7d47a21db23b7b58a72ed6a38256b8a1849f15fbbdf7"
dependencies = [
 "hmac",
]

[[package]]
name = "hmac"
version = "0.12.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "6c49c37c09c17a53d937dfbb742eb3a961d65a994e6bcdcf37e7399d0cc8ab5e"
dependencies = [
 "digest",
]

[[package]]
name = "http"
version = "0.2.12"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "601cbb57e577e2f5ef5be8e7b83f0f63994f25aa94d673e54a92d5c516d101f1"
dependencies = [
 "bytes",
 "fnv",
 "itoa",
]

[[package]]
name = "http-body"
version = "0.4.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "7ceab25649e9960c0311ea418d17bee82c0dcec1bd053b5f9a66e265a693bed2"
dependencies = [
 "bytes",
 "http",
 "pin-project-lite",
]

[[package]]
name = "httparse"
version = "1.10.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "6dbf3de79e51f3d586ab4cb9d5c3e2c14aa28ed23d180cf89b4df0454a69cc87"

[[package]]
name = "httpdate"
version = "1.0.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "df3b46402a9d5adb4c86a0cf463f42e19994e3ee891101b1841f30a545cb49a9"

[[package]]
name = "hyper"
version = "0.14.32"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "41dfc780fdec9373c01bae43289ea34c972e40ee3c9f6b3c8801a35f35586ce7"
dependencies = [
 "bytes",
 "futures-channel",
 "futures-core",
 "futures-util",
 "h2",
 "http",
 "http-body",
 "httparse",
 "httpdate",
 "itoa",
 "pin-project-lite",
 "socket2 0.5.10",
 "tokio",
 "tower-service",
 "tracing",
 "want",
]

[[package]]
name = "icu_collections"
version = "2.4.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "fe090a42a0d3140fed8c63263ed1fecc02422cb2f4bfe55cd8de2de1b8e105dd"
dependencies = [
 "displaydoc",
 "potential_utf",
 "utf8_iter",
 "yoke",
 "zerofrom",
 "zerovec",
]

[[package]]
name = "icu_locale_core"
version = "2.4.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "25d29b57c17c6528d0dc4c2141cfa2d08200465acb537a3909c8b9b8a4a984c0"
dependencies = [
 "displaydoc",
 "litemap",
 "tinystr",
 "writeable",
 "zerovec",
]

[[package]]
name = "icu_normalizer"
version = "2.4.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "404a3b8c486f205c87fe7f23ab6894d84a4ad76d6e4671ae1981ba7def87c599"
dependencies = [
 "icu_collections",
 "icu_normalizer_data",
 "icu_properties",
 "icu_provider",
 "smallvec",
 "zerovec",
]

[[package]]
name = "icu_normalizer_data"
version = "2.4.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "20f0088bfb7441f7a37fa0c9e20cb1e9cba1cac6b9ce8cd2a6dc44294f8e8cbc"

[[package]]
name = "icu_properties"
version = "2.4.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2ea83d991c56158f7cf898bf86436c1dfe7c07ee82fe88951f2695c9f37a379f"
dependencies = [
 "displaydoc",
 "icu_collections",
 "icu_locale_core",
 "icu_properties_data",
 "icu_provider",
 "zerotrie",
 "zerovec",
]

[[package]]
name = "icu_properties_data"
version = "2.4.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b98f29af82d02b163fe50161388350e743bb3107cc8e8c2f7314cb505faddfcf"

[[package]]
name = "icu_provider"
version = "2.4.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "413099315636c588ee8f011190b329b971a09a8fae9d157e01dcae8379468514"
dependencies = [
 "displaydoc",
 "icu_locale_core",
 "writeable",
 "yoke",
 "zerofrom",
 "zerotrie",
 "zerovec",
]

[[package]]
name = "idna"
version = "1.1.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "3b0875f23caa03898994f6ddc501886a45c7d3d62d04d2d90788d47be1b1e4de"
dependencies = [
 "idna_adapter",
 "smallvec",
 "utf8_iter",
]

[[package]]
name = "idna_adapter"
version = "1.2.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "cb68373c0d6620ef8105e855e7745e18b0d00d3bdb07fb532e434244cdb9a714"
dependencies = [
 "icu_normalizer",
 "icu_properties",
]

[[package]]
name = "if-addrs"
version = "0.15.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c0a05c691e1fae256cf7013d99dad472dc52d5543322761f83ec8d47eab40d2b"
dependencies = [
 "libc",
 "windows-sys 0.61.2",
]

[[package]]
name = "if-watch"
version = "3.2.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "71c02a5161c313f0cbdbadc511611893584a10a7b6153cb554bdf83ddce99ec2"
dependencies = [
 "async-io",
 "core-foundation",
 "fnv",
 "futures",
 "if-addrs",
 "ipnet",
 "log",
 "netlink-packet-core",
 "netlink-packet-route",
 "netlink-proto",
 "netlink-sys",
 "rtnetlink",
 "system-configuration",
 "tokio",
 "windows",
]

[[package]]
name = "igd-next"
version = "0.14.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "064d90fec10d541084e7b39ead8875a5a80d9114a2b18791565253bae25f49e4"
dependencies = [
 "async-trait",
 "attohttpc",
 "bytes",
 "futures",
 "http",
 "hyper",
 "log",
 "rand 0.8.8",
 "tokio",
 "url",
 "xmltree",
]

[[package]]
name = "indexmap"
version = "2.14.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "cc4e190f5d26ca7051642629da2c52fc03bde85a03197c99408dcd291734c855"
dependencies = [
 "equivalent",
 "hashbrown 0.17.1",
]

[[package]]
name = "inout"
version = "0.1.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "879f10e63c20629ecabbb64a8010319738c66a5cd0c29b02d63d272b03751d01"
dependencies = [
 "generic-array",
]

[[package]]
name = "instant"
version = "0.1.13"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e0242819d153cba4b4b05a5a8f2a7e9bbf97b6055b2a002b395c96b5ff3c0222"
dependencies = [
 "cfg-if",
]

[[package]]
name = "ipconfig"
version = "0.3.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4d40460c0ce33d6ce4b0630ad68ff63d6661961c48b6dba35e5a4d81cfb48222"
dependencies = [
 "socket2 0.6.5",
 "widestring",
 "windows-registry",
 "windows-result",
 "windows-sys 0.61.2",
]

[[package]]
name = "ipnet"
version = "2.12.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "791930b43c0d5973160d90a8f3894509f2b273430f5c5c73b668636d0287c5c0"

[[package]]
name = "is_terminal_polyfill"
version = "1.70.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a6cb138bb79a146c1bd460005623e142ef0181e3d0219cb493e02f7d08a35695"

[[package]]
name = "itertools"
version = "0.14.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2b192c782037fadd9cfa75548310488aabdbf3d2da73885b31bd0abd03351285"
dependencies = [
 "either",
]

[[package]]
name = "itoa"
version = "1.0.18"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "8f42a60cbdf9a97f5d2305f08a87dc4e09308d1276d28c869c684d7777685682"

[[package]]
name = "js-sys"
version = "0.3.107"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "8dc09d2154098bbf4ef54eab6b117a3c24cbbffe94046b16ee6d6d4510584d3a"
dependencies = [
 "cfg-if",
 "futures-util",
 "wasm-bindgen",
]

[[package]]
name = "lazy_static"
version = "1.5.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "20870f649af7073d53e38067b2a84312175d56ea15217e1b15bc83506ec50afb"

[[package]]
name = "libc"
version = "0.2.191"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "65cd87c9a6d60536580b316ad985726104730a5151c99845f2490428ef91240a"

[[package]]
name = "libp2p"
version = "0.53.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "681fb3f183edfbedd7a57d32ebe5dcdc0b9f94061185acf3c30249349cc6fc99"
dependencies = [
 "bytes",
 "either",
 "futures",
 "futures-timer",
 "getrandom 0.2.17",
 "instant",
 "libp2p-allow-block-list",
 "libp2p-connection-limits",
 "libp2p-core",
 "libp2p-dns",
 "libp2p-identity",
 "libp2p-mdns",
 "libp2p-noise",
 "libp2p-quic",
 "libp2p-request-response",
 "libp2p-swarm",
 "libp2p-tcp",
 "libp2p-upnp",
 "libp2p-yamux",
 "multiaddr",
 "pin-project",
 "rw-stream-sink",
 "thiserror 1.0.69",
]

[[package]]
name = "libp2p-allow-block-list"
version = "0.3.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "107b238b794cb83ab53b74ad5dcf7cca3200899b72fe662840cfb52f5b0a32e6"
dependencies = [
 "libp2p-core",
 "libp2p-identity",
 "libp2p-swarm",
 "void",
]

[[package]]
name = "libp2p-connection-limits"
version = "0.3.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c7cd50a78ccfada14de94cbacd3ce4b0138157f376870f13d3a8422cd075b4fd"
dependencies = [
 "libp2p-core",
 "libp2p-identity",
 "libp2p-swarm",
 "void",
]

[[package]]
name = "libp2p-core"
version = "0.41.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a5a8920cbd8540059a01950c1e5c96ea8d89eb50c51cd366fc18bdf540a6e48f"
dependencies = [
 "either",
 "fnv",
 "futures",
 "futures-timer",
 "libp2p-identity",
 "multiaddr",
 "multihash",
 "multistream-select",
 "once_cell",
 "parking_lot",
 "pin-project",
 "quick-protobuf",
 "rand 0.8.8",
 "rw-stream-sink",
 "smallvec",
 "thiserror 1.0.69",
 "tracing",
 "unsigned-varint 0.8.0",
 "void",
 "web-time",
]

[[package]]
name = "libp2p-dns"
version = "0.41.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d17cbcf7160ff35c3e8e560de4a068fe9d6cb777ea72840e48eb76ff9576c4b6"
dependencies = [
 "async-trait",
 "futures",
 "hickory-resolver",
 "libp2p-core",
 "libp2p-identity",
 "parking_lot",
 "smallvec",
 "tracing",
]

[[package]]
name = "libp2p-identity"
version = "0.2.14"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9525f3831544f7ae497bde79adf114ef127b0fbbb97edbbf692a80408636421c"
dependencies = [
 "bs58",
 "ed25519-dalek",
 "hkdf",
 "multihash",
 "prost",
 "rand 0.8.8",
 "sha2",
 "thiserror 2.0.21",
 "tracing",
 "zeroize",
]

[[package]]
name = "libp2p-mdns"
version = "0.45.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "49007d9a339b3e1d7eeebc4d67c05dbf23d300b7d091193ec2d3f26802d7faf2"
dependencies = [
 "data-encoding",
 "futures",
 "hickory-proto",
 "if-watch",
 "libp2p-core",
 "libp2p-identity",
 "libp2p-swarm",
 "rand 0.8.8",
 "smallvec",
 "socket2 0.5.10",
 "tokio",
 "tracing",
 "void",
]

[[package]]
name = "libp2p-noise"
version = "0.44.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "8ecd0545ce077f6ea5434bcb76e8d0fe942693b4380aaad0d34a358c2bd05793"
dependencies = [
 "asynchronous-codec",
 "bytes",
 "curve25519-dalek",
 "futures",
 "libp2p-core",
 "libp2p-identity",
 "multiaddr",
 "multihash",
 "once_cell",
 "quick-protobuf",
 "rand 0.8.8",
 "sha2",
 "snow",
 "static_assertions",
 "thiserror 1.0.69",
 "tracing",
 "x25519-dalek",
 "zeroize",
]

[[package]]
name = "libp2p-quic"
version = "0.10.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c67296ad4e092e23f92aea3d2bdb6f24eab79c0929ed816dfb460ea2f4567d2b"
dependencies = [
 "bytes",
 "futures",
 "futures-timer",
 "if-watch",
 "libp2p-core",
 "libp2p-identity",
 "libp2p-tls",
 "parking_lot",
 "quinn",
 "rand 0.8.8",
 "ring 0.17.14",
 "rustls",
 "socket2 0.5.10",
 "thiserror 1.0.69",
 "tokio",
 "tracing",
]

[[package]]
name = "libp2p-request-response"
version = "0.26.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c314fe28368da5e3a262553fb0ad575c1c8934c461e10de10265551478163836"
dependencies = [
 "async-trait",
 "futures",
 "futures-bounded",
 "futures-timer",
 "instant",
 "libp2p-core",
 "libp2p-identity",
 "libp2p-swarm",
 "rand 0.8.8",
 "serde",
 "serde_json",
 "smallvec",
 "tracing",
 "void",
]

[[package]]
name = "libp2p-swarm"
version = "0.44.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "80cae6cb75f89dbca53862f9ebe0b9f463aa7b302762fcfaafb9e51dcc9b0f7e"
dependencies = [
 "either",
 "fnv",
 "futures",
 "futures-timer",
 "instant",
 "libp2p-core",
 "libp2p-identity",
 "libp2p-swarm-derive",
 "lru",
 "multistream-select",
 "once_cell",
 "rand 0.8.8",
 "smallvec",
 "tokio",
 "tracing",
 "void",
]

[[package]]
name = "libp2p-swarm-derive"
version = "0.34.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "5daceb9dd908417b6dfcfe8e94098bc4aac54500c282e78120b885dadc09b999"
dependencies = [
 "heck",
 "proc-macro2",
 "quote",
 "syn 2.0.119",
]

[[package]]
name = "libp2p-tcp"
version = "0.41.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "8b2460fc2748919adff99ecbc1aab296e4579e41f374fb164149bd2c9e529d4c"
dependencies = [
 "futures",
 "futures-timer",
 "if-watch",
 "libc",
 "libp2p-core",
 "libp2p-identity",
 "socket2 0.5.10",
 "tokio",
 "tracing",
]

[[package]]
name = "libp2p-tls"
version = "0.4.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "72b7b831e55ce2aa6c354e6861a85fdd4dd0a2b97d5e276fabac0e4810a71776"
dependencies = [
 "futures",
 "futures-rustls",
 "libp2p-core",
 "libp2p-identity",
 "rcgen",
 "ring 0.17.14",
 "rustls",
 "rustls-webpki 0.101.7",
 "thiserror 1.0.69",
 "x509-parser",
 "yasna",
]

[[package]]
name = "libp2p-upnp"
version = "0.2.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "cccf04b0e3ff3de52d07d5fd6c3b061d0e7f908ffc683c32d9638caedce86fc8"
dependencies = [
 "futures",
 "futures-timer",
 "igd-next",
 "libp2p-core",
 "libp2p-swarm",
 "tokio",
 "tracing",
 "void",
]

[[package]]
name = "libp2p-yamux"
version = "0.45.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ddd5265f6b80f94d48a3963541aad183cc598a645755d2f1805a373e41e0716b"
dependencies = [
 "either",
 "futures",
 "libp2p-core",
 "thiserror 1.0.69",
 "tracing",
 "yamux 0.12.1",
 "yamux 0.13.10",
]

[[package]]
name = "linked-hash-map"
version = "0.5.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0717cef1bc8b636c6e1c1bbdefc09e6322da8a9321966e8928ef80d20f7f770f"

[[package]]
name = "linux-raw-sys"
version = "0.12.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "32a66949e030da00e8c7d4434b251670a91556f4144941d37452769c25d58a53"

[[package]]
name = "litemap"
version = "0.8.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "47d9d19d1d6efa0109d2f65ff4c85cddd50bd572e5a00127ab10987290bcefae"

[[package]]
name = "lock_api"
version = "0.4.14"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "224399e74b87b5f3557511d98dff8b14089b3dadafcab6bb93eab67d3aace965"
dependencies = [
 "scopeguard",
]

[[package]]
name = "log"
version = "0.4.34"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f9f8bd3e56ce4dfc153cf470fffbfa98c7620958b312ca5c3a4b8d5181fd13c6"

[[package]]
name = "lru"
version = "0.12.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "234cf4f4a04dc1f57e24b96cc0cd600cf2af460d4161ac5ecdd0af8e1f3b2a38"
dependencies = [
 "hashbrown 0.15.5",
]

[[package]]
name = "lru-cache"
version = "0.1.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "31e24f1ad8321ca0e8a1e0ac13f23cb668e6f5466c2c57319f6a5cf1cc8e3b1c"
dependencies = [
 "linked-hash-map",
]

[[package]]
name = "lru-slab"
version = "0.1.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4050469837a6ff301cd14c1f8f24f88549e6d548f24f64e2148eb0f72cebc51f"

[[package]]
name = "match-lookup"
version = "0.1.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "549e39695cc0b640f3cb378053832db3d2133422d49e8dcae5c866a2aaf1f730"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 2.0.119",
]

[[package]]
name = "memchr"
version = "2.8.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "cf8baf1c55e62ffcace7a9f06f4bd9cd3f0c4beb022d3b367256b91b87513d98"

[[package]]
name = "minimal-lexical"
version = "0.2.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "68354c5c6bd36d73ff3feceb05efa59b6acb7626617f4962be322a825e61f79a"

[[package]]
name = "mio"
version = "1.2.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1788edb87fdc09c7e26304471e2f5be8cdefb1b6930d6e3985fc02ff53bf86ee"
dependencies = [
 "libc",
 "wasi",
 "windows-sys 0.61.2",
]

[[package]]
name = "multiaddr"
version = "0.18.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "fe6351f60b488e04c1d21bc69e56b89cb3f5e8f5d22557d6e8031bdfd79b6961"
dependencies = [
 "arrayref",
 "byteorder",
 "data-encoding",
 "libp2p-identity",
 "multibase",
 "multihash",
 "percent-encoding",
 "serde",
 "static_assertions",
 "unsigned-varint 0.8.0",
 "url",
]

[[package]]
name = "multibase"
version = "0.9.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "7e0e4a371cbf1dfd666b658ba137763edb23c45beb43cfe369b5593cd6b437b6"
dependencies = [
 "base-x",
 "base256emoji",
 "base45",
 "data-encoding",
 "data-encoding-macro",
]

[[package]]
name = "multihash"
version = "0.19.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "577c63b00ad74d57e8c9aa870b5fccebf2fd64a308a5aee9f1bb88e4aea19447"
dependencies = [
 "unsigned-varint 0.8.0",
]

[[package]]
name = "multistream-select"
version = "0.13.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ea0df8e5eec2298a62b326ee4f0d7fe1a6b90a09dfcf9df37b38f947a8c42f19"
dependencies = [
 "bytes",
 "futures",
 "log",
 "pin-project",
 "smallvec",
 "unsigned-varint 0.7.2",
]

[[package]]
name = "netlink-packet-core"
version = "0.8.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b897d7bd4f0af82e68d40d0344cf37e97f9c97ddf74a098de3e4da05e96ca395"
dependencies = [
 "paste",
]

[[package]]
name = "netlink-packet-route"
version = "0.28.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4ce3636fa715e988114552619582b530481fd5ef176a1e5c1bf024077c2c9445"
dependencies = [
 "bitflags",
 "libc",
 "log",
 "netlink-packet-core",
]

[[package]]
name = "netlink-proto"
version = "0.12.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "93af8261786086024cd5e96e0a991dd65ced07bbf7c233a487bbc96b971d5539"
dependencies = [
 "bytes",
 "futures-channel",
 "futures-util",
 "log",
 "netlink-packet-core",
 "netlink-sys",
 "thiserror 2.0.21",
]

[[package]]
name = "netlink-sys"
version = "0.8.8"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "cd6c30ed10fa69cc491d491b85cc971f6bdeb8e7367b7cde2ee6cc878d583fae"
dependencies = [
 "bytes",
 "futures-util",
 "libc",
 "log",
 "tokio",
]

[[package]]
name = "nix"
version = "0.30.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "74523f3a35e05aba87a1d978330aef40f67b0304ac79c1c00b294c9830543db6"
dependencies = [
 "bitflags",
 "cfg-if",
 "cfg_aliases",
 "libc",
]

[[package]]
name = "nohash-hasher"
version = "0.2.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2bf50223579dc7cdcfb3bfcacf7069ff68243f8c363f62ffa99cf000a6b9c451"

[[package]]
name = "nom"
version = "7.1.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d273983c5a657a70a3e8f2a01329822f3b8c8172b73826411a55751e404a0a4a"
dependencies = [
 "memchr",
 "minimal-lexical",
]

[[package]]
name = "num-bigint"
version = "0.4.8"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c89e69e7e0f03bea5ef08013795c25018e101932225a656383bd384495ecc367"
dependencies = [
 "num-integer",
 "num-traits",
]

[[package]]
name = "num-conv"
version = "0.2.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "521739c6d2bac4aa25192232afe6841231376b2b26d4d9fae5ecf8ca5772e441"

[[package]]
name = "num-integer"
version = "0.1.47"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "7ce2d95d4b3734dc35aa2f45e1aa22cd416814592a4f9d9205e11affd5b8e10b"
dependencies = [
 "num-traits",
]

[[package]]
name = "num-traits"
version = "0.2.19"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "071dfc062690e90b734c0b2273ce72ad0ffa95f0c74596bc250dcfd960262841"
dependencies = [
 "autocfg",
]

[[package]]
name = "oid-registry"
version = "0.7.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a8d8034d9489cdaf79228eb9f6a3b8d7bb32ba00d6645ebd48eef4077ceb5bd9"
dependencies = [
 "asn1-rs",
]

[[package]]
name = "once_cell"
version = "1.21.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9f7c3e4beb33f85d45ae3e3a1792185706c8e16d043238c593331cc7cd313b50"

[[package]]
name = "once_cell_polyfill"
version = "1.70.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "384b8ab6d37215f3c5301a95a4accb5d64aa607f1fcb26a11b5303878451b4fe"

[[package]]
name = "opaque-debug"
version = "0.3.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c08d65885ee38876c4f86fa503fb49d7b507c2b62552df7c70b2fce627e06381"

[[package]]
name = "parking"
version = "2.2.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f38d5652c16fde515bb1ecef450ab0f6a219d619a7274976324d5e377f7dceba"

[[package]]
name = "parking_lot"
version = "0.12.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "93857453250e3077bd71ff98b6a65ea6621a19bb0f559a85248955ac12c45a1a"
dependencies = [
 "lock_api",
 "parking_lot_core",
]

[[package]]
name = "parking_lot_core"
version = "0.9.12"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2621685985a2ebf1c516881c026032ac7deafcda1a2c9b7850dc81e3dfcb64c1"
dependencies = [
 "cfg-if",
 "libc",
 "redox_syscall",
 "smallvec",
 "windows-link",
]

[[package]]
name = "paste"
version = "1.0.15"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "57c0d7b74b563b49d38dae00a0c37d4d6de9b432382b2892f0574ddcae73fd0a"

[[package]]
name = "pem"
version = "3.0.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1d30c53c26bc5b31a98cd02d20f25a7c8567146caf63ed593a9d87b2775291be"
dependencies = [
 "base64",
 "serde_core",
]

[[package]]
name = "percent-encoding"
version = "2.3.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9b4f627cb1b25917193a259e49bdad08f671f8d9708acfd5fe0a8c1455d87220"

[[package]]
name = "pin-project"
version = "1.1.13"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2466b2336ed02bcdca6b294417127b90ec92038d1d5c4fbeac971a922e0e0924"
dependencies = [
 "pin-project-internal",
]

[[package]]
name = "pin-project-internal"
version = "1.1.13"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c96395f0a926bc13b1c17622aaddda1ecb55d49c8f1bf9777e4d877800a43f8b"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 2.0.119",
]

[[package]]
name = "pin-project-lite"
version = "0.2.17"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a89322df9ebe1c1578d689c92318e070967d1042b512afbe49518723f4e6d5cd"

[[package]]
name = "pkcs8"
version = "0.10.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f950b2377845cebe5cf8b5165cb3cc1a5e0fa5cfa3e1f7f55707d8fd82e0a7b7"
dependencies = [
 "der",
 "spki",
]

[[package]]
name = "polling"
version = "3.11.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "5d0e4f59085d47d8241c88ead0f274e8a0cb551f3625263c05eb8dd897c34218"
dependencies = [
 "cfg-if",
 "concurrent-queue",
 "hermit-abi",
 "pin-project-lite",
 "rustix",
 "windows-sys 0.61.2",
]

[[package]]
name = "poly1305"
version = "0.8.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "8159bd90725d2df49889a078b54f4f79e87f1f8a8444194cdca81d38f5393abf"
dependencies = [
 "cpufeatures 0.2.17",
 "opaque-debug",
 "universal-hash",
]

[[package]]
name = "polyval"
version = "0.6.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9d1fe60d06143b2430aa532c94cfe9e29783047f06c0d7fd359a9a51b729fa25"
dependencies = [
 "cfg-if",
 "cpufeatures 0.2.17",
 "opaque-debug",
 "universal-hash",
]

[[package]]
name = "potential_utf"
version = "0.1.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d83eb9bc6d8e5cf568e7a1101d60ee05e81ed50ea106026f3d18deeb046d7661"
dependencies = [
 "zerovec",
]

[[package]]
name = "powerfmt"
version = "0.2.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4a6394b9e965e73d0a289ee54f589087e2c676aedf60885baf52c76b771e4958"

[[package]]
name = "ppv-lite86"
version = "0.2.21"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "85eae3c4ed2f50dcfe72643da4befc30deadb458a9b590d720cde2f2b1e97da9"
dependencies = [
 "zerocopy",
]

[[package]]
name = "proc-macro2"
version = "1.0.107"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "985e7ec9bb745e6ce6535b544d84d6cd6f7ad8bd711c398938ae983b91a766d9"
dependencies = [
 "unicode-ident",
]

[[package]]
name = "prost"
version = "0.14.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "528ac67416ff8646872a3c02cad9cc4ee5dc9f9540c9b10771855c95cb2e5ae1"
dependencies = [
 "bytes",
 "prost-derive",
]

[[package]]
name = "prost-derive"
version = "0.14.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b570b25f7617e43d59005d0990ccb79e950a423952cea19671b7a876da390adf"
dependencies = [
 "anyhow",
 "itertools",
 "proc-macro2",
 "quote",
 "syn 2.0.119",
]

[[package]]
name = "quick-protobuf"
version = "0.8.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9d6da84cc204722a989e01ba2f6e1e276e190f22263d0cb6ce8526fcdb0d2e1f"
dependencies = [
 "byteorder",
]

[[package]]
name = "quinn"
version = "0.11.12"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4051e23e9185c255a7e33ef59cdbca87a22d359052eecd22fc6b901fb37d9d11"
dependencies = [
 "bytes",
 "cfg_aliases",
 "futures-io",
 "pin-project-lite",
 "quinn-proto",
 "quinn-udp",
 "rustc-hash",
 "rustls",
 "socket2 0.6.5",
 "thiserror 2.0.21",
 "tokio",
 "tracing",
 "web-time",
]

[[package]]
name = "quinn-proto"
version = "0.11.19"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0e750cca55fe4f0439a15d0bb529da9651e79993e8e72c61a899a36d462befbe"
dependencies = [
 "bytes",
 "getrandom 0.4.3",
 "lru-slab",
 "rand 0.10.3",
 "rand_pcg",
 "ring 0.17.14",
 "rustc-hash",
 "rustls",
 "rustls-pki-types",
 "slab",
 "thiserror 2.0.21",
 "tinyvec",
 "tracing",
 "web-time",
]

[[package]]
name = "quinn-udp"
version = "0.5.16"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "af66907df18639dcf4db56ca65490cabc4b27a97dbadd96f2926cca73298f016"
dependencies = [
 "cfg_aliases",
 "libc",
 "once_cell",
 "socket2 0.6.5",
 "tracing",
 "windows-sys 0.61.2",
]

[[package]]
name = "quote"
version = "1.0.47"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1fbf4db142a473a8d80c26bbf18454ed458bf8d26c8219c331daecfdbd079001"
dependencies = [
 "proc-macro2",
]

[[package]]
name = "r-efi"
version = "5.3.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "69cdb34c158ceb288df11e18b4bd39de994f6657d83847bdffdbd7f346754b0f"

[[package]]
name = "r-efi"
version = "6.0.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f8dcc9c7d52a811697d2151c701e0d08956f92b0e24136cf4cf27b57a6a0d9bf"

[[package]]
name = "rand"
version = "0.8.8"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e058c7de0b26af77780c769414d6257830bb240f3c38477dbc2c16e5f54d6d4c"
dependencies = [
 "libc",
 "rand_chacha 0.3.1",
 "rand_core 0.6.4",
]

[[package]]
name = "rand"
version = "0.9.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b9ef1d0d795eb7d84685bca4f72f3649f064e6641543d3a8c415898726a57b41"
dependencies = [
 "rand_chacha 0.9.0",
 "rand_core 0.9.5",
]

[[package]]
name = "rand"
version = "0.10.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "65c9fb96cbc91e3478eaae79a69fcd3f1ae4ad052e471fe6732fff548984b4af"
dependencies = [
 "chacha20 0.10.2",
 "getrandom 0.4.3",
 "rand_core 0.10.1",
]

[[package]]
name = "rand_chacha"
version = "0.3.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e6c10a63a0fa32252be49d21e7709d4d4baf8d231c2dbce1eaa8141b9b127d88"
dependencies = [
 "ppv-lite86",
 "rand_core 0.6.4",
]

[[package]]
name = "rand_chacha"
version = "0.9.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d3022b5f1df60f26e1ffddd6c66e8aa15de382ae63b3a0c1bfc0e4d3e3f325cb"
dependencies = [
 "ppv-lite86",
 "rand_core 0.9.5",
]

[[package]]
name = "rand_core"
version = "0.6.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ec0be4795e2f6a28069bec0b5ff3e2ac9bafc99e6a9a7dc3547996c5c816922c"
dependencies = [
 "getrandom 0.2.17",
]

[[package]]
name = "rand_core"
version = "0.9.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "76afc826de14238e6e8c374ddcc1fa19e374fd8dd986b0d2af0d02377261d83c"
dependencies = [
 "getrandom 0.3.4",
]

[[package]]
name = "rand_core"
version = "0.10.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "63b8176103e19a2643978565ca18b50549f6101881c443590420e4dc998a3c69"

[[package]]
name = "rand_pcg"
version = "0.10.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "caa0f4137e1c0a72f4c651489402276c8e8e1cf081f3b0ba156d2cbeef09e86a"
dependencies = [
 "rand_core 0.10.1",
]

[[package]]
name = "rcgen"
version = "0.11.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "52c4f3084aa3bc7dfbba4eff4fab2a54db4324965d8872ab933565e6fbd83bc6"
dependencies = [
 "pem",
 "ring 0.16.20",
 "time",
 "yasna",
]

[[package]]
name = "redox_syscall"
version = "0.5.18"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ed2bf2547551a7053d6fdfafda3f938979645c44812fbfcda098faae3f1a362d"
dependencies = [
 "bitflags",
]

[[package]]
name = "resolv-conf"
version = "0.7.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1e061d1b48cb8d38042de4ae0a7a6401009d6143dc80d2e2d6f31f0bdd6470c7"

[[package]]
name = "ring"
version = "0.16.20"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "3053cf52e236a3ed746dfc745aa9cacf1b791d846bdaf412f60a8d7d6e17c8fc"
dependencies = [
 "cc",
 "libc",
 "once_cell",
 "spin",
 "untrusted 0.7.1",
 "web-sys",
 "winapi",
]

[[package]]
name = "ring"
version = "0.17.14"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a4689e6c2294d81e88dc6261c768b63bc4fcdb852be6d1352498b114f61383b7"
dependencies = [
 "cc",
 "cfg-if",
 "getrandom 0.2.17",
 "libc",
 "untrusted 0.9.0",
 "windows-sys 0.52.0",
]

[[package]]
name = "rtnetlink"
version = "0.20.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4b960d5d873a75b5be9761b1e73b146f52dddcd27bac75263f40fba686d4d7b5"
dependencies = [
 "futures-channel",
 "futures-util",
 "log",
 "netlink-packet-core",
 "netlink-packet-route",
 "netlink-proto",
 "netlink-sys",
 "nix",
 "thiserror 1.0.69",
 "tokio",
]

[[package]]
name = "rustc-hash"
version = "2.1.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "6b1e7f9a428571be2dc5bc0505c13fb6bf936822b894ec87abf8a08a4e51742d"

[[package]]
name = "rustc_version"
version = "0.4.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "cfcb3a22ef46e85b45de6ee7e79d063319ebb6594faafcf1c225ea92ab6e9b92"
dependencies = [
 "semver",
]

[[package]]
name = "rusticata-macros"
version = "4.1.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "faf0c4a6ece9950b9abdb62b1cfcf2a68b3b67a10ba445b3bb85be2a293d0632"
dependencies = [
 "nom",
]

[[package]]
name = "rustix"
version = "1.1.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e5e76742e5294153d4dde1207dbec5bdd81eef6fabdc0d2118babadabfd858aa"
dependencies = [
 "bitflags",
 "errno",
 "libc",
 "linux-raw-sys",
 "windows-sys 0.61.2",
]

[[package]]
name = "rustls"
version = "0.23.46"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "48e13bd8c0e9365c43cfa5c9e8f9ad49d3c8444926c9aac819e0e4dc503c8fdf"
dependencies = [
 "once_cell",
 "ring 0.17.14",
 "rustls-pki-types",
 "rustls-webpki 0.103.16",
 "subtle",
 "zeroize",
]

[[package]]
name = "rustls-pki-types"
version = "1.15.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2f4925028c7eb5d1fcdaf196971378ed9d2c1c4efc7dc5d011256f76c99c0a96"
dependencies = [
 "web-time",
 "zeroize",
]

[[package]]
name = "rustls-webpki"
version = "0.101.7"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "8b6275d1ee7a1cd780b64aca7726599a1dbc893b1e64144529e55c3c2f745765"
dependencies = [
 "ring 0.17.14",
 "untrusted 0.9.0",
]

[[package]]
name = "rustls-webpki"
version = "0.103.16"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4443b1b6d39d7c663139942cc4558262562d2c84123bb6282ef177009ca8b281"
dependencies = [
 "ring 0.17.14",
 "rustls-pki-types",
 "untrusted 0.9.0",
]

[[package]]
name = "rustversion"
version = "1.0.23"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "cf54715a573b99ac80df0bc206da022bcd442c974952c7b9720069370852e21f"

[[package]]
name = "rw-stream-sink"
version = "0.4.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d8c9026ff5d2f23da5e45bbc283f156383001bfb09c4e44256d02c1a685fe9a1"
dependencies = [
 "futures",
 "pin-project",
 "static_assertions",
]

[[package]]
name = "scopeguard"
version = "1.2.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "94143f37725109f92c262ed2cf5e59bce7498c01bcc1502d7b9afe439a4e9f49"

[[package]]
name = "semver"
version = "1.0.28"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "8a7852d02fc848982e0c167ef163aaff9cd91dc640ba85e263cb1ce46fae51cd"

[[package]]
name = "serde"
version = "1.0.229"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4148590afebada386688f18773da617792bf2ef03ffc1e4cbd2b1d45b023e0ba"
dependencies = [
 "serde_core",
 "serde_derive",
]

[[package]]
name = "serde_core"
version = "1.0.229"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "67dca2c9c51e58a4791a4b1ed58308b39c64224d349a935ab5039aa360942a48"
dependencies = [
 "serde_derive",
]

[[package]]
name = "serde_derive"
version = "1.0.229"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e7a5d71263a5a7d47b41f6b3f06ba276f10cc18b0931f1799f710578e2309348"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 3.0.9",
]

[[package]]
name = "serde_json"
version = "1.0.154"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e7e9cc8b1b85264074fbcc02a88680c4096b1e47df8f739dceb03bf482f04bd6"
dependencies = [
 "itoa",
 "memchr",
 "serde",
 "serde_core",
 "zmij",
]

[[package]]
name = "sha2"
version = "0.10.9"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a7507d819769d01a365ab707794a4084392c824f54a7a6a7862f8c3d0892b283"
dependencies = [
 "cfg-if",
 "cpufeatures 0.2.17",
 "digest",
]

[[package]]
name = "shlex"
version = "2.0.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f8fadd59c855ef2080decdef8ff161eb6661b86933c9d82e5ba29dc602a55aba"

[[package]]
name = "signal-hook-registry"
version = "1.4.8"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c4db69cba1110affc0e9f7bcd48bbf87b3f4fc7c61fc9155afd4c469eb3d6c1b"
dependencies = [
 "errno",
 "libc",
]

[[package]]
name = "signature"
version = "2.2.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "77549399552de45a898a580c1b41d445bf730df867cc44e6c0233bbc4b8329de"
dependencies = [
 "rand_core 0.6.4",
]

[[package]]
name = "slab"
version = "0.4.12"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0c790de23124f9ab44544d7ac05d60440adc586479ce501c1d6d7da3cd8c9cf5"

[[package]]
name = "smallvec"
version = "1.16.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d0d5d4b1981b8bbbb7aed204cae5726d683d5d6ac7e74ec54122ea28f315e7c8"

[[package]]
name = "snow"
version = "0.9.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "850948bee068e713b8ab860fe1adc4d109676ab4c3b621fd8147f06b261f2f85"
dependencies = [
 "aes-gcm",
 "blake2",
 "chacha20poly1305",
 "curve25519-dalek",
 "rand_core 0.6.4",
 "ring 0.17.14",
 "rustc_version",
 "sha2",
 "subtle",
]

[[package]]
name = "socket2"
version = "0.5.10"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e22376abed350d73dd1cd119b57ffccad95b4e585a7cda43e286245ce23c0678"
dependencies = [
 "libc",
 "windows-sys 0.52.0",
]

[[package]]
name = "socket2"
version = "0.6.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c3d1e2c7f27f8d4cb10542a02c49005dbd6e93095799d6f3be745fae9f8fedd4"
dependencies = [
 "libc",
 "windows-sys 0.61.2",
]

[[package]]
name = "spin"
version = "0.5.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "6e63cff320ae2c57904679ba7cb63280a3dc4613885beafb148ee7bf9aa9042d"

[[package]]
name = "spki"
version = "0.7.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d91ed6c858b01f942cd56b37a94b3e0a1798290327d1236e4d9cf4eaca44d29d"
dependencies = [
 "base64ct",
 "der",
]

[[package]]
name = "stable_deref_trait"
version = "1.2.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "6ce2be8dc25455e1f91df71bfa12ad37d7af1092ae736f3a6cd0e37bc7810596"

[[package]]
name = "static_assertions"
version = "1.1.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a2eb9349b6444b326872e140eb1cf5e7c522154d69e7a0ffb0fb81c06b37543f"

[[package]]
name = "strsim"
version = "0.11.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "7da8b5736845d9f2fcb837ea5d9e2628564b3b043a70948a3f0b778838c5fb4f"

[[package]]
name = "subtle"
version = "2.6.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "13c2bddecc57b384dee18652358fb23172facb8a2c51ccc10d74c157bdea3292"

[[package]]
name = "syn"
version = "2.0.119"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "872831b642d1a07999a962a351ed35b955ea2cfc8f3862091e2a240a84f17297"
dependencies = [
 "proc-macro2",
 "quote",
 "unicode-ident",
]

[[package]]
name = "syn"
version = "3.0.9"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d78c8dee4c7bf0e14673097256fed6142ce9d3b85a408189d07482442145823b"
dependencies = [
 "proc-macro2",
 "quote",
 "unicode-ident",
]

[[package]]
name = "synstructure"
version = "0.13.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "728a70f3dbaf5bab7f0c4b1ac8d7ae5ea60a4b5549c8a5914361c99147a709d2"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 2.0.119",
]

[[package]]
name = "synstructure"
version = "0.14.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "901704edd0dfe137f1987838ee4f259e4e063c31371bdb423f7ae38ec6f77f02"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 3.0.9",
]

[[package]]
name = "system-configuration"
version = "0.7.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a13f3d0daba03132c0aa9767f98351b3488edc2c100cda2d2ec2b04f3d8d3c8b"
dependencies = [
 "bitflags",
 "core-foundation",
 "system-configuration-sys",
]

[[package]]
name = "system-configuration-sys"
version = "0.6.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "8e1d1b10ced5ca923a1fcb8d03e96b8d3268065d724548c0211415ff6ac6bac4"
dependencies = [
 "core-foundation-sys",
 "libc",
]

[[package]]
name = "thiserror"
version = "1.0.69"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b6aaf5339b578ea85b50e080feb250a3e8ae8cfcdff9a461c9ec2904bc923f52"
dependencies = [
 "thiserror-impl 1.0.69",
]

[[package]]
name = "thiserror"
version = "2.0.21"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "09e52cb86a36cede5cb101bf8908837b3e4c6e5e59fe7fd85c23fb56200d189e"
dependencies = [
 "thiserror-impl 2.0.21",
]

[[package]]
name = "thiserror-impl"
version = "1.0.69"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4fee6c4efc90059e10f81e6d42c60a18f76588c3d74cb83a0b242a2b6c7504c1"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 2.0.119",
]

[[package]]
name = "thiserror-impl"
version = "2.0.21"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "fe5197923287db20a58125f0bc85c062f7f2c892de97b18c356f9efb14b28524"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 3.0.9",
]

[[package]]
name = "time"
version = "0.3.55"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "cdb87b95ec50ddfa440816d227a17b2ccbdda963a316a727fda0fc4334f7d134"
dependencies = [
 "deranged",
 "num-conv",
 "powerfmt",
 "serde_core",
 "time-core",
 "time-macros",
]

[[package]]
name = "time-core"
version = "0.1.9"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9e1c906769ad99c88eaa54e728060edef082f8e358ff32030cb7c7d315e81109"

[[package]]
name = "time-macros"
version = "0.2.32"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "7e689342a48d2ea927c87ea50cabf8594854bf940e9310208848d680d668ed85"
dependencies = [
 "num-conv",
 "time-core",
]

[[package]]
name = "tinystr"
version = "0.8.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "abc840c238154d58f9e86b2792261edfde565a17696e1cda1a449de27979801a"
dependencies = [
 "displaydoc",
 "zerovec",
]

[[package]]
name = "tinyvec"
version = "1.13.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "fd3ca314f692efd6c868f8408f53fe444634a845f96c028b97d35f6a1f79f0ee"

[[package]]
name = "tokio"
version = "1.54.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b52fd3255258d26fac7264ab5a76b53c13367136dc011d3d6ad4f8ed070396a3"
dependencies = [
 "bytes",
 "libc",
 "mio",
 "parking_lot",
 "pin-project-lite",
 "signal-hook-registry",
 "socket2 0.6.5",
 "tokio-macros",
 "windows-sys 0.61.2",
]

[[package]]
name = "tokio-macros"
version = "2.7.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "78773a2a397f451582ce068015985c33193cf6dea8b74d2a639fe457b2f07b0e"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 3.0.9",
]

[[package]]
name = "tokio-util"
version = "0.7.20"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e464cf451ba96ebfc6f9b6542f17ee8b8956e33f1e40d9690624e59d7a7f8a4b"
dependencies = [
 "bytes",
 "futures-core",
 "futures-sink",
 "libc",
 "pin-project-lite",
 "tokio",
]

[[package]]
name = "tower-service"
version = "0.3.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "8df9b6e13f2d32c91b9bd719c00d1958837bc7dec474d94952798cc8e69eeec3"

[[package]]
name = "tracing"
version = "0.1.44"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "63e71662fa4b2a2c3a26f570f037eb95bb1f85397f3cd8076caed2f026a6d100"
dependencies = [
 "pin-project-lite",
 "tracing-attributes",
 "tracing-core",
]

[[package]]
name = "tracing-attributes"
version = "0.1.31"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "7490cfa5ec963746568740651ac6781f701c9c5ea257c58e057f3ba8cf69e8da"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 2.0.119",
]

[[package]]
name = "tracing-core"
version = "0.1.36"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "db97caf9d906fbde555dd62fa95ddba9eecfd14cb388e4f491a66d74cd5fb79a"
dependencies = [
 "once_cell",
]

[[package]]
name = "try-lock"
version = "0.2.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e421abadd41a4225275504ea4d6566923418b7f05506fbc9c0fe86ba7396114b"

[[package]]
name = "typenum"
version = "1.20.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b6f5e870be6c3b371b77fe0ee0bafb859fa4964b4404c27de1d380043c4dda20"

[[package]]
name = "unicode-ident"
version = "1.0.27"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a2c754d6c33795a1c324727428e5a7dedb5b06195f9890bdbcba760d3e246563"

[[package]]
name = "universal-hash"
version = "0.5.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "fc1de2c688dc15305988b563c3854064043356019f97a4b46276fe734c4f07ea"
dependencies = [
 "crypto-common",
 "subtle",
]

[[package]]
name = "unsigned-varint"
version = "0.7.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "6889a77d49f1f013504cec6bf97a2c730394adedaeb1deb5ea08949a50541105"

[[package]]
name = "unsigned-varint"
version = "0.8.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "eb066959b24b5196ae73cb057f45598450d2c5f71460e98c49b738086eff9c06"

[[package]]
name = "untrusted"
version = "0.7.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a156c684c91ea7d62626509bce3cb4e1d9ed5c4d978f7b4352658f96a4c26b4a"

[[package]]
name = "untrusted"
version = "0.9.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "8ecb6da28b8a351d773b68d5825ac39017e680750f980f3a1a85cd8dd28a47c1"

[[package]]
name = "url"
version = "2.5.8"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ff67a8a4397373c3ef660812acab3268222035010ab8680ec4215f38ba3d0eed"
dependencies = [
 "form_urlencoded",
 "idna",
 "percent-encoding",
 "serde",
]

[[package]]
name = "utf8_iter"
version = "1.1.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "af3bd9d3e571c26fcce9d033b87ea5ab061b8d2ffe9b7a5675d810d68f03edf0"
dependencies = [
 "utf_types",
]

[[package]]
name = "utf8parse"
version = "0.2.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "06abde3611657adf66d383f00b093d7faecc7fa57071cce2578660c9f1010821"

[[package]]
name = "utf_types"
version = "1.0.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "3a3b425286980a367278453f3b6d28cdcb134b574e5a35824a6ff5eebad50bb6"

[[package]]
name = "version_check"
version = "0.9.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0b928f33d975fc6ad9f86c8f283853ad26bdd5b10b7f1542aa2fa15e2289105a"

[[package]]
name = "void"
version = "1.0.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "6a02e4885ed3bc0f2de90ea6dd45ebcbb66dacffe03547fadbb0eeae2770887d"

[[package]]
name = "want"
version = "0.3.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ec4cdd0dd910afe868b7ef477227d8d538b46b3075031afee8a9f2acb0a2ed0b"
dependencies = [
 "try-lock",
]

[[package]]
name = "wasi"
version = "0.11.1+wasi-snapshot-preview1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ccf3ec651a847eb01de73ccad15eb7d99f80485de043efb2f370cd654f4ea44b"

[[package]]
name = "wasip2"
version = "1.0.4+wasi-0.2.12"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b67efb37e106e55ce722a510d6b5f9c17f083e5fc79afc2badeb12cc313d9487"
dependencies = [
 "wit-bindgen",
]

[[package]]
name = "wasm-bindgen"
version = "0.2.130"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "a0181c14ddd6c7b8b0b0132a5f1ea2f32be0d893cd3ea97b6e3b28886b8a3d1c"
dependencies = [
 "cfg-if",
 "rustversion",
 "wasm-bindgen-macro",
 "wasm-bindgen-shared",
]

[[package]]
name = "wasm-bindgen-macro"
version = "0.2.130"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "6e931a02a39abdbf66966fc35902b5ed58344750a70885bed4ebb3d8eaf28ed9"
dependencies = [
 "quote",
 "wasm-bindgen-macro-support",
]

[[package]]
name = "wasm-bindgen-macro-support"
version = "0.2.130"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "2ca4b54280e455bd831e33a6b8e734baf432fe63fbc35c42ac14ce67a043a53a"
dependencies = [
 "bumpalo",
 "proc-macro2",
 "quote",
 "syn 3.0.9",
 "wasm-bindgen-shared",
]

[[package]]
name = "wasm-bindgen-shared"
version = "0.2.130"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "3b1f9c3798725016c6ee5f2f57869ec0831e8bbc0ab0310a86e787e97f41389e"
dependencies = [
 "unicode-ident",
]

[[package]]
name = "web-sys"
version = "0.3.107"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d7d179596ff5ec0f6de4db64d54011bde6289cc49603d3a6e4ce3f329207ab88"
dependencies = [
 "js-sys",
 "wasm-bindgen",
]

[[package]]
name = "web-time"
version = "1.1.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "5a6580f308b1fad9207618087a65c04e7a10bc77e02c8e84e9b00dd4b12fa0bb"
dependencies = [
 "js-sys",
 "wasm-bindgen",
]

[[package]]
name = "widestring"
version = "1.2.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "72069c3113ab32ab29e5584db3c6ec55d416895e60715417b5b883a357c3e471"

[[package]]
name = "winapi"
version = "0.3.9"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "5c839a674fcd7a98952e593242ea400abe93992746761e38641405d28b00f419"
dependencies = [
 "winapi-i686-pc-windows-gnu",
 "winapi-x86_64-pc-windows-gnu",
]

[[package]]
name = "winapi-i686-pc-windows-gnu"
version = "0.4.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ac3b87c63620426dd9b991e5ce0329eff545bccbbb34f3be09ff6fb6ab51b7b6"

[[package]]
name = "winapi-x86_64-pc-windows-gnu"
version = "0.4.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "712e227841d057c1ee1cd2fb22fa7e5a5461ae8e48fa2ca79ec42cfc1931183f"

[[package]]
name = "windows"
version = "0.62.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "527fadee13e0c05939a6a05d5bd6eec6cd2e3dbd648b9f8e447c6518133d8580"
dependencies = [
 "windows-collections",
 "windows-core",
 "windows-future",
 "windows-numerics",
]

[[package]]
name = "windows-collections"
version = "0.3.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "23b2d95af1a8a14a3c7367e1ed4fc9c20e0a26e79551b1454d72583c97cc6610"
dependencies = [
 "windows-core",
]

[[package]]
name = "windows-core"
version = "0.62.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "b8e83a14d34d0623b51dce9581199302a221863196a1dde71a7663a4c2be9deb"
dependencies = [
 "windows-implement",
 "windows-interface",
 "windows-link",
 "windows-result",
 "windows-strings",
]

[[package]]
name = "windows-future"
version = "0.3.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e1d6f90251fe18a279739e78025bd6ddc52a7e22f921070ccdc67dde84c605cb"
dependencies = [
 "windows-core",
 "windows-link",
 "windows-threading",
]

[[package]]
name = "windows-implement"
version = "0.60.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "053e2e040ab57b9dc951b72c264860db7eb3b0200ba345b4e4c3b14f67855ddf"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 2.0.119",
]

[[package]]
name = "windows-interface"
version = "0.59.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "3f316c4a2570ba26bbec722032c4099d8c8bc095efccdc15688708623367e358"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 2.0.119",
]

[[package]]
name = "windows-link"
version = "0.2.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f0805222e57f7521d6a62e36fa9163bc891acd422f971defe97d64e70d0a4fe5"

[[package]]
name = "windows-numerics"
version = "0.3.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "6e2e40844ac143cdb44aead537bbf727de9b044e107a0f1220392177d15b0f26"
dependencies = [
 "windows-core",
 "windows-link",
]

[[package]]
name = "windows-registry"
version = "0.6.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "02752bf7fbdcce7f2a27a742f798510f3e5ad88dbe84871e5168e2120c3d5720"
dependencies = [
 "windows-link",
 "windows-result",
 "windows-strings",
]

[[package]]
name = "windows-result"
version = "0.4.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "7781fa89eaf60850ac3d2da7af8e5242a5ea78d1a11c49bf2910bb5a73853eb5"
dependencies = [
 "windows-link",
]

[[package]]
name = "windows-strings"
version = "0.5.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "7837d08f69c77cf6b07689544538e017c1bfcf57e34b4c0ff58e6c2cd3b37091"
dependencies = [
 "windows-link",
]

[[package]]
name = "windows-sys"
version = "0.52.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "282be5f36a8ce781fad8c8ae18fa3f9beff57ec1b52cb3de0789201425d9a33d"
dependencies = [
 "windows-targets",
]

[[package]]
name = "windows-sys"
version = "0.61.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ae137229bcbd6cdf0f7b80a31df61766145077ddf49416a728b02cb3921ff3fc"
dependencies = [
 "windows-link",
]

[[package]]
name = "windows-targets"
version = "0.52.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9b724f72796e036ab90c1021d4780d4d3d648aca59e491e6b98e725b84e99973"
dependencies = [
 "windows_aarch64_gnullvm",
 "windows_aarch64_msvc",
 "windows_i686_gnu",
 "windows_i686_gnullvm",
 "windows_i686_msvc",
 "windows_x86_64_gnu",
 "windows_x86_64_gnullvm",
 "windows_x86_64_msvc",
]

[[package]]
name = "windows-threading"
version = "0.2.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "3949bd5b99cafdf1c7ca86b43ca564028dfe27d66958f2470940f73d86d75b37"
dependencies = [
 "windows-link",
]

[[package]]
name = "windows_aarch64_gnullvm"
version = "0.52.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "32a4622180e7a0ec044bb555404c800bc9fd9ec262ec147edd5989ccd0c02cd3"

[[package]]
name = "windows_aarch64_msvc"
version = "0.52.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "09ec2a7bb152e2252b53fa7803150007879548bc709c039df7627cabbd05d469"

[[package]]
name = "windows_i686_gnu"
version = "0.52.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "8e9b5ad5ab802e97eb8e295ac6720e509ee4c243f69d781394014ebfe8bbfa0b"

[[package]]
name = "windows_i686_gnullvm"
version = "0.52.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0eee52d38c090b3caa76c563b86c3a4bd71ef1a819287c19d586d7334ae8ed66"

[[package]]
name = "windows_i686_msvc"
version = "0.52.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "240948bc05c5e7c6dabba28bf89d89ffce3e303022809e73deaefe4f6ec56c66"

[[package]]
name = "windows_x86_64_gnu"
version = "0.52.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "147a5c80aabfbf0c7d901cb5895d1de30ef2907eb21fbbab29ca94c5b08b1a78"

[[package]]
name = "windows_x86_64_gnullvm"
version = "0.52.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "24d5b23dc417412679681396f2b49f3de8c1473deb516bd34410872eff51ed0d"

[[package]]
name = "windows_x86_64_msvc"
version = "0.52.6"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "589f6da84c646204747d1270a2a5661ea66ed1cced2631d546fdfb155959f9ec"

[[package]]
name = "wit-bindgen"
version = "0.57.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1ebf944e87a7c253233ad6766e082e3cd714b5d03812acc24c318f549614536e"

[[package]]
name = "writeable"
version = "0.6.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "3ad82d2a33cdc9674dc7465672f271e096168fcdbe0f799d9e6db8c5892679dc"

[[package]]
name = "x25519-dalek"
version = "2.0.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c7e468321c81fb07fa7f4c636c3972b9100f0346e5b6a9f2bd0603a52f7ed277"
dependencies = [
 "curve25519-dalek",
 "rand_core 0.6.4",
 "serde",
 "zeroize",
]

[[package]]
name = "x509-parser"
version = "0.16.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "fcbc162f30700d6f3f82a24bf7cc62ffe7caea42c0b2cba8bf7f3ae50cf51f69"
dependencies = [
 "asn1-rs",
 "data-encoding",
 "der-parser",
 "lazy_static",
 "nom",
 "oid-registry",
 "rusticata-macros",
 "thiserror 1.0.69",
 "time",
]

[[package]]
name = "xml-rs"
version = "0.8.29"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e450f9b2ed1dff33c94c12589a87338689467b9c4f5d8a5710bd09a847d2c8a7"

[[package]]
name = "xmltree"
version = "0.10.3"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "d7d8a75eaf6557bb84a65ace8609883db44a29951042ada9b393151532e41fcb"
dependencies = [
 "xml-rs",
]

[[package]]
name = "yamux"
version = "0.12.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "9ed0164ae619f2dc144909a9f082187ebb5893693d8c0196e8085283ccd4b776"
dependencies = [
 "futures",
 "log",
 "nohash-hasher",
 "parking_lot",
 "pin-project",
 "rand 0.8.8",
 "static_assertions",
]

[[package]]
name = "yamux"
version = "0.13.10"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "1991f6690292030e31b0144d73f5e8368936c58e45e7068254f7138b23b00672"
dependencies = [
 "futures",
 "log",
 "nohash-hasher",
 "parking_lot",
 "pin-project",
 "rand 0.9.5",
 "static_assertions",
 "web-time",
]

[[package]]
name = "yasna"
version = "0.5.2"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e17bb3549cc1321ae1296b9cdc2698e2b6cb1992adfa19a8c72e5b7a738f44cd"
dependencies = [
 "time",
]

[[package]]
name = "yoke"
version = "0.8.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "417ef3fcf6c300b7dbd25c85531a746931c02ad536f3cf4786ed1e88223340b3"
dependencies = [
 "stable_deref_trait",
 "yoke-derive",
 "zerofrom",
]

[[package]]
name = "yoke-derive"
version = "0.8.4"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "ec8ebde2db3681e8c9980cc27822030e68752690ddfa9473e739aeb4dbde6d71"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 3.0.9",
 "synstructure 0.14.0",
]

[[package]]
name = "zerocopy"
version = "0.8.63"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e5fe1f8f1b06191a00962174c61aa5005e0bb391a6d80d07e24d115c01a92ed8"
dependencies = [
 "zerocopy-derive",
]

[[package]]
name = "zerocopy-derive"
version = "0.8.63"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "863ad3ac83293fb4d740aedbfdc9240dd8d1a50c1099acd76ce80ce7c7230c7f"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 2.0.119",
]

[[package]]
name = "zerofrom"
version = "0.1.8"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0ec05a11813ea801ff6d75110ad09cd0824ddba17dfe17128ea0d5f68e6c5272"
dependencies = [
 "zerofrom-derive",
]

[[package]]
name = "zerofrom-derive"
version = "0.1.8"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f75b4683f6c7f45248d4d64056a24298c6281e0993356d7d1b4a1a962ef10d4a"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 3.0.9",
 "synstructure 0.14.0",
]

[[package]]
name = "zeroize"
version = "1.9.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "e13084392c5e4bc371903e2935a5eaeed24905a7511356b883835e18a78f6879"
dependencies = [
 "zeroize_derive",
]

[[package]]
name = "zeroize_derive"
version = "1.5.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "3c50655cbb0fe3fc43170059e702f1ce5e19b84cec58dc87b037a09935c2f328"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 2.0.119",
]

[[package]]
name = "zerotrie"
version = "0.2.5"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "4ea269c3bd32f0a32c321907a2ae912ba6f4649bb0fc764a15627e99a7095a3f"
dependencies = [
 "displaydoc",
 "yoke",
 "zerofrom",
]

[[package]]
name = "zerovec"
version = "0.11.9"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "f58a2799cfe9a1670c7ea8edbd52ef8edb93cb37a7f83bf31ba9e35d9dae6a40"
dependencies = [
 "yoke",
 "zerofrom",
 "zerovec-derive",
]

[[package]]
name = "zerovec-derive"
version = "0.11.7"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "c3743ddbf47738d929cd1ae2e199d40d0162979dfe31aef8ae646d2bf00bf97a"
dependencies = [
 "proc-macro2",
 "quote",
 "syn 3.0.9",
]

[[package]]
name = "zmij"
version = "1.0.23"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "29666d0abbfad1e3dc4dcf6144730dd3a3ab225bbbdac83319345b1b44ccfc1b"
AETHER_EOF_2
generer ".gitignore" <<'AETHER_EOF_3'
target/
Cargo.lock
AETHER_EOF_3
generer "README.md" <<'AETHER_EOF_4'
# Aether — réseau de calcul distribué P2P (Rust)

Aether est un réseau pair-à-pair de **calcul distribué chiffré** : des tâches
sont découpées par un routeur, distribuées à des nœuds calculants hétérogènes
via des tunnels chiffrés, puis les résultats sont agrégés et renvoyés au
client. À terme : preuves à divulgation nulle et ancrage blockchain.

**État actuel : MVP Phase 1 — vérifié.** Tunnel chiffré libp2p (Noise +
Yamux), protocole requête/réponse, distribution multi-nœuds, reprise sur
échec, contre-vérification d'exactitude automatisée.

```text
   client (submit)                routeur (bootstrap)              workers
        │  soumission                 │                             │
        ├────────────────────────────▶│  découpe en morceaux        │
        │                             ├──Hello/battements──────────▶│
        │                             ├──morceau (chiffré)─────────▶│
        │                             │◀──résultat du morceau───────┤
        │                             │   … un morceau par worker … │
        │◀──résultat agrégé───────────┤                             │
        │  (JSON : count, workers,    │                             │
        │   temps CPU, temps mur)     │                             │
```

## Démarrage rapide (3 terminaux)

```bash
cargo build                                # ~5-15 min la première fois

# Terminal 1 — le routeur
./target/debug/aether-node bootstrap --port 4001

# Terminal 2 et 3 — deux nœuds calculants
./target/debug/aether-node worker --bootstrap /ip4/127.0.0.1/tcp/4001
./target/debug/aether-node worker --bootstrap /ip4/127.0.0.1/tcp/4001

# N'importe où — soumettre une tâche (premiers dans [2, 200000])
./target/debug/aether-node submit --to 200000 --chunks 8
```

Sortie du client (JSON, consommable par `jq`) :

```json
{
  "primes_found": 17984,
  "workers": ["12D3KooW…d9PR", "12D3KooW…5Fyi"],
  "cpu_ms": 29.5,
  "mur_ms": 89.5
}
```

## Structure du dépôt

| Crate            | Rôle                                                       |
| ---------------- | ---------------------------------------------------------- |
| `aether-core`    | Contrat partagé : tâches, morceaux, résultats, protocole   |
| `aether-net`     | Tunnels chiffrés libp2p : TCP → Noise → Yamux → req/resp   |
| `aether-compute` | Routeur cognitif MVP : découpage, exécution, agrégation    |
| `aether-zk`      | Preuves ZK — contrat figé, implémentation en Phase 3       |
| `aether-node`    | Le binaire : `bootstrap` / `worker` / `submit`             |

## Tests

```bash
cargo test --workspace        # 17 tests unitaires
bash selftest.sh              # suite complète : unitaires + réseau 3 nœuds
```

Le test d'intégration (`selftest.sh`) lance un vrai réseau local (routeur +
2 workers + client), vérifie le chiffrement des tunnels dans les journaux et
contre-vérifie le résultat avec un crible Python indépendant.

## Documentation

- [`ARCHITECTURE.md`](ARCHITECTURE.md) — chaîne complète, protocole, modèle de menace
- [`ROADMAP.md`](ROADMAP.md) — de la Phase 1 (actuelle) à la Phase 5 (GPU, blockchain)

## Avertissement honnête

C'est un MVP de recherche : la validation des résultats repose uniquement
sur l'exactitude déterministe de l'exécuteur (et la contre-vérification du
selftest) — **pas** encore sur des preuves cryptographiques. La
décentralisation réelle (DHT, traversée NAT) arrive en Phase 2. Voir
[`ROADMAP.md`](ROADMAP.md).
AETHER_EOF_4
generer "ARCHITECTURE.md" <<'AETHER_EOF_5'
# Architecture Aether

## La chaîne visée (et où on en est)

La vision d'Aether :

```text
UI ──▶ routeur cognitif ──▶ P2P mesh chiffré ──▶ nœuds hétérogènes
                                       │              (PC gamer GPU,
                                       │               serveur CPU,
                                       │               Mac M3 edge)
                                       ▼
UI ◀── réponse ◀── blockchain ◀── preuve ZK ◀── agrégateur
```

État des maillons :

| Maillon                    | État Phase 1                          |
| -------------------------- | ------------------------------------- |
| UI / client                | ✅ CLI `submit` (JSON en sortie)      |
| Routeur cognitif           | ✅ MVP : découpage équilibré          |
| P2P mesh chiffré           | ✅ libp2p : TCP + Noise + Yamux       |
| Nœuds hétérogènes          | ✅ CPU (exécuteur `primes`)           |
| Agrégateur                 | ✅ fusion ordonnée + métriques        |
| Preuve ZK                  | ⏳ contrat figé (`aether-zk`)         |
| Blockchain                 | ⏳ Phase 4                            |

## Pile réseau (implémentée)

Chaque connexion entre nœuds Aether :

```text
┌───────────────────────────────────────────────────┐
│ protocole applicatif Aether (requête/réponse JSON)│
├───────────────────────────────────────────────────┤
│ Yamux — multiplexage des sous-flux                │
├───────────────────────────────────────────────────┤
│ Noise — chiffrement authentifié (clés Ed25519)    │
├───────────────────────────────────────────────────┤
│ TCP                                               │
└───────────────────────────────────────────────────┘
```

- **Identité** : chaque nœud génère une paire Ed25519 ; son `PeerId` est
  dérivé de la clé publique. Pas d'identité = pas de connexion.
- **Chiffrement** : négociation Noise *avant tout* échange applicatif —
  rien ne circule en clair, y compris les métadonnées de tâches.
- **Multiplexage** : Yamux permet plusieurs requêtes concurrentes sur une
  seule connexion chiffrée (une seule négociation coûteuse).
- **Codage** : JSON préfixé par sa longueur (max 1 Mo requête / 10 Mo
  réponse, bornes du codec libp2p).

## Protocole applicatif

Défini dans `aether-core/src/types.rs` :

```rust
enum AetherRequest  { Hello { capabilities }, SubmitTask(ComputeTask), ComputeChunk(ChunkSpec) }
enum AetherResponse { Welcome { node }, ChunkDone(ChunkResult), TaskDone(TaskResult), Error { message } }
```

Flux nominal d'une tâche :

```text
worker                     bootstrap                       client
  │── Hello(capabilités)──────▶│                              │
  │◀── Welcome─────────────────│                              │
  │                            │◀── SubmitTask(tâche)─────────│
  │◀── ComputeChunk(morceau i)─│   (round-robin sur workers)  │
  │── ChunkDone(résultat i)───▶│                              │
  │       … tous les morceaux …│                              │
  │                            │── TaskDone(résultat agrégé)─▶│
```

Les messages sont sérialisés en JSON avec **ignorance des champs
inconnus** : le protocole peut évoluer sans casser les nœuds déployés.

## Routeur cognitif (MVP)

`aether-compute` :

- **plan_chunks** — découpe la plage en morceaux contigus équilibrés
  (garantie : ni trou ni chevauchement, testée par propriété) ;
- **execute_chunk** — exécution locale déterministe (crible) ;
- **aggregate** — fusion ordonnée par index, temps CPU cumulé, liste des
  participants.

La distribution est aujourd'hui un **round-robin naïf** sur les workers
enregistrés. La Phase 2 introduira un choix conscient des capacités
annoncées (`NodeCapabilities.hardware`, `.executor`).

## Tolérance aux pannes

- **Battement de cœur** : chaque worker renvoie `Hello` toutes les 60 s ;
  un worker silencieux pendant 150 s est retiré du pool.
- **Reconnexion** : un worker qui perd le routeur re-dial au battement
  suivant.
- **Reprise sur échec** : un morceau en échec (erreur applicative ou échec
  d'envoi) est redistribué à un autre worker, jusqu'à 2 redistributions ;
  au-delà la tâche est abandonnée et le client reçoit une `Error`
  explicite.
- **File d'attente** : une requête vers un pair pas encore connecté est
  mise en attente et envoyée dès l'établissement du tunnel (libp2p).

## Modèle de menace — ce qui est protégé, ce qui ne l'est pas

Protégé aujourd'hui :

- ✅ **Confidentialité et intégrité du transport** — Noise authentifie les
  deux extrémités et chiffre tout le trafic ;
- ✅ **Authenticité des pairs** — PeerId dérivé de la clé publique ;
- ✅ **Disponibilité partielle** — battements, TTL, redistributions.

PAS encore protégé (assumé, planifié) :

- ❌ **Exactitude des résultats malveillants** — un worker compromis peut
  mentir sur son morceau. Phase 2 : double calcul sur nœuds distincts et
  vote ; Phase 3 : preuve ZK d'exécution ;
- ❌ **Sybil / éclipsage** — pas encore de DHT ni de réputation ;
- ❌ **Confidentialité de la tâche elle-même** — le routeur voit tout en
  clair (chiffrement de bout en bout application : Phase 5).

## Choix techniques (et pourquoi)

- **Rust** : sûreté mémoire + performance proche du C++ (des milliers de
  connexions sans GC ni fuite), `tokio` pour la concurrence.
- **libp2p** : pile P2P modulaire éprouvée (IPFS) — Noise, Yamux, et plus
  tard Kademlia/gossipsub/quic sans réécrire le réseau.
- **JSON** : débogable à la main sur le tunnel ; passage bincode/protobuf
  possible sans changer le contrat (serde).
- **libp2p = 0.53.2 épinglé exactement** : la crate évolue vite, la
  recompilation d'un autre poste doit être bit-identique.
AETHER_EOF_5
generer "ROADMAP.md" <<'AETHER_EOF_6'
# Feuille de route Aether

Chaque phase a un **critère de sortie mesurable** — pas de « améliorations
diverses ».

## Phase 1 — MVP réseau (✅ livrée, vérifiée)

- Workspace 5 crates, tunnel chiffré Noise+Yamux, protocole req/rep JSON ;
- `bootstrap` / `worker` / `submit`, battements, TTL, reprise sur échec ;
- Selftest réseau automatisé avec contre-vérification Python.

**Critère de sortie** : un réseau local de 2+ workers calcule une tâche
découpée et le résultat agrégé est exact. ✅ (17984/17984 premiers,
charge 4+4 morceaux, tunnels chiffrés attestés dans les journaux.)

## Phase 2 — Résilience et hétérogénéité

- **Validation par redondance** : chaque morceau exécuté sur 2 nœuds
  distincts, désaccord ⇒ élection ; coût : ×2 calcul, gain : détection des
  nœuds menteurs ;
- **Découverte décentralisée** : Kademlia DHT + annonces gossipsub des
  capacités (le routeur n'est plus un point de rendez-vous unique) ;
- **Traversée NAT** : relais libp2p + hole punching (dcutr), transport QUIC ;
- **Planification consciente** : choix du worker par capacités annoncées et
  charge observée ;
- Nouvel exécuteur : recherche de collisions par lots (SHA-256) — charge
  réellement inégale entre nœuds.

**Critère de sortie** : 3 machines physiques différentes sur 2 réseaux
différents, sans routeur central sur LAN, tâche complète validée.

## Phase 3 — Preuves à divulgation nulle

- Sélection du moteur (candidats : **RISC Zero** zkVM — preuve d'un
  binaire Rust ; **SP1** — intégration Ethereum directe ; **arkworks** —
  circuits Groth16 sur mesure) ;
- Énoncé prouvé : « le résultat agrégé B découle des morceaux signés
  {m_i} par les PeerId {p_i} pour la tâche T » ;
- `aether-zk` : implémentation réelle du trait `Prover` + banc de vérification.

**Critère de sortie** : une preuve vérifiable en < 5 s hors ligne, taille
< 100 ko, générée sur du matériel grand public.

## Phase 4 — Ancrage blockchain et économie

- Contrat de vérification on-chain (L2 à frais réduits) : dépôt de
  preuve + énoncé haché ;
- Paiement des nœuds calculants, dépôt de garantie (staking), slashing sur
  preuve de mensonge ;
- Marché de la capacité : enchères de morceaux par lots.

**Critère de sortie** : un cycle complet tâche → preuve → paiement
exécuté sur un testnet, sans intervention manuelle.

## Phase 5 — Calcul hétérogène réel

- Exécuteur GPU via `wgpu` (CUDA/Vulkan/Metal) — cible explicite :
  PC gamer (GPU), serveur (CPU), Mac M3 (Metal via wgpu) ;
- Chiffrement applicatif de bout en bout des tâches sensibles (le routeur
  devient aveugle) ;
- Interface utilisateur (hors navigateur — ligne de conduite du projet).

**Critère de sortie** : une tâche GPU exécutée sur 2 GPU hétérogènes avec
le même résultat bit-à-bit et preuve ZK associée.
AETHER_EOF_6
generer "selftest.sh" <<'AETHER_EOF_7'
#!/usr/bin/env bash
# Selftest Aether — suite complète de vérification du réseau.
#   1. tests unitaires (cargo test)
#   2. build du binaire
#   3. réseau local réel : routeur + 2 nœuds calculants + client
#   4. contre-vérification Python indépendante du résultat
# Usage : bash selftest.sh   (depuis la racine du dépôt)
set -uo pipefail
cd "$(dirname "$0")"

VERT=$'\033[32m'; ROUGE=$'\033[31m'; JAUNE=$'\033[33m'; BLEU=$'\033[34m'; NEUTRE=$'\033[0m'
PASS=0; FAIL=0
ok() { printf '%s✓ %s — %s%s\n' "$VERT" "$1" "$2" "$NEUTRE"; PASS=$((PASS + 1)); }
ko() { printf '%s✗ %s — %s%s\n' "$ROUGE" "$1" "$2" "$NEUTRE"; FAIL=$((FAIL + 1)); }

CARGO=${CARGO:-cargo}
NODE=target/debug/aether-node
PORT=$((41000 + $$ % 1000))
DIR=$(mktemp -d)
trap 'pkill -f "target/debug/aether-node (bootstrap|worker)" 2>/dev/null; rm -rf "$DIR"' EXIT

attendre() { # attendre <fichier> <motif> <essais>
    local fichier=$1 motif=$2 essais=${3:-100} i
    for i in $(seq 1 "$essais"); do
        grep -q "$motif" "$fichier" 2>/dev/null && return 0
        sleep 0.3
    done
    return 1
}

printf '%s═══ Selftest Aether (port de test : %s) ═══%s\n' "$BLEU" "$PORT" "$NEUTRE"

# T1 — tests unitaires
printf '%s[T1] tests unitaires…%s\n' "$BLEU" "$NEUTRE"
if $CARGO test --workspace --quiet >"$DIR/tests.log" 2>&1 && grep -q "test result: ok" "$DIR/tests.log"; then
    NB=$(grep -o 'test result: ok\. [0-9]* passed' "$DIR/tests.log" | awk '{s += $4} END {print s + 0}')
    ok "T1" "tests unitaires : $NB passés, 0 échec"
else
    ko "T1" "tests unitaires en échec"
    tail -20 "$DIR/tests.log"
fi

# T2 — build
printf '%s[T2] build du binaire…%s\n' "$BLEU" "$NEUTRE"
if $CARGO build --quiet >"$DIR/build.log" 2>&1; then
    ok "T2" "build debug : $NODE"
else
    ko "T2" "build en échec"
    tail -20 "$DIR/build.log"
fi

# T3 — réseau local complet
if [ -x "$NODE" ]; then
    printf '%s[T3] réseau local réel : routeur + 2 workers + client…%s\n' "$BLEU" "$NEUTRE"
    "$NODE" bootstrap --port "$PORT" >"$DIR/bootstrap.out" 2>"$DIR/bootstrap.log" &
    if attendre "$DIR/bootstrap.log" "écoute :"; then
        ok "T3a" "routeur en écoute"
    else
        ko "T3a" "routeur sans écoute"; cat "$DIR/bootstrap.log"
    fi
    "$NODE" worker --bootstrap "/ip4/127.0.0.1/tcp/$PORT" >"$DIR/w1.out" 2>"$DIR/w1.log" &
    "$NODE" worker --bootstrap "/ip4/127.0.0.1/tcp/$PORT" >"$DIR/w2.out" 2>"$DIR/w2.log" &
    if attendre "$DIR/bootstrap.log" "enregistré" && [ "$(grep -c enregistré "$DIR/bootstrap.log")" -ge 2 ]; then
        ok "T3b" "2 nœuds calculants enregistrés (battements OK)"
    else
        ko "T3b" "workers non enregistrés"; tail -5 "$DIR/bootstrap.log"
    fi
    "$NODE" submit --bootstrap "/ip4/127.0.0.1/tcp/$PORT" --from 2 --to 200000 --chunks 8 --timeout 60 \
        >"$DIR/result.json" 2>"$DIR/client.log"
    if [ -s "$DIR/result.json" ]; then
        ok "T3c" "tâche distribuée calculée et agrégée"
        cat "$DIR/result.json"
    else
        ko "T3c" "le client n'a pas obtenu de résultat"; cat "$DIR/client.log"
    fi
    if grep -q "tunnel chiffré établi" "$DIR/bootstrap.log"; then
        ok "T3d" "tunnels chiffrés (Noise) attestés dans les journaux"
    else
        ko "T3d" "aucun tunnel chiffré constaté"
    fi
    N1=$(grep -c "calcul…" "$DIR/w1.log" || true)
    N2=$(grep -c "calcul…" "$DIR/w2.log" || true)
    if [ "$N1" -gt 0 ] && [ "$N2" -gt 0 ]; then
        ok "T3e" "répartition de charge : worker1=$N1 morceau(x), worker2=$N2 morceau(x)"
    else
        ko "T3e" "répartition de charge anormale : worker1=$N1, worker2=$N2"
    fi
    # T4 — contre-vérification indépendante
    if [ -s "$DIR/result.json" ]; then
        printf '%s[T4] contre-vérification Python indépendante…%s\n' "$BLEU" "$NEUTRE"
        ATTENDU=$(python3 -c "
n=200000
s=bytearray([1])*(n+1); s[0]=s[1]=0
for i in range(2,int(n**0.5)+1):
    if s[i]: s[i*i::i]=bytearray(len(s[i*i::i]))
print(sum(s[2:]))")
        RECU=$(python3 -c "import json;print(json.load(open('$DIR/result.json'))['primes_found'])" 2>/dev/null || echo "?")
        if [ "$ATTENDU" = "$RECU" ]; then
            ok "T4" "exactitude : $RECU premiers (identique au crible Python)"
        else
            ko "T4" "écart : attendu $ATTENDU, reçu $RECU"
        fi
    fi
else
    ko "T3" "binaire absent — build d'abord (cargo build)"
fi

printf '%s═══ Bilan : %d verts, %d rouges ═══%s\n' "$BLEU" "$PASS" "$FAIL" "$NEUTRE"
[ "$FAIL" -eq 0 ]
AETHER_EOF_7
generer "crates/aether-core/Cargo.toml" <<'AETHER_EOF_8'
[package]
name = "aether-core"
version.workspace = true
edition.workspace = true
rust-version.workspace = true
license.workspace = true
description = "Types partagés du réseau Aether : tâches, résultats, protocole"

[dependencies]
serde = { workspace = true }

[dev-dependencies]
serde_json = { workspace = true }
AETHER_EOF_8
generer "crates/aether-core/src/lib.rs" <<'AETHER_EOF_9'
//! Aether — types partagés entre tous les crates du réseau.
//!
//! Ce crate est volontairement sans dépendance réseau : il définit le
//! « contrat » (tâches, morceaux, résultats, messages du protocole) utilisé
//! par `aether-net`, `aether-compute` et `aether-node`.
//!
//! Sérialiser ces types en JSON les rend extensibles sans casser le réseau :
//! les champs inconnus sont ignorés à la désérialisation.

pub mod math;
pub mod split;
pub mod types;

pub use types::{
    AetherRequest, AetherResponse, ChunkResult, ChunkSpec, ComputeTask, NodeCapabilities,
    TaskKind, TaskResult,
};
AETHER_EOF_9
generer "crates/aether-core/src/types.rs" <<'AETHER_EOF_10'
//! Contrat de données du réseau Aether.

use serde::{Deserialize, Serialize};

/// Genre de tâche que le réseau sait calculer.
///
/// MVP (Phase 1) : recherche de nombres premiers par crible.
/// Les phases futures ajouteront des variantes (GPU, edge, IA).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum TaskKind {
    /// Trouver tous les nombres premiers dans `[from, to]` (bornes incluses).
    Primes { from: u64, to: u64 },
}

/// Une tâche soumise par un client, découpée en `chunks` morceaux.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ComputeTask {
    /// Identifiant unique de la tâche (généré par le client).
    pub id: String,
    /// Ce qu'il faut calculer.
    pub kind: TaskKind,
    /// Nombre de morceaux demandé (découpe équilibrée).
    pub chunks: u32,
}

/// Un morceau de travail, envoyé par le routeur à un nœud calculant.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ChunkSpec {
    /// Tâche d'origine.
    pub task_id: String,
    /// Position du morceau dans la tâche (0..n), sert à la fusion finale.
    pub index: u32,
    /// Borne inférieure (inclusive).
    pub from: u64,
    /// Borne supérieure (inclusive).
    pub to: u64,
}

/// Le résultat d'un morceau, renvoyé par le nœud qui l'a calculé.
/// (`Eq` est omis volontairement : `elapsed_ms` est un `f64`.)
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ChunkResult {
    /// Tâche d'origine.
    pub task_id: String,
    /// Position du morceau dans la tâche.
    pub index: u32,
    /// Les nombres premiers trouvés dans le morceau, en ordre croissant.
    pub primes: Vec<u64>,
    /// `PeerId` (sérialisé) du nœud qui a calculé ce morceau.
    pub worker: String,
    /// Temps d'exécution local du morceau, en millisecondes.
    pub elapsed_ms: f64,
}

/// Résultat final agrégé, renvoyé au client par le routeur.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TaskResult {
    /// Identifiant de la tâche.
    pub task_id: String,
    /// Tous les premiers trouvés, en ordre croissant (fusion des morceaux).
    pub primes: Vec<u64>,
    /// Les nœuds qui ont participé (uniques, dans l'ordre de participation).
    pub workers: Vec<String>,
    /// Somme des temps d'exécution des morceaux (ms) — temps CPU cumulé.
    pub cpu_ms: f64,
    /// Temps mur total vu par le routeur, de la soumission au résultat (ms).
    pub wall_ms: f64,
}

/// Capacités annoncées par un nœud lors de son « Hello ».
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NodeCapabilities {
    /// Rôle annoncé (ex. `worker`).
    pub role: String,
    /// Étiquette matérielle (ex. `linux-x86_64-cpu`).
    pub hardware: String,
    /// Exécuteurs disponibles (ex. `["primes"]`).
    pub executor: Vec<String>,
}

/// Requêtes du protocole Aether (ce qu'un nœud peut demander à un autre).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum AetherRequest {
    /// Enregistrement / battement de cœur d'un nœud calculant.
    Hello { capabilities: NodeCapabilities },
    /// Soumission d'une tâche par un client au routeur.
    SubmitTask(ComputeTask),
    /// Morceau de travail à exécuter (routeur → nœud calculant).
    ComputeChunk(ChunkSpec),
}

/// Réponses du protocole Aether.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum AetherResponse {
    /// Accusé de réception d'un `Hello`.
    Welcome { node: String },
    /// Un morceau a été calculé (nœud calculant → routeur).
    ChunkDone(ChunkResult),
    /// Résultat final agrégé (routeur → client).
    TaskDone(TaskResult),
    /// Erreur applicative (borne invalide, aucun nœud disponible, abandon…).
    Error { message: String },
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Le contrat doit rester sérialisable en JSON dans les deux sens :
    /// c'est ce qui transite réellement sur le tunnel chiffré.
    #[test]
    fn protocole_fait_un_tour_en_json() {
        let req = AetherRequest::SubmitTask(ComputeTask {
            id: "t1".into(),
            kind: TaskKind::Primes { from: 2, to: 100 },
            chunks: 4,
        });
        let json = serde_json::to_string(&req).unwrap();
        let back: AetherRequest = serde_json::from_str(&json).unwrap();
        assert_eq!(req, back);

        let resp = AetherResponse::TaskDone(TaskResult {
            task_id: "t1".into(),
            primes: vec![2, 3, 5],
            workers: vec!["peer-a".into()],
            cpu_ms: 12.5,
            wall_ms: 40.0,
        });
        let json = serde_json::to_string(&resp).unwrap();
        let back: AetherResponse = serde_json::from_str(&json).unwrap();
        assert_eq!(resp, back);
    }

    /// Les champs inconnus sont ignorés : le protocole peut évoluer sans
    /// casser les nœuds déjà déployés.
    #[test]
    fn champs_inconnus_ignores() {
        let json = r#"{"Hello":{"capabilities":{"role":"worker","hardware":"linux-x86_64-cpu","executor":["primes"],"futur":true}}}"#;
        let req: AetherRequest = serde_json::from_str(json).unwrap();
        match req {
            AetherRequest::Hello { capabilities } => {
                assert_eq!(capabilities.executor, vec!["primes".to_string()]);
            }
            _ => panic!("variant inattendu"),
        }
    }
}
AETHER_EOF_10
generer "crates/aether-core/src/math.rs" <<'AETHER_EOF_11'
//! Exécuteur MVP du réseau Aether : crible d'Ératosthène.

/// Borne haute maximale acceptée par l'exécuteur MVP (limite mémoire :
/// le crible alloue ~1 octet par entier).
pub const MAX_BOUND: u64 = 20_000_000;

/// Erreur d'exécution d'un morceau.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ExecError {
    /// La borne dépasse [`MAX_BOUND`].
    BoundTooLarge { bound: u64, max: u64 },
    /// Plage invalide (`from > to`).
    InvalidRange { from: u64, to: u64 },
}

impl std::fmt::Display for ExecError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ExecError::BoundTooLarge { bound, max } => {
                write!(f, "borne {bound} trop élevée (max {max})")
            }
            ExecError::InvalidRange { from, to } => {
                write!(f, "plage invalide : {from} > {to}")
            }
        }
    }
}

impl std::error::Error for ExecError {}

/// Tous les nombres premiers dans `[from, to]`, bornes incluses.
///
/// Crible d'Ératosthène complet jusqu'à `to`, puis filtre des bornes.
/// Déterministe : deux nœuds différents obtiennent le même résultat pour
/// le même morceau — c'est ce qui permettra la vérification par
/// redondance dans les phases suivantes.
pub fn primes_in_range(from: u64, to: u64) -> Result<Vec<u64>, ExecError> {
    if to > MAX_BOUND {
        return Err(ExecError::BoundTooLarge {
            bound: to,
            max: MAX_BOUND,
        });
    }
    if from > to {
        return Err(ExecError::InvalidRange { from, to });
    }
    if to < 2 {
        return Ok(Vec::new());
    }
    let start = from.max(2);
    let mut is_prime = vec![true; (to + 1) as usize];
    is_prime[0] = false;
    is_prime[1] = false;
    let mut i = 2u64;
    while i * i <= to {
        if is_prime[i as usize] {
            let mut m = i * i;
            while m <= to {
                is_prime[m as usize] = false;
                m += i;
            }
        }
        i += 1;
    }
    Ok((start..=to).filter(|&n| is_prime[n as usize]).collect())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn premiers_de_2_a_30() {
        let attendu: Vec<u64> = vec![2, 3, 5, 7, 11, 13, 17, 19, 23, 29];
        assert_eq!(primes_in_range(2, 30).unwrap(), attendu);
    }

    #[test]
    fn bornes_partielles() {
        // [24, 29] ne contient que 29.
        assert_eq!(primes_in_range(24, 29).unwrap(), vec![29]);
        // [90, 96] est vide.
        assert!(primes_in_range(90, 96).unwrap().is_empty());
        // [0, 1] est vide.
        assert!(primes_in_range(0, 1).unwrap().is_empty());
        // from = 0 est ramené à 2.
        assert_eq!(primes_in_range(0, 10).unwrap(), vec![2, 3, 5, 7]);
    }

    #[test]
    fn plage_invalide_rejetee() {
        assert_eq!(
            primes_in_range(50, 10),
            Err(ExecError::InvalidRange { from: 50, to: 10 })
        );
    }

    #[test]
    fn borne_trop_grande_rejetee() {
        assert_eq!(
            primes_in_range(2, MAX_BOUND + 1),
            Err(ExecError::BoundTooLarge {
                bound: MAX_BOUND + 1,
                max: MAX_BOUND
            })
        );
    }

    #[test]
    fn deterministe_sur_repartition() {
        // Découper puis fusionner donne le même résultat que d'un coup :
        // propriété indispensable à l'agrégation par le routeur.
        let direct = primes_in_range(2, 1000).unwrap();
        let mut fusion: Vec<u64> = Vec::new();
        for (a, b) in crate::split::split_range(2, 1000, 7) {
            fusion.extend(primes_in_range(a, b).unwrap());
        }
        assert_eq!(direct, fusion);
    }
}
AETHER_EOF_11
generer "crates/aether-core/src/split.rs" <<'AETHER_EOF_12'
//! Découpage équilibré d'une plage en morceaux — le « routeur cognitif » MVP.

/// Découpe `[from, to]` (bornes incluses) en **au plus** `chunks` plages
/// contiguës et quasi égales. Les morceaux vides ne sont pas émis (si la
/// plage est plus petite que le nombre de morceaux demandé, on renvoie
/// simplement moins de morceaux).
///
/// Propriétés garanties (testées) :
/// - pas de trou, pas de chevauchement ;
/// - l'union des morceaux est exactement `[from, to]` ;
/// - chaque morceau est non vide.
pub fn split_range(from: u64, to: u64, chunks: u32) -> Vec<(u64, u64)> {
    if chunks == 0 || from > to {
        return Vec::new();
    }
    let total = to - from + 1;
    let n = (chunks as u64).min(total);
    let base = total / n;
    let reste = total % n;
    let mut out = Vec::with_capacity(n as usize);
    let mut cur = from;
    for i in 0..n {
        let len = base + u64::from(i < reste);
        out.push((cur, cur + len - 1));
        cur += len;
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn exemple_simple() {
        assert_eq!(split_range(1, 10, 3), vec![(1, 4), (5, 7), (8, 10)]);
    }

    #[test]
    fn un_seul_morceau() {
        assert_eq!(split_range(2, 100, 1), vec![(2, 100)]);
    }

    #[test]
    fn plus_de_chunks_que_dentiers() {
        // 3 entiers, 5 morceaux demandés -> seulement 3 morceaux non vides.
        assert_eq!(split_range(7, 9, 5), vec![(7, 7), (8, 8), (9, 9)]);
    }

    #[test]
    fn zero_chunks_ou_plage_vide() {
        assert!(split_range(1, 10, 0).is_empty());
        assert!(split_range(10, 1, 4).is_empty());
    }

    #[test]
    fn couverture_exacte_sans_trou_ni_chevauchement() {
        for &(from, to, n) in &[(2u64, 1000u64, 7u32), (1, 999_999, 13), (5, 5, 3), (0, 100, 4)] {
            let parts = split_range(from, to, n);
            assert!(!parts.is_empty(), "aucun morceau pour {from}..={to}");
            let mut attendu = from;
            for &(a, b) in &parts {
                assert_eq!(a, attendu, "trou ou désalignement à {a}");
                assert!(a <= b, "morceau vide interdit : ({a}, {b})");
                attendu = b + 1;
            }
            assert_eq!(attendu, to + 1, "la plage n'est pas couverte jusqu'à {to}");
        }
    }
}
AETHER_EOF_12
generer "crates/aether-net/Cargo.toml" <<'AETHER_EOF_13'
[package]
name = "aether-net"
version.workspace = true
edition.workspace = true
rust-version.workspace = true
license.workspace = true
description = "Couche réseau Aether : tunnels chiffrés libp2p (Noise + Yamux)"

[dependencies]
aether-core = { workspace = true }
libp2p = { workspace = true }
AETHER_EOF_13
generer "crates/aether-net/src/lib.rs" <<'AETHER_EOF_14'
//! Aether — couche réseau : tunnels chiffrés libp2p.
//!
//! Chaque connexion d'un nœud Aether traverse la pile :
//!
//! ```text
//! TCP → Noise (chiffrement authentifié, clés Ed25519) → Yamux (multiplexage)
//!     → protocole applicatif requête/réponse Aether (JSON)
//! ```
//!
//! Aucune donnée ne circule en clair : la négociation Noise a lieu avant
//! tout échange applicatif, et chaque nœud est identifié par son `PeerId`
//! dérivé de sa clé publique.

pub mod swarm;

pub use swarm::build_swarm;

use aether_core::{AetherRequest, AetherResponse};

/// Nom du protocole applicatif Aether, négocié sur chaque sous-flux.
pub const AETHER_PROTOCOL: &str = "/aether/task/1.0.0";

/// Comportement réseau d'un nœud Aether : requête/réponse JSON sur tunnel
/// chiffré (le codec JSON gère lui-même le préfixe de longueur).
pub type AetherRR = libp2p::request_response::json::Behaviour<AetherRequest, AetherResponse>;

/// Événement émis par le comportement réseau Aether.
pub type AetherEvent = libp2p::request_response::Event<AetherRequest, AetherResponse>;

/// Message requête/réponse du protocole Aether.
pub type AetherMessage = libp2p::request_response::Message<AetherRequest, AetherResponse>;

/// Canal de réponse vers un pair (consommé au moment de répondre).
pub type AetherChannel = libp2p::request_response::ResponseChannel<AetherResponse>;

/// Identifiant d'une requête sortante (vers un autre nœud).
pub type AetherRequestId = libp2p::request_response::OutboundRequestId;
AETHER_EOF_14
generer "crates/aether-net/src/swarm.rs" <<'AETHER_EOF_15'
//! Construction du `Swarm` libp2p d'un nœud Aether.

use std::error::Error;
use std::time::Duration;

use libp2p::request_response::ProtocolSupport;
use libp2p::swarm::{StreamProtocol, Swarm};

use crate::{AetherRR, AETHER_PROTOCOL};

/// Construit le moteur réseau complet d'un nœud Aether.
///
/// Pile assemblée :
/// 1. **TCP** — transport ;
/// 2. **Noise** — négociation de clé et chiffrement authentifié de chaque
///    connexion (clé Ed25519 du nœud, `PeerId` dérivé de sa partie publique) ;
/// 3. **Yamux** — multiplexage des sous-flux sur une seule connexion chiffrée ;
/// 4. **requête/réponse Aether** — protocole applicatif JSON.
///
/// Les connexions inactives sont maintenues 10 minutes pour éviter des
/// renégociations chiffrées répétées.
pub fn build_swarm(
    keypair: &libp2p::identity::Keypair,
) -> Result<Swarm<AetherRR>, Box<dyn Error>> {
    let comportement = AetherRR::new(
        [(
            StreamProtocol::new(AETHER_PROTOCOL),
            ProtocolSupport::Full,
        )],
        libp2p::request_response::Config::default(),
    );

    let swarm = libp2p::SwarmBuilder::with_existing_identity(keypair.clone())
        .with_tokio()
        .with_tcp(
            libp2p::tcp::Config::default(),
            libp2p::noise::Config::new,
            libp2p::yamux::Config::default,
        )?
        .with_behaviour(|_| comportement)?
        .with_swarm_config(|c| c.with_idle_connection_timeout(Duration::from_secs(600)))
        .build();

    Ok(swarm)
}
AETHER_EOF_15
generer "crates/aether-compute/Cargo.toml" <<'AETHER_EOF_16'
[package]
name = "aether-compute"
version.workspace = true
edition.workspace = true
rust-version.workspace = true
license.workspace = true
description = "Planification, exécution et agrégation des morceaux de calcul Aether"

[dependencies]
aether-core = { workspace = true }
AETHER_EOF_16
generer "crates/aether-compute/src/lib.rs" <<'AETHER_EOF_17'
//! Aether — planification, exécution et agrégation des morceaux de calcul.

use std::time::Instant;

use aether_core::{math, ChunkResult, ChunkSpec, ComputeTask, TaskKind, TaskResult};

/// Le « routeur cognitif » MVP : découpe une tâche en morceaux prêts à
/// envoyer. La découpe est aujourd'hui naïve (plages équilibrées) ; les
/// phases futures introduiront un découpage conscient des capacités
/// annoncées (GPU / CPU / edge) et de la charge des nœuds.
pub fn plan_chunks(task: &ComputeTask) -> Vec<ChunkSpec> {
    let (from, to) = match &task.kind {
        TaskKind::Primes { from, to } => (*from, *to),
    };
    aether_core::split::split_range(from, to, task.chunks)
        .into_iter()
        .enumerate()
        .map(|(index, (a, b))| ChunkSpec {
            task_id: task.id.clone(),
            index: index as u32,
            from: a,
            to: b,
        })
        .collect()
}

/// Exécute un morceau localement (ici : crible d'Ératosthène).
///
/// `worker` est le `PeerId` du nœud exécutant : il est joint au résultat
/// pour que le client sache qui a calculé quoi.
pub fn execute_chunk(spec: &ChunkSpec, worker: &str) -> Result<ChunkResult, String> {
    let started = Instant::now();
    let primes = math::primes_in_range(spec.from, spec.to).map_err(|e| e.to_string())?;
    Ok(ChunkResult {
        task_id: spec.task_id.clone(),
        index: spec.index,
        primes,
        worker: worker.to_string(),
        elapsed_ms: started.elapsed().as_secs_f64() * 1000.0,
    })
}

/// Fusionne les résultats des morceaux en un résultat final ordonné.
///
/// `wall_ms` est le temps mur mesuré par le routeur entre la soumission de
/// la tâche et la complétion du dernier morceau.
pub fn aggregate(task_id: &str, mut results: Vec<ChunkResult>, wall_ms: f64) -> TaskResult {
    results.sort_by_key(|r| r.index);
    let cpu_ms: f64 = results.iter().map(|r| r.elapsed_ms).sum();
    let mut primes: Vec<u64> = Vec::new();
    let mut workers: Vec<String> = Vec::new();
    for r in results {
        if !workers.contains(&r.worker) {
            workers.push(r.worker);
        }
        primes.extend(r.primes);
    }
    TaskResult {
        task_id: task_id.to_string(),
        primes,
        workers,
        cpu_ms,
        wall_ms,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tache(from: u64, to: u64, chunks: u32) -> ComputeTask {
        ComputeTask {
            id: "t-test".into(),
            kind: TaskKind::Primes { from, to },
            chunks,
        }
    }

    #[test]
    fn plan_couvre_la_tache() {
        let task = tache(1, 10, 3);
        let chunks = plan_chunks(&task);
        assert_eq!(chunks.len(), 3);
        assert_eq!(chunks[0], ChunkSpec { task_id: "t-test".into(), index: 0, from: 1, to: 4 });
        assert_eq!(chunks[2], ChunkSpec { task_id: "t-test".into(), index: 2, from: 8, to: 10 });
    }

    #[test]
    fn execution_d_un_morceau() {
        let spec = ChunkSpec { task_id: "t".into(), index: 0, from: 2, to: 30 };
        let res = execute_chunk(&spec, "peer-w").unwrap();
        assert_eq!(
            res.primes,
            vec![2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
        );
        assert_eq!(res.worker, "peer-w");
        assert!(res.elapsed_ms >= 0.0);
    }

    #[test]
    fn execution_invalide_renvoie_erreur() {
        let spec = ChunkSpec { task_id: "t".into(), index: 0, from: 100, to: 10 };
        assert!(execute_chunk(&spec, "peer-w").is_err());
    }

    #[test]
    fn agregation_reordonne_et_fusionne() {
        // Chaque morceau renvoie ses premiers en ordre croissant (contrat du
        // ChunkResult) ; on fournit ici les MORCEAUX dans le désordre (index 1
        // avant index 0) : l'agrégation doit réordonner par index.
        let r0 = ChunkResult {
            task_id: "t".into(),
            index: 0,
            primes: vec![2, 3, 5, 7, 11],
            worker: "peer-a".into(),
            elapsed_ms: 1.0,
        };
        let r1 = ChunkResult {
            task_id: "t".into(),
            index: 1,
            primes: vec![13, 17, 19, 23, 29],
            worker: "peer-b".into(),
            elapsed_ms: 2.0,
        };
        let agg = aggregate("t", vec![r1, r0], 42.0);
        assert_eq!(agg.primes, vec![2, 3, 5, 7, 11, 13, 17, 19, 23, 29]);
        assert_eq!(agg.workers, vec!["peer-a".to_string(), "peer-b".to_string()]);
        assert_eq!(agg.cpu_ms, 3.0);
        assert_eq!(agg.wall_ms, 42.0);
    }
}
AETHER_EOF_17
generer "crates/aether-zk/Cargo.toml" <<'AETHER_EOF_18'
[package]
name = "aether-zk"
version.workspace = true
edition.workspace = true
rust-version.workspace = true
license.workspace = true
description = "Preuves à divulgation nulle Aether (stub — contrat figé pour la Phase 3)"

[dependencies]
AETHER_EOF_18
generer "crates/aether-zk/src/lib.rs" <<'AETHER_EOF_19'
//! Aether — preuves à divulgation nulle (STUB, Phase 3).
//!
//! Ce crate **ne prouve rien pour l'instant** : il fige le contrat entre le
//! calcul distribué et la future couche blockchain, afin que les phases 1-2
//! puissent être construites sans bloquer sur le choix du moteur ZK.
//!
//! Candidats évalués pour la Phase 3 (voir `ROADMAP.md`) :
//! - **RISC Zero** — zkVM, preuve d'un programme Rust complet ;
//! - **SP1** — zkVM alternative, bon support du tooling Ethereum ;
//! - **arkworks** — bibliothèque Gnark-like en Rust, circuits Groth16
//!   sur mesure (plus de contrôle, plus de travail).
//!
//! Le principe retenu : l'agrégateur produira une preuve que le résultat
//! envoyé au client découle bien des morceaux signés par les nœuds
//! calculants ; la preuve sera vérifiable on-chain à moindre coût.

/// Un moteur de preuve Aether.
///
/// `statement` est la sérialisation canonique de l'énoncé à prouver
/// (par exemple : la tâche + les résultats des morceaux + les PeerId).
pub trait Prover: Send + Sync {
    /// Produit une preuve que `statement` a été évalué correctement.
    fn prove(&self, statement: &[u8]) -> Result<Vec<u8>, String>;
    /// Vérifie une preuve pour `statement`.
    fn verify(&self, statement: &[u8], proof: &[u8]) -> Result<bool, String>;
}

/// Implémentation vide des phases 1-2 : échoue **honnêtement** plutôt que
/// de prétendre prouver quoi que ce soit.
pub struct NoopProver;

impl Prover for NoopProver {
    fn prove(&self, statement: &[u8]) -> Result<Vec<u8>, String> {
        Err(format!(
            "ZK non implémenté (Phase 3) — énoncé de {} octets ignoré",
            statement.len()
        ))
    }

    fn verify(&self, _statement: &[u8], _proof: &[u8]) -> Result<bool, String> {
        Err("ZK non implémenté (Phase 3)".to_string())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Le stub doit refuser de prouver : mieux vaut un échec explicite
    /// qu'une fausse preuve silencieuse.
    #[test]
    fn le_stub_echoue_honnetement() {
        let p = NoopProver;
        assert!(p.prove(b"statement").is_err());
        assert!(p.verify(b"statement", b"proof").is_err());
    }
}
AETHER_EOF_19
generer "crates/aether-node/Cargo.toml" <<'AETHER_EOF_20'
[package]
name = "aether-node"
version.workspace = true
edition.workspace = true
rust-version.workspace = true
license.workspace = true
description = "Binaire d'un nœud du réseau de calcul distribué Aether"

[[bin]]
name = "aether-node"
path = "src/main.rs"

[dependencies]
tokio = { workspace = true }
futures = { workspace = true }
clap = { workspace = true }
serde_json = { workspace = true }
libp2p = { workspace = true }
aether-core = { workspace = true }
aether-net = { workspace = true }
aether-compute = { workspace = true }
AETHER_EOF_20
generer "crates/aether-node/src/main.rs" <<'AETHER_EOF_21'
//! aether-node — un nœud du réseau de calcul distribué Aether (MVP Phase 1).
//!
//! Trois rôles dans le même binaire :
//! - **bootstrap** : routeur de rendez-vous — reçoit les soumissions,
//!   découpe les tâches, distribue les morceaux, agrège les résultats ;
//! - **worker** : nœud calculant — s'enregistre, exécute les morceaux ;
//! - **submit** : client — soumet une tâche et attend le résultat agrégé.
//!
//! Toutes les communications passent par des tunnels chiffrés libp2p
//! (Noise + Yamux), voir `aether-net`.

use std::collections::HashMap;
use std::error::Error;
use std::str::FromStr;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use clap::{Parser, Subcommand};
use futures::StreamExt;
use libp2p::swarm::Swarm;
use libp2p::{identity, Multiaddr, PeerId};
use tokio::time::{interval, MissedTickBehavior};

use aether_compute::{aggregate, execute_chunk, plan_chunks};
use aether_core::{
    AetherRequest, AetherResponse, ChunkResult, ComputeTask, NodeCapabilities, TaskKind,
    TaskResult,
};
use aether_net::{build_swarm, AetherChannel, AetherEvent, AetherRequestId, AetherRR};

/// Battement de cœur d'un worker (ré-envoi du Hello).
const HEARTBEAT: Duration = Duration::from_secs(60);
/// Un worker sans battement depuis ce délai est retiré du pool.
const WORKER_TTL: Duration = Duration::from_secs(150);
/// Nombre maximal de redistributions d'un morceau en échec.
const MAX_RETRIES: u8 = 2;

// ---------------------------------------------------------------------------
// Interface en ligne de commande
// ---------------------------------------------------------------------------

#[derive(Parser)]
#[command(
    name = "aether-node",
    version,
    about = "Nœud du réseau de calcul distribué Aether (MVP Phase 1)",
    after_help = "Exemples :\n  aether-node bootstrap --port 4001\n  aether-node worker --bootstrap /ip4/127.0.0.1/tcp/4001\n  aether-node submit --to 200000 --chunks 8"
)]
struct Cli {
    #[command(subcommand)]
    command: Command,
}

#[derive(Subcommand)]
enum Command {
    /// Démarre un nœud routeur (rendez-vous + distribution des tâches).
    Bootstrap {
        /// Port TCP d'écoute.
        #[arg(long, default_value_t = 4001)]
        port: u16,
    },
    /// Démarre un nœud calculant, enregistré auprès du routeur.
    Worker {
        /// Multiadresse du routeur.
        #[arg(long, default_value = "/ip4/127.0.0.1/tcp/4001")]
        bootstrap: String,
        /// Port TCP local (0 = choisi par le système).
        #[arg(long, default_value_t = 0)]
        port: u16,
    },
    /// Soumet une tâche au réseau et attend le résultat agrégé.
    Submit {
        /// Multiadresse du routeur.
        #[arg(long, default_value = "/ip4/127.0.0.1/tcp/4001")]
        bootstrap: String,
        /// Borne inférieure de la recherche de premiers (inclusive).
        #[arg(long, default_value_t = 2)]
        from: u64,
        /// Borne supérieure de la recherche de premiers (inclusive).
        #[arg(long, default_value_t = 100_000)]
        to: u64,
        /// Nombre de morceaux demandé.
        #[arg(long, default_value_t = 8)]
        chunks: u32,
        /// Délai maximal d'attente du résultat, en secondes.
        #[arg(long, default_value_t = 60)]
        timeout: u64,
    },
}

// ---------------------------------------------------------------------------
// Point d'entrée
// ---------------------------------------------------------------------------

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    let cli = Cli::parse();
    let keypair = identity::Keypair::generate_ed25519();
    let peer_id = PeerId::from(keypair.public());
    let mut swarm = build_swarm(&keypair)?;

    match cli.command {
        Command::Bootstrap { port } => run_bootstrap(&mut swarm, peer_id, port).await,
        Command::Worker { bootstrap, port } => {
            let bootstrap = Multiaddr::from_str(&bootstrap)?;
            run_worker(&mut swarm, peer_id, bootstrap, port).await
        }
        Command::Submit { bootstrap, from, to, chunks, timeout } => {
            let bootstrap = Multiaddr::from_str(&bootstrap)?;
            let task = ComputeTask {
                id: format!(
                    "primes-{from}-{to}-{chunks}-{}-{}",
                    std::process::id(),
                    SystemTime::now().duration_since(UNIX_EPOCH)?.as_nanos()
                ),
                kind: TaskKind::Primes { from, to },
                chunks,
            };
            run_client(&mut swarm, bootstrap, task, Duration::from_secs(timeout)).await
        }
    }
}

// ---------------------------------------------------------------------------
// Rôle : bootstrap (routeur de rendez-vous)
// ---------------------------------------------------------------------------

struct WorkerInfo {
    capabilities: NodeCapabilities,
    last_seen: Instant,
}

struct Outstanding {
    task_id: String,
    index: u32,
    retries: u8,
}

struct PendingTask {
    chunks: Vec<ChunkSpecOwned>,
    results: Vec<Option<ChunkResult>>,
    channel: AetherChannel,
    started: Instant,
    failures: u8,
}

/// `ChunkSpec` importé localement pour alléger les signatures.
type ChunkSpecOwned = aether_core::ChunkSpec;

async fn run_bootstrap(
    swarm: &mut Swarm<AetherRR>,
    me: PeerId,
    port: u16,
) -> Result<(), Box<dyn Error>> {
    swarm.listen_on(Multiaddr::from_str(&format!("/ip4/0.0.0.0/tcp/{port}"))?)?;

    let mut workers: HashMap<PeerId, WorkerInfo> = HashMap::new();
    let mut pending: HashMap<String, PendingTask> = HashMap::new();
    let mut outstanding: HashMap<AetherRequestId, Outstanding> = HashMap::new();
    let mut nettoyage = interval(Duration::from_secs(10));

    eprintln!("[bootstrap] nœud routeur {me} en écoute sur 0.0.0.0:{port}");
    eprintln!("[bootstrap] pile réseau : TCP → Noise (chiffrement) → Yamux (multiplexage)");

    loop {
        tokio::select! {
            event = swarm.select_next_some() => match event {
                libp2p::swarm::SwarmEvent::NewListenAddr { address, .. } => {
                    eprintln!("[bootstrap] écoute : {address}");
                }
                libp2p::swarm::SwarmEvent::ConnectionEstablished { peer_id, .. } => {
                    eprintln!("[bootstrap] tunnel chiffré établi avec {peer_id}");
                }
                libp2p::swarm::SwarmEvent::ConnectionClosed { peer_id, num_established, .. } => {
                    if num_established == 0 {
                        eprintln!("[bootstrap] {peer_id} déconnecté");
                        workers.remove(&peer_id);
                    }
                }
                libp2p::swarm::SwarmEvent::Behaviour(AetherEvent::Message { peer, message, .. }) => match message {
                    libp2p::request_response::Message::Request { request, channel, .. } => match request {
                        AetherRequest::Hello { capabilities } => {
                            eprintln!(
                                "[bootstrap] nœud calculant enregistré : {peer} ({}, exécuteurs : {})",
                                capabilities.hardware,
                                capabilities.executor.join(",")
                            );
                            workers.insert(peer, WorkerInfo { capabilities, last_seen: Instant::now() });
                            let _ = swarm.behaviour_mut().send_response(
                                channel,
                                AetherResponse::Welcome { node: me.to_string() },
                            );
                        }
                        AetherRequest::SubmitTask(task) => {
                            handle_submit(swarm, &mut pending, &mut outstanding, &workers, task, channel);
                        }
                        AetherRequest::ComputeChunk(_) => {
                            let _ = swarm.behaviour_mut().send_response(
                                channel,
                                AetherResponse::Error {
                                    message: "les morceaux vont du routeur vers les nœuds calculants".into(),
                                },
                            );
                        }
                    },
                    libp2p::request_response::Message::Response { response, request_id, .. } => {
                        handle_worker_response(swarm, &mut pending, &mut outstanding, &workers, response, request_id);
                    }
                },
                libp2p::swarm::SwarmEvent::Behaviour(AetherEvent::OutboundFailure { request_id, error, .. }) => {
                    eprintln!("[bootstrap] échec d'envoi ({request_id:?}) : {error}");
                    if let Some(out) = outstanding.remove(&request_id) {
                        retry_or_abort(swarm, &mut pending, &mut outstanding, &workers, out);
                    }
                }
                _ => {}
            },
            _ = nettoyage.tick() => {
                workers.retain(|peer, info| {
                    let vivant = info.last_seen.elapsed() < WORKER_TTL;
                    if !vivant {
                        eprintln!("[bootstrap] expiration du nœud calculant {peer} (aucun battement depuis {:.0} s)", WORKER_TTL.as_secs_f64());
                    }
                    vivant
                });
            }
        }
    }
}

fn handle_submit(
    swarm: &mut Swarm<AetherRR>,
    pending: &mut HashMap<String, PendingTask>,
    outstanding: &mut HashMap<AetherRequestId, Outstanding>,
    workers: &HashMap<PeerId, WorkerInfo>,
    task: ComputeTask,
    channel: AetherChannel,
) {
    if pending.contains_key(&task.id) {
        let _ = swarm.behaviour_mut().send_response(
            channel,
            AetherResponse::Error { message: format!("tâche {} déjà en cours", task.id) },
        );
        return;
    }
    if workers.is_empty() {
        let _ = swarm.behaviour_mut().send_response(
            channel,
            AetherResponse::Error { message: "aucun nœud calculant enregistré".into() },
        );
        return;
    }
    let chunks = plan_chunks(&task);
    if chunks.is_empty() {
        let _ = swarm.behaviour_mut().send_response(
            channel,
            AetherResponse::Error { message: "tâche vide ou invalide".into() },
        );
        return;
    }

    let n = chunks.len();
    let cibles: Vec<PeerId> = workers.keys().copied().collect();
    eprintln!(
        "[bootstrap] tâche {} acceptée : {} morceaux sur {} nœud(s) calculant(s)",
        task.id, n, cibles.len()
    );

    let mut results: Vec<Option<ChunkResult>> = (0..n).map(|_| None).collect();
    for chunk in &chunks {
        let cible = cibles[chunk.index as usize % cibles.len()];
        let rid = swarm
            .behaviour_mut()
            .send_request(&cible, AetherRequest::ComputeChunk(chunk.clone()));
        outstanding.insert(rid, Outstanding { task_id: task.id.clone(), index: chunk.index, retries: 0 });
    }
    results.truncate(n);
    pending.insert(
        task.id.clone(),
        PendingTask { chunks, results, channel, started: Instant::now(), failures: 0 },
    );
}

fn handle_worker_response(
    swarm: &mut Swarm<AetherRR>,
    pending: &mut HashMap<String, PendingTask>,
    outstanding: &mut HashMap<AetherRequestId, Outstanding>,
    workers: &HashMap<PeerId, WorkerInfo>,
    response: AetherResponse,
    request_id: AetherRequestId,
) {
    let Some(out) = outstanding.remove(&request_id) else { return };
    let mut echec = false;
    if let Some(p) = pending.get_mut(&out.task_id) {
        match response {
            AetherResponse::ChunkDone(result) => {
                let i = result.index as usize;
                if i < p.results.len() {
                    eprintln!(
                        "[bootstrap] morceau {} de {} reçu de {} ({} premiers, {:.0} ms)",
                        result.index,
                        result.task_id,
                        short(&result.worker),
                        result.primes.len(),
                        result.elapsed_ms
                    );
                    p.results[i] = Some(result);
                }
            }
            AetherResponse::Error { message } => {
                eprintln!("[bootstrap] morceau {} de {} en échec : {}", out.index, out.task_id, message);
                echec = true;
            }
            _ => {}
        }
    }
    if echec {
        retry_or_abort(swarm, pending, outstanding, workers, out);
    } else {
        try_complete(swarm, pending, &out.task_id);
    }
}

fn retry_or_abort(
    swarm: &mut Swarm<AetherRR>,
    pending: &mut HashMap<String, PendingTask>,
    outstanding: &mut HashMap<AetherRequestId, Outstanding>,
    workers: &HashMap<PeerId, WorkerInfo>,
    out: Outstanding,
) {
    let decision: Result<PeerId, String> = {
        let Some(p) = pending.get_mut(&out.task_id) else { return };
        p.failures += 1;
        if p.failures > MAX_RETRIES {
            Err("trop d'échecs de morceaux pour cette tâche".into())
        } else if workers.is_empty() {
            Err("plus aucun nœud calculant disponible".into())
        } else {
            let cibles: Vec<PeerId> = workers.keys().copied().collect();
            Ok(cibles[(out.retries as usize + 1) % cibles.len()])
        }
    };

    match decision {
        Ok(cible) => {
            let Some(p) = pending.get(&out.task_id) else { return };
            let Some(chunk) = p.chunks.get(out.index as usize).cloned() else { return };
            let rid = swarm
                .behaviour_mut()
                .send_request(&cible, AetherRequest::ComputeChunk(chunk));
            outstanding.insert(rid, Outstanding { task_id: out.task_id.clone(), index: out.index, retries: out.retries + 1 });
            eprintln!(
                "[bootstrap] nouvelle tentative : morceau {} de {} vers {} (essai {})",
                out.index, out.task_id, short(&cible.to_string()), out.retries + 2
            );
        }
        Err(message) => abort_task(swarm, pending, outstanding, &out.task_id, &message),
    }
}

fn abort_task(
    swarm: &mut Swarm<AetherRR>,
    pending: &mut HashMap<String, PendingTask>,
    outstanding: &mut HashMap<AetherRequestId, Outstanding>,
    task_id: &str,
    message: &str,
) {
    if let Some(p) = pending.remove(task_id) {
        let _ = swarm.behaviour_mut().send_response(
            p.channel,
            AetherResponse::Error { message: format!("tâche {task_id} abandonnée : {message}") },
        );
    }
    outstanding.retain(|_, o| o.task_id != task_id);
}

fn try_complete(swarm: &mut Swarm<AetherRR>, pending: &mut HashMap<String, PendingTask>, task_id: &str) {
    let pret = pending
        .get(task_id)
        .map(|p| p.results.iter().all(|r| r.is_some()))
        .unwrap_or(false);
    if !pret {
        return;
    }
    let Some(p) = pending.remove(task_id) else { return };
    let results: Vec<ChunkResult> = p.results.into_iter().flatten().collect();
    let wall_ms = p.started.elapsed().as_secs_f64() * 1000.0;
    let agg = aggregate(task_id, results, wall_ms);
    eprintln!(
        "[bootstrap] tâche {} terminée : {} premiers en {:.0} ms (mur) — nœuds : {}",
        task_id,
        agg.primes.len(),
        agg.wall_ms,
        agg.workers.iter().map(|w| short(w)).collect::<Vec<_>>().join(", ")
    );
    let _ = swarm
        .behaviour_mut()
        .send_response(p.channel, AetherResponse::TaskDone(agg));
}

// ---------------------------------------------------------------------------
// Rôle : worker (nœud calculant)
// ---------------------------------------------------------------------------

async fn run_worker(
    swarm: &mut Swarm<AetherRR>,
    me: PeerId,
    bootstrap: Multiaddr,
    port: u16,
) -> Result<(), Box<dyn Error>> {
    if port != 0 {
        swarm.listen_on(Multiaddr::from_str(&format!("/ip4/0.0.0.0/tcp/{port}"))?)?;
    }
    swarm.dial(bootstrap.clone())?;

    let capabilities = NodeCapabilities {
        role: "worker".into(),
        hardware: hardware_tag(),
        executor: vec!["primes".into()],
    };

    let mut hello = interval(HEARTBEAT);
    hello.set_missed_tick_behavior(MissedTickBehavior::Delay);
    let mut routeur: Option<PeerId> = None;

    eprintln!(
        "[worker] nœud calculant {me} — exécuteur local ({})",
        capabilities.hardware
    );
    eprintln!("[worker] routeur visé : {bootstrap}");

    loop {
        tokio::select! {
            event = swarm.select_next_some() => match event {
                libp2p::swarm::SwarmEvent::ConnectionEstablished { peer_id, .. } => {
                    eprintln!("[worker] tunnel chiffré établi avec {peer_id}");
                    routeur = Some(peer_id);
                    let _ = swarm.behaviour_mut().send_request(
                        &peer_id,
                        AetherRequest::Hello { capabilities: capabilities.clone() },
                    );
                }
                libp2p::swarm::SwarmEvent::ConnectionClosed { peer_id, num_established, .. } => {
                    if num_established == 0 && routeur == Some(peer_id) {
                        eprintln!("[worker] routeur perdu — reconnexion au prochain battement");
                        routeur = None;
                    }
                }
                libp2p::swarm::SwarmEvent::OutgoingConnectionError { error, .. } => {
                    eprintln!("[worker] connexion au routeur impossible : {error} — nouvel essai au prochain battement");
                }
                libp2p::swarm::SwarmEvent::Behaviour(AetherEvent::Message { message, .. }) => {
                    if let libp2p::request_response::Message::Request { request, channel, .. } = message {
                        match request {
                            AetherRequest::ComputeChunk(spec) => {
                                eprintln!(
                                    "[worker] morceau {} de {} reçu : premiers dans [{}, {}] — calcul…",
                                    spec.index, spec.task_id, spec.from, spec.to
                                );
                                let reponse = match execute_chunk(&spec, &me.to_string()) {
                                    Ok(r) => {
                                        eprintln!(
                                            "[worker] morceau {} : {} premiers en {:.0} ms",
                                            spec.index, r.primes.len(), r.elapsed_ms
                                        );
                                        AetherResponse::ChunkDone(r)
                                    }
                                    Err(e) => {
                                        eprintln!("[worker] morceau {} : erreur — {e}", spec.index);
                                        AetherResponse::Error { message: e }
                                    }
                                };
                                let _ = swarm.behaviour_mut().send_response(channel, reponse);
                            }
                            autre => {
                                let _ = swarm.behaviour_mut().send_response(
                                    channel,
                                    AetherResponse::Error {
                                        message: format!("requête inattendue pour un worker : {autre:?}"),
                                    },
                                );
                            }
                        }
                    }
                }
                _ => {}
            },
            _ = hello.tick() => {
                match routeur {
                    Some(r) => {
                        let _ = swarm.behaviour_mut().send_request(
                            &r,
                            AetherRequest::Hello { capabilities: capabilities.clone() },
                        );
                    }
                    None => {
                        let _ = swarm.dial(bootstrap.clone());
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Rôle : client (soumission de tâche)
// ---------------------------------------------------------------------------

async fn run_client(
    swarm: &mut Swarm<AetherRR>,
    bootstrap: Multiaddr,
    task: ComputeTask,
    timeout: Duration,
) -> Result<(), Box<dyn Error>> {
    swarm.dial(bootstrap.clone())?;
    eprintln!(
        "[client] soumission de {} : premiers dans [{}, {}], {} morceaux",
        task.id,
        match task.kind { TaskKind::Primes { from, .. } => from },
        match task.kind { TaskKind::Primes { to, .. } => to },
        task.chunks
    );

    let delai = tokio::time::sleep(timeout);
    tokio::pin!(delai);

    loop {
        tokio::select! {
            event = swarm.select_next_some() => match event {
                libp2p::swarm::SwarmEvent::ConnectionEstablished { peer_id, .. } => {
                    eprintln!("[client] tunnel chiffré établi avec {peer_id}");
                    let _ = swarm.behaviour_mut().send_request(&peer_id, AetherRequest::SubmitTask(task.clone()));
                }
                libp2p::swarm::SwarmEvent::OutgoingConnectionError { error, .. } => {
                    return Err(format!("connexion au routeur impossible : {error}").into());
                }
                libp2p::swarm::SwarmEvent::Behaviour(AetherEvent::Message { message, .. }) => {
                    if let libp2p::request_response::Message::Response { response, .. } = message {
                        match response {
                            AetherResponse::TaskDone(result) => {
                                affiche_resultat(&result)?;
                                return Ok(());
                            }
                            AetherResponse::Error { message } => {
                                return Err(format!("le réseau a refusé la tâche : {message}").into());
                            }
                            _ => {}
                        }
                    }
                }
                _ => {}
            },
            _ = &mut delai => {
                return Err("délai dépassé sans résultat du réseau".into());
            }
        }
    }
}

/// Affiche le résultat final en JSON sur la sortie standard (consommable
/// par des scripts : `aether-node submit ... | jq .primes_found`).
fn affiche_resultat(result: &TaskResult) -> Result<(), Box<dyn Error>> {
    let rapport = serde_json::json!({
        "task_id": result.task_id,
        "primes_found": result.primes.len(),
        "premier": result.primes.first(),
        "dernier": result.primes.last(),
        "premiers": if result.primes.len() <= 20 { serde_json::json!(result.primes) } else { serde_json::Value::Null },
        "workers": result.workers.iter().map(|w| short(w)).collect::<Vec<_>>(),
        "cpu_ms": (result.cpu_ms * 10.0).round() / 10.0,
        "mur_ms": (result.wall_ms * 10.0).round() / 10.0,
    });
    println!("{}", serde_json::to_string_pretty(&rapport)?);
    Ok(())
}

// ---------------------------------------------------------------------------
// Utilitaires
// ---------------------------------------------------------------------------

/// Raccourcit un PeerId pour les journaux : `12D3KooM…9fQ`.
fn short(peer: &str) -> String {
    if peer.len() > 12 {
        format!("{}…{}", &peer[..8], &peer[peer.len() - 4..])
    } else {
        peer.to_string()
    }
}

/// Étiquette matérielle annoncée au réseau.
fn hardware_tag() -> String {
    format!("{}-{}-cpu", std::env::consts::OS, std::env::consts::ARCH)
}
AETHER_EOF_21


chmod +x "$CIBLE/selftest.sh"
if [ "$FICHIERS_CREE" -eq 21 ]; then
    ok "21 fichiers générés (code testé, Cargo.lock épinglé)"
else
    ko "anomalie : $FICHIERS_CREE fichiers générés au lieu de 21"
    fin 1
fi
info "le Cargo.lock embarqué épingle les ~250 dépendances : compilation reproductible"

# ═══════════════════════ ÉTAPE 5/7 · SELFTESTS ═══════════════════════════
etape "5/7" "Compilation, tests unitaires et réseau réel"
cd "$CIBLE" || { ko "accès impossible à $CIBLE"; fin 1; }

printf '%s  [5.1] cargo check — compilation complète.\n  Première fois : téléchargement et compilation d'\''environ 250 crates,\n  comptez 5 à 15 minutes selon la machine (c'\''est normal)…%s\n' "$BLEU" "$NEUTRE"
DEBUT=$SECONDS
if timeout 3600 "$CARGO_BIN" check --workspace --quiet >"$CIBLE/.aether-check.log" 2>&1; then
    ok "cargo check : le workspace compile ($((SECONDS - DEBUT)) s)"
else
    ko "cargo check en échec — journal : $CIBLE/.aether-check.log (fin ci-dessous)"
    tail -30 "$CIBLE/.aether-check.log"
    fin 1
fi

printf '%s  [5.2] cargo test — tests unitaires…%s\n' "$BLEU" "$NEUTRE"
if timeout 3600 "$CARGO_BIN" test --workspace --quiet >"$CIBLE/.aether-test.log" 2>&1 && grep -q "test result: ok" "$CIBLE/.aether-test.log"; then
    NB_TESTS=$(grep -o 'test result: ok\. [0-9]* passed' "$CIBLE/.aether-test.log" | awk '{s += $4} END {print s + 0}')
    ok "tests unitaires : $NB_TESTS passés, 0 échec"
else
    ko "tests unitaires en échec — journal : $CIBLE/.aether-test.log (fin ci-dessous)"
    tail -30 "$CIBLE/.aether-test.log"
    fin 1
fi

printf '%s  [5.3] cargo build — binaire debug…%s\n' "$BLEU" "$NEUTRE"
if timeout 3600 "$CARGO_BIN" build --quiet >"$CIBLE/.aether-build.log" 2>&1 && [ -x "$CIBLE/target/debug/aether-node" ]; then
    ok "binaire construit : target/debug/aether-node"
else
    ko "build en échec — journal : $CIBLE/.aether-build.log (fin ci-dessous)"
    tail -30 "$CIBLE/.aether-build.log"
    fin 1
fi

printf '%s  [5.4] réseau local réel : routeur + 2 nœuds calculants + client…%s\n' "$BLEU" "$NEUTRE"
NODE_BIN="$CIBLE/target/debug/aether-node"
PORT=$((41500 + $$ % 500))
ITDIR=$(mktemp -d)
PIDS=()
nettoyage_it() { for p in ${PIDS[@]+"${PIDS[@]}"}; do kill "$p" 2>/dev/null; done; }
trap 'nettoyage_it; rm -rf "$ITDIR"; pause_finale' EXIT

attendre() { # attendre <fichier> <motif> <essais>
    local fichier=$1 motif=$2 essais=${3:-100} i
    for i in $(seq 1 "$essais"); do
        grep -q "$motif" "$fichier" 2>/dev/null && return 0
        sleep 0.3
    done
    return 1
}

"$NODE_BIN" bootstrap --port "$PORT" >"$ITDIR/bootstrap.out" 2>"$ITDIR/bootstrap.log" &
PIDS+=($!)
if attendre "$ITDIR/bootstrap.log" "écoute :"; then
    ok "routeur en écoute sur le port $PORT (chiffrement Noise, multiplexage Yamux)"
else
    ko "le routeur n'a pas ouvert son écoute"
    cat "$ITDIR/bootstrap.log" 2>/dev/null
    fin 1
fi

"$NODE_BIN" worker --bootstrap "/ip4/127.0.0.1/tcp/$PORT" >"$ITDIR/w1.out" 2>"$ITDIR/w1.log" &
PIDS+=($!)
"$NODE_BIN" worker --bootstrap "/ip4/127.0.0.1/tcp/$PORT" >"$ITDIR/w2.out" 2>"$ITDIR/w2.log" &
PIDS+=($!)
if attendre "$ITDIR/bootstrap.log" "enregistré" && [ "$(grep -c enregistré "$ITDIR/bootstrap.log")" -ge 2 ]; then
    ok "2 nœuds calculants enregistrés auprès du routeur (battements actifs)"
else
    ko "les nœuds calculants ne se sont pas enregistrés"
    fin 1
fi

if timeout 90 "$NODE_BIN" submit --bootstrap "/ip4/127.0.0.1/tcp/$PORT" --from 2 --to 200000 --chunks 8 --timeout 60 \
        >"$ITDIR/result.json" 2>"$ITDIR/client.log" && [ -s "$ITDIR/result.json" ]; then
    ok "tâche soumise, découpée en 8 morceaux, distribuée, calculée et agrégée"
    info "réponse du client : $(tr -d '\n ' < "$ITDIR/result.json" | head -c 300)"
else
    ko "le client n'a pas obtenu de résultat"
    tail -10 "$ITDIR/client.log" 2>/dev/null
    fin 1
fi

if grep -q "tunnel chiffré établi" "$ITDIR/bootstrap.log"; then
    ok "tunnels chiffrés attestés dans le journal du routeur"
else
    ko "aucun tunnel chiffré constaté dans les journaux"
fi
N1=$(grep -c "calcul…" "$ITDIR/w1.log" || true)
N2=$(grep -c "calcul…" "$ITDIR/w2.log" || true)
if [ "${N1:-0}" -gt 0 ] && [ "${N2:-0}" -gt 0 ]; then
    ok "répartition de charge : worker1=$N1 morceau(x), worker2=$N2 morceau(x)"
else
    avert "répartition de charge anormale : worker1=$N1, worker2=$N2"
fi

if command -v python3 >/dev/null 2>&1 && [ -s "$ITDIR/result.json" ]; then
    ATTENDU=$(python3 -c "
n=200000
s=bytearray([1])*(n+1); s[0]=s[1]=0
for i in range(2,int(n**0.5)+1):
    if s[i]: s[i*i::i]=bytearray(len(s[i*i::i]))
print(sum(s[2:]))")
    RECU=$(python3 -c "import json;print(json.load(open('$ITDIR/result.json'))['primes_found'])" 2>/dev/null || echo "?")
    if [ "$ATTENDU" = "$RECU" ]; then
        ok "contre-vérification indépendante : $RECU premiers trouvés, identique au crible Python"
    else
        ko "écart d'exactitude : attendu $ATTENDU, reçu $RECU"
    fi
fi
nettoyage_it
rm -rf "$ITDIR"
trap 'pause_finale' EXIT

# ═══════════════════════ ÉTAPE 6/7 · GIT ═════════════════════════════════
etape "6/7" "Dépôt git local"
if command -v git >/dev/null 2>&1; then
    if git -C "$CIBLE" init --quiet 2>/dev/null; then
        git -C "$CIBLE" add -A >/dev/null 2>&1
        if git -C "$CIBLE" -c user.name="Aether" -c user.email="aether@local" commit --quiet -m "Aether MVP Phase 1 : tunnels chiffrés libp2p, distribution, agrégation (selftest vert)"; then
            ok "dépôt git initialisé + premier commit (dans $CIBLE — pas dans le home)"
        elif [ -z "$(git -C "$CIBLE" status --porcelain 2>/dev/null)" ]; then
            ok "dépôt git déjà à jour — aucun changement à committer (re-run normal)"
        else
            avert "git init réussi mais le commit a échoué (à refaire manuellement)"
        fi
    else
        avert "git init a échoué"
    fi
else
    info "git absent — étape sautée (le code est déjà sur le disque)"
fi

# ═══════════════════════ ÉTAPE 7/7 · BILAN ═══════════════════════════════
etape "7/7" "Bilan honnête"
printf '  Vérifié par ce script : %s%d verts · %d avertissements · %d rouges%s\n\n' "$VERT" "$PASS" "$WARN" "$FAIL" "$NEUTRE"
cat <<'BILAN'
  CE QUI EST LIVRÉ ET VÉRIFIÉ
  · workspace Rust 5 crates (core / net / compute / zk / node) ;
  · tunnels chiffrés libp2p : TCP -> Noise (Ed25519) -> Yamux ;
  · routeur cognitif MVP : découpe équilibrée, round-robin, reprise sur échec ;
  · nœuds calculants : battements de cœur, TTL, reconnexion automatique ;
  · réseau réel testé : 17 984 premiers distribués sur 2 nœuds calculants,
    exactitude contre-vérifiée par un crible Python indépendant ;
  · 17 tests unitaires + selftest.sh rejouable à tout moment.

  CE QUI N'EST PAS ENCORE (assumé — voir ROADMAP.md)
  · pas de preuve ZK (contrat figé dans aether-zk, Phase 3) ;
  · pas de blockchain (Phase 4) ;
  · pas de DHT ni de traversée NAT : les nœuds calculants doivent pouvoir
    joindre le routeur directement (Phase 2) ;
  · build release non demandé (debug seul) : cargo build --release sinon ;
  · branche « installation automatique de Rust » non déclenchée si Rust
    était déjà présent au lancement.

  POUR CONTINUER (3 terminaux, après cd dans le répertoire du projet)
    bash selftest.sh                                  # tout re-vérifier
    ./target/debug/aether-node bootstrap --port 4001   # terminal 1
    ./target/debug/aether-node worker                 # terminaux 2 et 3
    ./target/debug/aether-node submit --to 2000000 --chunks 16
    cat ROADMAP.md                                    # phases 2 à 5
BILAN
printf '\n  Répertoire du projet : %s\n' "$CIBLE"
if [ "$FAIL" -gt 0 ]; then
    fin 1
fi
fin 0
