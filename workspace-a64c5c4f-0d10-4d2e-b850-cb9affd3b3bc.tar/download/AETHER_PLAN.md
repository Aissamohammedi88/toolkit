# AETHER — plan d'implémentation Rust (Phase 1 livrée et vérifiée)

*Réseau de calcul distribué P2P chiffré — livrable du 2026-10-30*

---

## 1. Ce que tu télécharges

| Fichier                  | Rôle                                                     |
| ------------------------ | -------------------------------------------------------- |
| `aether-tout-en-un.sh`   | Le tout : installe Rust si besoin, génère le dépôt Aether complet, compile, teste, lance un vrai réseau, commite, fait le bilan — et se met en pause à la fin (fini le terminal qui se ferme) |
| `AETHER_PLAN.md`         | Ce document (lecture sans rien exécuter)                 |

```bash
bash aether-tout-en-un.sh            # tout est expliqué pas à pas à l'écran
# ou : bash aether-tout-en-un.sh ~/mes-projets/aether
```

## 2. Ce qui a été vérifié pour de vrai (pas déclaré — mesuré)

Dans l'environnement de génération, le script a été exécuté de bout en bout,
y compris sur un répertoire vierge :

- **16/16 vérifications vertes, 0 avertissement, code de sortie 0** ;
- 17 tests unitaires passés (découpage sans trou ni chevauchement, crible
  exact, agrégation ordonnée, protocole JSON aller-retour, tolérance aux
  champs inconnus) ;
- **réseau réel** : routeur + 2 nœuds calculants + client sur tunnels
  chiffrés libp2p (Noise + Yamux, clés Ed25519) ;
- tâche « premiers dans [2, 200 000] » découpée en 8 morceaux, répartis
  4/4 sur les deux nœuds calculants, résultat agrégé en ~90 ms ;
- **exactitude contre-vérifiée par un crible Python indépendant :
  17 984 premiers trouvés, zéro écart** ;
- dépôt git initialisé *dans le répertoire du projet* (le défaut du
  `nexus-tout-en-un` qui mettait le repo dans `$HOME` est corrigé).

Non testé ici (dit honnêtement) : la branche « installation automatique de
Rust » (Rust était déjà présent pendant la vérification) et le build
`--release`.

## 3. Architecture livrée

```text
client (submit)              routeur (bootstrap)                workers
     │ soumission                 │                              │
     ├───────────────────────────▶│ découpe équilibrée           │
     │                            ├──Hello/battements 60 s──────▶│
     │                            ├──ComputeChunk (chiffré)─────▶│
     │                            │◀──ChunkDone──────────────────┤
     │◀──TaskDone (agrégé)────────│   + reprise sur échec ×2     │
```

Pile réseau de chaque connexion : **TCP → Noise (chiffrement authentifié) →
Yamux (multiplexage) → requête/réponse JSON**.

| Crate            | Rôle                                                    |
| ---------------- | ------------------------------------------------------- |
| `aether-core`    | Contrat partagé : tâches, morceaux, résultats, protocole |
| `aether-net`     | Tunnels chiffrés libp2p (identités Ed25519 / PeerId)     |
| `aether-compute` | Routeur cognitif MVP : découpage, exécution, agrégation  |
| `aether-zk`      | Contrat ZK figé (stub honnête — échoue plutôt que mentir) |
| `aether-node`    | Binaire unique : `bootstrap` / `worker` / `submit`       |

Robustesse incluse dès la Phase 1 : battements de cœur + TTL (150 s),
reconnexion automatique, redistribution des morceaux en échec (max 2),
bornes mémoire de l'exécuteur, protocole JSON tolérant aux évolutions.

## 4. Feuille de route (critères de sortie mesurables)

- **Phase 2 — résilience** : validation par double calcul + vote, DHT
  Kademlia, gossipsub de capacités, traversée NAT (relais + hole punching),
  QUIC, exécuteur à charge réellement inégale (SHA-256 par lots).
  *Sortie : 3 machines physiques sur 2 réseaux, sans routeur central.*
- **Phase 3 — preuves ZK** : sélection du moteur (RISC Zero / SP1 /
  arkworks), énoncé prouvé = « l'agrégé découle des morceaux signés ».
  *Sortie : preuve vérifiable < 5 s, < 100 ko.*
- **Phase 4 — blockchain** : vérification on-chain (L2), paiement des
  nœuds, staking/slashing. *Sortie : cycle tâche→preuve→paiement sur testnet.*
- **Phase 5 — hétérogène réel** : GPU via `wgpu` (CUDA/Vulkan/Metal —
  PC gamer / serveur / Mac M3), chiffrement applicatif bout en bout.
  *Sortie : même résultat bit-à-bit sur 2 GPU hétérogènes + preuve ZK.*

Le détail complet est dans `ARCHITECTURE.md` et `ROADMAP.md` **générés dans
le dépôt** par le script, avec le modèle de menace (ce qui est protégé, ce
qui ne l'est pas encore).

## 5. Après le script

```bash
cd ~/aether                # (ou le répertoire choisi)
bash selftest.sh           # re-vérifie TOUT, à tout moment
./target/debug/aether-node bootstrap --port 4001     # terminal 1
./target/debug/aether-node worker                    # terminaux 2, 3…
./target/debug/aether-node submit --to 2000000 --chunks 16
cargo build --release      # binaire optimisé
```

Trois chantiers suivants possibles — dis-moi lequel tu veux :
1. **Phase 2 résilience** (double calcul + DHT) ;
2. **exécuteur GPU wgpu** pour la partie PC gamer ;
3. **sélection ZK** (banc d'essai RISC Zero vs SP1 vs arkworks).
