#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════
#  NEXUS AETHER — TOUT-EN-UN BUREAU · v1.0.0
#  ──────────────────────────────────────────────────────────────────────
#  Crée, compile, installe et teste l'application desktop NEXUS AETHER :
#    · Interface nébuleuse WebGL + Glassmorphism 2.0 (identité exclusive)
#    · VRAI terminal fluide (pty réel via util-linux « script » + xterm.js)
#    · Serveur qui démarre AUTOMATIQUEMENT à l'ouverture (port 8420 donné)
#    · Plugins IA « truc maître » : Ollama (port), GLM (API), Gemini (API),
#      ou tout fournisseur compatible OpenAI
#    · Orbe de commande · Mode Deep Work · Mémoire vivante · Aether Grid (P2P)
#  Cible : Linux Mint · bash ≥ 5 · node ≥ 18 · npm ≥ 9
#  Ré-exécutable sans risque (fichiers régénérés, node_modules conservé).
#  Souverain : serveur lié à 127.0.0.1 uniquement, rien ne sort sans ta clé.
# ══════════════════════════════════════════════════════════════════════
set -euo pipefail

# ── Configuration ────────────────────────────────────────────────────
APP_TITLE="NEXUS AETHER"
APP_ID="nexus-aether"
APP_VERSION="1.0.0"
APP_DIR="${AETHER_DIR:-$HOME/Aether}"
PORT="${AETHER_PORT:-8420}"
SKIP_INSTALL="${AETHER_SKIP_INSTALL:-0}"
NO_DESKTOP="${AETHER_NO_DESKTOP:-0}"
P2P_SCRIPT="$HOME/Bureau/aether-tout-en-un.sh"
CONF_DIR="$HOME/.aether"

C_CYAN="\033[1;36m"; C_MAG="\033[1;95m"; C_GRN="\033[1;32m"; C_YLW="\033[1;33m"
C_RED="\033[1;31m"; C_DIM="\033[2m"; C_B="\033[1m"; C_RST="\033[0m"
PASS=0; FAIL=0

ok()   { echo -e "  ${C_GRN}✓${C_RST} $1"; PASS=$((PASS+1)); }
ko()   { echo -e "  ${C_RED}✗${C_RST} $1"; FAIL=$((FAIL+1)); }
info() { echo -e "  ${C_DIM}·${C_RST} $1"; }
warn() { echo -e "  ${C_YLW}!${C_RST} $1"; }
phase(){ echo; echo -e "${C_MAG}━━━ PHASE $1/8 ━━━ ${C_CYAN}${C_B}$2${C_RST}"; }
chk()  { if eval "$2" >/dev/null 2>&1; then ok "$1"; else ko "$1"; fi }

echo
echo -e "${C_MAG}${C_B}"
cat <<'BANIERE'
   ╔══════════════════════════════════════════════════════╗
   ║    N E X U S   A E T H E R   ·   B U R E A U         ║
   ║    Environnement immersif, souverain et conscient    ║
   ╚══════════════════════════════════════════════════════╝
BANIERE
echo -e "${C_RST}${C_DIM}   v$APP_VERSION · destination : $APP_DIR · port : $PORT${C_RST}"

# ════════════════════════════════════════════════════════════════════
phase 1 "Environnement"
# ════════════════════════════════════════════════════════════════════
if command -v node >/dev/null 2>&1; then ok "node $(node -v)"; else ko "node absent — installe Node 18+ puis relance"; fi
NODE_MAJOR="$(node -p 'parseInt(process.versions.node,10)' 2>/dev/null || echo 0)"
if [ "${NODE_MAJOR:-0}" -ge 18 ] 2>/dev/null; then ok "node ≥ 18 — OK"; else ko "node ≥ 18 requis (trouvé : ${NODE_MAJOR:-aucun}) — arrêt"; echo; exit 1; fi
if command -v npm >/dev/null 2>&1; then ok "npm $(npm -v)"; else ko "npm absent — installe npm puis relance"; fi
chk "git" "command -v git"
chk "curl" "command -v curl"
if [ -x /usr/bin/script ]; then ok "util-linux « script » — pty réel du terminal (aucun module natif à compiler)"
else warn "« script » absent — le terminal passera en mode dégradé (installe util-linux)"; fi
if [ "$SKIP_INSTALL" = "1" ]; then
  warn "AETHER_SKIP_INSTALL=1 → l'installation npm sera ignorée (mode test)"
elif curl -sI --max-time 10 https://registry.npmjs.org/ >/dev/null 2>&1; then
  ok "Internet joignable (registry.npmjs.org)"
else
  warn "Internet injoignable — l'étape Electron (~100 Mo) échouera si ça persiste"
fi
DISK_MB="$(df -Pm "$HOME" 2>/dev/null | tail -1 | awk '{print $4}')"
if [ "${DISK_MB:-0}" -ge 2048 ] 2>/dev/null; then ok "espace disque suffisant (${DISK_MB} Mo libres)"
else warn "espace disque faible (${DISK_MB:-?} Mo libres) — Electron + dépendances ≈ 600 Mo"; fi
if [ -f "$P2P_SCRIPT" ]; then
  ok "scaffold P2P détecté : $P2P_SCRIPT (affiché dans l'onglet Grid, JAMAIS modifié)"
else
  info "scaffold P2P absent du Bureau (l'onglet Grid le sondera en direct)"
fi

# ════════════════════════════════════════════════════════════════════
phase 2 "Génération de l'application (scaffold)"
# ════════════════════════════════════════════════════════════════════
mkdir -p "$APP_DIR"/{server,core,ui,config,assets,scripts,build}
cd "$APP_DIR"

cat > package.json <<'AE_PKG'
{
  "name": "nexus-aether",
  "productName": "NEXUS AETHER",
  "version": "1.0.0",
  "description": "Environnement de travail immersif, souverain et conscient",
  "main": "main.js",
  "private": true,
  "engines": { "node": ">=18" },
  "scripts": { "start": "electron ." },
  "dependencies": {
    "@xterm/addon-fit": "^0.10.0",
    "@xterm/xterm": "^5.5.0",
    "ws": "^8.17.1"
  },
  "devDependencies": {
    "electron": "^28.3.3"
  }
}
AE_PKG
ok "package.json — electron 28 · ws · xterm (PAS de module natif à compiler)"

cat > main.js <<'AE_MAIN'
'use strict';
// NEXUS AETHER — processus principal Electron.
// Ouvrir l'app ⇒ le serveur démarre AUTOMATIQUEMENT (port donné) PUIS la fenêtre.
const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const fs = require('fs');
const path = require('path');
const os = require('os');

app.setName('nexus-aether');

const CONF_DIR = path.join(os.homedir(), '.aether');
const PID_FILE = path.join(CONF_DIR, 'aether.pid');
const PORT = parseInt(process.env.AETHER_PORT || '8420', 10);
let win = null;

if (!app.requestSingleInstanceLock()) { app.quit(); }

app.on('second-instance', function () {
  if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); }
});

function createWindow(port) {
  win = new BrowserWindow({
    width: 1600,
    height: 940,
    minWidth: 1080,
    minHeight: 680,
    backgroundColor: '#050510',
    frame: false,
    title: 'NEXUS AETHER',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      backgroundThrottling: false
    }
  });
  win.setMenuBarVisibility(false);
  win.loadURL('http://127.0.0.1:' + port + '/?port=' + port);
  win.once('ready-to-show', function () { win.show(); });
  win.on('closed', function () { win = null; });
}

app.whenReady().then(async function () {
  const { startServer } = require('./server/core');
  try {
    const srv = await startServer(PORT);
    try {
      fs.mkdirSync(CONF_DIR, { recursive: true });
      fs.writeFileSync(PID_FILE, String(process.pid));
    } catch (e) { /* pidfile non bloquant */ }
    createWindow(srv.port);
    console.log('[nexus-aether] serveur prêt sur 127.0.0.1:' + srv.port);
  } catch (err) {
    dialog.showErrorBox('NEXUS AETHER', 'Le serveur n\u2019a pas pu démarrer :\n' + String((err && err.message) || err));
    app.quit();
  }
});

app.on('window-all-closed', function () { app.quit(); });
app.on('before-quit', function () { try { fs.unlinkSync(PID_FILE); } catch (e) {} });

ipcMain.on('win:minimize', function () { if (win) win.minimize(); });
ipcMain.on('win:maximize', function () { if (!win) return; if (win.isMaximized()) win.unmaximize(); else win.maximize(); });
ipcMain.on('win:close', function () { app.quit(); });
AE_MAIN
ok "main.js — fenêtre frameless + démarrage auto du serveur"

cat > preload.js <<'AE_PRE'
'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('aether', {
  isElectron: true,
  minimize: function () { ipcRenderer.send('win:minimize'); },
  maximize: function () { ipcRenderer.send('win:maximize'); },
  close: function () { ipcRenderer.send('win:close'); }
});
AE_PRE
ok "preload.js — pont sécurisé (contextIsolation)"

cat > server/core.js <<'AE_CORE'
'use strict';
// NEXUS AETHER — cœur serveur (HTTP + WebSocket), embarqué dans Electron.
// Démarre AUTOMATIQUEMENT à l'ouverture de l'app, sur le port donné
// (8420 par défaut). Si le port est occupé, il cherche le suivant (8421…).
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');

let WS = null;
try { WS = require('ws'); } catch (e) { WS = null; }

const { chat, loadConfig, saveConfig } = require('../core/router');
const { remember, getMemory } = require('../core/memory');

const ROOT = path.join(__dirname, '..');
const UI_DIR = path.join(ROOT, 'ui');
const HOME = os.homedir();
const APP_VERSION = '1.0.0';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon'
};
const TEXT_EXT = new Set(['js','mjs','cjs','ts','jsx','tsx','json','md','txt','sh','bash','html','htm','css','py','yml','yaml','toml','conf','ini','env','log','svg','xml','csv','sql','desktop','gitignore']);

let srvPort = 0;
let startedAt = Date.now();
let activeAi = 0;
const termSet = new Set();
let cpuLast = null;

// ── CPU % via /proc/stat (delta entre deux lectures) ─────────────────
function cpuUsage() {
  try {
    const parts = fs.readFileSync('/proc/stat', 'utf8').split('\n')[0].trim().split(/\s+/).slice(1).map(Number);
    const idle = parts[3] + (parts[4] || 0);
    const total = parts.reduce(function (a, b) { return a + b; }, 0);
    let pct = 0;
    if (cpuLast) {
      const dTotal = total - cpuLast.total;
      const dIdle = idle - cpuLast.idle;
      pct = dTotal > 0 ? Math.round((1 - dIdle / dTotal) * 100) : 0;
    }
    cpuLast = { idle: idle, total: total };
    return Math.max(0, Math.min(100, pct));
  } catch (e) { return 0; }
}

function metrics() {
  const total = os.totalmem();
  const free = os.freemem();
  return {
    cpu: cpuUsage(),
    ramUsedGb: +(((total - free) / 1073741824).toFixed(1)),
    ramTotalGb: +((total / 1073741824).toFixed(1)),
    uptimeS: Math.round((Date.now() - startedAt) / 1000),
    terminalSessions: termSet.size,
    activeAi: activeAi,
    hostname: os.hostname(),
    platform: os.platform() + '/' + os.arch(),
    node: process.version
  };
}

function json(res, obj, code) {
  res.writeHead(code || 200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}

function sendFile(res, abs) {
  fs.readFile(abs, function (err, data) {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('404'); return; }
    const ext = path.extname(abs).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(data);
  });
}

function safePath(p) {
  const real = path.resolve(String(p || ''));
  if (real === HOME || real.indexOf(HOME + path.sep) === 0) return real;
  return null;
}

// ── API fichiers (graphe + éditeur) — limité au dossier maison ───────
function apiFiles(u, res) {
  const dir = safePath(u.searchParams.get('path') || HOME);
  if (!dir) return json(res, { error: 'chemin hors de ton espace utilisateur' }, 403);
  fs.readdir(dir, { withFileTypes: true }, function (err, entries) {
    if (err) return json(res, { error: err.code || String((err && err.message) || err) }, 400);
    const dirs = []; const files = [];
    entries.forEach(function (e) {
      if (e.name.charAt(0) === '.') return;
      if (e.isDirectory()) dirs.push(e.name);
      else if (e.isFile()) files.push(e.name);
    });
    const cmp = function (a, b) { return a.localeCompare(b); };
    json(res, { path: dir, dirs: dirs.sort(cmp), files: files.sort(cmp) });
  });
}

function apiFileRead(u, res) {
  const file = safePath(u.searchParams.get('path') || '');
  if (!file) return json(res, { error: 'chemin interdit' }, 403);
  fs.stat(file, function (err, st) {
    if (err || !st.isFile()) return json(res, { error: 'fichier introuvable' }, 404);
    if (st.size > 2 * 1024 * 1024) return json(res, { error: 'fichier > 2 Mo' }, 413);
    fs.readFile(file, 'utf8', function (e2, content) {
      if (e2) return json(res, { error: 'lecture impossible (binaire ?)' }, 415);
      json(res, { path: file, ext: path.extname(file).slice(1).toLowerCase(), content: content });
    });
  });
}

function apiFileSave(data, res) {
  const file = safePath(data.path || '');
  if (!file) return json(res, { ok: false, error: 'chemin interdit' }, 403);
  const ext = path.extname(file).slice(1).toLowerCase();
  if (ext && !TEXT_EXT.has(ext)) return json(res, { ok: false, error: 'extension non éditable : .' + ext }, 415);
  const content = String(data.content == null ? '' : data.content);
  if (content.length > 5 * 1024 * 1024) return json(res, { ok: false, error: 'contenu > 5 Mo' }, 413);
  fs.writeFile(file, content, function (e) {
    if (e) return json(res, { ok: false, error: e.code || String((e && e.message) || e) }, 400);
    remember('file', 'enregistré : ' + file);
    json(res, { ok: true, path: file, bytes: Buffer.byteLength(content) });
  });
}

// ── Aether Grid : état du projet P2P ─────────────────────────────────
function apiGrid(res) {
  const p2pPath = path.join(HOME, 'Bureau', 'aether-tout-en-un.sh');
  json(res, {
    node: os.hostname(),
    platform: os.platform() + '/' + os.arch(),
    p2p: { exists: fs.existsSync(p2pPath), path: p2pPath },
    phases: [
      { id: 0, name: 'Tunnel chiffré — 2 nœuds (libp2p)', status: 'planifié' },
      { id: 1, name: 'Tâches distribuées & collecte', status: 'planifié' },
      { id: 2, name: 'Calcul hétérogène — GPU / CPU / Edge', status: 'planifié' },
      { id: 3, name: 'Preuves ZK → blockchain', status: 'planifié' }
    ]
  });
}

// ── Fichiers statiques xterm depuis node_modules ─────────────────────
const VENDOR_MAP = {
  '/vendor/xterm.css': ['@xterm', 'xterm', 'css', 'xterm.css'],
  '/vendor/xterm.js': ['@xterm', 'xterm', 'lib', 'xterm.js'],
  '/vendor/addon-fit.js': ['@xterm', 'addon-fit', 'lib', 'addon-fit.js']
};
function sendVendor(p, res) {
  const rel = VENDOR_MAP[p];
  if (!rel) { res.writeHead(404); res.end(); return; }
  sendFile(res, path.join.apply(path, [ROOT, 'node_modules'].concat(rel)));
}

// ── Routeur HTTP ─────────────────────────────────────────────────────
function handler(req, res) {
  let u;
  try { u = new URL(req.url, 'http://127.0.0.1'); } catch (e) { res.writeHead(400); res.end(); return; }
  const p = u.pathname;
  if (req.method === 'GET' || req.method === 'HEAD') {
    if (p === '/' || p === '/index.html') return sendFile(res, path.join(UI_DIR, 'index.html'));
    if (p === '/api/health') return json(res, { ok: true, app: 'NEXUS AETHER', version: APP_VERSION, port: srvPort, uptimeS: Math.round((Date.now() - startedAt) / 1000) });
    if (p === '/api/metrics') return json(res, metrics());
    if (p === '/api/files') return apiFiles(u, res);
    if (p === '/api/file') return apiFileRead(u, res);
    if (p === '/api/plugins') return json(res, loadConfig());
    if (p === '/api/memory') return json(res, { items: getMemory(100) });
    if (p === '/api/grid/status') return apiGrid(res);
    if (p.indexOf('/vendor/') === 0) return sendVendor(p, res);
    if (p.indexOf('/ui/') === 0) return sendFile(res, path.join(UI_DIR, p.slice(4)));
    if (p.indexOf('/assets/') === 0) return sendFile(res, path.join(ROOT, p.slice(1)));
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('NEXUS AETHER — 404');
    return;
  }
  if (req.method === 'POST') {
    const chunks = [];
    let size = 0;
    req.on('data', function (c) { size += c.length; if (size <= 8 * 1024 * 1024) chunks.push(c); });
    req.on('end', function () {
      handlePost(p, Buffer.concat(chunks).toString('utf8'), res).catch(function (e) {
        json(res, { ok: false, error: String((e && e.message) || e) }, 500);
      });
    });
    return;
  }
  res.writeHead(405); res.end();
}

async function handlePost(p, body, res) {
  let data = {};
  try { data = JSON.parse(body || '{}'); } catch (e) {}
  if (p === '/api/ai') {
    const msgs = (Array.isArray(data.messages) && data.messages.length)
      ? data.messages
      : [{ role: 'user', content: String(data.prompt || '') }];
    let lastUser = '';
    for (let i = msgs.length - 1; i >= 0; i--) { if (msgs[i] && msgs[i].role === 'user') { lastUser = String(msgs[i].content || ''); break; } }
    activeAi += 1;
    try {
      const out = await chat(msgs, data.provider ? { providerId: data.provider } : {});
      remember('ai', 'Q: ' + lastUser.slice(0, 500) + '\nA: ' + String(out.text).slice(0, 800));
      json(res, { ok: true, text: out.text, provider: out.provider });
    } catch (e) {
      json(res, { ok: false, error: String((e && e.message) || e) });
    } finally {
      activeAi -= 1;
    }
    return;
  }
  if (p === '/api/file') return apiFileSave(data, res);
  if (p === '/api/plugins/active') {
    const cfg = loadConfig();
    const id = String(data.id || '');
    const found = (cfg.providers || []).some(function (x) { return x.id === id; });
    if (!found) return json(res, { ok: false, error: 'fournisseur inconnu : ' + id });
    cfg.active = id;
    saveConfig(cfg);
    return json(res, { ok: true, active: id });
  }
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('404');
}

// ── VRAI terminal : pty réel via util-linux « script » ───────────────
// Aucun module natif (node-pty) ⇒ aucune compilation, aucun problème d'ABI.
// Le pty de « script » donne couleurs, Ctrl-C, vim, htop, TAB… tout.
function createTerminal(cols, rows) {
  const shell = (process.env.SHELL && fs.existsSync(process.env.SHELL)) ? process.env.SHELL : 'bash';
  let proc;
  if (fs.existsSync('/usr/bin/script')) {
    proc = spawn('/usr/bin/script', ['-qfc', shell, '/dev/null'], {
      cwd: HOME,
      env: Object.assign({}, process.env, { TERM: 'xterm-256color', COLORTERM: 'truecolor' })
    });
  } else {
    proc = spawn(shell, ['-i'], { cwd: HOME, env: process.env });
  }
  const handle = {
    proc: proc,
    write: function (d) { try { proc.stdin.write(d); } catch (e) {} },
    resize: function (c, r) { try { proc.stdin.write('stty rows ' + r + ' cols ' + c + '; clear\n'); } catch (e) {} },
    kill: function () {
      try { proc.kill('SIGHUP'); } catch (e) {}
      setTimeout(function () { try { proc.kill('SIGKILL'); } catch (e) {} }, 500);
    },
    onData: function (cb) {
      proc.stdout.on('data', function (d) { cb(d.toString()); });
      proc.stderr.on('data', function (d) { cb(d.toString()); });
    },
    onExit: function (cb) { proc.on('exit', function (code) { cb(code); }); }
  };
  setTimeout(function () { handle.resize(cols || 100, rows || 30); }, 300);
  return handle;
}

function attachWs(server) {
  if (!WS) return null;
  const wss = new WS.Server({ noServer: true });
  server.on('upgrade', function (req, socket, head) {
    let pathname = '';
    let sp = new URLSearchParams();
    try {
      const uu = new URL(req.url, 'http://127.0.0.1');
      pathname = uu.pathname; sp = uu.searchParams;
    } catch (e) { socket.destroy(); return; }
    if (pathname !== '/terminal') { socket.destroy(); return; }
    wss.handleUpgrade(req, socket, head, function (ws) {
      const cols = parseInt(sp.get('cols') || '100', 10) || 100;
      const rows = parseInt(sp.get('rows') || '30', 10) || 30;
      const term = createTerminal(cols, rows);
      termSet.add(term);
      ws.on('message', function (raw) {
        const s = raw.toString();
        if (s.length < 48 && s.charCodeAt(0) === 123) { // '{' → message de contrôle JSON
          try {
            const j = JSON.parse(s);
            if (j && Array.isArray(j.resize) && j.resize.length === 2) { term.resize(j.resize[0], j.resize[1]); return; }
          } catch (e) { /* texte normal */ }
        }
        term.write(s);
      });
      term.onData(function (d) { try { if (ws.readyState === 1) ws.send(d); } catch (e) {} });
      term.onExit(function () { try { ws.close(); } catch (e) {} termSet.delete(term); });
      ws.on('close', function () { term.kill(); termSet.delete(term); });
      ws.on('error', function () {});
    });
  });
  return wss;
}

// ── Démarrage (repli automatique sur le port suivant si occupé) ──────
function startServer(preferredPort) {
  return new Promise(function (resolve, reject) {
    let port = preferredPort;
    let tries = 0;
    const attempt = function () {
      const server = http.createServer(handler);
      const wss = attachWs(server);
      server.once('error', function (err) {
        if (err && err.code === 'EADDRINUSE' && tries < 20) {
          tries += 1; port += 1; setTimeout(attempt, 150);
        } else reject(err);
      });
      server.listen(port, '127.0.0.1', function () {
        srvPort = port;
        startedAt = Date.now();
        resolve({ port: port, server: server, wss: wss });
      });
    };
    attempt();
  });
}

module.exports = { startServer };

// Mode autonome / auto-test : node server/core.js [--smoke]
if (require.main === module) {
  const port = parseInt(process.env.AETHER_PORT || '8420', 10);
  if (process.argv.indexOf('--smoke') !== -1) {
    startServer(port).then(function (s) {
      fetch('http://127.0.0.1:' + s.port + '/api/health').then(function (r) { return r.json(); }).then(function (h) {
        if (h && h.ok) { console.log('SMOKE_OK port=' + s.port + ' version=' + h.version); process.exit(0); }
        console.log('SMOKE_FAIL health=' + JSON.stringify(h)); process.exit(1);
      }).catch(function (e) { console.log('SMOKE_FAIL ' + String((e && e.message) || e)); process.exit(1); });
    }).catch(function (e) { console.log('SMOKE_FAIL ' + String((e && e.message) || e)); process.exit(1); });
  } else {
    startServer(port).then(function (s) { console.log('[nexus-aether] cœur serveur prêt sur http://127.0.0.1:' + s.port); });
  }
}
AE_CORE
ok "server/core.js — HTTP+WS, port donné + repli auto, pty réel, API fichiers/IA/mémoire/grid"

cat > core/router.js <<'AE_ROUTER'
'use strict';
// NEXUS AETHER — routeur IA « truc maître » : branche N'IMPORTE QUELLE IA.
//  · type "port"   → service local (Ollama sur 127.0.0.1:11434)
//  · type "openai" → toute API compatible OpenAI (GLM/Z.ai, OpenAI, Mistral…)
//  · type "gemini" → Google Gemini
// Config : ~/.aether/plugins.json (créé au premier réglage) sinon celui de l'app.
const fs = require('fs');
const path = require('path');
const os = require('os');

const CONF_DIR = path.join(os.homedir(), '.aether');
const USER_FILE = path.join(CONF_DIR, 'plugins.json');
const BUNDLED_FILE = path.join(__dirname, '..', 'config', 'plugins.json');

function loadConfig() {
  try { if (fs.existsSync(USER_FILE)) return JSON.parse(fs.readFileSync(USER_FILE, 'utf8')); } catch (e) {}
  try { return JSON.parse(fs.readFileSync(BUNDLED_FILE, 'utf8')); } catch (e) {}
  return { active: '', providers: [] };
}

function saveConfig(cfg) {
  fs.mkdirSync(CONF_DIR, { recursive: true });
  fs.writeFileSync(USER_FILE, JSON.stringify(cfg, null, 2) + '\n');
}

async function readJson(res) {
  const t = await res.text();
  try { return JSON.parse(t); } catch (e) {
    throw new Error('réponse non-JSON (' + res.status + ') : ' + t.slice(0, 200));
  }
}

async function chat(messages, opts) {
  const cfg = loadConfig();
  const providers = cfg.providers || [];
  const id = (opts && opts.providerId) || cfg.active;
  const p = providers.find(function (x) { return x.id === id; }) || providers[0];
  if (!p) throw new Error('aucun fournisseur IA — configure ~/.aether/plugins.json');
  const key = p.key || (p.keyEnv ? (process.env[p.keyEnv] || '') : '');

  if (p.type === 'port') {
    // Service local (Ollama). url ex : http://127.0.0.1:11434
    let res;
    try {
      res = await fetch(p.url.replace(/\/+$/, '') + '/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: p.model, messages: messages, stream: false })
      });
    } catch (e) {
      throw new Error('service local injoignable sur ' + p.url + ' — est-il lancé ? (' + String((e && e.message) || e) + ')');
    }
    const j = await readJson(res);
    if (j.error) throw new Error('port ' + p.url + ' : ' + ((j.error && j.error.message) || j.error));
    return { text: (j.message && j.message.content) || JSON.stringify(j).slice(0, 400), provider: p.id };
  }

  if (p.type === 'gemini') {
    if (!key) throw new Error('clé Gemini absente — export ' + (p.keyEnv || 'AETHER_GEMINI_KEY') + '=…');
    const url = p.url.replace(/\/+$/, '') + '/models/' + p.model + ':generateContent?key=' + encodeURIComponent(key);
    const sys = messages.find(function (m) { return m.role === 'system'; });
    const contents = messages.filter(function (m) { return m.role !== 'system'; }).map(function (m) {
      return { role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: String(m.content) }] };
    });
    const body = { contents: contents };
    if (sys) body.systemInstruction = { parts: [{ text: String(sys.content) }] };
    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await readJson(res);
    if (j.error) throw new Error('Gemini : ' + ((j.error && j.error.message) || JSON.stringify(j.error).slice(0, 200)));
    const parts = (j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || [];
    return { text: parts.map(function (x) { return x.text || ''; }).join('') || '(réponse vide)', provider: p.id };
  }

  // type "openai" (défaut) — GLM, OpenAI, Mistral, LM Studio… toutes compatibles
  if (!p.url) throw new Error('fournisseur « ' + (p.name || p.id) + ' » : url manquante dans ~/.aether/plugins.json');
  if (!key) throw new Error('fournisseur « ' + (p.name || p.id) + ' » : clé absente — export ' + (p.keyEnv || 'AETHER_CUSTOM_KEY') + '=…');
  const res = await fetch(p.url.replace(/\/+$/, ''), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
    body: JSON.stringify({ model: p.model, messages: messages, stream: false, temperature: 0.7 })
  });
  const j = await readJson(res);
  if (j.error) throw new Error('API : ' + ((j.error && j.error.message) || JSON.stringify(j.error).slice(0, 200)));
  const txt = (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '';
  return { text: txt || '(réponse vide)', provider: p.id };
}

module.exports = { chat: chat, loadConfig: loadConfig, saveConfig: saveConfig };
AE_ROUTER
ok "core/router.js — plugin IA universel : port local (Ollama) ou API (GLM/Gemini/custom)"

cat > core/memory.js <<'AE_MEM'
'use strict';
// NEXUS AETHER — mémoire vivante : journal JSONL de tout ce qui compte.
const fs = require('fs');
const path = require('path');
const os = require('os');

const FILE = path.join(os.homedir(), '.aether', 'memory.jsonl');

function remember(kind, text) {
  try {
    fs.mkdirSync(path.dirname(FILE), { recursive: true });
    fs.appendFileSync(FILE, JSON.stringify({
      ts: new Date().toISOString(),
      kind: kind,
      text: String(text).slice(0, 4000)
    }) + '\n');
  } catch (e) { /* mémoire non bloquante */ }
}

function getMemory(n) {
  try {
    const lines = fs.readFileSync(FILE, 'utf8').trim().split('\n').filter(Boolean);
    return lines.slice(-(n || 100)).map(function (l) {
      try { return JSON.parse(l); } catch (e) { return null; }
    }).filter(Boolean);
  } catch (e) { return []; }
}

module.exports = { remember: remember, getMemory: getMemory };
AE_MEM
ok "core/memory.js — mémoire vivante (~/.aether/memory.jsonl)"

cat > ui/index.html <<'AE_HTML'
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>NEXUS AETHER</title>
<link rel="icon" href="/assets/aether.svg">
<link rel="stylesheet" href="/vendor/xterm.css">
<link rel="stylesheet" href="/ui/style.css">
</head>
<body>
<canvas id="nebula"></canvas>

<header id="topbar">
  <div class="brand"><span class="dot"></span>NEXUS&nbsp;<b>AETHER</b><span class="ver">v1.0.0</span></div>
  <div class="metrics">
    <span class="metric">CPU <b id="m-cpu">—</b></span>
    <span class="metric">RAM <b id="m-ram">—</b></span>
    <span class="metric">PORT <b id="m-port">—</b></span>
    <span class="metric">AGENTS <b id="m-agents">1</b></span>
  </div>
  <span id="chrono" class="hidden">00:00</span>
  <div class="winbtns">
    <button id="btn-deep" title="Mode Deep Work (immersion)">&#9684;</button>
    <button id="btn-min" title="Réduire">&#8722;</button>
    <button id="btn-max" title="Agrandir">&#9633;</button>
    <button id="btn-close" title="Fermer">&#10005;</button>
  </div>
</header>

<main>
  <aside id="left" class="glass">
    <h2>Graphe fichiers</h2>
    <div id="filetree" class="tree"></div>
  </aside>

  <section id="center" class="glass">
    <nav id="tabs">
      <button class="tab" data-tab="code">&#9672; Code</button>
      <button class="tab active" data-tab="term">&#9646; Terminal</button>
      <button class="tab" data-tab="grid">&#10022; Grid</button>
      <button class="tab" data-tab="memory">&#10228; Mémoire</button>
    </nav>
    <div id="panel-code" class="panel hidden">
      <div class="editor-head">
        <span id="editor-path">aucun fichier ouvert — clique le Graphe à gauche</span>
        <button id="btn-save">Enregistrer · Ctrl+S</button>
      </div>
      <textarea id="editor" spellcheck="false" placeholder="…"></textarea>
    </div>
    <div id="panel-term" class="panel"><div id="term"></div></div>
    <div id="panel-grid" class="panel hidden">
      <div class="grid-wrap">
        <h1 class="serif">Aether Grid — réseau P2P de calcul</h1>
        <p class="dim">Le projet Aether complet vit ici : le scaffold Rust (tunnel chiffré → tâches distribuées → calcul hétérogène → ZK/blockchain) reste piloté par ton script du Bureau, et cet onglet en montre l'état en direct.</p>
        <div id="phase-list"></div>
        <p class="dim">Nœud local&nbsp;: <code id="grid-node">…</code></p>
        <p class="dim">Script P2P&nbsp;: <code id="p2p-path">…</code></p>
      </div>
    </div>
    <div id="panel-memory" class="panel hidden"><div id="memlist" class="memlist"></div></div>
  </section>

  <aside id="right" class="glass">
    <h2>Agents</h2>
    <div class="provider-row">
      <label for="provider">IA maître</label>
      <select id="provider"></select>
    </div>
    <div id="timeline"></div>
  </aside>
</main>

<footer id="orbbar">
  <div id="orb" class="orb"></div>
  <input id="orbinput" type="text" autocomplete="off" spellcheck="false"
         placeholder="Orbe — parle à Aether&#8239;: !cmd → terminal · /help · sinon l'IA répond">
</footer>

<script src="/vendor/xterm.js"></script>
<script src="/vendor/addon-fit.js"></script>
<script src="/ui/nebula.js"></script>
<script src="/ui/terminal.js"></script>
<script src="/ui/app.js"></script>
</body>
</html>
AE_HTML
ok "ui/index.html — canvas nébuleuse, graphe, onglets, orbe, panneau agents"

cat > ui/style.css <<'AE_CSS'
/* ═══════════════════════════════════════════════════════════════
   NEXUS AETHER — identité visuelle au-delà des géants
   Nébuleuse WebGL derrière verre dépoli · cyan / magenta / vert néon
   ═══════════════════════════════════════════════════════════════ */
:root{
  --bg:#050510;
  --cyan:#00E5FF;
  --magenta:#FF00C8;
  --green:#00FF88;
  --txt:#E8ECFF;
  --dim:#8A90B8;
  --glass:rgba(12,14,28,.46);
  --glass-brd:rgba(255,255,255,.07);
  --sans:'Inter','Space Grotesk','Ubuntu',system-ui,sans-serif;
  --mono:'JetBrains Mono','Fira Code','DejaVu Sans Mono',monospace;
  --serif:'Playfair Display','Georgia',serif;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;overflow:hidden}
body{background:var(--bg);color:var(--txt);font-family:var(--sans);font-size:13px}
::selection{background:rgba(0,229,255,.3)}
::-webkit-scrollbar{width:8px;height:8px}
::-webkit-scrollbar-thumb{background:rgba(255,255,255,.12);border-radius:4px}
::-webkit-scrollbar-track{background:transparent}

#nebula{position:fixed;inset:0;z-index:0;transition:opacity 1s}

.glass{
  background:var(--glass);
  -webkit-backdrop-filter:blur(40px) saturate(150%);
  backdrop-filter:blur(40px) saturate(150%);
  border-radius:16px;
  box-shadow:0 24px 60px rgba(0,0,0,.5),inset 0 0 0 1px var(--glass-brd);
}
.hidden{display:none!important}

/* ── Barre de statut : titre + métriques + fenêtre ──*/
#topbar{
  position:fixed;top:0;left:0;right:0;height:38px;z-index:20;
  display:flex;align-items:center;gap:18px;padding:0 10px 0 14px;
  background:rgba(5,5,16,.55);
  -webkit-backdrop-filter:blur(24px);backdrop-filter:blur(24px);
  border-bottom:1px solid rgba(255,255,255,.05);
  -webkit-app-region:drag;user-select:none;
}
#topbar .brand{display:flex;align-items:center;gap:8px;font-size:13px;letter-spacing:2px;color:var(--dim)}
#topbar .brand b{color:var(--txt);font-weight:700}
#topbar .dot{width:9px;height:9px;border-radius:50%;background:var(--cyan);box-shadow:0 0 10px var(--cyan)}
#topbar .ver{font-family:var(--mono);font-size:10px;color:var(--dim);margin-left:2px}
.metrics{display:flex;gap:14px;margin-left:auto}
.metric{font-size:10px;letter-spacing:1.5px;color:var(--dim)}
.metric b{font-family:var(--mono);font-size:11px;color:var(--cyan);margin-left:4px}
#chrono{font-family:var(--mono);font-size:12px;color:var(--green);text-shadow:0 0 8px rgba(0,255,136,.6)}
.winbtns{display:flex;gap:6px;-webkit-app-region:no-drag}
.winbtns button{
  width:26px;height:26px;border:none;border-radius:8px;cursor:pointer;
  background:rgba(255,255,255,.05);color:var(--dim);font-size:12px;line-height:1;
  transition:all .15s;
}
.winbtns button:hover{background:rgba(0,229,255,.15);color:var(--cyan)}
.winbtns #btn-close:hover{background:rgba(255,60,90,.2);color:#FF5C7A}
.winbtns #btn-deep.on{background:rgba(0,255,136,.15);color:var(--green)}

/* ── Zone principale ──*/
main{position:fixed;top:48px;bottom:74px;left:10px;right:10px;display:grid;grid-template-columns:262px 1fr 318px;gap:10px;z-index:5}
#left,#right{padding:12px;overflow:auto}
#left h2,#right h2{font-size:10px;letter-spacing:3px;text-transform:uppercase;color:var(--dim);margin-bottom:10px}

/* ── Graphe fichiers ──*/
.tnode{padding:3px 6px;border-radius:6px;cursor:pointer;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tnode:hover{background:rgba(0,229,255,.08)}
.tnode.dir{color:#9fd8ff}
.tnode.file{color:var(--dim)}
.tkids{margin-left:12px;border-left:1px solid rgba(0,229,255,.12);padding-left:4px}

/* ── Centre : onglets + panneaux ──*/
#center{display:flex;flex-direction:column;overflow:hidden}
#tabs{display:flex;gap:6px;padding:10px 10px 0}
.tab{
  border:1px solid transparent;background:transparent;color:var(--dim);
  padding:6px 14px;border-radius:10px 10px 0 0;cursor:pointer;font-size:12px;letter-spacing:1px;
}
.tab:hover{color:var(--txt)}
.tab.active{
  color:var(--cyan);background:rgba(0,229,255,.07);
  border-color:rgba(0,229,255,.25);border-bottom-color:transparent;
  text-shadow:0 0 12px rgba(0,229,255,.5);
}
.panel{flex:1;min-height:0;display:flex;flex-direction:column;padding:10px}
.panel.hidden{display:none!important}

/* éditeur */
.editor-head{display:flex;align-items:center;gap:10px;margin-bottom:8px}
#editor-path{font-family:var(--mono);font-size:11px;color:var(--dim);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#btn-save{border:1px solid rgba(0,229,255,.35);background:rgba(0,229,255,.08);color:var(--cyan);padding:5px 12px;border-radius:8px;cursor:pointer;font-size:11px}
#btn-save:hover{background:rgba(0,229,255,.18)}
#editor{
  flex:1;min-height:0;resize:none;border:none;outline:none;border-radius:10px;
  background:rgba(0,0,0,.28);color:var(--txt);
  font-family:var(--mono);font-size:12.5px;line-height:1.5;padding:12px;
}

/* terminal */
#term{flex:1;min-height:0}
#term .xterm{height:100%}
.term-miss{padding:14px;color:var(--dim)}

/* grid */
.grid-wrap{overflow:auto;padding:6px 4px}
.serif{font-family:var(--serif);font-size:21px;font-weight:500;margin-bottom:10px;color:#ffffff}
.dim{color:var(--dim);margin-bottom:10px;line-height:1.5}
.dim code{font-family:var(--mono);font-size:11px;color:#9fd8ff;word-break:break-all}
.phase-card{
  display:flex;align-items:center;justify-content:space-between;gap:10px;
  background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.06);
  border-radius:12px;padding:10px 14px;margin-bottom:8px;
}
.phase-card b{color:var(--cyan)}
.badge{font-size:9px;letter-spacing:2px;color:var(--green);border:1px solid rgba(0,255,136,.35);padding:3px 8px;border-radius:20px;text-transform:uppercase}

/* mémoire */
.memlist{overflow:auto}
.mem{margin-bottom:10px;background:rgba(255,255,255,.03);border-radius:10px;padding:8px 10px}
.mem-t{font-family:var(--mono);font-size:9.5px;color:var(--dim);letter-spacing:1px}
.mem-b{font-family:var(--mono);font-size:11.5px;white-space:pre-wrap;word-break:break-word;margin-top:4px;color:#c9cff2}

/* ── Panneau agents ──*/
.provider-row{display:flex;flex-direction:column;gap:4px;margin-bottom:12px}
.provider-row label{font-size:10px;letter-spacing:2px;color:var(--dim);text-transform:uppercase}
#provider{
  background:rgba(0,0,0,.3);color:var(--txt);border:1px solid rgba(0,229,255,.25);
  border-radius:8px;padding:7px 8px;font-size:12px;outline:none;
}
#provider:focus{border-color:var(--cyan)}
#timeline{overflow:auto;flex:1;min-height:0}
.ev{margin-bottom:10px}
.ev-t{display:block;font-family:var(--mono);font-size:9.5px;color:var(--dim);letter-spacing:1px;margin-bottom:3px}
.ev-b{
  white-space:pre-wrap;word-break:break-word;font-size:12px;line-height:1.5;
  background:rgba(255,255,255,.04);border-radius:10px;padding:8px 10px;color:#c9cff2;
}
.ev.user .ev-b{border-left:2px solid var(--cyan)}
.ev.ai .ev-b{border-left:2px solid var(--magenta)}
.ev.cmd .ev-b{border-left:2px solid var(--green);font-family:var(--mono);font-size:11.5px}
.ev.err .ev-b{border-left:2px solid #FF5C7A;color:#ffb3c2}
.ev.sys .ev-b{border-left:2px solid rgba(255,255,255,.2);color:var(--dim)}
.ev.file .ev-b{border-left:2px solid #9fd8ff}

/* ── Orbe ──*/
#orbbar{position:fixed;left:0;right:0;bottom:10px;height:56px;display:flex;align-items:center;justify-content:center;gap:14px;z-index:20}
.orb{
  width:22px;height:22px;border-radius:50%;flex:none;
  background:radial-gradient(circle at 32% 30%,#a8fbff 0%,var(--cyan) 45%,#0039c8 100%);
  box-shadow:0 0 18px rgba(0,229,255,.75),0 0 46px rgba(0,229,255,.3);
}
body.thinking .orb{animation:orbPulse 1s ease-in-out infinite}
@keyframes orbPulse{
  0%,100%{transform:scale(1);box-shadow:0 0 14px rgba(0,229,255,.7),0 0 40px rgba(0,229,255,.25)}
  50%{transform:scale(1.3);box-shadow:0 0 30px rgba(255,0,200,.9),0 0 70px rgba(255,0,200,.4)}
}
#orbinput{
  width:min(660px,72vw);height:42px;border-radius:21px;outline:none;
  border:1px solid rgba(0,229,255,.22);
  background:rgba(8,10,24,.72);
  -webkit-backdrop-filter:blur(30px);backdrop-filter:blur(30px);
  color:var(--txt);font-family:var(--mono);font-size:13px;padding:0 18px;
  transition:border-color .25s,box-shadow .25s;
}
#orbinput::placeholder{color:var(--dim)}
#orbinput:focus{border-color:var(--cyan);box-shadow:0 0 0 1px rgba(0,229,255,.35),0 0 34px rgba(0,229,255,.22)}

/* ── Mode Deep Work ──*/
body.deep #left,body.deep #right{display:none}
body.deep main{grid-template-columns:1fr}
body.deep #nebula{opacity:.25}
AE_CSS
ok "ui/style.css — Glassmorphism 2.0 (blur 40px) · palette #00E5FF/#FF00C8/#00FF88"

cat > ui/nebula.js <<'AE_NEB'
(function () {
  'use strict';
  // NEXUS AETHER — nébuleuse vivante : shader WebGL (fbm + warp de domaine),
  // réagit à l'activité système (u_act) et à la souris. Repli 2D si pas de WebGL.
  const canvas = document.getElementById('nebula');
  if (!canvas) return;
  window.__aetherActivity = 0.2;

  let gl = null;
  try { gl = canvas.getContext('webgl', { antialias: false, alpha: false, depth: false }); } catch (e) { gl = null; }
  if (gl) initWebGL(gl); else init2d();

  function initWebGL(gl) {
    const VS = 'attribute vec2 p;void main(){gl_Position=vec4(p,0.0,1.0);}';
    const FS = [
      'precision highp float;',
      'uniform vec2 u_res;',
      'uniform float u_time;',
      'uniform float u_act;',
      'uniform vec2 u_mouse;',
      'float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453123);}',
      'float noise(vec2 p){vec2 i=floor(p);vec2 f=fract(p);vec2 u=f*f*(3.0-2.0*f);',
      '  return mix(mix(hash(i),hash(i+vec2(1.0,0.0)),u.x),mix(hash(i+vec2(0.0,1.0)),hash(i+vec2(1.0,1.0)),u.x),u.y);}',
      'float fbm(vec2 p){float v=0.0;float a=0.5;for(int k=0;k<5;k++){v+=a*noise(p);p=p*2.03+vec2(1.7,9.2);a*=0.5;}return v;}',
      'void main(){',
      '  vec2 uv=(gl_FragCoord.xy*2.0-u_res)/min(u_res.x,u_res.y);',
      '  float t=u_time*(0.04+u_act*0.10);',
      '  vec2 m=u_mouse*0.3;',
      '  vec2 q=vec2(fbm(uv*1.3+t),fbm(uv*1.3-t*0.7+5.2));',
      '  vec2 r=vec2(fbm(uv*1.7+q*1.8+m+vec2(1.7,9.2)+t*0.4),fbm(uv*1.7+q*1.8+vec2(8.3,2.8)-t*0.3));',
      '  float f=fbm(uv*2.1+r*1.6);',
      '  vec3 deep=vec3(0.016,0.02,0.075);',
      '  vec3 violet=vec3(0.16,0.05,0.32);',
      '  vec3 cyan=vec3(0.0,0.9,1.0);',
      '  vec3 magenta=vec3(1.0,0.0,0.78);',
      '  vec3 col=deep;',
      '  col=mix(col,violet,clamp(f*f*1.9,0.0,1.0));',
      '  col=mix(col,cyan*0.5,clamp(pow(max(r.x,0.0),3.0)*(0.35+u_act*0.6),0.0,0.6));',
      '  col=mix(col,magenta*0.45,clamp(pow(max(r.y,0.0),4.0)*0.9,0.0,0.5));',
      '  col+=cyan*pow(clamp(f-0.70,0.0,1.0)*2.4,2.0)*(0.35+u_act*0.5);',
      '  float vig=smoothstep(1.9,0.3,length(uv));',
      '  col*=mix(0.5,1.0,vig);',
      '  gl_FragColor=vec4(col,1.0);',
      '}'
    ].join('\n');
    function sh(type, src) {
      const s = gl.createShader(type);
      gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) || 'shader');
      return s;
    }
    let prog;
    try {
      prog = gl.createProgram();
      gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS));
      gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FS));
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error('link');
    } catch (e) { init2d(); return; }
    gl.useProgram(prog);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, 'p');
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    const uRes = gl.getUniformLocation(prog, 'u_res');
    const uTime = gl.getUniformLocation(prog, 'u_time');
    const uAct = gl.getUniformLocation(prog, 'u_act');
    const uMouse = gl.getUniformLocation(prog, 'u_mouse');
    let mx = 0, my = 0;
    window.addEventListener('mousemove', function (e) {
      mx = (e.clientX / window.innerWidth - 0.5) * 2;
      my = (e.clientY / window.innerHeight - 0.5) * 2;
    });
    function resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = Math.max(1, Math.floor(window.innerWidth * dpr));
      canvas.height = Math.max(1, Math.floor(window.innerHeight * dpr));
      gl.viewport(0, 0, canvas.width, canvas.height);
    }
    resize();
    window.addEventListener('resize', resize);
    const t0 = Date.now();
    (function frame() {
      gl.uniform2f(uRes, canvas.width, canvas.height);
      gl.uniform1f(uTime, (Date.now() - t0) / 1000);
      gl.uniform1f(uAct, window.__aetherActivity || 0.2);
      gl.uniform2f(uMouse, mx, my);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      requestAnimationFrame(frame);
    })();
  }

  function init2d() {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const blobs = [
      { c: 'rgba(0,229,255,0.20)', r: 0.5, x: 0.3, y: 0.35, dx: 0.00007, dy: 0.00005 },
      { c: 'rgba(255,0,200,0.16)', r: 0.45, x: 0.7, y: 0.5, dx: -0.00006, dy: 0.00007 },
      { c: 'rgba(90,60,255,0.18)', r: 0.6, x: 0.5, y: 0.75, dx: 0.00005, dy: -0.00006 }
    ];
    function resize() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
    resize();
    window.addEventListener('resize', resize);
    (function frame() {
      ctx.fillStyle = '#050510';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      blobs.forEach(function (b) {
        b.x += b.dx; b.y += b.dy;
        if (b.x < 0.1 || b.x > 0.9) b.dx *= -1;
        if (b.y < 0.1 || b.y > 0.9) b.dy *= -1;
        const rr = b.r * Math.min(canvas.width, canvas.height);
        const g = ctx.createRadialGradient(b.x * canvas.width, b.y * canvas.height, 0, b.x * canvas.width, b.y * canvas.height, rr);
        g.addColorStop(0, b.c);
        g.addColorStop(1, 'rgba(5,5,16,0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      });
      requestAnimationFrame(frame);
    })();
  }
})();
AE_NEB
ok "ui/nebula.js — shader WebGL fbm, réagit CPU + souris (repli 2D automatique)"

cat > ui/terminal.js <<'AE_TERM'
(function () {
  'use strict';
  // NEXUS AETHER — vrai terminal : xterm.js ⇄ WebSocket ⇄ pty réel côté serveur.
  window.AetherTerm = { ready: false, ws: null, term: null, fit: null, run: function () {} };
  const el = document.getElementById('term');
  if (!el) return;
  if (!window.Terminal) {
    el.innerHTML = '<p class="term-miss">xterm.js non chargé — relance « npm install » dans le dossier de l\u2019app.</p>';
    return;
  }
  const term = new window.Terminal({
    fontFamily: "'JetBrains Mono','Fira Code','DejaVu Sans Mono',monospace",
    fontSize: 13,
    lineHeight: 1.15,
    cursorBlink: true,
    allowTransparency: true,
    scrollback: 5000,
    theme: {
      background: 'rgba(4,4,12,0.35)',
      foreground: '#E8ECFF',
      cursor: '#00E5FF',
      cursorAccent: '#050510',
      selectionBackground: 'rgba(0,229,255,0.28)',
      black: '#101020', red: '#FF5C7A', green: '#00FF88', yellow: '#FFD166',
      blue: '#4DA6FF', magenta: '#FF00C8', cyan: '#00E5FF', white: '#E8ECFF'
    }
  });
  const fit = new window.FitAddon.FitAddon();
  term.loadAddon(fit);
  term.open(el);
  try { fit.fit(); } catch (e) {}

  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const ws = new WebSocket(proto + '://' + location.host + '/terminal?cols=' + term.cols + '&rows=' + term.rows);
  ws.onopen = function () { window.AetherTerm.ready = true; term.focus(); };
  ws.onmessage = function (ev) { term.write(ev.data); };
  ws.onclose = function () {
    window.AetherTerm.ready = false;
    term.write('\r\n\x1b[38;5;245m[session terminal fermée — relance l\u2019app]\x1b[0m\r\n');
  };
  ws.onerror = function () {};
  term.onData(function (d) { if (ws.readyState === 1) ws.send(d); });
  term.onResize(function (sz) { if (ws.readyState === 1) ws.send(JSON.stringify({ resize: [sz.cols, sz.rows] })); });
  window.addEventListener('resize', function () { try { fit.fit(); } catch (e) {} });
  window.addEventListener('tab-shown-term', function () {
    setTimeout(function () { try { fit.fit(); term.focus(); } catch (e) {} }, 30);
  });

  window.AetherTerm.term = term;
  window.AetherTerm.fit = fit;
  window.AetherTerm.ws = ws;
  window.AetherTerm.run = function (cmd) { if (ws.readyState === 1) ws.send(cmd + '\n'); };
})();
AE_TERM
ok "ui/terminal.js — xterm.js branché au pty réel via WebSocket"

cat > ui/app.js <<'AE_APP'
(function () {
  'use strict';
  // NEXUS AETHER — orchestration : orbe, onglets, métriques, graphe,
  // éditeur, agents, mémoire vivante, Grid, Deep Work.
  const $ = function (id) { return document.getElementById(id); };
  const desk = window.aether || null;

  /* ── Fenêtre (Electron) ──*/
  $('btn-min').addEventListener('click', function () { if (desk) desk.minimize(); });
  $('btn-max').addEventListener('click', function () { if (desk) desk.maximize(); });
  $('btn-close').addEventListener('click', function () { if (desk) desk.close(); });

  /* ── Onglets ──*/
  const TABS = ['code', 'term', 'grid', 'memory'];
  const tabBtns = Array.prototype.slice.call(document.querySelectorAll('#tabs .tab'));
  tabBtns.forEach(function (b) { b.addEventListener('click', function () { switchTab(b.dataset.tab); }); });
  function switchTab(name) {
    tabBtns.forEach(function (b) { b.classList.toggle('active', b.dataset.tab === name); });
    TABS.forEach(function (t) { const el = $('panel-' + t); if (el) el.classList.toggle('hidden', t !== name); });
    if (name === 'term') window.dispatchEvent(new Event('tab-shown-term'));
    if (name === 'memory') loadMemory();
    if (name === 'grid') loadGrid();
  }

  /* ── Métriques temps réel (barre du haut + activité nébuleuse) ──*/
  const qs = new URLSearchParams(location.search);
  const PORT = qs.get('port') || location.port || '8420';
  $('m-port').textContent = PORT;
  async function pollMetrics() {
    try {
      const m = await (await fetch('/api/metrics')).json();
      $('m-cpu').textContent = m.cpu + '%';
      $('m-ram').textContent = m.ramUsedGb + '/' + m.ramTotalGb + 'G';
      $('m-agents').textContent = String(1 + m.terminalSessions + m.activeAi);
      window.__aetherActivity = Math.max(0.08, Math.min(1, m.cpu / 100));
    } catch (e) { /* serveur momentanément absent */ }
  }
  pollMetrics();
  setInterval(pollMetrics, 2000);

  /* ── Timeline agents ──*/
  function kindLabel(k) {
    return { user: 'toi', ai: 'Aether', cmd: 'terminal', sys: 'système', err: 'erreur', file: 'fichier' }[k] || k;
  }
  function event(kind, text) {
    const tl = $('timeline');
    const d = document.createElement('div');
    d.className = 'ev ' + kind;
    const t = new Date().toLocaleTimeString('fr-FR', { hour12: false });
    const head = document.createElement('span');
    head.className = 'ev-t';
    head.textContent = t + ' · ' + kindLabel(kind);
    const body = document.createElement('div');
    body.className = 'ev-b';
    body.textContent = text;
    d.appendChild(head); d.appendChild(body);
    tl.insertBefore(d, tl.firstChild);
  }

  /* ── Graphe fichiers ──*/
  function pjoin(a, b) { return a.replace(/\/+$/, '') + '/' + b; }
  async function fillTree(container, dirPath) {
    let j;
    try { j = await (await fetch('/api/files?path=' + encodeURIComponent(dirPath))).json(); }
    catch (e) { container.textContent = '⚠ serveur injoignable'; return; }
    if (j.error) { container.textContent = '⚠ ' + j.error; return; }
    j.dirs.forEach(function (n) { container.appendChild(makeNode(n, pjoin(dirPath || j.path, n), true)); });
    j.files.forEach(function (n) { container.appendChild(makeNode(n, pjoin(dirPath || j.path, n), false)); });
  }
  function makeNode(name, full, isDir) {
    const wrap = document.createElement('div'); wrap.className = 'tnode-wrap';
    const row = document.createElement('div'); row.className = 'tnode ' + (isDir ? 'dir' : 'file');
    row.textContent = (isDir ? '▸ ' : '· ') + name;
    row.title = full;
    const kids = document.createElement('div'); kids.className = 'tkids hidden';
    wrap.appendChild(row); wrap.appendChild(kids);
    row.addEventListener('click', async function () {
      if (!isDir) return openFile(full);
      if (kids.classList.contains('hidden')) {
        kids.classList.remove('hidden');
        row.textContent = '▾ ' + name;
        if (!kids.dataset.loaded) { kids.dataset.loaded = '1'; await fillTree(kids, full); }
      } else {
        kids.classList.add('hidden');
        row.textContent = '▸ ' + name;
      }
    });
    return wrap;
  }
  fillTree($('filetree'), '');

  /* ── Éditeur de code ──*/
  let openPath = null;
  const editor = $('editor');
  async function openFile(p) {
    try {
      const j = await (await fetch('/api/file?path=' + encodeURIComponent(p))).json();
      if (j.error) { event('err', 'lecture : ' + j.error); return; }
      openPath = j.path;
      editor.value = j.content;
      $('editor-path').textContent = j.path;
      switchTab('code');
      event('file', 'ouvert : ' + j.path);
    } catch (e) { event('err', String((e && e.message) || e)); }
  }
  $('btn-save').addEventListener('click', async function () {
    if (!openPath) { event('err', 'aucun fichier ouvert'); return; }
    try {
      const r = await (await fetch('/api/file', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: openPath, content: editor.value })
      })).json();
      if (r.ok) event('file', 'enregistré : ' + r.path + ' (' + r.bytes + ' o)');
      else event('err', 'enregistrement : ' + (r.error || '?'));
    } catch (e) { event('err', String((e && e.message) || e)); }
  });
  editor.addEventListener('keydown', function (e) {
    if (e.key === 'Tab') {
      e.preventDefault();
      editor.setRangeText('  ', editor.selectionStart, editor.selectionEnd, 'end');
    }
  });
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); $('btn-save').click(); }
  });

  /* ── Fournisseurs IA (le « truc maître ») ──*/
  async function loadProviders() {
    try {
      const cfg = await (await fetch('/api/plugins')).json();
      const sel = $('provider');
      sel.innerHTML = '';
      (cfg.providers || []).forEach(function (p) {
        const o = document.createElement('option');
        o.value = p.id; o.textContent = p.name;
        if (p.id === cfg.active) o.selected = true;
        sel.appendChild(o);
      });
      sel.onchange = async function () {
        try {
          await fetch('/api/plugins/active', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: sel.value })
          });
          event('sys', 'IA maître → ' + sel.value);
        } catch (e) { event('err', String((e && e.message) || e)); }
      };
    } catch (e) { /* ignore */ }
  }
  loadProviders();

  /* ── Mémoire vivante ──*/
  async function loadMemory() {
    const box = $('memlist');
    box.innerHTML = '';
    try {
      const j = await (await fetch('/api/memory')).json();
      const items = j.items || [];
      if (!items.length) {
        box.innerHTML = '<p class="dim">Mémoire vide — chaque échange IA et chaque fichier enregistré s\u2019y inscrira.</p>';
        return;
      }
      items.slice().reverse().forEach(function (it) {
        const d = document.createElement('div'); d.className = 'mem';
        const t = document.createElement('span'); t.className = 'mem-t';
        t.textContent = (it.ts || '').replace('T', ' ').slice(0, 19) + ' · ' + it.kind;
        const b = document.createElement('div'); b.className = 'mem-b'; b.textContent = it.text;
        d.appendChild(t); d.appendChild(b);
        box.appendChild(d);
      });
    } catch (e) { box.innerHTML = '<p class="dim">⚠ ' + String((e && e.message) || e) + '</p>'; }
  }

  /* ── Aether Grid ──*/
  async function loadGrid() {
    try {
      const g = await (await fetch('/api/grid/status')).json();
      $('grid-node').textContent = g.node + ' · ' + g.platform;
      $('p2p-path').textContent = (g.p2p.exists ? '✓ détecté : ' : '✗ introuvable : ') + g.p2p.path;
      const box = $('phase-list');
      box.innerHTML = '';
      (g.phases || []).forEach(function (ph) {
        const card = document.createElement('div'); card.className = 'phase-card';
        const t = document.createElement('div');
        const b = document.createElement('b'); b.textContent = 'Phase ' + ph.id;
        t.appendChild(b);
        t.appendChild(document.createTextNode(' — ' + ph.name));
        const badge = document.createElement('span'); badge.className = 'badge'; badge.textContent = ph.status;
        card.appendChild(t); card.appendChild(badge);
        box.appendChild(card);
      });
    } catch (e) { /* ignore */ }
  }

  /* ── Mode Deep Work ──*/
  let deep = false, chronoInt = null, t0 = 0;
  function tickChrono() {
    const s = Math.floor((Date.now() - t0) / 1000);
    $('chrono').textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  }
  $('btn-deep').addEventListener('click', function () {
    deep = !deep;
    document.body.classList.toggle('deep', deep);
    $('btn-deep').classList.toggle('on', deep);
    if (deep) {
      t0 = Date.now(); tickChrono();
      $('chrono').classList.remove('hidden');
      chronoInt = setInterval(tickChrono, 1000);
      event('sys', 'Mode Deep Work — nébuleuse ralentie, panneaux escamotés.');
    } else {
      clearInterval(chronoInt);
      $('chrono').classList.add('hidden');
      event('sys', 'Deep Work terminé.');
    }
  });

  /* ── Orbe ──*/
  const input = $('orbinput');
  const thread = [{
    role: 'system',
    content: 'Tu es Aether, l\u2019agent central de l\u2019environnement NEXUS AETHER. Tu réponds en français, de façon directe et utile. Tout tourne en local ou via les API configurées par l\u2019utilisateur.'
  }];
  const history = [];
  let hi = 0, busy = false;

  input.addEventListener('keydown', async function (e) {
    if (e.key === 'ArrowUp' && history.length) {
      if (hi > 0) hi--;
      input.value = history[hi] || '';
      e.preventDefault(); return;
    }
    if (e.key === 'ArrowDown') {
      if (hi < history.length) hi++;
      input.value = history[hi] || '';
      e.preventDefault(); return;
    }
    if (e.key !== 'Enter' || busy) return;
    const text = input.value.trim();
    if (!text) return;
    input.value = '';
    history.push(text); hi = history.length;

    if (text.charAt(0) === '!' || text.indexOf('run ') === 0) {
      const cmd = text.charAt(0) === '!' ? text.slice(1) : text.slice(4);
      switchTab('term');
      if (window.AetherTerm && window.AetherTerm.ready) { window.AetherTerm.run(cmd); event('cmd', cmd); }
      else event('err', 'terminal pas encore prêt — réessaie dans une seconde');
      return;
    }
    if (text.charAt(0) === '/') { localCmd(text); return; }
    await askAi(text);
  });

  async function askAi(text) {
    busy = true;
    document.body.classList.add('thinking');
    event('user', text);
    thread.push({ role: 'user', content: text });
    while (thread.length > 13) thread.splice(1, 1);
    try {
      const r = await fetch('/api/ai', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: thread.slice() })
      });
      const j = await r.json();
      if (j.ok) { thread.push({ role: 'assistant', content: j.text }); event('ai', j.text); }
      else event('err', j.error || 'erreur IA inconnue');
    } catch (e2) { event('err', String((e2 && e2.message) || e2)); }
    busy = false;
    document.body.classList.remove('thinking');
  }

  function localCmd(t) {
    const parts = t.slice(1).trim().split(/\s+/);
    const cmd = (parts[0] || '').toLowerCase();
    const arg = parts.slice(1).join(' ');
    if (cmd === 'help') {
      event('sys', 'Commandes — !cmd : exécute dans le terminal · /help · /ai list · /ai use <id> · /plugins · /deep · /clear · /grid · /memory · texte libre : l\u2019IA maître répond');
      return;
    }
    if (cmd === 'ai') {
      if (arg.indexOf('use') === 0) {
        const id = arg.slice(3).trim();
        fetch('/api/plugins/active', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: id })
        }).then(function (r) { return r.json(); }).then(function (j) {
          event(j.ok ? 'sys' : 'err', j.ok ? 'IA maître → ' + j.active : (j.error || 'fournisseur inconnu'));
          loadProviders();
        }).catch(function (e) { event('err', String((e && e.message) || e)); });
      } else {
        fetch('/api/plugins').then(function (r) { return r.json(); }).then(function (cfg) {
          const lines = (cfg.providers || []).map(function (p) {
            return (p.id === cfg.active ? '▸ ' : '  ') + p.id + ' — ' + p.name;
          }).join('\n');
          event('sys', 'Fournisseurs IA (actif marqué ▸) :\n' + lines + '\n→ /ai use <id>');
        }).catch(function (e) { event('err', String((e && e.message) || e)); });
      }
      return;
    }
    if (cmd === 'plugins') {
      fetch('/api/plugins').then(function (r) { return r.json(); }).then(function (cfg) {
        event('sys', 'Config : ~/.aether/plugins.json — actif : ' + cfg.active);
      });
      return;
    }
    if (cmd === 'deep') { $('btn-deep').click(); return; }
    if (cmd === 'clear') { $('timeline').innerHTML = ''; return; }
    if (cmd === 'grid') { switchTab('grid'); return; }
    if (cmd === 'memory') { switchTab('memory'); return; }
    event('sys', 'Commande inconnue — /help liste tout');
  }

  event('sys', 'NEXUS AETHER en ligne — port ' + PORT + '. L\u2019orbe t\u2019écoute : /help pour les commandes.');
})();
AE_APP
ok "ui/app.js — orbe (intention !cmd // /commandes // IA), graphe, éditeur, agents, Deep Work"

cat > config/plugins.json <<'AE_PLG'
{
  "active": "ollama-local",
  "providers": [
    { "id": "ollama-local", "name": "Ollama (local · souverain)", "type": "port", "url": "http://127.0.0.1:11434", "model": "llama3" },
    { "id": "glm", "name": "GLM · Z.ai (API)", "type": "openai", "url": "https://open.bigmodel.cn/api/paas/v4/chat/completions", "model": "glm-4-flash", "keyEnv": "AETHER_GLM_KEY" },
    { "id": "gemini", "name": "Google Gemini (API)", "type": "gemini", "url": "https://generativelanguage.googleapis.com/v1beta", "model": "gemini-1.5-flash", "keyEnv": "AETHER_GEMINI_KEY" },
    { "id": "openai-compat", "name": "Compatible OpenAI (tout fournisseur)", "type": "openai", "url": "", "model": "", "keyEnv": "AETHER_CUSTOM_KEY" }
  ]
}
AE_PLG
ok "config/plugins.json — Ollama (port) · GLM · Gemini · custom (API)"

cat > assets/aether.svg <<'AE_SVG'
<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128">
  <defs>
    <radialGradient id="g" cx="35%" cy="35%" r="75%">
      <stop offset="0%" stop-color="#a8fbff"/>
      <stop offset="45%" stop-color="#00E5FF"/>
      <stop offset="100%" stop-color="#0a1a8c"/>
    </radialGradient>
  </defs>
  <rect width="128" height="128" rx="28" fill="#050510"/>
  <circle cx="64" cy="64" r="30" fill="url(#g)"/>
  <ellipse cx="64" cy="64" rx="52" ry="18" fill="none" stroke="#FF00C8" stroke-width="3" transform="rotate(-18 64 64)" opacity=".85"/>
  <ellipse cx="64" cy="64" rx="52" ry="18" fill="none" stroke="#00E5FF" stroke-width="2.5" transform="rotate(24 64 64)" opacity=".7"/>
</svg>
AE_SVG
ok "assets/aether.svg — icône orbe + anneaux (identité Aether)"

cat > README.md <<'AE_README'
# NEXUS AETHER — v1.0.0
Environnement de travail immersif, souverain et conscient.

## Lancer
- Menu des applications → **NEXUS AETHER**
- ou double-clic sur l'icône du Bureau
- ou `~/Aether/scripts/aether-launch.sh`

## Port
Le serveur démarre automatiquement à l'ouverture, sur le port **8420**
(s'il est occupé : 8421, 8422…). Pour changer :
`AETHER_PORT=9000 ~/Aether/scripts/aether-launch.sh`

## Brancher n'importe quelle IA (« truc maître »)
Config : `~/.aether/plugins.json`
- Ollama (local, souverain) : lance `ollama serve` → type "port"
- GLM / Z.ai : `export AETHER_GLM_KEY=...` → type "openai"
- Gemini : `export AETHER_GEMINI_KEY=...` → type "gemini"
- Tout autre : type "openai" + url + `AETHER_CUSTOM_KEY`
L'IA maître se choisit dans le panneau AGENTS ou via `/ai use <id>`.

## Orbe (barre du bas)
- `!commande` → exécute dans le vrai terminal
- `/help` → liste des commandes
- texte libre → l'IA maître répond

## Arrêter
`~/Aether/scripts/aether-stop.sh`

## Confidentialité
Serveur lié à 127.0.0.1 uniquement. Rien ne sort sans ta clé API,
rien n'est envoyé à un cloud. Mémoire locale : ~/.aether/
AE_README
ok "README.md — mode d'emploi complet"

cat > scripts/aether-launch.sh <<'AE_LCH'
#!/usr/bin/env bash
# NEXUS AETHER — lanceur (utilisé par le raccourci Bureau et le menu)
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ELECTRON_BIN="$DIR/node_modules/.bin/electron"
if [ ! -x "$ELECTRON_BIN" ]; then
  echo "Electron absent — relance l'installateur ou fais : cd $DIR && npm install" >&2
  exit 1
fi
cd "$DIR"
export AETHER_PORT="${AETHER_PORT:-8420}"
mkdir -p "$HOME/.aether"
nohup "$ELECTRON_BIN" . >> "$DIR/aether.log" 2>&1 &
disown 2>/dev/null || true
echo "◉ NEXUS AETHER démarre — port $AETHER_PORT — log : $DIR/aether.log"
AE_LCH
chmod +x scripts/aether-launch.sh

cat > scripts/aether-stop.sh <<'AE_STP'
#!/usr/bin/env bash
# NEXUS AETHER — arrêt propre (fenêtre + serveur + sessions terminal)
PIDF="$HOME/.aether/aether.pid"
if [ -f "$PIDF" ]; then
  PID="$(cat "$PIDF" 2>/dev/null || true)"
  if [ -n "${PID:-}" ] && kill -0 "$PID" 2>/dev/null; then
    pkill -P "$PID" 2>/dev/null || true
    kill "$PID" 2>/dev/null || true
    echo "◉ NEXUS AETHER arrêté (pid $PID)"
  else
    echo "· pid $PID introuvable — nettoyage"
  fi
  rm -f "$PIDF"
else
  if pkill -f "$HOME/Aether/node_modules/electron" 2>/dev/null; then
    echo "◉ NEXUS AETHER arrêté (recherche par chemin)"
  else
    echo "· NEXUS AETHER ne semble pas tourner"
  fi
fi
AE_STP
chmod +x scripts/aether-stop.sh
ok "scripts/aether-launch.sh + aether-stop.sh"

cat > build/nexus-aether.desktop <<AE_DSK
[Desktop Entry]
Type=Application
Version=1.0
Name=NEXUS AETHER
GenericName=Environnement souverain
Comment=Terminal réel · nébuleuse vivante · IA locale ou API · port ${PORT}
Exec=${APP_DIR}/scripts/aether-launch.sh
Icon=${APP_DIR}/assets/aether.svg
Path=${APP_DIR}
Terminal=false
Categories=Development;Utility;
StartupNotify=true
StartupWMClass=nexus-aether
AE_DSK
ok "build/nexus-aether.desktop — entrée de menu prête"

info "scaffold complet : $(find "$APP_DIR" -type f -not -path '*/node_modules/*' -not -path '*/.git/*' | wc -l) fichiers générés dans $APP_DIR"

# ════════════════════════════════════════════════════════════════════
phase 3 "Compilation & dépendances (npm / Electron)"
# ════════════════════════════════════════════════════════════════════
cd "$APP_DIR"
if [ "$SKIP_INSTALL" = "1" ]; then
  warn "AETHER_SKIP_INSTALL=1 → npm ignoré (mode test — l'app ne se lancera pas encore)"
else
  info "npm install — Electron ≈ 100 Mo à télécharger, puis installation… patience"
  if npm install --no-audit --no-fund --loglevel=error; then
    ok "dépendances installées"
    chk "binaire Electron" "[ -x node_modules/.bin/electron ]"
    chk "xterm.js (terminal)" "[ -s node_modules/@xterm/xterm/lib/xterm.js ]"
    chk "addon-fit" "[ -s node_modules/@xterm/addon-fit/lib/addon-fit.js ]"
    chk "module ws (WebSocket)" "[ -d node_modules/ws ]"
  else
    ko "npm install — vérifie Internet puis relance ce script (il est ré-exécutable)"
  fi
fi

# ════════════════════════════════════════════════════════════════════
phase 4 "Validation de la syntaxe"
# ════════════════════════════════════════════════════════════════════
for f in main.js preload.js server/core.js core/router.js core/memory.js ui/nebula.js ui/terminal.js ui/app.js; do
  chk "node --check $f" "node --check '$APP_DIR/$f'"
done
chk "package.json (JSON valide)" "node -e \"JSON.parse(require('fs').readFileSync('$APP_DIR/package.json','utf8'))\""
chk "config/plugins.json (JSON valide)" "node -e \"JSON.parse(require('fs').readFileSync('$APP_DIR/config/plugins.json','utf8'))\""
chk "interface : orbe présente" "grep -q orbinput '$APP_DIR/ui/index.html'"
chk "style : palette nébuleuse" "grep -q -- '--cyan' '$APP_DIR/ui/style.css'"
chk "bash -n aether-launch.sh" "bash -n '$APP_DIR/scripts/aether-launch.sh'"
chk "bash -n aether-stop.sh" "bash -n '$APP_DIR/scripts/aether-stop.sh'"
chk "icône SVG non vide" "[ -s '$APP_DIR/assets/aether.svg' ]"

# ════════════════════════════════════════════════════════════════════
phase 5 "Test serveur réel (démarrage automatique sur le port donné)"
# ════════════════════════════════════════════════════════════════════
if [ "$FAIL" -gt 0 ]; then
  warn "échecs en amont — test serveur sauté"
else
  SMOKE_OUT="$(cd "$APP_DIR" && AETHER_PORT="$PORT" timeout 25 node server/core.js --smoke 2>&1 || true)"
  if printf '%s' "$SMOKE_OUT" | grep -q "SMOKE_OK"; then
    SMOKE_PORT="$(printf '%s' "$SMOKE_OUT" | sed -n 's/.*port=\([0-9]*\).*/\1/p')"
    ok "serveur démarré + /api/health OK (port réel : ${SMOKE_PORT:-?})"
    info "$SMOKE_OUT"
  else
    ko "test serveur — sortie : ${SMOKE_OUT:-<vide>}"
  fi
fi

# ════════════════════════════════════════════════════════════════════
phase 6 "Installation Bureau (icône + menu + git)"
# ════════════════════════════════════════════════════════════════════
chmod +x scripts/aether-launch.sh scripts/aether-stop.sh 2>/dev/null || true
if [ "$NO_DESKTOP" = "1" ]; then
  warn "AETHER_NO_DESKTOP=1 → raccourcis non installés (lancement : scripts/aether-launch.sh)"
else
  APPS_DIR="$HOME/.local/share/applications"
  mkdir -p "$APPS_DIR"
  cp build/nexus-aether.desktop "$APPS_DIR/nexus-aether.desktop"
  ok "menu des applications → NEXUS AETHER"
  DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Bureau")"
  mkdir -p "$DESKTOP_DIR"
  cp build/nexus-aether.desktop "$DESKTOP_DIR/nexus-aether.desktop"
  chmod +x "$DESKTOP_DIR/nexus-aether.desktop" 2>/dev/null || true
  if gio set "$DESKTOP_DIR/nexus-aether.desktop" metadata::trusted true 2>/dev/null; then
    ok "icône Bureau installée et marquée fiable : $DESKTOP_DIR/nexus-aether.desktop"
  else
    ok "icône Bureau créée : $DESKTOP_DIR/nexus-aether.desktop (si Mint demande : clic-droit → « Autoriser le lancement »)"
  fi
  if command -v desktop-file-validate >/dev/null 2>&1; then
    chk ".desktop valide" "desktop-file-validate '$APPS_DIR/nexus-aether.desktop'"
  else
    info "desktop-file-validate absent — validation ignorée (non bloquant)"
  fi
fi
if command -v git >/dev/null 2>&1; then
  if [ ! -d .git ]; then
    if git init -q -b main 2>/dev/null; then
      ok "dépôt git initialisé (dans $APP_DIR — pas dans le home)"
      git add -A 2>/dev/null || true
      if git config user.email >/dev/null 2>&1; then
        if git commit -q -m "NEXUS AETHER v1.0.0 — app bureau (nébuleuse + terminal réel + serveur auto + plugins IA)" 2>/dev/null; then
          ok "commit initial créé"
        else
          info "commit sauté (rien à valider)"
        fi
      else
        warn "git user.email non configuré — commit à faire plus tard : git -C $APP_DIR commit"
      fi
    else
      warn "git init a échoué (non bloquant)"
    fi
  else
    info "dépôt git déjà présent — fichiers mis à jour"
  fi
fi

# ════════════════════════════════════════════════════════════════════
phase 7 "Auto-test final"
# ════════════════════════════════════════════════════════════════════
echo
echo -e "  ${C_B}Bilan : ${C_GRN}$PASS réussis${C_RST} / ${C_RED}$FAIL échoués${C_RST}"
if [ "$FAIL" -eq 0 ]; then
  echo -e "  ${C_GRN}${C_B}✦ TOUT EST VERT — NEXUS AETHER est prêt.${C_RST}"
else
  echo -e "  ${C_YLW}Des échecs subsistent — corrige puis relance ce script (ré-exécutable sans risque).${C_RST}"
fi
echo
echo -e "  ${C_CYAN}${C_B}Fichiers clés${C_RST}"
echo -e "    ${C_DIM}·${C_RST} application     : $APP_DIR/main.js"
echo -e "    ${C_DIM}·${C_RST} serveur         : $APP_DIR/server/core.js"
echo -e "    ${C_DIM}·${C_RST} interface       : $APP_DIR/ui/index.html"
echo -e "    ${C_DIM}·${C_RST} plugins IA      : $CONF_DIR/plugins.json"
echo -e "    ${C_DIM}·${C_RST} mémoire vivante : $CONF_DIR/memory.jsonl"
echo -e "    ${C_DIM}·${C_RST} lanceur         : $APP_DIR/scripts/aether-launch.sh"
echo -e "    ${C_DIM}·${C_RST} arrêt           : $APP_DIR/scripts/aether-stop.sh"

# ════════════════════════════════════════════════════════════════════
phase 8 "Rapport & lancement"
# ════════════════════════════════════════════════════════════════════
cat <<AE_RPT

  Comment lancer :
    1. Menu des applications  →  NEXUS AETHER
    2. Icône sur le Bureau    →  double-clic
    3. Terminal               →  ~/Aether/scripts/aether-launch.sh
       (port personnalisé :   AETHER_PORT=9000 ~/Aether/scripts/aether-launch.sh)
    Arrêt : ~/Aether/scripts/aether-stop.sh

  À l'ouverture de l'app :
    · le serveur démarre AUTOMATIQUEMENT (port ${PORT}, repli 8421+ si occupé)
    · un VRAI terminal s'ouvre (pty réel : couleurs, vim, htop, Ctrl-C, TAB)
    · l'orbe en bas parle à l'IA maître (Ollama / GLM / Gemini / plugin)
    · !commande → terminal   ·   /help → commandes

  Brancher les IA (config ~/.aether/plugins.json) :
    · Ollama (local)  : lance « ollama serve »        → type "port"
    · GLM (Z.ai)      : export AETHER_GLM_KEY=…       → type "openai"
    · Gemini          : export AETHER_GEMINI_KEY=…    → type "gemini"
    · Autre / custom  : type "openai" + url + AETHER_CUSTOM_KEY
AE_RPT
if [ -f "$P2P_SCRIPT" ]; then
  echo -e "  ${C_DIM}·${C_RST} Scaffold P2P détecté : $P2P_SCRIPT — visible dans l'onglet ✦ Grid (aucune modification)."
fi
echo

LAUNCH_NOW="n"
if [ "${1:-}" = "--launch" ]; then
  LAUNCH_NOW="o"
elif [ -t 0 ]; then
  read -r -p "  Lancer NEXUS AETHER maintenant ? [o/N] " LAUNCH_NOW || LAUNCH_NOW="n"
fi
if [[ "$LAUNCH_NOW" == [oO]* ]]; then
  "$APP_DIR/scripts/aether-launch.sh" || true
  echo -e "  ${C_DIM}la fenêtre apparaît dans quelques secondes…${C_RST}"
fi

echo
if [ -t 0 ]; then
  echo -e "${C_DIM}— Appuie sur ENTRÉE pour fermer ce terminal —${C_RST}"
  read -r _
fi
echo

[ "$FAIL" -eq 0 ] && exit 0 || exit 1
