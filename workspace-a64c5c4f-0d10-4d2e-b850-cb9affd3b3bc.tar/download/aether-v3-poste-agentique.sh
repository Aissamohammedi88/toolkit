#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════
#  NEXUS AETHER v3 — POSTE AGENTIQUE  (script d'upgrade, partie 1/6)
# ══════════════════════════════════════════════════════════════════════
#  CE QUE C'EST  : Aether = terminal réel + mémoire + AGENTS en arrière-plan
#                  + MONITEUR OS agentique + IA maîtresse (Ollama auto-détecté,
#                  repli cléless réel). Serveur persistant (systemd + linger).
#  CE QUE CE N'EST PAS : un hub de services. Le hub (141 services) vit dans
#                  ~/Bureau/nexus-genedit/ (genedit.py + genhub.sh) et CE
#                  SCRIPT N'Y TOUCHE JAMAIS. Le catalogue « 90+ services »
#                  ajouté par erreur dans Aether est RETIRÉ (démêlage).
#  PRINCIPE      : optimise l'installation existante, ne détruit rien
#                  (sauvegarde horodatée + restauration depuis .backup-v2-*).
#  Usage : bash aether-v3-poste-agentique.sh
#          AETHER_OLLAMA_AUTOSTART=0  → Ollama ne démarre pas tout seul
#          AETHER_SKIP_LINGER=1      → ne touche pas à linger
# ══════════════════════════════════════════════════════════════════════
set -euo pipefail

APP_TITLE="NEXUS AETHER"
APP_ID="nexus-aether"
APP_VERSION="3.0.0"
APP_DIR="${AETHER_DIR:-$HOME/Aether}"
PORT="${AETHER_PORT:-8420}"
CONF_DIR="$HOME/.aether"
WORKSPACE="$APP_DIR/workspace"

C_CYAN="\033[1;36m"; C_MAG="\033[1;95m"; C_GRN="\033[1;32m"; C_YLW="\033[1;33m"
C_RED="\033[1;31m"; C_DIM="\033[2m"; C_B="\033[1m"; C_RST="\033[0m"
PASS=0; FAIL=0

ok()   { echo -e "  ${C_GRN}✓${C_RST} $1"; PASS=$((PASS+1)); }
ko()   { echo -e "  ${C_RED}✗${C_RST} $1"; FAIL=$((FAIL+1)); }
info() { echo -e "  ${C_DIM}·${C_RST} $1"; }
warn() { echo -e "  ${C_YLW}!${C_RST} $1"; }
phase(){ echo; echo -e "${C_MAG}━━━ PHASE $1/9 ━━━ ${C_CYAN}${C_B}$2${C_RST}"; }
chk()  { if eval "$2" >/dev/null 2>&1; then ok "$1"; else ko "$1"; fi }

echo
echo -e "${C_MAG}${C_B}"
cat <<'BANIERE'
   ╔════════════════════════════════════════════════════════════════╗
   ║   N E X U S   A E T H E R   ·   v 3   P O S T E   A G E N T    ║
   ║   Terminal · Mémoire · Agents arrière-plan · Moniteur OS       ║
   ║   IA réelle : Ollama auto-détecté · daemon persistant          ║
   ╚════════════════════════════════════════════════════════════════╝
BANIERE
echo -e "${C_RST}${C_DIM}   Démêlage : Aether ≠ GenHub. Le hub 141 services reste dans"
echo -e "   ~/Bureau/nexus-genedit/ (genedit.py + genhub.sh) — ici, on n'y touche pas.${C_RST}"

# ════════════════════════════════════════════════════════════════════
phase 1 "Contrôles, sauvegarde, arrêt propre"
# ════════════════════════════════════════════════════════════════════
if [ -d "$APP_DIR" ]; then ok "installation détectée : $APP_DIR"; else
  ko "$APP_DIR introuvable — lance d'abord aether-bureau-tout-en-un.sh"; echo; exit 1; fi

if command -v node >/dev/null 2>&1; then ok "node $(node -v)"; else ko "node absent"; exit 1; fi
NODE_MAJOR="$(node -p 'parseInt(process.versions.node,10)' 2>/dev/null || echo 0)"
if [ "${NODE_MAJOR:-0}" -ge 18 ] 2>/dev/null; then ok "node ≥ 18 — fetch natif + AbortSignal disponibles"
else ko "node ≥ 18 requis — arrêt"; echo; exit 1; fi
chk "curl" "command -v curl"

# État actuel : v1 propre, ou v2 appliqué (coffre asar + catalogue mélangé) ?
V2_STATE=0
[ -f "$APP_DIR/app.asar" ] && V2_STATE=1
[ -f "$APP_DIR/config/services.json" ] && V2_STATE=1
[ -f "$APP_DIR/core/engine.js" ] && V2_STATE=1
if [ "$V2_STATE" = "1" ]; then
  info "état v2 détecté (coffre asar / catalogue 93 services) — démêlage en phase 2"
else
  info "état v1 détecté — pas de catalogue mélangé, démêlage non nécessaire"
fi

# Dernière sauvegarde v2 disponible (base v1 propre pour restauration)
BACKUP_V2=""
for d in $(ls -d "$APP_DIR"/.backup-v2-* 2>/dev/null | sort | tail -n 1 || true); do
  [ -d "$d" ] && BACKUP_V2="$d"
done
if [ -n "$BACKUP_V2" ]; then ok "sauvegarde v2 trouvée (base v1 propre) : $BACKUP_V2"
else info "aucune .backup-v2-* — les fichiers actuels servent de base"; fi

# Arrêt propre de l'app/serveur en cours
if [ -x "$APP_DIR/scripts/aether-stop.sh" ]; then
  "$APP_DIR/scripts/aether-stop.sh" >/dev/null 2>&1 || true
  info "instances en cours arrêtées (le daemon reviendra en phase 6)"
fi
command -v systemctl >/dev/null 2>&1 && systemctl --user stop aether.service >/dev/null 2>&1 || true

# Sauvegarde horodatée v3 de TOUT ce qu'on va toucher
TS="$(date +%Y%m%d-%H%M%S)"
BACKUP="$APP_DIR/.backup-v3-$TS"
mkdir -p "$BACKUP"
for f in main.js preload.js package.json server/core.js core/router.js core/memory.js \
         ui/index.html ui/app.js ui/style.css config/plugins.json \
         scripts/aether-launch.sh scripts/aether-stop.sh README.md; do
  [ -f "$APP_DIR/$f" ] && mkdir -p "$BACKUP/$(dirname "$f")" && cp "$APP_DIR/$f" "$BACKUP/$f"
done
ok "sauvegarde complète : $BACKUP"
echo "$BACKUP" > "$CONF_DIR/last-backup-v3.txt" 2>/dev/null || true

# ════════════════════════════════════════════════════════════════════
phase 2 "DÉMÊLAGE — Aether redevient un poste agentique, pas un hub"
# ════════════════════════════════════════════════════════════════════
cd "$APP_DIR"

# 1) Restauration de la base v1 propre
if [ "$V2_STATE" = "1" ] && [ -n "${BACKUP_V2:-}" ]; then
  for f in main.js preload.js package.json server/core.js ui/index.html ui/app.js \
           ui/style.css config/plugins.json; do
    if [ -f "$BACKUP_V2/$f" ]; then
      mkdir -p "$(dirname "$APP_DIR/$f")"
      cp "$BACKUP_V2/$f" "$APP_DIR/$f"
    fi
  done
  ok "fichiers d'origine restaurés depuis $BACKUP_V2"
fi

# 2) Récupération du cœur v1 (TOUJOURS — v2 scellait core/ dans le coffre,
#    et un run interrompu peut laisser la machine à moitié démontée).
#    Sources, dans l'ordre : coffre app.asar → ~/.nexus-aether/src-backup-*
MISSING_CORE=0
[ -f "$APP_DIR/core/router.js" ] || MISSING_CORE=1
[ -f "$APP_DIR/core/memory.js" ] || MISSING_CORE=1
if [ "$MISSING_CORE" = "1" ]; then
  mkdir -p "$APP_DIR/core"
  VREST="$APP_DIR/.vault-restore"
  if [ -f "$APP_DIR/app.asar" ] && [ ! -d "$VREST" ]; then
    (cd "$APP_DIR" && npx --yes @electron/asar extract app.asar "$VREST" >/dev/null 2>&1) || true
  fi
  SRC_BACKUP=""
  for d in $(ls -d "$HOME/.nexus-aether/src-backup-"* 2>/dev/null | sort | tail -n 1 || true); do
    [ -d "$d" ] && SRC_BACKUP="$d"
  done
  for f in core/router.js core/memory.js; do
    if [ ! -f "$APP_DIR/$f" ]; then
      if [ -d "$VREST" ] && [ -f "$VREST/$f" ]; then
        cp "$VREST/$f" "$APP_DIR/$f"; ok "récupéré du coffre : $f"
      elif [ -n "$SRC_BACKUP" ] && [ -f "$SRC_BACKUP/$f" ]; then
        cp "$SRC_BACKUP/$f" "$APP_DIR/$f"; ok "récupéré de $SRC_BACKUP : $f"
      fi
    fi
  done
  rm -rf "$VREST"
fi

# 3) Retrait du catalogue GenHub qui avait été mélangé dans Aether
MIXED=0
for f in config/services.json core/engine.js ui/engine.js scripts/patch-v2.js \
         "$CONF_DIR/services.json" "$CONF_DIR/engine-history.jsonl"; do
  if [ -f "$f" ]; then rm -f "$f"; MIXED=$((MIXED+1)); fi
done
if [ "$MIXED" -gt 0 ]; then
  ok "catalogue « 90+ services » retiré d'Aether ($MIXED fichier(s)) — il reste dans nexus-genedit"
else
  info "aucun fichier du mélange en clair — il était scellé dans le coffre (retiré ci-dessous)"
fi
# Le coffre v2 est retiré : il sera recompilé proprement en phase 8
[ -f "$APP_DIR/app.asar" ] && { rm -f "$APP_DIR/app.asar"; ok "ancien coffre app.asar retiré (recompilation propre en phase 8)"; } || true

# 3) Vérification des marqueurs v1 (base connue et stable)
# NB : core/router.js n'est pas exigé ici — la phase 3 le réécrit intégralement.
BASE_OK=1
grep -q "startServer" "$APP_DIR/server/core.js" 2>/dev/null || BASE_OK=0
grep -q "</body>" "$APP_DIR/ui/index.html" 2>/dev/null || BASE_OK=0
[ -f "$APP_DIR/core/memory.js" ] || BASE_OK=0
if [ "$BASE_OK" = "1" ]; then ok "base v1 vérifiée (core.js / index.html / memory.js)"
else
  ko "base inconnue : marqueurs v1 introuvables — arrêt par sécurité"
  echo "  → relance d'abord aether-bureau-tout-en-un.sh, puis ce script."; echo; exit 1
fi

# ════════════════════════════════════════════════════════════════════
phase 3 "CERVEAU IA — Ollama auto-détecté (fin du bug « model not found »)"
# ════════════════════════════════════════════════════════════════════
# Le bug : l'ancien code codait « model: llama3 » en dur. S'il n'était pas
# téléchargé → « model 'llama3' not found ». La vraie correction d'ingénieur :
# interroger GET /api/tags d'Ollama et utiliser un modèle INSTALLÉ, avec un
# repli cléless RÉEL (text.pollinations.ai) si Ollama est absent.

cat > core/router.js <<'AE_ROUTER_V3'
'use strict';
// NEXUS AETHER v3 — routeur IA réel.
//  · type "port"        → service local (Ollama 127.0.0.1:11434), modèle AUTO-DÉTECTÉ
//  · type "pollinations"→ cléless RÉEL (text.pollinations.ai) — repli par défaut
//  · type "gemini"      → Google Gemini (clé)
//  · type "openai"      → toute API compatible OpenAI (clé)
// AUCUN modèle n'est codé en dur : si p.model vaut "auto", on lit /api/tags.
const fs = require('fs');
const path = require('path');
const os = require('os');

const CONF_DIR = path.join(os.homedir(), '.aether');
const USER_FILE = path.join(CONF_DIR, 'plugins.json');
const BUNDLED_FILE = path.join(__dirname, '..', 'config', 'plugins.json');

function loadConfig() {
  try { if (fs.existsSync(USER_FILE)) return JSON.parse(fs.readFileSync(USER_FILE, 'utf8')); } catch (e) {}
  try { return JSON.parse(fs.readFileSync(BUNDLED_FILE, 'utf8')); } catch (e) {}
  return { active: '', providers: [], agentique: {} };
}
function saveConfig(cfg) {
  fs.mkdirSync(CONF_DIR, { recursive: true });
  fs.writeFileSync(USER_FILE, JSON.stringify(cfg, null, 2) + '\n');
}

function fetchTimeout(url, opts, ms) {
  const c = new AbortController();
  const t = setTimeout(function () { try { c.abort(); } catch (e) {} }, ms || 30000);
  return fetch(url, Object.assign({}, opts || {}, { signal: c.signal })).then(function (r) {
    clearTimeout(t); return r;
  }, function (e) { clearTimeout(t); throw e; });
}

async function readJson(res) {
  const t = await res.text();
  try { return JSON.parse(t); } catch (e) {
    throw new Error('réponse non-JSON (' + res.status + ') : ' + t.slice(0, 200));
  }
}

// ── Ollama : la liste des modèles RÉELLEMENT installés ──────────────
async function ollamaModels(base, ms) {
  const r = await fetchTimeout(String(base).replace(/\/+$/, '') + '/api/tags', {}, ms || 4000);
  if (!r.ok) throw new Error('Ollama HTTP ' + r.status);
  const j = await r.json();
  return (j.models || []).map(function (m) { return m.name; }).filter(Boolean);
}

// préfère un modèle causonnable déjà installé, sinon le premier de la liste
function pickModel(list) {
  const pref = ['llama3.2', 'qwen2.5', 'qwen3', 'mistral', 'llama3.1', 'llama3', 'gemma3', 'gemma2', 'phi', 'deepseek', 'codellama', 'tinyllama'];
  for (let i = 0; i < pref.length; i++) {
    const hit = list.find(function (m) { return m.indexOf(pref[i]) === 0; });
    if (hit) return hit;
  }
  return list[0];
}

async function chatWithOllama(p, messages) {
  const base = String(p.url || 'http://127.0.0.1:11434');
  let model = p.model;
  if (!model || model === 'auto') {
    let list;
    try { list = await ollamaModels(base, 4000); }
    catch (e) { throw new Error('Ollama injoignable sur ' + base + ' — il démarre tout seul si l\u2019option est active, sinon : ollama serve'); }
    if (!list.length) throw new Error('Ollama ne compte AUCUN modèle — télécharge-en un : ollama pull llama3.2:1b');
    model = pickModel(list);
  }
  let res;
  try {
    res = await fetchTimeout(base.replace(/\/+$/, '') + '/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: model, messages: messages, stream: false })
    }, 180000);
  } catch (e) {
    throw new Error('Ollama injoignable sur ' + base + ' (' + String((e && e.message) || e) + ')');
  }
  const j = await readJson(res);
  if (j.error) throw new Error('Ollama : ' + ((j.error && j.error.message) || j.error));
  return (j.message && j.message.content) || '(réponse vide)';
}

// ── Pollinations : cléless RÉEL, testé en direct ─────────────────────
// Free tier : 1 réponse / 30 s / IP → HTTP 402. Vraie correction d'ingénieur :
// on RETIENT (backoff indiqué par le service) et on réessaie — pas d'échec sec.
async function chatWithPollinations(p, messages) {
  const body = { messages: messages, model: p.model || 'openai-fast' };
  let lastErr = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    if (attempt > 0) {
      const d = (lastErr && lastErr.waitMs) ? lastErr.waitMs : 31000;
      await new Promise(function (r) { setTimeout(r, d); });
    }
    const res = await fetchTimeout('https://text.pollinations.ai/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }, 120000);
    const t = await res.text();
    if (res.status === 402 || res.status === 429) {
      const m = t.match(/wait (\d+) seconds/);
      const err = new Error('Pollinations HTTP ' + res.status + ' (quota gratuit) — nouvelle tentative automatique');
      err.waitMs = Math.min(45000, ((m ? parseInt(m[1], 10) : 30) + 4) * 1000);
      lastErr = err;
      continue;
    }
    if (res.status >= 400) throw new Error('Pollinations HTTP ' + res.status + ' — ' + t.slice(0, 160));
    try {
      const j = JSON.parse(t);
      return (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content)
        || j.message || j.text || t;
    } catch (e) { return t; }
  }
  throw lastErr || new Error('Pollinations : échec après 3 tentatives');
}

async function chatWithGemini(p, key, messages) {
  if (!key) throw new Error('clé Gemini absente — export ' + (p.keyEnv || 'AETHER_GEMINI_KEY') + '=…');
  const url = String(p.url).replace(/\/+$/, '') + '/models/' + p.model + ':generateContent?key=' + encodeURIComponent(key);
  const sys = messages.find(function (m) { return m.role === 'system'; });
  const contents = messages.filter(function (m) { return m.role !== 'system'; }).map(function (m) {
    return { role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: String(m.content) }] };
  });
  const body = { contents: contents };
  if (sys) body.systemInstruction = { parts: [{ text: String(sys.content) }] };
  const res = await fetchTimeout(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }, 120000);
  const j = await readJson(res);
  if (j.error) throw new Error('Gemini : ' + ((j.error && j.error.message) || JSON.stringify(j.error).slice(0, 200)));
  const parts = (j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || [];
  return parts.map(function (x) { return x.text || ''; }).join('') || '(réponse vide)';
}

async function chatWithOpenAI(p, key, messages) {
  if (!p.url) throw new Error('fournisseur « ' + (p.name || p.id) + ' » : url manquante');
  if (!key) throw new Error('fournisseur « ' + (p.name || p.id) + ' » : clé absente — export ' + (p.keyEnv || 'AETHER_CUSTOM_KEY') + '=…');
  const res = await fetchTimeout(String(p.url).replace(/\/+$/, ''), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
    body: JSON.stringify({ model: p.model, messages: messages, stream: false, temperature: 0.7 })
  }, 120000);
  const j = await readJson(res);
  if (j.error) throw new Error('API : ' + ((j.error && j.error.message) || JSON.stringify(j.error).slice(0, 200)));
  return (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '(réponse vide)';
}

// ── chat() : compatible v1 (même signature) + repli automatique ──────
async function chat(messages, opts) {
  const cfg = loadConfig();
  const providers = cfg.providers || [];
  let p = providers.find(function (x) { return x.id === ((opts && opts.providerId) || cfg.active); })
       || providers[0];
  if (!p) throw new Error('aucun fournisseur IA — vérifie ~/.aether/plugins.json');
  let tries = 0;
  for (;;) {
    tries += 1;
    const key = p.key || (p.keyEnv ? (process.env[p.keyEnv] || '') : '');
    try {
      let text;
      if (p.type === 'port') text = await chatWithOllama(p, messages);
      else if (p.type === 'pollinations') text = await chatWithPollinations(p, messages);
      else if (p.type === 'gemini') text = await chatWithGemini(p, key, messages);
      else text = await chatWithOpenAI(p, key, messages);
      return { text: text, provider: p.id, model: p.model || 'auto' };
    } catch (e) {
      if (p.fallback && tries === 1) {
        const fb = providers.find(function (x) { return x.id === p.fallback; });
        if (fb) { p = fb; continue; } // repli réel (ex : Ollama absent → Pollinations cléless)
      }
      throw e;
    }
  }
}

// ── testProvider : un VRAI appel, pour le bouton « Tester » ──────────
async function testProvider(id) {
  const t0 = Date.now();
  try {
    const out = await chat([{ role: 'user', content: 'Réponds exactement : TEST_OK' }], { providerId: id });
    return { ok: true, ms: Date.now() - t0, provider: out.provider, extrait: String(out.text).slice(0, 80) };
  } catch (e) {
    return { ok: false, ms: Date.now() - t0, error: String((e && e.message) || e) };
  }
}

module.exports = { chat: chat, loadConfig: loadConfig, saveConfig: saveConfig, testProvider: testProvider, ollamaModels: ollamaModels };
AE_ROUTER_V3
ok "core/router.js v3 — modèle auto-détecté via /api/tags, repli cléless réel, testProvider"
chk "syntaxe router.js v3" "node --check '$APP_DIR/core/router.js'"

# Config officielle v3 : Aether ne référence QUE ses 4 fournisseurs IA.
# Les clés déjà posées par l'utilisateur (key/keyEnv) sont conservées.
cat > config/plugins.json <<'AE_PLUG_V3'
{
  "active": "ollama",
  "providers": [
    {
      "id": "ollama",
      "name": "Ollama (local · souverain)",
      "type": "port",
      "url": "http://127.0.0.1:11434",
      "model": "auto",
      "fallback": "pollinations-text",
      "tier": "local",
      "docs": "Modèle auto-détecté via /api/tags — plus jamais « model not found »."
    },
    {
      "id": "pollinations-text",
      "name": "Pollinations Text (cléless · réel)",
      "type": "pollinations",
      "url": "https://text.pollinations.ai/",
      "model": "openai-fast",
      "tier": "cléless",
      "docs": "Aucune clé requise — testé en direct."
    },
    {
      "id": "gemini",
      "name": "Google Gemini (clé)",
      "type": "gemini",
      "url": "https://generativelanguage.googleapis.com/v1beta",
      "model": "gemini-2.0-flash",
      "keyEnv": "AETHER_GEMINI_KEY",
      "tier": "clé-gratuit"
    },
    {
      "id": "openai-compat",
      "name": "API compatible OpenAI (clé)",
      "type": "openai",
      "url": "https://api.openai.com/v1/chat/completions",
      "model": "gpt-4o-mini",
      "keyEnv": "AETHER_CUSTOM_KEY",
      "tier": "clé"
    }
  ],
  "agentique": {
    "masterIA": "auto",
    "ollamaAutoStart": true,
    "maxConcurrent": 2
  }
}
AE_PLUG_V3
# Fusion : garder les clés posées par l'utilisateur dans l'ancien plugins.json
node -e '
const fs = require("fs");
const p = process.argv[1], b = process.argv[2];
try {
  const old = JSON.parse(fs.readFileSync(p, "utf8"));
  const nw = JSON.parse(fs.readFileSync(b, "utf8"));
  const oldById = {}; (old.providers || []).forEach(function (x) { oldById[x.id] = x; });
  nw.providers.forEach(function (x) {
    const o = oldById[x.id];
    if (o && o.key) x.key = o.key;
    if (o && o.keyEnv && !x.keyEnv) x.keyEnv = o.keyEnv;
  });
  if (old.active && nw.providers.some(function (x) { return x.id === old.active; })) nw.active = old.active;
  fs.writeFileSync(b, JSON.stringify(nw, null, 2) + "\n");
} catch (e) {}
' "$CONF_DIR/plugins.json" "$APP_DIR/config/plugins.json" 2>/dev/null || true
cp "$APP_DIR/config/plugins.json" "$CONF_DIR/plugins.json" 2>/dev/null || true
ok "config IA v3 écrite (~/.aether/plugins.json) — clés utilisateur conservées"

# main.js : si le daemon persistant tourne déjà, la fenêtre s'y BRANCHE au lieu
# de démarrer un second serveur.
MAIN_PATCH_OUT="$(node -e '
const fs = require("fs");
const f = process.argv[1];
let s = fs.readFileSync(f, "utf8");
if (s.indexOf("AETHER_V3") !== -1) { console.log("already"); process.exit(0); }
const anchor = "  const { startServer } = require(\u0027./server/core\u0027);\n  try {";
const rep =
"  const { startServer } = require(\u0027./server/core\u0027);\n" +
"  // AETHER_V3 : si le daemon persistant (systemd) est vivant, on s\u0027y branche\n" +
"  try {\n" +
"    const pr = await fetch(\u0027http://127.0.0.1:\u0027 + PORT + \u0027/api/health\u0027, { signal: AbortSignal.timeout(1500) });\n" +
"    const pj = await pr.json();\n" +
"    if (pj && pj.ok) { createWindow(PORT); console.log(\u0027[nexus-aether] branché au daemon persistant :\u0027 + PORT); return; }\n" +
"  } catch (e) {}\n" +
"  try {";
if (s.indexOf(anchor) === -1) { console.log("anchor-missing"); process.exit(2); }
s = s.replace(anchor, rep).replace("// NEXUS AETHER — processus principal Electron.", "// NEXUS AETHER — processus principal Electron. (AETHER_V3)");
fs.writeFileSync(f, s);
console.log("patched");
' "$APP_DIR/main.js" 2>&1)" || true
if echo "$MAIN_PATCH_OUT" | grep -q "^patched"; then
  ok "main.js — branchement automatique au daemon persistant"
elif echo "$MAIN_PATCH_OUT" | grep -q "already"; then
  ok "main.js déjà patché v3 (re-run sans casse)"
else
  warn "ancre main.js introuvable — comportement v1 conservé (sans casse) : $MAIN_PATCH_OUT"
fi
chk "syntaxe main.js" "node --check '$APP_DIR/main.js'"

# ════════════════════════════════════════════════════════════════════
phase 4 "AGENTS EN ARRIÈRE-PLAN — file réelle, étapes, journal, résultat"
# ════════════════════════════════════════════════════════════════════
mkdir -p "$WORKSPACE/agents" "$CONF_DIR"

cat > core/agents.js <<'AE_AGENTS_V3'
'use strict';
// NEXUS AETHER v3 — agents en arrière-plan.
// Un agent = une tâche → plan par l'IA maîtresse → étapes exécutées une à une
// (VRAIS appels IA) → résultat écrit dans workspace/agents/<id>/result.md.
// La file vit DANS le daemon persistant : fermer la fenêtre n'arrête rien.
const fs = require('fs');
const path = require('path');
const os = require('os');
const { chat, loadConfig } = require('./router');
const { remember } = require('./memory');

const HOME = os.homedir();
const STORE = path.join(HOME, '.aether', 'agents.json');

let agents = {};
let timer = null;

function wsDir() {
  return path.join(process.env.AETHER_WORKSPACE || path.join(HOME, 'Aether', 'workspace'), 'agents');
}
function cfgVal(k, d) {
  try {
    const c = loadConfig();
    return (c.agentique && typeof c.agentique[k] !== 'undefined') ? c.agentique[k] : d;
  } catch (e) { return d; }
}
function save() {
  try {
    fs.mkdirSync(path.dirname(STORE), { recursive: true });
    fs.writeFileSync(STORE, JSON.stringify(agents, null, 2) + '\n');
  } catch (e) {}
}
function load() {
  try { agents = JSON.parse(fs.readFileSync(STORE, 'utf8')) || {}; } catch (e) { agents = {}; }
  // au boot du daemon : les agents « en cours » deviennent « interrompu » (honnête)
  Object.keys(agents).forEach(function (id) {
    if (agents[id].status === 'en-cours') { agents[id].status = 'interrompu'; log(agents[id], 'daemon redémarré — agent marqué interrompu'); }
  });
  save();
}
function log(a, line) {
  a.log = a.log || [];
  a.log.push({ t: Date.now(), line: String(line).slice(0, 600) });
  if (a.log.length > 400) a.log = a.log.slice(-300);
}
function broadcast(a) {
  try {
    if (global.__AETHER_V3_WS) global.__AETHER_V3_WS({
      kind: 'agent', id: a.id, status: a.status, stepIndex: a.stepIndex,
      steps: (a.steps || []).map(function (s) { return { label: s.label, status: s.status }; })
    });
  } catch (e) {}
}
function summary(a) {
  return {
    id: a.id, task: a.task, status: a.status, createdAt: a.createdAt, endedAt: a.endedAt,
    stepIndex: a.stepIndex, steps: (a.steps || []).map(function (s) { return { label: s.label, status: s.status }; }),
    resultFile: a.resultFile || null, error: a.error || null,
    logTail: (a.log || []).slice(-12)
  };
}
function create(task, opts) {
  const id = 'ag-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);
  const a = {
    id: id, task: String(task || '').slice(0, 4000), status: 'en-file',
    createdAt: Date.now(), startedAt: null, endedAt: null,
    steps: [], stepIndex: -1, log: [], resultFile: null, error: null,
    cancelRequested: false
  };
  agents[id] = a;
  log(a, 'agent créé — placé en file d\u2019attente');
  save(); kick(); broadcast(a);
  return summary(a);
}
function get(id) { const a = agents[id]; return a ? summary(a) : null; }
function detail(id) { return agents[id] ? JSON.parse(JSON.stringify(agents[id])) : null; }
function list() {
  return Object.keys(agents).map(function (id) { return summary(agents[id]); })
    .sort(function (x, y) { return y.createdAt - x.createdAt; }).slice(0, 60);
}
function cancel(id) {
  const a = agents[id]; if (!a) return null;
  if (a.status === 'en-file') { a.status = 'annulé'; a.endedAt = Date.now(); log(a, 'annulé (encore en file)'); }
  else if (a.status === 'en-cours') { a.cancelRequested = true; log(a, 'annulation demandée — arrêt à la fin de l\u2019étape en cours'); }
  save(); broadcast(a); return summary(a);
}
function runningCount() {
  return Object.keys(agents).filter(function (id) { return agents[id].status === 'en-cours'; }).length;
}
function kick() { if (!timer) timer = setInterval(tick, 1500); }
function tick() {
  const max = Math.max(1, Math.min(4, parseInt(cfgVal('maxConcurrent', 2), 10) || 2));
  if (runningCount() >= max) return;
  const next = Object.keys(agents).map(function (id) { return agents[id]; })
    .filter(function (a) { return a.status === 'en-file'; })
    .sort(function (x, y) { return x.createdAt - y.createdAt; })[0];
  if (next) run(next);
  const busy = Object.keys(agents).some(function (id) {
    return agents[id].status === 'en-file' || agents[id].status === 'en-cours';
  });
  if (!busy && timer) { clearInterval(timer); timer = null; }
}
function extractJson(t) {
  const m = String(t || '').match(/\{[\s\S]*\}/);
  if (!m) return null;
  try { return JSON.parse(m[0]); } catch (e) { return null; }
}
async function callIA(messages) {
  const out = await chat(messages, {});
  return String(out.text || '');
}
async function run(a) {
  a.status = 'en-cours'; a.startedAt = Date.now(); save(); broadcast(a);
  try {
    log(a, 'IA maîtresse : planification…'); broadcast(a);
    let planTxt = '';
    try {
      planTxt = await callIA([
        { role: 'system', content: 'Tu es le planificateur d\u2019agents de NEXUS AETHER. Découpe la tâche en 2 à 4 étapes courtes et concrètes. Réponds UNIQUEMENT avec un JSON {"etapes":["...","..."]}.' },
        { role: 'user', content: a.task }
      ]);
    } catch (e) { throw new Error('IA maîtresse injoignable : ' + String((e && e.message) || e)); }
    const plan = extractJson(planTxt);
    const etapes = (plan && Array.isArray(plan.etapes) && plan.etapes.length)
      ? plan.etapes : ['Analyser la tâche', 'Produire le résultat', 'Vérifier et rédiger'];
    a.steps = etapes.slice(0, 5).map(function (s) { return { label: String(s).slice(0, 200), status: 'en-attente' }; });
    save(); broadcast(a);
    let context = '';
    for (let i = 0; i < a.steps.length; i++) {
      if (a.cancelRequested) throw new Error('annulé à la demande de l\u2019utilisateur');
      a.stepIndex = i; a.steps[i].status = 'en-cours'; save(); broadcast(a);
      const out = await callIA([
        { role: 'system', content: 'Tu es un agent de NEXUS AETHER. Exécute UNE étape de façon directe et utile, sans bavardage.' },
        { role: 'user', content: 'Tâche globale : ' + a.task + '\nContexte des étapes précédentes :\n' + (context || '(aucun)') + '\n\nÉtape à exécuter : ' + a.steps[i].label }
      ]);
      a.steps[i].status = 'terminé';
      a.steps[i].resume = String(out).slice(0, 300);
      context += '\n[' + a.steps[i].label + ']\n' + String(out).slice(0, 1500);
      log(a, 'étape ' + (i + 1) + '/' + a.steps.length + ' terminée'); save(); broadcast(a);
    }
    if (a.cancelRequested) throw new Error('annulé à la demande de l\u2019utilisateur');
    const dir = path.join(wsDir(), a.id);
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, 'result.md');
    fs.writeFileSync(file, '# Agent ' + a.id + '\n\n**Tâche :** ' + a.task + '\n\n' + context.trim() + '\n');
    a.resultFile = file; a.status = 'terminé'; a.endedAt = Date.now();
    log(a, 'terminé — résultat : ' + file);
    try { remember('agent', 'agent ' + a.id + ' terminé : ' + a.task.slice(0, 120)); } catch (e) {}
    save(); broadcast(a);
  } catch (e) {
    a.status = a.cancelRequested ? 'annulé' : 'échec';
    a.error = String((e && e.message) || e); a.endedAt = Date.now();
    log(a, 'échec : ' + a.error); save(); broadcast(a);
  }
}
module.exports = { create: create, list: list, get: get, detail: detail, cancel: cancel, load: load, runningCount: runningCount };
AE_AGENTS_V3
ok "core/agents.js — file d'attente réelle, plan IA, étapes, résultat sur disque, survit à la fermeture"
chk "syntaxe agents.js" "node --check '$APP_DIR/core/agents.js'"

# ════════════════════════════════════════════════════════════════════
phase 5 "MONITEUR OS AGENTIQUE — CPU/RAM réels + processus (comme un vrai)"
# ════════════════════════════════════════════════════════════════════
cat > core/sysmon.js <<'AE_SYSMON_V3'
'use strict';
// NEXUS AETHER v3 — moniteur OS : lectures /proc réelles (aucune dépendance).
// CPU global (%), RAM, charge, uptime + TABLE DES PROCESSUS (pid, nom, CPU %,
// RAM Mo, état) avec étiquettes aether / ollama / electron.
const fs = require('fs');
const os = require('os');

let cpuLast = null;
let procLast = {};   // pid → {t, jiffies}
let CLK = 100;
try { CLK = os.sysconf ? os.sysconf('SC_CLK_TCK') : 100; } catch (e) { CLK = 100; }
if (!CLK || CLK < 1) CLK = 100;

function cpuGlobal() {
  try {
    const parts = fs.readFileSync('/proc/stat', 'utf8').split('\n')[0].trim().split(/\s+/).slice(1).map(Number);
    const idle = parts[3] + (parts[4] || 0);
    const total = parts.reduce(function (a, b) { return a + b; }, 0);
    let pct = 0;
    if (cpuLast) {
      const dT = total - cpuLast.total, dI = idle - cpuLast.idle;
      pct = dT > 0 ? Math.round((1 - dI / dT) * 100) : 0;
    }
    cpuLast = { idle: idle, total: total };
    return Math.max(0, Math.min(100, pct));
  } catch (e) { return 0; }
}
function readStat(pid) {
  try {
    const s = fs.readFileSync('/proc/' + pid + '/stat', 'utf8');
    const close = s.lastIndexOf(')');
    const f = s.slice(close + 2).split(' ');
    // après state(0) : ppid(1)… utime = f[11], stime = f[12]
    return { state: f[0], utime: parseInt(f[11], 10) || 0, stime: parseInt(f[12], 10) || 0 };
  } catch (e) { return null; }
}
function readCmd(pid) {
  try {
    return fs.readFileSync('/proc/' + pid + '/cmdline', 'utf8')
      .split('\u0000').filter(Boolean).join(' ').slice(0, 90) || '(kernel)';
  } catch (e) { return ''; }
}
function readRss(pid) {
  try {
    const pages = parseInt(fs.readFileSync('/proc/' + pid + '/statm', 'utf8').trim().split(/\s+/)[1], 10) || 0;
    return Math.round(pages * 4096 / 1048576);
  } catch (e) { return 0; }
}
function tagOf(cmd) {
  const c = String(cmd).toLowerCase();
  if (c.indexOf('ollama') !== -1) return 'ollama';
  if (c.indexOf('electron') !== -1) return 'aether-fenêtre';
  if (c.indexOf('aether') !== -1 || c.indexOf('nexus') !== -1) return 'aether';
  return '';
}
function snapshot() {
  const total = os.totalmem(), free = os.freemem();
  const now = Date.now();
  const procs = [];
  let names = [];
  try { names = fs.readdirSync('/proc'); } catch (e) { names = []; }
  names.forEach(function (n) {
    if (!/^[0-9]+$/.test(n)) return;
    const pid = parseInt(n, 10);
    const st = readStat(pid);
    if (!st) return;
    const cmd = readCmd(pid);
    if (!cmd) return; // processus kernel sans cmdline
    const j = st.utime + st.stime;
    const prev = procLast[pid];
    let cpu = 0;
    if (prev && now > prev.t) {
      const dJ = j - prev.j, dT = (now - prev.t) / 1000;
      cpu = dT > 0 ? Math.max(0, Math.min(160, (dJ / CLK) / dT * 100)) : 0;
    }
    procLast[pid] = { t: now, j: j };
    procs.push({ pid: pid, cmd: cmd, cpu: +cpu.toFixed(1), rssMb: readRss(pid), state: st.state, tag: tagOf(cmd) });
  });
  // purge les pids disparus (évite la fuite mémoire de la map)
  const alive = {};
  procs.forEach(function (p) { alive[p.pid] = true; });
  Object.keys(procLast).forEach(function (k) { if (!alive[parseInt(k, 10)]) delete procLast[k]; });
  procs.sort(function (a, b) { return b.cpu - a.cpu; });
  const load = os.loadavg();
  return {
    cpu: cpuGlobal(),
    cpuCores: os.cpus().length,
    ramUsedMb: Math.round((total - free) / 1048576),
    ramTotalMb: Math.round(total / 1048576),
    ramPct: Math.round((total - free) / total * 100),
    load: [+load[0].toFixed(2), +load[1].toFixed(2), +load[2].toFixed(2)],
    uptimeS: Math.round(os.uptime()),
    serverPid: process.pid,
    procs: procs.slice(0, 14)
  };
}
module.exports = { snapshot: snapshot };
AE_SYSMON_V3
ok "core/sysmon.js — /proc réel : CPU %, RAM, charge, table processus (ollama/aether repérés)"
chk "syntaxe sysmon.js" "node --check '$APP_DIR/core/sysmon.js'"

# ── Module de colle : routes v3 branchées dans le cœur v1 sans le réécrire ──
cat > core/aether-v3.js <<'AE_GLUE_V3'
'use strict';
// NEXUS AETHER v3 — colle entre le cœur v1 (server/core.js) et les modules v3.
// AUCUNE logique ici : juste le routage HTTP vers agents.js / sysmon.js / router.js.
const agents = require('./agents');
const sysmon = require('./sysmon');
const router = require('./router');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');

let deps = function () { return {}; };
function init(fn) { deps = fn; }

function onServerUp(port) {
  try { agents.load(); } catch (e) {}
  try {
    const c = router.loadConfig();
    if (c.agentique && c.agentique.ollamaAutoStart && process.env.AETHER_HEADLESS !== '0') {
      // systemd s'en charge via aether-ollama.service — ici on ne spawn PAS de doublon
      return;
    }
  } catch (e) {}
}

function j(res, obj, code) {
  const d = deps();
  if (d && d.json) return d.json(res, obj, code);
  res.writeHead(code || 200, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}

async function ollamaStatus() {
  try {
    const models = await router.ollamaModels('http://127.0.0.1:11434', 2500);
    return { present: true, models: models, activeModel: models.length ? models[0] : null };
  } catch (e) { return { present: false, models: [], activeModel: null }; }
}

async function iaStatus() {
  const cfg = router.loadConfig();
  const ollama = await ollamaStatus();
  return {
    ok: true,
    active: cfg.active || '',
    providers: (cfg.providers || []).map(function (p) {
      return {
        id: p.id, name: p.name, type: p.type, model: p.model || 'auto',
        tier: p.tier || '', fallback: p.fallback || null,
        keySet: !!(p.key || (p.keyEnv && process.env[p.keyEnv])),
        keyEnv: p.keyEnv || null
      };
    }),
    ollama: ollama,
    agentique: cfg.agentique || { masterIA: 'auto', ollamaAutoStart: false, maxConcurrent: 2 }
  };
}

function httpGet(u, p, res) {
  if (p === '/api/agents') return j(res, { ok: true, agents: agents.list() });
  if (p === '/api/sysmon') return j(res, { ok: true, sysmon: sysmon.snapshot() });
  if (p === '/api/ia') return iaStatus().then(function (s) { j(res, s); }).catch(function (e) { j(res, { ok: false, error: String((e && e.message) || e) }); });
  const mAgent = p.match(/^\/api\/agents\/([^\/]+)$/);
  if (mAgent) { const d = agents.detail(mAgent[1]); return d ? j(res, { ok: true, agent: d }) : j(res, { ok: false, error: 'agent inconnu' }, 404); }
  const mRes = p.match(/^\/api\/agents\/([^\/]+)\/result$/);
  if (mRes) {
    const a = agents.detail(mRes[1]);
    if (!a || !a.resultFile) return j(res, { ok: false, error: 'pas de résultat' }, 404);
    try {
      const txt = fs.readFileSync(a.resultFile, 'utf8');
      res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end(txt);
    } catch (e) { return j(res, { ok: false, error: 'lecture impossible' }, 404); }
  }
  return j(res, { ok: false, error: 'route v3 inconnue : ' + p }, 404);
}

function httpPost(u, p, data, res) {
  data = data || {};
  if (p === '/api/agents') {
    const task = String(data.task || '').trim();
    if (!task) return j(res, { ok: false, error: 'tâche vide' }, 400);
    const a = agents.create(task, {});
    return j(res, { ok: true, agent: a });
  }
  let m = p.match(/^\/api\/agents\/([^\/]+)\/cancel$/);
  if (m) { const a = agents.cancel(m[1]); return a ? j(res, { ok: true, agent: a }) : j(res, { ok: false, error: 'agent inconnu' }, 404); }
  if (p === '/api/ia/test') {
    const id = String(data.id || '');
    return router.testProvider(id).then(function (r) { j(res, Object.assign({ ok: !!r.ok }, r)); });
  }
  if (p === '/api/ia/active') {
    const cfg = router.loadConfig();
    const id = String(data.id || '');
    if (!(cfg.providers || []).some(function (x) { return x.id === id; })) return j(res, { ok: false, error: 'fournisseur inconnu' }, 400);
    cfg.active = id; router.saveConfig(cfg);
    return j(res, { ok: true, active: id });
  }
  if (p === '/api/ia/config') {
    const cfg = router.loadConfig();
    cfg.agentique = cfg.agentique || {};
    ['masterIA', 'ollamaAutoStart', 'maxConcurrent'].forEach(function (k) {
      if (typeof data[k] !== 'undefined') cfg.agentique[k] = data[k];
    });
    router.saveConfig(cfg);
    return j(res, { ok: true, agentique: cfg.agentique });
  }
  if (p === '/api/ia/ollama-autostart') {
    const on = !!data.on;
    const cfg = router.loadConfig();
    cfg.agentique = cfg.agentique || {};
    cfg.agentique.ollamaAutoStart = on;
    router.saveConfig(cfg);
    const act = on ? 'enable' : 'disable';
    spawn('systemctl', ['--user', act, 'aether-ollama.service'], { stdio: 'ignore' }).on('error', function () {});
    return j(res, { ok: true, ollamaAutoStart: on, note: on ? 'aether-ollama.service activé' : 'aether-ollama.service désactivé' });
  }
  return j(res, { ok: false, error: 'route v3 inconnue : ' + p }, 404);
}

module.exports = { init: init, onServerUp: onServerUp, httpGet: httpGet, httpPost: httpPost };
AE_GLUE_V3
ok "core/aether-v3.js — routes /api/agents · /api/sysmon · /api/ia (test réel, config, auto-start)"
chk "syntaxe aether-v3.js" "node --check '$APP_DIR/core/aether-v3.js'"

# ── Patch chirurgical de server/core.js (4 insertions, ancre par ancre) ──
cat > scripts/.patch-core-v3.js <<'AE_PATCH_CORE'
'use strict';
const fs = require('fs');
const f = process.argv[2];
let s = fs.readFileSync(f, 'utf8');
if (s.indexOf('AETHER_V3') !== -1) { console.log('already'); process.exit(0); }
let n = 0;
const rep = function (anchor, add) {
  if (s.indexOf(anchor) === -1) { console.log('MISS:' + n); process.exit(3 + n); }
  s = s.replace(anchor, anchor + add);
  n += 1;
};
const swap = function (from, to) {
  if (s.indexOf(from) === -1) { console.log('MISS:' + n); process.exit(3 + n); }
  s = s.replace(from, to);
  n += 1;
};
// 1) require du module v3 juste après les requires existants
rep("const { remember, getMemory } = require('../core/memory');",
"\n// AETHER_V3 — modules agentiques (agents, moniteur OS, IA v3)\n" +
"let V3 = null;\n" +
"try { V3 = require('../core/aether-v3'); V3.init(function () { return { json: json, metrics: metrics, srvPort: srvPort }; }); } catch (e3) { V3 = null; }");
// 2) routes GET v3
rep("if (p === '/api/grid/status') return apiGrid(res);",
"\n    if (V3 && (p === '/api/agents' || p === '/api/sysmon' || p === '/api/ia' || p.indexOf('/api/agents/') === 0 || p.indexOf('/api/ia/') === 0)) return V3.httpGet(u, p, res);");
// 3) routes POST v3 (AVANT /api/ai) — SWAP. NB : handlePost(p, body, res) n'a PAS
//    accès à « u » (local à handler) → on reconstruit l'URL depuis le pathname.
swap("  if (p === '/api/ai') {",
     "  if (V3 && (p.indexOf('/api/agents') === 0 || p.indexOf('/api/ia/') === 0)) { V3.httpPost(new URL('http://127.0.0.1' + p), p, data, res); return; }\n  if (p === '/api/ai') {");
// 4) au démarrage du serveur : recharger les agents + marquer le boot
rep("        srvPort = port;",
"\n        if (V3) { try { V3.onServerUp(port); } catch (e5) {} }");
// 5) vendor xterm + assets : servis depuis le VRAI dossier (hors coffre asar)
rep("const ROOT = path.join(__dirname, '..');",
"\nconst ROOT_FS = (process.env.AETHER_ROOT && fs.existsSync(path.join(process.env.AETHER_ROOT, 'node_modules'))) ? process.env.AETHER_ROOT : ROOT;");
swap("sendFile(res, path.join.apply(path, [ROOT, 'node_modules'].concat(rel)));",
     "sendFile(res, path.join.apply(path, [ROOT_FS, 'node_modules'].concat(rel)));");
swap("if (p.indexOf('/assets/') === 0) return sendFile(res, path.join(ROOT, p.slice(1)));",
     "if (p.indexOf('/assets/') === 0) return sendFile(res, path.join(ROOT_FS, p.slice(1)));");
fs.writeFileSync(f, s);
console.log('patched:' + n);
AE_PATCH_CORE
PATCH_OUT="$(node "$APP_DIR/scripts/.patch-core-v3.js" "$APP_DIR/server/core.js" 2>&1 || true)"
info "patch core.js : $PATCH_OUT"
if echo "$PATCH_OUT" | grep -q "patched:7"; then
  ok "server/core.js — 7 greffes v3 (routes agents/sysmon/ia + boot hook + vendor hors coffre)"
elif echo "$PATCH_OUT" | grep -q "already"; then
  ok "server/core.js déjà patché v3 (re-run sans casse)"
else
  ko "patch core.js : $PATCH_OUT — restaure depuis la sauvegarde et vérifie la base v1"
  exit 1
fi
rm -f "$APP_DIR/scripts/.patch-core-v3.js"
chk "syntaxe server/core.js" "node --check '$APP_DIR/server/core.js'"

# ════════════════════════════════════════════════════════════════════
phase 6 "SERVEUR PERSISTANT — daemon systemd, survit à la fermeture du PC"
# ════════════════════════════════════════════════════════════════════
# Exécution en node pur (HEADLESS) : le daemon tourne SANS fenêtre, au boot.
# La fenêtre Electron n'est qu'un client qui se branche dessus.
NODE_BIN="$(command -v node || echo /usr/bin/node)"
mkdir -p "$HOME/.config/systemd/user"

if command -v systemctl >/dev/null 2>&1 && systemctl --user daemon-reload >/dev/null 2>&1; then
  UNIT="$HOME/.config/systemd/user/aether.service"
  cat > "$UNIT" <<AE_UNIT
[Unit]
Description=NEXUS AETHER v3 — daemon agentique persistant (serveur réel)
After=network.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
Environment=AETHER_PORT=$PORT
Environment=AETHER_ROOT=$APP_DIR
Environment=AETHER_WORKSPACE=$WORKSPACE
Environment=AETHER_HEADLESS=1
Environment=NODE_ENV=production
EnvironmentFile=-$CONF_DIR/env
ExecStart=$NODE_BIN $APP_DIR/server/core.js
Restart=always
RestartSec=3

[Install]
WantedBy=default.target
AE_UNIT
  ok "unité daemon écrite : $UNIT (ExecStart = node pur, Restart=always)"
  systemctl --user daemon-reload >/dev/null 2>&1 || true
  if systemctl --user enable --now aether.service >/dev/null 2>&1; then
    ok "daemon ACTIVÉ — démarre au boot de la session, redémarre tout seul si tu le tues"
  else
    warn "activation auto impossible — à la main : systemctl --user enable --now aether.service"
  fi
  if [ "${AETHER_SKIP_LINGER:-0}" != "1" ]; then
    if loginctl enable-linger "$USER" >/dev/null 2>&1; then
      ok "linger activé — le daemon tourne même AVANT que tu ouvres ta session"
    else
      warn "linger nécessite une fois le mot de passe : sudo loginctl enable-linger $USER"
    fi
  fi
else
  warn "systemd indisponible ici — le lanceur démarrera le serveur en node pur (comportement dégradé mais fonctionnel)"
fi

# ── Option Ollama auto-démarré (modifiable à tout moment dans Réglages IA) ──
OLLAMA_BIN="$(command -v ollama || true)"
OLLAMA_AUTOSTART="${AETHER_OLLAMA_AUTOSTART:-}"
if [ -z "$OLLAMA_AUTOSTART" ]; then
  if [ -n "$OLLAMA_BIN" ]; then OLLAMA_AUTOSTART=1; else OLLAMA_AUTOSTART=0; fi
fi
SYSTEM_OLLAMA=0
if command -v systemctl >/dev/null 2>&1 && systemctl cat ollama.service >/dev/null 2>&1; then SYSTEM_OLLAMA=1; fi
if [ "$OLLAMA_AUTOSTART" = "1" ] && [ -n "$OLLAMA_BIN" ] && command -v systemctl >/dev/null 2>&1 \
   && systemctl --user daemon-reload >/dev/null 2>&1; then
  if [ "$SYSTEM_OLLAMA" = "1" ]; then
    ok "Ollama déjà servi par le système (ollama.service) — rien à doubler"
  else
    UNIT_O="$HOME/.config/systemd/user/aether-ollama.service"
    cat > "$UNIT_O" <<AE_OLLA
[Unit]
Description=Ollama — moteur IA local pour NEXUS AETHER
After=network.target

[Service]
Type=simple
ExecStart=$OLLAMA_BIN serve
Environment=OLLAMA_HOST=127.0.0.1:11434
Environment=OLLAMA_KEEP_ALIVE=24h
Restart=always
RestartSec=3

[Install]
WantedBy=default.target
AE_OLLA
    systemctl --user daemon-reload >/dev/null 2>&1 || true
    if systemctl --user enable --now aether-ollama.service >/dev/null 2>&1; then
      ok "Ollama se lancera TOUT SEUL au boot (unité : aether-ollama.service)"
    else
      warn "active à la main si besoin : systemctl --user enable --now aether-ollama.service"
    fi
  fi
else
  if [ -z "$OLLAMA_BIN" ]; then
    info "Ollama absent — l'IA maîtresse utilisera le repli cléless réel (Pollinations). Installe Ollama quand tu veux."
  fi
fi
# synchronise la config avec le choix (l'UI permet de changer ensuite)
node -e '
const fs = require("fs");
const f = process.argv[1];
try {
  const c = JSON.parse(fs.readFileSync(f, "utf8"));
  c.agentique = c.agentique || {};
  c.agentique.ollamaAutoStart = (process.argv[2] === "1");
  fs.writeFileSync(f, JSON.stringify(c, null, 2) + "\n");
} catch (e) {}
' "$APP_DIR/config/plugins.json" "$OLLAMA_AUTOSTART" 2>/dev/null || true
cp "$APP_DIR/config/plugins.json" "$CONF_DIR/plugins.json" 2>/dev/null || true

# ── Lanceur v3 : branche au daemon, sinon le démarre, puis ouvre la fenêtre ──
cat > scripts/aether-launch.sh <<'AE_LCH_V3'
#!/usr/bin/env bash
# NEXUS AETHER v3 — lanceur production.
# 1) daemon systemd vivant ? → on s'y branche
# 2) sinon → systemctl --user start aether
# 3) sinon → node pur en arrière-plan (filet de sécurité)
# puis ouverture de la fenêtre (simple cliente).
set -uo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export AETHER_PORT="${AETHER_PORT:-8420}"
export AETHER_ROOT="$DIR"
export AETHER_WORKSPACE="$DIR/workspace"
mkdir -p "$HOME/.aether" "$AETHER_WORKSPACE"
HEALTH="http://127.0.0.1:$AETHER_PORT/api/health"
if ! curl -s --max-time 2 "$HEALTH" >/dev/null 2>&1; then
  if command -v systemctl >/dev/null 2>&1 && systemctl --user cat aether.service >/dev/null 2>&1; then
    systemctl --user start aether.service >/dev/null 2>&1 || true
    for i in 1 2 3 4 5 6 7 8; do
      curl -s --max-time 1 "$HEALTH" >/dev/null 2>&1 && break
      sleep 1
    done
  fi
fi
if ! curl -s --max-time 2 "$HEALTH" >/dev/null 2>&1; then
  NODE_BIN="$(command -v node || echo /usr/bin/node)"
  nohup "$NODE_BIN" "$DIR/server/core.js" >> "$DIR/aether.log" 2>&1 &
  disown 2>/dev/null || true
  for i in 1 2 3 4 5 6 7 8 9 10; do
    curl -s --max-time 1 "$HEALTH" >/dev/null 2>&1 && break
    sleep 1
  done
fi
ELECTRON_BIN="$DIR/node_modules/.bin/electron"
[ -x "$ELECTRON_BIN" ] || ELECTRON_BIN="$DIR/node_modules/electron/dist/electron"
if [ -x "$ELECTRON_BIN" ]; then
  nohup "$ELECTRON_BIN" "$DIR" >> "$DIR/aether.log" 2>&1 &
  disown 2>/dev/null || true
  echo "◉ NEXUS AETHER v3 — fenêtre ouverte · daemon : $HEALTH"
else
  echo "◉ NEXUS AETHER v3 — serveur en ligne : $HEALTH (Electron absent, utilise l'URL dans un navigateur)"
fi
AE_LCH_V3
chmod +x scripts/aether-launch.sh
ok "scripts/aether-launch.sh v3 — branchement daemon + filets de sécurité"

cat > scripts/aether-stop.sh <<'AE_STP_V3'
#!/usr/bin/env bash
# NEXUS AETHER v3 — arrêt : fenêtre puis daemon (le daemon ne meurt JAMAIS seul :
# Restart=always. C'est CE script, ou systemctl --user stop, qui l'arrête vraiment).
set -uo pipefail
pkill -f "Aether/node_modules/electron" 2>/dev/null || true
command -v systemctl >/dev/null 2>&1 && systemctl --user stop aether.service 2>/dev/null
PIDF="$HOME/.aether/aether.pid"
if [ -f "$PIDF" ]; then
  PID="$(cat "$PIDF" 2>/dev/null || true)"
  [ -n "${PID:-}" ] && kill "$PID" 2>/dev/null
  rm -f "$PIDF"
fi
echo "◉ NEXUS AETHER v3 arrêté (fenêtre + daemon)"
exit 0
AE_STP_V3
chmod +x scripts/aether-stop.sh
ok "scripts/aether-stop.sh v3 — arrêt explicite (le daemon ne meurt plus par accident)"
chk "syntaxe lanceur" "bash -n '$APP_DIR/scripts/aether-launch.sh'"

# ════════════════════════════════════════════════════════════════════
phase 7 "VISUEL PRODUCTION — dock Agents · Moniteur OS · Réglages IA"
# ════════════════════════════════════════════════════════════════════
# Un seul fichier : ui/v3.js. Il crée son propre dock et ses panneaux —
# AUCUNE modification invasive du thème OMEGA existant.

cat > ui/v3.js <<'AE_UI_V3'
'use strict';
/* NEXUS AETHER v3 — poste agentique : dock + panneaux (Agents, Moniteur OS, Réglages IA). */
(function () {
  if (window.__AETHER_V3__) return;
  window.__AETHER_V3__ = true;

  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function fmtDur(ms) {
    var s = Math.round(ms / 1000);
    if (s < 60) return s + ' s';
    var m = Math.floor(s / 60);
    if (m < 60) return m + ' min ' + (s % 60) + ' s';
    return Math.floor(m / 60) + ' h ' + (m % 60) + ' min';
  }
  function chip(status) {
    var cls = { 'en-file': 'av3-chip-wait', 'en-cours': 'av3-chip-run', 'terminé': 'av3-chip-ok',
                'échec': 'av3-chip-ko', 'annulé': 'av3-chip-cancel', 'interrompu': 'av3-chip-int' }[status] || 'av3-chip-wait';
    return '<span class="av3-chip ' + cls + '">' + esc(status) + '</span>';
  }

  /* ── Dock ─────────────────────────────────────────────────────────── */
  var dock = el('div', 'av3-dock');
  dock.innerHTML =
    '<button class="av3-dock-btn" id="av3-open-agents" title="Agents en arrière-plan">🤖<small>Agents</small></button>' +
    '<button class="av3-dock-btn" id="av3-open-sysmon" title="Moniteur OS agentique">📊<small>OS</small></button>' +
    '<button class="av3-dock-btn" id="av3-open-ia" title="Réglages IA réelle">⚙️<small>IA</small></button>';
  document.body.appendChild(dock);

  var panel = el('div', 'av3-panel');
  panel.innerHTML = '<div class="av3-panel-head"><span id="av3-panel-title"></span>' +
                    '<button class="av3-x" id="av3-close">✕</button></div>' +
                    '<div class="av3-panel-body" id="av3-panel-body"></div>';
  document.body.appendChild(panel);
  var body = document.getElementById('av3-panel-body');
  var title = document.getElementById('av3-panel-title');
  var current = null;
  var timers = [];

  function clearTimers() { timers.forEach(function (t) { clearInterval(t); }); timers = []; }
  function openPanel(name) {
    current = name;
    panel.classList.add('av3-open');
    clearTimers();
    if (name === 'agents') renderAgents();
    if (name === 'sysmon') renderSysmon();
    if (name === 'ia') renderIA();
  }
  function closePanel() { current = null; panel.classList.remove('av3-open'); clearTimers(); }
  document.getElementById('av3-close').onclick = closePanel;
  document.getElementById('av3-open-agents').onclick = function () { current === 'agents' ? closePanel() : openPanel('agents'); };
  document.getElementById('av3-open-sysmon').onclick = function () { current === 'sysmon' ? closePanel() : openPanel('sysmon'); };
  document.getElementById('av3-open-ia').onclick = function () { current === 'ia' ? closePanel() : openPanel('ia'); };

  function api(path, opts) {
    return fetch(path, opts || {}).then(function (r) {
      var ct = r.headers.get('content-type') || '';
      return (ct.indexOf('json') !== -1) ? r.json() : r.text();
    });
  }

  /* ── Panneau AGENTS ───────────────────────────────────────────────── */
  var detailId = null;
  function renderAgents() {
    title.innerHTML = '🤖 Agents en arrière-plan';
    body.innerHTML =
      '<div class="av3-new-agent">' +
      '<textarea id="av3-task" rows="3" placeholder="Tâche pour l\u2019agent — ex : « Rédige un plan de test pour mon script bash et note les risques »"></textarea>' +
      '<button class="av3-btn" id="av3-launch">⚡ Lancer l\u2019agent</button>' +
      '<span class="av3-hint">file réelle dans le daemon — fermer la fenêtre n\u2019arrête rien</span></div>' +
      '<div id="av3-agent-list" class="av3-list"></div>' +
      '<div id="av3-agent-detail"></div>';
    document.getElementById('av3-launch').onclick = function () {
      var t = document.getElementById('av3-task').value.trim();
      if (!t) return;
      api('/api/agents', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ task: t }) })
        .then(function (r) {
          if (r && r.ok) { document.getElementById('av3-task').value = ''; detailId = r.agent.id; refreshAgents(); }
          else alert(r && r.error ? r.error : 'création impossible');
        });
    };
    refreshAgents();
    timers.push(setInterval(refreshAgents, 3000));
  }
  function refreshAgents() {
    if (current !== 'agents') return;
    api('/api/agents').then(function (r) {
      var list = (r && r.agents) || [];
      var box = document.getElementById('av3-agent-list');
      if (!box) return;
      if (!list.length) { box.innerHTML = '<div class="av3-empty">Aucun agent encore lancé. Écris une tâche ci-dessus ⚡</div>'; }
      else {
        box.innerHTML = list.map(function (a) {
          return '<div class="av3-agent' + (a.id === detailId ? ' av3-agent-sel' : '') + '" data-id="' + a.id + '">' +
            '<div class="av3-agent-top"><span class="av3-agent-id">' + esc(a.id) + '</span>' + chip(a.status) + '</div>' +
            '<div class="av3-agent-task">' + esc(a.task.slice(0, 110)) + '</div>' +
            (a.steps && a.steps.length ? '<div class="av3-agent-steps">' + a.steps.length + ' étapes · étape ' + (a.stepIndex + 1) + '</div>' : '') +
            '</div>';
        }).join('');
        Array.prototype.forEach.call(box.querySelectorAll('.av3-agent'), function (d) {
          d.onclick = function () { detailId = d.getAttribute('data-id'); refreshAgents(); };
        });
      }
      renderAgentDetail();
    }).catch(function () {});
  }
  function renderAgentDetail() {
    var box = document.getElementById('av3-agent-detail');
    if (!box || !detailId) { if (box) box.innerHTML = ''; return; }
    api('/api/agents/' + detailId).then(function (r) {
      var a = r && r.agent;
      if (!a) { box.innerHTML = ''; return; }
      var stepsHtml = (a.steps || []).map(function (s, i) {
        var ic = s.status === 'terminé' ? '✓' : (s.status === 'en-cours' ? '⟳' : '·');
        var cls = s.status === 'terminé' ? 'ok' : (s.status === 'en-cours' ? 'run' : 'wait');
        return '<div class="av3-step av3-step-' + cls + '"><span class="av3-step-ic">' + ic + '</span> Étape ' + (i + 1) + ' — ' + esc(s.label) + '</div>';
      }).join('');
      var logHtml = (a.log || []).slice(-10).map(function (l) { return '<div>' + esc(new Date(l.t).toLocaleTimeString() + ' · ' + l.line) + '</div>'; }).join('');
      box.innerHTML =
        '<div class="av3-detail">' +
        '<div class="av3-detail-head"><b>' + esc(a.id) + '</b> ' + chip(a.status) +
        ' <button class="av3-btn-sm" id="av3-cancel">annuler</button></div>' +
        '<div class="av3-steps">' + (stepsHtml || '<i>planification…</i>') + '</div>' +
        '<div class="av3-log">' + (logHtml || '<i>journal vide</i>') + '</div>' +
        (a.resultFile ? '<button class="av3-btn-sm" id="av3-result">📄 voir le résultat</button>' : '') +
        (a.error ? '<div class="av3-err">' + esc(a.error) + '</div>' : '') +
        '<div id="av3-result-view"></div></div>';
      var cb = document.getElementById('av3-cancel');
      if (cb) cb.onclick = function () {
        api('/api/agents/' + a.id + '/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })
          .then(function () { refreshAgents(); });
      };
      var rb = document.getElementById('av3-result');
      if (rb) rb.onclick = function () {
        fetch('/api/agents/' + a.id + '/result').then(function (x) { return x.text(); }).then(function (t) {
          document.getElementById('av3-result-view').innerHTML = '<pre class="av3-result">' + esc(t.slice(0, 6000)) + '</pre>';
        });
      };
    }).catch(function () {});
  }
  timers.push(setInterval(function () { if (current === 'agents' && detailId) renderAgentDetail(); }, 2500));

  /* ── Panneau MONITEUR OS ──────────────────────────────────────────── */
  function renderSysmon() {
    title.innerHTML = '📊 Moniteur OS agentique';
    body.innerHTML = '<div id="av3-sys"></div>';
    refreshSysmon();
    timers.push(setInterval(refreshSysmon, 2000));
  }
  function refreshSysmon() {
    if (current !== 'sysmon') return;
    api('/api/sysmon').then(function (r) {
      var s = r && r.sysmon;
      var box = document.getElementById('av3-sys');
      if (!s || !box) return;
      var rows = (s.procs || []).map(function (p) {
        return '<tr' + (p.tag ? ' class="av3-tagged"' : '') + '><td>' + p.pid + '</td><td class="av3-cmd">' + esc(p.cmd) + '</td>' +
               '<td>' + p.cpu + '%</td><td>' + p.rssMb + ' Mo</td>' +
               (p.tag ? '<td><span class="av3-tag">' + esc(p.tag) + '</span></td>' : '<td></td>') + '</tr>';
      }).join('');
      box.innerHTML =
        '<div class="av3-gauges">' +
        '<div class="av3-gauge"><label>CPU global <b>' + s.cpu + '%</b> · ' + s.cpuCores + ' cœurs</label>' +
        '<div class="av3-bar"><i style="width:' + s.cpu + '%"></i></div></div>' +
        '<div class="av3-gauge"><label>RAM <b>' + s.ramUsedMb + '</b> / ' + s.ramTotalMb + ' Mo (' + s.ramPct + '%)</label>' +
        '<div class="av3-bar"><i style="width:' + s.ramPct + '%"></i></div></div>' +
        '<div class="av3-gauge"><label>Charge (1/5/15 min) <b>' + s.load.join(' · ') + '</b></label>' +
        '<div class="av3-bar"><i style="width:' + Math.min(100, s.load[0] * 100 / s.cpuCores) + '%"></i></div></div>' +
        '<div class="av3-gauge"><label>Uptime machine <b>' + fmtDur(s.uptimeS * 1000) + '</b> · daemon pid ' + s.serverPid + '</label></div>' +
        '</div>' +
        '<table class="av3-table"><thead><tr><th>PID</th><th>Commande</th><th>CPU</th><th>RAM</th><th></th></tr></thead>' +
        '<tbody>' + (rows || '<tr><td colspan="5"><i>lecture /proc…</i></td></tr>') + '</tbody></table>' +
        '<div class="av3-hint">lectures réelles dans /proc — repère <span class="av3-tag">ollama</span> et <span class="av3-tag">aether</span></div>';
    }).catch(function () {});
  }

  /* ── Panneau RÉGLAGES IA ──────────────────────────────────────────── */
  function renderIA() {
    title.innerHTML = '⚙️ Réglages IA réelle';
    body.innerHTML = '<div id="av3-ia"><div class="av3-empty">lecture de la config…</div></div>';
    refreshIA();
  }
  function refreshIA() {
    api('/api/ia').then(function (s) {
      if (!s || !s.ok) return;
      var box = document.getElementById('av3-ia');
      if (!box) return;
      var cards = (s.providers || []).map(function (p) {
        return '<div class="av3-prov' + (p.id === s.active ? ' av3-prov-active' : '') + '" data-id="' + p.id + '">' +
          '<div class="av3-prov-top"><b>' + esc(p.name) + '</b>' +
          (p.id === s.active ? '<span class="av3-tag av3-tag-on">ACTIVE</span>' : '') + '</div>' +
          '<div class="av3-prov-sub">type : ' + esc(p.type) + ' · modèle : ' + esc(p.model) +
          (p.keySet ? ' · <span class="av3-oktxt">clé ✓</span>' : (p.type === 'gemini' || p.type === 'openai') ? ' · <span class="av3-errtxt">clé absente</span>' : ' · <span class="av3-oktxt">sans clé</span>') +
          (p.fallback ? ' · repli : ' + esc(p.fallback) : '') + '</div>' +
          '<div class="av3-prov-actions"><button class="av3-btn-sm av3-test" data-id="' + p.id + '">⚡ Tester (vrai appel)</button>' +
          (p.id !== s.active ? '<button class="av3-btn-sm av3-use" data-id="' + p.id + '">utiliser</button>' : '') +
          '<span class="av3-test-out" data-out="' + p.id + '"></span></div></div>';
      }).join('');
      var o = s.ollama || {};
      var ag = s.agentique || {};
      box.innerHTML = cards +
        '<div class="av3-prov"><div class="av3-prov-top"><b>Ollama</b>' +
        (o.present ? '<span class="av3-tag av3-tag-on">en ligne</span>' : '<span class="av3-tag">absent — repli cléless actif</span>') + '</div>' +
        '<div class="av3-prov-sub">modèles installés : ' + (o.models && o.models.length ? esc(o.models.join(', ')) : '<i>aucun — ollama pull llama3.2:1b</i>') + '</div>' +
        '<div class="av3-prov-actions"><label class="av3-switch"><input type="checkbox" id="av3-ollastart"' + (ag.ollamaAutoStart ? ' checked' : '') + '> Ollama se lance TOUT SEUL au boot</label></div></div>' +
        '<div class="av3-prov"><div class="av3-prov-top"><b>Agents</b></div>' +
        '<div class="av3-prov-actions"><label>agents en parallèle : <input type="number" id="av3-maxc" min="1" max="4" value="' + (ag.maxConcurrent || 2) + '" style="width:52px"></label>' +
        '<button class="av3-btn-sm" id="av3-save-ag">enregistrer</button></div></div>';
      Array.prototype.forEach.call(box.querySelectorAll('.av3-test'), function (b) {
        b.onclick = function () {
          var id = b.getAttribute('data-id');
          var out = box.querySelector('[data-out="' + id + '"]');
          out.textContent = ' appel réel en cours…';
          api('/api/ia/test', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: id }) })
            .then(function (r) {
              out.innerHTML = r && r.ok
                ? '<span class="av3-oktxt"> ✓ ' + r.ms + ' ms — « ' + esc((r.extrait || '').slice(0, 40)) + ' »</span>'
                : '<span class="av3-errtxt"> ✗ ' + esc((r && r.error) || 'échec') + '</span>';
            });
        };
      });
      Array.prototype.forEach.call(box.querySelectorAll('.av3-use'), function (b) {
        b.onclick = function () {
          api('/api/ia/active', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: b.getAttribute('data-id') }) })
            .then(function () { refreshIA(); });
        };
      });
      var oa = document.getElementById('av3-ollastart');
      if (oa) oa.onchange = function () {
        api('/api/ia/ollama-autostart', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ on: oa.checked }) })
          .then(function (r) { alert(r && r.note ? r.note : 'enregistré'); });
      };
      var sa = document.getElementById('av3-save-ag');
      if (sa) sa.onclick = function () {
        var v = parseInt(document.getElementById('av3-maxc').value, 10) || 2;
        api('/api/ia/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ maxConcurrent: v }) })
          .then(function () { sa.textContent = '✓ enregistré'; });
      };
    }).catch(function (e) {
      var box = document.getElementById('av3-ia');
      if (box) box.innerHTML = '<div class="av3-empty">daemon v3 injoignable</div>';
    });
  }

  console.log('[aether-v3] poste agentique prêt — dock en bas à droite');
})();
AE_UI_V3
ok "ui/v3.js — dock Agents / Moniteur OS / Réglages IA (polling réel, aucun framework)"
chk "syntaxe ui/v3.js" "node --check '$APP_DIR/ui/v3.js'"

# ── Styles v3 (ajoutés à la fin : le thème OMEGA reste intact) ──────────
cat >> ui/style.css <<'AE_CSS_V3'

/* ═══ AETHER V3 — poste agentique (dock + panneaux) ═══ */
.av3-dock { position: fixed; right: 18px; bottom: 18px; z-index: 9000; display: flex; gap: 8px;
  padding: 8px; border-radius: 16px; background: rgba(10, 12, 28, .82); border: 1px solid rgba(64, 224, 255, .25);
  box-shadow: 0 8px 32px rgba(0, 0, 0, .55); backdrop-filter: blur(10px); }
.av3-dock-btn { display: flex; flex-direction: column; align-items: center; gap: 2px; width: 62px;
  padding: 8px 4px; border-radius: 12px; border: 1px solid transparent; background: transparent;
  color: #bfe9ff; cursor: pointer; font: 600 11px/1.2 system-ui, sans-serif; }
.av3-dock-btn small { font-size: 9px; opacity: .75; letter-spacing: .04em; }
.av3-dock-btn:hover { background: rgba(64, 224, 255, .12); border-color: rgba(64, 224, 255, .35); }
.av3-panel { position: fixed; top: 0; right: -560px; width: 540px; max-width: 94vw; height: 100vh; z-index: 9100;
  background: rgba(8, 10, 24, .96); border-left: 1px solid rgba(64, 224, 255, .3);
  box-shadow: -18px 0 48px rgba(0, 0, 0, .6); transition: right .25s ease; display: flex; flex-direction: column; }
.av3-panel.av3-open { right: 0; }
.av3-panel-head { display: flex; align-items: center; justify-content: space-between; padding: 14px 18px;
  border-bottom: 1px solid rgba(64, 224, 255, .18); color: #7ee7ff; font: 700 14px system-ui, sans-serif; }
.av3-x { background: none; border: none; color: #7ee7ff; font-size: 16px; cursor: pointer; }
.av3-panel-body { flex: 1; overflow-y: auto; padding: 14px 18px; color: #d7e6f5; font: 13px/1.5 system-ui, sans-serif; }
.av3-new-agent textarea { width: 100%; background: #0b0e22; color: #d7e6f5; border: 1px solid rgba(64, 224, 255, .3);
  border-radius: 10px; padding: 10px; font: 13px/1.5 inherit; resize: vertical; }
.av3-btn { margin-top: 8px; padding: 9px 16px; border-radius: 10px; border: 1px solid rgba(64, 224, 255, .5);
  background: linear-gradient(135deg, rgba(64, 224, 255, .2), rgba(64, 224, 255, .08)); color: #aef1ff;
  cursor: pointer; font-weight: 700; }
.av3-btn:hover { background: rgba(64, 224, 255, .25); }
.av3-btn-sm { padding: 4px 10px; border-radius: 8px; border: 1px solid rgba(64, 224, 255, .4); background: transparent;
  color: #aef1ff; cursor: pointer; font-size: 12px; margin-right: 6px; }
.av3-btn-sm:hover { background: rgba(64, 224, 255, .15); }
.av3-hint { display: block; margin-top: 6px; color: #6b7f99; font-size: 11px; }
.av3-list { margin-top: 12px; display: flex; flex-direction: column; gap: 8px; }
.av3-agent { padding: 10px 12px; border-radius: 12px; background: rgba(20, 26, 52, .6);
  border: 1px solid rgba(64, 224, 255, .14); cursor: pointer; }
.av3-agent-sel { border-color: rgba(64, 224, 255, .6); }
.av3-agent-top { display: flex; justify-content: space-between; align-items: center; gap: 8px; }
.av3-agent-id { font-family: ui-monospace, monospace; font-size: 11px; color: #7ee7ff; }
.av3-agent-task { margin-top: 4px; font-size: 12.5px; color: #d7e6f5; }
.av3-agent-steps { margin-top: 3px; font-size: 11px; color: #6b7f99; }
.av3-chip { padding: 2px 9px; border-radius: 99px; font-size: 10.5px; font-weight: 700; letter-spacing: .03em; }
.av3-chip-wait { background: rgba(140, 150, 170, .18); color: #aeb9c9; }
.av3-chip-run { background: rgba(64, 224, 255, .16); color: #7ee7ff; animation: av3pulse 1.4s infinite; }
.av3-chip-ok { background: rgba(46, 204, 113, .16); color: #7be3a6; }
.av3-chip-ko { background: rgba(231, 76, 60, .16); color: #ff9a8d; }
.av3-chip-cancel { background: rgba(241, 196, 15, .16); color: #ffe08a; }
.av3-chip-int { background: rgba(230, 126, 34, .16); color: #ffbf8a; }
@keyframes av3pulse { 50% { opacity: .55; } }
.av3-detail { margin-top: 14px; padding: 12px; border-radius: 12px; background: rgba(20, 26, 52, .5);
  border: 1px solid rgba(64, 224, 255, .18); }
.av3-detail-head { display: flex; align-items: center; gap: 10px; }
.av3-steps { margin-top: 10px; display: flex; flex-direction: column; gap: 6px; }
.av3-step { font-size: 12.5px; padding: 6px 10px; border-radius: 8px; background: rgba(10, 14, 32, .6); }
.av3-step-ok { color: #7be3a6; } .av3-step-run { color: #7ee7ff; } .av3-step-wait { color: #8b9bb0; }
.av3-step-ic { font-weight: 900; margin-right: 4px; }
.av3-log { margin-top: 10px; padding: 8px 10px; border-radius: 8px; background: #07091a;
  font: 11px/1.6 ui-monospace, monospace; color: #7f97b3; max-height: 160px; overflow-y: auto; }
.av3-result { margin-top: 10px; padding: 12px; border-radius: 10px; background: #07091a; color: #cde7ff;
  font: 12px/1.6 ui-monospace, monospace; white-space: pre-wrap; max-height: 320px; overflow-y: auto;
  border: 1px solid rgba(64, 224, 255, .2); }
.av3-err { margin-top: 8px; color: #ff9a8d; font-size: 12px; }
.av3-gauges { display: flex; flex-direction: column; gap: 12px; margin-bottom: 14px; }
.av3-gauge label { font-size: 12px; color: #9fb3c8; display: flex; justify-content: space-between; }
.av3-gauge label b { color: #7ee7ff; }
.av3-bar { margin-top: 5px; height: 10px; border-radius: 99px; background: rgba(20, 26, 52, .8); overflow: hidden; }
.av3-bar i { display: block; height: 100%; border-radius: 99px;
  background: linear-gradient(90deg, #22d3ee, #7c5cff); transition: width .6s ease; }
.av3-table { width: 100%; border-collapse: collapse; font-size: 11.5px; }
.av3-table th { text-align: left; color: #6b7f99; padding: 6px 8px; border-bottom: 1px solid rgba(64, 224, 255, .18); }
.av3-table td { padding: 5px 8px; border-bottom: 1px solid rgba(255, 255, 255, .05); color: #c3d3e3; }
.av3-table .av3-cmd { font-family: ui-monospace, monospace; font-size: 10.5px; color: #8ba3bd; max-width: 240px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.av3-table .av3-tagged td { background: rgba(64, 224, 255, .06); }
.av3-tag { padding: 1px 8px; border-radius: 99px; font-size: 10px; font-weight: 700;
  background: rgba(64, 224, 255, .14); color: #7ee7ff; }
.av3-tag-on { background: rgba(46, 204, 113, .18); color: #7be3a6; }
.av3-prov { margin-top: 10px; padding: 12px; border-radius: 12px; background: rgba(20, 26, 52, .55);
  border: 1px solid rgba(64, 224, 255, .14); }
.av3-prov-active { border-color: rgba(46, 204, 113, .45); }
.av3-prov-top { display: flex; justify-content: space-between; align-items: center; gap: 8px; color: #d7e6f5; }
.av3-prov-sub { margin-top: 4px; font-size: 12px; color: #8b9bb0; }
.av3-prov-actions { margin-top: 8px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; font-size: 12px; }
.av3-test-out { font-size: 12px; }
.av3-oktxt { color: #7be3a6; } .av3-errtxt { color: #ff9a8d; }
.av3-switch { display: flex; align-items: center; gap: 8px; cursor: pointer; color: #d7e6f5; }
.av3-empty { color: #6b7f99; font-style: italic; padding: 18px 0; text-align: center; }
AE_CSS_V3
ok "style.css — thème v3 ajouté (OMEGA intact)"

# ── index.html : une seule insertion (le script v3) ─────────────────────
node -e '
const fs = require("fs");
const f = process.argv[1];
let s = fs.readFileSync(f, "utf8");
if (s.indexOf("ui/v3.js") !== -1) { console.log("already"); process.exit(0); }
if (s.indexOf("</body>") === -1) { console.log("no-body"); process.exit(2); }
s = s.replace("</body>", "<script src=\"/ui/v3.js\"></script></body>");
fs.writeFileSync(f, s);
console.log("patched");
' "$APP_DIR/ui/index.html" 2>/dev/null || true
grep -q "ui/v3.js" "$APP_DIR/ui/index.html" \
  && ok "index.html — script v3 branché (dock apparaît dans la fenêtre)" \
  || warn "index.html : insertion à refaire (voir plus bas)"
chk "syntaxe index.html contient dock" "grep -q 'ui/v3.js' '$APP_DIR/ui/index.html'"

# ════════════════════════════════════════════════════════════════════
phase 8 "COMPILATION PRODUCTION — coffre app.asar, vérifs réelles, Bureau"
# ════════════════════════════════════════════════════════════════════
cd "$APP_DIR"
mkdir -p "$WORKSPACE"/{agents,textes,images,projets} build 2>/dev/null || true

# Dépendance temps réel présente ?
if node -e "require('ws')" >/dev/null 2>&1; then ok "module ws présent (terminal temps réel)"
else
  npm install --no-audit --no-fund --no-save --loglevel=error ws >/dev/null 2>&1 \
    && ok "module ws installé" || warn "ws absent — terminal sans WebSocket (le reste marche)"
fi

# Vérification syntaxique de TOUT le JavaScript v3 + cœur
SYNT_OK=1
for jf in main.js main-app.js preload.js server/core.js core/router.js core/agents.js core/sysmon.js core/aether-v3.js ui/v3.js; do
  if [ -f "$APP_DIR/$jf" ]; then
    if node --check "$APP_DIR/$jf" >/dev/null 2>&1; then ok "syntaxe : $jf"; else ko "syntaxe : $jf"; SYNT_OK=0; fi
  fi
done

# Auto-test du cœur sur un port jetable (serveur RÉEL, réponse RÉELLE)
SMOKE_PORT=$((PORT + 7))
if AETHER_PORT="$SMOKE_PORT" timeout 25 node server/core.js --smoke 2>/dev/null | grep -q "SMOKE_OK"; then
  ok "auto-test cœur : SMOKE_OK (port $SMOKE_PORT)"
else
  warn "auto-test cœur non concluant ici (port $SMOKE_PORT occupé ?) — le daemon reste prioritaire sur $PORT"
fi

# ── Coffre de production : le code cœur vit dans app.asar, plus lisible ──
LOADER_WRITTEN=0
if [ -f "$APP_DIR/main.js" ] && [ ! -f "$APP_DIR/main-app.js" ]; then
  cp "$APP_DIR/main.js" "$APP_DIR/main-app.js"
fi
cat > "$APP_DIR/main.js" <<'AE_LOADER_V3'
'use strict';
// NEXUS AETHER v3 — chargeur de production.
// Le cœur de l'app vit dans app.asar (code cœur non lisible dans le dossier).
// Si le coffre manque ou est cassé → repli TRANSPARENT sur main-app.js : rien ne casse.
try {
  require('./app.asar/main.js');
} catch (e) {
  console.error('[nexus-aether] coffre indisponible — repli local :', (e && e.message) || e);
  try { require('./main-app.js'); }
  catch (e2) { console.error('[nexus-aether] démarrage impossible :', (e2 && e2.message) || e2); process.exit(1); }
}
AE_LOADER_V3
ok "chargeur de production écrit (app.asar prioritaire, repli transparent)"
chk "syntaxe chargeur" "node --check '$APP_DIR/main.js'"

STAGE="$APP_DIR/.vault-stage"
rm -rf "$STAGE" && mkdir -p "$STAGE"
cp "$APP_DIR/main-app.js" "$STAGE/main.js"
for f in preload.js package.json; do [ -f "$APP_DIR/$f" ] && cp "$APP_DIR/$f" "$STAGE/"; done
for d in server core config ui build; do
  [ -d "$APP_DIR/$d" ] && mkdir -p "$STAGE/$d" && cp -r "$APP_DIR/$d/." "$STAGE/$d/"
done
rm -f "$STAGE/core/engine.js" "$STAGE/config/services.json" "$STAGE/ui/engine.js" 2>/dev/null || true
if (cd "$APP_DIR" && npx --yes @electron/asar pack .vault-stage app.asar >/dev/null 2>&1) && [ -s "$APP_DIR/app.asar" ]; then
  ok "coffre de production scellé : app.asar ($(du -h "$APP_DIR/app.asar" | cut -f1)) — code cœur plus lisible, repli automatique si casse"
  rm -rf "$STAGE"
else
  warn "scellement asar impossible ici — l'app fonctionne en clair (aucune casse, tu pourras resceller plus tard)"
  rm -rf "$STAGE"
fi

# ── Raccourci Bureau / menu ─────────────────────────────────────────
DESK_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
mkdir -p "$DESK_DIR"
cat > "$APP_DIR/build/nexus-aether.desktop" <<AE_DESK_V3
[Desktop Entry]
Type=Application
Name=NEXUS AETHER
Comment=Poste agentique — terminal, mémoire, agents arrière-plan, moniteur OS
Exec=$APP_DIR/scripts/aether-launch.sh
Icon=utilities-system-monitor
Terminal=false
Categories=Development;System;
StartupWMClass=nexus-aether
AE_DESK_V3
cp "$APP_DIR/build/nexus-aether.desktop" "$DESK_DIR/nexus-aether.desktop" 2>/dev/null || true
DESKTOP_USER="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Bureau")"
if [ -d "$DESKTOP_USER" ]; then
  cp "$APP_DIR/build/nexus-aether.desktop" "$DESKTOP_USER/nexus-aether.desktop" 2>/dev/null || true
  gio set "$DESKTOP_USER/nexus-aether.desktop" metadata::trusted true 2>/dev/null || true
  ok "raccourci posé : menu + $DESKTOP_USER"
else
  ok "raccourci posé : menu des applications"
fi

# ════════════════════════════════════════════════════════════════════
phase 9 "RAPPORT"
# ════════════════════════════════════════════════════════════════════
cat > "$APP_DIR/README.md" <<'AE_README_V3'
# NEXUS AETHER v3 — POSTE AGENTIQUE

**Aether = terminal réel + mémoire + agents en arrière-plan + moniteur OS + IA maîtresse réelle.**
Ce n'est PAS un hub de services : le hub (141 services) vit dans `~/Bureau/nexus-genedit/`
(genedit.py + genhub.sh), un projet séparé que cette installation ne touche jamais.

## Démarrage
- Menu des applications → **NEXUS AETHER**, ou : `~/Aether/scripts/aether-launch.sh`
- Le daemon persistant tourne SANS fenêtre : `systemctl --user status aether.service`
- Fermer la fenêtre n'arrête PAS le serveur ; redémarrer le PC le relance tout seul
  (systemd `Restart=always` + linger). Arrêt volontaire : `~/Aether/scripts/aether-stop.sh`.

## Agents (dock en bas à droite → 🤖)
- Écris une tâche → l'IA maîtresse planifie → les étapes s'exécutent en VRAI (appels IA réels)
- Résultat : `~/Aether/workspace/agents/<id>/result.md` · mémoire alimentée automatiquement
- La file vit dans le daemon : tu peux fermer la fenêtre, ça continue.

## IA réelle (dock → ⚙️)
- **Ollama** : modèle AUTO-DÉTECTÉ via `/api/tags` — plus jamais « model not found ».
  Un modèle manquant ? `ollama pull llama3.2:1b` (ou ton choix).
- **Repli cléless réel** : text.pollinations.ai (aucune clé) si Ollama est absent.
- Bouton **⚡ Tester** : un vrai appel API, ms réelles — pas de fausse option.
- Option « Ollama se lance tout seul » : cochable/décochable dans Réglages IA
  (unité systemd `aether-ollama.service`).

## Moniteur OS (dock → 📊)
Lectures réelles de `/proc` : CPU, RAM, charge, uptime, table des processus
avec repérage `ollama` / `aether`, pid du daemon.

## Séparation des projets
- `~/Aether` → poste agentique (CE dossier).
- `~/Bureau/nexus-genedit` → GenEdit (générateur CI/YAML) + GenHub (hub 141 services).
  Aucun fichier du hub ne vit dans Aether ; le catalogue ajouté par erreur a été retiré.

## Dépannage
- `journalctl --user -u aether.service -f` (logs daemon) · `curl http://127.0.0.1:8420/api/health`
- Sauvegardes : `~/Aether/.backup-v3-*` (et `.backup-v2-*` conservées).
- Re-sceller le coffre après modif : voir `npx @electron/asar pack` (le chargeur replie tout seul sinon).
AE_README_V3
ok "README.md v3 — identité, commandes, séparation des projets"

echo
if [ "$FAIL" -gt 0 ]; then
  echo -e "  ${C_RED}${C_B}✗ $FAIL contrôle(s) en échec — corrige avant d'investir du temps.${C_RST}"
  echo -e "  ${C_DIM}Sauvegarde : $BACKUP${C_RST}"
else
  echo -e "  ${C_GRN}${C_B}✦ NEXUS AETHER v3 — POSTE AGENTIQUE EN PLACE ($PASS contrôles verts).${C_RST}"
fi
echo
echo -e "  ${C_B}Maintenant :${C_RST}"
echo -e "   · lance  ${C_CYAN}$APP_DIR/scripts/aether-launch.sh${C_RST}  → fenêtre + dock en bas à droite"
echo -e "   · 🤖 Agents : écris une tâche, ça tourne en arrière-plan (résultat .md)"
echo -e "   · 📊 OS : CPU/RAM/processus réels · ⚙️ IA : bouton Tester = vrai appel"
echo -e "   · daemon : ${C_CYAN}systemctl --user status aether.service${C_RST} — survit aux fermetures"
echo -e "   · GenEdit + GenHub : ${C_DIM}~/Bureau/nexus-genedit — intouchés, comme convenu${C_RST}"
echo
