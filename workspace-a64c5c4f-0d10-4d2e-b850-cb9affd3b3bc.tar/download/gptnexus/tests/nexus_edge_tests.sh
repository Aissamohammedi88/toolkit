#!/usr/bin/env bash
# GPTNexus edge test bench — 22 tests (N01-N22)
# DGK x GLM — protocole ULTRA. Preuve d'exécution pour chaque capacité.
# v1.1 NOBLE : N14-N22 = Language Systémique NEXUS-COBOL + ContextEngine.
set -uo pipefail

NX_HOME="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export PATH="$HOME/.cargo/bin:$PATH"
SCAN_BIN="$NX_HOME/scanner/target/release/nexus_scan"
FIX="$NX_HOME/fixtures"
CORE="$NX_HOME/nexus_core.py"

PASS=0; FAIL=0; FAILED_TESTS=()

c_red()   { printf '\033[31m%s\033[0m' "$*"; }
c_green() { printf '\033[32m%s\033[0m' "$*"; }
c_yellow(){ printf '\033[33m%s\033[0m' "$*"; }

t() {
    local id="$1"; shift
    local desc="$1"; shift
    if "$@" >/tmp/nx_test_out 2>&1; then
        printf "  [$(c_green PASS)] %s  %s\n" "$id" "$desc"
        PASS=$((PASS+1))
    else
        printf "  [$(c_red   FAIL)] %s  %s\n" "$id" "$desc"
        sed 's/^/        | /' /tmp/nx_test_out | tail -8
        FAIL=$((FAIL+1))
        FAILED_TESTS+=("$id")
    fi
}

# ---- setup ---------------------------------------------------------------
if [[ ! -x "$SCAN_BIN" ]]; then
    ( cd "$NX_HOME/scanner" && cargo build --release ) >/tmp/nx_build.log 2>&1 || {
        cat /tmp/nx_build.log
        echo "FATAL: cargo build failed in setup" >&2
        exit 1
    }
fi

# sandbox frais pour les tests qui patchent (les fixtures restent vierges)
SB="/tmp/nx_sandbox_$$"
mkdir -p "$SB"
cp "$FIX"/vuln_eval.py "$FIX"/vuln_sql.py "$FIX"/vuln_import.py "$FIX"/safe_code.py "$SB/"
cleanup() { rm -rf "$SB" /tmp/nx_test_out /tmp/nx_build.log; }
trap cleanup EXIT

echo "$(c_yellow "GPTNexus edge bench — 22 tests (protocole ULTRA)")"
echo ""

# N01 — scanner compilé et versionne
t N01 "nexus_scan compilé, --version exit 0" \
    "$SCAN_BIN" --version

# N02 — Finding : eval détecté
t N02 "scanner détecte eval dans vuln_eval.py (R001)" \
    python3 -c "
import json, subprocess, sys
r = json.loads(subprocess.run([sys.argv[1], sys.argv[2]], capture_output=True, text=True).stdout)
assert any(f['rule'] == 'eval' for f in r['findings']), r
print('ok:', [f['rule'] for f in r['findings']])
" "$SCAN_BIN" "$FIX/vuln_eval.py"

# N03 — Finding : SQL concat détecté
t N03 "scanner détecte sql_concat dans vuln_sql.py (R004)" \
    python3 -c "
import json, subprocess, sys
r = json.loads(subprocess.run([sys.argv[1], sys.argv[2]], capture_output=True, text=True).stdout)
assert any(f['rule'] == 'sql_concat' for f in r['findings']), r
print('ok:', [f['rule'] for f in r['findings']])
" "$SCAN_BIN" "$FIX/vuln_sql.py"

# N04 — Finding : __import__ détecté
t N04 "scanner détecte dyn_import dans vuln_import.py (R003)" \
    python3 -c "
import json, subprocess, sys
r = json.loads(subprocess.run([sys.argv[1], sys.argv[2]], capture_output=True, text=True).stdout)
assert any(f['rule'] == 'dyn_import' for f in r['findings']), r
print('ok:', [f['rule'] for f in r['findings']])
" "$SCAN_BIN" "$FIX/vuln_import.py"

# N05 — anti-faux-positif : le code sain doit rester à 0
t N05 "scanner silencieux sur safe_code.py (0 détection)" \
    python3 -c "
import json, subprocess, sys
r = json.loads(subprocess.run([sys.argv[1], sys.argv[2]], capture_output=True, text=True).stdout)
assert r['count'] == 0, f'faux positif ! {r}'
print('ok: 0 findings sur code sain')
" "$SCAN_BIN" "$FIX/safe_code.py"

# N06 — ExploitGym : eval CONFIRMÉ par sonde contrôlée
t N06 "sonde eval CONFIRME l'exécution arbitraire (pid retourné)" \
    python3 "$CORE" exploit "$SB/vuln_eval.py" eval --json

# N07 — ExploitGym : injection SQL CONFIRMÉE
t N07 "sonde sql CONFIRME l'injection (1 OR 1=1 dans la requête)" \
    python3 "$CORE" exploit "$SB/vuln_sql.py" sql_concat --json

# N08 — Patching : eval patché + re-scan propre
t N08 "patch eval RÉUSSI + re-scan 0 détection" \
    bash -c '
        python3 "$0" patch "$1" eval --json
        "$2" "$1" | python3 -c "import json,sys; r=json.load(sys.stdin); assert not any(f[\"rule\"]==\"eval\" for f in r[\"findings\"]), r; print(\"rescan ok\")"
    ' "$CORE" "$SB/vuln_eval.py" "$SCAN_BIN"

# N09 — Long-horizon : le registre exige une impasse traversée AVANT succès
# (ULTRA: L — la persistance n'est pas une promesse, c'est une donnée lue)
t N09 "mission.json : >= 1 dead_end ET final == success (persistance prouvée)" \
    python3 -c "
import json
m = json.load(open('$SB/.nexus/mission.json'))
assert m['dead_ends'] >= 1, f'aucune impasse enregistrée : {m[\"dead_ends\"]}'
assert m['final'] == 'success', f'final={m[\"final\"]}'
print(f\"ok: {m['dead_ends']} impasse(s) traversée(s) avant succès — persistance prouvée\")
"

# N10 — sécurité : l'exploit est BLOQUÉ après patch
t N10 "sonde eval BLOQUÉE sur le fichier patché" \
    python3 "$CORE" exploit "$SB/vuln_eval.py" eval --json

# N11 — le patch préserve l'usage légitime (pas de patch qui casse tout)
# [harness fix] bash -c: le 1er arg positionnel est $0 — il faut un "_" placeholder
# avant les vrais args, sinon $1 est vide (bug attrapé au 1er passage).
t N11 "fichier patché compile ET '1+1' -> 2 (usage légitime préservé)" \
    bash -c '
        python3 -m py_compile "$1"
        out=$(python3 "$1" "1+1")
        [ "$out" = "2" ] && echo "legit ok: 1+1 -> $out"
    ' _ "$SB/vuln_eval.py"

# N12 — cerveau GLM branché en vrai (famille glm [ai-brain])
t N12 "GLM répond via z-ai (avis [glm-advisory] non vide)" \
    bash -c '
        out=$(python3 "$0" ask "Réponds en un seul mot: OK")
        echo "$out" | grep -q "\[glm-advisory\]"
        lines=$(echo "$out" | grep "\[glm-advisory\]" | sed "s/\[glm-advisory\] //" | tr -d "[:space:]")
        [ -n "$lines" ] && echo "glm advisory ok"
    ' "$CORE"

# N13 — autonomie : sweep de bout en bout sur le sandbox
t N13 "sweep autonome : 3 findings -> 3 confirmés -> patchés -> rescan 0 -> final=success" \
    bash -c '
        # vuln_import doit aussi être patché ; on relance un sweep complet
        python3 "$0" sweep "$1" --json
    ' "$CORE" "$SB"

# ============================================================
# v1.1 NOBLE — Language Systémique NEXUS-COBOL + ContextEngine
# ============================================================
PROG="$NX_HOME/programs"

cd "$NX_HOME"   # les programmes .nxc utilisent des chemins relatifs au projet

# N14 — Language Systémique : arithmétique + DISPLAY exact
t N14 "NEXUS-COBOL hello : DISPLAY/MOVE/COMPUTE/PERFORM exacts" \
    bash -c '
        out=$(python3 "$0" cobol "$1")
        echo "$out" | grep -q "SALUT DGK"
        echo "$out" | grep -q "COMPTE=5"
        echo "$out" | grep -q "DOUBLE=10"
        echo "ok: SALUT DGK / COMPTE=5 / DOUBLE=10"
    ' "$CORE" "$PROG/hello.nxc"

# N15 — branches : IF/ELSE + EVALUATE + condition AND
t N15 "NEXUS-COBOL branches : IF/ELSE, EVALUATE, AND" \
    bash -c '
        out=$(python3 "$0" cobol "$1")
        echo "$out" | grep -q "GRADE=B"
        echo "$out" | grep -q "QUATRE-VINGT-CINQ"
        echo "$out" | grep -q "MOYENNE-PLUS"
        echo "ok: GRADE=B / QUATRE-VINGT-CINQ / MOYENNE-PLUS"
    ' "$CORE" "$PROG/branches.nxc"

# N16 — boucles : PERFORM VARYING inline + TIMES + UNTIL hors-ligne
t N16 "NEXUS-COBOL boucles : VARYING=55, TIMES=4, UNTIL=12" \
    bash -c '
        out=$(python3 "$0" cobol "$1")
        echo "$out" | grep -q "SOMME=55"
        echo "$out" | grep -q "TOTAL=4"
        echo "$out" | grep -q "TOTAL=12"
        echo "ok: SOMME=55 / TOTAL=4 / TOTAL=12"
    ' "$CORE" "$PROG/loops.nxc"

# N17 — verbe systémique SCAN-FILE : le COBOL invoque le scanner Rust
t N17 "verbe SCAN-FILE : scanner Rust invoqué depuis COBOL + rapport JSON" \
    bash -c '
        out=$(python3 "$0" cobol "$1")
        echo "$out" | grep -q "SCAN fixtures/vuln_eval.py: 1 FINDINGS"
        echo "$out" | grep -q "REPORT .nexus/scan_report.json"
        python3 -c "
import json
r = json.load(open(\".nexus/scan_report.json\"))
assert any(f[\"rule\"] == \"eval\" for f in r[\"findings\"]), r
print(\"ok: rapport JSON valide, règle eval présente\")
"
    ' "$CORE" "$PROG/scan.nxc"

# N18 — verbes REMEMBER/RECALL : mémoire persistante ENTRE 2 PROCESSUS
t N18 "verbes REMEMBER/RECALL : persistance inter-processus prouvée" \
    bash -c '
        w=$(python3 "$0" cobol "$1")
        echo "$w" | grep -q "MEMORISE"
        r=$(python3 "$0" cobol "$2")
        [ "$r" = "valeur-noble" ] || { echo "RECALL a rendu: $r"; exit 1; }
        echo "ok: RECALL inter-processus = valeur-noble"
        python3 -c "
import json
m = json.load(open(\".nexus/cobol_memory.json\"))
assert m[\"cle-dgk\"] == \"valeur-noble\", m
print(\"ok: cobol_memory.json contient la clé\")
"
    ' "$CORE" "$PROG/mem_write.nxc" "$PROG/mem_read.nxc"

# N19 — verbe PROBE-FILE : ExploitGym invoqué depuis le programme COBOL
t N19 "verbe PROBE-FILE : sonde eval CONFIRMÉE depuis NEXUS-COBOL" \
    bash -c '
        out=$(python3 "$0" cobol "$1")
        echo "$out" | grep -q "PROBE eval CONFIRMED"
        echo "ok: PROBE eval CONFIRMED"
    ' "$CORE" "$PROG/probe.nxc"

# N20 — verbes CONTEXT-LOAD/CONTEXT-SEARCH : mémoire 1M tokens depuis COBOL
t N20 "verbes CONTEXT-LOAD/SEARCH : tokens>0 + HIT sur SEC-bench du spec Carbon" \
    bash -c '
        out=$(python3 "$0" cobol "$1")
        echo "$out" | grep -q "CONTEXT docs/gemini_carbon_spec_dgk.md: [1-9]"
        echo "$out" | grep -q "HIT score=1 doc=gemini_carbon_spec_dgk.md"
        echo "ok: CONTEXT + HIT"
    ' "$CORE" "$PROG/context_demo.nxc"

# N21 — sécurité : boucle infinie abortée par le budget (exit 3)
t N21 "budget anti-boucle-infinie : exit 3 + message BUDGET EXCEEDED" \
    bash -c '
        python3 "$0" cobol "$1" 2>/tmp/nx_budget_err
        rc=$?
        [ "$rc" -eq 3 ] || { echo "exit=$rc au lieu de 3"; exit 1; }
        grep -q "BUDGET EXCEEDED" /tmp/nx_budget_err
        echo "ok: boucle infinie abortée à 200000 instructions, exit 3"
    ' "$CORE" "$PROG/infinite.nxc"

# N22 — méta : version NOBLE + help liste les commandes v1.1
t N22 "version 1.1.0 NOBLE + help liste cobol/context + demo_monstre complet" \
    bash -c '
        python3 "$0" version | grep -q "1.1.0"
        python3 "$0" version | grep -q "NOBLE"
        python3 "$0" help | grep -q "cobol <file.nxc>"
        python3 "$0" help | grep -q "context --load"
        out=$(python3 "$0" cobol "$1")
        echo "$out" | grep -q "MONSTRE NOBLE OPERATIONNEL"
        echo "$out" | grep -q "PROBE eval CONFIRMED"
        echo "ok: v1.1.0 NOBLE + demo monstre verte"
    ' "$CORE" "$PROG/demo_monstre.nxc"

cd - >/dev/null
rm -f /tmp/nx_budget_err

echo ""
echo "─────────────────────────────────────────"
echo "  passed: $(c_green $PASS)    failed: $(c_red $FAIL)    total: $((PASS+FAIL))"
if [[ $FAIL -gt 0 ]]; then
    echo "  failed tests: ${FAILED_TESTS[*]}"
    exit 1
fi
echo "  status: $(c_green "ALL GREEN — ULTRA SATISFIED (v1.1 NOBLE)")"
echo "─────────────────────────────────────────"
