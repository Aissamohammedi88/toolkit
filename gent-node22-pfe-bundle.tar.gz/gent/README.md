# GENT — Node 22 Premium Founder Edition · Bundle d'installation

Runtime souverain Node 22 LTS cloné + transformé + durci. IDE local. Identité
unique d'instance. Service systemd autostart :4310. Raccourci bureau.
**Zone sacrée `~/Aether` : jamais lue, jamais écrite (garde-fou codé).**

## Contenu du bundle

| Fichier | Rôle |
|---|---|
| `gent-install.sh` | Installeur complet (clone Node 22, transformation PFE, identité, IDE, systemd, bureau, scaffold Git) |
| `gent-build.sh`   | Script de build Premium (intégrité, warmup compile-cache V8, manifeste SHA256, tarball dist) |
| `gent-git-push.sh`| Publication vers l'organisation GitHub (+ cheatsheet des commandes Git) |
| `gent-verify.sh`  | Protocole senior : 9 contrôles PASS/FAIL/SKIP |
| `app/gent-server.js` | L'IDE souverain (référence ; embarqué aussi dans l'installeur) |

## Installation (2 commandes)

```bash
bash gent-install.sh              # port dédié 4310 par défaut
gent verify                       # protocole senior immédiat
```

Options : `--port NNNN` · `--version v22.x.y` · `--home /chemin/isole` ·
`--no-service` · `--selftest` (test hors-ligne sans réseau).

## Build Premium

```bash
gent build
```

## Publication GitHub (organisation officielle)

```bash
bash ~/gent/scripts/gent-git-push.sh MON-ORG gent-node22-pfe

# ou manuellement :
cd ~/gent/repo
git remote add origin git@github.com:MON-ORG/gent-node22-pfe.git
git push -u origin main
git push origin --tags
```

`identity/` (jeton), `runtime/`, `logs/`, `cache/`, `workspace/` sont
exclus par `.gitignore` + garde anti-fuite dans le script.

## Sécurité embarquée (prouvée en test sur Node v22.23.4)

- SHA256 strict contre `SHASUMS256.txt` officiel nodejs.org ;
- API de l'IDE protégée par jeton d'instance (401 sans jeton) ;
- exécution code via **modèle de permission Node 22** (`ERR_ACCESS_DENIED`
  sur toute lecture/écriture hors workspace) ;
- refus des traversées de chemin (400) ;
- bind 127.0.0.1 uniquement, sandbox systemd (`NoNewPrivileges`,
  `PrivateTmp`, `ProtectSystem=full`, UMask 0077) ;
- identité `GENT-xxxx-xxxx-xxxx-xxxx` + registre de builds append-only.

## Accès

- IDE : `http://127.0.0.1:4310` (ou `gent open`, ou raccourci bureau)
- Identité : `gent id`
- Santé : `gent status`
