#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS-QL v2.0 — Watchdog : surveille un dossier et re-scanne tout fichier
modifie (polling mtimes, zero dependance, zero inotify requis).
State partage via /tmp/nexus-ql-watchdog.json lu par le serveur.
"""
import os, sys, json, time, threading
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from analyzer import analyze_file, score, LANG_MAP

STATE = '/tmp/nexus-ql-watchdog.json'
POLL = 2.0

class Watchdog(threading.Thread):
    daemon = True
    def __init__(self, folder, callback=None):
        super().__init__()
        self.folder = folder
        self.callback = callback
        self.snapshot = {}
        self.alerts = []
        self.scans = 0
        self.running = True

    def scan_all(self):
        results = []
        for root, dirs, files in os.walk(self.folder):
            dirs[:] = [d for d in dirs if not d.startswith('.')]
            for f in files:
                p = os.path.join(root, f)
                if os.path.splitext(f)[1].lower() in LANG_MAP:
                    r = analyze_file(p)
                    if r['lang'] and r['findings']:
                        results.append({'file': p, 'lang': r['lang'],
                                        'count': len(r['findings']),
                                        'score': score(r['findings']),
                                        'findings': r['findings'][:10]})
        self.scans += 1
        return results

    def run(self):
        self.snapshot = self._mtimes()
        while self.running:
            time.sleep(POLL)
            try:
                cur = self._mtimes()
                changed = [p for p, m in cur.items()
                           if self.snapshot.get(p) != m]
                if changed:
                    for p in changed:
                        r = analyze_file(p)
                        if r['lang'] and r['findings']:
                            self.alerts = self.alerts[-49:] + [{
                                'time': time.strftime('%H:%M:%S'),
                                'file': p, 'count': len(r['findings']),
                                'top': r['findings'][0]['rule'],
                                'severity': r['findings'][0]['severity'],
                                'score': score(r['findings'])}]
                            if self.callback:
                                self.callback(p, r)
                        else:
                            self.alerts = self.alerts[-49:] + [{
                                'time': time.strftime('%H:%M:%S'), 'file': p,
                                'count': 0, 'score': 100, 'severity': 'none',
                                'top': 'CLEAN'}]
                    self.snapshot = cur
                self._save_state()
            except Exception as e:
                self._save_state(error=str(e))

    def _mtimes(self):
        snap = {}
        for root, dirs, files in os.walk(self.folder):
            dirs[:] = [d for d in dirs if not d.startswith('.')]
            for f in files:
                if os.path.splitext(f)[1].lower() in LANG_MAP:
                    p = os.path.join(root, f)
                    try: snap[p] = os.path.getmtime(p)
                    except OSError: pass
        return snap

    def _save_state(self, error=None):
        st = {'folder': self.folder, 'scans': self.scans,
              'files_watched': len(self.snapshot), 'alerts': self.alerts[-25:],
              'ts': time.strftime('%H:%M:%S')}
        if error: st['error'] = error
        try:
            with open(STATE, 'w') as f: json.dump(st, f)
        except OSError: pass

def start_watchdog(folder):
    wd = Watchdog(folder)
    wd.start()
    return wd

if __name__ == '__main__':
    folder = sys.argv[1] if len(sys.argv) > 1 else '.'
    wd = Watchdog(folder)
    print(json.dumps(wd.scan_all(), indent=2, ensure_ascii=False))
