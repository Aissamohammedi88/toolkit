// NEXUS-QL v2.0 — éditeur + terminal + rapport (vanilla JS, zéro dépendance)
const $ = id => document.getElementById(id);
let currentFile = null, stdinData = '';

/* ---------- éditeur ---------- */
const code = $('code'), gutter = $('gutter');
function syncGutter() {
  const n = code.value.split('\n').length;
  gutter.textContent = Array.from({length:n}, (_,i)=>i+1).join('\n');
}
code.addEventListener('input', syncGutter);
code.addEventListener('scroll', () => gutter.scrollTop = code.scrollTop);
code.addEventListener('keydown', e => {
  if (e.key === 'Tab') {
    e.preventDefault();
    const s = code.selectionStart;
    code.value = code.value.slice(0,s) + '    ' + code.value.slice(code.selectionEnd);
    code.selectionStart = code.selectionEnd = s + 4; syncGutter();
  }
  if ((e.ctrlKey||e.metaKey) && e.key === 'Enter') doAnalyze();
  if ((e.ctrlKey||e.metaKey) && e.key === 's') { e.preventDefault(); doSave(); }
});
syncGutter();

/* ---------- fichiers ---------- */
async function loadFiles() {
  const r = await (await fetch('/api/files')).json();
  $('fileList').innerHTML = r.files.map(f =>
    `<div class="fitem" onclick="openFile('${f.path.replace(/'/g,"\\'")}')">
       <span>${f.name}</span><span class="tag">${f.lang||'?'}</span></div>`).join('')
    || '<div class="fitem" style="color:var(--dim)">workspace vide</div>';
}
async function openFile(p) {
  const r = await (await fetch('/api/file?path='+encodeURIComponent(p))).json();
  if (r.error) return term(`err: ${r.error}`, 'err');
  currentFile = p;
  code.value = r.text; syncGutter();
  $('fileBadge').textContent = p;
  document.querySelectorAll('.fitem').forEach(el =>
    el.classList.toggle('active', el.textContent.includes(p.split('/').pop())));
}
function newFile() {
  const name = prompt('Nom du fichier (ex: test.py, run.sh, main.rs, app.f90…) :');
  if (!name) return;
  currentFile = name;
  code.value = ''; syncGutter();
  $('fileBadge').textContent = name + ' (nouveau)';
}
async function doSave() {
  if (!currentFile) return term('donne un nom de fichier d abord (nouveau fichier)', 'err');
  const r = await (await fetch('/api/save', {method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({path: currentFile, text: code.value})})).json();
  term(r.ok ? `💾 sauvé → workspace/${r.path}` : `err: ${r.error}`, r.ok?'ok':'err');
  loadFiles();
}

/* ---------- analyse QL ---------- */
const ICONS = {critical:'🔴', high:'🟠', medium:'🟣', low:'🔵'};
async function doAnalyze() {
  const r = await (await fetch('/api/analyze', {method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({text: code.value, lang: $('langSel').value || null,
                          filename: currentFile || 'buffer'})})).json();
  $('ring').style.setProperty('--s', r.score);
  $('scoreTxt').textContent = r.score;
  $('scoreTxt').style.color = r.score >= 80 ? 'var(--green)' : r.score >= 50 ? 'var(--yellow)' : 'var(--red)';
  if (!r.findings.length) {
    $('resList').innerHTML = `<div class="res-empty"><div class="big">✅</div>
      Aucune faille détectée (seuil confiance ≥ 55).<br>Score sécurité : <b>${r.score}/100</b><br>
      langage : ${r.lang}</div>`;
    return;
  }
  $('resList').innerHTML =
    `<div class="res-empty" style="padding:8px">langage <b>${r.lang}</b> · score <b>${r.score}/100</b> ·
     ${r.findings.length} faille(s) · triées par confiance</div>` +
    r.findings.sort((a,b)=>b.confidence-a.confidence).map(f =>
      `<div class="finding" onclick="jump(${f.line})">
        <div class="top"><span class="sev ${f.severity}">${f.severity.toUpperCase()}</span>
          ${ICONS[f.severity]} ${f.rule} — ${f.title}
          <span class="conf">conf ${f.confidence}%</span></div>
        <div class="tech">🔬 ${f.technical}</div>
        <div class="simple">💬 ${f.simple}</div>
        <code>L${f.line} : ${f.snippet.replace(/</g,'&lt;')}</code>
      </div>`).join('');
  term(`⚡ QL : ${r.findings.length} finding(s), score ${r.score}/100`, r.findings.length?'err':'ok');
}
function jump(line) { // surligne la ligne fautive
  const lines = code.value.split('\n');
  const pos = lines.slice(0, line-1).join('\n').length + (line>1?1:0);
  code.focus(); code.selectionStart = pos; code.selectionEnd = pos + (lines[line-1]||'').length;
}

/* ---------- runner ---------- */
function doStdin() { stdinData = prompt('stdin du programme (optionnel) :') ?? ''; }
async function doRun() {
  const lang = $('langSel').value || guessLang();
  term(`▶ exécution [${lang}]…`, 'info');
  const r = await (await fetch('/api/run', {method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({lang, code: code.value, stdin: stdinData})})).json();
  $('termTitle').textContent = `${lang} · ${r.ms}ms · exit ${r.code}`;
  term(r.stdout, r.ok?'':'');
  if (r.stderr) term(r.stderr, 'err');
  if (!r.ok && r.stderr && r.stderr.startsWith('[NEXUS-QL]')) term(r.stderr, 'err');
}
function guessLang() {
  const c = code.value;
  if (/^\s*def |import \w+$|print\(/m.test(c)) return 'python';
  if (/#!.*bash|echo\s+\$/.test(c)) return 'bash';
  if (/package main/.test(c)) return 'go';
  if (/fn main|println!/.test(c)) return 'rust';
  if (/#include|printf\(/.test(c)) return 'cpp';
  if (/program \w+|implicit none/i.test(c)) return 'fortran';
  if (/public class|System\.out/.test(c)) return 'java';
  if (/interface |: (string|number)/.test(c)) return 'typescript';
  if (/local |io\.write|function\s+\w+\(/.test(c)) return 'lua';
  return 'python';
}

/* ---------- terminal + watchdog ---------- */
function term(msg, cls='') {
  const el = $('termOut');
  el.innerHTML += `<span class="${cls}">${String(msg).replace(/</g,'&lt;')}</span>\n`;
  el.scrollTop = el.scrollHeight;
}
$('termIn').addEventListener('keydown', async e => {
  if (e.key !== 'Enter') return;
  const cmd = e.target.value.trim(); e.target.value = '';
  if (!cmd) return;
  if (cmd === 'help') return term(
`commandes : ls · cat FICHIER · python3 · go · gcc · g++ · rustc · javac · node · lua ·
gfortran · tcc · grep · head · tail · wc · which · date · uname · git
(terminal filtré — pas de rm/sudo/network)`, 'info');
  term(`nexus-ql ❯ ${cmd}`, 'info');
  const r = await (await fetch('/api/terminal', {method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({cmd})})).json();
  if (r.stdout) term(r.stdout);
  if (r.stderr) term(r.stderr, r.ok ? '' : 'err');
});
async function pollWD() {
  try {
    const s = await (await fetch('/api/status')).json();
    const w = s.watchdog;
    $('wdInfo').textContent = `${w.files} fichiers · ${w.scans} scans`;
    $('wdState').style.color = w.alerts.length && w.alerts[w.alerts.length-1].count ? 'var(--yellow)' : 'var(--green)';
    $('tcList').innerHTML = Object.entries(s.toolchains)
      .map(([k,v]) => `${v?'✅':'❌'} ${k}`).join('<br>');
  } catch(e) { $('wdState').style.color = 'var(--red)'; }
  setTimeout(pollWD, 3000);
}

/* demo code si vide */
if (!code.value) code.value = `# demo : analyse cette faille volontaire
import os, pickle, yaml, hashlib

user = input("cmd: ")
os.system("ping -c 1 " + user)          # QL doit crier
eval(user)                              # QL doit crier
pickle.loads(open(user,'rb').read())    # deserialisation
yaml.load(open(user))                   # sans Loader
h = hashlib.md5(user.encode())          # hash faible
`;
syncGutter();
loadFiles(); pollWD();
