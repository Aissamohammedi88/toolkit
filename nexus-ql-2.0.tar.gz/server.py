#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS-QL v2.0 — Serveur local http://localhost:3600
API : /api/analyze  /api/run  /api/files  /api/file  /api/save
      /api/terminal /api/watchdog /api/status
Zero dependance externe (http.server + analyzer + runners + watchdog).
"""
import os, sys, json, shutil, subprocess, urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from analyzer import analyze_text, analyze_file, report_json, score, LANG_MAP
from runners import run_code, available
from watchdog import start_watchdog

PORT = 3600
WORKSPACE = os.environ.get('NEXUS_QL_WS', os.path.join(HERE, 'workspace'))
os.makedirs(WORKSPACE, exist_ok=True)

WD = None
def get_watchdog():
    global WD
    if WD is None:
        WD = start_watchdog(WORKSPACE)
    return WD

ALLOWED_CMDS = ('ls','cat','pwd','echo','date','whoami','uname','python3','bash',
                'grep','wc','head','tail','which','go','gcc','g++','rustc','java',
                'javac','node','lua','gfortran','tcc','cargo','git')

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _json(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _static(self, name):
        path = os.path.join(HERE, name)
        ctype = {'html':'text/html','js':'text/javascript','css':'text/css',
                 'svg':'image/svg+xml'}.get(os.path.splitext(name)[1][1:], 'text/plain')
        try:
            data = open(path, 'rb').read()
            self.send_response(200)
            self.send_header('Content-Type', f'{ctype}; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except FileNotFoundError:
            self.send_error(404)

    def _body(self):
        n = int(self.headers.get('Content-Length', 0))
        return json.loads(self.rfile.read(n) or b'{}')

    def do_GET(self):
        route = urllib.parse.urlparse(self.path).path
        if route == '/': return self._static('editor.html')
        if route == '/editor.js': return self._static('editor.js')
        if route == '/editor.css': return self._static('editor.css')
        if route == '/api/status':
            wd = get_watchdog()
            return self._json({'port': PORT, 'workspace': WORKSPACE,
                               'toolchains': available(),
                               'watchdog': {'scans': wd.scans,
                                            'files': len(wd.snapshot),
                                            'alerts': wd.alerts[-10:]}})
        if route == '/api/files':
            items = []
            for root, dirs, files in os.walk(WORKSPACE):
                dirs[:] = [d for d in dirs if not d.startswith('.')]
                for f in sorted(files):
                    p = os.path.join(root, f)
                    items.append({'name': f,
                                  'path': os.path.relpath(p, WORKSPACE),
                                  'lang': LANG_MAP.get(os.path.splitext(f)[1].lower()),
                                  'size': os.path.getsize(p)})
            return self._json({'files': items})
        if route == '/api/file':
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            rel = urllib.parse.unquote(q.get('path',[''])[0])
            p = os.path.normpath(os.path.join(WORKSPACE, rel))
            if not p.startswith(WORKSPACE): return self._json({'error':'forbidden'}, 403)
            try:
                with open(p, errors='replace') as f: txt = f.read()
                return self._json({'path': rel, 'text': txt})
            except FileNotFoundError:
                return self._json({'error':'introuvable'}, 404)
        return self.send_error(404)

    def do_POST(self):
        route = urllib.parse.urlparse(self.path).path
        body = self._body()
        if route == '/api/analyze':
            if 'text' in body:
                lang = body.get('lang') or LANG_MAP.get(
                    os.path.splitext(body.get('filename','x.txt'))[1].lower(), 'python')
                findings = analyze_text(body['text'], lang, body.get('filename','buffer'))
                return self._json({'lang': lang, 'findings': findings,
                                   'score': score(findings)})
            return self._json(json.loads(report_json(body['path'])))
        if route == '/api/run':
            r = run_code(body.get('lang','python'), body.get('code',''),
                         body.get('stdin',''))
            return self._json(r)
        if route == '/api/save':
            rel = body.get('path','')
            p = os.path.normpath(os.path.join(WORKSPACE, rel))
            if not rel or not p.startswith(WORKSPACE):
                return self._json({'error':'chemin interdit'}, 403)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, 'w') as f: f.write(body.get('text',''))
            return self._json({'ok': True, 'path': rel})
        if route == '/api/watchdog':
            wd = get_watchdog()
            if body.get('action') == 'scan':
                return self._json({'results': wd.scan_all()})
            return self._json({'scans': wd.scans, 'alerts': wd.alerts,
                               'files': len(wd.snapshot)})
        if route == '/api/terminal':
            cmd = body.get('cmd','')
            parts = cmd.split()
            if not parts or parts[0] not in ALLOWED_CMDS:
                return self._json({'ok': False,
                    'stderr': f"[terminal] commande non autorisee: {parts[0] if parts else ''}\n"
                              f"autorisees: {' '.join(ALLOWED_CMDS)}"})
            try:
                p = subprocess.run(parts, cwd=WORKSPACE, timeout=15,
                                   capture_output=True, text=True, errors='replace')
                return self._json({'ok': p.returncode == 0,
                                   'stdout': p.stdout[:15000],
                                   'stderr': p.stderr[:15000]})
            except subprocess.TimeoutExpired:
                return self._json({'ok': False, 'stderr': 'timeout 15s'})
        return self.send_error(404)

class Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True

if __name__ == '__main__':
    print(f'[NEXUS-QL v2.0] http://localhost:{PORT}  workspace={WORKSPACE}')
    get_watchdog()
    Server(('127.0.0.1', PORT), Handler).serve_forever()
