#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS-QL v2.0 — Analyseur statique 2e generation
Anti-faux-positifs : chaque regle a une CONFIDENCE (0-100) calculee via
contexte (marqueurs de tainted input, garde de longueur, sanitizers).
Seuil par defaut : on n'affiche que confidence >= 55.
"""
import re, os, json, hashlib, time

TAINT = re.compile(
    r'(input\(|request\.|argv|args|params|getenv|environ|recv|read_line|'
    r'scanf|readLine|getParameter|query|body|stdin|prompt\(|os\.args|std::cin)', re.I)
SANITIZE = re.compile(
    r'(escape|sanitize|parameterize|placeholder|\?|prepared|bind|validate|'
    r'escape_html|htmlentities|quote\(|shlex\.quote|int\(|atoi|parseInt)', re.I)
GUARD = re.compile(r'(strlen|strn|snprintf|bounds|len\s*<|len\s*<=|size\s*-|'
                   r'check|assert|capacity|\.len\(\)\s*[<>]|MIN\(|MAX\()')

RULES = [
 # ---------- PYTHON ----------
 ('python', r'\beval\s*\(', 'PY-EVAL', 'critical', 90,
  'eval() sur donnee potentiellement utilisateur',
  'eval() compile et execute du code Python arbitraire depuis une chaine.',
  'eval execute n importe quoi comme code. Si un hacker ecrit dedans, il controle la machine.', False),
 ('python', r'\bexec\s*\(', 'PY-EXEC', 'critical', 85,
  'exec() de code dynamique', 'exec() execute du code construit a l execution.',
  'meme danger que eval : le code est execute tel quel.', False),
 ('python', r'os\.system\s*\(|os\.popen\s*\(', 'PY-SYSCALL', 'critical', 80,
  'Commande systeme avec concatenation',
  'os.system/popen passent par /bin/sh : injection de commande si la chaine est concatenee.',
  'une commande shell construite avec des donnees utilisateur = porte ouverte.', True),
 ('python', r'subprocess\.\w+\([^)]*(?:shell\s*=\s*True|f?["\'].*\+)', 'PY-SUBSHELL', 'high', 75,
  'subprocess avec shell=True ou concatenation',
  'shell=True combine a une chaine dynamique permet l injection de commande.',
  'shell=True dit au systeme d interpreter la commande : dangereux avec des variables.', False),
 ('python', r'pickle\.loads?\s*\(', 'PY-PICKLE', 'high', 70,
  'Deserialisation pickle de donnees externes',
  'pickle.loads execute du code embarque dans le blob. Jamais sur des donnees non signees.',
  'un fichier pickle peut contenir du code qui s execute a l ouverture.', True),
 ('python', r'yaml\.load\s*\((?![^)]*Loader)', 'PY-YAML', 'high', 85,
  'yaml.load sans Loader safe', 'yaml.load sans Loader=SafeLoader permet RCE via tags YAML.',
  'charger du YAML sans mode safe permet d executer du code cache dedans.', False),
 ('python', r'(?:SELECT|INSERT|UPDATE|DELETE)\b.*["\']\s*(?:\+|%|f["\'])', 'PY-SQLI', 'critical', 80,
  'Requete SQL construite par concatenation', 'SQL concatene = injection SQL classique.',
  'la requete est collee avec des variables : un utilisateur peut injecter du SQL.', True),
 ('python', r'hashlib\.md5|hashlib\.sha1\b', 'PY-WEAKHASH', 'medium', 70,
  'Hash faible (MD5/SHA1)', 'MD5/SHA1 sont casses pour la securite (collisions).',
  'ces algos de hash sont perimes, on peut fabriquer des collisions.', False),
 # ---------- JAVASCRIPT / TYPESCRIPT ----------
 ('javascript', r'\beval\s*\(', 'JS-EVAL', 'critical', 90,
  'eval() dynamique', 'eval execute du JS arbitraire.', 'eval execute tout ce qu on lui donne.', False),
 ('typescript', r'\beval\s*\(', 'TS-EVAL', 'critical', 90,
  'eval() dynamique (TS)', 'eval contourne tout le typage TypeScript.',
  'eval casse toutes les garanties de TypeScript.', False),
 ('javascript', r'\.innerHTML\s*=', 'JS-INNERHTML', 'high', 75,
  'innerHTML avec contenu dynamique', 'XSS : innerHTML interprete le HTML/JS injecte.',
  'du texte utilisateur mis dans innerHTML peut lancer du script chez le visiteur.', True),
 ('javascript', r'document\.write\s*\(', 'JS-DOCWRITE', 'high', 70,
  'document.write dynamique', 'XSS via document.write.', 'ancienne facon de faire XSS.', True),
 ('javascript', r'(?:child_process|exec)\s*\(|spawnSync?\s*\([^)]*\+', 'JS-EXECCMD', 'critical', 80,
  'Commande shell depuis Node', 'exec() passe par /bin/sh : injection de commande.',
  'executer une commande shell avec des variables utilisateur = injection.', True),
 ('javascript', r'crypto\.createHash\s*\(\s*["\'](?:md5|sha1)["\']', 'JS-WEAKHASH', 'medium', 80,
  'Hash faible MD5/SHA1', 'MD5/SHA1 casse.', 'hash perime.', False),
 ('typescript', r':\s*any\b', 'TS-ANY', 'low', 60,
  'Type any explicite', 'any desactive la securite de type en ce point.',
  'any = desactiver les verifications de TypeScript ici.', False),
 # ---------- C / C++ ----------
 ('c', r'\bgets\s*\(', 'C-GETS', 'critical', 98,
  'gets() : debordement de tampon garanti', 'gets() ne connait PAS la taille du tampon. Bannie de la norme C11.',
  'gets lit sans limite : on peut ecrire hors du buffer. Toujours dangereux.', False),
 ('cpp', r'\bgets\s*\(', 'C-GETS', 'critical', 98, 'gets() : debordement de tampon garanti',
  'gets() sans borne.', 'gets lit sans limite.', False),
 ('c', r'\bstrcpy\s*\(', 'C-STRCPY', 'high', 65,
  'strcpy sans verification de taille', 'strcpy ne borne pas la copie. Utiliser strncpy/snprintf.',
  'strcpy copie tout, meme si ca deborde. Utiliser la version avec n.', True),
 ('cpp', r'\bstrcpy\s*\(', 'C-STRCPY', 'high', 65, 'strcpy sans borne',
  'strcpy ne borne pas.', 'strcpy copie tout.', True),
 ('c', r'\bsprintf\s*\(', 'C-SPRINTF', 'high', 60,
  'sprintf sans limite', 'sprintf peut deborder, utiliser snprintf.',
  'sprintf ecrit sans compter. snprintf est la version securisee.', True),
 ('cpp', r'\bsprintf\s*\(', 'C-SPRINTF', 'high', 60, 'sprintf sans limite',
  'sprintf peut deborder.', 'sprintf ecrit sans compter.', True),
 ('c', r'\bsystem\s*\(', 'C-SYSTEM', 'critical', 75,
  'system() avec chaine dynamique', 'system() execute via /bin/sh.',
  'system lance une commande shell : injection possible.', True),
 ('cpp', r'\bsystem\s*\(', 'C-SYSTEM', 'critical', 75, 'system() dynamique',
  'system() via /bin/sh.', 'system lance un shell.', True),
 ('cpp', r'\bconst_cast\b|\breinterpret_cast\b', 'CPP-CAST', 'medium', 55,
  'Cast dangereux', 'reinterpret_cast/const_cast cassent le systeme de types.',
  'ces casts forcent le compilateur a fermer les yeux.', False),
 ('c', r'\bmalloc\s*\([^)]*\)\s*(?!.*\bfree\b)', 'C-MALLOC', 'medium', 50,
  'malloc a verifier (pair free)', 'Verifier que chaque malloc a son free (fuite memoire).',
  'chaque malloc doit avoir un free, sinon la memoire fuit.', False),
 # ---------- GO ----------
 ('go', r'fmt\.Sprintf\s*\([^)]*\)\s*(?:.*)exec\.Command', 'GO-EXECSI', 'critical', 80,
  'Commande construite avec Sprintf', 'exec.Command avec chaine formatee = injection.',
  'commande collee avec des variables = injection.', True),
 ('go', r'math/rand', 'GO-WEAKRAND', 'medium', 70,
  'math/rand pour usage securite', 'math/rand est previsible ; utiliser crypto/rand.',
  'ce hasard est devinable, pas pour les mots de passe.', False),
 ('go', r'\bunsafe\.Pointer\b', 'GO-UNSAFE', 'medium', 60,
  'unsafe.Pointer', 'Contourne la securite memoire de Go.',
  'unsafe desactive la protection memoire de Go.', False),
 ('go', r'_\s*=\s*\w+\.(?:Close|Err)\(\)', 'GO-ERRDROP', 'low', 55,
  'Erreur ignoree', 'L erreur de retour est jetee sans test.',
  'l erreur est jetee a la poubelle sans etre lue.', False),
 # ---------- RUST ----------
 ('rust', r'\.unwrap\(\)', 'RS-UNWRAP', 'medium', 60,
  'unwrap() sans gestion d erreur', 'unwrap panique (crash) sur Err/None. Preferer ? ou match.',
  'unwrap fait planter le programme si ca rate. Mieux : gerer l erreur.', True),
 ('rust', r'\bunsafe\s*\{', 'RS-UNSAFE', 'high', 65,
  'Bloc unsafe', 'unsafe desactive les garanties memoire de Rust.',
  'unsafe desactive les protections de Rust, a doubler de verifications.', False),
 ('rust', r'expect\s*\(\s*["\'](?:TODO|FIXME)', 'RS-EXPECT-TODO', 'low', 90,
  'expect() TODO en production', 'Message expect laissant un TODO : code non termine.',
  'un TODO laisse dans la gestion d erreur = oublie de finir le travail.', False),
 # ---------- JAVA ----------
 ('java', r'Runtime\.getRuntime\(\)\.exec\s*\([^)]*\+', 'JV-EXEC', 'critical', 80,
  'Runtime.exec avec concatenation', 'exec avec chaine concatenee = injection de commande.',
  'commande collee avec des variables = injection.', True),
 ('java', r'MessageDigest\.getInstance\s*\(\s*"(?:MD5|SHA-?1)"', 'JV-WEAKHASH', 'medium', 85,
  'Hash faible MD5/SHA1', 'MD5/SHA1 casses.', 'hash perime.', False),
 ('java', r'(?:SELECT|INSERT|UPDATE|DELETE).*"\s*\+\s*\w+', 'JV-SQLI', 'critical', 80,
  'SQL concatene', 'Utiliser PreparedStatement.', 'coller du SQL = injection. PreparedStatement !', True),
 ('java', r'new\s+Random\s*\(\s*\)', 'JV-RANDOM', 'low', 55,
  'java.util.Random pour securite', 'Random est previsible, utiliser SecureRandom.',
  'ce hasard est devinable. SecureRandom pour la securite.', True),
 # ---------- LUA ----------
 ('lua', r'\bloadstring\s*\(|\bload\s*\(', 'LUA-LOAD', 'critical', 85,
  'loadstring/load de code dynamique', 'Compile et execute du code Lua arbitraire.',
  'load execute du code ecrit dans une chaine.', True),
 ('lua', r'os\.execute\s*\(', 'LUA-EXEC', 'critical', 80,
  'os.execute avec chaine', 'Injection de commande shell.', 'commande shell avec variables = danger.', True),
 ('lua', r'io\.popen\s*\(', 'LUA-POPEN', 'high', 70,
  'io.popen', 'Execute via shell.', 'lance un shell.', True),
 # ---------- BASH ----------
 ('bash', r'\beval\b', 'SH-EVAL', 'critical', 80,
  'eval shell', 'eval re-parse la ligne : injection si variable non quotee.',
  'eval reinterprete tout : une variable piagee devient du code.', True),
 ('bash', r'curl[^|]*\|\s*(?:ba)?sh', 'SH-CURLSH', 'critical', 95,
  'curl pipele vers sh', 'Execute du code distant non verifie.',
  'telecharger et executer direct = executer ce que le serveur veut.', False),
 ('bash', r'rm\s+-rf\s+\$', 'SH-RMF', 'critical', 85,
  'rm -rf sur variable', 'Si la variable est vide, rm -rf / possible.',
  'rm -rf avec une variable vide peut effacer tout le disque.', False),
 ('bash', r'\[\[\s*\$\w+\s*==?\s*[^\$]*\]\]\s*;?\s*then', 'SH-COMPARE', 'low', 40,
  'Comparaison (info)', 'Preferer [[ ]] avec quotes.', 'mieux vaut quoter les variables.', False),
 # ---------- FORTRAN ----------
 ('fortran', r'\bCALL\s+SYSTEM\b|\bCALL\s+EXECUTE_COMMAND_LINE\b', 'FT-SYSTEM', 'high', 75,
  'Appel systeme Fortran', 'Execute une commande shell depuis Fortran.',
  'le programme Fortran lance une commande shell.', True),
 ('fortran', r'CHARACTER\s*\(\s*LEN\s*=\s*\d+\s*\).*READ\s*\(\s*\*.*\)', 'FT-BUFREAD', 'medium', 55,
  'Lecture possible sans borne', 'READ * peut depasser la longueur declaree selon le format.',
  'une lecture peut ecrire plus loin que la taille reservee.', False),
 # ---------- TINYCC (C minimal) ----------
 ('c', r'#include\s*<gets\.h>|void\s+main\s*\(', 'TCC-BADMAIN', 'medium', 70,
  'main sans type / include suspect', 'void main est non standard ; int main requis.',
  'main doit retourner int, sinon comportement indetermine.', False),
]

LANG_MAP = {'.py':'python', '.js':'javascript', '.ts':'typescript', '.jsx':'javascript',
           '.tsx':'typescript', '.c':'c', '.h':'c', '.cpp':'cpp', '.cc':'cpp', '.cxx':'cpp',
           '.hpp':'cpp', '.go':'go', '.rs':'rust', '.java':'java', '.lua':'lua',
           '.sh':'bash', '.bash':'bash', '.f90':'fortran', '.f95':'fortran', '.f':'fortran'}

def analyze_text(text, lang, filename='input'):
    findings, lines = [], text.split('\n')
    rules = [r for r in RULES if r[0] == lang] or \
            ([r for r in RULES if r[0] in ('c','cpp')] if lang == 'tcc' else [])
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if stripped.startswith(('#','//','--','*','/*')) and not stripped.startswith('#!'):
            continue  # ignore commentaires -> moins de faux positifs
        taint = bool(TAINT.search(line)) or bool(TAINT.search(
            '\n'.join(lines[max(0,i-6):i-1])))
        guarded = bool(GUARD.search('\n'.join(lines[max(0,i-4):i+2])))
        for (lg, pat, rid, sev, base, title, tech, simple, taint_req) in rules:
            if not re.search(pat, line, re.I):
                continue
            conf = base
            if taint_req and not taint: conf -= 45   # pas de source utilisateur -> FP probable
            if taint: conf += 8
            if guarded and rid in ('C-STRCPY','C-SPRINTF','RS-UNWRAP'): conf -= 25
            if SANITIZE.search(line): conf -= 30
            conf = max(5, min(99, conf))
            if conf < 55:  # seuil anti-FP
                continue
            findings.append({
                'rule': rid, 'severity': sev, 'confidence': conf,
                'file': filename, 'line': i, 'column': len(line) - len(line.lstrip()) + 1,
                'title': title, 'technical': tech, 'simple': simple,
                'snippet': line[:200]})
    return findings

def analyze_file(path):
    lang = LANG_MAP.get(os.path.splitext(path)[1].lower())
    if not lang:
        return {'lang': None, 'findings': []}
    with open(path, 'r', errors='replace') as f:
        text = f.read()
    return {'lang': lang, 'findings': analyze_text(text, lang, os.path.basename(path))}

def score(findings):
    w = {'critical': 40, 'high': 25, 'medium': 12, 'low': 5}
    penalty = sum(w.get(f['severity'], 5) * f['confidence'] / 100 for f in findings)
    return max(0, round(100 - min(100, penalty)))

def report_json(path):
    r = analyze_file(path)
    r['score'] = score(r['findings'])
    r['sha256'] = hashlib.sha256(open(path,'rb').read()).hexdigest()[:16] if os.path.exists(path) else '-'
    r['timestamp'] = time.strftime('%Y-%m-%d %H:%M:%S')
    return json.dumps(r, indent=2, ensure_ascii=False)

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print('usage: analyzer.py <fichier>'); sys.exit(1)
    print(report_json(sys.argv[1]))
