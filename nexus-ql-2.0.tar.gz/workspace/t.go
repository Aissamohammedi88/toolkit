package main
import "fmt"
func main(){fmt.Println("hello from GO", 1+1)}
