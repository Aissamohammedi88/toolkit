public class Main{public static void main(String[] a){System.out.println("hello from JAVA "+99);}}
