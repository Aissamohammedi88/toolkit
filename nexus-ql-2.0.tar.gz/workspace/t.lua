print("hello from LUA " .. 7*6)
