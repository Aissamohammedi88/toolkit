#include <iostream>
int main(){std::cout<<"hello from CPP "<<2026<<"\n";}
