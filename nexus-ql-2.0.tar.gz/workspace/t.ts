const x:number = 5*5; console.log("hello from TS", x);
