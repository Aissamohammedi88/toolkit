#include <stdio.h>
int main(){printf("hello from C %d\n", 6*7);return 0;}
