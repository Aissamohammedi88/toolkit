fn main(){println!("hello from RUST {}", 42);}
