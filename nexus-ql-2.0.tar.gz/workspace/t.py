print("hello from", "PYTHON")
