program hello
implicit none
print *, "hello from FORTRAN", 3*3
end program
