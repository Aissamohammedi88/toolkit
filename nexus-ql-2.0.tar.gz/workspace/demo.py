import os, pickle, yaml, hashlib
user = input("cmd: ")
os.system("ping -c 1 " + user)
eval(user)
pickle.loads(open(user,'rb').read())
yaml.load(open(user))
h = hashlib.md5(user.encode())
# eval(danger) dans un commentaire ne doit PAS etre signale
