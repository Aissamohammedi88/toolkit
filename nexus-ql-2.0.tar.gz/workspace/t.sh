echo "hello from BASH $((2+2))"
