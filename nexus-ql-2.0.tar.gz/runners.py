#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS-QL v2.0 — Runner multi-langages (sandbox user-space, timeout, sans sudo)
10 langages : python, bash, go, cpp/c(gcc+tinycc), rust, java, typescript, lua, fortran
Chaque run : dossier temporel isole /tmp/nexus-ql-run-<rand>, timeout 20s.
"""
import os, sys, json, shutil, subprocess, tempfile, random, time, string

TIMEOUT = 20
TOOLCHAINS = {
    'python':    ['python3'],
    'bash':      ['bash'],
    'go':        ['go'],
    'cpp':       ['g++'],
    'c':         ['gcc'],
    'tcc':       ['tcc'],
    'rust':      ['rustc'],
    'java':      ['javac'],
    'typescript':['node'],
    'lua':       ['lua'],
    'fortran':   ['gfortran'],
}

def which(t):
    return shutil.which(t)

def available():
    return {lang: bool(which(t[0])) for lang, t in TOOLCHAINS.items()}

def _run(cmd, cwd, stdin_data=''):
    if isinstance(stdin_data, bytes):
        stdin_data = stdin_data.decode(errors='replace')
    t0 = time.time()
    try:
        p = subprocess.run(cmd, cwd=cwd, input=stdin_data, timeout=TIMEOUT,
                           capture_output=True, text=True, errors='replace',
                           env={**os.environ, 'HOME': cwd})
        return {'ok': p.returncode == 0, 'code': p.returncode,
                'stdout': p.stdout[:20000], 'stderr': p.stderr[:20000],
                'ms': int((time.time()-t0)*1000)}
    except subprocess.TimeoutExpired:
        return {'ok': False, 'code': -1, 'stdout': '', 'ms': TIMEOUT*1000,
                'stderr': f'TIMEOUT {TIMEOUT}s'}
    except FileNotFoundError as e:
        return {'ok': False, 'code': -1, 'stdout': '', 'stderr': str(e), 'ms': 0}

def _tmpdir():
    d = os.path.join(tempfile.gettempdir(), 'nexus-ql-run-' +
                     ''.join(random.choices(string.ascii_lowercase, k=8)))
    os.makedirs(d, exist_ok=True)
    return d

def run_code(lang, code, stdin_data=''):
    d = _tmpdir()
    try:
        return _dispatch(lang, code, stdin_data, d)
    finally:
        shutil.rmtree(d, ignore_errors=True)

def _dispatch(lang, code, stdin_data, d):
    src = os.path.join(d, 'main')
    res = None

    if lang in ('python',):
        f = src + '.py'; open(f, 'w').write(code)
        res = _run(['python3', '-I', f], d, stdin_data)

    elif lang in ('bash',):
        f = src + '.sh'; open(f, 'w').write(code)
        res = _run(['bash', f], d, stdin_data)

    elif lang in ('c', 'tcc'):
        f = src + '.c'; open(f, 'w').write(code)
        cc = 'tcc' if lang == 'tcc' and which('tcc') else 'gcc'
        if not which(cc):
            return missing(cc)
        res = _run([cc, '-O1', '-o', src+'.bin', f, '-lm'], d)
        if res['ok']:
            res = _run([src+'.bin'], d, stdin_data)

    elif lang == 'cpp':
        f = src + '.cpp'; open(f, 'w').write(code)
        if not which('g++'): return missing('g++')
        res = _run(['g++', '-O1', '-std=c++17', '-o', src+'.bin', f], d)
        if res['ok']:
            res = _run([src+'.bin'], d, stdin_data)

    elif lang == 'go':
        f = os.path.join(d, 'main.go'); open(f, 'w').write(code)
        open(os.path.join(d, 'go.mod'), 'w').write('module run\n\ngo 1.21\n')
        if not which('go'): return missing('go')
        res = _run(['go', 'run', '-.', 'main.go'], d, stdin_data)
        if 'go run' in res.get('stderr','') and '-.' not in res['stderr']:
            res = _run(['go', 'run', 'main.go'], d, stdin_data)

    elif lang == 'rust':
        f = src + '.rs'; open(f, 'w').write(code)
        if not which('rustc'): return missing('rustc')
        res = _run(['rustc', '-O', '-o', src+'.bin', f], d)
        if res['ok']:
            res = _run([src+'.bin'], d, stdin_data)

    elif lang == 'java':
        cls = 'Main'
        f = os.path.join(d, cls + '.java'); open(f, 'w').write(code)
        if not which('javac'): return missing('javac')
        res = _run(['javac', cls + '.java'], d)
        if res['ok']:
            res = _run(['java', '-cp', d, cls], d, stdin_data)

    elif lang == 'typescript':
        f = src + '.ts'; open(f, 'w').write(code)
        if not which('node'): return missing('node')
        # Node >=22.6 strip TypeScript nativement
        r = _run(['node', '--version'], d)
        v = r.get('stdout','v0.0.0').strip().lstrip('v').split('.')
        if int(v[0]) >= 22:
            res = _run(['node', '--experimental-strip-types', f], d, stdin_data)
        else:
            tsc = which('tsc')
            if not tsc: return missing('tsc (ou node >= 22)')
            r2 = _run([tsc, f, '--outFile', src+'.js', '--target', 'es2020'], d)
            res = _run(['node', src+'.js'], d, stdin_data) if r2['ok'] else r2

    elif lang == 'lua':
        f = src + '.lua'; open(f, 'w').write(code)
        if not which('lua'): return missing('lua')
        res = _run(['lua', f], d, stdin_data)

    elif lang == 'fortran':
        f = src + '.f90'; open(f, 'w').write(code)
        if not which('gfortran'): return missing('gfortran')
        res = _run(['gfortran', '-O1', '-o', src+'.bin', f], d)
        if res['ok']:
            res = _run([src+'.bin'], d, stdin_data)
    else:
        return {'ok': False, 'stdout': '', 'stderr': f'langage inconnu: {lang}', 'ms': 0}

    res['lang'] = lang
    return res

def missing(tool):
    return {'ok': False, 'ms': 0, 'stdout': '',
            'stderr': f"[NEXUS-QL] toolchain absente: {tool}. "
                      f"Installer: sudo apt install {tool} (une seule fois).",
            'lang': tool}

if __name__ == '__main__':
    lang, path = sys.argv[1], sys.argv[2]
    print(json.dumps(run_code(lang, open(path).read()), indent=2))
