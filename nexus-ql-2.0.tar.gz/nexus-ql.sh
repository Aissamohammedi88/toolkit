#!/usr/bin/env bash
# ============================================================
#  NEXUS-QL v2.0 — launcher (analyse statique 2e generation)
#  8 fichiers · 10 langages · localhost:3600 · zero sudo
# ============================================================
set -u
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT=3600
URL="http://localhost:$PORT"
C_G='\033[1;32m'; C_R='\033[1;31m'; C_B='\033[1;34m'; C_Y='\033[1;33m'; C_0='\033[0m'

banner() { echo -e "$C_B
  ╔══════════════════════════════════════════════╗
  ║   N E X U S - Q L   v 2 . 0                  ║
  ║   analyse statique 2e generation · 8 fichiers ║
  ║   python bash go c cpp rust java ts lua f90  ║
  ╚══════════════════════════════════════════════╝$C_0"; }

pid_of() { pgrep -f "python3.*$DIR/server.py" 2>/dev/null | head -1; }

start() {
  if pid_of >/dev/null; then
    echo -e "${C_Y}[!] deja lance (pid $(pid_of)) → $URL${C_0}"; return 0
  fi
  command -v python3 >/dev/null || { echo -e "${C_R}[✗] python3 requis${C_0}"; exit 1; }
  echo -e "${C_G}[+] demarrage serveur QL…${C_0}"
  nohup python3 "$DIR/server.py" > "$DIR/server.log" 2>&1 &
  sleep 1
  if pid_of >/dev/null; then
    echo -e "${C_G}[+] OK → $URL${C_0}   (log: $DIR/server.log)"
  else
    echo -e "${C_R}[✗] echec, voir $DIR/server.log${C_0}"; exit 1
  fi
}

stop() { p=$(pid_of); [ -n "$p" ] && kill "$p" && echo "[+] arrete (pid $p)" || echo "[!] pas lance"; }

case "${1:-}" in
  start)  banner; start ;;
  stop)   stop ;;
  restart) stop; sleep 1; start ;;
  scan)   shift; python3 "$DIR/watchdog.py" "${1:-$DIR/workspace}" ;;
  analyze) shift; [ -n "${1:-}" ] && python3 "$DIR/analyzer.py" "$1" || { echo "usage: $0 analyze <fichier>"; exit 1; } ;;
  run)    shift; [ $# -ge 2 ] && python3 "$DIR/runners.py" "$1" "$2" || { echo "usage: $0 run <lang> <fichier>"; exit 1; } ;;
  editor) banner; start; xdg-open "$URL" 2>/dev/null || open "$URL" 2>/dev/null \
          || echo -e "${C_B}[i] ouvre $URL dans ton navigateur${C_0}" ;;
  status) curl -s "$URL/api/status" 2>/dev/null | python3 -m json.tool || echo "[!] serveur arrete" ;;
  install)
    # raccourci bureau (zero sudo)
    DESK="$HOME/.local/share/applications"
    ICON="$HOME/.local/share/icons/hicolor/256x256/apps"
    mkdir -p "$DESK" "$ICON"
    cat > "$ICON/nexus-ql.svg" <<'SVG'
<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256">
  <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="#1d9bf0"/><stop offset="1" stop-color="#7856ff"/>
  </linearGradient></defs>
  <rect width="256" height="256" rx="52" fill="#0a0a0b"/>
  <path d="M70 186V70l116 116V70" stroke="url(#g)" stroke-width="20" fill="none"
        stroke-linecap="round" stroke-linejoin="round"/>
  <circle cx="70" cy="70" r="14" fill="#00ba7c"/>
</svg>
SVG
    cat > "$DESK/nexus-ql.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=NEXUS-QL v2.0
Comment=Analyse statique 2e generation — 10 langages, editeur, terminal, watchdog
Exec=$DIR/nexus-ql.sh editor
Icon=$ICON/nexus-ql.svg
Terminal=false
Categories=Development;Security;
DESK
    chmod +x "$0" "$DESK/nexus-ql.desktop"
    command -v update-desktop-database >/dev/null && update-desktop-database "$DESK"
    echo -e "${C_G}[+] installe : menu applications → NEXUS-QL v2.0${C_0}" ;;
  *)
    banner
    cat <<USAGE
  ${C_Y}usage:${C_0} $0 <commande>

    ${C_G}editor${C_0}    lance le serveur + ouvre l editeur (Mac/Vercel/Twitter/PS5)
    ${C_G}start${C_0}     lance le serveur en arriere-plan
    ${C_G}stop${C_0}      arrete le serveur
    ${C_G}status${C_0}    etat API + toolchains detectees
    ${C_G}analyze${C_0}   $0 analyze <fichier>     (rapport JSON direct)
    ${C_G}scan${C_0}      $0 scan <dossier>        (scan complet du dossier)
    ${C_G}run${C_0}       $0 run <lang> <fichier>  (execute en sandbox)
    ${C_G}install${C_0}   raccourci bureau (.desktop + icone)

  ${C_Y}exemples:${C_0}
    $0 editor
    $0 analyze ./workspace/demo.py
    $0 run python ./workspace/demo.py
    $0 run rust ./workspace/main.rs
USAGE
    ;;
esac
