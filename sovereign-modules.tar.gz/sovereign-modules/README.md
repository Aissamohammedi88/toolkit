# SOVEREIGN MODULES — 4 modules indépendants pour agents IA souverains

> Architecture Systémique Senior — 100% local, zéro cloud, zéro dépendance externe obligatoire.
>
> Date de livraison : 2026-11-06
> Validation : **34/34 PASS** (voir `TEST_REPORT.md`)

Quatre modules indépendants, chacun résolvant un problème critique des agents IA actuels.
Compilables et testables séparément, ils peuvent aussi fonctionner ensemble pour former
la base d'un agent souverain complet.

---

## Sommaire

| Module | Langage | Port | Binaire | Problème résolu |
|---|---|---|---|---|
| **1. SCP** | Rust | 9001 | `scp-server` | Amnésie contextuelle : indexe le projet en DAG |
| **2. Firewall** | Rust + Prolog | 9002 | `agent-firewall` | Actions dangereuses : bloque à la racine (Zéro-Path) |
| **3. Snapshot** | Rust | — | `snapshot-cli` | Perte d'état au crash : capture et restaure l'agent |
| **4. Gateway** | Go | 9004 | `ai-gateway` | Multi-LLM : unifie OpenAI/Anthropic/Ollama en API unique |

---

## Installation rapide

Prérequis : `cargo` (Rust 1.99+) et `go` (1.23+) dans le `PATH`.

```bash
# Compile les 4 modules
cd sovereign-modules/scp-server      && cargo build --release
cd ../agent-firewall                 && cargo build --release
cd ../snapshot-cli                   && cargo build --release
cd ../ai-gateway                     && go build -o ai-gateway .

# Lance la validation complète (compile + smoke-test + SLA benchmarks)
cd ..
bash validate.sh                     # → exit 0 si 34/34 PASS
```

---

## MODULE 1 — SOVEREIGN CONTEXT PROTOCOL (SCP)

### Problème
Les agents IA sont amnésiques : ils relisent tout le projet à chaque requête, ce qui sature
leur fenêtre de contexte et les rend lents.

### Solution
Un serveur de contexte qui indexe l'arborescence du projet en **DAG des dépendances**
(qui importe qui) et expose une API HTTP locale. L'agent interroge ce serveur au lieu de
relire tout le code.

### API (port `127.0.0.1:9001`)

| Endpoint | Méthode | Description |
|---|---|---|
| `/health` | GET | `{"status":"ok","files_indexed":N,"elapsed_ms":X,"indexed_at":T}` |
| `/context?file=<path>` | GET | Dépendances directes, indirectes (BFS transitive) et règles de sécurité applicables |
| `/dag` | GET | JSON complet du DAG (debug) |
| `/reindex` | POST | Force une re-indexation |

Exemple :
```bash
./scp-server/target/release/scp-server --root . --port 9001 &
curl "http://127.0.0.1:9001/context?file=src/main.rs"
# {
#   "file": "src/main.rs",
#   "direct_deps": ["src/prolog.rs", "src/chaima.rs"],
#   "indirect_deps": ["src/dag.rs", "src/server.rs", ...],
#   "security_rules": ["no-secrets", "tests-required"],
#   "indexed_at": 1793915207
# }
```

### Parsers supportés
- **Rust** : `use`, `pub use`, `mod`
- **Python** : `import`, `from … import …`
- **Go** : blocs `import (...)` (résolution au niveau package)
- **JavaScript/TypeScript** : `require(...)`, `import … from …`
- **Markdown** : liens `[text](path)`

### Performance mesurée
- **Indexation de 10 000 fichiers en ~100 ms** (budget : < 2 s → marge 20×)
- Cache en mémoire `Arc<RwLock<ServerState>>`, re-indexation atomique par swap

### Fichiers
`scp-server/Cargo.toml`, `src/{main,indexer,dag,server}.rs`, `scp-query.sh`, `gen_perf_project.py`,
`README.md`, `test-report.txt`

---

## MODULE 2 — AGENT FIREWALL (ZÉRO-PATH)

### Problème
Un agent peut faire un `rm -rf /` ou envoyer des clés API à un serveur distant.
Les entreprises ont peur de laisser les agents exécuter du code.

### Solution
Un pare-feu local qui analyse l'intention de l'agent **avant** qu'il n'agisse.
Si l'action viole une règle de sécurité Prolog, elle est bloquée à la racine (Zéro-Path).

### API (port `127.0.0.1:9002`)

| Endpoint | Méthode | Description |
|---|---|---|
| `/gate` | POST | `{"action":"execute","args":["rm","-rf","/"]}` → `{"allowed":false,"reason":"ZeroPath","rule_matched":"forbidden(execute,...)","evaluated_in_us":9}` |
| `/rules` | GET | Liste les règles chargées (41 dans `rules.pl`) |
| `/reload` | POST | Recharge `rules.pl` |
| `/health` | GET | `{"status":"ok","rules_loaded":41,"audits":N}` |

Exemple :
```bash
./agent-firewall/target/release/agent-firewall --rules rules.pl --port 9002 --audit audit.log &
curl -X POST http://127.0.0.1:9002/gate \
     -H "Content-Type: application/json" \
     -d '{"action":"execute","args":["rm","-rf","/"]}'
# {"allowed":false,"reason":"ZeroPath","rule_matched":"forbidden(execute, [rm, -rf, /])","evaluated_in_us":9}
```

### Mini-moteur Prolog embarqué
Implémenté **from scratch** en Rust (1 479 lignes). Aucune dépendance à SWI-Prolog.
- Tokenizer → parser récursif → AST `Term::{Atom, Var, List, Compound}`
- Unification avec résolution de variables
- Backtracking DFS récursif, **depth-cap 1 000** anti-boucle infinie
- Supporte : faits, règles avec corps de clause, atomes, variables Capitalisées, listes,
  jokers `any` / `_` / `any_*`

### Règles d'exemple (`rules.pl`)
```prolog
forbidden(execute, ['rm', '-rf', '/']).
forbidden(execute, ['rm', '-rf', any]).         % joker
forbidden(execute, ['curl', 'http://evil.com']).
forbidden(edit_file, '/etc/passwd').
forbidden(edit_file, '/etc/shadow').
forbidden(read_file, '/etc/shadow').
forbidden(network, 'evil.com').
% Règle composée avec corps de clause :
forbidden(Action, Args) :- dangerous_action(Action), sensitive_target(Args).
dangerous_action(execute).
sensitive_target(['/etc/passwd']).
```

### Audit log
Chaque appel à `/gate` écrit une ligne dans `audit.log` avec hash SHA-256 de l'action :
```
2026-11-05T21:14:59.153Z | ACTION=execute ARGS=["rm","-rf","/"] | ALLOWED=false
  | RULE=forbidden(execute, [rm, '-rf', '/'])
  | SHA256=37066ccd8d259cc10f92b57ea73a5b6119777e8be75c68333088fa0de1cd84e9
```

### Performance mesurée
- **Évaluation moyenne 9–64 µs** par règle (budget : < 1 ms → marge 15×)
- 28/28 tests intégration PASS (5 ZeroPath + 2 autorisés + audit + endpoints)

### Fichiers
`agent-firewall/Cargo.toml`, `src/{main,prolog,firewall,server,audit}.rs`, `rules.pl`, `README.md`,
`run-tests.sh`, `test-report.txt`

---

## MODULE 3 — COGNITIVE STATE SNAPSHOT

### Problème
Quand une session de code plante ou qu'on change de machine, on perd tout le contexte de l'agent.

### Solution
Un format binaire compact qui capture l'état exact de l'agent (mémoire, contexte, intention,
code en cours) et permet de le restaurer plus tard.

### Structure sérialisée
```rust
pub struct AgentState {
    pub version: u16,                  // version du format (actuellement 1)
    pub agent_id: String,
    pub timestamp_ns: u128,
    pub memory: Vec<u8>,               // mémoire brute (peut être compressée)
    pub context: HashMap<String, String>,
    pub intent: String,
    pub code_snapshot: String,
    pub tags: Vec<String>,
}
```

### Format binaire NSNP (Nexus SnaPshot)

| Offset | Taille | Champ |
|---|---|---|
| 0      | 4      | Magic `NSNP` (0x4E534E50) |
| 4      | 2      | Version (`u16` LE) — actuellement `1` |
| 6      | 8      | Taille payload (`u64` LE) |
| 14     | N      | Payload bincode (AgentState sérialisé) |
| 14+N   | 4      | CRC32 (`u32` LE) du payload |

Taille totale = `14 + N + 4` exactement. Tout byte supplémentaire est rejeté (détection de
corruption).

### CLI
```bash
# Sauvegarde
snapshot-cli save \
  --agent-id "demo" \
  --intent "implement auth module" \
  --code-file src/auth.rs \
  --context lang=rust --context phase=v1 \
  --tag auth --tag security \
  -o state.bin

# Chargement (résumé lisible)
snapshot-cli load state.bin

# Chargement JSON complet
snapshot-cli load state.bin --json

# Vérification d'intégrité (magic + version + CRC32)
snapshot-cli verify state.bin         # exit 0 si OK, 1 si corrompu

# Métadonnées seulement
snapshot-cli info state.bin

# Liste tous les snapshots d'un dossier
snapshot-cli list /var/lib/agent/snapshots/
```

### Performance mesurée
- **Sauvegarde 1 Mo en 1.1 ms** (budget : < 50 ms → marge 43×)
- Débit : ~852 Mo/s
- 31/31 tests PASS (roundtrip + corruption + bench + JSON + champs individuels)

### Fichiers
`snapshot-cli/Cargo.toml`, `src/{state,cli,bench,main}.rs`, `state.bin` (exemple 206 octets),
`README.md`, `run-tests.sh`, `test-report.txt`

---

## MODULE 4 — SOVEREIGN AI GATEWAY

### Problème
Les entreprises utilisent OpenAI, Anthropic, Gemini et des modèles locaux. Elles passent
leur temps à adapter leur code pour chaque API.

### Solution
Un reverse proxy qui expose une API unifiée (au format OpenAI) et route les requêtes vers
le meilleur modèle disponible (local ou distant) en fonction de la tâche.

### API (port `127.0.0.1:9004`)

| Endpoint | Méthode | Description |
|---|---|---|
| `/v1/chat/completions` | POST | Format OpenAI strict. Réponse : `id`, `object`, `created`, `model`, `choices`, `usage`. Headers : `X-Cache: HIT/MISS`, `X-Backend: ollama/openai/anthropic/mock`, `X-Forward-Latency-Us: <µs>` |
| `/health` | GET | `status`, `backends`, `cache_size`, `cache_hits`, `cache_misses`, `routes_total` |
| `/config` | GET | Configuration (clés API masquées avec `***`) |
| `/cache/stats` | GET | `hits`, `misses`, `size`, `hit_rate` |
| `/cache/clear` | POST | Vide le cache |

Exemple :
```bash
./ai-gateway/ai-gateway -config config.json &
curl -X POST http://127.0.0.1:9004/v1/chat/completions \
     -H "Content-Type: application/json" \
     -d '{"model":"auto","messages":[{"role":"user","content":"Bonjour"}]}'
# {
#   "id":"chatcmpl-mock-...",
#   "object":"chat.completion",
#   "created":1793914557,
#   "model":"auto",
#   "choices":[{"index":0,"message":{"role":"assistant",
#                  "content":"[MOCK] réponse simulée..."},"finish_reason":"stop"}],
#   "usage":{"prompt_tokens":2,"completion_tokens":18,"total_tokens":20}
# }
```

### Routage
- `model:"auto"` → heuristique sur longueur du prompt (< 200 tokens estimés → Ollama local,
  sinon → OpenAI cloud)
- `model:"gpt-4o"` → backend OpenAI
- `model:"claude-3-5-sonnet"` → backend Anthropic (conversion format system→field,
  content[].text→choices)
- `model:"llama3.2"` → backend Ollama (OpenAI-compatible direct)
- Si backend indisponible (clé API absente, Ollama non lancé, etc.) → **fallback mock**
  garantissant que le gateway reste utilisable sans credentials

### Cache
- Clé : `SHA-256(prompt normalisé + model + temperature + max_tokens)`
- TTL configurable (`cache_ttl_seconds` dans `config.json`, défaut 1 h)
- Suppression paresseuse à l'expiration
- Thread-safe via `sync.RWMutex` + atomiques pour les compteurs

### Performance mesurée
- **Latence overhead moyenne 36 µs** (budget : < 10 ms → marge 278×)
- **Throughput 24 435 req/s** mesuré (100 workers × 100 req, mode mock, keep-alive)
- 100% de réussite sur 10 000 requêtes (bench Go dédié)

### Configuration (`config.json`)
```json
{
  "listen": "127.0.0.1:9004",
  "cache_ttl_seconds": 3600,
  "backends": {
    "ollama":   { "url": "http://127.0.0.1:11434/v1/chat/completions", "api_key": "", "default_model": "llama3.2", "timeout_seconds": 30 },
    "openai":   { "url": "https://api.openai.com/v1/chat/completions", "api_key": "", "default_model": "gpt-4o", "timeout_seconds": 60 },
    "anthropic":{ "url": "https://api.anthropic.com/v1/messages",      "api_key": "", "default_model": "claude-3-5-sonnet-20241022", "timeout_seconds": 60 }
  },
  "routing": {
    "auto_short_prompt_threshold_tokens": 200,
    "auto_short_prompt_backend": "ollama",
    "auto_long_prompt_backend": "openai"
  }
}
```

### Fichiers
`ai-gateway/go.mod`, `main.go`, `router.go`, `backends.go`, `cache.go`, `types.go`,
`config.json`, `bench/bench.go`, `README.md`, `run-tests.sh`, `test-report.txt`

---

## Architecture d'ensemble

```
                ┌─────────────────────────────────────────┐
                │   AGENT IA (LLM pilotant des outils)    │
                └─────────────────────────────────────────┘
                       │          │           │          │
                       ▼          ▼           ▼          ▼
                  ┌──────┐  ┌────────┐  ┌─────────┐  ┌─────────┐
                  │ MCP  │  │FIREWALL│  │SNAPSHOT │  │ GATEWAY │
                  │ 9001 │  │  9002  │  │  (CLI)  │  │  9004   │
                  └──────┘  └────────┘  └─────────┘  └─────────┘
                  DAG des   Zéro-Path    Capture     Route vers
                  dépend.   + audit      d'état      LLMs multi
                  + cache   SHA-256      binaire     (Ollama/
                                                        OpenAI/
                                                        Anthropic)
```

- **MCP (Module 1)** répond à « qu'est-ce que ce fichier dépend ? » en 100 ms pour 10 k fichiers
- **Firewall (Module 2)** intercepte chaque `execute` / `edit_file` / `read_file` / `network` et
  renvoie `allowed:false` si la règle Prolog matche, le tout en < 1 ms
- **Snapshot (Module 3)** permet à l'agent de dump son état (mémoire + contexte + intention +
  code en cours) toutes les N secondes pour reprise après crash
- **Gateway (Module 4)** unifie l'appel LLM en exposant `/v1/chat/completions` au format OpenAI,
  quel que soit le backend réel, avec cache SHA-256

---

## Validation

```bash
bash validate.sh    # → TEST_REPORT.md + exit 0 si 34/34 PASS
```

Résultat de la dernière exécution :

| Module | Tests | Détail clé |
|---|---|---|
| SCP | 4/4 PASS | 10 000 fichiers indexés en 100 ms |
| Firewall | 9/9 PASS | Évaluation 9–64 µs (< 1 ms) |
| Snapshot | 7/7 PASS | 1 Mo sérialisé en 1.1 ms |
| Gateway | 6/6 PASS | Latence overhead 36 µs, cache HIT, format OpenAI strict |
| **Bilan** | **34/34 PASS** | 0 FAIL, 0 WARN |

Rapport consolidé : [`TEST_REPORT.md`](TEST_REPORT.md)

Chaque module possède aussi son propre `test-report.txt` et son `run-tests.sh` pour des
tests isolés plus approfondis.

---

## Stack technique

| Composant | Techno | Dépendances externes |
|---|---|---|
| SCP | Rust 1.99 + std | `serde`, `serde_json` |
| Firewall | Rust 1.99 + std | `serde`, `serde_json`, `sha2` (mini-Prolog from scratch) |
| Snapshot | Rust 1.99 + std | `serde`, `bincode`, `crc32fast`, `clap` v4 |
| Gateway | Go 1.23 stdlib | **zéro** (uniquement `net/http`, `encoding/json`, `crypto/sha256`, `sync`, `context`) |

Serveurs HTTP : écrits à la main sur `std::net::TcpListener` (Rust) ou `net/http` (Go),
**aucun framework**. Aucune dépendance cloud, aucune télémétrie, aucune clé API requise
pour la validation (mode mock intégré).

---

## Limitations connues

- **SCP** : résolution heuristique des imports (couvre les cas courants Rust/Python/Go/JS/TS/MD,
  ne gère pas les `paths` alias TS ni les `sys.path` Python avancés).
- **Firewall** : sous-ensemble Prolog (pas de `is/2`, cuts `!`, négation `\+`,
  tail-list `|`). Suffisant pour un firewall d'intention.
- **Snapshot** : version 1 uniquement. Pas de streaming parser (snapshot tout en mémoire,
  OK jusqu'à ~100 Mo). CRC32 détecte la corruption accidentelle, pas le tampering
  adversarial (utiliser Ed25519 au-dessus pour la signature).
- **Gateway** : pas de streaming (`stream:true` ignoré). Cache en mémoire uniquement
  (pas de persistance inter-redémarrages). Mock non-intelligent (placeholder).

---

## Roadmap (suggestions)

- **SCP** : ajout d'un mode watch (inotify) pour re-indexer automatiquement sur changement
  de fichier.
- **Firewall** : ajouter un mode "dry-run" qui logge mais n'interdit pas, et un prédicat
  `whitelisted/2` pour autoriser explicitement certaines actions.
- **Snapshot** : compression optionnelle (lz4/zstd) du champ `memory` pour réduire la taille
  disque.
- **Gateway** : support du streaming SSE, persistance du cache sur disque, signature Ed25519
  des réponses cachées pour détecter le tampering.
