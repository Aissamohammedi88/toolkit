#!/usr/bin/env bash
# run-tests.sh - End-to-end test driver for MODULE 3 snapshot-cli.
# Produces test-report.txt with PASS/FAIL for each test + benchmark timing.
set -u
export PATH=$HOME/.cargo/bin:$PATH

ROOT=/home/z/my-project/download/sovereign-modules/snapshot-cli
BIN=$ROOT/target/release/snapshot-cli
REPORT=$ROOT/test-report.txt
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

PASS=0
FAIL=0
declare -a LINES

record() {
  # $1 = PASS/FAIL, $2 = label, $3 = optional detail
  if [ "$1" = "PASS" ]; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); fi
  LINES+=("$1 | $2 | $3")
}

run() {
  # $1 = label, rest = command. Records PASS/FAIL based on exit code.
  local label="$1"; shift
  local out
  out=$("$@" 2>&1); local rc=$?
  if [ $rc -eq 0 ]; then record PASS "$label" "exit=0"
  else record FAIL "$label" "exit=$rc :: $(echo "$out" | tail -1)"; fi
}

run_fail() {
  # $1 = label, rest = command. Records PASS if command FAILS (non-zero exit).
  local label="$1"; shift
  local out
  out=$("$@" 2>&1); local rc=$?
  if [ $rc -ne 0 ]; then record PASS "$label" "exit=$rc (expected non-zero) :: $(echo "$out" | tail -1)"
  else record FAIL "$label" "expected non-zero exit, got exit=0"; fi
}

echo "=== MODULE 3 - COGNITIVE STATE SNAPSHOT - TEST REPORT ==="
echo "Date: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
echo "Toolchain: $(rustc --version), $(cargo --version)"
echo "Root: $ROOT"
echo ""

# 0. Build
echo "--- Step 0: cargo build --release ---"
build_out=$(cd "$ROOT" && cargo build --release 2>&1); build_rc=$?
echo "$build_out" | tail -3
if [ $build_rc -eq 0 ]; then record PASS "cargo build --release" "exit=0"; else record FAIL "cargo build --release" "exit=$build_rc"; fi

# 0b. cargo test --release
echo "--- Step 0b: cargo test --release ---"
test_out=$(cd "$ROOT" && cargo test --release 2>&1); test_rc=$?
test_summary=$(echo "$test_out" | grep 'test result:')
echo "$test_summary"
if [ $test_rc -eq 0 ]; then record PASS "cargo test --release" "$test_summary"; else record FAIL "cargo test --release" "exit=$test_rc"; fi

# 1. save
run "save basic snapshot" $BIN save --agent-id "demo" --intent "test" --code "fn main(){}" --context lang=rust --tag v1 -o "$TMP/test.bin"
test -f "$TMP/test.bin" && [ -s "$TMP/test.bin" ] && record PASS "output file exists & non-empty" "$(stat -c%s "$TMP/test.bin") bytes" || record FAIL "output file exists" "missing or empty"

# 2. load (summary)
run "load summary" $BIN load "$TMP/test.bin"

# 3. load --json (validate with python)
json_out=$($BIN load "$TMP/test.bin" --json 2>/dev/null)
if echo "$json_out" | python3 -m json.tool >/dev/null 2>&1; then
  record PASS "load --json produces valid JSON" "$(echo "$json_out" | wc -c) bytes"
else
  record FAIL "load --json produces valid JSON" "python3 json.tool rejected"
fi

# 4. info
run "info" $BIN info "$TMP/test.bin"

# 5. verify (valid)
run "verify valid" $BIN verify "$TMP/test.bin"

# 6. corrupt + verify (should exit 1)
cp "$TMP/test.bin" "$TMP/corrupt.bin"
echo "x" >> "$TMP/corrupt.bin"
run_fail "verify corrupt (append)" $BIN verify "$TMP/corrupt.bin"
run_fail "load corrupt (append)" $BIN load "$TMP/corrupt.bin"

# 6b. corrupt via byte flip in payload
cp "$TMP/test.bin" "$TMP/corrupt2.bin"
python3 -c "
import sys
p='$TMP/corrupt2.bin'
b=bytearray(open(p,'rb').read())
b[20]^=0xff
open(p,'wb').write(b)
"
run_fail "verify corrupt (byte flip)" $BIN verify "$TMP/corrupt2.bin"

# 7. --field options
for f in version agent_id timestamp memory_hex context intent code tags; do
  run "load --field $f" $BIN load "$TMP/test.bin" --field "$f"
done

# 8. list
mkdir -p "$TMP/dir"
$BIN save --agent-id "agent-A" --intent "implement auth module with OAuth2 flow" --code "fn auth(){}" --context lang=rust --tag v1 -o "$TMP/dir/a.bin" >/dev/null
$BIN save --agent-id "agent-B" --intent "refactor database access layer" --code "fn db(){}" --tag v2 -o "$TMP/dir/b.bin" >/dev/null
$BIN save --agent-id "agent-C" --intent "write tests" --code "fn t(){}" -o "$TMP/dir/c.bin" >/dev/null
cp "$TMP/test.bin" "$TMP/dir/state.bin"
run "list directory" $BIN list "$TMP/dir"

# 9. benchmark
echo "--- Step 9: 1MB benchmark ---"
bench_out=$($BIN bench 2>&1)
echo "$bench_out"
mean_ms=$(echo "$bench_out" | grep 'mean save time' | grep -oE '[0-9.]+' | head -1)
target_str=$(echo "$bench_out" | grep 'target' | grep -oE '(PASS|FAIL)')
if [ "$target_str" = "PASS" ]; then
  record PASS "1MB benchmark < 50ms" "mean=${mean_ms} ms (target < 50 ms)"
else
  record FAIL "1MB benchmark < 50ms" "mean=${mean_ms} ms"
fi

# 10. state.bin demo file
echo "--- Step 10: state.bin demo ---"
$BIN gen-demo -o "$ROOT/state.bin" >/dev/null
if [ -f "$ROOT/state.bin" ]; then
  record PASS "state.bin generated" "$(stat -c%s "$ROOT/state.bin") bytes"
  run "verify state.bin" $BIN verify "$ROOT/state.bin"
else
  record FAIL "state.bin generated" "file missing"
fi

# 11. Cross-binary compatibility: load state.bin produced by gen-demo
run "load state.bin (demo)" $BIN load "$ROOT/state.bin"
state_json=$($BIN load "$ROOT/state.bin" --json 2>/dev/null)
echo "$state_json" | python3 -m json.tool >/dev/null 2>&1 && record PASS "state.bin JSON valid" "$(echo "$state_json" | wc -c) bytes" || record FAIL "state.bin JSON valid" "rejected"

# 12. --memory-file option
head -c 1024 /dev/urandom > "$TMP/mem.bin"
run "save with --memory-file" $BIN save --agent-id "mem-agent" --intent "memory test" --memory-file "$TMP/mem.bin" -o "$TMP/mem_snap.bin"
mem_hex=$($BIN load "$TMP/mem_snap.bin" --field memory_hex 2>/dev/null)
expected_len=$((1024 * 2))
[ ${#mem_hex} -eq $expected_len ] && record PASS "memory roundtrip hex length" "${#mem_hex} hex chars ($expected_len expected)" || record FAIL "memory roundtrip hex length" "got ${#mem_hex}, expected $expected_len"

# 13. --code-file option
echo "fn from_file() { /* ok */ }" > "$TMP/code.rs"
run "save with --code-file" $BIN save --agent-id "cf-agent" --intent "code file" --code-file "$TMP/code.rs" -o "$TMP/cf.bin"
code_back=$($BIN load "$TMP/cf.bin" --field code 2>/dev/null)
[ "$code_back" = "fn from_file() { /* ok */ }" ] && record PASS "code-file roundtrip" "code preserved" || record FAIL "code-file roundtrip" "got '$code_back'"

# 14. Multiple context and tags
run "save multi context+tags" $BIN save --agent-id "multi" --intent "multi" --context a=1 --context b=2 --context c=3 --tag t1 --tag t2 --tag t3 -o "$TMP/multi.bin"
ctx_json=$($BIN load "$TMP/multi.bin" --field context 2>/dev/null)
echo "$ctx_json" | python3 -m json.tool >/dev/null 2>&1 && record PASS "multi-context JSON valid" "$ctx_json" || record FAIL "multi-context JSON valid" "$ctx_json"

# === Final report ===
{
echo "=== MODULE 3 - COGNITIVE STATE SNAPSHOT - TEST REPORT ==="
echo "Generated: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
echo "Toolchain: $(rustc --version 2>&1), $(cargo --version 2>&1)"
echo "Root: $ROOT"
echo ""
echo "Summary: $PASS passed, $FAIL failed, $((PASS+FAIL)) total"
echo ""
echo "Per-test result:"
echo "STATUS  | TEST                                                 | DETAIL"
echo "--------+------------------------------------------------------+----------------------------------------"
for line in "${LINES[@]}"; do
  # line format: "PASS | label | detail" - split on first two ' | ' only.
  status="${line%% | *}"
  rest="${line#* | }"
  label="${rest%% | *}"
  detail="${rest#* | }"
  if [ "$label" = "$rest" ]; then detail=""; fi
  printf '%-7s | %-52s | %s\n' "$status" "$label" "$detail"
done
echo ""
echo "--- Benchmark detail ---"
echo "$bench_out"
echo ""
echo "--- state.bin metadata ---"
$BIN info "$ROOT/state.bin"
echo ""
echo "--- Files in module ---"
ls -la "$ROOT"/*.rs "$ROOT"/*.toml "$ROOT"/*.md "$ROOT"/*.bin "$ROOT"/*.sh 2>/dev/null
echo ""
echo "--- LOC ---"
wc -l "$ROOT"/src/*.rs "$ROOT"/Cargo.toml "$ROOT"/README.md "$ROOT"/run-tests.sh 2>/dev/null
} | tee "$REPORT"

echo ""
echo "Report written to: $REPORT"
[ $FAIL -eq 0 ] && exit 0 || exit 1
