//! `state.rs` - Core `AgentState` structure and binary (de)serialization.
//!
//! Binary format ("NSNP" - Nexus SnaPshot):
//! ```text
//! Offset  Size  Field
//! 0       4     Magic "NSNP"
//! 4       2     Version (u16 LE)
//! 6       8     Payload size (u64 LE)
//! 14      N     Payload bincode (serialized AgentState)
//! 14+N    4     CRC32 (u32 LE) of the payload
//! ```
//!
//! The magic + version header allow forward compatibility (future versions
//! can be rejected with a clear error). The CRC32 trailer guarantees payload
//! integrity (bit-flip / truncation / corruption detection).

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::time::{SystemTime, UNIX_EPOCH};

/// Magic bytes identifying a Nexus Snapshot file.
pub const MAGIC: &[u8; 4] = b"NSNP";

/// Current supported on-disk format version.
pub const FORMAT_VERSION: u16 = 1;

/// Header size in bytes: magic(4) + version(2) + payload_size(8) = 14
pub const HEADER_SIZE: usize = 14;

/// Trailer size in bytes: CRC32 (4)
pub const TRAILER_SIZE: usize = 4;

/// Minimum valid file size: header + 0 payload + trailer = 18
pub const MIN_FILE_SIZE: usize = HEADER_SIZE + TRAILER_SIZE;

/// The complete cognitive state of an AI agent at a given instant.
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct AgentState {
    /// Format version (starts at 1, mirrors file header version).
    pub version: u16,
    /// Unique agent identifier.
    pub agent_id: String,
    /// Capture timestamp, nanoseconds since UNIX epoch.
    pub timestamp_ns: u128,
    /// Raw agent memory (may be compressed context blob).
    pub memory: Vec<u8>,
    /// Free-form key/value context map.
    pub context: HashMap<String, String>,
    /// Current intent (e.g. "implement auth module").
    pub intent: String,
    /// Code currently being edited.
    pub code_snapshot: String,
    /// Free tags for search / classification.
    pub tags: Vec<String>,
}

/// All errors that can occur while reading or writing a snapshot.
#[derive(Debug)]
pub enum SnapshotError {
    /// Underlying IO error (file not found, permission, ...).
    Io(std::io::Error),
    /// bincode (de)serialization failure.
    Bincode(bincode::Error),
    /// Magic bytes did not match `NSNP`.
    BadMagic([u8; 4]),
    /// Version field is higher than what we support.
    UnsupportedVersion(u16),
    /// Stored CRC32 != recomputed CRC32.
    ChecksumMismatch { expected: u32, actual: u32 },
    /// File is shorter than the minimum layout.
    Truncated,
    /// File total size != HEADER_SIZE + payload_len + TRAILER_SIZE
    /// (trailing bytes appended, or file partially truncated past the header).
    SizeMismatch { expected: usize, actual: usize },
    /// `--field` requested an unknown field name.
    UnknownField(String),
}

impl std::fmt::Display for SnapshotError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Io(e) => write!(f, "io error: {e}"),
            Self::Bincode(e) => write!(f, "bincode error: {e}"),
            Self::BadMagic(m) => write!(
                f,
                "bad magic bytes: 0x{:02x}{:02x}{:02x}{:02x} ({:?}) - expected \"NSNP\"",
                m[0], m[1], m[2], m[3],
                std::str::from_utf8(m).unwrap_or("<binary>")
            ),
            Self::UnsupportedVersion(v) => write!(
                f,
                "unsupported snapshot version {v} (this binary supports version {FORMAT_VERSION} only)"
            ),
            Self::ChecksumMismatch { expected, actual } => write!(
                f,
                "CRC32 checksum mismatch: stored=0x{expected:08x} recomputed=0x{actual:08x} - file is corrupt"
            ),
            Self::Truncated => write!(f, "snapshot file is truncated (smaller than minimum {MIN_FILE_SIZE} bytes)"),
            Self::SizeMismatch { expected, actual } => write!(
                f,
                "file size mismatch: expected {expected} bytes (= 14 header + payload + 4 crc), got {actual} - file has been truncated or has trailing bytes"
            ),
            Self::UnknownField(s) => write!(
                f,
                "unknown field '{s}' - valid fields: version, agent_id, timestamp, memory_hex, context, intent, code, tags"
            ),
        }
    }
}

impl std::error::Error for SnapshotError {}

impl From<std::io::Error> for SnapshotError {
    fn from(e: std::io::Error) -> Self {
        Self::Io(e)
    }
}
impl From<bincode::Error> for SnapshotError {
    fn from(e: bincode::Error) -> Self {
        Self::Bincode(e)
    }
}

/// Parsed but not-yet-validated header (magic, version, payload size, stored crc).
/// Used by `info` and `verify` commands.
#[derive(Debug, Clone)]
pub struct SnapshotHeader {
    pub magic: [u8; 4],
    pub version: u16,
    pub payload_len: u64,
    pub stored_crc: u32,
    pub computed_crc: u32,
    pub file_size: usize,
}

impl SnapshotHeader {
    /// True iff magic matches AND stored crc == recomputed crc.
    #[allow(dead_code)]
    pub fn is_valid(&self) -> bool {
        &self.magic == MAGIC && self.stored_crc == self.computed_crc
    }
}

impl AgentState {
    /// Build a new AgentState with `version = FORMAT_VERSION` and a timestamp
    /// captured at call time (nanoseconds since UNIX epoch).
    pub fn new(
        agent_id: String,
        intent: String,
        code_snapshot: String,
        memory: Vec<u8>,
        context: HashMap<String, String>,
        tags: Vec<String>,
    ) -> Self {
        let timestamp_ns = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_nanos())
            .unwrap_or(0);
        Self {
            version: FORMAT_VERSION,
            agent_id,
            timestamp_ns,
            memory,
            context,
            intent,
            code_snapshot,
            tags,
        }
    }

    /// Serialize self into the on-disk NSNP binary format
    /// (magic + version + size + bincode payload + CRC32).
    ///
    /// This is infallible in practice (bincode only fails on unbounded types,
    /// which we don't have here) so we panic on the impossible failure.
    pub fn to_bytes(&self) -> Vec<u8> {
        let payload = bincode::serialize(self).expect("bincode::serialize AgentState");
        let crc = crc32fast::hash(&payload);
        let total = HEADER_SIZE + payload.len() + TRAILER_SIZE;
        let mut out = Vec::with_capacity(total);
        out.extend_from_slice(MAGIC);
        out.extend_from_slice(&FORMAT_VERSION.to_le_bytes());
        out.extend_from_slice(&(payload.len() as u64).to_le_bytes());
        out.extend_from_slice(&payload);
        out.extend_from_slice(&crc.to_le_bytes());
        out
    }

    /// Deserialize a NSNP file from raw bytes. Verifies magic, version, total
    /// size (no trailing/missing bytes) and CRC32.
    pub fn from_bytes(data: &[u8]) -> Result<Self, SnapshotError> {
        let header = parse_header(data)?;
        if header.magic != *MAGIC {
            return Err(SnapshotError::BadMagic(header.magic));
        }
        if header.version != FORMAT_VERSION {
            return Err(SnapshotError::UnsupportedVersion(header.version));
        }
        let expected_total = HEADER_SIZE + header.payload_len as usize + TRAILER_SIZE;
        if data.len() != expected_total {
            return Err(SnapshotError::SizeMismatch {
                expected: expected_total,
                actual: data.len(),
            });
        }
        if header.stored_crc != header.computed_crc {
            return Err(SnapshotError::ChecksumMismatch {
                expected: header.stored_crc,
                actual: header.computed_crc,
            });
        }
        let payload_len = header.payload_len as usize;
        let payload = &data[HEADER_SIZE..HEADER_SIZE + payload_len];
        let state: AgentState = bincode::deserialize(payload)?;
        Ok(state)
    }

    /// Render this snapshot as a single line of pretty JSON.
    /// We avoid adding `serde_json` as a dependency (spec: zero deps beyond
    /// serde/bincode/crc32fast/clap) and emit JSON manually with proper escaping.
    pub fn to_json(&self) -> String {
        let mut s = String::with_capacity(256 + self.memory.len() * 2);
        s.push('{');
        s.push_str(&format!("\"version\":{}", self.version));
        s.push_str(&format!(",\"agent_id\":{}", json_str(&self.agent_id)));
        s.push_str(&format!(",\"timestamp_ns\":{}", self.timestamp_ns));
        s.push_str(&format!(",\"timestamp_iso\":{}", json_str(&iso8601_from_ns(self.timestamp_ns))));
        s.push_str(",\"memory_hex\":\"");
        s.push_str(&hex_encode(&self.memory));
        s.push('"');
        s.push_str(&format!(",\"memory_size\":{}", self.memory.len()));
        s.push_str(",\"context\":{");
        let mut first = true;
        // Sort keys for deterministic output (HashMap iteration order is random).
        let mut keys: Vec<&String> = self.context.keys().collect();
        keys.sort();
        for k in keys {
            if !first {
                s.push(',');
            }
            first = false;
            s.push_str(&json_str(k));
            s.push(':');
            s.push_str(&json_str(&self.context[k]));
        }
        s.push('}');
        s.push_str(&format!(",\"context_count\":{}", self.context.len()));
        s.push_str(&format!(",\"intent\":{}", json_str(&self.intent)));
        s.push_str(&format!(",\"code_snapshot\":{}", json_str(&self.code_snapshot)));
        s.push_str(&format!(",\"code_size\":{}", self.code_snapshot.len()));
        s.push_str(",\"tags\":[");
        for (i, t) in self.tags.iter().enumerate() {
            if i > 0 {
                s.push(',');
            }
            s.push_str(&json_str(t));
        }
        s.push(']');
        s.push('}');
        s
    }

    /// Render a single field by name (used by `load --field <name>`).
    /// Returns the raw string value (no quoting for scalars, JSON for maps/arrays).
    pub fn field(&self, name: &str) -> Result<String, SnapshotError> {
        Ok(match name {
            "version" => self.version.to_string(),
            "agent_id" => self.agent_id.clone(),
            "timestamp" => iso8601_from_ns(self.timestamp_ns),
            "timestamp_ns" => self.timestamp_ns.to_string(),
            "memory_hex" => hex_encode(&self.memory),
            "memory_size" => self.memory.len().to_string(),
            "context" => {
                // JSON object, keys sorted.
                let mut s = String::from("{");
                let mut keys: Vec<&String> = self.context.keys().collect();
                keys.sort();
                for (i, k) in keys.iter().enumerate() {
                    if i > 0 {
                        s.push(',');
                    }
                    s.push_str(&json_str(k));
                    s.push(':');
                    s.push_str(&json_str(&self.context[*k]));
                }
                s.push('}');
                s
            }
            "intent" => self.intent.clone(),
            "code" => self.code_snapshot.clone(),
            "code_size" => self.code_snapshot.len().to_string(),
            "tags" => {
                let mut s = String::from("[");
                for (i, t) in self.tags.iter().enumerate() {
                    if i > 0 {
                        s.push(',');
                    }
                    s.push_str(&json_str(t));
                }
                s.push(']');
                s
            }
            "context_count" => self.context.len().to_string(),
            other => return Err(SnapshotError::UnknownField(other.to_string())),
        })
    }

    /// Build a one-shot human-readable summary (multi-line).
    pub fn summary(&self) -> String {
        let first_tag = self.tags.first().map(String::as_str).unwrap_or("(none)");
        format!(
            "version       : {}\nagent_id      : {}\ntimestamp     : {} ({} ns)\nmemory_size   : {} bytes\ncontext_count : {} keys\ncode_size     : {} bytes\nintent        : {}\nfirst_tag     : {}",
            self.version,
            self.agent_id,
            iso8601_from_ns(self.timestamp_ns),
            self.timestamp_ns,
            self.memory.len(),
            self.context.len(),
            self.code_snapshot.len(),
            self.intent,
            first_tag,
        )
    }
}

/// Parse only the NSNP header + trailer, verify length, compute CRC.
/// Does NOT verify magic/version/checksum equality (caller decides).
pub fn parse_header(data: &[u8]) -> Result<SnapshotHeader, SnapshotError> {
    if data.len() < MIN_FILE_SIZE {
        return Err(SnapshotError::Truncated);
    }
    let mut magic = [0u8; 4];
    magic.copy_from_slice(&data[0..4]);
    let version = u16::from_le_bytes([data[4], data[5]]);
    let payload_len = u64::from_le_bytes(data[6..14].try_into().unwrap());
    let need = HEADER_SIZE
        .checked_add(payload_len as usize)
        .and_then(|n| n.checked_add(TRAILER_SIZE))
        .ok_or(SnapshotError::Truncated)?;
    if data.len() < need {
        return Err(SnapshotError::Truncated);
    }
    let payload = &data[HEADER_SIZE..HEADER_SIZE + payload_len as usize];
    let crc_start = HEADER_SIZE + payload_len as usize;
    let stored_crc = u32::from_le_bytes(data[crc_start..crc_start + 4].try_into().unwrap());
    let computed_crc = crc32fast::hash(payload);
    Ok(SnapshotHeader {
        magic,
        version,
        payload_len,
        stored_crc,
        computed_crc,
        file_size: data.len(),
    })
}

/// Verify a NSNP file fully: magic + supported version + CRC32.
/// Returns Ok(()) if valid, Err otherwise.
pub fn verify_bytes(data: &[u8]) -> Result<(), SnapshotError> {
    // Walk through the full pipeline; if from_bytes succeeds, it's valid.
    AgentState::from_bytes(data)?;
    Ok(())
}

// ---------------------------------------------------------------------------
// Helpers (JSON escaping, hex encoding, ISO-8601 conversion).
// ---------------------------------------------------------------------------

/// Escape a Rust string into a JSON string literal (including surrounding quotes).
fn json_str(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            '\u{08}' => out.push_str("\\b"),
            '\u{0c}' => out.push_str("\\f"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
    out
}

/// Lowercase hex encoding of a byte slice.
pub fn hex_encode(bytes: &[u8]) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        s.push(HEX[(b >> 4) as usize] as char);
        s.push(HEX[(b & 0x0f) as usize] as char);
    }
    s
}

/// Convert nanoseconds-since-UNIX-epoch into an ISO-8601 UTC string
/// (`YYYY-MM-DDTHH:MM:SS.nnnnnnnnnZ`). No external chrono dependency.
pub fn iso8601_from_ns(ns: u128) -> String {
    let secs_total = (ns / 1_000_000_000) as i64;
    let nanos = (ns % 1_000_000_000) as u32;
    let days = secs_total.div_euclid(86400);
    let secs_of_day = secs_total.rem_euclid(86400);
    let hour = secs_of_day / 3600;
    let min = (secs_of_day % 3600) / 60;
    let sec = secs_of_day % 60;
    // Howard Hinnant's civil-from-days algorithm.
    let z = days + 719_468;
    let era = if z >= 0 { z } else { z - 146_096 } / 146_097;
    let doe = z - era * 146_097;
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    let year = y + if m <= 2 { 1 } else { 0 };
    format!(
        "{:04}-{:02}-{:02}T{:02}:{:02}:{:02}.{:09}Z",
        year, m, d, hour, min, sec, nanos
    )
}

// ---------------------------------------------------------------------------
// Unit tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    fn demo() -> AgentState {
        let mut ctx = HashMap::new();
        ctx.insert("lang".to_string(), "rust".to_string());
        ctx.insert("v".to_string(), "1.99".to_string());
        AgentState::new(
            "demo-agent".to_string(),
            "implement sovereign modules".to_string(),
            "fn main() {}".to_string(),
            vec![0xde, 0xad, 0xbe, 0xef],
            ctx,
            vec!["demo".to_string(), "v1".to_string()],
        )
    }

    #[test]
    fn roundtrip_basic() {
        let s = demo();
        let bytes = s.to_bytes();
        let back = AgentState::from_bytes(&bytes).expect("roundtrip");
        assert_eq!(back.version, s.version);
        assert_eq!(back.agent_id, s.agent_id);
        assert_eq!(back.intent, s.intent);
        assert_eq!(back.code_snapshot, s.code_snapshot);
        assert_eq!(back.memory, s.memory);
        assert_eq!(back.tags, s.tags);
        assert_eq!(back.context, s.context);
        assert_eq!(back.timestamp_ns, s.timestamp_ns);
    }

    #[test]
    fn magic_layout() {
        let s = demo();
        let bytes = s.to_bytes();
        assert_eq!(&bytes[0..4], b"NSNP");
        assert_eq!(u16::from_le_bytes([bytes[4], bytes[5]]), FORMAT_VERSION);
        let payload_len = u64::from_le_bytes(bytes[6..14].try_into().unwrap()) as usize;
        assert_eq!(bytes.len(), HEADER_SIZE + payload_len + TRAILER_SIZE);
        let payload = &bytes[HEADER_SIZE..HEADER_SIZE + payload_len];
        let stored_crc = u32::from_le_bytes(
            bytes[HEADER_SIZE + payload_len..HEADER_SIZE + payload_len + 4].try_into().unwrap(),
        );
        assert_eq!(stored_crc, crc32fast::hash(payload));
    }

    #[test]
    fn detects_bad_magic() {
        let s = demo();
        let mut bytes = s.to_bytes();
        bytes[0] = b'X';
        assert!(matches!(AgentState::from_bytes(&bytes), Err(SnapshotError::BadMagic(_))));
    }

    #[test]
    fn detects_unsupported_version() {
        let s = demo();
        let mut bytes = s.to_bytes();
        bytes[4] = 0xff;
        bytes[5] = 0xff;
        assert!(matches!(
            AgentState::from_bytes(&bytes),
            Err(SnapshotError::UnsupportedVersion(_))
        ));
    }

    #[test]
    fn detects_crc_corruption() {
        let s = demo();
        let mut bytes = s.to_bytes();
        // Flip a byte in the payload (after header).
        let payload_len = u64::from_le_bytes(bytes[6..14].try_into().unwrap()) as usize;
        let last_payload_byte = HEADER_SIZE + payload_len - 1;
        bytes[last_payload_byte] ^= 0xff;
        assert!(matches!(
            AgentState::from_bytes(&bytes),
            Err(SnapshotError::ChecksumMismatch { .. })
        ));
    }

    #[test]
    fn detects_truncation() {
        let s = demo();
        let bytes = s.to_bytes();
        let short = &bytes[..10];
        assert!(matches!(AgentState::from_bytes(short), Err(SnapshotError::Truncated)));
    }

    #[test]
    fn detects_trailing_bytes() {
        // Appending bytes after the CRC32 trailer must be detected as corruption
        // (this is the `echo "x" >> file` tampering case from the spec).
        let s = demo();
        let mut bytes = s.to_bytes();
        bytes.push(b'x');
        assert!(matches!(
            AgentState::from_bytes(&bytes),
            Err(SnapshotError::SizeMismatch { .. })
        ));
    }

    #[test]
    fn verify_ok_on_valid() {
        let s = demo();
        let bytes = s.to_bytes();
        assert!(verify_bytes(&bytes).is_ok());
    }

    #[test]
    fn verify_fails_on_corrupt() {
        let s = demo();
        let mut bytes = s.to_bytes();
        bytes[20] ^= 0x01;
        assert!(verify_bytes(&bytes).is_err());
    }

    #[test]
    fn json_is_parseable_shape() {
        // We don't have serde_json so just check structural markers.
        let s = demo();
        let j = s.to_json();
        assert!(j.starts_with('{'));
        assert!(j.ends_with('}'));
        assert!(j.contains("\"agent_id\":\"demo-agent\""));
        assert!(j.contains("\"version\":1"));
        assert!(j.contains("\"intent\":\"implement sovereign modules\""));
        assert!(j.contains("\"tags\":[\"demo\",\"v1\"]"));
    }

    #[test]
    fn field_lookup() {
        let s = demo();
        assert_eq!(s.field("version").unwrap(), "1");
        assert_eq!(s.field("agent_id").unwrap(), "demo-agent");
        assert_eq!(s.field("intent").unwrap(), "implement sovereign modules");
        assert_eq!(s.field("code").unwrap(), "fn main() {}");
        assert_eq!(s.field("code_size").unwrap(), "12");
        assert_eq!(s.field("context_count").unwrap(), "2");
        assert!(s.field("memory_hex").unwrap().contains("deadbeef"));
        assert!(s.field("bogus").is_err());
    }

    #[test]
    fn iso8601_known() {
        // 1970-01-01T00:00:00Z == 0 ns
        assert_eq!(iso8601_from_ns(0), "1970-01-01T00:00:00.000000000Z");
        // 1 second
        assert_eq!(iso8601_from_ns(1_000_000_000), "1970-01-01T00:00:01.000000000Z");
        // 2020-01-01T00:00:00Z = 1577836800 seconds
        let ns = 1_577_836_800u128 * 1_000_000_000;
        assert_eq!(iso8601_from_ns(ns), "2020-01-01T00:00:00.000000000Z");
    }

    #[test]
    fn json_escapes_quotes() {
        assert_eq!(json_str("a\"b"), "\"a\\\"b\"");
        assert_eq!(json_str("a\nb"), "\"a\\nb\"");
        assert_eq!(json_str("\u{1f}"), "\"\\u001f\"");
    }
}
