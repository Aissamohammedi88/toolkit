//! `cli.rs` - Sub-command handlers (save, load, info, verify, list).
//!
//! Each handler returns `Result<(), SnapshotError>`; `main.rs` maps the
//! result onto a process exit code (0 / 1) and prints errors to stderr.

use crate::state::{
    parse_header, verify_bytes, AgentState, SnapshotError, FORMAT_VERSION, HEADER_SIZE, MAGIC,
    TRAILER_SIZE,
};
use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};

/// Parse a single `key=val` CLI argument. Returns Err on malformed input.
fn parse_kv(s: &str) -> Result<(String, String), SnapshotError> {
    match s.split_once('=') {
        Some((k, v)) if !k.is_empty() => Ok((k.to_string(), v.to_string())),
        _ => Err(SnapshotError::UnknownField(format!(
            "bad --context value '{s}' (expected key=val)"
        ))),
    }
}

/// Read a file fully into a Vec<u8>.
fn read_file(path: &str) -> Result<Vec<u8>, SnapshotError> {
    fs::read(path).map_err(SnapshotError::Io)
}

/// `snapshot-cli save ...`
pub fn cmd_save(
    agent_id: String,
    intent: String,
    code_file: Option<String>,
    code: Option<String>,
    memory_file: Option<String>,
    context: Vec<String>,
    tags: Vec<String>,
    output: String,
) -> Result<(), SnapshotError> {
    // Resolve code_snapshot.
    let code_snapshot = match (code.as_ref(), code_file.as_ref()) {
        (Some(c), None) => c.clone(),
        (None, Some(path)) => {
            fs::read_to_string(path).map_err(|e| SnapshotError::Io(std::io::Error::new(
                e.kind(),
                format!("read --code-file {path}: {e}"),
            )))?
        }
        (Some(_), Some(_)) => {
            return Err(SnapshotError::UnknownField(
                "--code and --code-file are mutually exclusive".to_string(),
            ));
        }
        (None, None) => String::new(),
    };

    // Resolve memory.
    let memory = match memory_file.as_ref() {
        Some(path) => read_file(path)?,
        None => Vec::new(),
    };

    // Resolve context map.
    let mut ctx: HashMap<String, String> = HashMap::new();
    for item in &context {
        let (k, v) = parse_kv(item)?;
        ctx.insert(k, v);
    }

    let state = AgentState::new(agent_id, intent, code_snapshot, memory, ctx, tags);
    let bytes = state.to_bytes();
    fs::write(&output, &bytes)?;
    let size = bytes.len();
    println!(
        "saved snapshot -> {} ({} bytes, version={}, agent_id='{}')",
        output, size, state.version, state.agent_id
    );
    Ok(())
}

/// `snapshot-cli load <input>` (with optional --json / --field)
pub fn cmd_load(input: String, json: bool, field: Option<String>) -> Result<(), SnapshotError> {
    let bytes = read_file(&input)?;
    let state = AgentState::from_bytes(&bytes)?;
    if let Some(name) = field {
        // Single field mode (raw value, no decoration).
        println!("{}", state.field(&name)?);
        return Ok(());
    }
    if json {
        println!("{}", state.to_json());
        return Ok(());
    }
    // Default: human-readable summary.
    println!("{}", state.summary());
    Ok(())
}

/// `snapshot-cli info <input>` - header only (magic / version / crc / size).
pub fn cmd_info(input: String) -> Result<(), SnapshotError> {
    let bytes = read_file(&input)?;
    let header = parse_header(&bytes)?;
    let magic_str = std::str::from_utf8(&header.magic).unwrap_or("<binary>");
    let expected_total = HEADER_SIZE + header.payload_len as usize + TRAILER_SIZE;
    println!("file         : {}", input);
    println!("file_size    : {} bytes (expected {})", header.file_size, expected_total);
    println!("magic        : {} (0x{:02x}{:02x}{:02x}{:02x})",
        magic_str,
        header.magic[0], header.magic[1], header.magic[2], header.magic[3]);
    println!("version      : {} (supported: {})", header.version, FORMAT_VERSION);
    println!("payload_size : {} bytes", header.payload_len);
    println!("crc32_stored : 0x{:08x}", header.stored_crc);
    println!("crc32_actual : 0x{:08x}", header.computed_crc);
    println!("crc_match    : {}", header.stored_crc == header.computed_crc);
    println!("magic_match  : {}", &header.magic == MAGIC);
    println!("size_match   : {}", header.file_size == expected_total);
    Ok(())
}

/// `snapshot-cli verify <input>` - returns Ok(()) if valid (exit 0), Err otherwise (exit 1).
pub fn cmd_verify(input: String) -> Result<(), SnapshotError> {
    let bytes = read_file(&input)?;
    verify_bytes(&bytes)?;
    println!("OK: {} is a valid NSNP v{} snapshot (CRC32 verified)", input, FORMAT_VERSION);
    Ok(())
}

/// `snapshot-cli list <dir>` - list every .bin file with agent_id + ISO timestamp + intent.
pub fn cmd_list(dir: String) -> Result<(), SnapshotError> {
    let path = Path::new(&dir);
    if !path.is_dir() {
        return Err(SnapshotError::Io(std::io::Error::new(
            std::io::ErrorKind::NotFound,
            format!("not a directory: {dir}"),
        )));
    }
    // Collect and sort for deterministic output.
    let mut entries: Vec<PathBuf> = fs::read_dir(path)?
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().map_or(false, |ext| ext == "bin"))
        .collect();
    entries.sort();

    let total = entries.len();
    if total == 0 {
        println!("no .bin files in {}", dir);
        return Ok(());
    }

    println!("{:<32} {:<28} {}", "agent_id", "timestamp", "intent");
    println!("{:-<32} {:-<28} {:-<40}", "", "", "");

    let mut ok = 0usize;
    let mut bad = 0usize;
    for entry in &entries {
        let bytes = match fs::read(entry) {
            Ok(b) => b,
            Err(e) => {
                println!(
                    "{:<32} {:<28} {} (read error: {})",
                    "?", "?", entry.display(), e
                );
                bad += 1;
                continue;
            }
        };
        match AgentState::from_bytes(&bytes) {
            Ok(state) => {
                let intent_preview: String = state.intent.chars().take(50).collect();
                println!(
                    "{:<32} {:<28} {}",
                    state.agent_id,
                    crate::state::iso8601_from_ns(state.timestamp_ns),
                    intent_preview
                );
                ok += 1;
            }
            Err(e) => {
                println!("{:<32} {:<28} {} ({} bytes, invalid: {})",
                    "?", "?", entry.display(), bytes.len(), e);
                bad += 1;
            }
        }
    }
    println!("\nlisted {} .bin file(s): {} valid, {} invalid", total, ok, bad);
    Ok(())
}

// Re-export header constants for any external caller.
#[allow(dead_code)]
pub const _LAYOUT: (usize, usize) = (HEADER_SIZE, TRAILER_SIZE);
