//! `main.rs` - Entry point for `snapshot-cli` (Module 3 - Cognitive State Snapshot).
//!
//! CLI structure (clap v4 derive):
//!   snapshot-cli save    --agent-id <id> --intent <text> [--code-file <p> | --code <text>]
//!                          [--memory-file <p>] [--context key=val ...] [--tag t1 --tag t2]
//!                          -o <output.bin>
//!   snapshot-cli load    <input.bin> [--json] [--field <name>]
//!   snapshot-cli info    <input.bin>
//!   snapshot-cli verify  <input.bin>
//!   snapshot-cli list    <dir>
//!   snapshot-cli bench
//!   snapshot-cli gen-demo <output.bin>   (helper - writes the README example snapshot)

mod bench;
mod cli;
mod state;

use clap::{Parser, Subcommand};
use state::SnapshotError;
use std::process::ExitCode;

#[derive(Parser)]
#[command(
    name = "snapshot-cli",
    version,
    about = "MODULE 3 - Cognitive State Snapshot: versioned binary serialization of an AI agent state (memory, context, intent, code) with CRC32 integrity."
)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Save a new snapshot to a .bin file.
    Save {
        #[arg(long)]
        agent_id: String,
        #[arg(long)]
        intent: String,
        /// Read code snapshot from a file. Mutually exclusive with --code.
        #[arg(long)]
        code_file: Option<String>,
        /// Inline code snapshot. Mutually exclusive with --code-file.
        #[arg(long)]
        code: Option<String>,
        /// Read raw agent memory from a file (binary).
        #[arg(long)]
        memory_file: Option<String>,
        /// Context key=value pair. Repeatable: --context lang=rust --context v=1.99.
        #[arg(long = "context")]
        context: Vec<String>,
        /// Free-form tag. Repeatable: --tag demo --tag v1.
        #[arg(long = "tag")]
        tag: Vec<String>,
        /// Output .bin file path.
        #[arg(short = 'o', long = "output")]
        output: String,
    },
    /// Load a snapshot and print it (summary by default, full JSON with --json,
    /// or a single field value with --field <name>).
    Load {
        input: String,
        #[arg(long)]
        json: bool,
        /// Print only the value of one field (memory_hex, context, intent, code,
        /// tags, agent_id, timestamp, timestamp_ns, version, memory_size, code_size).
        #[arg(long)]
        field: Option<String>,
    },
    /// Print only the file header: magic, version, payload size, CRC32.
    Info { input: String },
    /// Verify magic + supported version + CRC32. Exit 0 if OK, 1 if corrupt.
    Verify { input: String },
    /// List every .bin file in a directory with agent_id / timestamp / intent.
    List { dir: String },
    /// Run the 1 MB serialization benchmark (target: < 50 ms mean save time).
    Bench,
    /// Generate the demo state.bin shipped with the module (helper).
    GenDemo {
        /// Output path (defaults to ./state.bin).
        #[arg(short = 'o', long = "output", default_value = "state.bin")]
        output: String,
    },
}

fn run() -> Result<(), SnapshotError> {
    let cli = Cli::parse();
    match cli.command {
        Commands::Save {
            agent_id,
            intent,
            code_file,
            code,
            memory_file,
            context,
            tag,
            output,
        } => cli::cmd_save(agent_id, intent, code_file, code, memory_file, context, tag, output),
        Commands::Load { input, json, field } => cli::cmd_load(input, json, field),
        Commands::Info { input } => cli::cmd_info(input),
        Commands::Verify { input } => cli::cmd_verify(input),
        Commands::List { dir } => cli::cmd_list(dir),
        Commands::Bench => {
            let _ = bench::bench_1mb();
            Ok(())
        }
        Commands::GenDemo { output } => {
            let mut ctx = std::collections::HashMap::new();
            ctx.insert("lang".to_string(), "rust".to_string());
            ctx.insert("version".to_string(), "1.99".to_string());
            let state = state::AgentState::new(
                "demo-agent".to_string(),
                "implement sovereign modules".to_string(),
                "fn main() {}".to_string(),
                Vec::new(),
                ctx,
                vec!["demo".to_string(), "v1".to_string()],
            );
            let bytes = state.to_bytes();
            std::fs::write(&output, &bytes)?;
            println!(
                "wrote demo snapshot -> {} ({} bytes, agent_id='demo-agent', version={})",
                output,
                bytes.len(),
                state.version
            );
            Ok(())
        }
    }
}

fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("error: {e}");
            ExitCode::from(1)
        }
    }
}
