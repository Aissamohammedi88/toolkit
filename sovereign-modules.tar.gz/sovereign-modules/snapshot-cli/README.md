# MODULE 3 — COGNITIVE STATE SNAPSHOT (`snapshot-cli`)

A versioned binary serialization format that captures the exact cognitive
state of an AI agent (memory, context, intent, code being edited) and lets
you restore it later. Designed for **crash recovery** and **cross-machine
transfer** of agent state.

100% local. Zero cloud. Zero external service.

---

## 1. Quick start

```bash
export PATH=$HOME/.cargo/bin:$PATH
cd sovereign-modules/snapshot-cli
cargo build --release

# Save a snapshot
./target/release/snapshot-cli save \
    --agent-id "demo" \
    --intent "implement auth module" \
    --code "fn main() { println!(\"hi\"); }" \
    --context lang=rust --context os=linux \
    --tag v1 --tag demo \
    -o /tmp/demo.bin

# Load it back (human-readable summary)
./target/release/snapshot-cli load /tmp/demo.bin

# Full JSON dump
./target/release/snapshot-cli load /tmp/demo.bin --json

# Just one field
./target/release/snapshot-cli load /tmp/demo.bin --field intent

# Header / checksum inspection
./target/release/snapshot-cli info   /tmp/demo.bin
./target/release/snapshot-cli verify /tmp/demo.bin   # exit 0 if OK, 1 if corrupt

# Walk a directory of snapshots
./target/release/snapshot-cli list /tmp/snapshots

# Run the 1 MB benchmark
./target/release/snapshot-cli bench
```

A demo file `state.bin` is shipped in this directory. Inspect it with
`./target/release/snapshot-cli info state.bin`.

---

## 2. Binary format — `NSNP` (Nexus SnaPshot)

All multi-byte integers are **little-endian**. The file layout is:

| Offset | Size  | Field                                    |
|--------|-------|------------------------------------------|
| 0      | 4     | Magic bytes `b"NSNP"` (0x4E 0x53 0x4E 0x50) |
| 4      | 2     | Version (`u16` LE) — currently `1`       |
| 6      | 8     | Payload size in bytes (`u64` LE)         |
| 14     | N     | Payload: `bincode`-serialized `AgentState` |
| 14+N   | 4     | CRC32 (`u32` LE) of the payload          |

Minimum file size: **18 bytes** (4 + 2 + 8 + 0 + 4).
Total file size must equal exactly `14 + N + 4` — any extra/missing bytes
are rejected as corruption.

The payload itself is a `bincode` (v1.x default config: little-endian,
fixed-width integers, `u64` length-prefixed sequences) serialization of:

```rust
pub struct AgentState {
    pub version: u16,             // mirrors header version
    pub agent_id: String,
    pub timestamp_ns: u128,       // nanoseconds since UNIX epoch
    pub memory: Vec<u8>,          // raw agent memory (may be compressed)
    pub context: HashMap<String, String>,
    pub intent: String,
    pub code_snapshot: String,
    pub tags: Vec<String>,
}
```

### 2.1 Why magic + version + CRC?

* **Magic `NSNP`** lets tools quickly identify the file format and reject
  foreign inputs (defensive parse).
* **Version** enables forward compatibility. A reader that only knows
  version 1 will refuse version 2+ with a clear
  `unsupported snapshot version N` error rather than silently
  misinterpreting bytes.
* **CRC32 (IEEE, polynomial 0xEDB88320 via `crc32fast`)** protects against
  bit-flips, truncation, and accidental append (trailing bytes are also
  rejected by the strict total-size check). On every `load` and `verify`,
  the stored CRC is compared to the recomputed CRC of the payload.

### 2.2 Worked example (hex dump)

For a snapshot `agent_id="demo"`, `intent="test"`, `code="fn main(){}"`,
`context={lang:rust}`, `tags=[v1]`, `memory=[]`:

```
4E 53 4E 50              ; magic "NSNP"
01 00                    ; version = 1 (LE)
77 00 00 00 00 00 00 00  ; payload size = 119 bytes (LE)
... 119 bytes payload ...; bincode(AgentState)
C7 85 3E 43              ; CRC32 = 0x433E85C7 (LE)
```

Use `snapshot-cli info <file>` to see this layout decoded for any file.

---

## 3. CLI reference

```
snapshot-cli --help

Subcommands:
  save      Save a new snapshot to a .bin file
  load      Load a snapshot and print it
  info      Print only the file header (magic / version / size / CRC32)
  verify    Verify magic + version + CRC32 (exit 0 if OK, 1 if corrupt)
  list      List every .bin file in a directory
  bench     Run the 1 MB serialization benchmark
  gen-demo  Generate the demo state.bin shipped with the module
```

### `save`

```
snapshot-cli save \
    --agent-id <id>            (required)
    --intent   <text>          (required)
   [--code <text> | --code-file <path>]   (mutually exclusive; default empty)
   [--memory-file <path>]                 (raw binary memory; default empty)
   [--context key=val]...                 (repeatable)
   [--tag t]...                           (repeatable)
    -o, --output <file>        (required)
```

### `load`

```
snapshot-cli load <input.bin>            # human-readable summary (default)
snapshot-cli load <input.bin> --json     # full snapshot as a single JSON line
snapshot-cli load <input.bin> --field <name>
    # <name> ∈ {version, agent_id, timestamp, timestamp_ns,
    #           memory_hex, memory_size, context, context_count,
    #           intent, code, code_size, tags}
```

### `info`

Prints: `file_size (expected)`, `magic` (ASCII + hex), `version`,
`payload_size`, `crc32_stored`, `crc32_actual`, plus three boolean flags
`crc_match`, `magic_match`, `size_match` so you can spot any discrepancy
at a glance.

### `verify`

Returns exit code **0** if (and only if) all of these hold:

1. `data.len() >= 18`
2. magic == `"NSNP"`
3. version == `1` (the only supported version)
4. `data.len() == 14 + payload_len + 4` (no extra/missing bytes)
5. stored CRC32 == recomputed CRC32 of the payload
6. payload deserializes cleanly with `bincode`

Otherwise prints a precise error message to stderr and returns exit code **1**.

### `list <dir>`

Walks `<dir>` for `*.bin` files (sorted), tries to load each, and prints
`agent_id | timestamp (ISO-8601 UTC) | intent (first 50 chars)`. Invalid
snapshots are listed with a `?` placeholder and the reason.

### `bench`

Generates a snapshot with `memory = 1_000_000` bytes, calls `to_bytes()`
100 times (with one warmup), and reports mean/min/max save time + throughput.
Target: mean save time **< 50 ms**.

---

## 4. Performance

On the dev box (Rust 1.99.1, release profile, `lto="thin"`,
`codegen-units=1`):

```
=== snapshot-cli 1MB benchmark ===
iterations     : 100
memory size    : 1000000 bytes
serialized size: 1000238 bytes (1.000 MB)
mean save time : ~1.15 ms
min  save time : ~1.12 ms
max  save time : ~1.22 ms
throughput     : ~870 MB/s
target         : < 50 ms  ->  PASS
```

We are ~43× under budget. `bincode` + `crc32fast` (SIMD-accelerated on
x86_64/aarch64) are well-suited to this workload.

---

## 5. Project layout

```
snapshot-cli/
├── Cargo.toml         # deps: serde (derive), bincode, crc32fast, clap (derive)
├── README.md          # this file
├── run-tests.sh       # end-to-end test driver, writes test-report.txt
├── test-report.txt    # last test run result (PASS/FAIL per test + bench)
├── state.bin          # demo snapshot (agent_id="demo-agent", ...)
└── src/
    ├── main.rs        # clap CLI definition + dispatch + exit-code mapping
    ├── state.rs       # AgentState struct, NSNP (de)serialization, CRC32, JSON
    ├── cli.rs         # sub-command handlers: save/load/info/verify/list
    └── bench.rs       # 1 MB benchmark
```

### Dependencies (exact, no others)

```toml
serde       = { version = "1", features = ["derive"] }
bincode     = "1"      # binary serialization (classic API: serialize/deserialize)
crc32fast   = "1"      # SIMD-accelerated CRC32 (IEEE)
clap        = { version = "4", features = ["derive"] }
```

---

## 6. Error model

All errors flow through a single `SnapshotError` enum (`src/state.rs`),
with `Display` + `std::error::Error` impls and `From` conversions for
`io::Error` and `bincode::Error`. Variants:

| Variant                | When                                                                  |
|------------------------|-----------------------------------------------------------------------|
| `Io(_)`                | File not found / permission / disk write failure                      |
| `Bincode(_)`           | bincode failed to deserialize the payload                             |
| `BadMagic([u8;4])`     | First 4 bytes != `"NSNP"`                                             |
| `UnsupportedVersion(u16)` | Header version ≠ 1 (the only version this binary supports)        |
| `ChecksumMismatch { expected, actual }` | Stored CRC32 ≠ recomputed CRC32                    |
| `Truncated`            | File smaller than the 18-byte minimum                                |
| `SizeMismatch { expected, actual }` | File size ≠ `14 + payload_len + 4` (trailing bytes / partial truncation) |
| `UnknownField(_)`      | `load --field <name>` given a name not in the allow-list             |

`main()` maps `Ok(())` to exit code 0 and any `Err` to exit code 1 with the
error message on stderr — so `verify` doubles as a CI/script gate.

---

## 7. Tests

```bash
cargo test --release    # 15 unit tests in state.rs + bench.rs
./run-tests.sh          # end-to-end CLI tests -> test-report.txt
```

Unit tests cover: roundtrip, magic/layout, bad magic, unsupported version,
CRC corruption, truncation, trailing-bytes detection, `verify` OK/fail,
JSON shape, `--field` lookup, ISO-8601 conversion, JSON string escaping.

End-to-end tests cover: build, unit tests, save, load (summary + JSON +
every `--field`), info, verify (valid + corrupted-by-append + corrupted-by-
byte-flip), list, 1 MB benchmark, `state.bin` generation and round-trip,
`--memory-file`, `--code-file`, multi-context, multi-tag.

Last run: **31 / 31 PASS** — see `test-report.txt`.

---

## 8. Limitations / future work

* **Version 1 only.** A v2 reader will need to be added when the format
  evolves; the magic+version header makes that safe.
* **No streaming.** The whole file is read into memory before parsing.
  Fine for the multi-MB scale this module targets; for >1 GB snapshots a
  streaming reader would be needed.
* **No compression.** `memory` may already be compressed by the agent; the
  snapshot format itself does not compress. A future `--compress` flag
  (zstd/flate2) would shrink large memory blobs at a small CPU cost.
* **CRC32 only.** Detects accidental corruption, not adversarial tampering
  (an attacker can recompute CRC32). For tamper-evidence, wrap the file
  with an Ed25519 signature in a higher module.
* **JSON output is hand-rolled** (the spec forbids `serde_json` as a
  dependency). It escapes correctly and is validated by `python3 -m
  json.tool` in the test suite, but does not aim to be a general JSON
  library.
* **`HashMap` iteration order is randomized** — for deterministic JSON
  output the `context` object's keys are sorted alphabetically.
