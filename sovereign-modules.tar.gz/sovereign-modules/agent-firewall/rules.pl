% ===========================================================================
% MODULE 2 - AGENT FIREWALL (ZÉRO-PATH) — rule base
% ===========================================================================
% Loaded by `agent-firewall --rules rules.pl`.
% Each fact/rule declares a `forbidden(Action, Args)` clause.
% The firewall evaluates `?- forbidden(action, args)` for every /gate call.
%
% Syntax:
%   * Atoms are lowercase: execute, rm, '/etc/passwd' (quoted because of '/')
%   * Variables are uppercase: X, Args, Action
%   * Lists: [a, b, c]
%   * Wildcards: any (matches anything), _ (matches anything), any_* (named)
% ===========================================================================

% --- Execute: dangerous commands -------------------------------------------
forbidden(execute, ['rm', '-rf', '/']).
forbidden(execute, ['rm', '-rf', any]).
forbidden(execute, ['rm', '-rf', '--no-preserve-root', '/']).
forbidden(execute, ['curl', 'http://evil.com']).
forbidden(execute, ['curl', 'https://evil.com']).
forbidden(execute, ['wget', 'http://evil.com']).
forbidden(execute, ['wget', 'https://malware.cn']).
forbidden(execute, ['wget', 'http://malware.cn']).
forbidden(execute, ['chmod', '777', any]).
forbidden(execute, ['chmod', '777', any_evil]).
forbidden(execute, ['chown', 'nobody', '/etc']).
forbidden(execute, ['dd', 'if=/dev/zero', 'of=/dev/sda']).
forbidden(execute, ['mkfs', '/dev/sda1']).
forbidden(execute, ['shutdown', '-h', 'now']).
forbidden(execute, ['kill', '-9', '1']).

% --- Edit files: sensitive targets -----------------------------------------
forbidden(edit_file, '/etc/passwd').
forbidden(edit_file, '/etc/shadow').
forbidden(edit_file, '/etc/sudoers').
forbidden(edit_file, 'credentials.yaml').
forbidden(edit_file, 'secrets.json').
forbidden(edit_file, '.env').
forbidden(edit_file, '.aws/credentials').

% --- Read files: secrets ---------------------------------------------------
forbidden(read_file, '/etc/shadow').
forbidden(read_file, '/etc/sudoers').
forbidden(read_file, '.ssh/id_rsa').
forbidden(read_file, 'credentials.yaml').

% --- Network: malicious domains --------------------------------------------
forbidden(network, 'evil.com').
forbidden(network, 'malware.cn').
forbidden(network, 'c2.botnet.example').
forbidden(network, 'exfil.attacker.io').

% --- Composed rules (clause body) ------------------------------------------
% Anything that is both a dangerous action AND targets a sensitive target
% is forbidden, regardless of the specific action name.
forbidden(Action, Args) :-
    dangerous_action(Action),
    sensitive_target(Args).

dangerous_action(execute).
dangerous_action(edit_file).
dangerous_action(read_file).
dangerous_action(network).

sensitive_target(['/etc/passwd']).
sensitive_target(['/etc/shadow']).
sensitive_target(['/etc/sudoers']).
sensitive_target(['credentials.yaml']).
sensitive_target(['secrets.json']).
sensitive_target(['/root/.ssh/id_rsa']).

% --- Optional: query examples (skipped at load time) -----------------------
% ?- forbidden(execute, ['rm', '-rf', '/']).
