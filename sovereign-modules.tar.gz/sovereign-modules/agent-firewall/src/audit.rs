//! Audit logger.
//!
//! Every `/gate` evaluation is appended to `audit.log` as a single line:
//!
//! ```text
//! 2026-11-06T12:34:56.789Z | ACTION=execute ARGS=["rm","-rf","/"] | ALLOWED=false | RULE=forbidden(execute,...) | SHA256=abc123...
//! ```
//!
//! The SHA-256 is computed over the normalised canonical string
//! `action|args_json` where `args_json` is the JSON-serialised args.

use sha2::{Digest, Sha256};
use std::fs::OpenOptions;
use std::io::Write;
use std::path::PathBuf;
use std::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};

pub struct AuditLogger {
    file: Mutex<PathBuf>,
    /// Counter of audit records written (used by /health).
    counter: Mutex<u64>,
}

impl AuditLogger {
    pub fn new(path: PathBuf) -> Result<Self, String> {
        // Make sure parent dir exists (or just the file).
        if let Some(parent) = path.parent() {
            if !parent.as_os_str().is_empty() && !parent.exists() {
                std::fs::create_dir_all(parent)
                    .map_err(|e| format!("Failed to create audit dir: {}", e))?;
            }
        }
        // Touch the file so subsequent reads succeed.
        OpenOptions::new()
            .create(true)
            .append(true)
            .open(&path)
            .map_err(|e| format!("Failed to open audit file: {}", e))?;
        Ok(AuditLogger { file: Mutex::new(path), counter: Mutex::new(0) })
    }

    pub fn records_written(&self) -> u64 {
        *self.counter.lock().unwrap()
    }

    /// Append one audit line. Returns the SHA-256 hex string that was logged.
    pub fn log(
        &self,
        action: &str,
        args: &serde_json::Value,
        allowed: bool,
        rule: Option<&str>,
    ) -> Result<String, String> {
        let args_json = serde_json::to_string(args).unwrap_or_else(|_| "null".to_string());
        let canonical = format!("{}|{}", action, args_json);
        let sha_hex = sha256_hex(&canonical);

        let ts = iso8601_utc_now();
        let rule_str = rule.unwrap_or("-");
        let allowed_str = if allowed { "true" } else { "false" };

        let line = format!(
            "{} | ACTION={} ARGS={} | ALLOWED={} | RULE={} | SHA256={}\n",
            ts, action, args_json, allowed_str, rule_str, sha_hex
        );

        let path = self.file.lock().unwrap().clone();
        let mut f = OpenOptions::new()
            .create(true)
            .append(true)
            .open(&path)
            .map_err(|e| format!("Failed to open audit file for write: {}", e))?;
        f.write_all(line.as_bytes())
            .map_err(|e| format!("Failed to write audit line: {}", e))?;

        *self.counter.lock().unwrap() += 1;
        Ok(sha_hex)
    }
}

/// Compute SHA-256 of `input` and return lowercase hex string (64 chars).
pub fn sha256_hex(input: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(input.as_bytes());
    let result = hasher.finalize();
    let mut out = String::with_capacity(64);
    for byte in result.iter() {
        out.push_str(&format!("{:02x}", byte));
    }
    out
}

/// Returns the current UTC time formatted as `YYYY-MM-DDTHH:MM:SS.mmmZ`.
pub fn iso8601_utc_now() -> String {
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_else(|_| std::time::Duration::ZERO);
    let secs = now.as_secs();
    let millis = now.subsec_millis();
    let (y, mo, d, h, mi, s) = unix_to_ymdhms(secs as i64);
    format!(
        "{:04}-{:02}-{:02}T{:02}:{:02}:{:02}.{:03}Z",
        y, mo, d, h, mi, s, millis
    )
}

fn is_leap(y: i64) -> bool {
    (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)
}

fn days_in_month(y: i64, m: usize) -> i64 {
    match m {
        1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
        4 | 6 | 9 | 11 => 30,
        2 => if is_leap(y) { 29 } else { 28 },
        _ => 0,
    }
}

/// Convert Unix seconds (UTC) to `(year, month, day, hour, minute, second)`.
fn unix_to_ymdhms(secs: i64) -> (i64, i64, i64, i64, i64, i64) {
    let secs_of_day = secs.rem_euclid(86400);
    let mut days = secs.div_euclid(86400);

    let hour = secs_of_day / 3600;
    let minute = (secs_of_day % 3600) / 60;
    let second = secs_of_day % 60;

    let mut year = 1970i64;
    loop {
        let dy = if is_leap(year) { 366 } else { 365 };
        if days < dy {
            break;
        }
        days -= dy;
        year += 1;
    }

    let mut month = 1i64;
    while days >= days_in_month(year, month as usize) {
        days -= days_in_month(year, month as usize);
        month += 1;
    }
    let day = days + 1;

    (year, month, day, hour, minute, second)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sha256_known_vector() {
        // SHA-256("abc") = ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad
        assert_eq!(
            sha256_hex("abc"),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
    }

    #[test]
    fn sha256_is_64_hex_chars() {
        let h = sha256_hex("anything");
        assert_eq!(h.len(), 64);
        assert!(h.chars().all(|c| c.is_ascii_hexdigit()));
    }

    #[test]
    fn audit_writes_one_line_per_call() {
        let tmp = std::env::temp_dir().join(format!("afw_audit_{}.log", std::process::id()));
        let _ = std::fs::remove_file(&tmp);
        let logger = AuditLogger::new(tmp.clone()).unwrap();
        let _ = logger
            .log("execute", &serde_json::json!(["rm", "-rf", "/"]), false, Some("forbidden(execute,...)"))
            .unwrap();
        let _ = logger
            .log("execute", &serde_json::json!(["ls", "-la"]), true, None)
            .unwrap();
        let content = std::fs::read_to_string(&tmp).unwrap();
        let lines: Vec<&str> = content.lines().collect();
        assert_eq!(lines.len(), 2);
        assert!(lines[0].contains("ALLOWED=false"));
        assert!(lines[1].contains("ALLOWED=true"));
        assert!(lines[0].contains("SHA256="));
        // SHA-256 hex is 64 chars after "SHA256=".
        let sha_part = lines[0].rsplit("SHA256=").next().unwrap();
        assert_eq!(sha_part.len(), 64);
        let _ = std::fs::remove_file(&tmp);
    }
}
