//! MODULE 2 - AGENT FIREWALL (ZÉRO-PATH)
//!
//! A local Prolog-backed firewall that vetoes AI agent actions before they
//! happen. The agent proposes `(action, args)` and the firewall evaluates the
//! goal `forbidden(action, args)` against a rule base loaded from `rules.pl`.
//!
//! CLI:
//!   --rules <path>   Path to rules.pl file (default: ./rules.pl)
//!   --bind  <addr>   Bind address (default: 127.0.0.1)
//!   --port  <port>   Bind port (default: 9002)
//!   --audit <path>   Audit log path (default: ./audit.log)
//!   --help           Show usage

mod audit;
mod firewall;
mod prolog;
mod server;

use std::path::PathBuf;
use std::sync::atomic::AtomicU64;
use std::sync::{Arc, RwLock};

use crate::audit::AuditLogger;
use crate::prolog::Engine;
use crate::server::AppState;

struct Cli {
    rules: PathBuf,
    bind: String,
    port: u16,
    audit: PathBuf,
}

fn print_usage() {
    eprintln!(
        "agent-firewall -- Module 2: Agent Firewall (Zero-Path)\n\
         Usage:\n\
         \x20  agent-firewall [--rules <rules.pl>] [--bind 127.0.0.1] [--port 9002] [--audit audit.log]\n\
         Flags:\n\
         \x20  --help   Show this help."
    );
}

fn parse_cli(argv: Vec<String>) -> Result<Cli, String> {
    let mut cli = Cli {
        rules: PathBuf::from("./rules.pl"),
        bind: "127.0.0.1".to_string(),
        port: 9002,
        audit: PathBuf::from("./audit.log"),
    };
    let mut i = 0;
    while i < argv.len() {
        let arg = &argv[i];
        match arg.as_str() {
            "--help" | "-h" => {
                print_usage();
                std::process::exit(0);
            }
            "--rules" => {
                i += 1;
                let v = argv.get(i).ok_or("--rules requires a value")?;
                cli.rules = PathBuf::from(v);
            }
            "--bind" => {
                i += 1;
                let v = argv.get(i).ok_or("--bind requires a value")?;
                cli.bind = v.clone();
            }
            "--port" => {
                i += 1;
                let v = argv.get(i).ok_or("--port requires a value")?;
                cli.port = v.parse().map_err(|e| format!("invalid --port: {}", e))?;
            }
            "--audit" => {
                i += 1;
                let v = argv.get(i).ok_or("--audit requires a value")?;
                cli.audit = PathBuf::from(v);
            }
            other => {
                return Err(format!("Unknown argument: {}", other));
            }
        }
        i += 1;
    }
    Ok(cli)
}

fn main() {
    let argv: Vec<String> = std::env::args().skip(1).collect();
    let cli = match parse_cli(argv) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("error: {}", e);
            print_usage();
            std::process::exit(2);
        }
    };

    // Load engine from rules.pl.
    let engine = match Engine::load_file(&cli.rules) {
        Ok(e) => e,
        Err(e) => {
            eprintln!("error: failed to load rules from {}: {}", cli.rules.display(), e);
            std::process::exit(3);
        }
    };
    eprintln!(
        "[agent-firewall] loaded {} clauses from {}",
        engine.rules_count(),
        cli.rules.display()
    );

    // Set up audit logger.
    let audit = match AuditLogger::new(cli.audit.clone()) {
        Ok(a) => a,
        Err(e) => {
            eprintln!("error: failed to open audit log {}: {}", cli.audit.display(), e);
            std::process::exit(4);
        }
    };

    let state = Arc::new(AppState {
        engine: Arc::new(RwLock::new(engine)),
        audit: Arc::new(audit),
        rules_path: cli.rules.clone(),
        audit_path: cli.audit.clone(),
        gate_calls: AtomicU64::new(0),
    });

    if let Err(e) = server::run(state, &cli.bind, cli.port) {
        eprintln!("error: server failed: {}", e);
        std::process::exit(5);
    }
}
