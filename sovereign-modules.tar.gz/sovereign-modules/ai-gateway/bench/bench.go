package main

// bench/bench.go — Client de benchmark pour mesurer le throughput du gateway.
//
// Lance N workers concurrents qui envoient chacun M requêtes POST au gateway
// via une connection HTTP keep-alive. Mesure le throughput (req/s) et le taux
// de réussite.
//
// Usage : go run ./bench -url http://127.0.0.1:9004/v1/chat/completions \
//                    -workers 100 -requests 10000

import (
	"bytes"
	"flag"
	"fmt"
	"io"
	"net/http"
	"os"
	"sync"
	"sync/atomic"
	"time"
)

func main() {
	url := flag.String("url", "http://127.0.0.1:9004/v1/chat/completions", "gateway URL")
	workers := flag.Int("workers", 100, "concurrent workers")
	requests := flag.Int("requests", 10000, "total requests")
	flag.Parse()

	// Transport avec keep-alive et pool de connections large.
	transport := &http.Transport{
		MaxIdleConns:        *workers + 10,
		MaxIdleConnsPerHost: *workers + 10,
		IdleConnTimeout:     60 * time.Second,
	}
	client := &http.Client{
		Transport: transport,
		Timeout:   30 * time.Second,
	}

	var ok int64
	var fail int64
	var totalLatencyNS int64

	var wg sync.WaitGroup
	reqsPerWorker := *requests / *workers
	if reqsPerWorker < 1 {
		reqsPerWorker = 1
	}
	actualTotal := reqsPerWorker * *workers

	fmt.Fprintf(os.Stderr, "Starting benchmark: %d workers × %d reqs = %d total\n",
		*workers, reqsPerWorker, actualTotal)

	start := time.Now()

	for w := 0; w < *workers; w++ {
		wg.Add(1)
		go func(wid int) {
			defer wg.Done()
			for i := 0; i < reqsPerWorker; i++ {
				// Body varié pour éviter le cache (mesure réelle du chemin complet).
				body := []byte(fmt.Sprintf(
					`{"model":"gpt-4o","messages":[{"role":"user","content":"bench-%d-%d"}]}`,
					wid, i))
				reqStart := time.Now()
				resp, err := client.Post(*url, "application/json", bytes.NewReader(body))
				reqLatency := time.Since(reqStart)
				atomic.AddInt64(&totalLatencyNS, reqLatency.Nanoseconds())
				if err != nil {
					atomic.AddInt64(&fail, 1)
					continue
				}
				_, _ = io.Copy(io.Discard, resp.Body)
				resp.Body.Close()
				if resp.StatusCode == 200 {
					atomic.AddInt64(&ok, 1)
				} else {
					atomic.AddInt64(&fail, 1)
				}
			}
		}(w)
	}

	wg.Wait()

	dur := time.Since(start)
	qps := float64(atomic.LoadInt64(&ok)) / dur.Seconds()
	successRate := float64(atomic.LoadInt64(&ok)) * 100 / float64(actualTotal)
	avgLatencyUS := float64(atomic.LoadInt64(&totalLatencyNS)/int64(actualTotal)) / 1000

	fmt.Printf("=== BENCHMARK RESULTS ===\n")
	fmt.Printf("workers=%d requests_per_worker=%d total=%d\n", *workers, reqsPerWorker, actualTotal)
	fmt.Printf("ok=%d fail=%d\n", atomic.LoadInt64(&ok), atomic.LoadInt64(&fail))
	fmt.Printf("elapsed=%.3fs\n", dur.Seconds())
	fmt.Printf("throughput=%.1f req/s\n", qps)
	fmt.Printf("success_rate=%.2f%%\n", successRate)
	fmt.Printf("avg_latency_per_req=%.0f µs (%.3f ms)\n", avgLatencyUS, avgLatencyUS/1000)
	fmt.Printf("=== END ===\n")
}
