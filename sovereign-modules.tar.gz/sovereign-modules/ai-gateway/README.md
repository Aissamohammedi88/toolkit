# Sovereign AI Gateway (MODULE 4)

Reverse proxy HTTP en Go qui expose une **API unifiée au format OpenAI**
(`/v1/chat/completions`) et route les requêtes vers le meilleur modèle
disponible (local ou cloud) avec **cache des réponses** et **fallback mock
automatique**.

- **Zéro dépendance externe** (stdlib Go uniquement : `net/http`,
  `encoding/json`, `crypto/sha256`, `sync`, `time`, `context`).
- **Mode mock** : si un backend n'est pas joignable (pas de clé API, pas
  d'Ollama local), le gateway répond quand même avec un format OpenAI valide.
- **Latence ajoutée < 10 ms** (overhead routeur + cache lookup).
- **Supporte 1000+ requêtes/s** en mode mock.

---

## Architecture

```
        Client (curl, app, ...)
              │
              ▼
   ┌────────────────────────────────┐
   │   Sovereign AI Gateway (Go)    │
   │                                │
   │  POST /v1/chat/completions     │
   │     │                          │
   │     ▼                          │
   │  [ Cache SHA-256 lookup ]      │  ← HIT → réponse immédiate
   │     │ (miss)                   │
   │     ▼                          │
   │  [ Router ]                    │
   │     │ auto / explicite         │
   │     ▼                          │
   │  ┌──────┬──────┬──────────┐    │
   │  │ollama│openai│anthropic │    │
   │  └──────┴──────┴──────────┘    │
   │     │  erreur / pas de clé     │
   │     ▼                          │
   │  [ Mock fallback ]             │  ← "[MOCK] ..."
   │                                │
   └────────────────────────────────┘
```

### Fichiers

| Fichier       | Rôle                                                       |
|---------------|------------------------------------------------------------|
| `main.go`     | Point d'entrée, serveur HTTP, handlers, config loading.   |
| `router.go`   | Logique de routage (auto / explicite / mock fallback).    |
| `backends.go` | Adaptateurs Ollama / OpenAI / Anthropic / Mock.           |
| `cache.go`    | Cache SHA-256 + TTL + stats thread-safe.                  |
| `types.go`    | Structs OpenAI request / response.                        |
| `config.json` | Configuration des backends + routage.                     |

---

## Compilation & lancement

```bash
export PATH=$HOME/.local/go/bin:$PATH

# Compilation
cd /home/z/my-project/download/sovereign-modules/ai-gateway
go build -o ai-gateway .

# Lancement (écoute 127.0.0.1:9004 par défaut)
./ai-gateway -config config.json
```

---

## API

### `POST /v1/chat/completions`

Body entrant au format OpenAI strict :

```json
{
  "model": "auto",
  "messages": [{"role":"user","content":"Bonjour, qui es-tu ?"}],
  "temperature": 0.7,
  "max_tokens": 1000,
  "stream": false
}
```

Réponse au format OpenAI strict :

```json
{
  "id": "chatcmpl-mock-abc123",
  "object": "chat.completion",
  "created": 1699999999,
  "model": "auto",
  "choices": [
    {
      "index": 0,
      "message": {"role":"assistant","content":"[MOCK] réponse simulée ..."},
      "finish_reason": "stop"
    }
  ],
  "usage": {"prompt_tokens":5,"completion_tokens":12,"total_tokens":17}
}
```

**Headers de réponse utiles :**

| Header                   | Valeur                              |
|--------------------------|-------------------------------------|
| `X-Cache`                | `HIT` ou `MISS`                     |
| `X-Backend`              | `ollama`, `openai`, `anthropic`, `mock`, `cache` |
| `X-Forward-Latency-Us`   | overhead en microsecondes (< 10 ms) |

#### Routage

- `model: "auto"` :
  - prompt court (< 200 tokens estimés) → **ollama** (local)
  - prompt long  (≥ 200 tokens estimés) → **openai** (cloud)
- `model: "gpt-4o"`         → **openai**
- `model: "claude-3-5-..."` → **anthropic**
- `model: "llama3.2"`       → **ollama**
- Backend indisponible (pas de clé API, etc.) → **mock** automatique

#### Cache

La clé de cache est `SHA-256(normalized_prompt + model + temperature + max_tokens)`.
Une 2ᵉ requête identique est servie depuis le cache sans appeler le backend.

### `GET /health`

```json
{
  "status":"ok",
  "backends":["ollama","openai","anthropic"],
  "cache_size":0,
  "cache_hits":0,
  "cache_misses":0,
  "routes_total":0
}
```

### `GET /config`

Renvoie la configuration avec les clés API masquées (`""` reste `""`, une clé
non-vide devient `"***"`).

### `POST /cache/clear`

Vide le cache. Retourne `{"status":"ok","cleared":N}`.

### `GET /cache/stats`

```json
{
  "cache_hits": 1,
  "cache_misses": 2,
  "cache_size": 2,
  "hit_rate": 0.333
}
```

### `GET /`

Page d'accueil JSON décrivant le service et ses endpoints.

---

## Exemples `curl`

```bash
# 1. Requête auto (prompt court → ollama → mock fallback)
curl -s -X POST http://127.0.0.1:9004/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"auto","messages":[{"role":"user","content":"Bonjour"}]}' | jq

# 2. Requête OpenAI explicite (mock fallback car pas de clé API)
curl -s -X POST http://127.0.0.1:9004/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"gpt-4o","messages":[{"role":"user","content":"Hello"}]}'

# 3. Voir les headers de latence / cache
curl -s -i -X POST http://127.0.0.1:9004/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"auto","messages":[{"role":"user","content":"Salut"}]}'

# 4. Santé du service
curl -s http://127.0.0.1:9004/health | jq

# 5. Config masquée
curl -s http://127.0.0.1:9004/config | jq

# 6. Stats du cache
curl -s http://127.0.0.1:9004/cache/stats | jq

# 7. Vider le cache
curl -s -X POST http://127.0.0.1:9004/cache/clear | jq
```

---

## Backends

### Ollama (local, OpenAI-compatible)

- URL : `http://127.0.0.1:11434/v1/chat/completions`
- Pas besoin de clé API.
- Si Ollama n'est pas lancé → fallback mock automatique.

### OpenAI (cloud)

- URL : `https://api.openai.com/v1/chat/completions`
- Requiert une clé API (`api_key` dans `config.json`).
- Sans clé → fallback mock.

### Anthropic (cloud, format spécifique)

- URL : `https://api.anthropic.com/v1/messages`
- Format ≠ OpenAI : le gateway convertit automatiquement :
  - `system` messages → champ `system` Anthropic
  - `max_tokens` obligatoire (défaut 1024)
  - Headers `x-api-key` + `anthropic-version: 2023-06-01`
  - Réponse `content[].text` → `choices[0].message.content`
  - `stop_reason` `end_turn` → `stop`
- Sans clé → fallback mock.

### Mock (fallback local)

- Génère `"[MOCK] réponse simulée pour le modèle <X> — prompt: <Y>"`.
- Compte les tokens estimés (~4 chars/token).
- Toujours disponible, aucune I/O réseau.

---

## Performance

- **Latence overhead (cache + routing) : < 10 ms** (généralement < 1 ms).
  Mesurable via le header `X-Forward-Latency-Us`.
- **Throughput : 1000+ req/s** en mode mock (limité par le client, pas le gateway).
- Cache en mémoire (`sync.RWMutex` + atomics), TTL configurable.

---

## Limitations

- Pas de support du **streaming** (`stream: true` est ignoré, réponse complète renvoyée).
- Cache en mémoire uniquement (pas de persistance entre redémarrages).
- Estimation des tokens approximative (~4 chars/token).
- Mode mock ne produit pas de réponse intelligente — seulement un placeholder.
