package main

// backends.go — Adaptateurs pour chaque backend de modèle.
//
// Backends supportés :
//   - Ollama    (local, format OpenAI /v1/chat/completions)
//   - OpenAI    (cloud, format OpenAI natif)
//   - Anthropic (cloud, format /v1/messages — conversion vers/depuis OpenAI)
//   - Mock      (fallback local — génère une réponse factice "[MOCK] ...")
//
// Tous les backends respectent l'interface Backend. En cas d'indisponibilité
// (pas de clé API, backend injoignable, erreur HTTP), le routeur bascule
// vers le backend Mock afin que le gateway reste toujours fonctionnel.

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

// Backend est l'interface commune à tous les backends de modèle.
type Backend interface {
	Name() string
	Forward(ctx context.Context, req *ChatRequest) (*ChatResponse, error)
}

// ---------------------------------------------------------------------------
// Helpers partagés
// ---------------------------------------------------------------------------

// estimateTokens estime grossièrement le nombre de tokens (~4 chars/token).
func estimateTokens(s string) int {
	if s == "" {
		return 0
	}
	return (len(s) + 3) / 4
}

// truncate coupe une chaîne à n caractères en ajoutant "..." si nécessaire.
func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}

// randID génère un identifiant aléatoire de longueur n (chars alphanum).
func randID(n int) string {
	const charset = "abcdefghijklmnopqrstuvwxyz0123456789"
	b := make([]byte, n)
	_, _ = rand.Read(b)
	for i := range b {
		b[i] = charset[b[i]%byte(len(charset))]
	}
	return string(b)
}

// ---------------------------------------------------------------------------
// MockBackend — Réponse factice locale (aucun réseau)
// ---------------------------------------------------------------------------

// MockBackend génère une réponse simulée sans aucun appel réseau.
// Utilisé comme fallback lorsqu'un backend n'est pas joignable.
type MockBackend struct{}

func (m *MockBackend) Name() string { return "mock" }

func (m *MockBackend) Forward(ctx context.Context, req *ChatRequest) (*ChatResponse, error) {
	var userPrompt string
	for _, msg := range req.Messages {
		if msg.Role == "user" {
			userPrompt = msg.Content
			break
		}
	}
	if userPrompt == "" && len(req.Messages) > 0 {
		userPrompt = req.Messages[len(req.Messages)-1].Content
	}

	mockContent := fmt.Sprintf("[MOCK] réponse simulée pour le modèle %q — prompt: %q",
		req.Model, truncate(userPrompt, 80))

	promptTok := estimateTokens(userPrompt)
	complTok := estimateTokens(mockContent)

	return &ChatResponse{
		ID:      "chatcmpl-mock-" + randID(12),
		Object:  "chat.completion",
		Created: time.Now().Unix(),
		Model:   req.Model,
		Choices: []Choice{
			{
				Index:        0,
				Message:      Message{Role: "assistant", Content: mockContent},
				FinishReason: "stop",
			},
		},
		Usage: Usage{
			PromptTokens:     promptTok,
			CompletionTokens: complTok,
			TotalTokens:      promptTok + complTok,
		},
	}, nil
}

// ---------------------------------------------------------------------------
// OpenAICompatBackend — Ollama + OpenAI (même format OpenAI)
// ---------------------------------------------------------------------------

// OpenAICompatBackend sert pour les backends compatibles OpenAI (Ollama, OpenAI).
type OpenAICompatBackend struct {
	name         string
	url          string
	apiKey       string
	defaultModel string
	timeout      time.Duration
	client       *http.Client
}

func (b *OpenAICompatBackend) Name() string { return b.name }

func (b *OpenAICompatBackend) Forward(ctx context.Context, req *ChatRequest) (*ChatResponse, error) {
	// Mode mock immédiat si la clé API est requise mais absente (OpenAI cloud).
	if b.name == "openai" && b.apiKey == "" {
		return nil, fmt.Errorf("openai api_key not configured (mode mock)")
	}

	model := req.Model
	if model == "auto" || model == "" {
		model = b.defaultModel
	}

	payload := map[string]interface{}{
		"model":    model,
		"messages": req.Messages,
	}
	if req.Temperature > 0 {
		payload["temperature"] = req.Temperature
	}
	if req.MaxTokens > 0 {
		payload["max_tokens"] = req.MaxTokens
	}
	if req.Stream {
		payload["stream"] = false // Le gateway ne supporte pas le streaming pour l'instant.
	}

	body, err := json.Marshal(payload)
	if err != nil {
		return nil, fmt.Errorf("marshal payload: %w", err)
	}

	subCtx, cancel := context.WithTimeout(ctx, b.timeout)
	defer cancel()

	httpReq, err := http.NewRequestWithContext(subCtx, http.MethodPost, b.url, bytes.NewReader(body))
	if err != nil {
		return nil, fmt.Errorf("build request: %w", err)
	}
	httpReq.Header.Set("Content-Type", "application/json")
	if b.apiKey != "" {
		httpReq.Header.Set("Authorization", "Bearer "+b.apiKey)
	}

	resp, err := b.client.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("backend %s unreachable: %w", b.name, err)
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("read response: %w", err)
	}
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("backend %s returned status %d: %s",
			b.name, resp.StatusCode, truncate(string(respBody), 200))
	}

	var chatResp ChatResponse
	if err := json.Unmarshal(respBody, &chatResp); err != nil {
		return nil, fmt.Errorf("decode response: %w", err)
	}
	if chatResp.Object == "" {
		chatResp.Object = "chat.completion"
	}
	if chatResp.Model == "" {
		chatResp.Model = model
	}
	if len(chatResp.Choices) > 0 && chatResp.Choices[0].FinishReason == "" {
		chatResp.Choices[0].FinishReason = "stop"
	}
	return &chatResp, nil
}

// ---------------------------------------------------------------------------
// AnthropicBackend — Conversion de format OpenAI <-> Anthropic
// ---------------------------------------------------------------------------

// AnthropicBackend adapte le format OpenAI vers le format Anthropic /v1/messages.
type AnthropicBackend struct {
	url          string
	apiKey       string
	defaultModel string
	timeout      time.Duration
	client       *http.Client
}

func (b *AnthropicBackend) Name() string { return "anthropic" }

// anthropicRequest est le body entrant attendu par l'API Anthropic.
type anthropicRequest struct {
	Model     string    `json:"model"`
	Messages  []Message `json:"messages"`
	MaxTokens int       `json:"max_tokens"`
	System    string    `json:"system,omitempty"`
}

// anthropicResponse est la réponse renvoyée par l'API Anthropic.
type anthropicResponse struct {
	ID         string `json:"id"`
	Model      string `json:"model"`
	Content    []struct {
		Type string `json:"type"`
		Text string `json:"text"`
	} `json:"content"`
	StopReason string `json:"stop_reason"`
	Usage      struct {
		InputTokens  int `json:"input_tokens"`
		OutputTokens int `json:"output_tokens"`
	} `json:"usage"`
}

func (b *AnthropicBackend) Forward(ctx context.Context, req *ChatRequest) (*ChatResponse, error) {
	// Mode mock immédiat si la clé API Anthropic est absente.
	if b.apiKey == "" {
		return nil, fmt.Errorf("anthropic api_key not configured (mode mock)")
	}

	model := req.Model
	if model == "auto" || model == "" || model == "claude-3-5-sonnet" {
		model = b.defaultModel
	}

	// Extraction du system prompt + des messages conversationnels.
	var systemPrompt string
	var msgs []Message
	for _, m := range req.Messages {
		if m.Role == "system" {
			if systemPrompt != "" {
				systemPrompt += "\n"
			}
			systemPrompt += m.Content
		} else {
			msgs = append(msgs, m)
		}
	}
	if len(msgs) == 0 {
		msgs = req.Messages
	}

	maxTok := req.MaxTokens
	if maxTok <= 0 {
		maxTok = 1024
	}

	payload := anthropicRequest{
		Model:     model,
		Messages:  msgs,
		MaxTokens: maxTok,
		System:    strings.TrimSpace(systemPrompt),
	}

	body, err := json.Marshal(payload)
	if err != nil {
		return nil, fmt.Errorf("marshal payload: %w", err)
	}

	subCtx, cancel := context.WithTimeout(ctx, b.timeout)
	defer cancel()

	httpReq, err := http.NewRequestWithContext(subCtx, http.MethodPost, b.url, bytes.NewReader(body))
	if err != nil {
		return nil, fmt.Errorf("build request: %w", err)
	}
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("x-api-key", b.apiKey)
	httpReq.Header.Set("anthropic-version", "2023-06-01")

	resp, err := b.client.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("anthropic unreachable: %w", err)
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("read response: %w", err)
	}
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("anthropic returned status %d: %s",
			resp.StatusCode, truncate(string(respBody), 200))
	}

	var ar anthropicResponse
	if err := json.Unmarshal(respBody, &ar); err != nil {
		return nil, fmt.Errorf("decode anthropic response: %w", err)
	}

	// Conversion vers le format OpenAI strict.
	var text string
	for _, c := range ar.Content {
		if c.Type == "text" {
			text += c.Text
		}
	}
	finishReason := ar.StopReason
	if finishReason == "" {
		finishReason = "stop"
	}
	// Normalisation des stop reasons Anthropic -> OpenAI.
	switch finishReason {
	case "end_turn", "max_tokens", "stop_sequence":
		if finishReason == "end_turn" {
			finishReason = "stop"
		}
	}

	return &ChatResponse{
		ID:      ar.ID,
		Object:  "chat.completion",
		Created: time.Now().Unix(),
		Model:   ar.Model,
		Choices: []Choice{
			{
				Index:        0,
				Message:      Message{Role: "assistant", Content: text},
				FinishReason: finishReason,
			},
		},
		Usage: Usage{
			PromptTokens:     ar.Usage.InputTokens,
			CompletionTokens: ar.Usage.OutputTokens,
			TotalTokens:      ar.Usage.InputTokens + ar.Usage.OutputTokens,
		},
	}, nil
}
