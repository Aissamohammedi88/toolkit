#!/usr/bin/env python3
"""Generate a synthetic project with ~10 000 source files (100 dirs x 100 files)
covering Rust, Python, Go, JS, TS and Markdown, with cross-referencing imports
so the SCP DAG has non-trivial direct + indirect dependencies.

Each dir is single-language (cycling through 6 languages). Within a dir, files
form a chain: file_j imports file_(j+1). Go (package-level imports) instead
links each file to the next same-language dir's package.
"""
import os
import sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else "/tmp/scp-perf"
LANGS = ["rs", "py", "js", "ts", "go", "md"]
N_DIRS = 100
N_FILES = 100


def content_for(lang, d, f):
    nxt = f"file_{f + 1}"
    if f < N_FILES - 1:
        if lang == "rs":
            return f"use {nxt};\nfn f_{d}_{f}() {{}}\n"
        if lang == "py":
            return f"from {nxt} import x\n"
        if lang == "js":
            return f"const x = require('./{nxt}.js');\n"
        if lang == "ts":
            return f"import {{ x }} from './{nxt}';\n"
        if lang == "md":
            return f"# doc {d}_{f}\n\nSee [next](./{nxt}.md)\n"
        if lang == "go":
            nxt_dir = d + len(LANGS)
            if nxt_dir < N_DIRS:
                return f"package pkg{d}\n\nimport \"dir_{nxt_dir}\"\n"
            return f"package pkg{d}\n"
    # terminal file
    if lang == "rs":
        return f"fn f_{d}_{f}() {{}}\n"
    if lang == "py":
        return "x = 1\n"
    if lang == "js":
        return "module.exports = {};\n"
    if lang == "ts":
        return "export const x = 1;\n"
    if lang == "md":
        return f"# doc {d}_{f}\n"
    if lang == "go":
        return f"package pkg{d}\n"
    return ""


def main():
    os.makedirs(ROOT, exist_ok=True)
    total = 0
    for d in range(N_DIRS):
        lang = LANGS[d % len(LANGS)]
        dpath = os.path.join(ROOT, f"dir_{d}")
        os.makedirs(dpath, exist_ok=True)
        for f in range(N_FILES):
            path = os.path.join(dpath, f"file_{f}.{lang}")
            with open(path, "w") as fh:
                fh.write(content_for(lang, d, f))
            total += 1
    print(f"generated {total} files under {ROOT}")


if __name__ == "__main__":
    main()
