//! indexer.rs - Project walker + multi-language import parser + DAG builder.
//!
//! Strategy:
//!   1. Recursively walk `root`, collecting every source file we recognise.
//!      Build a `HashSet` of all known project-relative paths (for O(1) resolution
//!      checks) and a `HashMap<dir, Vec<file>>` (for Go package-level resolution).
//!   2. Parse every file in parallel (N worker threads, chunked by file count).
//!      Each worker extracts *raw* import strings (language specific, line based)
//!      and resolves them to concrete file paths using the known set.
//!   3. Merge the per-file resolved dependencies into a single `Dag`.
//!
//! Parsing is done line-by-line (no regex) for speed and zero heavy deps.

use crate::dag::Dag;
use std::collections::{HashMap, HashSet};
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::thread;
use std::time::Instant;

/// Extensions we treat as indexable source files.
const KNOWN_EXTS: &[&str] = &[
    "rs", "py", "go", "js", "jsx", "mjs", "cjs", "ts", "tsx", "md",
];

/// Directories we never descend into (build output / deps / VCS / hidden).
const IGNORED_DIRS: &[&str] = &[
    ".git",
    "target",
    "node_modules",
    "__pycache__",
    ".venv",
    "venv",
    ".idea",
    ".vscode",
    "dist",
    "build",
];

pub struct IndexResult {
    pub dag: Dag,
    pub elapsed_ms: u64,
    pub files_indexed: usize,
}

pub struct Indexer {
    pub root: PathBuf,
}

impl Indexer {
    pub fn new(root: PathBuf) -> Self {
        Self { root }
    }

    /// Build the dependency DAG from scratch. Returns timing + stats.
    pub fn build(&self) -> IndexResult {
        let start = Instant::now();

        // 1. walk
        let mut files: Vec<PathBuf> = Vec::new();
        walk(&self.root, &mut files);

        // 2. build lookup tables
        let mut known: HashSet<String> = HashSet::with_capacity(files.len());
        let mut dir_files: HashMap<String, Vec<String>> = HashMap::new();
        for f in &files {
            let rel = relpath(f, &self.root);
            known.insert(rel.clone());
            let dir = file_dir_of(&rel);
            dir_files.entry(dir).or_default().push(rel);
        }

        let known = Arc::new(known);
        let dir_files = Arc::new(dir_files);
        let root = Arc::new(self.root.clone());

        // 3. parallel parse
        let nthreads = thread::available_parallelism()
            .map(|n| n.get())
            .unwrap_or(2)
            .max(1)
            .min(files.len().max(1));
        let chunk = (files.len() + nthreads - 1) / nthreads;
        let chunks: Vec<Vec<PathBuf>> = if chunk == 0 {
            vec![files.clone()]
        } else {
            files.chunks(chunk).map(|c| c.to_vec()).collect()
        };

        let mut handles = Vec::new();
        for chunk in chunks {
            let known = Arc::clone(&known);
            let dir_files = Arc::clone(&dir_files);
            let root = Arc::clone(&root);
            handles.push(thread::spawn(move || -> Vec<(String, Vec<String>)> {
                let mut out = Vec::with_capacity(chunk.len());
                for f in chunk {
                    let rel = relpath(&f, &root);
                    let deps = parse_file(&f, &rel, &known, &dir_files);
                    out.push((rel, deps));
                }
                out
            }));
        }

        // 4. merge
        let mut dag = Dag::new();
        for h in handles {
            match h.join() {
                Ok(pairs) => {
                    for (file, deps) in pairs {
                        dag.add_node(&file);
                        for d in deps {
                            dag.add_edge(&file, &d);
                        }
                    }
                }
                Err(_) => eprintln!("[scp] worker thread panicked"),
            }
        }

        IndexResult {
            dag,
            elapsed_ms: start.elapsed().as_millis() as u64,
            files_indexed: files.len(),
        }
    }
}

// ---------------------------------------------------------------------------
// File system walking
// ---------------------------------------------------------------------------

fn walk(dir: &Path, out: &mut Vec<PathBuf>) {
    let entries = match fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return,
    };
    for entry in entries.flatten() {
        let path = entry.path();
        let name = entry.file_name();
        let name = name.to_string_lossy();
        if path.is_dir() {
            // Skip hidden dirs and known build/dep/VCS dirs.
            if name.starts_with('.') || IGNORED_DIRS.iter().any(|ig| *ig == &*name) {
                continue;
            }
            walk(&path, out);
        } else if path.is_file() {
            if let Some(ext) = path.extension().and_then(|e| e.to_str()) {
                if KNOWN_EXTS.iter().any(|e| *e == ext) {
                    out.push(path);
                }
            }
        }
    }
}

/// Project-relative path with `/` separators (canonical for the DAG keys).
pub fn relpath(file: &Path, root: &Path) -> String {
    let stripped = file
        .strip_prefix(root)
        .map(|p| p.to_path_buf())
        .unwrap_or_else(|_| file.to_path_buf());
    stripped.to_string_lossy().replace('\\', "/")
}

/// Directory portion (relative) of a file path: "dir_0/file_0.rs" -> "dir_0".
fn file_dir_of(rel: &str) -> String {
    match rel.rfind('/') {
        Some(i) => rel[..i].to_string(),
        None => String::new(),
    }
}

// ---------------------------------------------------------------------------
// Per-file dispatch
// ---------------------------------------------------------------------------

fn parse_file(
    path: &Path,
    rel: &str,
    known: &HashSet<String>,
    dir_files: &HashMap<String, Vec<String>>,
) -> Vec<String> {
    let ext = match path.extension().and_then(|e| e.to_str()) {
        Some(e) => e,
        None => return Vec::new(),
    };
    let content = match fs::read_to_string(path) {
        Ok(c) => c,
        Err(_) => return Vec::new(), // binary / unreadable -> no deps
    };
    let file_dir = file_dir_of(rel);

    let raw_imports: Vec<String> = match ext {
        "rs" => parse_rust(&content),
        "py" => parse_python(&content),
        "go" => parse_go(&content),
        "js" | "jsx" | "mjs" | "cjs" => parse_js(&content),
        "ts" | "tsx" => parse_js(&content),
        "md" => parse_markdown(&content),
        _ => Vec::new(),
    };

    let mut resolved: Vec<String> = Vec::new();
    for imp in raw_imports {
        let deps: Vec<String> = match ext {
            "rs" => filter_known(resolve_rust(&imp, &file_dir), known, rel),
            "py" => filter_known(resolve_python(&imp, &file_dir), known, rel),
            "js" | "jsx" | "mjs" | "cjs" => {
                filter_known(resolve_js(&imp, &file_dir, false), known, rel)
            }
            "ts" | "tsx" => filter_known(resolve_js(&imp, &file_dir, true), known, rel),
            "md" => filter_known(resolve_markdown(&imp, &file_dir), known, rel),
            "go" => resolve_go(&imp, &file_dir, rel, dir_files),
            _ => Vec::new(),
        };
        for d in deps {
            if !resolved.contains(&d) {
                resolved.push(d);
            }
        }
    }
    resolved
}

fn filter_known(cands: Vec<String>, known: &HashSet<String>, rel: &str) -> Vec<String> {
    cands.into_iter().filter(|c| known.contains(c) && c != rel).collect()
}

// ---------------------------------------------------------------------------
// Import parsers (line based, no regex)
// ---------------------------------------------------------------------------

/// Rust: `use a::b::c;`, `pub use ...`, `mod foo;`, `pub mod foo;`
fn parse_rust(src: &str) -> Vec<String> {
    let mut out = Vec::new();
    for line in src.lines() {
        let l = line.trim();
        let stripped = if let Some(r) = l.strip_prefix("pub ") {
            r.trim()
        } else {
            l
        };
        if let Some(rest) = stripped.strip_prefix("use ") {
            let path = take_until_terminator(rest);
            if !path.is_empty() {
                out.push(path.to_string());
            }
        } else if let Some(rest) = stripped.strip_prefix("mod ") {
            let name = take_until_terminator(rest);
            if !name.is_empty() {
                out.push(name.to_string());
            }
        }
    }
    out
}

/// Python: `import a.b`, `import a as b`, `from a.b import c`, `from .a import b`
fn parse_python(src: &str) -> Vec<String> {
    let mut out = Vec::new();
    for line in src.lines() {
        let l = line.trim();
        if let Some(rest) = l.strip_prefix("import ") {
            for part in rest.split(',') {
                // "a.b as x" -> keep "a.b"
                let name = part.split_whitespace().next().unwrap_or("");
                if !name.is_empty() {
                    out.push(name.to_string());
                }
            }
        } else if let Some(rest) = l.strip_prefix("from ") {
            if let Some(modpath) = rest.split_whitespace().next() {
                if modpath != "import" {
                    out.push(modpath.to_string());
                }
            }
        }
    }
    out
}

/// Go: single `import "pkg"` and block `import ( ... )`.
fn parse_go(src: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut in_block = false;
    for line in src.lines() {
        let l = line.trim();
        if !in_block && l.starts_with("import ") {
            if let Some(q) = extract_double_quoted(l) {
                out.push(q);
            }
            if l.contains('(') {
                in_block = true;
            }
            continue;
        }
        if in_block {
            if l == ")" {
                in_block = false;
                continue;
            }
            if let Some(q) = extract_double_quoted(l) {
                out.push(q);
            }
        }
    }
    out
}

/// JS/TS: `require('...')`, `require("...")`, `import ... from '...'`,
/// `import '...'`, `export ... from '...'`, dynamic `import('...')`.
fn parse_js(src: &str) -> Vec<String> {
    let mut out = Vec::new();
    for line in src.lines() {
        let l = line.trim();
        if l.starts_with("import") || l.starts_with("export") {
            if let Some(q) = first_quoted(l) {
                out.push(q);
            }
        }
        if let Some(pos) = l.find("require(") {
            let after = &l[pos + "require(".len()..];
            if let Some(q) = first_quoted(after) {
                out.push(q);
            }
        }
        if let Some(pos) = l.find("import(") {
            let after = &l[pos + "import(".len()..];
            if let Some(q) = first_quoted(after) {
                out.push(q);
            }
        }
    }
    out
}

/// Markdown: `[text](path)` reference links.
fn parse_markdown(src: &str) -> Vec<String> {
    let mut out = Vec::new();
    let bytes = src.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b']' && i + 1 < bytes.len() && bytes[i + 1] == b'(' {
            if let Some(close) = src[i + 2..].find(')') {
                let path = &src[i + 2..i + 2 + close];
                if !path.is_empty()
                    && !path.starts_with('#')
                    && !path.starts_with("http://")
                    && !path.starts_with("https://")
                    && !path.starts_with("mailto:")
                {
                    out.push(path.to_string());
                }
                i = i + 2 + close + 1;
                continue;
            }
        }
        i += 1;
    }
    out
}

// ---------------------------------------------------------------------------
// Parsing helpers
// ---------------------------------------------------------------------------

fn take_until_terminator(s: &str) -> &str {
    // Stop at `;`, `{` (grouped use) or end of line. We deliberately do NOT stop
    // on `:` so that `a::b::c` module paths are preserved.
    let end = s.find(|c: char| c == ';' || c == '{').unwrap_or(s.len());
    let t = s[..end].trim();
    // `use foo as bar;` -> keep only `foo`
    if let Some(idx) = t.find(" as ") {
        t[..idx].trim().trim_end_matches("::").trim()
    } else {
        t.trim_end_matches("::").trim()
    }
}

fn extract_double_quoted(s: &str) -> Option<String> {
    let start = s.find('"')?;
    let rest = &s[start + 1..];
    let end = rest.find('"')?;
    Some(rest[..end].to_string())
}

/// First single- or double-quoted string on the line.
fn first_quoted(s: &str) -> Option<String> {
    let (quote, start) = s
        .find('\'')
        .map(|p| ('\'', p))
        .or_else(|| s.find('"').map(|p| ('"', p)))?;
    let rest = &s[start + 1..];
    let end = rest.find(quote)?;
    Some(rest[..end].to_string())
}

// ---------------------------------------------------------------------------
// Resolution: raw import string -> candidate file paths (project-relative)
// ---------------------------------------------------------------------------

/// Combine a base directory and a relative path, resolving `.` and `..`.
fn normalize_join(base_dir: &str, rel: &str) -> String {
    let mut comps: Vec<&str> = if base_dir.is_empty() {
        Vec::new()
    } else {
        base_dir.split('/').collect()
    };
    let rel_stripped = rel.strip_prefix("./").unwrap_or(rel);
    for part in rel_stripped.split('/') {
        match part {
            "" | "." => {}
            ".." => {
                comps.pop();
            }
            other => comps.push(other),
        }
    }
    comps.join("/")
}

/// Generate candidate file paths for a "module path" (segments separated by `/`).
/// Tries the full path as a file, then progressively drops the last segment
/// (parent module re-export pattern). Each candidate is tried both relative to
/// `file_dir` and relative to the project root.
fn module_candidates(segments: &[&str], file_dir: &str, exts: &[&str], mod_file: &str) -> Vec<String> {
    let mut out = Vec::new();
    let bases: Vec<&str> = if file_dir.is_empty() {
        vec![""]
    } else {
        vec![file_dir, ""]
    };
    for n in (1..=segments.len()).rev() {
        let joined = segments[..n].join("/");
        for base in &bases {
            for ext in exts {
                let p = if base.is_empty() {
                    format!("{}.{}", joined, ext)
                } else {
                    format!("{}/{}.{}", base, joined, ext)
                };
                out.push(p);
            }
            let p = if base.is_empty() {
                format!("{}/{}", joined, mod_file)
            } else {
                format!("{}/{}/{}", base, joined, mod_file)
            };
            out.push(p);
        }
    }
    out
}

/// Rust `use a::b::c` / `mod foo` resolution. Handles `crate::`, `self::` and
/// `super::` qualifiers.
fn resolve_rust(imp: &str, file_dir: &str) -> Vec<String> {
    let mut s = imp.trim();
    let mut base_dir = file_dir.to_string();
    let mut relative = false;
    loop {
        if let Some(r) = s.strip_prefix("crate::") {
            s = r;
            base_dir.clear(); // crate-relative => root based
            relative = false;
        } else if let Some(r) = s.strip_prefix("self::") {
            s = r;
            relative = true; // current module
        } else if let Some(r) = s.strip_prefix("super::") {
            s = r;
            if let Some(i) = base_dir.rfind('/') {
                base_dir.truncate(i);
            } else {
                base_dir.clear();
            }
            relative = true;
        } else {
            break;
        }
    }

    let joined = s.replace("::", "/");
    let segments: Vec<&str> = joined.split('/').collect();

    if relative {
        let bases: Vec<&str> = if base_dir.is_empty() {
            vec![""]
        } else {
            vec![&base_dir]
        };
        let mut out = Vec::new();
        for n in (1..=segments.len()).rev() {
            let joined = segments[..n].join("/");
            for base in &bases {
                for ext in &["rs"] {
                    out.push(if base.is_empty() {
                        format!("{}.{}", joined, ext)
                    } else {
                        format!("{}/{}.{}", base, joined, ext)
                    });
                }
                out.push(if base.is_empty() {
                    format!("{}/mod.rs", joined)
                } else {
                    format!("{}/{}/mod.rs", base, joined)
                });
            }
        }
        out
    } else {
        module_candidates(&segments, &base_dir, &["rs"], "mod.rs")
    }
}

/// Python `import a.b` / `from .a import b` resolution.
fn resolve_python(imp: &str, file_dir: &str) -> Vec<String> {
    // Count leading dots for relative imports: `.x` (1), `..x` (2)...
    let mut chars = imp.chars().peekable();
    let mut dots = 0;
    while let Some(&c) = chars.peek() {
        if c == '.' {
            dots += 1;
            chars.next();
        } else {
            break;
        }
    }
    let rest: String = chars.collect();
    let rest = rest.trim();
    if rest.is_empty() {
        return Vec::new();
    }
    let joined = rest.replace('.', "/");
    let segments: Vec<&str> = joined.split('/').collect();

    if dots == 0 {
        module_candidates(&segments, file_dir, &["py"], "__init__.py")
    } else {
        // relative: dots=1 -> current dir, dots=2 -> parent, ...
        let mut base = file_dir.to_string();
        for _ in 1..dots {
            if let Some(i) = base.rfind('/') {
                base.truncate(i);
            } else {
                base.clear();
            }
        }
        let bases: Vec<&str> = if base.is_empty() {
            vec![""]
        } else {
            vec![&base]
        };
        let mut out = Vec::new();
        for n in (1..=segments.len()).rev() {
            let joined = segments[..n].join("/");
            for base in &bases {
                out.push(if base.is_empty() {
                    format!("{}.py", joined)
                } else {
                    format!("{}/{}.py", base, joined)
                });
                out.push(if base.is_empty() {
                    format!("{}/__init__.py", joined)
                } else {
                    format!("{}/{}/__init__.py", base, joined)
                });
            }
        }
        out
    }
}

/// JS/TS `require('./x')` / `import ... from './x'` resolution.
fn resolve_js(imp: &str, file_dir: &str, typescript: bool) -> Vec<String> {
    // Only relative specifiers resolve to local files. Bare specifiers
    // (`react`, `lodash`) are external packages -> ignored.
    if !imp.starts_with("./") && !imp.starts_with("../") && !imp.starts_with('/') {
        return Vec::new();
    }
    let normalized = if imp.starts_with('/') {
        imp.trim_start_matches('/').to_string()
    } else {
        normalize_join(file_dir, imp)
    };

    // If the import already carries an extension, use it verbatim.
    let has_ext = normalized
        .rsplit('/')
        .next()
        .map(|name| name.contains('.'))
        .unwrap_or(false);

    let mut out = Vec::new();
    if has_ext {
        out.push(normalized.clone());
    } else {
        let exts: &[&str] = if typescript {
            &["ts", "tsx", "js", "jsx", "d.ts"]
        } else {
            &["js", "jsx", "mjs", "cjs", "json"]
        };
        for ext in exts {
            out.push(format!("{}.{}", normalized, ext));
        }
        for ext in exts {
            out.push(format!("{}/index.{}", normalized, ext));
        }
    }
    out
}

/// Markdown `[text](path)` resolution. Keeps the link path as-is (relative).
fn resolve_markdown(imp: &str, file_dir: &str) -> Vec<String> {
    if imp.starts_with("http://") || imp.starts_with("https://") || imp.starts_with('#') {
        return Vec::new();
    }
    let mut out = Vec::new();
    if imp.starts_with("./") || imp.starts_with("../") {
        out.push(normalize_join(file_dir, imp));
    } else if imp.starts_with('/') {
        out.push(imp.trim_start_matches('/').to_string());
    } else {
        // bare relative path: try file_dir then root
        if !file_dir.is_empty() {
            out.push(format!("{}/{}", file_dir, imp));
        }
        out.push(imp.to_string());
    }
    out
}

/// Go `import "pkg/path"` resolution. Go imports are package-level: the path
/// maps to a *directory*, and every `.go` file in that directory is a dependency.
/// Returns concrete file paths (already known to exist via `dir_files`).
fn resolve_go(
    imp: &str,
    file_dir: &str,
    current: &str,
    dir_files: &HashMap<String, Vec<String>>,
) -> Vec<String> {
    let pkg = imp.trim().trim_start_matches("./").to_string();
    if pkg.is_empty() {
        return Vec::new();
    }
    // Candidate package directories: the import path as-is, or resolved
    // relative to the importing file's directory (rare in Go but supported).
    let mut candidates: Vec<String> = Vec::new();
    candidates.push(pkg.clone());
    if !file_dir.is_empty() {
        let rel = normalize_join(file_dir, &format!("./{}", pkg));
        candidates.push(rel);
    }

    let mut out = Vec::new();
    for cand in candidates {
        if let Some(files) = dir_files.get(&cand) {
            for f in files {
                if f.ends_with(".go") && f != current && !out.contains(f) {
                    out.push(f.clone());
                }
            }
        }
    }
    out
}

// ---------------------------------------------------------------------------
// Security rules (file path / extension based heuristics)
// ---------------------------------------------------------------------------

/// Heuristic security rules attached to a file in `/context` responses.
pub fn security_rules(rel: &str) -> Vec<String> {
    let lower = rel.to_lowercase();
    let mut rules: Vec<String> = Vec::new();

    let is_source = lower.ends_with(".rs")
        || lower.ends_with(".py")
        || lower.ends_with(".go")
        || lower.ends_with(".js")
        || lower.ends_with(".jsx")
        || lower.ends_with(".mjs")
        || lower.ends_with(".cjs")
        || lower.ends_with(".ts")
        || lower.ends_with(".tsx");

    if is_source {
        rules.push("no-secrets".into());
        rules.push("tests-required".into());
    }
    if lower.ends_with(".md") {
        rules.push("docs-only".into());
    }
    if lower.contains("/test/")
        || lower.contains("/tests/")
        || lower.contains("/spec/")
        || lower.contains("/__tests__/")
        || lower.contains("_test.go")
        || lower.contains("_test.rs")
        || lower.ends_with(".test.js")
        || lower.ends_with(".test.ts")
        || lower.ends_with(".spec.js")
        || lower.ends_with(".spec.ts")
    {
        rules.push("is-test-file".into());
    }
    if lower.ends_with(".env")
        || lower.contains(".env.")
        || lower.ends_with(".key")
        || lower.ends_with(".pem")
        || lower.ends_with(".p12")
        || lower.ends_with(".pfx")
    {
        rules.push("secret-file-no-commit".into());
    }
    if lower.ends_with(".yml")
        || lower.ends_with(".yaml")
        || lower.ends_with(".toml")
        || lower.ends_with(".json")
        || lower.ends_with(".ini")
        || lower.ends_with(".cfg")
        || lower.ends_with(".conf")
    {
        rules.push("config-file".into());
        rules.push("no-secrets".into());
    }
    rules
}
