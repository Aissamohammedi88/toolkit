//! server.rs - Minimal HTTP/1.1 server (one thread per connection, hand-rolled
//! request parsing). Exposes `/health`, `/context`, `/dag`, `/reindex`.
//!
//! No async runtime, no framework: just `std::net::TcpListener` + threads.

use crate::dag::Dag;
use crate::indexer::{security_rules, Indexer};
use std::collections::HashMap;
use std::io::{BufRead, BufReader, Write};
use std::net::{TcpListener, TcpStream};
use std::path::PathBuf;
use std::sync::{Arc, RwLock};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

/// Mutable server state, guarded by a RwLock. Reads take a snapshot under a
/// short-lived read lock; `/reindex` rebuilds a fresh DAG *outside* the lock and
/// then swaps it in under a short write lock.
pub struct ServerState {
    pub dag: Dag,
    pub files_indexed: usize,
    pub elapsed_ms: u64,
    pub indexed_at: u64,
    pub root: PathBuf,
}

pub struct Server {
    pub root: PathBuf,
    pub bind: String,
}

impl Server {
    pub fn new(root: PathBuf, bind: String) -> Self {
        Self { root, bind }
    }

    pub fn run(self) -> std::io::Result<()> {
        // Initial indexation.
        let indexer = Indexer::new(self.root.clone());
        let result = indexer.build();
        eprintln!(
            "[scp] indexed {} files in {} ms",
            result.files_indexed, result.elapsed_ms
        );

        let state = Arc::new(RwLock::new(ServerState {
            dag: result.dag,
            files_indexed: result.files_indexed,
            elapsed_ms: result.elapsed_ms,
            indexed_at: unix_now(),
            root: self.root.clone(),
        }));

        let listener = TcpListener::bind(&self.bind)?;
        eprintln!("[scp] listening on http://{}", self.bind);

        for stream in listener.incoming() {
            match stream {
                Ok(s) => {
                    let state = Arc::clone(&state);
                    std::thread::spawn(move || {
                        if let Err(e) = handle_connection(s, state) {
                            eprintln!("[scp] connection error: {}", e);
                        }
                    });
                }
                Err(e) => eprintln!("[scp] accept error: {}", e),
            }
        }
        Ok(())
    }
}

fn handle_connection(mut stream: TcpStream, state: Arc<RwLock<ServerState>>) -> std::io::Result<()> {
    // A short read timeout protects the per-connection thread from hung clients.
    let _ = stream.set_read_timeout(Some(Duration::from_secs(10)));
    let _ = stream.set_write_timeout(Some(Duration::from_secs(10)));

    let mut reader = BufReader::new(stream.try_clone()?);

    let mut request_line = String::new();
    if reader.read_line(&mut request_line)? == 0 {
        return Ok(()); // empty request, peer closed
    }

    let parts: Vec<&str> = request_line.split_whitespace().collect();
    if parts.len() < 2 {
        send_json(&mut stream, 400, r#"{"error":"bad request"}"#)?;
        return Ok(());
    }
    let method = parts[0];
    let target = parts[1];

    // Drain headers until the blank separator.
    loop {
        let mut header = String::new();
        if reader.read_line(&mut header)? == 0 {
            break;
        }
        if header == "\r\n" || header == "\n" {
            break;
        }
    }

    let (path, query) = split_target(target);

    match (method, path.as_str()) {
        ("GET", "/health") => handle_health(&mut stream, &state),
        ("GET", "/context") => handle_context(&mut stream, &state, &query),
        ("GET", "/dag") => handle_dag(&mut stream, &state),
        ("POST", "/reindex") => handle_reindex(&mut stream, &state),
        _ => send_json(
            &mut stream,
            404,
            &serde_json::json!({"error":"not found","path":path}).to_string(),
        ),
    }
}

fn handle_health(stream: &mut TcpStream, state: &Arc<RwLock<ServerState>>) -> std::io::Result<()> {
    let s = state.read().expect("state lock poisoned");
    let body = serde_json::json!({
        "status": "ok",
        "files_indexed": s.files_indexed,
        "elapsed_ms": s.elapsed_ms,
        "indexed_at": s.indexed_at,
    });
    send_json(stream, 200, &body.to_string())
}

fn handle_context(
    stream: &mut TcpStream,
    state: &Arc<RwLock<ServerState>>,
    query: &HashMap<String, String>,
) -> std::io::Result<()> {
    let file = match query.get("file") {
        Some(f) if !f.is_empty() => f.clone(),
        _ => {
            return send_json(
                stream,
                400,
                &serde_json::json!({"error":"missing 'file' query parameter"}).to_string(),
            )
        }
    };

    let s = state.read().expect("state lock poisoned");
    let direct = s.dag.direct_deps(&file);
    let indirect = s.dag.indirect_deps(&file);
    let rules = security_rules(&file);

    let body = serde_json::json!({
        "file": file,
        "direct_deps": direct,
        "indirect_deps": indirect,
        "security_rules": rules,
        "indexed_at": s.indexed_at,
    });
    send_json(stream, 200, &body.to_string())
}

fn handle_dag(stream: &mut TcpStream, state: &Arc<RwLock<ServerState>>) -> std::io::Result<()> {
    let s = state.read().expect("state lock poisoned");
    send_json(stream, 200, &s.dag.dag_json().to_string())
}

fn handle_reindex(
    stream: &mut TcpStream,
    state: &Arc<RwLock<ServerState>>,
) -> std::io::Result<()> {
    let root = {
        let s = state.read().expect("state lock poisoned");
        s.root.clone()
    };
    // Rebuild outside the lock so concurrent reads keep being served.
    let indexer = Indexer::new(root);
    let result = indexer.build();
    let body = {
        let mut s = state.write().expect("state lock poisoned");
        s.dag = result.dag;
        s.files_indexed = result.files_indexed;
        s.elapsed_ms = result.elapsed_ms;
        s.indexed_at = unix_now();
        serde_json::json!({
            "status": "reindexed",
            "files_indexed": s.files_indexed,
            "elapsed_ms": s.elapsed_ms,
            "indexed_at": s.indexed_at,
        })
    };
    send_json(stream, 200, &body.to_string())
}

// ---------------------------------------------------------------------------
// HTTP plumbing
// ---------------------------------------------------------------------------

fn send_json(stream: &mut TcpStream, status: u16, body: &str) -> std::io::Result<()> {
    let reason = match status {
        200 => "OK",
        400 => "Bad Request",
        404 => "Not Found",
        500 => "Internal Server Error",
        _ => "OK",
    };
    let response = format!(
        "HTTP/1.1 {} {}\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
        status,
        reason,
        body.len(),
        body
    );
    stream.write_all(response.as_bytes())?;
    stream.flush()?;
    Ok(())
}

/// Split a request target into a path and a parsed query map.
fn split_target(target: &str) -> (String, HashMap<String, String>) {
    let (path, raw_query) = match target.find('?') {
        Some(i) => (&target[..i], &target[i + 1..]),
        None => (target, ""),
    };
    let mut query = HashMap::new();
    for pair in raw_query.split('&') {
        if pair.is_empty() {
            continue;
        }
        let (k, v) = match pair.find('=') {
            Some(i) => (&pair[..i], &pair[i + 1..]),
            None => (pair, ""),
        };
        query.insert(url_decode(k), url_decode(v));
    }
    (path.to_string(), query)
}

/// Minimal percent-decoding (handles %XX and `+` -> space).
fn url_decode(s: &str) -> String {
    let bytes = s.as_bytes();
    let mut out: Vec<u8> = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        let b = bytes[i];
        if b == b'+' {
            out.push(b' ');
            i += 1;
        } else if b == b'%' && i + 2 < bytes.len() {
            if let (Some(h), Some(l)) = (hex(bytes[i + 1]), hex(bytes[i + 2])) {
                out.push(h * 16 + l);
                i += 3;
            } else {
                out.push(b);
                i += 1;
            }
        } else {
            out.push(b);
            i += 1;
        }
    }
    String::from_utf8_lossy(&out).into_owned()
}

fn hex(b: u8) -> Option<u8> {
    match b {
        b'0'..=b'9' => Some(b - b'0'),
        b'a'..=b'f' => Some(b - b'a' + 10),
        b'A'..=b'F' => Some(b - b'A' + 10),
        _ => None,
    }
}

fn unix_now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}
