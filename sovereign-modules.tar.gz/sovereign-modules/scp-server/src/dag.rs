//! dag.rs - Directed Acyclic Graph of file dependencies.
//!
//! A node is a file's project-relative path (using `/` as separator).
//! An edge `A -> B` means "A depends on B" (A imports / references B).
//!
//! The graph is built once (at startup or on `/reindex`) and then served
//! read-only from memory. `indirect_deps` is computed lazily via BFS over the
//! transitive closure of the direct dependencies.

use std::collections::{HashMap, HashSet, VecDeque};

/// A dependency DAG: `edges[f]` = sorted-ish list of files that `f` directly depends on.
#[derive(Clone, Default)]
pub struct Dag {
    edges: HashMap<String, Vec<String>>,
}

impl Dag {
    pub fn new() -> Self {
        Self {
            edges: HashMap::new(),
        }
    }

    /// Ensure a node exists in the graph (even with no outgoing edges).
    pub fn add_node(&mut self, file: &str) {
        self.edges.entry(file.to_string()).or_default();
    }

    /// Add a directed edge `from -> to`. Duplicate edges are silently ignored.
    pub fn add_edge(&mut self, from: &str, to: &str) {
        if from == to {
            return; // self-loops are not meaningful dependencies
        }
        let v = self.edges.entry(from.to_string()).or_default();
        if !v.iter().any(|x| x == to) {
            v.push(to.to_string());
        }
    }

    /// Direct dependencies of `file` (imports that resolved to a known file).
    pub fn direct_deps(&self, file: &str) -> Vec<String> {
        match self.edges.get(file) {
            Some(v) => {
                let mut out = v.clone();
                out.sort();
                out.dedup();
                out
            }
            None => Vec::new(),
        }
    }

    /// Transitive dependencies reachable from `file`, excluding the direct deps
    /// and `file` itself. Computed by BFS over the adjacency list.
    pub fn indirect_deps(&self, file: &str) -> Vec<String> {
        let direct = self.direct_deps(file);
        let direct_set: HashSet<String> = direct.iter().cloned().collect();

        let mut visited: HashSet<String> = HashSet::new();
        visited.insert(file.to_string());
        // Seed the BFS with the direct deps (they are "visited" but not part of
        // the *indirect* set).
        let mut queue: VecDeque<String> = VecDeque::new();
        for d in &direct {
            visited.insert(d.clone());
            queue.push_back(d.clone());
        }

        let mut indirect: Vec<String> = Vec::new();
        while let Some(node) = queue.pop_front() {
            if let Some(deps) = self.edges.get(&node) {
                for dep in deps {
                    // newly discovered node => it is an indirect dependency
                    if visited.insert(dep.clone()) {
                        indirect.push(dep.clone());
                        queue.push_back(dep.clone());
                    }
                }
            }
        }

        indirect.sort();
        indirect.dedup();
        // Defensive: a node could be both direct and transitively reachable;
        // the spec defines indirect = transitive \ direct.
        indirect.retain(|x| !direct_set.contains(x));
        indirect
    }

    pub fn node_count(&self) -> usize {
        self.edges.len()
    }

    pub fn edge_count(&self) -> usize {
        self.edges.values().map(|v| v.len()).sum()
    }

    /// Serialize the whole DAG as a JSON value (sorted for deterministic output).
    pub fn dag_json(&self) -> serde_json::Value {
        let mut keys: Vec<&String> = self.edges.keys().collect();
        keys.sort();

        let mut map = serde_json::Map::new();
        for k in keys {
            let mut deps = self.edges.get(k).cloned().unwrap_or_default();
            deps.sort();
            deps.dedup();
            let arr: Vec<serde_json::Value> = deps
                .into_iter()
                .map(serde_json::Value::String)
                .collect();
            map.insert(k.clone(), serde_json::Value::Array(arr));
        }
        serde_json::json!({
            "node_count": self.node_count(),
            "edge_count": self.edge_count(),
            "edges": serde_json::Value::Object(map),
        })
    }
}
