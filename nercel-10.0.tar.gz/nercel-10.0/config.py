#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NERCEL v10.0 — registre d'options (200 options, 19 catégories).

Une seule source de vérité : chaque option déclarée ici est disponible
dans la CLI, l'API (/api/config) et le panneau Options du dashboard.
Persistance : ~/.nercel/config.json.
"""

from __future__ import annotations
import json
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

DATA_DIR = os.environ.get("NERCEL_DATA", os.path.expanduser("~/.nercel"))
CONFIG_PATH = os.path.join(DATA_DIR, "config.json")


@dataclass
class Option:
    key: str; category: str; type: str; default: Any
    choices: Optional[List[str]] = None
    min: Optional[float] = None; max: Optional[float] = None
    secret: bool = False; desc: str = ""

    def validate(self, value: Any) -> Tuple[bool, Any, str]:
        try:
            if self.type == "int":
                v = int(value)
                if self.min is not None and v < self.min: return False, None, f"{self.key} : minimum {self.min}"
                if self.max is not None and v > self.max: return False, None, f"{self.key} : maximum {self.max}"
                return True, v, ""
            if self.type == "bool":
                if isinstance(value, bool): return True, value, ""
                s = str(value).strip().lower()
                if s in ("1","true","oui","on","yes"): return True, True, ""
                if s in ("0","false","non","off","no"): return True, False, ""
                return False, None, f"{self.key} : booléen attendu"
            if self.type == "choice":
                s = str(value)
                if self.choices and s in self.choices: return True, s, ""
                return False, None, f"{self.key} : choix parmi {self.choices}"
            if self.type == "color":
                s = str(value).strip()
                if s.startswith("#") and len(s) in (4,7): return True, s, ""
                return False, None, f"{self.key} : couleur #rgb ou #rrggbb"
            return True, str(value), ""
        except (ValueError, TypeError) as e:
            return False, None, f"{self.key} : {e}"


# Helper compact : (key, cat, type, default, desc) + kwargs
def _o(key, cat, typ, default, desc="", **kw):
    kw["desc"] = desc
    return Option(key=key, category=cat, type=typ, default=default, **kw)

C = lambda *a, **k: list(a)  # alias choix

REGISTRY: List[Option] = [
    # === serveur (10) ====================================================== #
    _o("serveur.port","serveur","int",3923,min=1024,max=65535,desc="Port de l'orchestrateur."),
    _o("serveur.edge_port","serveur","int",8765,min=1024,max=65535,desc="Port du proxy edge NEXUS."),
    _o("serveur.host","serveur","str","127.0.0.1",desc="Adresse d'écoute (0.0.0.0 = réseau)."),
    _o("serveur.auto_open","serveur","bool",False,desc="Ouvrir le navigateur au démarrage."),
    _o("serveur.log_level","serveur","choice","info",choices=C("debug","info","warning","error"),desc="Verbosité des journaux."),
    _o("serveur.max_upload_mb","serveur","int",50,min=1,max=2048,desc="Taille max d'un dépôt, en Mo."),
    _o("serveur.graceful_shutdown","serveur","bool",True,desc="Terminer les requêtes avant arrêt."),
    _o("serveur.workers","serveur","int",4,min=1,max=64,desc="Threads de traitement concurrents."),
    _o("serveur.keepalive_s","serveur","int",30,min=1,max=300,desc="Durée keep-alive HTTP, en secondes."),
    _o("serveur.request_timeout_s","serveur","int",60,min=5,max=600,desc="Délai max d'une requête, en secondes."),

    # === editeur (10) ====================================================== #
    _o("editeur.editor","editeur","choice","auto",choices=C("auto","code","vscodium","cursor","vim","nano","micro","emacs","code-server","none"),desc="Éditeur lancé par `nercel edit`."),
    _o("editeur.args","editeur","str","",desc="Arguments supplémentaires de l'éditeur."),
    _o("editeur.open_on_deploy","editeur","bool",False,desc="Ouvrir le paquet déployé dans l'éditeur."),
    _o("editeur.format_on_save","editeur","bool",False,desc="Réindenter à la sauvegarde (expérimental)."),
    _o("editeur.tab_size","editeur","int",2,min=1,max=8,desc="Taille d'une tabulation."),
    _o("editeur.word_wrap","editeur","bool",True,desc="Retour à la ligne automatique."),
    _o("editeur.lint","editeur","bool",True,desc="Analyse statique en temps réel."),
    _o("editeur.autocomplete","editeur","bool",True,desc="Complétion automatique."),
    _o("editeur.font_family","editeur","choice","mono",choices=C("mono","fira","jetbrains","iosevka"),desc="Police de l'éditeur."),
    _o("editeur.font_size","editeur","int",14,min=10,max=24,desc="Taille de police de l'éditeur."),

    # === ia (12) =========================================================== #
    _o("ia.provider","ia","choice","pollinations",choices=C("pollinations","glm","openai","ollama","none"),desc="Fournisseur de modèle."),
    _o("ia.model","ia","str","glm-flash",desc="Identifiant du modèle."),
    _o("ia.temperature","ia","int",7,min=0,max=10,desc="Température (0 sobre, 10 créatif)."),
    _o("ia.max_tokens","ia","int",1024,min=64,max=8192,desc="Jetons max par réponse."),
    _o("ia.system_prompt","ia","str","Tu es l'assistant de NERCEL. Réponds en français, concis et exact.",desc="Consigne système."),
    _o("ia.streaming","ia","bool",True,desc="Diffuser la réponse au fil de l'eau."),
    _o("ia.fallback","ia","bool",True,desc="Revenir à Pollinations en cas d'échec."),
    _o("ia.top_p","ia","int",9,min=1,max=10,desc="Nucleus sampling (1-10)."),
    _o("ia.frequency_penalty","ia","int",0,min=0,max=10,desc="Pénalité de répétition."),
    _o("ia.presence_penalty","ia","int",0,min=0,max=10,desc="Pénalité de présence."),
    _o("ia.seed","ia","int",0,min=0,max=1000000,desc="Graine reproductible (0 = aléatoire)."),
    _o("ia.timeout_s","ia","int",25,min=5,max=120,desc="Délai max d'appel IA, en secondes."),

    # === ui (20) =========================================================== #
    _o("ui.theme","ui","choice","dark",choices=C("dark","light","cyber","solarized","nord","dracula","gruvbox"),desc="Thème du dashboard."),
    _o("ui.accent","ui","color","#7c5cff",desc="Couleur d'accent principale."),
    _o("ui.accent2","ui","color","#00d4ff",desc="Couleur d'accent secondaire."),
    _o("ui.bg","ui","color","#0e0f13",desc="Couleur de fond."),
    _o("ui.bg2","ui","color","#15171d",desc="Couleur de fond secondaire."),
    _o("ui.density","ui","choice","confortable",choices=C("compact","confortable","spacieux"),desc="Densité d'affichage."),
    _o("ui.font_size","ui","int",14,min=10,max=22,desc="Taille de police de base."),
    _o("ui.sidebar_collapsed","ui","bool",False,desc="Barre latérale repliée."),
    _o("ui.monospace","ui","choice","auto",choices=C("auto","mono","fira","jetbrains","iosevka"),desc="Police à chasse fixe."),
    _o("ui.animations","ui","bool",True,desc="Transitions et micro-animations."),
    _o("ui.radius","ui","int",10,min=0,max=24,desc="Rayon des arrondis, en pixels."),
    _o("ui.sidebar_width","ui","int",220,min=160,max=320,desc="Largeur de la barre latérale."),
    _o("ui.header_height","ui","int",56,min=40,max=80,desc="Hauteur de la barre supérieure."),
    _o("ui.tabs","ui","choice","top",choices=C("top","side","bottom"),desc="Position des onglets."),
    _o("ui.icon_set","ui","choice","emoji",choices=C("emoji","lucide","text","none"),desc="Jeu d'icônes."),
    _o("ui.title","ui","str","NERCEL",desc="Titre affiché dans la barre."),
    _o("ui.favicon","ui","str","N",desc="Lettre du favicon."),
    _o("ui.logo","ui","str","▲",desc="Symbole du logo."),
    _o("ui.blur","ui","int",8,min=0,max=30,desc="Flou du verre dépoli, en pixels."),
    _o("ui.glass","ui","bool",True,desc="Effet verre dépoli sur les panneaux."),

    # === securite (15) ===================================================== #
    _o("securite.auth_required","securite","bool",True,desc="Exiger une authentification."),
    _o("securite.session_timeout_min","securite","int",10080,min=1,max=525600,desc="Durée de session, en minutes (7j défaut)."),
    _o("securite.cors_origins","securite","str","*",desc="Origines CORS autorisées."),
    _o("securite.rate_limit_rpm","securite","int",120,min=0,max=10000,desc="Requêtes/min/IP (0 = illimité)."),
    _o("securite.api_key","securite","str","",secret=True,desc="Clé d'API machine."),
    _o("securite.password_algo","securite","choice","pbkdf2_sha256",choices=C("pbkdf2_sha256","argon2","scrypt"),desc="Algorithme de hachage des mots de passe."),
    _o("securite.pbkdf2_iterations","securite","int",200000,min=10000,max=1000000,desc="Itérations PBKDF2."),
    _o("securite.brute_force_lockout","securite","int",5,min=1,max=20,desc="Tentatives avant blocage."),
    _o("securite.https_only","securite","bool",False,desc="Forcer HTTPS (cookies sécurisés)."),
    _o("securite.cookie_secure","securite","bool",False,desc="Marquer les cookies Secure."),
    _o("securite.csrf","securite","bool",True,desc="Protection CSRF sur les formulaires."),
    _o("securite.jwt_expiry_min","securite","int",60,min=1,max=1440,desc="Durée de validité d'un JWT."),
    _o("securite.allowed_ips","securite","str","",desc="IP autorisées, séparées par virgules (vide = toutes)."),
    _o("securite.deny_ips","securite","str","",desc="IP bloquées, séparées par virgules."),
    _o("securite.audit_log","securite","bool",True,desc="Journaliser les actions sensibles."),

    # === donnees (12) ====================================================== #
    _o("donnees.data_dir","donnees","str",DATA_DIR,desc="Dossier racine des données."),
    _o("donnees.backup_on_start","donnees","bool",True,desc="Sauvegarder avant chaque démarrage."),
    _o("donnees.retention_days","donnees","int",30,min=0,max=3650,desc="Conservation des journaux, en jours."),
    _o("donnees.db_driver","donnees","choice","sqlite",choices=C("sqlite","json"),desc="Pilote de stockage."),
    _o("donnees.autosave_s","donnees","int",30,min=0,max=3600,desc="Sauvegarde auto, en secondes."),
    _o("donnees.backup_count","donnees","int",10,min=0,max=100,desc="Nombre de sauvegardes conservées."),
    _o("donnees.compress_logs","donnees","bool",True,desc="Compresser les journaux archivés."),
    _o("donnees.log_rotation","donnees","choice","size",choices=C("size","daily","never"),desc="Rotation des journaux."),
    _o("donnees.cache_ttl","donnees","int",300,min=0,max=86400,desc="Durée de vie du cache, en secondes."),
    _o("donnees.cache_max_mb","donnees","int",100,min=0,max=4096,desc="Taille max du cache, en Mo."),
    _o("donnees.index_on_startup","donnees","bool",False,desc="Réindexer les données au démarrage."),
    _o("donnees.vacuum","donnees","bool",True,desc="Compacter la base au démarrage."),

    # === deploiement (12) ================================================== #
    _o("deploiement.github_branch","deploiement","str","main",desc="Branche GitHub cible."),
    _o("deploiement.auto_commit","deploiement","bool",False,desc="Commit automatique avant push."),
    _o("deploiement.commit_prefix","deploiement","str","[nercel]",desc="Préfixe des commits auto."),
    _o("deploiement.registry_url","deploiement","str","",desc="URL d'un registre de paquets privé."),
    _o("deploiement.deploy_timeout","deploiement","int",120,min=10,max=1800,desc="Délai max d'un déploiement, en secondes."),
    _o("deploiement.rollback","deploiement","bool",True,desc="Repli automatique sur échec."),
    _o("deploiement.health_check","deploiement","bool",True,desc="Vérifier la santé après déploiement."),
    _o("deploiement.replicas","deploiement","int",1,min=1,max=20,desc="Réplicas à déployer."),
    _o("deploiement.env_file","deploiement","str",".env",desc="Fichier d'environnement à charger."),
    _o("deploiement.build_cmd","deploiement","str","",desc="Commande de build (vide = auto)."),
    _o("deploiement.artifact_dir","deploiement","str","dist",desc="Dossier d'artefacts à servir."),
    _o("deploiement.keep_releases","deploiement","int",5,min=0,max=50,desc="Versions précédentes conservées."),

    # === agents (12) ======================================================= #
    _o("agents.max_agents","agents","int",16,min=1,max=256,desc="Nombre maximal d'agents concurrents."),
    _o("agents.default_runtime","agents","choice","python",choices=C("python","node","bash","static"),desc="Runtime par défaut."),
    _o("agents.heartbeat_s","agents","int",15,min=1,max=300,desc="Intervalle de signal de vie."),
    _o("agents.log_retention_days","agents","int",7,min=0,max=365,desc="Conservation des journaux d'agents."),
    _o("agents.restart_policy","agents","choice","on-failure",choices=C("always","on-failure","never"),desc="Politique de redémarrage."),
    _o("agents.max_memory_mb","agents","int",256,min=16,max=8192,desc="Mémoire max par agent, en Mo."),
    _o("agents.max_cpu_pct","agents","int",50,min=1,max=100,desc="CPU max par agent, en pourcentage."),
    _o("agents.timeout_s","agents","int",300,min=10,max=3600,desc="Délai max d'exécution, en secondes."),
    _o("agents.sandbox","agents","bool",True,desc="Exécuter les agents en bac à sable."),
    _o("agents.allowed_modules","agents","str","",desc="Modules Python autorisés (vide = tous)."),
    _o("agents.auto_scale","agents","bool",False,desc="Mise à l'échelle automatique."),
    _o("agents.queue_size","agents","int",100,min=1,max=10000,desc="Taille de la file d'attente."),

    # === chat (12) ========================================================= #
    _o("chat.history_limit","chat","int",50,min=0,max=10000,desc="Messages conservés par conversation."),
    _o("chat.language","chat","choice","fr",choices=C("fr","en","es","de","auto"),desc="Langue imposée au modèle."),
    _o("chat.profanity_filter","chat","bool",False,desc="Filtrer les grossièretés."),
    _o("chat.temperature","chat","int",7,min=0,max=10,desc="Température du chat."),
    _o("chat.stream_chunk_s","chat","int",1,min=1,max=10,desc="Intervalle de stream, en dixièmes de seconde."),
    _o("chat.max_history_kb","chat","int",512,min=1,max=10240,desc="Taille max de l'historique, en Ko."),
    _o("chat.persona","chat","choice","assistant",choices=C("assistant","reviewer","devops","artist","writer"),desc="Persona du chat."),
    _o("chat.welcome_msg","chat","str","Salut 👋 Pose-moi une question.",desc="Message d'accueil."),
    _o("chat.suggestions","chat","bool",True,desc="Afficher les suggestions de prompts."),
    _o("chat.markdown","chat","bool",True,desc="Rendre le markdown."),
    _o("chat.code_highlight","chat","bool",True,desc="Colorer le code."),
    _o("chat.voice_input","chat","bool",False,desc="Saisie vocale (expérimental)."),

    # === observabilite (10) ================================================ #
    _o("observabilite.metrics_enabled","observabilite","bool",True,desc="Collecter les métriques."),
    _o("observabilite.tracing","observabilite","bool",False,desc="Traçage distribué."),
    _o("observabilite.sentry_dsn","observabilite","str","",secret=True,desc="DSN Sentry."),
    _o("observabilite.prometheus_port","observabilite","int",9090,min=1024,max=65535,desc="Port d'export Prometheus."),
    _o("observabilite.log_format","observabilite","choice","text",choices=C("text","json"),desc="Format des journaux."),
    _o("observabilite.log_to_file","observabilite","bool",True,desc="Écrire les journaux en fichier."),
    _o("observabilite.log_to_stdout","observabilite","bool",True,desc="Écrire les journaux sur la sortie."),
    _o("observabilite.slow_query_ms","observabilite","int",500,min=1,max=60000,desc="Seuil de requête lente, en ms."),
    _o("observabilite.health_path","observabilite","str","/api/health",desc="Route de sonde de santé."),
    _o("observabilite.uptime_path","observabilite","str","/api/status",desc="Route de disponibilité."),

    # === reseau (10) ======================================================= #
    _o("reseau.proxy_url","reseau","str","",desc="Proxy sortant HTTP(S)."),
    _o("reseau.proxy_user","reseau","str","",desc="Utilisateur du proxy."),
    _o("reseau.dns_ttl","reseau","int",60,min=0,max=3600,desc="Durée de vie du cache DNS, en secondes."),
    _o("reseau.tcp_keepalive","reseau","bool",True,desc="Keep-alive TCP."),
    _o("reseau.max_connections","reseau","int",100,min=1,max=10000,desc="Connexions simultanées max."),
    _o("reseau.connection_pool","reseau","int",20,min=1,max=500,desc="Taille du pool de connexions."),
    _o("reseau.websocket","reseau","bool",True,desc="Activer les WebSockets."),
    _o("reseau.sse","reseau","bool",True,desc="Activer les Server-Sent Events."),
    _o("reseau.ipv6","reseau","bool",False,desc="Écouter en IPv6."),
    _o("reseau.bind_retry","reseau","int",3,min=0,max=10,desc="Tentatives de liaison au port."),

    # === stockage (8) ====================================================== #
    _o("stockage.driver","stockage","choice","local",choices=C("local","s3","minio"),desc="Pilote de stockage des artefacts."),
    _o("stockage.s3_endpoint","stockage","str","",desc="Point d'accès S3."),
    _o("stockage.s3_bucket","stockage","str","",desc="Nom du bucket S3."),
    _o("stockage.s3_region","stockage","str","",desc="Région S3."),
    _o("stockage.s3_access_key","stockage","str","",secret=True,desc="Clé d'accès S3."),
    _o("stockage.s3_secret","stockage","str","",secret=True,desc="Secret S3."),
    _o("stockage.local_root","stockage","str","",desc="Racine du stockage local."),
    _o("stockage.multipart_threshold","stockage","int",8,min=1,max=1024,desc="Seuil multipart, en Mo."),

    # === integration (10) ================================================== #
    _o("integration.github_token","integration","str","",secret=True,desc="Jeton GitHub (PAT)."),
    _o("integration.gitlab_token","integration","str","",secret=True,desc="Jeton GitLab."),
    _o("integration.slack_webhook","integration","str","",secret=True,desc="Webhook Slack."),
    _o("integration.discord_webhook","integration","str","",secret=True,desc="Webhook Discord."),
    _o("integration.email_smtp","integration","str","",desc="Hôte SMTP."),
    _o("integration.email_from","integration","str","",desc="Adresse expéditeur."),
    _o("integration.telegram_token","integration","str","",secret=True,desc="Jeton Telegram."),
    _o("integration.mattermost_url","integration","str","",desc="URL Mattermost."),
    _o("integration.webhook_secret","integration","str","",secret=True,desc="Secret de signature des webhooks."),
    _o("integration.oauth_client_id","integration","str","",desc="Client OAuth."),

    # === localisation (8) ================================================== #
    _o("localisation.locale","localisation","choice","fr_FR",choices=C("fr_FR","en_US","es_ES","de_DE","it_IT","pt_BR","ja_JP","zh_CN"),desc="Locale."),
    _o("localisation.timezone","localisation","str","Europe/Paris",desc="Fuseau horaire."),
    _o("localisation.date_format","localisation","choice","dmy",choices=C("dmy","mdy","ymd"),desc="Ordre des dates."),
    _o("localisation.time_format","localisation","choice","24h",choices=C("24h","12h"),desc="Format horaire."),
    _o("localisation.first_day_week","localisation","choice","monday",choices=C("monday","sunday","saturday"),desc="Premier jour de la semaine."),
    _o("localisation.currency","localisation","str","EUR",desc="Code devise."),
    _o("localisation.number_format","localisation","choice","fr",choices=C("fr","en","de","ch"),desc="Format des nombres."),
    _o("localisation.rtl","localisation","bool",False,desc="Interface de droite à gauche."),

    # === accessibilite (7) ================================================= #
    _o("accessibilite.contrast","accessibilite","choice","normal",choices=C("normal","high","maximum"),desc="Niveau de contraste."),
    _o("accessibilite.font_scale","accessibilite","int",100,min=80,max=200,desc="Échelle de police, en pourcentage."),
    _o("accessibilite.reduce_motion","accessibilite","bool",False,desc="Réduire les animations."),
    _o("accessibilite.focus_ring","accessibilite","bool",True,desc="Anneau de focus visible."),
    _o("accessibilite.screen_reader_hints","accessibilite","bool",True,desc="Annotations aria étendues."),
    _o("accessibilite.keyboard_nav","accessibilite","bool",True,desc="Navigation clavier complète."),
    _o("accessibilite.high_contrast","accessibilite","bool",False,desc="Mode contraste élevé."),

    # === developpement (10) ================================================ #
    _o("developpement.debug","developpement","bool",False,desc="Mode débogage."),
    _o("developpement.hot_reload","developpement","bool",False,desc="Rechargement à chaud."),
    _o("developpement.source_maps","developpement","bool",True,desc="Générer les source maps."),
    _o("developpement.profile","developpement","bool",False,desc="Profilage des performances."),
    _o("developpement.mock_ia","developpement","bool",False,desc="Bouchonner les réponses IA."),
    _o("developpement.test_on_deploy","developpement","bool",False,desc="Lancer les tests avant déploiement."),
    _o("developpement.lint_on_save","developpement","bool",True,desc="Lint à la sauvegarde."),
    _o("developpement.watch_paths","developpement","str","",desc="Dossiers surveillés (virgules)."),
    _o("developpement.ignore_patterns","developpement","str","node_modules,.git,dist",desc="Motifs ignorés."),
    _o("developpement.cache_bust","developpement","bool",True,desc="Invalider le cache par hash."),

    # === routing (8) ======================================================= #
    _o("routing.base_path","routing","str","",desc="Préfixe de toutes les routes."),
    _o("routing.trailing_slash","routing","choice","strip",choices=C("strip","add","keep"),desc="Slash final d'URL."),
    _o("routing.default_route","routing","str","/",desc="Route par défaut."),
    _o("routing.404_page","routing","str","",desc="Page 404 personnalisée."),
    _o("routing.redirects","routing","str","",desc="Redirections (src->dst, une par ligne)."),
    _o("routing.rewrite_rules","routing","str","",desc="Règles de réécriture."),
    _o("routing.spa_fallback","routing","bool",False,desc="Repli SPA sur 404."),
    _o("routing.cache_rules","routing","str","",desc="Règles de cache par route."),

    # === notifications (7) ================================================= #
    _o("notifications.enabled","notifications","bool",True,desc="Activer les notifications."),
    _o("notifications.desktop","notifications","bool",True,desc="Notifications navigateur."),
    _o("notifications.sound","notifications","bool",False,desc="Son à la notification."),
    _o("notifications.position","notifications","choice","bottom-right",choices=C("top-left","top-right","bottom-left","bottom-right"),desc="Position des toasts."),
    _o("notifications.duration","notifications","int",4000,min=500,max=30000,desc="Durée d'un toast, en ms."),
    _o("notifications.group_by","notifications","choice","category",choices=C("category","severity","none"),desc="Regroupement des toasts."),
    _o("notifications.do_not_disturb","notifications","bool",False,desc="Ne pas déranger."),

    # === clavier (7) ======================================================= #
    _o("clavier.shortcuts","clavier","bool",True,desc="Activer les raccourcis."),
    _o("clavier.vim_mode","clavier","bool",False,desc="Mode vim dans l'éditeur."),
    _o("clavier.emacs_mode","clavier","bool",False,desc="Mode emacs dans l'éditeur."),
    _o("clavier.modifier","clavier","choice","ctrl",choices=C("ctrl","alt","cmd"),desc="Touche modificateur."),
    _o("clavier.quick_save","clavier","str","ctrl+s",desc="Raccourci de sauvegarde."),
    _o("clavier.command_palette","clavier","str","ctrl+k",desc="Raccourci de la palette de commandes."),
    _o("clavier.hotkey_theme","clavier","choice","default",choices=C("default","vscode","intellij"),desc="Thème de raccourcis."),
]

_BY_KEY: Dict[str, Option] = {o.key: o for o in REGISTRY}

def categories() -> List[str]:
    seen, out = set(), []
    for o in REGISTRY:
        if o.category not in seen:
            seen.add(o.category); out.append(o.category)
    return out

def options_in(category: str) -> List[Option]:
    return [o for o in REGISTRY if o.category == category]

def get_option(key: str) -> Optional[Option]:
    return _BY_KEY.get(key)

def _load_disk() -> Dict[str, Any]:
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def _save_disk(values: Dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(values, f, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(tmp, CONFIG_PATH)

class Config:
    def __init__(self) -> None:
        self._disk = _load_disk()
    def all(self) -> Dict[str, Any]:
        return {o.key: self._disk.get(o.key, o.default) for o in REGISTRY}
    def get(self, key: str) -> Any:
        o = _BY_KEY.get(key)
        if o is None: raise KeyError(key)
        return self._disk.get(key, o.default)
    def describe(self, key: str) -> Dict[str, Any]:
        o = _BY_KEY[key]
        return {"key":o.key,"category":o.category,"type":o.type,"default":o.default,
                "choices":o.choices,"min":o.min,"max":o.max,"secret":o.secret,
                "desc":o.desc,"value":self.get(key)}
    def registry(self) -> List[Dict[str, Any]]:
        return [self.describe(o.key) for o in REGISTRY]
    def set(self, key: str, value: Any) -> Tuple[bool, str]:
        o = _BY_KEY.get(key)
        if o is None: return False, f"Option inconnue : {key}"
        ok, norm, msg = o.validate(value)
        if not ok: return False, msg
        self._disk[key] = norm; _save_disk(self._disk)
        return True, f"{key} = {norm!r}"
    def reset(self, key: str) -> Tuple[bool, str]:
        o = _BY_KEY.get(key)
        if o is None: return False, f"Option inconnue : {key}"
        self._disk.pop(key, None); _save_disk(self._disk)
        return True, f"{key} réinitialisée à {o.default!r}"

CFG = Config()
